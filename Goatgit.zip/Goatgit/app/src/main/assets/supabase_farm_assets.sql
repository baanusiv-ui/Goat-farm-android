-- ==============================================================================
-- Supabase Schema: create_farm_assets
-- Table: public.farm_assets
-- Description: Supports Farm Asset & Infrastructure tracking with columns for
-- name, category, purchase_date, cost, useful_life, current_condition,
-- location, warranty_expiry, maintenance_schedule, and depreciation metrics.
-- ==============================================================================

CREATE TABLE IF NOT EXISTS public.farm_assets (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name TEXT NOT NULL,
    category TEXT NOT NULL, -- 'Farm Buildings', 'Farm Infrastructure', 'Equipment', 'Vehicles'
    purchase_date DATE,
    cost NUMERIC(14, 2) NOT NULL DEFAULT 0.00,
    useful_life INTEGER NOT NULL DEFAULT 5, -- Useful life in years
    current_condition TEXT NOT NULL DEFAULT 'Good', -- 'Excellent', 'Good', 'Fair', 'Poor', 'Damaged'
    location TEXT NOT NULL DEFAULT 'Main Shed',
    warranty_expiry DATE,
    maintenance_schedule TEXT DEFAULT 'Monthly', -- 'Daily', 'Weekly', 'Monthly', 'Quarterly', 'Half-yearly', 'Yearly'

    -- Extended Asset Lifecycle, Maintenance & Depreciation fields
    asset_id TEXT, -- Human-readable identifier e.g. AST-BLD-001
    supplier TEXT, -- Supplier or contractor name
    quantity INTEGER NOT NULL DEFAULT 1,
    status TEXT NOT NULL DEFAULT 'Active', -- 'Active', 'Under maintenance', 'Damaged', 'Sold', 'Disposed'
    amc_expiry DATE,
    last_maintenance DATE,
    next_maintenance DATE,
    residual_value NUMERIC(14, 2) NOT NULL DEFAULT 0.00,
    depreciation_method TEXT NOT NULL DEFAULT 'Straight-line',
    accumulated_depreciation NUMERIC(14, 2) NOT NULL DEFAULT 0.00,
    current_book_value NUMERIC(14, 2) NOT NULL DEFAULT 0.00,
    is_capex BOOLEAN NOT NULL DEFAULT true,
    notes TEXT,
    photo_url TEXT,
    document_urls JSONB DEFAULT '[]'::jsonb,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Comments on table and core columns
COMMENT ON TABLE public.farm_assets IS 'Farm Assets, Infrastructure, Equipment, and Vehicles tracking local and remote farm assets';
COMMENT ON COLUMN public.farm_assets.name IS 'Name or description of the farm asset';
COMMENT ON COLUMN public.farm_assets.category IS 'Asset category: Farm Buildings, Farm Infrastructure, Equipment, Vehicles';
COMMENT ON COLUMN public.farm_assets.purchase_date IS 'Date the asset was purchased or constructed';
COMMENT ON COLUMN public.farm_assets.cost IS 'Capital expenditure cost in INR (CAPEX)';
COMMENT ON COLUMN public.farm_assets.useful_life IS 'Estimated useful economic life in years';
COMMENT ON COLUMN public.farm_assets.current_condition IS 'Current asset physical condition (Excellent, Good, Fair, Poor, Damaged)';
COMMENT ON COLUMN public.farm_assets.location IS 'Farm location or shed where asset is installed';
COMMENT ON COLUMN public.farm_assets.warranty_expiry IS 'Expiry date of manufacturer or builder warranty';
COMMENT ON COLUMN public.farm_assets.maintenance_schedule IS 'Frequency of routine maintenance (Daily, Weekly, Monthly, etc.)';

-- Indexes for efficient queries and filtering
CREATE INDEX IF NOT EXISTS idx_farm_assets_category ON public.farm_assets(category);
CREATE INDEX IF NOT EXISTS idx_farm_assets_status ON public.farm_assets(status);
CREATE INDEX IF NOT EXISTS idx_farm_assets_next_maintenance ON public.farm_assets(next_maintenance);
CREATE INDEX IF NOT EXISTS idx_farm_assets_created_at ON public.farm_assets(created_at DESC);

-- Enable Row Level Security (RLS)
ALTER TABLE public.farm_assets ENABLE ROW LEVEL SECURITY;

-- Allow read access for authenticated and anonymous users
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_policies WHERE tablename = 'farm_assets' AND policyname = 'Allow public read access to farm_assets'
    ) THEN
        CREATE POLICY "Allow public read access to farm_assets"
            ON public.farm_assets FOR SELECT
            USING (true);
    END IF;
END $$;

-- Allow insert for authenticated and anonymous users
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_policies WHERE tablename = 'farm_assets' AND policyname = 'Allow public insert to farm_assets'
    ) THEN
        CREATE POLICY "Allow public insert to farm_assets"
            ON public.farm_assets FOR INSERT
            WITH CHECK (true);
    END IF;
END $$;

-- Allow update for authenticated and anonymous users
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_policies WHERE tablename = 'farm_assets' AND policyname = 'Allow public update to farm_assets'
    ) THEN
        CREATE POLICY "Allow public update to farm_assets"
            ON public.farm_assets FOR UPDATE
            USING (true)
            WITH CHECK (true);
    END IF;
END $$;

-- Allow delete for authenticated and anonymous users
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_policies WHERE tablename = 'farm_assets' AND policyname = 'Allow public delete from farm_assets'
    ) THEN
        CREATE POLICY "Allow public delete from farm_assets"
            ON public.farm_assets FOR DELETE
            USING (true);
    END IF;
END $$;

-- Trigger to auto-update updated_at timestamp
CREATE OR REPLACE FUNCTION update_farm_assets_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_farm_assets_updated_at ON public.farm_assets;
CREATE TRIGGER trg_farm_assets_updated_at
    BEFORE UPDATE ON public.farm_assets
    FOR EACH ROW
    EXECUTE FUNCTION update_farm_assets_updated_at();
