-- ==============================================================================
-- Supabase Migration: create_finance_modules
-- Tables:
--   1. financial_accounts (Cash, Bank, UPI multi-account ledger)
--   2. account_transactions (Every financial movement with 3-pillar classification)
--   3. recurring_expenses (Scheduled recurring farm expenses)
--   4. electricity_connections (EB meters & connections)
--   5. electricity_bills (EB billing, meter readings, unit consumption)
--   6. loans (Lenders, loan terms, EMI parameters)
--   7. loan_schedules (Amortization schedules, principal/interest breakdown)
--   8. suppliers (Creditor master, credit terms)
--   9. supplier_invoices (Accounts payable & purchases)
--   10. supplier_payments (Payment allocations against supplier invoices)
--   11. gst_settings (Configurable GST, business info, tax rates)
--   12. eway_bills (E-Way Bill register & transport details)
-- ==============================================================================

-- 1. Financial Accounts
CREATE TABLE IF NOT EXISTS public.financial_accounts (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    account_name TEXT NOT NULL,
    account_type TEXT NOT NULL DEFAULT 'CASH', -- CASH, CURRENT_BANK, SAVINGS_BANK, UPI, OTHER
    account_number TEXT,
    bank_name TEXT,
    ifsc_code TEXT,
    branch TEXT,
    opening_balance NUMERIC(14, 2) NOT NULL DEFAULT 0.00,
    current_balance NUMERIC(14, 2) NOT NULL DEFAULT 0.00,
    opening_date DATE,
    is_active BOOLEAN NOT NULL DEFAULT true,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 2. Account Transactions
CREATE TABLE IF NOT EXISTS public.account_transactions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    date DATE NOT NULL,
    account_id UUID NOT NULL REFERENCES public.financial_accounts(id) ON DELETE CASCADE,
    transaction_type TEXT NOT NULL, -- INCOME, EXPENSE, TRANSFER, DEPOSIT, WITHDRAWAL, CUSTOMER_RECEIPT, SUPPLIER_PAYMENT, LOAN_RECEIPT, LOAN_REPAYMENT, OWNER_INVESTMENT, OWNER_WITHDRAWAL
    amount NUMERIC(14, 2) NOT NULL,
    category TEXT NOT NULL,
    reference_id TEXT,
    to_account_id UUID REFERENCES public.financial_accounts(id) ON DELETE SET NULL,
    pillar TEXT NOT NULL DEFAULT 'OPERATING', -- OPERATING, INVESTING, FINANCING, NON_CASH
    description TEXT,
    related_entity_type TEXT, -- GOAT, SALE, FEED, MEDICINE, EB, SUPPLIER, LOAN, ASSET
    related_entity_id TEXT,
    created_by TEXT DEFAULT 'user',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 3. Recurring Expenses
CREATE TABLE IF NOT EXISTS public.recurring_expenses (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    expense_name TEXT NOT NULL,
    category TEXT NOT NULL,
    vendor TEXT,
    amount NUMERIC(14, 2) NOT NULL,
    frequency TEXT NOT NULL DEFAULT 'MONTHLY', -- DAILY, WEEKLY, MONTHLY, QUARTERLY, HALF_YEARLY, YEARLY
    start_date DATE NOT NULL,
    end_date DATE,
    next_due_date DATE NOT NULL,
    payment_account_id UUID REFERENCES public.financial_accounts(id) ON DELETE SET NULL,
    payment_method TEXT NOT NULL DEFAULT 'BANK',
    gst_applicable BOOLEAN NOT NULL DEFAULT false,
    gst_rate NUMERIC(5, 2) NOT NULL DEFAULT 0.00,
    notes TEXT,
    is_active BOOLEAN NOT NULL DEFAULT true,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 4. Electricity Connections
CREATE TABLE IF NOT EXISTS public.electricity_connections (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    connection_name TEXT NOT NULL,
    consumer_number TEXT NOT NULL,
    meter_number TEXT NOT NULL,
    service_provider TEXT NOT NULL,
    tariff_category TEXT NOT NULL DEFAULT 'Agricultural',
    location TEXT NOT NULL DEFAULT 'Main Shed',
    billing_cycle TEXT NOT NULL DEFAULT 'Monthly',
    is_active BOOLEAN NOT NULL DEFAULT true,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 5. Electricity Bills
CREATE TABLE IF NOT EXISTS public.electricity_bills (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    connection_id UUID NOT NULL REFERENCES public.electricity_connections(id) ON DELETE CASCADE,
    billing_period TEXT NOT NULL,
    bill_date DATE NOT NULL,
    due_date DATE NOT NULL,
    previous_reading NUMERIC(10, 2) NOT NULL,
    current_reading NUMERIC(10, 2) NOT NULL,
    units_consumed NUMERIC(10, 2) GENERATED ALWAYS AS (current_reading - previous_reading) STORED,
    base_amount NUMERIC(14, 2) NOT NULL,
    other_charges NUMERIC(14, 2) NOT NULL DEFAULT 0.00,
    tax_amount NUMERIC(14, 2) NOT NULL DEFAULT 0.00,
    total_bill NUMERIC(14, 2) NOT NULL,
    paid_amount NUMERIC(14, 2) NOT NULL DEFAULT 0.00,
    balance_amount NUMERIC(14, 2) NOT NULL,
    payment_date DATE,
    payment_account_id UUID REFERENCES public.financial_accounts(id) ON DELETE SET NULL,
    payment_status TEXT NOT NULL DEFAULT 'UNPAID', -- UNPAID, PARTIALLY_PAID, PAID
    notes TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 6. Loans & Borrowings
CREATE TABLE IF NOT EXISTS public.loans (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    lender TEXT NOT NULL,
    loan_name TEXT NOT NULL,
    loan_account_number TEXT NOT NULL,
    loan_type TEXT NOT NULL DEFAULT 'BANK_LOAN', -- BANK_LOAN, NBFC_LOAN, VEHICLE_LOAN, EQUIPMENT_LOAN, BUSINESS_LOAN, PERSONAL_LOAN, OTHER
    sanctioned_amount NUMERIC(14, 2) NOT NULL,
    disbursed_amount NUMERIC(14, 2) NOT NULL,
    interest_rate NUMERIC(5, 2) NOT NULL,
    interest_type TEXT NOT NULL DEFAULT 'Diminishing',
    tenure_months INT NOT NULL,
    emi_amount NUMERIC(14, 2) NOT NULL,
    start_date DATE NOT NULL,
    first_emi_date DATE NOT NULL,
    maturity_date DATE NOT NULL,
    processing_fee NUMERIC(14, 2) NOT NULL DEFAULT 0.00,
    outstanding_principal NUMERIC(14, 2) NOT NULL,
    total_interest_paid NUMERIC(14, 2) NOT NULL DEFAULT 0.00,
    total_principal_paid NUMERIC(14, 2) NOT NULL DEFAULT 0.00,
    disbursement_account_id UUID REFERENCES public.financial_accounts(id) ON DELETE SET NULL,
    status TEXT NOT NULL DEFAULT 'ACTIVE', -- ACTIVE, CLOSED, DEFAULTED
    notes TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 7. Loan Schedules
CREATE TABLE IF NOT EXISTS public.loan_schedules (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    loan_id UUID NOT NULL REFERENCES public.loans(id) ON DELETE CASCADE,
    emi_number INT NOT NULL,
    due_date DATE NOT NULL,
    opening_principal NUMERIC(14, 2) NOT NULL,
    principal_component NUMERIC(14, 2) NOT NULL,
    interest_component NUMERIC(14, 2) NOT NULL,
    emi_amount NUMERIC(14, 2) NOT NULL,
    closing_principal NUMERIC(14, 2) NOT NULL,
    paid_date DATE,
    paid_amount NUMERIC(14, 2) NOT NULL DEFAULT 0.00,
    payment_account_id UUID REFERENCES public.financial_accounts(id) ON DELETE SET NULL,
    status TEXT NOT NULL DEFAULT 'PENDING', -- PENDING, PAID, OVERDUE, PARTIAL
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 8. Suppliers
CREATE TABLE IF NOT EXISTS public.suppliers (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name TEXT NOT NULL,
    phone TEXT,
    address TEXT,
    gstin TEXT,
    credit_limit NUMERIC(14, 2) NOT NULL DEFAULT 0.00,
    credit_period_days INT NOT NULL DEFAULT 30,
    opening_balance NUMERIC(14, 2) NOT NULL DEFAULT 0.00,
    current_outstanding NUMERIC(14, 2) NOT NULL DEFAULT 0.00,
    is_active BOOLEAN NOT NULL DEFAULT true,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 9. Supplier Invoices
CREATE TABLE IF NOT EXISTS public.supplier_invoices (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    supplier_id UUID NOT NULL REFERENCES public.suppliers(id) ON DELETE CASCADE,
    invoice_number TEXT NOT NULL,
    invoice_date DATE NOT NULL,
    due_date DATE NOT NULL,
    items_description TEXT NOT NULL,
    quantity NUMERIC(10, 2) NOT NULL DEFAULT 1.00,
    rate NUMERIC(14, 2) NOT NULL DEFAULT 0.00,
    taxable_value NUMERIC(14, 2) NOT NULL,
    gst_rate NUMERIC(5, 2) NOT NULL DEFAULT 0.00,
    gst_amount NUMERIC(14, 2) NOT NULL DEFAULT 0.00,
    total_amount NUMERIC(14, 2) NOT NULL,
    paid_amount NUMERIC(14, 2) NOT NULL DEFAULT 0.00,
    balance_due NUMERIC(14, 2) NOT NULL,
    status TEXT NOT NULL DEFAULT 'UNPAID', -- UNPAID, PARTIALLY_PAID, PAID, OVERDUE
    notes TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 10. Supplier Payments
CREATE TABLE IF NOT EXISTS public.supplier_payments (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    invoice_id UUID NOT NULL REFERENCES public.supplier_invoices(id) ON DELETE CASCADE,
    supplier_id UUID NOT NULL REFERENCES public.suppliers(id) ON DELETE CASCADE,
    payment_date DATE NOT NULL,
    amount NUMERIC(14, 2) NOT NULL,
    payment_account_id UUID NOT NULL REFERENCES public.financial_accounts(id) ON DELETE CASCADE,
    payment_mode TEXT NOT NULL DEFAULT 'BANK',
    reference_number TEXT,
    notes TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 11. GST Settings
CREATE TABLE IF NOT EXISTS public.gst_settings (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    gst_enabled BOOLEAN NOT NULL DEFAULT false,
    business_name TEXT NOT NULL DEFAULT 'Green Pastures Goat Farm',
    business_address TEXT NOT NULL DEFAULT 'Farm Road, Rural District',
    gstin TEXT NOT NULL DEFAULT '',
    state_name TEXT NOT NULL DEFAULT 'Tamil Nadu',
    state_code TEXT NOT NULL DEFAULT '33',
    invoice_prefix TEXT NOT NULL DEFAULT 'INV',
    next_invoice_number INT NOT NULL DEFAULT 1001,
    default_hsn TEXT NOT NULL DEFAULT '0104',
    default_tax_rate NUMERIC(5, 2) NOT NULL DEFAULT 5.00,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 12. E-Way Bills
CREATE TABLE IF NOT EXISTS public.eway_bills (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    invoice_id TEXT NOT NULL,
    invoice_number TEXT NOT NULL,
    supplier_gstin TEXT NOT NULL,
    recipient_gstin TEXT,
    place_of_supply TEXT NOT NULL,
    delivery_address TEXT NOT NULL,
    hsn_code TEXT NOT NULL,
    quantity NUMERIC(10, 2) NOT NULL,
    taxable_value NUMERIC(14, 2) NOT NULL,
    gst_amount NUMERIC(14, 2) NOT NULL,
    total_value NUMERIC(14, 2) NOT NULL,
    transporter_id TEXT,
    transporter_name TEXT,
    vehicle_number TEXT NOT NULL,
    transport_mode TEXT NOT NULL DEFAULT 'Road',
    transport_doc_number TEXT,
    document_date DATE NOT NULL,
    eway_bill_number TEXT,
    status TEXT NOT NULL DEFAULT 'Draft', -- Draft, Ready, Submitted, Generated, Active, Cancelled, Expired, Error
    error_message TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ==============================================================================
-- 13. SHARED 'transactions' TABLE (Multi-account Income, Expense, Transfer)
-- Transfers are strictly non-P&L (affects_pnl = false, pillar = 'NON_CASH')
-- ==============================================================================
CREATE TABLE IF NOT EXISTS public.transactions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    date DATE NOT NULL,
    account_id UUID REFERENCES public.financial_accounts(id) ON DELETE SET NULL,
    to_account_id UUID REFERENCES public.financial_accounts(id) ON DELETE SET NULL,
    transaction_type TEXT NOT NULL, -- 'INCOME', 'EXPENSE', 'TRANSFER'
    amount NUMERIC(14, 2) NOT NULL CHECK (amount >= 0),
    category TEXT NOT NULL,
    payment_mode TEXT NOT NULL DEFAULT 'Cash',
    reference_id TEXT,
    description TEXT,
    affects_pnl BOOLEAN NOT NULL DEFAULT true,
    pillar TEXT NOT NULL DEFAULT 'OPERATING',
    related_entity_type TEXT,
    related_entity_id TEXT,
    created_by TEXT DEFAULT 'user',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE OR REPLACE VIEW public.pnl_transactions AS
SELECT * FROM public.transactions
WHERE affects_pnl = true AND UPPER(transaction_type) != 'TRANSFER';

