package com.example.data.supabase

import android.content.Context
import com.example.BuildConfig

/**
 * Supabase client configuration containing URL endpoints, API keys,
 * authentication tokens, and real-time WebSocket connection settings.
 */
data class SupabaseClientConfig(
    val url: String = DEFAULT_URL,
    val apiKey: String = "",
    val autoConnectRealtime: Boolean = true,
    val timeoutSeconds: Long = 30L,
    val accessToken: String? = null,
    val refreshToken: String? = null,
    val userId: String? = null,
    val userEmail: String? = null
) {
    val websocketUrl: String
        get() {
            val wsScheme = if (url.startsWith("https://")) "wss://" else "ws://"
            val hostAndPath = url.removePrefix("https://").removePrefix("http://").trimEnd('/')
            return "$wsScheme$hostAndPath/realtime/v1/websocket?apikey=$apiKey&vsn=1.0.0"
        }

    val restUrl: String
        get() = "${url.trimEnd('/')}/rest/v1"

    val authUrl: String
        get() = "${url.trimEnd('/')}/auth/v1"

    val hasValidKey: Boolean
        get() = apiKey.isNotBlank() && !apiKey.startsWith("YOUR_")

    val isAuthenticated: Boolean
        get() = !accessToken.isNullOrBlank()

    fun toSupabaseConfig(): SupabaseConfig {
        val config = SupabaseConfig(url, apiKey)
        if (!accessToken.isNullOrBlank()) {
            config.saveSession(accessToken, refreshToken, userEmail, userId)
        }
        return config
    }

    companion object {
        const val DEFAULT_URL = "https://xrjoajpvrcfjpunoruom.supabase.co"
        const val TABLE_GOATS = "goats_c"

        fun fromContext(context: Context): SupabaseClientConfig {
            val cfg = SupabaseConfig(context)
            return SupabaseClientConfig(
                url = cfg.url,
                apiKey = cfg.publishableKey,
                accessToken = cfg.accessToken,
                refreshToken = cfg.refreshToken,
                userId = cfg.userId,
                userEmail = cfg.userEmail
            )
        }

        fun fromBuildConfig(): SupabaseClientConfig {
            val buildConfigUrl = try {
                BuildConfig::class.java.getField("VITE_SUPABASE_URL").get(null) as? String
            } catch (e: Exception) {
                null
            }
            val buildConfigKey = try {
                BuildConfig::class.java.getField("VITE_SUPABASE_PUBLISHABLE_KEY").get(null) as? String
            } catch (e: Exception) {
                null
            }
            return SupabaseClientConfig(
                url = if (!buildConfigUrl.isNullOrBlank()) buildConfigUrl.trimEnd('/') else DEFAULT_URL,
                apiKey = buildConfigKey?.trim() ?: ""
            )
        }

        fun default(): SupabaseClientConfig = fromBuildConfig()
    }
}
