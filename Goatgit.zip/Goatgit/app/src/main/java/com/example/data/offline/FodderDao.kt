package com.example.data.offline

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface FodderDao {

    // ==========================================
    // SPECIES MASTER
    // ==========================================
    @Query("SELECT * FROM local_fodder_species ORDER BY name ASC")
    fun getAllSpeciesFlow(): Flow<List<FodderSpeciesEntity>>

    @Query("SELECT * FROM local_fodder_species ORDER BY name ASC")
    suspend fun getAllSpecies(): List<FodderSpeciesEntity>

    @Query("SELECT * FROM local_fodder_species WHERE id = :id LIMIT 1")
    suspend fun getSpeciesById(id: String): FodderSpeciesEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateSpecies(species: FodderSpeciesEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllSpecies(list: List<FodderSpeciesEntity>)

    @Query("DELETE FROM local_fodder_species WHERE id = :id")
    suspend fun deleteSpeciesById(id: String)

    // ==========================================
    // FIELDS / PLOTS
    // ==========================================
    @Query("SELECT * FROM local_fodder_plots ORDER BY plot_name ASC")
    fun getAllPlotsFlow(): Flow<List<FodderPlotEntity>>

    @Query("SELECT * FROM local_fodder_plots ORDER BY plot_name ASC")
    suspend fun getAllPlots(): List<FodderPlotEntity>

    @Query("SELECT * FROM local_fodder_plots WHERE id = :id LIMIT 1")
    suspend fun getPlotById(id: String): FodderPlotEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdatePlot(plot: FodderPlotEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllPlots(list: List<FodderPlotEntity>)

    @Query("DELETE FROM local_fodder_plots WHERE id = :id")
    suspend fun deletePlotById(id: String)

    // ==========================================
    // FIELD ROWS (ROW MASTER & STATUS)
    // ==========================================
    @Query("SELECT * FROM local_fodder_rows WHERE plot_id = :plotId ORDER BY row_index ASC")
    fun getRowsByPlotFlow(plotId: String): Flow<List<FodderRowEntity>>

    @Query("SELECT * FROM local_fodder_rows WHERE plot_id = :plotId ORDER BY row_index ASC")
    suspend fun getRowsByPlot(plotId: String): List<FodderRowEntity>

    @Query("SELECT * FROM local_fodder_rows ORDER BY row_index ASC")
    suspend fun getAllRows(): List<FodderRowEntity>

    @Query("SELECT * FROM local_fodder_rows WHERE id = :id LIMIT 1")
    suspend fun getRowById(id: String): FodderRowEntity?

    @Query("SELECT * FROM local_fodder_rows WHERE plot_id = :plotId AND row_code = :rowCode LIMIT 1")
    suspend fun getRowByCode(plotId: String, rowCode: String): FodderRowEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateRow(row: FodderRowEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllRows(rows: List<FodderRowEntity>)

    @Query("UPDATE local_fodder_rows SET status = :status, last_cut_date = :lastCutDate, total_cuts = total_cuts + 1, total_yield_kg = total_yield_kg + :cutYieldKg, updated_at = :updatedAt WHERE id = :rowId")
    suspend fun updateRowHarvested(rowId: String, status: String, lastCutDate: String, cutYieldKg: Double, updatedAt: Long)

    @Query("UPDATE local_fodder_rows SET status = :status, updated_at = :updatedAt WHERE id = :rowId")
    suspend fun updateRowStatus(rowId: String, status: String, updatedAt: Long)

    @Query("DELETE FROM local_fodder_rows WHERE plot_id = :plotId")
    suspend fun deleteRowsByPlot(plotId: String)

    // ==========================================
    // CROP CYCLES
    // ==========================================
    @Query("SELECT * FROM local_fodder_crop_cycles WHERE plot_id = :plotId ORDER BY cycle_number DESC")
    fun getCropCyclesByPlotFlow(plotId: String): Flow<List<FodderCropCycleEntity>>

    @Query("SELECT * FROM local_fodder_crop_cycles WHERE plot_id = :plotId ORDER BY cycle_number DESC")
    suspend fun getCropCyclesByPlot(plotId: String): List<FodderCropCycleEntity>

    @Query("SELECT * FROM local_fodder_crop_cycles ORDER BY cycle_number DESC")
    suspend fun getAllCropCycles(): List<FodderCropCycleEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCropCycle(cycle: FodderCropCycleEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllCropCycles(list: List<FodderCropCycleEntity>)

    // ==========================================
    // PLANTING MATERIALS (SEED / SLIPS INVENTORY)
    // ==========================================
    @Query("SELECT * FROM local_fodder_materials ORDER BY purchase_date DESC")
    fun getAllMaterialsFlow(): Flow<List<FodderPlantingMaterialEntity>>

    @Query("SELECT * FROM local_fodder_materials ORDER BY purchase_date DESC")
    suspend fun getAllMaterials(): List<FodderPlantingMaterialEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateMaterial(material: FodderPlantingMaterialEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllMaterials(list: List<FodderPlantingMaterialEntity>)

    @Query("DELETE FROM local_fodder_materials WHERE id = :id")
    suspend fun deleteMaterialById(id: String)

    // ==========================================
    // CROP ACTIVITY HISTORY
    // ==========================================
    @Query("SELECT * FROM local_fodder_activities ORDER BY activity_date DESC, updated_at DESC")
    fun getAllActivitiesFlow(): Flow<List<FodderActivityEntity>>

    @Query("SELECT * FROM local_fodder_activities WHERE plot_id = :plotId ORDER BY activity_date DESC, updated_at DESC")
    fun getActivitiesByPlotFlow(plotId: String): Flow<List<FodderActivityEntity>>

    @Query("SELECT * FROM local_fodder_activities ORDER BY activity_date DESC, updated_at DESC")
    suspend fun getAllActivities(): List<FodderActivityEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertActivity(activity: FodderActivityEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllActivities(list: List<FodderActivityEntity>)

    @Query("DELETE FROM local_fodder_activities WHERE id = :id")
    suspend fun deleteActivityById(id: String)

    // ==========================================
    // CUTTINGS & HARVEST
    // ==========================================
    @Query("SELECT * FROM local_fodder_cuttings ORDER BY cutting_date DESC")
    fun getAllCuttingsFlow(): Flow<List<FodderCuttingEntity>>

    @Query("SELECT * FROM local_fodder_cuttings ORDER BY cutting_date DESC")
    suspend fun getAllCuttings(): List<FodderCuttingEntity>

    @Query("SELECT * FROM local_fodder_cuttings WHERE plot_id = :plotId ORDER BY cutting_date DESC")
    suspend fun getCuttingsByPlot(plotId: String): List<FodderCuttingEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCutting(cutting: FodderCuttingEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllCuttings(list: List<FodderCuttingEntity>)

    @Query("DELETE FROM local_fodder_cuttings WHERE id = :id")
    suspend fun deleteCuttingById(id: String)

    // ==========================================
    // FEEDINGS
    // ==========================================
    @Query("SELECT * FROM local_fodder_feedings ORDER BY feeding_date DESC")
    fun getAllFeedingsFlow(): Flow<List<FodderFeedingEntity>>

    @Query("SELECT * FROM local_fodder_feedings ORDER BY feeding_date DESC")
    suspend fun getAllFeedings(): List<FodderFeedingEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFeeding(feeding: FodderFeedingEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllFeedings(list: List<FodderFeedingEntity>)

    @Query("DELETE FROM local_fodder_feedings WHERE id = :id")
    suspend fun deleteFeedingById(id: String)

    // ==========================================
    // STOCK ADJUSTMENTS
    // ==========================================
    @Query("SELECT * FROM local_fodder_stock_adjustments ORDER BY date_c DESC")
    fun getAllStockAdjustmentsFlow(): Flow<List<FodderStockAdjustmentEntity>>

    @Query("SELECT * FROM local_fodder_stock_adjustments ORDER BY date_c DESC")
    suspend fun getAllStockAdjustments(): List<FodderStockAdjustmentEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStockAdjustment(adjustment: FodderStockAdjustmentEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllStockAdjustments(list: List<FodderStockAdjustmentEntity>)

    @Query("DELETE FROM local_fodder_stock_adjustments WHERE id = :id")
    suspend fun deleteStockAdjustmentById(id: String)

    // ==========================================
    // MASTER SETTINGS
    // ==========================================
    @Query("SELECT * FROM local_fodder_master_settings")
    suspend fun getAllMasterSettings(): List<FodderMasterSettingEntity>

    @Query("SELECT * FROM local_fodder_master_settings WHERE setting_key = :key LIMIT 1")
    suspend fun getMasterSettingByKey(key: String): FodderMasterSettingEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMasterSetting(setting: FodderMasterSettingEntity)
}
