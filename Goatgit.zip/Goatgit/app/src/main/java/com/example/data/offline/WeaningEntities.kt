package com.example.data.offline

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.UUID

@Entity(tableName = "weaning_records")
data class WeaningRecordEntity(
    @PrimaryKey
    val id: String = UUID.randomUUID().toString(),
    val farm_id: String = "default_farm",
    val goat_id: String,
    val mother_goat_id: String? = null,
    val kidding_id: String? = null,
    val birth_date: String,
    val weaning_due_date: String,
    val actual_weaning_date: String? = null,
    val age_at_weaning_days: Int? = null,
    val weight_at_weaning: Double? = null,
    val weight_unit: String = "kg",
    val weaning_method: String? = null, // NATURAL, GRADUAL, SEPARATION, OTHER
    val status: String = "PLANNED", // PLANNED, DUE, WEANED, DELAYED, NOT_APPLICABLE
    val reason_if_delayed: String? = null,
    val notes: String? = null,
    val setting_source: String = "FARM_DEFAULT", // FARM_DEFAULT, BREED_SPECIFIC, MANUAL_OVERRIDE, VET_OVERRIDE
    val post_weaning_feed_group: String = "WEANED KID / GROWING KID",
    val birth_weight: Double? = null,
    val prev_weight: Double? = null,
    val adg_g_per_day: Double? = null,
    val batch_id: String? = null,
    val created_at: String = "",
    val updated_at: Long = System.currentTimeMillis(),
    val is_synced: Boolean = true
)

@Entity(tableName = "weaning_batches")
data class WeaningBatchEntity(
    @PrimaryKey
    val id: String = UUID.randomUUID().toString(),
    val farm_id: String = "default_farm",
    val weaning_date: String,
    val number_of_kids: Int,
    val average_weight: Double? = null,
    val notes: String? = null,
    val created_at: String = "",
    val updated_at: Long = System.currentTimeMillis(),
    val is_synced: Boolean = true
)
