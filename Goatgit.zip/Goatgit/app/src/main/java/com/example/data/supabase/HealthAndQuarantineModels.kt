package com.example.data.supabase

import com.example.data.offline.DewormingScheduleEntity
import com.example.data.offline.QuarantineRecordEntity
import com.example.data.offline.VaccinationScheduleEntity
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

data class VaccinationSchedule(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val disease: String,
    val vaccine_name: String,
    val species: String = "Goat",
    val recommended_age: String,
    val recommended_interval: String,
    val dose_reference: String,
    val notes: String? = null,
    val source: String = "TANUVAS Reference Schedule",
    val active: Boolean = true,
    val created_at: String? = null
) {
    fun toEntity(): VaccinationScheduleEntity = VaccinationScheduleEntity(
        id = id,
        name = name,
        disease = disease,
        vaccine_name = vaccine_name,
        species = species,
        recommended_age = recommended_age,
        recommended_interval = recommended_interval,
        dose_reference = dose_reference,
        notes = notes,
        source = source,
        active = active,
        created_at = created_at
    )
}

fun VaccinationScheduleEntity.toDomain(): VaccinationSchedule = VaccinationSchedule(
    id = id,
    name = name,
    disease = disease,
    vaccine_name = vaccine_name,
    species = species,
    recommended_age = recommended_age,
    recommended_interval = recommended_interval,
    dose_reference = dose_reference,
    notes = notes,
    source = source,
    active = active,
    created_at = created_at
)

data class DewormingSchedule(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val species: String = "Goat",
    val trigger_type: String, // PERIODIC, FEC-BASED, VETERINARIAN ADVISED, CUSTOM
    val interval_days: Int = 90,
    val fec_reference: String? = null,
    val notes: String? = null,
    val source: String = "TANUVAS Reference",
    val active: Boolean = true,
    val created_at: String? = null
) {
    fun toEntity(): DewormingScheduleEntity = DewormingScheduleEntity(
        id = id,
        name = name,
        species = species,
        trigger_type = trigger_type,
        interval_days = interval_days,
        fec_reference = fec_reference,
        notes = notes,
        source = source,
        active = active,
        created_at = created_at
    )
}

fun DewormingScheduleEntity.toDomain(): DewormingSchedule = DewormingSchedule(
    id = id,
    name = name,
    species = species,
    trigger_type = trigger_type,
    interval_days = interval_days,
    fec_reference = fec_reference,
    notes = notes,
    source = source,
    active = active,
    created_at = created_at
)

data class QuarantineExtension(
    val extended_date: String,
    val new_end_date: String,
    val reason: String,
    val veterinarian: String?,
    val notes: String?
)

data class QuarantineRecord(
    val id: String = UUID.randomUUID().toString(),
    val farm_id: String = "default_farm",
    val goat_id: String,
    val goat_tag: String = "",
    val goat_name: String = "",
    val purchase_id: String? = null,
    val start_date: String,
    val planned_end_date: String,
    val actual_release_date: String? = null,
    val source_location: String? = null,
    val seller_name: String? = null,
    val seller_contact: String? = null,
    val reason: String = "Market Purchase Quarantine Protocol",
    val initial_health_status: String = "Under Observation",
    val temperature: Double? = null,
    val weight: Double? = null,
    val vaccination_status: String = "Pending Review",
    val deworming_status: String = "Pending Review",
    val fecal_test: String? = null,
    val clinical_exam: String? = null,
    val veterinarian: String? = null,
    val isolation_location: String = "Isolation Barn / Quarantine Pen",
    val status: String = "QUARANTINE", // QUARANTINE, CLEARED, EXTENDED, REJECTED, TRANSFERRED, DECEASED
    val release_reason: String? = null,
    val notes: String? = null,
    val checklist: Map<String, Boolean> = defaultChecklist(),
    val extensions: List<QuarantineExtension> = emptyList(),
    val created_at: String? = null
) {
    fun toEntity(): QuarantineRecordEntity {
        val checkJson = JSONObject().apply {
            checklist.forEach { (k, v) -> put(k, v) }
        }.toString()

        val extArray = JSONArray().apply {
            extensions.forEach { ext ->
                put(JSONObject().apply {
                    put("extended_date", ext.extended_date)
                    put("new_end_date", ext.new_end_date)
                    put("reason", ext.reason)
                    if (ext.veterinarian != null) put("veterinarian", ext.veterinarian)
                    if (ext.notes != null) put("notes", ext.notes)
                })
            }
        }.toString()

        return QuarantineRecordEntity(
            id = id,
            farm_id = farm_id,
            goat_id = goat_id,
            purchase_id = purchase_id,
            start_date = start_date,
            planned_end_date = planned_end_date,
            actual_release_date = actual_release_date,
            source_location = source_location,
            seller_name = seller_name,
            seller_contact = seller_contact,
            reason = reason,
            initial_health_status = initial_health_status,
            temperature = temperature,
            weight = weight,
            vaccination_status = vaccination_status,
            deworming_status = deworming_status,
            fecal_test = fecal_test,
            clinical_exam = clinical_exam,
            veterinarian = veterinarian,
            isolation_location = isolation_location,
            status = status,
            release_reason = release_reason,
            notes = notes,
            checklist_json = checkJson,
            extensions_json = extArray,
            created_at = created_at
        )
    }

    companion object {
        fun defaultChecklist(): Map<String, Boolean> = mapOf(
            "Identification verified" to false,
            "Weight recorded" to false,
            "Temperature/check completed" to false,
            "Clinical examination" to false,
            "External parasite check" to false,
            "Deworming status reviewed" to false,
            "Vaccination history reviewed" to false,
            "Fecal examination if required" to false,
            "Other veterinary tests" to false,
            "Veterinarian review" to false,
            "Final clearance" to false
        )
    }
}

fun QuarantineRecordEntity.toDomain(goatTag: String = "", goatName: String = ""): QuarantineRecord {
    val checkMap = mutableMapOf<String, Boolean>()
    QuarantineRecord.defaultChecklist().forEach { (k, v) -> checkMap[k] = v }
    if (!checklist_json.isNullOrBlank()) {
        try {
            val json = JSONObject(checklist_json)
            val keys = json.keys()
            while (keys.hasNext()) {
                val k = keys.next()
                checkMap[k] = json.optBoolean(k, false)
            }
        } catch (_: Exception) {}
    }

    val extList = mutableListOf<QuarantineExtension>()
    if (!extensions_json.isNullOrBlank()) {
        try {
            val arr = JSONArray(extensions_json)
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                extList.add(
                    QuarantineExtension(
                        extended_date = obj.optString("extended_date", ""),
                        new_end_date = obj.optString("new_end_date", ""),
                        reason = obj.optString("reason", ""),
                        veterinarian = if (obj.has("veterinarian")) obj.getString("veterinarian") else null,
                        notes = if (obj.has("notes")) obj.getString("notes") else null
                    )
                )
            }
        } catch (_: Exception) {}
    }

    return QuarantineRecord(
        id = id,
        farm_id = farm_id,
        goat_id = goat_id,
        goat_tag = goatTag,
        goat_name = goatName,
        purchase_id = purchase_id,
        start_date = start_date,
        planned_end_date = planned_end_date,
        actual_release_date = actual_release_date,
        source_location = source_location,
        seller_name = seller_name,
        seller_contact = seller_contact,
        reason = reason,
        initial_health_status = initial_health_status,
        temperature = temperature,
        weight = weight,
        vaccination_status = vaccination_status,
        deworming_status = deworming_status,
        fecal_test = fecal_test,
        clinical_exam = clinical_exam,
        veterinarian = veterinarian,
        isolation_location = isolation_location,
        status = status,
        release_reason = release_reason,
        notes = notes,
        checklist = checkMap,
        extensions = extList,
        created_at = created_at
    )
}

data class HealthHistoryItem(
    val id: String,
    val goat_id: String,
    val goat_tag: String,
    val date: String,
    val type: String, // Vaccination, Deworming, Treatment, Veterinary Visit, Reproductive Complication, Mortality
    val title: String,
    val description: String,
    val medicine_or_product: String? = null,
    val dose: String? = null,
    val veterinarian: String? = null,
    val cost: Double? = null,
    val outcome: String? = null,
    val attachment_note: String? = null,
    val is_seller_reported: Boolean = false
)

data class HealthAlert(
    val id: String = UUID.randomUUID().toString(),
    val type: String, // VACCINATION_DUE, VACCINATION_OVERDUE, DEWORMING_DUE, DEWORMING_OVERDUE, TREATMENT_FOLLOW_UP, QUARANTINE_ENDING, QUARANTINE_OVERDUE, VET_FOLLOW_UP
    val title: String,
    val message: String,
    val goat_id: String,
    val goat_tag: String,
    val due_date: String,
    val days_diff: Int = 0,
    val severity: String = "WARNING" // INFO, WARNING, URGENT
)

data class HealthDashboardSummary(
    val totalGoats: Int = 0,
    val activeQuarantineCount: Int = 0,
    val vaccinationDueCount: Int = 0,
    val vaccinationOverdueCount: Int = 0,
    val dewormingDueCount: Int = 0,
    val dewormingOverdueCount: Int = 0,
    val activeTreatmentsCount: Int = 0,
    val totalHealthAlertsCount: Int = 0
)
