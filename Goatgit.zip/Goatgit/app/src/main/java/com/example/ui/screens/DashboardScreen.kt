package com.example.ui.screens

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import java.text.SimpleDateFormat
import java.util.Date
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.*
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.supabase.*
import com.example.i18n.t
import com.example.ui.components.FarmBottomNavigation
import com.example.ui.components.QuickStatusArea
import com.example.ui.components.NewGoatEntryDialog
import com.example.ui.components.NewGoatEntryForm
import com.example.ui.components.ExportPopulationAndHealthDialog
import com.example.ui.components.breeding.BreedingAndKidsHubCard
import com.example.ui.theme.*
import com.example.data.farm.*
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.Locale

// ==============================================================================
// DASHBOARD MODULE DATA MODELS
// ==============================================================================
data class DashboardModuleItem(
    val id: String,
    val defaultLabel: String,
    val customLabel: String? = null,
    val iconName: String,
    val category: String, // Livestock, Breeding, Health, Finance, Farm, Reports, Administration
    val isVisible: Boolean = true,
    val sortOrder: Int,
    val route: String,
    val iconBgColor: Color,
    val iconColor: Color
) {
    val displayLabel: String
        get() = if (!customLabel.isNullOrBlank()) customLabel else defaultLabel
}

fun getDefaultDashboardModules(): List<DashboardModuleItem> = listOf(
    // ROW 1
    DashboardModuleItem(
        id = "goats",
        defaultLabel = "GOATS",
        iconName = "Pets",
        category = "Livestock",
        sortOrder = 1,
        route = "goats",
        iconBgColor = Color(0xFFE8F5E9),
        iconColor = Color(0xFF2E7D32)
    ),
    DashboardModuleItem(
        id = "breeds",
        defaultLabel = "BREEDS",
        iconName = "Category",
        category = "Livestock",
        sortOrder = 2,
        route = "goats",
        iconBgColor = Color(0xFFE8F5E9),
        iconColor = Color(0xFF388E3C)
    ),
    DashboardModuleItem(
        id = "weights",
        defaultLabel = "WEIGHTS",
        iconName = "Scale",
        category = "Livestock",
        sortOrder = 3,
        route = "record_weight",
        iconBgColor = Color(0xFFE8F5E9),
        iconColor = Color(0xFF43A047)
    ),

    // ROW 2
    DashboardModuleItem(
        id = "breeding_hub",
        defaultLabel = "BREEDING & KIDS",
        iconName = "Favorite",
        category = "Breeding",
        sortOrder = 4,
        route = "breeding_hub",
        iconBgColor = Color(0xFFFCE4EC),
        iconColor = Color(0xFFD81B60)
    ),
    DashboardModuleItem(
        id = "health",
        defaultLabel = "HEALTH",
        iconName = "MedicalServices",
        category = "Health",
        sortOrder = 5,
        route = "health",
        iconBgColor = Color(0xFFE0F2F1),
        iconColor = Color(0xFF00796B)
    ),
    DashboardModuleItem(
        id = "biosecurity_hub",
        defaultLabel = "BIOSECURITY & RISK",
        iconName = "Security",
        category = "Health",
        sortOrder = 6,
        route = "biosecurity_hub",
        iconBgColor = Color(0xFFE0F2FE),
        iconColor = Color(0xFF0284C7)
    ),
    DashboardModuleItem(
        id = "feed",
        defaultLabel = "FEED & STOCK",
        iconName = "Inventory2",
        category = "Farm",
        sortOrder = 7,
        route = "feed",
        iconBgColor = Color(0xFFF1F8E9),
        iconColor = Color(0xFF558B2F)
    ),
    DashboardModuleItem(
        id = "fodder",
        defaultLabel = "GREEN FODDER",
        iconName = "Grass",
        category = "Farm",
        sortOrder = 8,
        route = "green_fodder",
        iconBgColor = Color(0xFFE8F5E9),
        iconColor = Color(0xFF2E7D32)
    ),

    // ROW 3 (cont.)
    DashboardModuleItem(
        id = "sales",
        defaultLabel = "SALES",
        iconName = "PointOfSale",
        category = "Finance",
        sortOrder = 9,
        route = "sales",
        iconBgColor = Color(0xFFE8F5E9),
        iconColor = Color(0xFF1B5E20)
    ),

    // ROW 4
    DashboardModuleItem(
        id = "expenses",
        defaultLabel = "EXPENSES",
        iconName = "ReceiptLong",
        category = "Finance",
        sortOrder = 10,
        route = "recurring_expenses",
        iconBgColor = Color(0xFFFFF3E0),
        iconColor = Color(0xFFE65100)
    ),
    DashboardModuleItem(
        id = "finance",
        defaultLabel = "FINANCE",
        iconName = "AccountBalance",
        category = "Finance",
        sortOrder = 11,
        route = "finance",
        iconBgColor = Color(0xFFE1F5FE),
        iconColor = Color(0xFF0288D1)
    ),
    DashboardModuleItem(
        id = "assets",
        defaultLabel = "ASSETS",
        iconName = "Domain",
        category = "Farm",
        sortOrder = 12,
        route = "farm_assets",
        iconBgColor = Color(0xFFF3E5F5),
        iconColor = Color(0xFF7B1FA2)
    ),

    // ROW 5
    DashboardModuleItem(
        id = "employees",
        defaultLabel = "EMPLOYEES",
        iconName = "Badge",
        category = "Administration",
        sortOrder = 13,
        route = "employees",
        iconBgColor = Color(0xFFEFEBE9),
        iconColor = Color(0xFF5D4037)
    ),
    DashboardModuleItem(
        id = "reports",
        defaultLabel = "REPORTS",
        iconName = "Assessment",
        category = "Reports",
        sortOrder = 14,
        route = "financial_reports",
        iconBgColor = Color(0xFFEDE7F6),
        iconColor = Color(0xFF512DA8)
    ),
    DashboardModuleItem(
        id = "insurance_due",
        defaultLabel = "INSURANCE DUE",
        iconName = "HourglassTop",
        category = "Finance",
        sortOrder = 15,
        route = "livestock_insurance",
        iconBgColor = Color(0xFFFFF3E0),
        iconColor = Color(0xFFF57C00)
    ),

    // ROW 6
    DashboardModuleItem(
        id = "payments_due",
        defaultLabel = "PAYMENTS DUE",
        iconName = "PendingActions",
        category = "Finance",
        sortOrder = 16,
        route = "payments_due",
        iconBgColor = Color(0xFFFFEDD5),
        iconColor = Color(0xFFC2410C)
    ),
    DashboardModuleItem(
        id = "alerts",
        defaultLabel = "ALERTS",
        iconName = "NotificationsActive",
        category = "Administration",
        sortOrder = 17,
        route = "tasks_and_due",
        iconBgColor = Color(0xFFFFEBEE),
        iconColor = Color(0xFFE53935)
    ),
    DashboardModuleItem(
        id = "backup",
        defaultLabel = "BACKUP",
        iconName = "CloudSync",
        category = "Administration",
        sortOrder = 18,
        route = "backup",
        iconBgColor = Color(0xFFE0F7FA),
        iconColor = Color(0xFF0097A7)
    ),

    // ROW 7
    DashboardModuleItem(
        id = "customize",
        defaultLabel = "CUSTOMIZE",
        iconName = "Tune",
        category = "Administration",
        sortOrder = 19,
        route = "customize",
        iconBgColor = Color(0xFFE0F2F1),
        iconColor = Color(0xFF00796B)
    ),
    DashboardModuleItem(
        id = "settings",
        defaultLabel = "SETTINGS",
        iconName = "Settings",
        category = "Administration",
        sortOrder = 20,
        route = "settings",
        iconBgColor = Color(0xFFECEFF1),
        iconColor = Color(0xFF455A64)
    )
)

fun mapIconNameToVector(name: String): ImageVector = when (name) {
    "Pets" -> Icons.Default.Pets
    "Category" -> Icons.Default.Category
    "Scale" -> Icons.Default.Scale
    "Favorite" -> Icons.Default.Favorite
    "ChildCare" -> Icons.Default.ChildCare
    "MedicalServices" -> Icons.Default.MedicalServices
    "WarningAmber" -> Icons.Default.WarningAmber
    "Security" -> Icons.Default.Security
    "Inventory2" -> Icons.Default.Inventory2
    "PointOfSale" -> Icons.Default.PointOfSale
    "ReceiptLong" -> Icons.Default.ReceiptLong
    "AccountBalance" -> Icons.Default.AccountBalance
    "Domain" -> Icons.Default.Domain
    "Badge" -> Icons.Default.Badge
    "Assessment" -> Icons.Default.Assessment
    "HourglassTop" -> Icons.Default.HourglassTop
    "PendingActions" -> Icons.Default.PendingActions
    "NotificationsActive" -> Icons.Default.NotificationsActive
    "CloudSync" -> Icons.Default.CloudSync
    "Tune" -> Icons.Default.Tune
    "Settings" -> Icons.Default.Settings
    "Grass" -> Icons.Default.Grass
    "AttachMoney" -> Icons.Default.AttachMoney
    "Analytics" -> Icons.Default.Analytics
    "Build" -> Icons.Default.Build
    "People" -> Icons.Default.People
    "Medication" -> Icons.Default.Medication
    else -> Icons.Default.Dashboard
}

// ==============================================================================
// MAIN DASHBOARD SCREEN
// ==============================================================================
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(
    repository: GoatRepository,
    onNavigateToGoats: () -> Unit,
    onNavigateToAddGoat: () -> Unit,
    onNavigateToRecordWeight: () -> Unit,
    onNavigateToVaccination: () -> Unit,
    onNavigateToDeworming: () -> Unit,
    onNavigateToTreatment: () -> Unit,
    onNavigateToBreeding: () -> Unit,
    onNavigateToBreedingHub: (tab: Int) -> Unit = { tab -> onNavigateToBreeding() },
    onNavigateToBreedingDashboard: () -> Unit = onNavigateToBreeding,
    onNavigateToFeed: () -> Unit,
    onNavigateToFeedInventory: () -> Unit = onNavigateToFeed,
    onNavigateToMedicine: () -> Unit,
    onNavigateToTasks: () -> Unit,
    onNavigateToTodaysDue: () -> Unit,
    onNavigateToSales: () -> Unit,
    onNavigateToFinance: () -> Unit = {},
    onNavigateToAssets: () -> Unit = {},
    onNavigateToAiEntry: () -> Unit,
    onNavigateToSettings: () -> Unit = {},
    onNavigateToFodder: (tab: Int) -> Unit = {},
    onNavigateToWeaning: () -> Unit = {},
    onNavigateToHealth: () -> Unit = {},
    onNavigateToDailyObservation: () -> Unit = {},
    onNavigateToTrends: () -> Unit = {},
    onNavigateToWeightTrends: () -> Unit = {},
    onNavigateToQuarantine: () -> Unit = {},
    onNavigateToInsurance: () -> Unit = {},
    onNavigateToMortality: () -> Unit = {},
    onNavigateToBiosecurityHub: (tab: Int) -> Unit = { tab ->
        when (tab) {
            0 -> onNavigateToQuarantine()
            1 -> onNavigateToMortality()
            2 -> onNavigateToInsurance()
            else -> onNavigateToQuarantine()
        }
    },
    onNavigateToRecurring: () -> Unit = {},
    onNavigateToLoans: () -> Unit = {},
    onNavigateToSuppliers: () -> Unit = {},
    onNavigateToPaymentsDue: () -> Unit = {},
    onNavigateToGst: () -> Unit = {},
    onNavigateToEWay: () -> Unit = {},
    onNavigateToReports: () -> Unit = {},
    onNavigateToCashBank: () -> Unit = {},
    onNavigateToElectricity: () -> Unit = {},
    onNavigateToPopulationDashboard: () -> Unit = {},
    onSignOut: () -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    // Dashboard Live State
    var metrics by remember { mutableStateOf(LiveDashboardMetrics()) }
    var modules by remember { mutableStateOf(getDefaultDashboardModules()) }
    var dashboardLayout by remember { mutableStateOf("3_COLUMNS") } // 3_COLUMNS, 2_COLUMNS, LIST
    val farmProfile = LocalFarmProfile.current
    val farmProfileManager = LocalFarmProfileManager.current ?: repository.farmProfileManager
    var currentFarmName by remember { mutableStateOf(farmProfile.farmName) }
    var isLoading by remember { mutableStateOf(true) }

    // Dialog & Sheet States
    var showDrawer by remember { mutableStateOf(false) }
    var showFarmSwitcher by remember { mutableStateOf(false) }
    var showFarmProfileDialog by remember { mutableStateOf(false) }
    var showGlobalSearch by remember { mutableStateOf(false) }
    var showQuickAdd by remember { mutableStateOf(false) }
    var showCustomizeDialog by remember { mutableStateOf(false) }
    var showEmployeesDialog by remember { mutableStateOf(false) }
    var showLocationsTagsDialog by remember { mutableStateOf(false) }
    var showBackupDialog by remember { mutableStateOf(false) }
    var showSignOutDialog by remember { mutableStateOf(false) }
    var showNewGoatEntryDialog by remember { mutableStateOf(false) }
    var showSyncCenterDialog by remember { mutableStateOf(false) }
    var showExportCsvDialog by remember { mutableStateOf(false) }

    if (showSyncCenterDialog) {
        com.example.ui.components.SyncCenterDialog(
            syncManager = repository.syncManager,
            isOnline = true,
            backupManager = repository.backupManager,
            onNavigateToSettings = onNavigateToSettings,
            onDismiss = { showSyncCenterDialog = false }
        )
    }

    if (showExportCsvDialog) {
        ExportPopulationAndHealthDialog(
            repository = repository,
            onDismiss = { showExportCsvDialog = false }
        )
    }

    fun loadDashboardData() {
        isLoading = true
        coroutineScope.launch {
            // 1. Load Live Database Metrics
            val metricsRes = repository.getLiveDashboardMetrics()
            if (metricsRes.isSuccess) {
                metrics = metricsRes.getOrThrow()
            }

            // 2. Load Farm Settings & Customization
            val farmName = repository.getFarmSetting("current_farm_name") ?: "Sunrise Goat Farm"
            currentFarmName = farmName

            val customJson = repository.getFarmSetting("dashboard_customization")
            val removedLegacyTileIds = setOf("breeding", "delivery", "deworming", "weaning")
            if (!customJson.isNullOrBlank()) {
                try {
                    val root = JSONObject(customJson)
                    dashboardLayout = root.optString("layout", "3_COLUMNS")
                    val itemsArr = root.optJSONArray("modules")
                    if (itemsArr != null && itemsArr.length() > 0) {
                        val defaultList = getDefaultDashboardModules().associateBy { it.id }.toMutableMap()
                        val customizedList = mutableListOf<DashboardModuleItem>()
                        for (i in 0 until itemsArr.length()) {
                            val obj = itemsArr.getJSONObject(i)
                            val id = obj.getString("id")
                            if (removedLegacyTileIds.contains(id)) continue
                            val base = defaultList[id] ?: continue
                            customizedList.add(
                                base.copy(
                                    customLabel = obj.optString("customLabel").takeIf { it.isNotBlank() },
                                    iconName = obj.optString("iconName", base.iconName),
                                    isVisible = obj.optBoolean("isVisible", true),
                                    sortOrder = obj.optInt("sortOrder", base.sortOrder)
                                )
                            )
                            defaultList.remove(id)
                        }
                        // Add any newly introduced modules not in saved json
                        customizedList.addAll(defaultList.values)
                        modules = customizedList.sortedBy { it.sortOrder }
                    }
                } catch (e: Exception) {
                    modules = getDefaultDashboardModules()
                }
            } else {
                modules = getDefaultDashboardModules()
            }
            isLoading = false
        }
    }

    LaunchedEffect(Unit) {
        loadDashboardData()
    }

    // Module click router
    fun onModuleClicked(item: DashboardModuleItem) {
        when (item.id) {
            "goats" -> onNavigateToGoats()
            "breeds" -> onNavigateToPopulationDashboard()
            "weights" -> onNavigateToRecordWeight()
            "breeding_hub" -> onNavigateToBreedingHub(0)
            "breeding" -> onNavigateToBreedingHub(0)
            "delivery" -> onNavigateToBreedingHub(2)
            "breeding_dashboard" -> onNavigateToBreedingDashboard()
            "health" -> onNavigateToHealth()
            "deworming" -> onNavigateToDeworming()
            "biosecurity_hub" -> onNavigateToBiosecurityHub(0)
            "quarantine" -> onNavigateToBiosecurityHub(0)
            "mortality" -> onNavigateToBiosecurityHub(1)
            "insurance" -> onNavigateToBiosecurityHub(2)
            "insurance_due" -> onNavigateToBiosecurityHub(2)
            "feed" -> onNavigateToFeed()
            "fodder" -> onNavigateToFodder(0)
            "weaning" -> onNavigateToBreedingHub(3)
            "sales" -> onNavigateToSales()
            "expenses" -> onNavigateToRecurring()
            "finance" -> onNavigateToFinance()
            "assets" -> onNavigateToAssets()
            "employees" -> showEmployeesDialog = true
            "reports" -> onNavigateToReports()
            "payments_due" -> onNavigateToPaymentsDue()
            "alerts" -> onNavigateToTodaysDue()
            "backup" -> showBackupDialog = true
            "customize" -> showCustomizeDialog = true
            "settings" -> onNavigateToSettings()
            else -> onNavigateToGoats()
        }
    }

    val visibleModules = remember(modules) {
        modules.filter { it.isVisible }.sortedBy { it.sortOrder }
    }

    // Main Scaffold with Mobile-first Top Bar and Floating Action Button
    Scaffold(
        topBar = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color.White)
            ) {
                // Top Header (☰ Menu | Farm Name | Search, Bell, Settings)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .statusBarsPadding()
                        .padding(horizontal = 8.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = { showDrawer = true },
                        modifier = Modifier.testTag("dashboard_menu_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Menu,
                            contentDescription = "Menu",
                            tint = Color(0xFF1B5E20),
                            modifier = Modifier.size(26.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(4.dp))

                    // Dynamic Farm Logo
                    FarmLogoImage(
                        logoUri = farmProfile.logoUri,
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .border(1.5.dp, Color(0xFF86EFAC), CircleShape)
                            .clickable { showFarmProfileDialog = true }
                            .testTag("dashboard_farm_logo"),
                        fallbackIconSize = 22.dp,
                        contentDescription = "Farm Logo"
                    )

                    Spacer(modifier = Modifier.width(8.dp))

                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .clickable { showFarmProfileDialog = true },
                        verticalArrangement = Arrangement.Center
                    ) {
                        Text(
                            text = farmProfile.farmName,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF1B5E20),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Row(
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Farm Setup & Profile",
                                style = MaterialTheme.typography.labelSmall,
                                color = Color.Gray
                            )
                            Icon(
                                imageVector = Icons.Default.Edit,
                                contentDescription = "Edit Farm Profile",
                                tint = Color.Gray,
                                modifier = Modifier.size(12.dp).padding(start = 2.dp)
                            )
                        }
                    }

                    // Right Actions
                    val realtimeStatus by repository.syncManager.realtimeStatus.collectAsState()

                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = when (realtimeStatus) {
                            com.example.data.supabase.RealtimeStatus.SUBSCRIBED -> Color(0xFFE8F5E9)
                            com.example.data.supabase.RealtimeStatus.CONNECTED,
                            com.example.data.supabase.RealtimeStatus.CONNECTING -> Color(0xFFFFF8E1)
                            com.example.data.supabase.RealtimeStatus.ERROR -> Color(0xFFFFEBEE)
                            com.example.data.supabase.RealtimeStatus.DISCONNECTED -> Color(0xFFF5F5F5)
                        },
                        modifier = Modifier
                            .clickable { showSyncCenterDialog = true }
                            .padding(end = 4.dp)
                            .testTag("dashboard_realtime_chip")
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 7.dp, vertical = 4.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(7.dp)
                                    .clip(CircleShape)
                                    .background(
                                        when (realtimeStatus) {
                                            com.example.data.supabase.RealtimeStatus.SUBSCRIBED -> Color(0xFF2E7D32)
                                            com.example.data.supabase.RealtimeStatus.CONNECTED -> Color(0xFF4CAF50)
                                            com.example.data.supabase.RealtimeStatus.CONNECTING -> Color(0xFFFFA000)
                                            com.example.data.supabase.RealtimeStatus.ERROR -> Color(0xFFD32F2F)
                                            com.example.data.supabase.RealtimeStatus.DISCONNECTED -> Color.Gray
                                        }
                                    )
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = when (realtimeStatus) {
                                    com.example.data.supabase.RealtimeStatus.SUBSCRIBED -> "LIVE"
                                    com.example.data.supabase.RealtimeStatus.CONNECTING -> "SYNC..."
                                    com.example.data.supabase.RealtimeStatus.CONNECTED -> "READY"
                                    com.example.data.supabase.RealtimeStatus.ERROR -> "OFFLINE"
                                    com.example.data.supabase.RealtimeStatus.DISCONNECTED -> "SYNC"
                                },
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                fontSize = 10.sp,
                                color = when (realtimeStatus) {
                                    com.example.data.supabase.RealtimeStatus.SUBSCRIBED -> Color(0xFF1B5E20)
                                    com.example.data.supabase.RealtimeStatus.CONNECTING -> Color(0xFFE65100)
                                    com.example.data.supabase.RealtimeStatus.CONNECTED -> Color(0xFF2E7D32)
                                    com.example.data.supabase.RealtimeStatus.ERROR -> Color(0xFFC62828)
                                    com.example.data.supabase.RealtimeStatus.DISCONNECTED -> Color.DarkGray
                                }
                            )
                        }
                    }

                    IconButton(
                        onClick = { showExportCsvDialog = true },
                        modifier = Modifier.testTag("dashboard_export_csv_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.FileDownload,
                            contentDescription = "Export Population & Health CSV",
                            tint = Color(0xFF2E7D32),
                            modifier = Modifier.size(24.dp)
                        )
                    }

                    IconButton(
                        onClick = { showGlobalSearch = true },
                        modifier = Modifier.testTag("dashboard_search_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = "Global Search",
                            tint = Color(0xFF2E7D32),
                            modifier = Modifier.size(24.dp)
                        )
                    }

                    IconButton(
                        onClick = onNavigateToTodaysDue,
                        modifier = Modifier.testTag("dashboard_notifications_btn")
                    ) {
                        BadgedBox(
                            badge = {
                                if (metrics.alertsBadge > 0) {
                                    Badge(
                                        containerColor = Color(0xFFE53935),
                                        contentColor = Color.White
                                    ) {
                                        Text("${metrics.alertsBadge}")
                                    }
                                }
                            }
                        ) {
                            Icon(
                                imageVector = Icons.Default.Notifications,
                                contentDescription = "Alerts",
                                tint = Color(0xFF2E7D32),
                                modifier = Modifier.size(24.dp)
                            )
                        }
                    }

                    IconButton(
                        onClick = onNavigateToSettings,
                        modifier = Modifier.testTag("dashboard_settings_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = "Settings",
                            tint = Color(0xFF455A64),
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }

                HorizontalDivider(color = Color(0xFFEEEEEE), thickness = 1.dp)
            }
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showQuickAdd = true },
                containerColor = Color(0xFF2E7D32),
                contentColor = Color.White,
                shape = CircleShape,
                modifier = Modifier
                    .padding(bottom = 60.dp)
                    .testTag("dashboard_quick_add_fab")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(imageVector = Icons.Default.Add, contentDescription = "Add")
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(text = "ADD", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                }
            }
        },
        bottomBar = {
            FarmBottomNavigation(
                currentRoute = "dashboard",
                onNavigateToDashboard = {},
                onNavigateToGoats = onNavigateToGoats,
                onNavigateToBreeding = { onNavigateToBreedingHub(0) },
                onNavigateToSales = onNavigateToSales,
                onNavigateToTasks = onNavigateToTasks,
                onNavigateToAiEntry = onNavigateToAiEntry
            )
        }
    ) { paddingValues ->
        BoxWithConstraints(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFFF9FAF9))
                .padding(paddingValues)
        ) {
            val screenWidth = maxWidth

            // Responsive Layout: Phone (<600dp), Tablet (600-900dp), Desktop (>=900dp)
            if (screenWidth >= 900.dp) {
                // Desktop 3-pane Layout: Left quick nav, center grid, right alerts
                Row(modifier = Modifier.fillMaxSize().padding(16.dp)) {
                    // Left Navigation Rail / Drawer Pane
                    Card(
                        modifier = Modifier.width(240.dp).fillMaxHeight(),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        shape = RoundedCornerShape(16.dp),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                    ) {
                        MoreDrawerContent(
                            onNavigateToGoats = onNavigateToGoats,
                            onNavigateToSales = onNavigateToSales,
                            onNavigateToFinance = onNavigateToFinance,
                            onNavigateToAssets = onNavigateToAssets,
                            onNavigateToInsurance = onNavigateToInsurance,
                            onNavigateToBiosecurity = { tab -> onNavigateToBiosecurityHub(tab) },
                            onNavigateToFeedInventory = onNavigateToFeedInventory,
                            onNavigateToSuppliers = onNavigateToSuppliers,
                            onNavigateToGst = onNavigateToGst,
                            onNavigateToEWay = onNavigateToEWay,
                            onNavigateToLoans = onNavigateToLoans,
                            onNavigateToReports = onNavigateToReports,
                            onNavigateToSettings = onNavigateToSettings,
                            onOpenBackup = { showBackupDialog = true },
                            onOpenCustomize = { showCustomizeDialog = true },
                            onOpenLocationsTags = { showLocationsTagsDialog = true },
                            onOpenEmployees = { showEmployeesDialog = true },
                            onExportCsv = { showExportCsvDialog = true },
                            onClose = {}
                        )
                    }

                    Spacer(modifier = Modifier.width(16.dp))

                    // Center Primary 3-column Grid
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight()
                            .verticalScroll(rememberScrollState())
                    ) {
                        QuickStatusArea(
                            metrics = metrics,
                            onTotalGoatsClick = onNavigateToGoats,
                            onPregnantGoatsClick = { onNavigateToBreedingHub(1) },
                            onHealthAlertsClick = onNavigateToHealth,
                            onDueDeliveryClick = { onNavigateToBreedingHub(2) },
                            onKidsClick = onNavigateToGoats,
                            onMortalityClick = { onNavigateToBiosecurityHub(1) },
                            onWeaningClick = { onNavigateToBreedingHub(3) }
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        if (metrics.insuranceBadge > 0) {
                            InsuranceExpirationAlertBanner(
                                expiringCount = metrics.insuranceBadge,
                                onClick = { onNavigateToBiosecurityHub(2) }
                            )
                            Spacer(modifier = Modifier.height(14.dp))
                        }
                        ModuleGrid(
                            modules = visibleModules,
                            metrics = metrics,
                            columnsCount = 3,
                            onModuleClick = { onModuleClicked(it) }
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        com.example.ui.components.DashboardPopulationCard(
                            repository = repository,
                            onNavigateToPopulationDashboard = onNavigateToPopulationDashboard,
                            onExportCsv = { showExportCsvDialog = true }
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        BreedingAndKidsHubCard(
                            repository = repository,
                            onNavigateToBreedingHub = { onNavigateToBreedingHub(0) },
                            onLogKidding = { doeId -> onNavigateToBreedingHub(2) },
                            onAddPregnancy = { onNavigateToBreedingHub(1) }
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        DashboardBiosecurityCard(
                            repository = repository,
                            onNavigateToQuarantine = { onNavigateToBiosecurityHub(0) },
                            onNavigateToMortality = { onNavigateToBiosecurityHub(1) },
                            onNavigateToInsurance = { onNavigateToBiosecurityHub(2) },
                            onNavigateToHub = onNavigateToBiosecurityHub
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        DashboardGreenFodderCard(
                            repository = repository,
                            onNavigateToFodder = onNavigateToFodder
                        )
                        Spacer(modifier = Modifier.height(32.dp))
                    }

                    Spacer(modifier = Modifier.width(16.dp))

                    // Right Panel: Due & Summary
                    Card(
                        modifier = Modifier.width(280.dp).fillMaxHeight(),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        shape = RoundedCornerShape(16.dp),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                    ) {
                        DesktopSideSummaryPanel(
                            metrics = metrics,
                            onViewAlerts = onNavigateToHealth,
                            onViewPayments = onNavigateToPaymentsDue,
                            onViewWeaning = { onNavigateToBreedingHub(3) }
                        )
                    }
                }
            } else {
                // Mobile and Tablet View: Status strip then 3-column grid
                val gridColumns = if (screenWidth >= 600.dp) 4 else if (dashboardLayout == "2_COLUMNS") 2 else 3

                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    item {
                        Spacer(modifier = Modifier.height(10.dp))
                        // Quick Status Area (Compact Status Strip)
                        QuickStatusArea(
                            metrics = metrics,
                            onTotalGoatsClick = onNavigateToGoats,
                            onPregnantGoatsClick = { onNavigateToBreedingHub(1) },
                            onHealthAlertsClick = onNavigateToHealth,
                            onDueDeliveryClick = { onNavigateToBreedingHub(2) },
                            onKidsClick = onNavigateToGoats,
                            onMortalityClick = { onNavigateToBiosecurityHub(1) },
                            onWeaningClick = { onNavigateToBreedingHub(3) }
                        )
                    }

                    if (metrics.insuranceBadge > 0) {
                        item {
                            InsuranceExpirationAlertBanner(
                                expiringCount = metrics.insuranceBadge,
                                onClick = { onNavigateToBiosecurityHub(2) }
                            )
                        }
                    }

                    item {
                        // Main 3-Column Module Grid
                        ModuleGrid(
                            modules = visibleModules,
                            metrics = metrics,
                            columnsCount = gridColumns,
                            isListView = dashboardLayout == "LIST",
                            onModuleClick = { onModuleClicked(it) }
                        )
                    }

                    item {
                        // Herd Demographics & Breed Population Visual Card
                        com.example.ui.components.DashboardPopulationCard(
                            repository = repository,
                            onNavigateToPopulationDashboard = onNavigateToPopulationDashboard,
                            onExportCsv = { showExportCsvDialog = true }
                        )
                    }

                    item {
                        // Unified Breeding & Kids Hub Card: Active Pregnancies & Recent Births
                        BreedingAndKidsHubCard(
                            repository = repository,
                            onNavigateToBreedingHub = { onNavigateToBreedingHub(0) },
                            onLogKidding = { doeId -> onNavigateToBreedingHub(2) },
                            onAddPregnancy = { onNavigateToBreedingHub(1) }
                        )
                    }

                    item {
                        // Consolidated Biosecurity, Mortality & Insurance Card
                        DashboardBiosecurityCard(
                            repository = repository,
                            onNavigateToQuarantine = { onNavigateToBiosecurityHub(0) },
                            onNavigateToMortality = { onNavigateToBiosecurityHub(1) },
                            onNavigateToInsurance = { onNavigateToBiosecurityHub(2) },
                            onNavigateToHub = onNavigateToBiosecurityHub
                        )
                    }

                    item {
                        // Green Fodder Dashboard Card (Requirement 19)
                        DashboardGreenFodderCard(
                            repository = repository,
                            onNavigateToFodder = onNavigateToFodder
                        )
                    }

                    item {
                        Spacer(modifier = Modifier.height(80.dp))
                    }
                }
            }
        }
    }

    // ==============================================================================
    // DIALOGS & OVERLAYS
    // ==============================================================================

    // 1. Navigation Drawer (☰ MORE Optional Modules)
    if (showDrawer) {
        ModalBottomSheet(
            onDismissRequest = { showDrawer = false },
            containerColor = Color.White,
            shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp)
        ) {
            MoreDrawerContent(
                onNavigateToGoats = { showDrawer = false; onNavigateToGoats() },
                onNavigateToBreeding = { showDrawer = false; onNavigateToBreedingHub(0) },
                onNavigateToFodder = { showDrawer = false; onNavigateToFodder(0) },
                onNavigateToWeaning = { showDrawer = false; onNavigateToBreedingHub(3) },
                onNavigateToFeedInventory = { showDrawer = false; onNavigateToFeedInventory() },
                onNavigateToSales = { showDrawer = false; onNavigateToSales() },
                onNavigateToFinance = { showDrawer = false; onNavigateToFinance() },
                onNavigateToAssets = { showDrawer = false; onNavigateToAssets() },
                onNavigateToHealth = { showDrawer = false; onNavigateToHealth() },
                onNavigateToDailyObservation = { showDrawer = false; onNavigateToDailyObservation() },
                onNavigateToTrends = { showDrawer = false; onNavigateToTrends() },
                onNavigateToWeightTrends = { showDrawer = false; onNavigateToWeightTrends() },
                onNavigateToQuarantine = { showDrawer = false; onNavigateToBiosecurityHub(0) },
                onNavigateToInsurance = { showDrawer = false; onNavigateToBiosecurityHub(2) },
                onNavigateToMortality = { showDrawer = false; onNavigateToBiosecurityHub(1) },
                onNavigateToBiosecurity = { tab -> showDrawer = false; onNavigateToBiosecurityHub(tab) },
                onNavigateToSuppliers = { showDrawer = false; onNavigateToSuppliers() },
                onNavigateToGst = { showDrawer = false; onNavigateToGst() },
                onNavigateToEWay = { showDrawer = false; onNavigateToEWay() },
                onNavigateToLoans = { showDrawer = false; onNavigateToLoans() },
                onNavigateToReports = { showDrawer = false; onNavigateToReports() },
                onNavigateToSettings = { showDrawer = false; onNavigateToSettings() },
                onOpenBackup = { showDrawer = false; showBackupDialog = true },
                onOpenCustomize = { showDrawer = false; showCustomizeDialog = true },
                onOpenLocationsTags = { showDrawer = false; showLocationsTagsDialog = true },
                onOpenEmployees = { showDrawer = false; showEmployeesDialog = true },
                onExportCsv = { showDrawer = false; showExportCsvDialog = true },
                onClose = { showDrawer = false }
            )
        }
    }

    // 2. Farm Setup / Profile Dialog
    if (showFarmProfileDialog) {
        FarmSetupDialog(
            farmProfile = farmProfile,
            farmProfileManager = farmProfileManager,
            onDismiss = { showFarmProfileDialog = false }
        )
    }

    // 2b. Farm Switcher Dialog
    if (showFarmSwitcher) {
        FarmSwitcherDialog(
            currentFarm = currentFarmName,
            onSelectFarm = { newFarm ->
                currentFarmName = newFarm
                coroutineScope.launch {
                    repository.saveFarmSetting("current_farm_name", newFarm)
                }
                showFarmSwitcher = false
            },
            onDismiss = { showFarmSwitcher = false }
        )
    }

    // 3. Global Search Dialog
    if (showGlobalSearch) {
        GlobalSearchDialog(
            repository = repository,
            onGoatClick = { goatId ->
                showGlobalSearch = false
                onNavigateToGoats()
            },
            onCustomerClick = {
                showGlobalSearch = false
                onNavigateToSales()
            },
            onSupplierClick = {
                showGlobalSearch = false
                onNavigateToSuppliers()
            },
            onInsuranceClick = {
                showGlobalSearch = false
                onNavigateToInsurance()
            },
            onLoanClick = {
                showGlobalSearch = false
                onNavigateToLoans()
            },
            onAssetClick = {
                showGlobalSearch = false
                onNavigateToAssets()
            },
            onDismiss = { showGlobalSearch = false }
        )
    }

    // 4. Quick Action Button (+ ADD)
    if (showQuickAdd) {
        QuickAddBottomSheet(
            onAddGoat = { showQuickAdd = false; onNavigateToAddGoat() },
            onQuickNewGoat = { showQuickAdd = false; showNewGoatEntryDialog = true },
            onRecordWeight = { showQuickAdd = false; onNavigateToRecordWeight() },
            onMating = { showQuickAdd = false; onNavigateToBreedingHub(0) },
            onPregnancy = { showQuickAdd = false; onNavigateToBreedingHub(1) },
            onDelivery = { showQuickAdd = false; onNavigateToBreedingHub(2) },
            onVaccination = { showQuickAdd = false; onNavigateToVaccination() },
            onDeworming = { showQuickAdd = false; onNavigateToDeworming() },
            onTreatment = { showQuickAdd = false; onNavigateToTreatment() },
            onMortality = { showQuickAdd = false; onNavigateToMortality() },
            onFeedPurchase = { showQuickAdd = false; onNavigateToFeed() },
            onSale = { showQuickAdd = false; onNavigateToSales() },
            onExpense = { showQuickAdd = false; onNavigateToRecurring() },
            onPayment = { showQuickAdd = false; onNavigateToCashBank() },
            onInsuranceClaim = { showQuickAdd = false; onNavigateToInsurance() },
            onDismiss = { showQuickAdd = false }
        )
    }

    // 4.5. New Goat Entry Form Dialog (Direct Room DB persistence)
    if (showNewGoatEntryDialog) {
        NewGoatEntryDialog(
            repository = repository,
            onGoatSaved = {
                showNewGoatEntryDialog = false
                loadDashboardData()
            },
            onDismiss = { showNewGoatEntryDialog = false }
        )
    }

    // 5. Dashboard Customization Dialog
    if (showCustomizeDialog) {
        DashboardCustomizeDialog(
            currentModules = modules,
            currentLayout = dashboardLayout,
            onSave = { updatedModules, layout ->
                modules = updatedModules
                dashboardLayout = layout
                coroutineScope.launch {
                    val root = JSONObject().apply {
                        put("layout", layout)
                        val arr = JSONArray()
                        updatedModules.forEach { m ->
                            arr.put(JSONObject().apply {
                                put("id", m.id)
                                put("customLabel", m.customLabel ?: "")
                                put("iconName", m.iconName)
                                put("isVisible", m.isVisible)
                                put("sortOrder", m.sortOrder)
                            })
                        }
                        put("modules", arr)
                    }
                    repository.saveFarmSetting("dashboard_customization", root.toString())
                    Toast.makeText(context, "Dashboard preferences saved", Toast.LENGTH_SHORT).show()
                }
                showCustomizeDialog = false
            },
            onDismiss = { showCustomizeDialog = false }
        )
    }

    // 6. Employees Dialog
    if (showEmployeesDialog) {
        EmployeesModal(
            repository = repository,
            onDismiss = { showEmployeesDialog = false }
        )
    }

    // 7. Locations & Tags Dialog
    if (showLocationsTagsDialog) {
        LocationsTagsDialog(
            repository = repository,
            onDismiss = { showLocationsTagsDialog = false }
        )
    }

    // 8. Backup Dialog
    if (showBackupDialog) {
        BackupDialog(
            repository = repository,
            onDismiss = { showBackupDialog = false }
        )
    }

    // 9. Sign Out Dialog
    if (showSignOutDialog) {
        AlertDialog(
            onDismissRequest = { showSignOutDialog = false },
            title = { Text("Sign Out") },
            text = { Text("Are you sure you want to sign out from the Goat Farm application?") },
            confirmButton = {
                TextButton(
                    onClick = {
                        showSignOutDialog = false
                        onSignOut()
                    }
                ) {
                    Text("Sign Out", color = Color(0xFFD32F2F))
                }
            },
            dismissButton = {
                TextButton(onClick = { showSignOutDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}

// ==============================================================================
// 1. QUICK STATUS AREA (Compact Status Strip)
// ==============================================================================
@Composable
fun QuickStatusStrip(
    metrics: LiveDashboardMetrics,
    onTotalGoatsClick: () -> Unit,
    onPregnantClick: () -> Unit,
    onDueDeliveryClick: () -> Unit,
    onKidsClick: () -> Unit,
    onMortalityClick: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(12.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        LazyRow(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 10.dp, horizontal = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            item {
                StatusMiniChip(
                    title = "TOTAL GOATS",
                    value = "${metrics.totalGoats}",
                    icon = Icons.Default.Pets,
                    color = Color(0xFF2E7D32),
                    bgColor = Color(0xFFE8F5E9),
                    onClick = onTotalGoatsClick
                )
            }
            item {
                StatusMiniChip(
                    title = "PREGNANT",
                    value = "${metrics.pregnantCount}",
                    icon = Icons.Default.Favorite,
                    color = Color(0xFF8E24AA),
                    bgColor = Color(0xFFF3E5F5),
                    onClick = onPregnantClick
                )
            }
            item {
                StatusMiniChip(
                    title = "DUE DELIVERY",
                    value = "${metrics.dueForDeliveryCount}",
                    icon = Icons.Default.ChildCare,
                    color = Color(0xFFE65100),
                    bgColor = Color(0xFFFFF3E0),
                    onClick = onDueDeliveryClick
                )
            }
            item {
                StatusMiniChip(
                    title = "KIDS",
                    value = "${metrics.kidsCount}",
                    icon = Icons.Default.ChildCare,
                    color = Color(0xFF00796B),
                    bgColor = Color(0xFFE0F2F1),
                    onClick = onKidsClick
                )
            }
            item {
                StatusMiniChip(
                    title = "MORTALITY",
                    value = "${metrics.mortalityCount}",
                    icon = Icons.Default.WarningAmber,
                    color = Color(0xFFC62828),
                    bgColor = Color(0xFFFFEBEE),
                    onClick = onMortalityClick
                )
            }
        }
    }
}

@Composable
fun StatusMiniChip(
    title: String,
    value: String,
    icon: ImageVector,
    color: Color,
    bgColor: Color,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(10.dp),
        color = bgColor,
        modifier = Modifier.height(58.dp)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(32.dp)
                    .clip(CircleShape)
                    .background(color.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = color,
                    modifier = Modifier.size(18.dp)
                )
            }
            Spacer(modifier = Modifier.width(8.dp))
            Column {
                Text(
                    text = value,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = color
                )
                Text(
                    text = title,
                    style = MaterialTheme.typography.labelSmall,
                    fontSize = 9.sp,
                    color = color.copy(alpha = 0.85f),
                    fontWeight = FontWeight.Medium
                )
            }
        }
    }
}

// ==============================================================================
// 2. MAIN MODULE GRID (3-Column Circular Icons)
// ==============================================================================
@Composable
fun ModuleGrid(
    modules: List<DashboardModuleItem>,
    metrics: LiveDashboardMetrics,
    columnsCount: Int,
    isListView: Boolean = false,
    onModuleClick: (DashboardModuleItem) -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        if (isListView) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp)
            ) {
                modules.forEachIndexed { index, item ->
                    val badge = getBadgeForModule(item.id, metrics)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onModuleClick(item) }
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(46.dp)
                                .clip(CircleShape)
                                .background(item.iconBgColor),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = mapIconNameToVector(item.iconName),
                                contentDescription = item.displayLabel,
                                tint = item.iconColor,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(14.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = item.displayLabel,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = Color(0xFF1B5E20)
                            )
                            Text(
                                text = item.category,
                                fontSize = 12.sp,
                                color = Color.Gray
                            )
                        }
                        if (badge > 0) {
                            Surface(
                                shape = CircleShape,
                                color = Color(0xFFE53935)
                            ) {
                                Text(
                                    text = "$badge",
                                    color = Color.White,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                                )
                            }
                        }
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowForwardIos,
                            contentDescription = null,
                            tint = Color.LightGray,
                            modifier = Modifier.size(14.dp)
                        )
                    }
                    if (index < modules.lastIndex) {
                        HorizontalDivider(color = Color(0xFFF5F5F5), thickness = 0.8.dp)
                    }
                }
            }
        } else {
            // Responsive 3-Column Grid
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 16.dp),
                verticalArrangement = Arrangement.spacedBy(18.dp)
            ) {
                modules.chunked(columnsCount).forEach { rowItems ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceAround
                    ) {
                        rowItems.forEach { item ->
                            val badge = getBadgeForModule(item.id, metrics)
                            Box(modifier = Modifier.weight(1f)) {
                                CircularModuleItem(
                                    item = item,
                                    badgeCount = badge,
                                    onClick = { onModuleClick(item) }
                                )
                            }
                        }
                        // Fill extra spacer cells if last row has fewer items
                        for (i in 0 until (columnsCount - rowItems.size)) {
                            Spacer(modifier = Modifier.weight(1f))
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun CircularModuleItem(
    item: DashboardModuleItem,
    badgeCount: Int,
    onClick: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(horizontal = 4.dp, vertical = 6.dp)
            .testTag("module_${item.id}"),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Large Circular Icon with subtle shadow and border
        Box(
            modifier = Modifier.size(58.dp),
            contentAlignment = Alignment.Center
        ) {
            Surface(
                shape = CircleShape,
                color = item.iconBgColor,
                shadowElevation = 1.dp,
                modifier = Modifier.size(54.dp)
            ) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = mapIconNameToVector(item.iconName),
                        contentDescription = item.displayLabel,
                        tint = item.iconColor,
                        modifier = Modifier.size(28.dp)
                    )
                }
            }

            // Notification Badge (Top-Right)
            if (badgeCount > 0) {
                Surface(
                    shape = CircleShape,
                    color = Color(0xFFE53935),
                    shadowElevation = 2.dp,
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .size(20.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Text(
                            text = if (badgeCount > 99) "99+" else "$badgeCount",
                            color = Color.White,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Short Clear Label below icon (max 2 lines)
        Text(
            text = item.displayLabel,
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.SemiBold,
            fontSize = 11.sp,
            color = Color(0xFF263238),
            textAlign = TextAlign.Center,
            maxLines = 2,
            lineHeight = 13.sp,
            modifier = Modifier.fillMaxWidth()
        )
    }
}

fun getBadgeForModule(moduleId: String, metrics: LiveDashboardMetrics): Int = when (moduleId) {
    "biosecurity_hub", "insurance", "insurance_due" -> metrics.insuranceBadge
    "payments_due" -> metrics.paymentsDueBadge
    "breeding_hub" -> metrics.deliveryBadge + metrics.weaningDueCount
    "delivery" -> metrics.deliveryBadge
    "health" -> metrics.vaccinationBadge
    "alerts" -> metrics.alertsBadge
    "weaning" -> metrics.weaningDueCount
    else -> 0
}

// ==============================================================================
// 3. OPTIONAL MODULES (☰ MORE Drawer Content)
// ==============================================================================
@Composable
fun MoreDrawerContent(
    onNavigateToGoats: () -> Unit,
    onNavigateToBreeding: () -> Unit = {},
    onNavigateToFodder: () -> Unit = {},
    onNavigateToFeedInventory: () -> Unit = {},
    onNavigateToWeaning: () -> Unit = {},
    onNavigateToSales: () -> Unit,
    onNavigateToFinance: () -> Unit,
    onNavigateToAssets: () -> Unit,
    onNavigateToHealth: () -> Unit = {},
    onNavigateToDailyObservation: () -> Unit = {},
    onNavigateToTrends: () -> Unit = {},
    onNavigateToWeightTrends: () -> Unit = {},
    onNavigateToQuarantine: () -> Unit = {},
    onNavigateToInsurance: () -> Unit,
    onNavigateToMortality: () -> Unit = {},
    onNavigateToBiosecurity: (tab: Int) -> Unit = {},
    onNavigateToSuppliers: () -> Unit,
    onNavigateToGst: () -> Unit,
    onNavigateToEWay: () -> Unit,
    onNavigateToLoans: () -> Unit,
    onNavigateToReports: () -> Unit,
    onNavigateToSettings: () -> Unit,
    onOpenBackup: () -> Unit,
    onOpenCustomize: () -> Unit,
    onOpenLocationsTags: () -> Unit,
    onOpenEmployees: () -> Unit,
    onExportCsv: () -> Unit = {},
    onClose: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Farm Modules & Navigation",
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp,
                color = Color(0xFF1B5E20)
            )
            IconButton(onClick = onClose) {
                Icon(Icons.Default.Close, contentDescription = "Close")
            }
        }

        HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = Color(0xFFEEEEEE))

        Text(
            text = "LIVESTOCK & MANAGEMENT",
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = Color.Gray,
            modifier = Modifier.padding(vertical = 4.dp)
        )
        DrawerItem(icon = Icons.Default.Pets, label = "Goats Management", onClick = onNavigateToGoats)
        DrawerItem(icon = Icons.Default.Favorite, label = "Breeding & Reproduction", onClick = onNavigateToBreeding)
        DrawerItem(icon = Icons.Default.Grass, label = "Green Fodder & Feed Cultivation", onClick = onNavigateToFodder)
        DrawerItem(icon = Icons.Default.Inventory2, label = "Feed Inventory & Daily Usage", onClick = onNavigateToFeedInventory)
        DrawerItem(icon = Icons.Default.ChildCare, label = "Weaning Management", onClick = onNavigateToWeaning)
        DrawerItem(icon = Icons.Default.MedicalServices, label = "Health & Clinical Care", onClick = onNavigateToHealth)
        DrawerItem(icon = Icons.Default.EditNote, label = "Daily Health Observations", onClick = onNavigateToDailyObservation)
        DrawerItem(icon = Icons.AutoMirrored.Filled.TrendingUp, label = "Health Trends & ADG Analytics", onClick = onNavigateToTrends)
        DrawerItem(icon = Icons.Default.Scale, label = "Weight Trends & Growth (Recharts)", onClick = onNavigateToWeightTrends)
        DrawerItem(icon = Icons.Default.Security, label = "Biosecurity, Mortality & Insurance", onClick = { onNavigateToBiosecurity(0) })
        DrawerItem(icon = Icons.Default.Place, label = "Locations, Barns & Sheds", onClick = onOpenLocationsTags)
        DrawerItem(icon = Icons.Default.QrCode, label = "Tags, RFID & Ear-Tags", onClick = onOpenLocationsTags)
        DrawerItem(icon = Icons.Default.Badge, label = "Employees & Farm Labour", onClick = onOpenEmployees)

        HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = Color(0xFFEEEEEE))

        Text(
            text = "FINANCE & BILLING",
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = Color.Gray,
            modifier = Modifier.padding(vertical = 4.dp)
        )
        DrawerItem(icon = Icons.Default.PointOfSale, label = "Sales & Customer Credit", onClick = onNavigateToSales)
        DrawerItem(icon = Icons.Default.Business, label = "Suppliers & Creditors", onClick = onNavigateToSuppliers)
        DrawerItem(icon = Icons.Default.Receipt, label = "GST Invoicing", onClick = onNavigateToGst)
        DrawerItem(icon = Icons.Default.LocalShipping, label = "E-Way Bill Generation", onClick = onNavigateToEWay)
        DrawerItem(icon = Icons.Default.RequestQuote, label = "Loans & Borrowings", onClick = onNavigateToLoans)
        DrawerItem(icon = Icons.Default.AccountBalance, label = "Multi-Account Cash & Bank", onClick = onNavigateToFinance)
        DrawerItem(icon = Icons.Default.Domain, label = "Farm Assets & Depreciation", onClick = onNavigateToAssets)

        HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = Color(0xFFEEEEEE))

        Text(
            text = "SYSTEM & TOOLS",
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = Color.Gray,
            modifier = Modifier.padding(vertical = 4.dp)
        )
        DrawerItem(icon = Icons.Default.Assessment, label = "Farm Reports & Audits", onClick = onNavigateToReports)
        DrawerItem(icon = Icons.Default.FileDownload, label = "Export Population & Health (CSV)", onClick = onExportCsv)
        DrawerItem(icon = Icons.Default.CloudSync, label = "Local & Cloud Backup", onClick = onOpenBackup)
        DrawerItem(icon = Icons.Default.Tune, label = "Customize Dashboard", onClick = onOpenCustomize)
        DrawerItem(icon = Icons.Default.Settings, label = "Settings & Appearance", onClick = onNavigateToSettings)

        Spacer(modifier = Modifier.height(24.dp))
    }
}

@Composable
fun DrawerItem(icon: ImageVector, label: String, onClick: () -> Unit) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(8.dp),
        color = Color.Transparent,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(imageVector = icon, contentDescription = null, tint = Color(0xFF2E7D32), modifier = Modifier.size(20.dp))
            Spacer(modifier = Modifier.width(12.dp))
            Text(text = label, fontSize = 13.sp, fontWeight = FontWeight.Medium, color = Color(0xFF37474F))
        }
    }
}

// ==============================================================================
// 4. QUICK ACTION BOTTOM SHEET (+ ADD)
// ==============================================================================
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun QuickAddBottomSheet(
    onAddGoat: () -> Unit,
    onQuickNewGoat: () -> Unit = {},
    onRecordWeight: () -> Unit,
    onMating: () -> Unit,
    onPregnancy: () -> Unit,
    onDelivery: () -> Unit,
    onVaccination: () -> Unit,
    onDeworming: () -> Unit,
    onTreatment: () -> Unit,
    onMortality: () -> Unit,
    onFeedPurchase: () -> Unit,
    onSale: () -> Unit,
    onExpense: () -> Unit,
    onPayment: () -> Unit,
    onInsuranceClaim: () -> Unit,
    onDismiss: () -> Unit
) {
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = Color.White,
        shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            Text(
                text = "Quick Actions (+ ADD)",
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp,
                color = Color(0xFF1B5E20)
            )
            Text(
                text = "Record farm activities directly to local database",
                fontSize = 12.sp,
                color = Color.Gray
            )

            Spacer(modifier = Modifier.height(14.dp))

            val actions = listOf(
                Triple("Quick Entry", Icons.Default.AddCircle, onQuickNewGoat),
                Triple("Add Goat", Icons.Default.Pets, onAddGoat),
                Triple("Weight", Icons.Default.Scale, onRecordWeight),
                Triple("Mating", Icons.Default.Favorite, onMating),
                Triple("Pregnancy", Icons.Default.FavoriteBorder, onPregnancy),
                Triple("Delivery", Icons.Default.ChildCare, onDelivery),
                Triple("Vaccination", Icons.Default.Medication, onVaccination),
                Triple("Deworming", Icons.Default.Healing, onDeworming),
                Triple("Treatment", Icons.Default.MedicalServices, onTreatment),
                Triple("Mortality", Icons.Default.WarningAmber, onMortality),
                Triple("Feed Stock", Icons.Default.Inventory2, onFeedPurchase),
                Triple("Record Sale", Icons.Default.PointOfSale, onSale),
                Triple("Add Expense", Icons.Default.ReceiptLong, onExpense),
                Triple("Bank Transfer", Icons.Default.SwapHoriz, onPayment),
                Triple("Insurance Claim", Icons.Default.Security, onInsuranceClaim)
            )

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                actions.chunked(3).forEach { rowActions ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceAround
                    ) {
                        rowActions.forEach { (label, icon, onClick) ->
                            Card(
                                modifier = Modifier
                                    .weight(1f)
                                    .padding(4.dp)
                                    .clickable { onClick() },
                                colors = CardDefaults.cardColors(containerColor = Color(0xFFF1F8E9)),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 12.dp, horizontal = 4.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Icon(
                                        imageVector = icon,
                                        contentDescription = label,
                                        tint = Color(0xFF2E7D32),
                                        modifier = Modifier.size(24.dp)
                                    )
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Text(
                                        text = label,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Medium,
                                        textAlign = TextAlign.Center,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                        }
                        // Spacer if incomplete row
                        for (i in 0 until (3 - rowActions.size)) {
                            Spacer(modifier = Modifier.weight(1f))
                        }
                    }
                }
                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }
}

// ==============================================================================
// 5. GLOBAL SEARCH DIALOG
// ==============================================================================
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GlobalSearchDialog(
    repository: GoatRepository,
    onGoatClick: (String) -> Unit,
    onCustomerClick: () -> Unit,
    onSupplierClick: () -> Unit,
    onInsuranceClick: () -> Unit,
    onLoanClick: () -> Unit,
    onAssetClick: () -> Unit,
    onDismiss: () -> Unit
) {
    var query by remember { mutableStateOf("") }
    var results by remember { mutableStateOf<List<GlobalSearchResult>>(emptyList()) }
    var isSearching by remember { mutableStateOf(false) }
    val coroutineScope = rememberCoroutineScope()

    LaunchedEffect(query) {
        if (query.isNotBlank()) {
            isSearching = true
            results = repository.searchGlobal(query)
            isSearching = false
        } else {
            results = emptyList()
        }
    }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(max = 560.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Global Search",
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        color = Color(0xFF1B5E20)
                    )
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close")
                    }
                }

                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    placeholder = { Text("Search Goats, Customers, Suppliers, Invoices, Loans...") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                )

                Spacer(modifier = Modifier.height(10.dp))

                if (isSearching) {
                    Box(modifier = Modifier.fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(color = Color(0xFF2E7D32), modifier = Modifier.size(28.dp))
                    }
                } else if (results.isEmpty() && query.isNotBlank()) {
                    Box(modifier = Modifier.fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) {
                        Text("No matching records found", color = Color.Gray, fontSize = 13.sp)
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        items(results) { item ->
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        when (item.moduleType) {
                                            "Goat" -> onGoatClick(item.id)
                                            "Customer" -> onCustomerClick()
                                            "Supplier" -> onSupplierClick()
                                            "Insurance" -> onInsuranceClick()
                                            "Loan" -> onLoanClick()
                                            "Asset" -> onAssetClick()
                                            else -> onGoatClick(item.id)
                                        }
                                    },
                                colors = CardDefaults.cardColors(containerColor = Color(0xFFF9FAF9)),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(10.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Surface(
                                        shape = RoundedCornerShape(6.dp),
                                        color = when (item.moduleType) {
                                            "Goat" -> Color(0xFFE8F5E9)
                                            "Customer" -> Color(0xFFE3F2FD)
                                            "Supplier" -> Color(0xFFFFF3E0)
                                            "Insurance" -> Color(0xFFFCE4EC)
                                            "Loan" -> Color(0xFFEDE7F6)
                                            else -> Color(0xFFE0F2F1)
                                        }
                                    ) {
                                        Text(
                                            text = item.moduleType.uppercase(),
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Color(0xFF1B5E20),
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(text = item.title, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                        Text(text = item.subtitle, fontSize = 11.sp, color = Color.Gray)
                                    }
                                    Icon(
                                        imageVector = Icons.AutoMirrored.Filled.ArrowForwardIos,
                                        contentDescription = null,
                                        tint = Color.LightGray,
                                        modifier = Modifier.size(12.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// ==============================================================================
// 6. FARM SWITCHER DIALOG
// ==============================================================================
@Composable
fun FarmSwitcherDialog(
    currentFarm: String,
    onSelectFarm: (String) -> Unit,
    onDismiss: () -> Unit
) {
    var newFarmName by remember { mutableStateOf("") }
    var showAddFarmInput by remember { mutableStateOf(false) }

    val defaultFarms = listOf(
        "Sunrise Goat Farm - Main Facility",
        "North Pasture Barn B",
        "Green Valley Breeding Station"
    )

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "Select Active Farm",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    color = Color(0xFF1B5E20)
                )
                Text(
                    text = "Switch active facility without mixing herd or financial data",
                    fontSize = 12.sp,
                    color = Color.Gray
                )

                Spacer(modifier = Modifier.height(12.dp))

                defaultFarms.forEach { farm ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onSelectFarm(farm) }
                            .padding(vertical = 10.dp, horizontal = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(
                            selected = farm.equals(currentFarm, ignoreCase = true),
                            onClick = { onSelectFarm(farm) },
                            colors = RadioButtonDefaults.colors(selectedColor = Color(0xFF2E7D32))
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(text = farm, fontWeight = FontWeight.Medium, fontSize = 13.sp)
                    }
                }

                if (showAddFarmInput) {
                    OutlinedTextField(
                        value = newFarmName,
                        onValueChange = { newFarmName = it },
                        label = { Text("New Farm Facility Name") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Button(
                        onClick = {
                            if (newFarmName.isNotBlank()) onSelectFarm(newFarmName)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Add & Switch to Farm")
                    }
                } else {
                    TextButton(
                        onClick = { showAddFarmInput = true },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Add Another Farm Facility")
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    TextButton(onClick = onDismiss) {
                        Text("Close")
                    }
                }
            }
        }
    }
}

// ==============================================================================
// 7. DASHBOARD CUSTOMIZE DIALOG
// ==============================================================================
@Composable
fun DashboardCustomizeDialog(
    currentModules: List<DashboardModuleItem>,
    currentLayout: String,
    onSave: (List<DashboardModuleItem>, String) -> Unit,
    onDismiss: () -> Unit
) {
    var modulesState by remember { mutableStateOf(currentModules) }
    var selectedLayout by remember { mutableStateOf(currentLayout) }
    var selectedCategoryFilter by remember { mutableStateOf("ALL") }

    val categories = listOf("ALL", "Livestock", "Breeding", "Health", "Finance", "Farm", "Reports", "Administration")

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(max = 580.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "Customize Dashboard",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    color = Color(0xFF1B5E20)
                )
                Text(
                    text = "Reorder, show/hide, rename labels, or switch layout",
                    fontSize = 12.sp,
                    color = Color.Gray
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Layout Selector
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilterChip(
                        selected = selectedLayout == "3_COLUMNS",
                        onClick = { selectedLayout = "3_COLUMNS" },
                        label = { Text("3-Col Grid") }
                    )
                    FilterChip(
                        selected = selectedLayout == "2_COLUMNS",
                        onClick = { selectedLayout = "2_COLUMNS" },
                        label = { Text("2-Col Grid") }
                    )
                    FilterChip(
                        selected = selectedLayout == "LIST",
                        onClick = { selectedLayout = "LIST" },
                        label = { Text("List View") }
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Category Filter
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(categories) { cat ->
                        FilterChip(
                            selected = selectedCategoryFilter == cat,
                            onClick = { selectedCategoryFilter = cat },
                            label = { Text(cat, fontSize = 11.sp) }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                val filtered = modulesState.filter {
                    selectedCategoryFilter == "ALL" || it.category.equals(selectedCategoryFilter, ignoreCase = true)
                }

                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    items(filtered) { item ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color(0xFFF9FAF9)),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Checkbox(
                                    checked = item.isVisible,
                                    onCheckedChange = { checked ->
                                        modulesState = modulesState.map {
                                            if (it.id == item.id) it.copy(isVisible = checked) else it
                                        }
                                    }
                                )
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = item.displayLabel,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp
                                    )
                                    Text(
                                        text = "${item.category} • Icon: ${item.iconName}",
                                        fontSize = 10.sp,
                                        color = Color.Gray
                                    )
                                }
                                IconButton(
                                    onClick = {
                                        val idx = modulesState.indexOfFirst { it.id == item.id }
                                        if (idx > 0) {
                                            val mutable = modulesState.toMutableList()
                                            val temp = mutable[idx]
                                            mutable[idx] = mutable[idx - 1].copy(sortOrder = temp.sortOrder)
                                            mutable[idx - 1] = temp.copy(sortOrder = temp.sortOrder - 1)
                                            modulesState = mutable
                                        }
                                    },
                                    modifier = Modifier.size(28.dp)
                                ) {
                                    Icon(Icons.Default.ArrowUpward, contentDescription = "Move Up", modifier = Modifier.size(16.dp))
                                }
                                IconButton(
                                    onClick = {
                                        val idx = modulesState.indexOfFirst { it.id == item.id }
                                        if (idx in 0 until modulesState.lastIndex) {
                                            val mutable = modulesState.toMutableList()
                                            val temp = mutable[idx]
                                            mutable[idx] = mutable[idx + 1].copy(sortOrder = temp.sortOrder)
                                            mutable[idx + 1] = temp.copy(sortOrder = temp.sortOrder + 1)
                                            modulesState = mutable
                                        }
                                    },
                                    modifier = Modifier.size(28.dp)
                                ) {
                                    Icon(Icons.Default.ArrowDownward, contentDescription = "Move Down", modifier = Modifier.size(16.dp))
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(
                        onClick = {
                            modulesState = getDefaultDashboardModules()
                            selectedLayout = "3_COLUMNS"
                        }
                    ) {
                        Text("Reset to Default", fontSize = 12.sp, color = Color.Gray)
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        TextButton(onClick = onDismiss) { Text("Cancel") }
                        Button(
                            onClick = { onSave(modulesState, selectedLayout) },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32))
                        ) {
                            Text("Save Layout")
                        }
                    }
                }
            }
        }
    }
}

// ==============================================================================
// 8. EMPLOYEES & LABOUR MODAL
// ==============================================================================
@Composable
fun EmployeesModal(
    repository: GoatRepository,
    onDismiss: () -> Unit
) {
    val sampleStaff = listOf(
        Triple("Murugan K.", "Farm Supervisor", "Daily • ₹650"),
        Triple("Ravi S.", "Herd Manager", "Daily • ₹550"),
        Triple("Selvi P.", "Feed & Milking Assistant", "Daily • ₹500"),
        Triple("Dr. Natarajan", "Visiting Veterinarian", "Weekly Retainer")
    )

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Farm Labour & Staff", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Color(0xFF1B5E20))
                    IconButton(onClick = onDismiss) { Icon(Icons.Default.Close, contentDescription = "Close") }
                }

                Text("Manage farm workers, roles, and wage records", fontSize = 12.sp, color = Color.Gray)
                Spacer(modifier = Modifier.height(12.dp))

                sampleStaff.forEach { (name, role, wage) ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFF9FAF9)),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                    ) {
                        Row(modifier = Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier.size(36.dp).clip(CircleShape).background(Color(0xFFE8F5E9)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.Badge, contentDescription = null, tint = Color(0xFF2E7D32), modifier = Modifier.size(18.dp))
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(name, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                Text("$role • $wage", fontSize = 11.sp, color = Color.Gray)
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))
                Button(
                    onClick = onDismiss,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Close")
                }
            }
        }
    }
}

// ==============================================================================
// 9. LOCATIONS & TAGS DIALOG
// ==============================================================================
@Composable
fun LocationsTagsDialog(
    repository: GoatRepository,
    onDismiss: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Locations, Tags & RFID", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Color(0xFF1B5E20))
                    IconButton(onClick = onDismiss) { Icon(Icons.Default.Close, contentDescription = "Close") }
                }

                Text("Manage physical barns, grazing pastures, and ear-tags", fontSize = 12.sp, color = Color.Gray)
                Spacer(modifier = Modifier.height(12.dp))

                val items = listOf(
                    "Barn A - Pregnant & Kidding Shed",
                    "Barn B - Weaner & Grower Pens",
                    "Pasture 1 - Napier Grass Grazing Area",
                    "Tag Registry & Barcode / RFID Scanning",
                    "Lost Tag Replacement Workflow"
                )

                items.forEach { label ->
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color(0xFF2E7D32), modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(label, fontSize = 13.sp, color = Color(0xFF37474F))
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))
                Button(
                    onClick = onDismiss,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Done")
                }
            }
        }
    }
}

// ==============================================================================
// 10. BACKUP DIALOG (Local Device & Cloud Backup)
// ==============================================================================
@Composable
fun BackupDialog(
    repository: GoatRepository,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    var isBackingUp by remember { mutableStateOf(false) }
    var backupStatusMessage by remember { mutableStateOf<String?>(null) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Farm Database Backup", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Color(0xFF1B5E20))
                    IconButton(onClick = onDismiss) { Icon(Icons.Default.Close, contentDescription = "Close") }
                }

                Text("Safeguard local herd, breeding, health, and finance records", fontSize = 12.sp, color = Color.Gray)
                Spacer(modifier = Modifier.height(14.dp))

                if (isBackingUp) {
                    Box(modifier = Modifier.fillMaxWidth().padding(16.dp), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(color = Color(0xFF2E7D32))
                    }
                } else {
                    Button(
                        onClick = {
                            isBackingUp = true
                            backupStatusMessage = null
                            coroutineScope.launch {
                                val res = repository.backupManager.createLocalDeviceBackup()
                                isBackingUp = false
                                if (res.isSuccess) {
                                    val info = res.getOrThrow()
                                    backupStatusMessage = "Local backup created successfully:\n${info.fileName} (${info.recordCount} records, ${repository.backupManager.formatFileSize(info.fileSize)})"
                                    Toast.makeText(context, "Local backup created!", Toast.LENGTH_SHORT).show()
                                } else {
                                    backupStatusMessage = "Backup failed: ${res.exceptionOrNull()?.message}"
                                }
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.SdCard, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("1-Click Local Backup (.zip)")
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedButton(
                        onClick = {
                            isBackingUp = true
                            backupStatusMessage = null
                            coroutineScope.launch {
                                val res = repository.backupManager.createBackup(isScheduled = false)
                                isBackingUp = false
                                if (res.isSuccess) {
                                    backupStatusMessage = "Google Drive cloud backup created successfully!"
                                    Toast.makeText(context, "Cloud backup completed!", Toast.LENGTH_SHORT).show()
                                } else {
                                    backupStatusMessage = "Cloud backup note: ${res.exceptionOrNull()?.message}"
                                }
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.CloudUpload, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Cloud Backup (Google Drive)")
                    }
                }

                if (!backupStatusMessage.isNullOrBlank()) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(backupStatusMessage ?: "", fontSize = 11.sp, color = Color(0xFF1B5E20))
                }

                Spacer(modifier = Modifier.height(12.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    TextButton(onClick = onDismiss) { Text("Close") }
                }
            }
        }
    }
}

// ==============================================================================
// 11. DESKTOP SIDE PANEL (Right Panel for Desktop)
// ==============================================================================
@Composable
fun DesktopSideSummaryPanel(
    metrics: LiveDashboardMetrics,
    onViewAlerts: () -> Unit,
    onViewPayments: () -> Unit,
    onViewWeaning: () -> Unit = {}
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
    ) {
        Text("Pending Items & Alerts", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Color(0xFF1B5E20))
        Text("Quick operational summary", fontSize = 12.sp, color = Color.Gray)

        Spacer(modifier = Modifier.height(14.dp))

        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFFFFEBEE)),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth().clickable { onViewAlerts() }
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.NotificationsActive, contentDescription = null, tint = Color(0xFFD32F2F), modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Farm Alerts", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color(0xFFD32F2F))
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text("${metrics.alertsBadge} items requiring immediate action", fontSize = 12.sp)
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF3E0)),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth().clickable { onViewPayments() }
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.PendingActions, contentDescription = null, tint = Color(0xFFE65100), modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Payments Due", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color(0xFFE65100))
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text("${metrics.paymentsDueBadge} pending bills & loans", fontSize = 12.sp)
            }
        }

        if (metrics.weaningDueCount > 0) {
            Spacer(modifier = Modifier.height(10.dp))
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF3E0)),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth().clickable { onViewWeaning() }
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.ChildCare, contentDescription = null, tint = Color(0xFFE65100), modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Weaning Due", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color(0xFFE65100))
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("${metrics.weaningDueCount} kids due for weaning", fontSize = 12.sp)
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFFE8F5E9)),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Security, contentDescription = null, tint = Color(0xFF2E7D32), modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Insurance Status", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color(0xFF2E7D32))
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text("${metrics.insuranceBadge} policies expiring soon", fontSize = 12.sp)
            }
        }
    }
}

// ==============================================================================
// GREEN FODDER DASHBOARD CARD (Requirement 19)
// ==============================================================================
@Composable
fun DashboardGreenFodderCard(
    repository: GoatRepository,
    onNavigateToFodder: (tab: Int) -> Unit
) {
    var plotsCount by remember { mutableStateOf(0) }
    var totalHarvestedKg by remember { mutableStateOf(0.0) }
    var stockBalanceKg by remember { mutableStateOf(0.0) }
    var costPerKg by remember { mutableStateOf(1.75) }
    var daysBuffer by remember { mutableStateOf(14) }

    LaunchedEffect(Unit) {
        try {
            val plots = repository.database.fodderDao().getAllPlots()
            plotsCount = plots.size
            val cuttings = repository.database.fodderDao().getAllCuttings()
            totalHarvestedKg = cuttings.sumOf { it.harvested_weight_kg }
            val feedings = repository.database.fodderDao().getAllFeedings()
            val totalFed = feedings.sumOf { it.quantity_fed_kg }
            stockBalanceKg = (totalHarvestedKg - totalFed).coerceAtLeast(0.0)

            val activities = repository.database.fodderDao().getAllActivities()
            val expenses = activities.sumOf { it.total_cost } + cuttings.sumOf { it.labor_cost ?: 0.0 }
            if (totalHarvestedKg > 0 && expenses > 0) {
                costPerKg = expenses / totalHarvestedKg
            }
            daysBuffer = if (stockBalanceKg > 0) (stockBalanceKg / 35.0).toInt().coerceAtLeast(1) else 14
        } catch (_: Exception) {}
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("dashboard_green_fodder_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        shape = CircleShape,
                        color = Color(0xFFE8F5E9),
                        modifier = Modifier.size(36.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(Icons.Default.Grass, contentDescription = null, tint = Color(0xFF2E7D32), modifier = Modifier.size(20.dp))
                        }
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text("Green Fodder & Feed Cultivation", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color(0xFF1B5E20))
                        Text(if (plotsCount > 0) "$plotsCount Active Plots • Home-grown Security" else "Cultivation & High-Yield Hybrid Grass", fontSize = 11.sp, color = Color.Gray)
                    }
                }

                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = Color(0xFFE8F5E9)
                ) {
                    Text(
                        text = "$daysBuffer d buffer",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF2E7D32),
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
            }

            // Quick Stats Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Color(0xFFF9FBF9),
                    modifier = Modifier.weight(1f)
                ) {
                    Column(modifier = Modifier.padding(8.dp)) {
                        Text("Current Stock", fontSize = 10.sp, color = Color.Gray)
                        Text(if (stockBalanceKg > 0) "${stockBalanceKg.toInt()} kg" else "350 kg", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color(0xFF2E7D32))
                        Text("Ready to feed", fontSize = 9.sp, color = Color.Gray)
                    }
                }
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Color(0xFFF9FBF9),
                    modifier = Modifier.weight(1f)
                ) {
                    Column(modifier = Modifier.padding(8.dp)) {
                        Text("Home-Grown Cost", fontSize = 10.sp, color = Color.Gray)
                        Text("₹${String.format(java.util.Locale.US, "%.2f", costPerKg)}/kg", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color(0xFFE65100))
                        Text("vs ₹3.50 market", fontSize = 9.sp, color = Color.Gray)
                    }
                }
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Color(0xFFF9FBF9),
                    modifier = Modifier.weight(1f)
                ) {
                    Column(modifier = Modifier.padding(8.dp)) {
                        Text("Total Harvested", fontSize = 10.sp, color = Color.Gray)
                        Text(if (totalHarvestedKg > 0) "${totalHarvestedKg.toInt()} kg" else "1,200 kg", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color(0xFF0288D1))
                        Text("Cumulative", fontSize = 9.sp, color = Color.Gray)
                    }
                }
            }

            // Action Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                OutlinedButton(
                    onClick = { onNavigateToFodder(1) }, // Cutting Plan
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 4.dp, vertical = 6.dp)
                ) {
                    Icon(Icons.Default.ContentCut, contentDescription = null, modifier = Modifier.size(13.dp))
                    Spacer(modifier = Modifier.width(3.dp))
                    Text("Cut Plan", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }

                OutlinedButton(
                    onClick = { onNavigateToFodder(3) }, // Cycles
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 4.dp, vertical = 6.dp)
                ) {
                    Icon(Icons.Default.Recycling, contentDescription = null, modifier = Modifier.size(13.dp))
                    Spacer(modifier = Modifier.width(3.dp))
                    Text("Cycles", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }

                Button(
                    onClick = { onNavigateToFodder(0) }, // Fodder Module
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32)),
                    modifier = Modifier.weight(1.2f),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 4.dp, vertical = 6.dp)
                ) {
                    Text("Fodder Hub", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.width(2.dp))
                    Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null, modifier = Modifier.size(13.dp))
                }
            }
        }
    }
}

// ==============================================================================
// 30-DAY LIVESTOCK INSURANCE EXPIRATION URGENT BANNER
// ==============================================================================
@Composable
fun InsuranceExpirationAlertBanner(
    expiringCount: Int,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(14.dp),
        color = Color(0xFFFEF2F2),
        border = BorderStroke(1.5.dp, Color(0xFFEF4444)),
        modifier = modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .testTag("banner_insurance_expiring_urgent")
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(38.dp)
                    .clip(CircleShape)
                    .background(Color(0xFFFEE2E2)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Warning,
                    contentDescription = "Insurance Expiration Alert",
                    tint = Color(0xFFDC2626),
                    modifier = Modifier.size(22.dp)
                )
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "⚠️ Urgent: $expiringCount Insurance ${if (expiringCount == 1) "Policy" else "Policies"} Expiring Within 30 Days",
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.5.sp,
                    color = Color(0xFFB91C1C)
                )
                Text(
                    text = "Tap to review expiring policies and prepare renewals to prevent lapses in mortality coverage.",
                    fontSize = 11.5.sp,
                    color = Color(0xFF7F1D1D),
                    lineHeight = 15.sp
                )
            }
            Spacer(modifier = Modifier.width(8.dp))
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = Color(0xFFDC2626)
            ) {
                Text(
                    text = "Renew",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                )
            }
        }
    }
}

// ==============================================================================
// CONSOLIDATED BIOSECURITY, MORTALITY & INSURANCE CARD
// ==============================================================================
@Composable
fun DashboardBiosecurityCard(
    repository: GoatRepository,
    onNavigateToQuarantine: () -> Unit,
    onNavigateToMortality: () -> Unit,
    onNavigateToInsurance: () -> Unit,
    onNavigateToHub: (tab: Int) -> Unit
) {
    var activeQuarantineCount by remember { mutableIntStateOf(0) }
    var monthlyMortalityCount by remember { mutableIntStateOf(0) }
    var activePolicyCount by remember { mutableIntStateOf(0) }

    val dateFormat = remember { SimpleDateFormat("yyyy-MM-dd", Locale.US) }
    val today = remember { dateFormat.format(Date()) }
    val currentMonth = today.take(7)

    LaunchedEffect(Unit) {
        try {
            val qRes = repository.getQuarantineRecords()
            if (qRes.isSuccess) {
                activeQuarantineCount = qRes.getOrThrow().count { it.status == "QUARANTINE" || it.status == "EXTENDED" }
            }
            val mRes = repository.insurance.getMortalityEvents()
            if (mRes.isSuccess) {
                monthlyMortalityCount = mRes.getOrThrow().count { it.death_date.startsWith(currentMonth) }
            }
            val pRes = repository.insurance.getPolicies()
            if (pRes.isSuccess) {
                activePolicyCount = pRes.getOrThrow().count { it.isActive }
            }
        } catch (_: Exception) {}
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("dashboard_biosecurity_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            // Header Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onNavigateToHub(0) },
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(42.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(Color(0xFFE0F2FE)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Security,
                        contentDescription = null,
                        tint = Color(0xFF0284C7),
                        modifier = Modifier.size(24.dp)
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Biosecurity, Mortality & Insurance",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = Color(0xFF1E293B)
                    )
                    Text(
                        text = "Active isolation, loss audit & policy coverage",
                        fontSize = 12.sp,
                        color = Color.Gray
                    )
                }
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowForwardIos,
                    contentDescription = "Open Hub",
                    tint = Color.LightGray,
                    modifier = Modifier.size(16.dp)
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // 3 Quick Status Chips / Summary Stats
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Surface(
                    color = Color(0xFFFEF3C7),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .weight(1f)
                        .clickable { onNavigateToQuarantine() }
                ) {
                    Column(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "$activeQuarantineCount",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = Color(0xFFD97706)
                        )
                        Text(
                            text = "Quarantine",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Medium,
                            color = Color(0xFF92400E)
                        )
                    }
                }

                Surface(
                    color = Color(0xFFFFEBEE),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .weight(1f)
                        .clickable { onNavigateToMortality() }
                ) {
                    Column(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "$monthlyMortalityCount",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = Color(0xFFD32F2F)
                        )
                        Text(
                            text = "Deaths (${currentMonth.takeLast(2)})",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Medium,
                            color = Color(0xFFB71C1C)
                        )
                    }
                }

                Surface(
                    color = Color(0xFFE3F2FD),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .weight(1f)
                        .clickable { onNavigateToInsurance() }
                ) {
                    Column(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "$activePolicyCount",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = Color(0xFF1976D2)
                        )
                        Text(
                            text = "Insured",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Medium,
                            color = Color(0xFF0D47A1)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Quick Subtab Action Buttons Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = onNavigateToQuarantine,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("btn_dashboard_biosecurity_quarantine"),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 4.dp, vertical = 6.dp),
                    border = BorderStroke(1.dp, Color(0xFFD97706).copy(alpha = 0.5f))
                ) {
                    Icon(
                        Icons.Default.Security,
                        contentDescription = null,
                        tint = Color(0xFFD97706),
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        "Quarantine",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Color(0xFFD97706)
                    )
                }

                OutlinedButton(
                    onClick = onNavigateToMortality,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("btn_dashboard_biosecurity_mortality"),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 4.dp, vertical = 6.dp),
                    border = BorderStroke(1.dp, Color(0xFFD32F2F).copy(alpha = 0.5f))
                ) {
                    Icon(
                        Icons.Default.WarningAmber,
                        contentDescription = null,
                        tint = Color(0xFFD32F2F),
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        "Mortality",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Color(0xFFD32F2F)
                    )
                }

                OutlinedButton(
                    onClick = onNavigateToInsurance,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("btn_dashboard_biosecurity_insurance"),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 4.dp, vertical = 6.dp),
                    border = BorderStroke(1.dp, Color(0xFF1976D2).copy(alpha = 0.5f))
                ) {
                    Icon(
                        Icons.Default.VerifiedUser,
                        contentDescription = null,
                        tint = Color(0xFF1976D2),
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        "Insurance",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Color(0xFF1976D2)
                    )
                }
            }
        }
    }
}
