package com.example.ui.screens.fodder

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.offline.FodderSpeciesEntity
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FodderSpeciesCard(
    species: FodderSpeciesEntity,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    var expanded by remember { mutableStateOf(false) }

    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("species_card_${species.id}")
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = species.name,
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleMedium,
                        color = FarmGreenDark
                    )
                    if (!species.scientific_name.isNullOrBlank()) {
                        Text(
                            text = species.scientific_name,
                            style = MaterialTheme.typography.labelSmall,
                            fontStyle = androidx.compose.ui.text.font.FontStyle.Italic,
                            color = Color.Gray
                        )
                    }
                }

                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = when (species.category) {
                        "Legume Fodder" -> Color(0xFFF3E5F5)
                        "Cereal Fodder" -> FarmAmberContainer
                        "Tree Fodder / Browse" -> Color(0xFFE8EAF6)
                        else -> FarmGreenContainer
                    }
                ) {
                    Text(
                        text = species.category,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = when (species.category) {
                            "Legume Fodder" -> Color(0xFF7B1FA2)
                            "Cereal Fodder" -> FarmBrown
                            "Tree Fodder / Browse" -> Color(0xFF303F9F)
                            else -> FarmGreenDark
                        },
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Quick Nutritive Badges
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                NutritiveBadge(label = "Crude Protein", value = "${species.crude_protein_pct}%", color = FarmGreenDark, modifier = Modifier.weight(1f))
                NutritiveBadge(label = "Dry Matter", value = "${species.dry_matter_pct}%", color = FarmBrown, modifier = Modifier.weight(1f))
                NutritiveBadge(label = "Regrowth", value = "${species.regrowth_interval_days} days", color = Color(0xFF0277BD), modifier = Modifier.weight(1f))
            }

            // Cutting & Regrowth Settings Summary
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = Color(0xFFF9FBF9),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 10.dp)
            ) {
                Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        text = "Cutting / Regrowth Settings:",
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 11.sp,
                        color = Color.DarkGray
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("• First Cut: ${species.days_to_first_cut} days", fontSize = 11.sp, color = Color.Gray)
                        Text("• Regrowth Interval: ${species.regrowth_interval_days} days", fontSize = 11.sp, color = Color.Gray)
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("• Stubble Height: ${species.cutting_height_cm} cm", fontSize = 11.sp, color = Color.Gray)
                        Text("• Est. Yield/Cut: ${species.expected_yield_per_acre_cut_kg.toInt()} kg/ac", fontSize = 11.sp, color = Color.Gray)
                    }
                    if (!species.notes.isNullOrBlank()) {
                        Text(
                            text = "Note: ${species.notes}",
                            fontSize = 10.sp,
                            color = Color.DarkGray,
                            modifier = Modifier.padding(top = 2.dp)
                        )
                    }
                }
            }

            // Action Buttons
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
            ) {
                TextButton(
                    onClick = onEdit,
                    modifier = Modifier.testTag("edit_species_${species.id}")
                ) {
                    Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Edit Settings", fontSize = 12.sp)
                }

                TextButton(
                    onClick = onDelete,
                    colors = ButtonDefaults.textButtonColors(contentColor = FarmError),
                    modifier = Modifier.testTag("delete_species_${species.id}")
                ) {
                    Icon(Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Delete", fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
fun NutritiveBadge(
    label: String,
    value: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(8.dp),
        color = color.copy(alpha = 0.08f),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(vertical = 6.dp, horizontal = 4.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(text = label, fontSize = 9.sp, color = Color.Gray)
            Text(text = value, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = color)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddEditSpeciesDialog(
    initialSpecies: FodderSpeciesEntity? = null,
    onDismiss: () -> Unit,
    onSave: (FodderSpeciesEntity) -> Unit
) {
    var name by remember { mutableStateOf(initialSpecies?.name ?: "") }
    var scientificName by remember { mutableStateOf(initialSpecies?.scientific_name ?: "") }
    var category by remember { mutableStateOf(initialSpecies?.category ?: "Perennial Grass") }
    var crudeProtein by remember { mutableStateOf(initialSpecies?.crude_protein_pct?.toString() ?: "16.0") }
    var dryMatter by remember { mutableStateOf(initialSpecies?.dry_matter_pct?.toString() ?: "20.0") }
    var daysToFirstCut by remember { mutableStateOf(initialSpecies?.days_to_first_cut?.toString() ?: "60") }
    var regrowthDays by remember { mutableStateOf(initialSpecies?.regrowth_interval_days?.toString() ?: "40") }
    var cuttingHeight by remember { mutableStateOf(initialSpecies?.cutting_height_cm?.toString() ?: "15.0") }
    var yieldPerCut by remember { mutableStateOf(initialSpecies?.expected_yield_per_acre_cut_kg?.toString() ?: "15000") }
    var waterRequirement by remember { mutableStateOf(initialSpecies?.water_requirement ?: "Medium") }
    var notes by remember { mutableStateOf(initialSpecies?.notes ?: "") }

    val categories = listOf("Perennial Grass", "Legume Fodder", "Cereal Fodder", "Tree Fodder / Browse")
    val waterLevels = listOf("Low", "Medium", "High")

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = if (initialSpecies == null) "Add Fodder Species" else "Edit Species Settings",
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 480.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Species / Variety Name *") },
                    placeholder = { Text("e.g. Super Napier (Pakchong 1)") },
                    modifier = Modifier.fillMaxWidth().testTag("species_name_input"),
                    singleLine = true
                )

                OutlinedTextField(
                    value = scientificName,
                    onValueChange = { scientificName = it },
                    label = { Text("Scientific Name (Optional)") },
                    placeholder = { Text("e.g. Pennisetum purpureum") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                // Category selector
                Text("Category:", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    categories.take(2).forEach { cat ->
                        FilterChip(
                            selected = category == cat,
                            onClick = { category = cat },
                            label = { Text(cat, fontSize = 11.sp) },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    categories.drop(2).forEach { cat ->
                        FilterChip(
                            selected = category == cat,
                            onClick = { category = cat },
                            label = { Text(cat, fontSize = 11.sp) },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                // Nutritive values
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = crudeProtein,
                        onValueChange = { crudeProtein = it },
                        label = { Text("Crude Protein %") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = dryMatter,
                        onValueChange = { dryMatter = it },
                        label = { Text("Dry Matter %") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                }

                Divider(modifier = Modifier.padding(vertical = 4.dp))
                Text("Cutting & Regrowth Settings:", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = FarmGreenDark)

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = daysToFirstCut,
                        onValueChange = { daysToFirstCut = it },
                        label = { Text("1st Cut (Days)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = regrowthDays,
                        onValueChange = { regrowthDays = it },
                        label = { Text("Regrowth (Days)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = cuttingHeight,
                        onValueChange = { cuttingHeight = it },
                        label = { Text("Stubble Height (cm)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = yieldPerCut,
                        onValueChange = { yieldPerCut = it },
                        label = { Text("Est. Yield/Cut (kg/ac)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                }

                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Agronomic / Feeding Notes") },
                    modifier = Modifier.fillMaxWidth(),
                    maxLines = 2
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (name.isNotBlank()) {
                        val entity = (initialSpecies ?: FodderSpeciesEntity(name = name)).copy(
                            name = name.trim(),
                            scientific_name = scientificName.trim().ifBlank { null },
                            category = category,
                            crude_protein_pct = crudeProtein.toDoubleOrNull() ?: 15.0,
                            dry_matter_pct = dryMatter.toDoubleOrNull() ?: 20.0,
                            days_to_first_cut = daysToFirstCut.toIntOrNull() ?: 60,
                            regrowth_interval_days = regrowthDays.toIntOrNull() ?: 40,
                            cutting_height_cm = cuttingHeight.toDoubleOrNull() ?: 15.0,
                            expected_yield_per_acre_cut_kg = yieldPerCut.toDoubleOrNull() ?: 15000.0,
                            water_requirement = waterRequirement,
                            notes = notes.trim().ifBlank { null },
                            updated_at = System.currentTimeMillis()
                        )
                        onSave(entity)
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = FarmGreenDark),
                modifier = Modifier.testTag("save_species_btn")
            ) {
                Text("Save Species")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
