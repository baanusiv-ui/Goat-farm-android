package com.example.data.backup

import android.content.Context
import android.util.Log
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.example.data.offline.AppDatabase
import com.example.data.offline.NetworkMonitor
import com.example.data.offline.OfflineSyncManager
import com.example.data.supabase.SupabaseClient
import com.example.data.supabase.SupabaseConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class DailyGoogleDriveBackupWorker(
    appContext: Context,
    workerParams: WorkerParameters
) : CoroutineWorker(appContext, workerParams) {

    companion object {
        private const val TAG = "DailyBackupWorker"
    }

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        Log.d(TAG, "Starting scheduled daily Google Drive backup work...")

        val context = applicationContext
        val authManager = GoogleAuthManager(context)
        val database = AppDatabase.getDatabase(context)
        val networkMonitor = NetworkMonitor(context)
        val config = SupabaseConfig(context)
        val client = SupabaseClient(config)
        val syncManager = OfflineSyncManager(context, database, client, networkMonitor)
        val backupManager = BackupManager(context, database, syncManager, authManager)

        // 1. Check if auto backup is enabled
        if (!backupManager.isAutoBackupEnabled.value) {
            Log.d(TAG, "Automatic backup is disabled in settings. Skipping work.")
            return@withContext Result.success()
        }

        // 2. Check if Google Drive account is connected
        if (!authManager.isConnected()) {
            Log.w(TAG, "Google Drive account not connected. Marking pending.")
            return@withContext Result.retry()
        }

        // 3. Check network connectivity
        if (!networkMonitor.isOnline.value) {
            Log.w(TAG, "No internet connection for Google Drive backup. Will retry when connected.")
            return@withContext Result.retry()
        }

        // 4. Execute scheduled backup
        try {
            val res = backupManager.createBackup(isScheduled = true)
            if (res.isSuccess) {
                Log.d(TAG, "Daily Google Drive backup successfully completed: ${res.getOrNull()}")
                Result.success()
            } else {
                val err = res.exceptionOrNull()?.message ?: "Unknown backup failure"
                Log.e(TAG, "Daily Google Drive backup failed: $err")
                // Retry if network or transient error
                Result.retry()
            }
        } catch (e: Exception) {
            Log.e(TAG, "Daily Google Drive backup unexpected exception: ${e.message}", e)
            Result.retry()
        }
    }
}
