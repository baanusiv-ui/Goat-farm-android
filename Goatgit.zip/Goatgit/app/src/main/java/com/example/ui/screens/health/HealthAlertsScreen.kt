package com.example.ui.screens.health

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.supabase.*
import com.example.ui.theme.*
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HealthAlertsScreen(
    repository: GoatRepository,
    onNavigateBack: () -> Unit,
    onNavigateToVaccination: (String) -> Unit,
    onNavigateToDeworming: (String) -> Unit,
    onNavigateToTreatment: (String) -> Unit,
    onNavigateToQuarantine: (String) -> Unit
) {
    BackHandler { onNavigateBack() }

    val coroutineScope = rememberCoroutineScope()
    var alerts by remember { mutableStateOf<List<HealthAlert>>(emptyList()) }
    var selectedFilter by remember { mutableStateOf("ALL") } // ALL, VACCINATION, DEWORMING, TREATMENT, QUARANTINE
    var isLoading by remember { mutableStateOf(true) }

    fun loadData() {
        isLoading = true
        coroutineScope.launch {
            val res = repository.getHealthAlerts()
            if (res.isSuccess) alerts = res.getOrThrow()
            isLoading = false
        }
    }

    LaunchedEffect(Unit) {
        loadData()
    }

    val filters = listOf("ALL", "Vaccination", "Deworming", "Treatment", "Quarantine")

    val filteredAlerts = remember(alerts, selectedFilter) {
        if (selectedFilter == "ALL") alerts
        else alerts.filter { it.type.startsWith(selectedFilter.uppercase()) }
    }

    val urgentCount = remember(alerts) { alerts.count { it.severity == "URGENT" } }
    val warningCount = remember(alerts) { alerts.count { it.severity == "WARNING" } }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "Health & Clinical Alerts",
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp
                        )
                        Text(
                            text = "${alerts.size} Active Reminders ($urgentCount Urgent)",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack, modifier = Modifier.testTag("health_alerts_btn_back")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        if (isLoading) {
            Box(modifier = Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = FarmGreenPrimary)
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xFFF8FAFC))
                    .padding(padding)
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    Spacer(modifier = Modifier.height(4.dp))
                    // Summary status card
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Surface(
                            color = Color(0xFFFEE2E2),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Column(modifier = Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("$urgentCount", fontWeight = FontWeight.Bold, fontSize = 20.sp, color = Color(0xFFDC2626))
                                Text("Urgent / Overdue", fontSize = 11.sp, color = Color(0xFF991B1B))
                            }
                        }
                        Surface(
                            color = Color(0xFFFEF3C7),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Column(modifier = Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("$warningCount", fontWeight = FontWeight.Bold, fontSize = 20.sp, color = Color(0xFFD97706))
                                Text("Due Soon", fontSize = 11.sp, color = Color(0xFF92400E))
                            }
                        }
                        Surface(
                            color = Color(0xFFE0F2FE),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Column(modifier = Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("${alerts.size}", fontWeight = FontWeight.Bold, fontSize = 20.sp, color = Color(0xFF0284C7))
                                Text("Total Alerts", fontSize = 11.sp, color = Color(0xFF075985))
                            }
                        }
                    }
                }

                // Filter row
                item {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        filters.forEach { f ->
                            FilterChip(
                                selected = selectedFilter == f,
                                onClick = { selectedFilter = f },
                                label = { Text(f, fontSize = 11.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = FarmGreenPrimary,
                                    selectedLabelColor = Color.White
                                )
                            )
                        }
                    }
                }

                if (filteredAlerts.isEmpty()) {
                    item {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Box(modifier = Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = FarmGreenDark, modifier = Modifier.size(40.dp))
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text("No Pending Health Alerts", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                                    Text("All scheduled vaccinations, dewormings, and quarantine checks are up to date.", fontSize = 12.sp, color = Color.Gray)
                                }
                            }
                        }
                    }
                } else {
                    items(filteredAlerts) { alert ->
                        HealthAlertCard(
                            alert = alert,
                            onClickAction = {
                                when {
                                    alert.type.startsWith("VACCINATION") -> onNavigateToVaccination(alert.goat_id)
                                    alert.type.startsWith("DEWORMING") -> onNavigateToDeworming(alert.goat_id)
                                    alert.type.startsWith("TREATMENT") -> onNavigateToTreatment(alert.goat_id)
                                    alert.type.startsWith("QUARANTINE") -> onNavigateToQuarantine(alert.goat_id)
                                }
                            }
                        )
                    }
                }

                item {
                    Spacer(modifier = Modifier.height(32.dp))
                }
            }
        }
    }
}

@Composable
private fun HealthAlertCard(
    alert: HealthAlert,
    onClickAction: () -> Unit
) {
    val isUrgent = alert.severity == "URGENT"
    val badgeColor = if (isUrgent) Color(0xFFDC2626) else if (alert.severity == "WARNING") Color(0xFFD97706) else Color(0xFF0284C7)
    val bgColor = if (isUrgent) Color(0xFFFEE2E2) else if (alert.severity == "WARNING") Color(0xFFFEF3C7) else Color(0xFFE0F2FE)

    val (icon, actionLabel) = when {
        alert.type.startsWith("VACCINATION") -> Icons.Default.Vaccines to "Vaccinate"
        alert.type.startsWith("DEWORMING") -> Icons.Default.Medication to "Deworm"
        alert.type.startsWith("TREATMENT") -> Icons.Default.Healing to "Treatment"
        alert.type.startsWith("QUARANTINE") -> Icons.Default.Security to "Quarantine"
        else -> Icons.Default.WarningAmber to "View"
    }

    Card(
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(12.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier.fillMaxWidth().testTag("alert_card_${alert.id}")
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(bgColor),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(icon, contentDescription = null, tint = badgeColor, modifier = Modifier.size(18.dp))
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = alert.title,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = Color(0xFF0F172A)
                        )
                        Text(
                            text = "Due: ${alert.due_date}",
                            fontSize = 11.sp,
                            color = Color.Gray
                        )
                    }
                }

                Surface(
                    color = bgColor,
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text(
                        text = if (isUrgent) "OVERDUE" else "DUE SOON",
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = badgeColor,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }

            Text(
                text = alert.message,
                fontSize = 12.sp,
                color = Color.DarkGray
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End
            ) {
                Button(
                    onClick = onClickAction,
                    colors = ButtonDefaults.buttonColors(containerColor = badgeColor),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(text = "Action: $actionLabel", fontSize = 11.sp, color = Color.White)
                }
            }
        }
    }
}
