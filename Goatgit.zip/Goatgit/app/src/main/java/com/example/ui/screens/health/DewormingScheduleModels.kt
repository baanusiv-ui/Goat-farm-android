package com.example.ui.screens.health

import androidx.compose.ui.graphics.Color
import com.example.data.supabase.Goat
import java.text.SimpleDateFormat
import java.util.*

enum class DewormingCategory {
    ALL,
    KIDS,
    GROWING,
    ADULTS,
    PREGNANT_DOES,
    ROTATION_GUIDE
}

data class DewormingProtocolStage(
    val id: String,
    val title: String,
    val tamilTitle: String,
    val category: DewormingCategory,
    val stageBadge: String,
    val timingDescription: String,
    val recommendedMedicine: String,
    val drugClass: String,
    val route: String,
    val dosageGuide: String,
    val targetParasites: String,
    val clinicalInstructions: String,
    val vitalWarning: String? = null,
    val isContraindicated: Boolean = false,
    val accentColor: Color = Color(0xFF059669)
)

data class AnthelminticClassInfo(
    val className: String,
    val tamilName: String,
    val commonDrugs: String,
    val colorTag: String,
    val primaryMode: String,
    val safetyNotes: String
)

data class PregnancyRiskInfo(
    val isPregnant: Boolean,
    val gestationDays: Int?,
    val isContraindicated: Boolean,
    val riskLevel: String, // "CRITICAL_DANGER", "LATE_GESTATION_CAUTION", "POST_PARTUM_SAFE", "NOT_PREGNANT"
    val warningMessage: String,
    val recommendedAction: String,
    val safeMedicineAdvice: String
)

data class GoatDewormingEvaluation(
    val goat: Goat,
    val ageDays: Int?,
    val ageMonths: Double?,
    val lifeStageLabel: String,
    val recommendedStageId: String,
    val recommendedMedicine: String,
    val recommendedDose: String,
    val recommendedIntervalDays: Int,
    val pregnancyRisk: PregnancyRiskInfo,
    val lastMedicineUsed: String?,
    val lastTreatmentDate: String?,
    val isDueNow: Boolean,
    val dueReason: String
)

object DewormingScheduleCatalog {

    val anthelminticClasses = listOf(
        AnthelminticClassInfo(
            className = "Benzimidazoles (Group 1 - White Drenches)",
            tamilName = "பென்சிமிடாசோல் வகை (வெள்ளை மருந்து)",
            commonDrugs = "Albendazole, Fenbendazole, Oxfendazole",
            colorTag = "White Drench",
            primaryMode = "Broad spectrum against adult nematodes, tapeworms (Moniezia) and inhibited larvae.",
            safetyNotes = "⚠️ CONTRAINDICATED in first 45-60 days of pregnancy (embryotoxic). Fenbendazole is safe in late pregnancy."
        ),
        AnthelminticClassInfo(
            className = "Imidazothiazoles (Group 2 - Clear Drenches)",
            tamilName = "லெவாமிசோல் வகை (தெளிந்த மருந்து)",
            commonDrugs = "Levamisole Hydrochloride",
            colorTag = "Clear Drench",
            primaryMode = "Paralyzes adult worms & lungworms (Dictyocaulus); immune-stimulant properties.",
            safetyNotes = "Narrow safety margin; weigh animals accurately to avoid toxic tremors. Avoid high doses in exhausted/sick stock."
        ),
        AnthelminticClassInfo(
            className = "Macrocyclic Lactones (Group 3 - Endectocides)",
            tamilName = "மேக்ரோசைக்ளிக் லாக்டோன் (ஐவர்மெக்டின்)",
            commonDrugs = "Ivermectin, Doramectin, Moxidectin",
            colorTag = "ML / Avermectin",
            primaryMode = "Controls both internal nematodes (Haemonchus) and external parasites (mites, lice, ticks, nasal bots).",
            safetyNotes = "Usually given Subcutaneously (S/C). Effective pre-monsoon for persistent protection."
        ),
        AnthelminticClassInfo(
            className = "Salicylanilides & Flukicides (Group 4)",
            tamilName = "கல்லீரல் புழு நீக்கி (க்ளோசாண்டெல் / ஆக்சிக்குளோசனைடு)",
            commonDrugs = "Closantel, Oxyclozanide, Rafoxanide, Triclabendazole",
            colorTag = "Flukicide",
            primaryMode = "Specialized against blood-sucking Haemonchus contortus and Liver Flukes (Fasciola gigantica), Amphistomes.",
            safetyNotes = "Essential post-monsoon after goats graze around wet tank bunds or canal vegetation."
        )
    )

    val protocols = listOf(
        DewormingProtocolStage(
            id = "kid_stage_1",
            title = "1st Deworming for Kids",
            tamilTitle = "குட்டிகளுக்கு முதல் முறை குடற்புழு நீக்கம்",
            category = DewormingCategory.KIDS,
            stageBadge = "Age: 30 Days (1 Month)",
            timingDescription = "Administer at 30 days of age (1 month old / 1 மாதம்).",
            recommendedMedicine = "Albendazole Suspension or Fenbendazole Oral",
            drugClass = "Benzimidazoles (Group 1)",
            route = "Oral Drench (வாய் வழியாக)",
            dosageGuide = "1 ml per 3-5 kg body weight (Albendazole 2.5% @ 5-7.5 mg/kg)",
            targetParasites = "Roundworms (Ascaris), Tapeworms (Moniezia), early intestinal nematodes",
            clinicalInstructions = "• Administer in the morning on an empty / light fasting stomach.\n• Weigh kid accurately using a hanging scale to prevent underdosing.\n• Gently drench across the base of the tongue to avoid aspiration into lungs.",
            vitalWarning = "Do not underdose; underdosing breeds early drug resistance.",
            accentColor = Color(0xFF0284C7)
        ),
        DewormingProtocolStage(
            id = "kid_stage_2",
            title = "2nd Deworming for Kids",
            tamilTitle = "குட்டிகளுக்கு இரண்டாம் முறை (மருந்து சுழற்சி)",
            category = DewormingCategory.KIDS,
            stageBadge = "Age: 60 Days (2 Months)",
            timingDescription = "Administer at 60 days of age (2 months old / 2 மாதம்).",
            recommendedMedicine = "Levamisole Hydrochloride or Fenbendazole",
            drugClass = "Imidazothiazoles (Group 2) - Rotated Family",
            route = "Oral Drench (வாய் வழியாக)",
            dosageGuide = "Levamisole @ 7.5 mg/kg body weight (or Fenbendazole @ 5 mg/kg)",
            targetParasites = "Hookworms (Bunostomum), Roundworms, Lungworms (Dictyocaulus)",
            clinicalInstructions = "• Rotate chemical family from the 1st deworming drug (switch from Albendazole to Levamisole or Fenbendazole).\n• Anthelmintic class rotation prevents parasite survival and builds resilient kids.\n• Check kid vitality, stool consistency, and mucous membrane tint.",
            vitalWarning = "Always rotate drug class from the previous treatment.",
            accentColor = Color(0xFF059669)
        ),
        DewormingProtocolStage(
            id = "kid_stage_3",
            title = "3rd Deworming - Weaning Transition",
            tamilTitle = "மூன்றாம் முறை - பால் குடி மறக்கும் பருவம் (3 மாதம்)",
            category = DewormingCategory.KIDS,
            stageBadge = "Age: 90 Days (3 Months / Weaning)",
            timingDescription = "Administer at 90 days of age (3 months old / பால் குடி மறக்கும் பருவம்).",
            recommendedMedicine = "Oxyclozanide + Levamisole Combination or Fenbendazole",
            drugClass = "Combination Flukicide + Group 2",
            route = "Oral Drench (வாய் வழியாக)",
            dosageGuide = "Per combination label (typically 1 ml per 3-4 kg body weight)",
            targetParasites = "Mixed helminths, Amphistomes (conical flukes), Tapeworms, Lungworms",
            clinicalInstructions = "• Administer 3 to 5 days BEFORE weaning (separating kids from mother does).\n• Weaning stress causes a sharp drop in kid immunity, creating a high-risk window for parasitic diarrhea.\n• Deworming pre-weaning protects the rumen villi and prevents post-weaning stunting.",
            vitalWarning = "Administer before separation to cushion weaning stress.",
            accentColor = Color(0xFF7C3AED)
        ),
        DewormingProtocolStage(
            id = "growing_weaners",
            title = "Growing Weaners & Young Stock",
            tamilTitle = "வளரும் குட்டிகளுக்கான வழிகாட்டல் (3 முதல் 6 மாதங்கள்)",
            category = DewormingCategory.GROWING,
            stageBadge = "Every 60-90 Days (3 - 6 Months)",
            timingDescription = "Administer every 60 to 90 days between 3 to 6 months of age.",
            recommendedMedicine = "Closantel Oral Drench, Levamisole, or Fenbendazole",
            drugClass = "Rotational Group (Salicylanilides / ML)",
            route = "Oral Drench or Subcutaneous (S/C)",
            dosageGuide = "Closantel @ 10-15 mg/kg or Levamisole @ 7.5 mg/kg",
            targetParasites = "Haemonchus contortus (Barber pole worm), Hookworms, Nasal bots",
            clinicalInstructions = "• Fast-growing weaners graze actively and pick up intense larvae from pasture.\n• Routinely examine lower eyelid mucous membranes using the FAMACHA system.\n• Treat weaners with pale pink/white eyes (FAMACHA score 3-5) immediately.\n• Monitor weight weekly to ensure steady daily weight gain.",
            vitalWarning = "Watch for bottle jaw (edema under chin) and paleness indicating barber pole worm.",
            accentColor = Color(0xFFD97706)
        ),
        DewormingProtocolStage(
            id = "adult_pre_monsoon",
            title = "Adults Pre-Monsoon Strategic Protocol",
            tamilTitle = "மழைக்காலத்திற்கு முன் - மே / ஜூன் (பெரிய ஆடுகள்)",
            category = DewormingCategory.ADULTS,
            stageBadge = "Pre-Monsoon (May - June)",
            timingDescription = "Administer in May - June before onset of Southwest / Northeast Monsoon rains.",
            recommendedMedicine = "Ivermectin (S/C) or Closantel or Albendazole",
            drugClass = "Macrocyclic Lactone / Group 3 or Salicylanilide",
            route = "Subcutaneous Injection (1 ml / 50 kg) or Oral Drench",
            dosageGuide = "Ivermectin 1% @ 0.2 mg/kg S/C or Closantel @ 10 mg/kg oral",
            targetParasites = "Nematodes, Barber pole worm, external ectoparasites (ticks, mites, lice)",
            clinicalInstructions = "• Strategic timing reduces fecal egg count before rain-triggered humidity and green pasture growth.\n• Prevents pastures from becoming mass larval contamination zones when monsoon rains arrive.\n• Boosts overall herd stamina before seasonal temperature shifts.",
            vitalWarning = "Administer across the entire adult herd simultaneously before the first heavy rain.",
            accentColor = Color(0xFFEA580C)
        ),
        DewormingProtocolStage(
            id = "adult_post_monsoon",
            title = "Adults Post-Monsoon Flukicide Protocol",
            tamilTitle = "மழைக்காலத்திற்கு பின் - அக்டோபர் / நவம்பர்",
            category = DewormingCategory.ADULTS,
            stageBadge = "Post-Monsoon (Oct - Nov)",
            timingDescription = "Administer in October - November after monsoon rains and waterlogging.",
            recommendedMedicine = "Levamisole + Oxyclozanide, Rafoxanide, or Triclabendazole",
            drugClass = "Flukicides + Imidazothiazoles",
            route = "Oral Drench (வாய் வழியாக)",
            dosageGuide = "Oxyclozanide 10-15 mg/kg + Levamisole 7.5 mg/kg combination suspension",
            targetParasites = "Liver Flukes (Fasciola gigantica), Conical Flukes (Amphistomes), Roundworms",
            clinicalInstructions = "• Wet, stagnant water puddles and damp grasses harbor snails (Lymnaea), the intermediate hosts of liver flukes.\n• Post-monsoon grazing exposes goats to massive metacercarial fluke cysts.\n• Deworming with flukicide eradicates liver flukes before irreversible liver fibrosis and bottle jaw occur.",
            vitalWarning = "Essential if goats graze near ponds, paddy fields, irrigation canals or wetlands.",
            accentColor = Color(0xFF0D9488)
        ),
        DewormingProtocolStage(
            id = "adult_quarterly_routine",
            title = "Adult Herd Quarterly Maintenance",
            tamilTitle = "பெரிய ஆடுகளுக்கு ஆண்டுக்கு 3 முதல் 4 முறை",
            category = DewormingCategory.ADULTS,
            stageBadge = "3 - 4 Times / Year (Every 90-120 Days)",
            timingDescription = "Regular maintenance for non-pregnant does and breeding bucks.",
            recommendedMedicine = "Rotate: Benzimidazoles ↔ Levamisole ↔ MLs ↔ Closantel",
            drugClass = "Systematic 4-Class Rotation Matrix",
            route = "Oral Drench or Injectable",
            dosageGuide = "Based on exact animal weight (weigh heaviest animal in pen for pen drenching)",
            targetParasites = "Gastrointestinal helminths, lungworms, tapeworms",
            clinicalInstructions = "• Never use the same anthelmintic product consecutively for more than 2 treatments.\n• Annual class rotation preserves the effectiveness of existing dewormers on your farm.\n• Perform periodic Faecal Egg Count (FEC / McMaster test) to check drug efficacy.",
            vitalWarning = "Calibrate drenching gun; wipe tip between pens to prevent oral disease transfer.",
            accentColor = Color(0xFF2563EB)
        ),
        DewormingProtocolStage(
            id = "pregnant_does_protocol",
            title = "Pregnant Does Protocol & Critical Safety Rules",
            tamilTitle = "சினை ஆடுகள் வழிகாட்டுதல் & எச்சரிக்கை",
            category = DewormingCategory.PREGNANT_DOES,
            stageBadge = "Gestation Life Stage (Strict Safety Rules)",
            timingDescription = "Specialized reproductive safety protocol throughout doe pregnancy.",
            recommendedMedicine = "Fenbendazole Oral ONLY (When essential in late pregnancy)",
            drugClass = "Selective Pregnancy-Safe Benzimidazole",
            route = "Oral Drench with gentle handling",
            dosageGuide = "Fenbendazole @ 5-7.5 mg/kg oral suspension (Strictly under vet guidance)",
            targetParasites = "Periparturient hypobiotic larvae, clinical Haemonchosis",
            clinicalInstructions = "• 🚫 FIRST 45-60 DAYS OF GESTATION (முதல் 45-60 நாட்கள்): STRICTLY PROHIBITED! Never administer dewormers (especially Albendazole, Parbendazole) during early pregnancy due to high embryotoxic risk, fetal skull/skeletal malformations, and abortion.\n• ⚠️ LATE GESTATION (Day 90+ / 3.5 - 4 Months): Deworm ONLY IF CLINICALLY ESSENTIAL (severe anemia / FAMACHA score 4-5). Use Fenbendazole oral drench under veterinary advice.\n• ✅ POST-PARTUM / LACTATION: Deworm the doe 2 to 3 weeks AFTER KIDDING to prevent 'spring rise' egg shedding in dung and milk transmission to newborn kids.",
            vitalWarning = "⚠️ NEVER USE ALBENDAZOLE IN EARLY PREGNANCY (Days 1-60). Risk of embryo death & abortion!",
            isContraindicated = true,
            accentColor = Color(0xFFDC2626)
        )
    )

    fun evaluatePregnancyRisk(gestationDays: Int?): PregnancyRiskInfo {
        if (gestationDays == null) {
            return PregnancyRiskInfo(
                isPregnant = false,
                gestationDays = null,
                isContraindicated = false,
                riskLevel = "NOT_PREGNANT",
                warningMessage = "Animal is not recorded as pregnant. Standard deworming protocol applies.",
                recommendedAction = "Standard deworming safe.",
                safeMedicineAdvice = "Any approved class with rotation."
            )
        }

        return when {
            gestationDays in 1..60 -> {
                PregnancyRiskInfo(
                    isPregnant = true,
                    gestationDays = gestationDays,
                    isContraindicated = true,
                    riskLevel = "CRITICAL_DANGER",
                    warningMessage = "🚫 CRITICAL DANGER (Day $gestationDays of pregnancy): Deworming is STRICTLY CONTRAINDICATED during the first 45-60 days of gestation! High risk of embryonic absorption, fetal deformities, or abortion (especially with Albendazole).",
                    recommendedAction = "DO NOT DEWORM NOW. Wait until late pregnancy or postpartum.",
                    safeMedicineAdvice = "Avoid all dewormers during organogenesis (Days 1-60)."
                )
            }
            gestationDays in 61..89 -> {
                PregnancyRiskInfo(
                    isPregnant = true,
                    gestationDays = gestationDays,
                    isContraindicated = false,
                    riskLevel = "MID_GESTATION_CAUTION",
                    warningMessage = "⚠️ MID-GESTATION (Day $gestationDays of pregnancy): Deworm only if severe clinical worm burden is diagnosed by a veterinarian.",
                    recommendedAction = "Consult veterinarian. If necessary, use Fenbendazole only.",
                    safeMedicineAdvice = "Fenbendazole oral suspension only. Avoid Albendazole and high doses of Levamisole."
                )
            }
            gestationDays in 90..155 -> {
                PregnancyRiskInfo(
                    isPregnant = true,
                    gestationDays = gestationDays,
                    isContraindicated = false,
                    riskLevel = "LATE_GESTATION_CAUTION",
                    warningMessage = "ℹ️ LATE GESTATION (Day $gestationDays of pregnancy): Safe window for selective treatment if doe shows anemia or heavy worm burden. Deworm gently.",
                    recommendedAction = "Use Fenbendazole oral drench under veterinary guidance.",
                    safeMedicineAdvice = "Fenbendazole @ 5-7.5 mg/kg oral drench. Avoid injectable organophosphates."
                )
            }
            else -> {
                PregnancyRiskInfo(
                    isPregnant = true,
                    gestationDays = gestationDays,
                    isContraindicated = false,
                    riskLevel = "POST_PARTUM_SAFE",
                    warningMessage = "✅ POST-PARTUM / LACTATION: Safe to deworm doe 2-3 weeks after kidding to arrest egg shedding.",
                    recommendedAction = "Administer broad-spectrum anthelmintic.",
                    safeMedicineAdvice = "Fenbendazole, Ivermectin, or Levamisole."
                )
            }
        }
    }

    fun calculateDose(medicineName: String, weightKg: Double?): String {
        val wt = weightKg ?: 25.0
        val lower = medicineName.lowercase(Locale.ROOT)
        return when {
            lower.contains("albendazole") -> {
                val ml = (wt / 3.0).coerceAtLeast(1.0)
                String.format(Locale.US, "%.1f ml (Albendazole 2.5%% @ 7.5 mg/kg)", ml)
            }
            lower.contains("fenbendazole") -> {
                val ml = (wt / 4.0).coerceAtLeast(1.0)
                String.format(Locale.US, "%.1f ml (Fenbendazole 2.5%% @ 5 mg/kg)", ml)
            }
            lower.contains("levamisole") -> {
                val ml = (wt / 5.0).coerceAtLeast(1.0)
                String.format(Locale.US, "%.1f ml (Levamisole 3%% @ 7.5 mg/kg)", ml)
            }
            lower.contains("closantel") -> {
                val ml = (wt / 5.0).coerceAtLeast(1.0)
                String.format(Locale.US, "%.1f ml (Closantel 5%% @ 10 mg/kg)", ml)
            }
            lower.contains("ivermectin") -> {
                val ml = (wt / 50.0).coerceAtLeast(0.2)
                String.format(Locale.US, "%.2f ml S/C (Ivermectin 1%% @ 0.2 mg/kg)", ml)
            }
            lower.contains("oxyclozanide") -> {
                val ml = (wt / 3.5).coerceAtLeast(1.0)
                String.format(Locale.US, "%.1f ml (Oxyclozanide + Levamisole drench)", ml)
            }
            else -> {
                val ml = (wt / 4.0).coerceAtLeast(1.0)
                String.format(Locale.US, "%.1f ml (Estimated for %.1f kg goat)", ml, wt)
            }
        }
    }

    fun evaluateGoatDeworming(
        goat: Goat,
        lastDewormingDate: String?,
        lastMedicine: String?,
        isPregnant: Boolean,
        gestationDays: Int?
    ): GoatDewormingEvaluation {
        val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        val today = Date()

        var ageDays: Int? = null
        var ageMonths: Double? = null

        if (!goat.birth_date_c.isNullOrBlank()) {
            try {
                val bDate = dateFormat.parse(goat.birth_date_c)
                if (bDate != null) {
                    val diff = today.time - bDate.time
                    val days = (diff / (1000 * 60 * 60 * 24)).toInt()
                    ageDays = days
                    ageMonths = days / 30.0
                }
            } catch (_: Exception) {}
        }

        val pregRisk = evaluatePregnancyRisk(if (isPregnant) (gestationDays ?: 30) else null)

        val daysSinceLastDeworming: Int? = if (!lastDewormingDate.isNullOrBlank()) {
            try {
                val lDate = dateFormat.parse(lastDewormingDate)
                if (lDate != null) {
                    ((today.time - lDate.time) / (1000 * 60 * 60 * 24)).toInt()
                } else null
            } catch (_: Exception) { null }
        } else null

        // Determine recommended stage and rotation
        val (stageId, recMed, interval, lifeStage) = when {
            pregRisk.isPregnant && pregRisk.isContraindicated -> {
                Tuple4("pregnant_does_protocol", "⚠️ CONTRAINDICATED (Days 1-60). Fenbendazole ONLY in late pregnancy.", 150, "Pregnant Doe (Caution)")
            }
            pregRisk.isPregnant -> {
                Tuple4("pregnant_does_protocol", "Fenbendazole Oral Suspension (Pregnancy Safe)", 150, "Pregnant Doe (Late Gestation)")
            }
            ageDays != null && ageDays in 20..45 -> {
                Tuple4("kid_stage_1", "Albendazole Oral Suspension (or Fenbendazole)", 30, "Kid (30 Days Milestone)")
            }
            ageDays != null && ageDays in 46..75 -> {
                val rotated = if (lastMedicine?.contains("Albendazole", ignoreCase = true) == true) "Levamisole Hydrochloride" else "Fenbendazole Oral"
                Tuple4("kid_stage_2", rotated, 30, "Kid (60 Days Milestone)")
            }
            ageDays != null && ageDays in 76..110 -> {
                Tuple4("kid_stage_3", "Oxyclozanide + Levamisole Combination", 30, "Weaner (90 Days Weaning)")
            }
            ageDays != null && ageDays in 111..190 -> {
                Tuple4("growing_weaners", "Closantel Oral or Levamisole", 60, "Growing Weaner (3-6 Months)")
            }
            else -> {
                val rotated = when {
                    lastMedicine?.contains("Albendazole", ignoreCase = true) == true -> "Levamisole + Oxyclozanide"
                    lastMedicine?.contains("Levamisole", ignoreCase = true) == true -> "Closantel or Ivermectin"
                    else -> "Albendazole or Fenbendazole"
                }
                Tuple4("adult_quarterly_routine", rotated, 90, "Adult Herd")
            }
        }

        val isDueNow = when {
            pregRisk.isPregnant && pregRisk.isContraindicated -> false
            daysSinceLastDeworming == null -> true
            daysSinceLastDeworming >= interval -> true
            ageDays != null && (ageDays in 28..35 || ageDays in 58..65 || ageDays in 88..95) -> true
            else -> false
        }

        val dueReason = when {
            pregRisk.isPregnant && pregRisk.isContraindicated -> "🚫 Contraindicated: Early Pregnancy (Day ${pregRisk.gestationDays})"
            daysSinceLastDeworming == null -> "Never dewormed on record"
            ageDays != null && ageDays in 25..35 -> "Reaching 30-day neonatal deworming milestone"
            ageDays != null && ageDays in 55..65 -> "Reaching 60-day booster milestone"
            ageDays != null && ageDays in 85..95 -> "Reaching 90-day weaning milestone"
            daysSinceLastDeworming >= interval -> "Last deworming was $daysSinceLastDeworming days ago (Exceeds $interval-day interval)"
            else -> "Next due in ${interval - (daysSinceLastDeworming ?: 0)} days"
        }

        val calculatedDose = calculateDose(recMed, goat.weight_kg_c)

        return GoatDewormingEvaluation(
            goat = goat,
            ageDays = ageDays,
            ageMonths = ageMonths,
            lifeStageLabel = lifeStage,
            recommendedStageId = stageId,
            recommendedMedicine = recMed,
            recommendedDose = calculatedDose,
            recommendedIntervalDays = interval,
            pregnancyRisk = pregRisk,
            lastMedicineUsed = lastMedicine,
            lastTreatmentDate = lastDewormingDate,
            isDueNow = isDueNow,
            dueReason = dueReason
        )
    }

    private data class Tuple4(val a: String, val b: String, val c: Int, val d: String)
}
