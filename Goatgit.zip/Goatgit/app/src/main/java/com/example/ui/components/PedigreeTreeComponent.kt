package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Pets
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.pedigree.AnimalOrigin
import com.example.data.pedigree.GoatPedigree
import com.example.data.pedigree.PedigreeManager
import com.example.data.pedigree.PedigreeNode
import com.example.data.supabase.Goat
import com.example.i18n.t
import com.example.ui.theme.*

@Composable
fun OriginBadge(
    origin: String,
    modifier: Modifier = Modifier
) {
    val norm = AnimalOrigin.normalize(origin)
    val (bgColor, textColor, label) = when (norm) {
        AnimalOrigin.FARM_BORN -> Triple(FarmGreenContainer, FarmGreenDark, t("pedigree.farm_born"))
        AnimalOrigin.MARKET_BOUGHT -> Triple(Color(0xFFE3F2FD), Color(0xFF0D47A1), t("pedigree.market_bought"))
        else -> Triple(Color(0xFFF5F5F5), Color(0xFF616161), t("pedigree.unknown_origin"))
    }

    Surface(
        shape = RoundedCornerShape(8.dp),
        color = bgColor,
        modifier = modifier
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Bold,
            color = textColor,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
        )
    }
}

@Composable
fun PedigreeDetailSection(
    goat: Goat,
    allGoats: List<Goat>,
    onOpenGoat: (Goat) -> Unit,
    modifier: Modifier = Modifier
) {
    val pedigree = PedigreeManager.buildPedigree(goat, allGoats)

    LazyColumn(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Summary Header Card
        item {
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFFAFAFA))
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "${t("pedigree.title")}: ${goat.name} (${goat.tag_c})",
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.titleSmall,
                            color = FarmGreenDark
                        )
                        OriginBadge(origin = goat.effectiveOrigin)
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Text(
                            text = "${t("pedigree.breed")}: ${goat.breed_c}",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        if (pedigree.isFarmBorn) {
                            Text(
                                text = "${t("pedigree.sire")}: ${pedigree.sireNode?.tag ?: goat.sire_c ?: "Unknown"}",
                                fontSize = 12.sp
                            )
                            Text(
                                text = "${t("pedigree.dam")}: ${pedigree.damNode?.tag ?: goat.dam_c ?: "Unknown"}",
                                fontSize = 12.sp
                            )
                        }
                    }
                }
            }
        }

        // Market-bought Notice
        if (pedigree.isMarketBought && !pedigree.hasPedigreeData) {
            item {
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFE3F2FD))
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Info, contentDescription = null, tint = Color(0xFF0D47A1))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = t("pedigree.market_bought"),
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF0D47A1)
                                )
                            }
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = Color(0xFFBBDEFB)
                            ) {
                                Text(
                                    text = t("pedigree.status_unknown"),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF0D47A1),
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                                )
                            }
                        }

                        HorizontalDivider(color = Color(0xFFBBDEFB))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "${t("pedigree.sire")}: ${t("pedigree.status_unknown")}",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = Color(0xFF1565C0)
                            )
                            Text(
                                text = "${t("pedigree.dam")}: ${t("pedigree.status_unknown")}",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = Color(0xFF1565C0)
                            )
                        }

                        Text(
                            text = "Pedigree Status: ${t("pedigree.not_recorded")}",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium,
                            color = Color(0xFF1565C0)
                        )

                        Text(
                            text = t("pedigree.market_bought_notice"),
                            fontSize = 12.sp,
                            color = Color(0xFF1565C0)
                        )
                        if (!goat.purchase_date_c.isNullOrBlank() || goat.purchase_cost_c != null) {
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "Purchase Details: Date: ${goat.purchase_date_c ?: "--"} • Cost: ₹${goat.purchase_cost_c ?: "--"}",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = Color(0xFF0D47A1)
                            )
                        }
                    }
                }
            }
        } else if (!pedigree.hasPedigreeData) {
            item {
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFF5F5F5))
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Pets, contentDescription = null, tint = Color.Gray)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "${t("pedigree.title")}: ${t("pedigree.not_recorded")}",
                            fontSize = 12.sp,
                            color = Color.DarkGray
                        )
                    }
                }
            }
        } else {
            // Generation 1: Parents
            item {
                Text(
                    text = t("pedigree.generation_1"),
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = FarmGreenDark,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }

            pedigree.sireNode?.let { sire ->
                item {
                    PedigreeNodeCard(
                        node = sire,
                        onOpen = { sire.goat?.let { onOpenGoat(it) } }
                    )
                }
            }

            pedigree.damNode?.let { dam ->
                item {
                    PedigreeNodeCard(
                        node = dam,
                        onOpen = { dam.goat?.let { onOpenGoat(it) } }
                    )
                }
            }

            // Generation 2: Grandparents
            if (pedigree.generation2Grandparents.isNotEmpty()) {
                item {
                    Text(
                        text = t("pedigree.generation_2"),
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = FarmGreenDark,
                        modifier = Modifier.padding(top = 8.dp)
                    )
                }
                items(pedigree.generation2Grandparents.size) { idx ->
                    val gp = pedigree.generation2Grandparents[idx]
                    PedigreeNodeCard(
                        node = gp,
                        onOpen = { gp.goat?.let { onOpenGoat(it) } }
                    )
                }
            }

            // Generation 3: Great-Grandparents
            if (pedigree.generation3GreatGrandparents.isNotEmpty()) {
                item {
                    Text(
                        text = t("pedigree.generation_3"),
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = FarmGreenDark,
                        modifier = Modifier.padding(top = 8.dp)
                    )
                }
                items(pedigree.generation3GreatGrandparents.size) { idx ->
                    val ggp = pedigree.generation3GreatGrandparents[idx]
                    PedigreeNodeCard(
                        node = ggp,
                        onOpen = { ggp.goat?.let { onOpenGoat(it) } }
                    )
                }
            }
        }
    }
}

@Composable
fun PedigreeNodeCard(
    node: PedigreeNode,
    onOpen: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = modifier
            .fillMaxWidth()
            .then(if (node.goat != null) Modifier.clickable { onOpen() } else Modifier)
            .testTag("pedigree_node_${node.tag}")
    ) {
        Row(
            modifier = Modifier
                .padding(10.dp)
                .fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = node.relationship,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = FarmGreenDark
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    OriginBadge(origin = node.origin)
                }
                Text(
                    text = "${node.name} (${node.tag})",
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                )
                if (!node.breed.isNullOrBlank()) {
                    Text(
                        text = "${t("pedigree.breed")}: ${node.breed}",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            if (node.goat != null) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = t("pedigree.open_record"),
                        fontSize = 11.sp,
                        color = FarmGreenPrimary,
                        fontWeight = FontWeight.SemiBold
                    )
                    Icon(
                        imageVector = Icons.Default.ChevronRight,
                        contentDescription = t("pedigree.open_record"),
                        tint = FarmGreenPrimary,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun PedigreeColumnView(
    goat: Goat,
    allGoats: List<Goat>,
    onOpenGoat: (Goat) -> Unit,
    modifier: Modifier = Modifier
) {
    val pedigree = PedigreeManager.buildPedigree(goat, allGoats)

    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Summary Header Card
        Card(
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFFFAFAFA))
        ) {
            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "${t("pedigree.title")}: ${goat.name} (${goat.tag_c})",
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleSmall,
                        color = FarmGreenDark
                    )
                    OriginBadge(origin = goat.effectiveOrigin)
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Text(
                        text = "${t("pedigree.breed")}: ${goat.breed_c}",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    if (pedigree.isFarmBorn) {
                        Text(
                            text = "${t("pedigree.sire")}: ${pedigree.sireNode?.tag ?: goat.sire_c ?: "Unknown"}",
                            fontSize = 12.sp
                        )
                        Text(
                            text = "${t("pedigree.dam")}: ${pedigree.damNode?.tag ?: goat.dam_c ?: "Unknown"}",
                            fontSize = 12.sp
                        )
                    }
                }
            }
        }

        // Market-bought Notice
        if (pedigree.isMarketBought && !pedigree.hasPedigreeData) {
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFE3F2FD))
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Info, contentDescription = null, tint = Color(0xFF0D47A1))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = t("pedigree.market_bought"),
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF0D47A1)
                            )
                        }
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = Color(0xFFBBDEFB)
                        ) {
                            Text(
                                text = t("pedigree.status_unknown"),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF0D47A1),
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                            )
                        }
                    }

                    HorizontalDivider(color = Color(0xFFBBDEFB))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "${t("pedigree.sire")}: ${t("pedigree.status_unknown")}",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color(0xFF1565C0)
                        )
                        Text(
                            text = "${t("pedigree.dam")}: ${t("pedigree.status_unknown")}",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color(0xFF1565C0)
                        )
                    }

                    Text(
                        text = "Pedigree Status: ${t("pedigree.not_recorded")}",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium,
                        color = Color(0xFF1565C0)
                    )

                    Text(
                        text = t("pedigree.market_bought_notice"),
                        fontSize = 12.sp,
                        color = Color(0xFF1565C0)
                    )
                    if (!goat.purchase_date_c.isNullOrBlank() || goat.purchase_cost_c != null) {
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "Purchase Details: Date: ${goat.purchase_date_c ?: "--"} • Cost: ₹${goat.purchase_cost_c ?: "--"}",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color(0xFF0D47A1)
                        )
                    }
                }
            }
        } else if (!pedigree.hasPedigreeData) {
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFF5F5F5))
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Pets, contentDescription = null, tint = Color.Gray)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "${t("pedigree.title")}: ${t("pedigree.not_recorded")}",
                        fontSize = 12.sp,
                        color = Color.DarkGray
                    )
                }
            }
        } else {
            // Generation 1: Parents
            Text(
                text = t("pedigree.generation_1"),
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
                color = FarmGreenDark,
                modifier = Modifier.padding(top = 4.dp)
            )

            pedigree.sireNode?.let { sire ->
                PedigreeNodeCard(
                    node = sire,
                    onOpen = { sire.goat?.let { onOpenGoat(it) } }
                )
            }

            pedigree.damNode?.let { dam ->
                PedigreeNodeCard(
                    node = dam,
                    onOpen = { dam.goat?.let { onOpenGoat(it) } }
                )
            }

            // Generation 2: Grandparents
            if (pedigree.generation2Grandparents.isNotEmpty()) {
                Text(
                    text = t("pedigree.generation_2"),
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = FarmGreenDark,
                    modifier = Modifier.padding(top = 8.dp)
                )
                pedigree.generation2Grandparents.forEach { gp ->
                    PedigreeNodeCard(
                        node = gp,
                        onOpen = { gp.goat?.let { onOpenGoat(it) } }
                    )
                }
            }

            // Generation 3: Great-Grandparents
            if (pedigree.generation3GreatGrandparents.isNotEmpty()) {
                Text(
                    text = t("pedigree.generation_3"),
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = FarmGreenDark,
                    modifier = Modifier.padding(top = 8.dp)
                )
                pedigree.generation3GreatGrandparents.forEach { ggp ->
                    PedigreeNodeCard(
                        node = ggp,
                        onOpen = { ggp.goat?.let { onOpenGoat(it) } }
                    )
                }
            }
        }
    }
}
