package com.example.ui.screens.breeding

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.data.supabase.Goat
import com.example.data.supabase.GoatRepository
import com.example.data.supabase.MatingRecord
import com.example.data.supabase.PregnancyRecord
import com.example.notification.KiddingReminderScheduler
import com.example.ui.components.DatePickerField
import com.example.ui.components.GoatSelector
import com.example.ui.theme.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.TimeUnit

private val FarmPurple = Color(0xFF7B1FA2)

enum class GestationTrimester(val label: String, val dayRange: String, val color: Color) {
    FIRST("1st Trimester", "Days 1–50", Color(0xFF0284C7)),
    SECOND("2nd Trimester", "Days 51–100", Color(0xFF16A34A)),
    THIRD("3rd / Late Trimester", "Days 101–150", Color(0xFFD97706)),
    OVERDUE("Overdue", "> 150 Days", Color(0xFFDC2626))
}

enum class KiddingAlertUrgency {
    CRITICAL_OVERDUE,
    IMMINENT,        // 0-3 days
    DUE_THIS_WEEK,   // 4-7 days
    CARE_MILESTONE,  // CD&T, feed change, ultrasound
    NORMAL
}

data class KiddingAlertItem(
    val id: String,
    val pregnancyId: String,
    val doeId: String,
    val doeTag: String,
    val doeName: String,
    val breed: String,
    val expectedKiddingDate: String,
    val currentGestationDay: Int,
    val totalGestationDays: Int = 150,
    val daysRemaining: Int,
    val urgency: KiddingAlertUrgency,
    val title: String,
    val description: String,
    val actionLabel: String,
    val milestoneType: String
)

data class DoeGestationTrackerItem(
    val pregnancy: PregnancyRecord,
    val doe: Goat?,
    val sire: Goat?,
    val matingRecord: MatingRecord?,
    val serviceDateStr: String,
    val expectedKiddingDateStr: String,
    val currentGestationDay: Int,
    val totalGestationDays: Int,
    val progressPct: Float,
    val daysRemaining: Int,
    val trimester: GestationTrimester,
    val isOverdue: Boolean,
    val alerts: List<KiddingAlertItem>
)

@Composable
fun GestationTrackingAndKiddingAlertsView(
    repository: GoatRepository,
    goats: List<Goat>,
    pregnancies: List<PregnancyRecord>,
    matings: List<MatingRecord>,
    today: String,
    dateFormat: SimpleDateFormat,
    onNavigateToKiddingWithDoe: (doeId: String) -> Unit,
    onPregnancyUpdated: () -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    var deviceAlertsEnabled by remember { mutableStateOf(KiddingReminderScheduler.areAlertsEnabled(context)) }
    var showNotificationGuideDialog by remember { mutableStateOf(false) }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            deviceAlertsEnabled = true
            KiddingReminderScheduler.setAlertsEnabled(context, true)
            Toast.makeText(context, "Local device kidding alerts enabled!", Toast.LENGTH_SHORT).show()
        } else {
            deviceAlertsEnabled = false
            Toast.makeText(context, "Notification permission required for alerts", Toast.LENGTH_SHORT).show()
        }
    }

    var selectedFilter by remember { mutableStateOf("ALL") } // ALL, IMMINENT, DUE_WEEK, MILESTONES, 3RD_TRIMESTER
    var showCalculatorDialog by remember { mutableStateOf(false) }
    var showKiddingChecklistDialog by remember { mutableStateOf(false) }
    var selectedTrackerForDetails by remember { mutableStateOf<DoeGestationTrackerItem?>(null) }
    var pregnancyToUpdateNotes by remember { mutableStateOf<PregnancyRecord?>(null) }
    var editedNotesText by remember { mutableStateOf("") }
    var isUpdatingNotes by remember { mutableStateOf(false) }

    // Parse today
    val todayDate = remember(today) {
        try { dateFormat.parse(today) ?: Date() } catch (_: Exception) { Date() }
    }

    // Build Gestation Tracker Items & Alerts Engine
    val gestationItems: List<DoeGestationTrackerItem> = remember(pregnancies, goats, matings, today) {
        val goatMap = goats.associateBy { it.id }
        val matingMap = matings.associateBy { it.id }

        pregnancies
            .filter { it.status_c.equals("Confirmed", ignoreCase = true) || it.status_c.equals("Suspected", ignoreCase = true) }
            .map { preg ->
                val doe = goatMap[preg.doe_id_c]
                val mating = preg.mating_record_id_c?.let { matingMap[it] }
                val sire = mating?.buck_id_c?.let { goatMap[it] }

                // Resolve service/mating date
                val expectedCal = Calendar.getInstance()
                val hasExpected = !preg.expected_kidding_date_c.isNullOrBlank()
                val expectedDate = if (hasExpected) {
                    try { dateFormat.parse(preg.expected_kidding_date_c) ?: Date() } catch (_: Exception) { Date() }
                } else {
                    val conf = try { dateFormat.parse(preg.confirmation_date_c) ?: Date() } catch (_: Exception) { Date() }
                    Calendar.getInstance().apply {
                        time = conf
                        add(Calendar.DAY_OF_YEAR, 150)
                    }.time
                }

                val totalGestationDays = when (doe?.breed_c?.lowercase() ?: "") {
                    "nigerian dwarf", "pygmy" -> 145
                    "nubian" -> 151
                    "boer" -> 149
                    else -> 150
                }

                val serviceDate: Date = when {
                    mating != null && !mating.mating_date_c.isNullOrBlank() -> {
                        try { dateFormat.parse(mating.mating_date_c) ?: Date() } catch (_: Exception) { Date() }
                    }
                    hasExpected -> {
                        Calendar.getInstance().apply {
                            time = expectedDate
                            add(Calendar.DAY_OF_YEAR, -totalGestationDays)
                        }.time
                    }
                    else -> {
                        try { dateFormat.parse(preg.confirmation_date_c) ?: Date() } catch (_: Exception) { Date() }
                    }
                }

                val diffMillis = todayDate.time - serviceDate.time
                val daysPassed = TimeUnit.MILLISECONDS.toDays(diffMillis).toInt().coerceAtLeast(1)
                val currentDay = daysPassed.coerceAtMost(165)
                val daysRemaining = TimeUnit.MILLISECONDS.toDays(expectedDate.time - todayDate.time).toInt()
                val isOverdue = daysRemaining < 0
                val progress = (currentDay.toFloat() / totalGestationDays.toFloat()).coerceIn(0f, 1f)

                val trimester = when {
                    currentDay > totalGestationDays -> GestationTrimester.OVERDUE
                    currentDay >= 101 -> GestationTrimester.THIRD
                    currentDay >= 51 -> GestationTrimester.SECOND
                    else -> GestationTrimester.FIRST
                }

                // Compile Alerts for this Doe
                val alerts = mutableListOf<KiddingAlertItem>()
                val doeTag = doe?.tag_c ?: "Doe"
                val doeName = doe?.name ?: "Unknown Doe"
                val breed = doe?.breed_c ?: "Boer"
                val expStr = dateFormat.format(expectedDate)

                if (isOverdue) {
                    val overDays = -daysRemaining
                    alerts.add(
                        KiddingAlertItem(
                            id = "${preg.id}_overdue",
                            pregnancyId = preg.id,
                            doeId = preg.doe_id_c,
                            doeTag = doeTag,
                            doeName = doeName,
                            breed = breed,
                            expectedKiddingDate = expStr,
                            currentGestationDay = currentDay,
                            totalGestationDays = totalGestationDays,
                            daysRemaining = daysRemaining,
                            urgency = KiddingAlertUrgency.CRITICAL_OVERDUE,
                            title = "🚨 OVERDUE KIDDING: Doe #${doeTag} is $overDays days overdue!",
                            description = "Gestation day $currentDay (Standard: $totalGestationDays days). Check for uterine inertia, fetal distress, or abnormal labor straining. Contact veterinary care if labor does not advance.",
                            actionLabel = "Log Delivery / Vet Exam",
                            milestoneType = "OVERDUE"
                        )
                    )
                } else if (daysRemaining in 0..3) {
                    val dayText = if (daysRemaining == 0) "TODAY" else "in $daysRemaining days"
                    alerts.add(
                        KiddingAlertItem(
                            id = "${preg.id}_imminent",
                            pregnancyId = preg.id,
                            doeId = preg.doe_id_c,
                            doeTag = doeTag,
                            doeName = doeName,
                            breed = breed,
                            expectedKiddingDate = expStr,
                            currentGestationDay = currentDay,
                            totalGestationDays = totalGestationDays,
                            daysRemaining = daysRemaining,
                            urgency = KiddingAlertUrgency.IMMINENT,
                            title = "⚠️ IMMINENT KIDDING: Doe #${doeTag} due $dayText (Day $currentDay/$totalGestationDays)",
                            description = "Look for loosened pelvic tailhead ligaments, engorged shiny udder, restlessness, pawing, nesting, and clear discharge. Keep fresh towels & iodine dip ready.",
                            actionLabel = "Ready Kidding Pen",
                            milestoneType = "IMMINENT_KIDDING"
                        )
                    )
                } else if (daysRemaining in 4..7) {
                    alerts.add(
                        KiddingAlertItem(
                            id = "${preg.id}_due_week",
                            pregnancyId = preg.id,
                            doeId = preg.doe_id_c,
                            doeTag = doeTag,
                            doeName = doeName,
                            breed = breed,
                            expectedKiddingDate = expStr,
                            currentGestationDay = currentDay,
                            totalGestationDays = totalGestationDays,
                            daysRemaining = daysRemaining,
                            urgency = KiddingAlertUrgency.DUE_THIS_WEEK,
                            title = "🔔 Due Within 7 Days: Separate Doe #${doeTag} to Maternity Stall",
                            description = "Due in $daysRemaining days (Day $currentDay/$totalGestationDays). Transition doe to a clean, well-bedded pen. Check heat lamps if nighttime temperatures drop.",
                            actionLabel = "Check Kidding Kit",
                            milestoneType = "MOVE_TO_PEN"
                        )
                    )
                }

                // Health & Vaccine Milestones
                if (currentDay in 118..126) {
                    alerts.add(
                        KiddingAlertItem(
                            id = "${preg.id}_cdt",
                            pregnancyId = preg.id,
                            doeId = preg.doe_id_c,
                            doeTag = doeTag,
                            doeName = doeName,
                            breed = breed,
                            expectedKiddingDate = expStr,
                            currentGestationDay = currentDay,
                            totalGestationDays = totalGestationDays,
                            daysRemaining = daysRemaining,
                            urgency = KiddingAlertUrgency.CARE_MILESTONE,
                            title = "💉 CD&T Vaccine Booster Alert (4 Weeks Pre-Kidding)",
                            description = "Day $currentDay/$totalGestationDays. Administer 2ml CD&T subcutaneously so high levels of protective antibodies pass through colostrum to newborns.",
                            actionLabel = "Mark Vaccinated",
                            milestoneType = "CDT_BOOSTER"
                        )
                    )
                } else if (currentDay in 98..105) {
                    alerts.add(
                        KiddingAlertItem(
                            id = "${preg.id}_nutrition",
                            pregnancyId = preg.id,
                            doeId = preg.doe_id_c,
                            doeTag = doeTag,
                            doeName = doeName,
                            breed = breed,
                            expectedKiddingDate = expStr,
                            currentGestationDay = currentDay,
                            totalGestationDays = totalGestationDays,
                            daysRemaining = daysRemaining,
                            urgency = KiddingAlertUrgency.CARE_MILESTONE,
                            title = "🌾 Late Gestation Nutrition Ramp-Up",
                            description = "Entering 3rd trimester (70% fetal growth phase). Increase protein and energy density (alfalfa/grain) to protect doe against pregnancy toxemia/ketosis.",
                            actionLabel = "Adjust Feed Ration",
                            milestoneType = "NUTRITION_RAMP"
                        )
                    )
                }

                DoeGestationTrackerItem(
                    pregnancy = preg,
                    doe = doe,
                    sire = sire,
                    matingRecord = mating,
                    serviceDateStr = dateFormat.format(serviceDate),
                    expectedKiddingDateStr = expStr,
                    currentGestationDay = currentDay,
                    totalGestationDays = totalGestationDays,
                    progressPct = progress,
                    daysRemaining = daysRemaining,
                    trimester = trimester,
                    isOverdue = isOverdue,
                    alerts = alerts
                )
            }
            .sortedBy { it.daysRemaining }
    }

    // Consolidated Kidding Alerts list
    val allKiddingAlerts = remember(gestationItems) {
        gestationItems.flatMap { it.alerts }
            .sortedBy {
                when (it.urgency) {
                    KiddingAlertUrgency.CRITICAL_OVERDUE -> 0
                    KiddingAlertUrgency.IMMINENT -> 1
                    KiddingAlertUrgency.DUE_THIS_WEEK -> 2
                    KiddingAlertUrgency.CARE_MILESTONE -> 3
                    KiddingAlertUrgency.NORMAL -> 4
                }
            }
    }

    // Filtered Tracker List
    val filteredTrackers = remember(gestationItems, selectedFilter) {
        when (selectedFilter) {
            "OVERDUE" -> gestationItems.filter { it.isOverdue }
            "IMMINENT" -> gestationItems.filter { it.daysRemaining in 0..3 }
            "DUE_WEEK" -> gestationItems.filter { it.daysRemaining in 0..7 }
            "MILESTONES" -> gestationItems.filter { it.alerts.any { a -> a.urgency == KiddingAlertUrgency.CARE_MILESTONE } }
            "3RD_TRIMESTER" -> gestationItems.filter { it.trimester == GestationTrimester.THIRD || it.isOverdue }
            else -> gestationItems
        }
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("gestation_tracking_root"),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Top Header Banner with Action Buttons
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
            elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = Color(0xFF7B1FA2).copy(alpha = 0.25f),
                            modifier = Modifier.size(42.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    Icons.Default.DateRange,
                                    contentDescription = null,
                                    tint = Color(0xFFCE93D8),
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                        }
                        Column {
                            Text(
                                text = "Gestation Tracker & Kidding Alerts",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Text(
                                text = "Caprine 150-day gestation timeline & clinical monitoring",
                                fontSize = 11.sp,
                                color = Color(0xFF94A3B8)
                            )
                        }
                    }

                    // Action buttons: Calculator & Checklist
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        IconButton(
                            onClick = { showCalculatorDialog = true },
                            modifier = Modifier
                                .background(Color.White.copy(alpha = 0.12f), CircleShape)
                                .size(36.dp)
                                .testTag("btn_gestation_calculator")
                        ) {
                            Icon(Icons.Default.Calculate, contentDescription = "Gestation Calculator", tint = Color.White, modifier = Modifier.size(18.dp))
                        }
                        IconButton(
                            onClick = { showKiddingChecklistDialog = true },
                            modifier = Modifier
                                .background(Color.White.copy(alpha = 0.12f), CircleShape)
                                .size(36.dp)
                                .testTag("btn_kidding_checklist")
                        ) {
                            Icon(Icons.Default.MedicalServices, contentDescription = "Kidding Kit Checklist", tint = Color(0xFF34D399), modifier = Modifier.size(18.dp))
                        }
                    }
                }

                // Summary Chips: Active Pregnancies, Due This Week, Overdue, Milestones
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    val overdueCount = gestationItems.count { it.isOverdue }
                    val imminentCount = gestationItems.count { it.daysRemaining in 0..3 }
                    val dueWeekCount = gestationItems.count { it.daysRemaining in 0..7 }

                    Surface(
                        modifier = Modifier.weight(1f),
                        color = Color(0xFF334155),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(8.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text("${gestationItems.size}", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Color.White)
                            Text("Pregnant", fontSize = 10.sp, color = Color(0xFF94A3B8))
                        }
                    }

                    Surface(
                        modifier = Modifier.weight(1f),
                        color = if (dueWeekCount > 0) Color(0xFFF59E0B).copy(alpha = 0.2f) else Color(0xFF334155),
                        border = if (dueWeekCount > 0) BorderStroke(1.dp, Color(0xFFF59E0B)) else null,
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(8.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text("$dueWeekCount", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = if (dueWeekCount > 0) Color(0xFFF59E0B) else Color.White)
                            Text("Due ≤7d", fontSize = 10.sp, color = Color(0xFFCBD5E1))
                        }
                    }

                    Surface(
                        modifier = Modifier.weight(1f),
                        color = if (imminentCount > 0) Color(0xFFF97316).copy(alpha = 0.2f) else Color(0xFF334155),
                        border = if (imminentCount > 0) BorderStroke(1.dp, Color(0xFFF97316)) else null,
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(8.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text("$imminentCount", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = if (imminentCount > 0) Color(0xFFF97316) else Color.White)
                            Text("Imminent", fontSize = 10.sp, color = Color(0xFFCBD5E1))
                        }
                    }

                    Surface(
                        modifier = Modifier.weight(1f),
                        color = if (overdueCount > 0) Color(0xFFEF4444).copy(alpha = 0.25f) else Color(0xFF334155),
                        border = if (overdueCount > 0) BorderStroke(1.dp, Color(0xFFEF4444)) else null,
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(8.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text("$overdueCount", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = if (overdueCount > 0) Color(0xFFEF4444) else Color.White)
                            Text("Overdue", fontSize = 10.sp, color = if (overdueCount > 0) Color(0xFFFCA5A5) else Color(0xFFCBD5E1))
                        }
                    }
                }
            }
        }

        // Local Device Alerts & Notifications Module Card
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            border = BorderStroke(1.dp, if (deviceAlertsEnabled) Color(0xFFCE93D8) else Color(0xFFE2E8F0)),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("card_device_kidding_alerts")
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = if (deviceAlertsEnabled) FarmPurple.copy(alpha = 0.12f) else Color.LightGray.copy(alpha = 0.3f),
                            modifier = Modifier.size(38.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = if (deviceAlertsEnabled) Icons.Default.NotificationsActive else Icons.Default.NotificationsOff,
                                    contentDescription = null,
                                    tint = if (deviceAlertsEnabled) FarmPurple else Color.Gray,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text(
                                    text = "Device Kidding Alerts",
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF1E293B)
                                )
                                Surface(
                                    color = if (deviceAlertsEnabled) Color(0xFFDCFCE7) else Color(0xFFF1F5F9),
                                    shape = RoundedCornerShape(6.dp)
                                ) {
                                    Text(
                                        text = if (deviceAlertsEnabled) "ACTIVE" else "DISABLED",
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (deviceAlertsEnabled) Color(0xFF15803D) else Color.Gray,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                            Text(
                                text = "Local device notifications for 150d expected kidding dates",
                                fontSize = 11.sp,
                                color = Color.Gray
                            )
                        }
                    }

                    Switch(
                        checked = deviceAlertsEnabled,
                        onCheckedChange = { isChecked ->
                            if (isChecked) {
                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
                                    ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
                                ) {
                                    permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                                } else {
                                    deviceAlertsEnabled = true
                                    KiddingReminderScheduler.setAlertsEnabled(context, true)
                                    Toast.makeText(context, "Local device kidding alerts active!", Toast.LENGTH_SHORT).show()
                                }
                            } else {
                                deviceAlertsEnabled = false
                                KiddingReminderScheduler.setAlertsEnabled(context, false)
                                Toast.makeText(context, "Kidding notifications paused", Toast.LENGTH_SHORT).show()
                            }
                        },
                        modifier = Modifier.testTag("switch_device_kidding_alerts")
                    )
                }

                // Alert Triggers Chips
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    listOf(
                        "🚨 Overdue Warning",
                        "🐐 Due Today Alert",
                        "⚠️ 24h Prior Notice",
                        "🔔 3-Day Check",
                        "📅 7-Day Isolation",
                        "💉 Day 120 CD&T Booster"
                    ).forEach { chipLabel ->
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = Color(0xFFF8FAFC),
                            border = BorderStroke(0.5.dp, Color(0xFFCBD5E1))
                        ) {
                            Text(
                                text = chipLabel,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = Color(0xFF475569),
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }
                }

                // Actions row: Send Test Alert & Scan Now & Schedule Guide
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedButton(
                        onClick = {
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
                                ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
                            ) {
                                permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                            } else {
                                val firstDoe = gestationItems.firstOrNull()
                                val tag = firstDoe?.doe?.tag_c ?: "DOE-101"
                                val name = firstDoe?.doe?.name ?: "Bella"
                                val expDate = firstDoe?.expectedKiddingDateStr ?: today
                                KiddingReminderScheduler.sendTestNotification(context, tag, name, expDate)
                                Toast.makeText(context, "Test kidding notification sent! Check notification shade.", Toast.LENGTH_SHORT).show()
                            }
                        },
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("btn_test_kidding_alert")
                    ) {
                        Icon(Icons.Default.Notifications, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Test Alert", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }

                    FilledTonalButton(
                        onClick = {
                            KiddingReminderScheduler.triggerImmediateCheck(context)
                            Toast.makeText(context, "Checking kidding dates & dispatching local alerts...", Toast.LENGTH_SHORT).show()
                        },
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("btn_sync_kidding_alerts")
                    ) {
                        Icon(Icons.Default.Sync, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Scan Now", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }

                    IconButton(
                        onClick = { showNotificationGuideDialog = true },
                        modifier = Modifier.size(34.dp)
                    ) {
                        Icon(Icons.Default.Info, contentDescription = "Alert Guide", tint = Color.Gray, modifier = Modifier.size(18.dp))
                    }
                }
            }
        }

        // Active Alerts Banner Section (Shows critical alerts directly)
        if (allKiddingAlerts.isNotEmpty()) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("gestation_alerts_banner"),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = "🚨 UPCOMING KIDDING & CARE ALERTS (${allKiddingAlerts.size})",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF991B1B)
                )

                allKiddingAlerts.take(3).forEach { alert ->
                    val (bgCard, borderCol, iconTint) = when (alert.urgency) {
                        KiddingAlertUrgency.CRITICAL_OVERDUE -> Triple(Color(0xFFFEF2F2), Color(0xFFEF4444), Color(0xFFDC2626))
                        KiddingAlertUrgency.IMMINENT -> Triple(Color(0xFFFFF7ED), Color(0xFFF97316), Color(0xFFEA580C))
                        KiddingAlertUrgency.DUE_THIS_WEEK -> Triple(Color(0xFFFFFBEB), Color(0xFFF59E0B), Color(0xFFD97706))
                        KiddingAlertUrgency.CARE_MILESTONE -> Triple(Color(0xFFF0FDF4), Color(0xFF22C55E), Color(0xFF16A34A))
                        else -> Triple(Color.White, Color(0xFFE2E8F0), Color.DarkGray)
                    }

                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = bgCard),
                        border = BorderStroke(1.dp, borderCol),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(
                                        when (alert.urgency) {
                                            KiddingAlertUrgency.CRITICAL_OVERDUE -> Icons.Default.Warning
                                            KiddingAlertUrgency.IMMINENT -> Icons.Default.ChildCare
                                            KiddingAlertUrgency.DUE_THIS_WEEK -> Icons.Default.NotificationsActive
                                            KiddingAlertUrgency.CARE_MILESTONE -> Icons.Default.Vaccines
                                            else -> Icons.Default.Info
                                        },
                                        contentDescription = null,
                                        tint = iconTint,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Text(
                                        text = alert.title,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp,
                                        color = borderCol
                                    )
                                }

                                Surface(
                                    shape = RoundedCornerShape(4.dp),
                                    color = borderCol.copy(alpha = 0.15f)
                                ) {
                                    Text(
                                        text = if (alert.daysRemaining < 0) "${-alert.daysRemaining}d Overdue" else "${alert.daysRemaining}d left",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 10.sp,
                                        color = borderCol,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }

                            Text(
                                text = alert.description,
                                fontSize = 11.sp,
                                color = Color(0xFF334155),
                                lineHeight = 16.sp
                            )

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.End
                            ) {
                                Button(
                                    onClick = {
                                        onNavigateToKiddingWithDoe(alert.doeId)
                                    },
                                    shape = RoundedCornerShape(8.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = borderCol),
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                    modifier = Modifier.testTag("alert_action_${alert.doeTag}")
                                ) {
                                    Icon(Icons.Default.ChildCare, contentDescription = null, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(alert.actionLabel, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }

        // Filter Chips Row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .testTag("gestation_filter_chips"),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            val filters = listOf(
                "ALL" to "All Pregnant (${gestationItems.size})",
                "DUE_WEEK" to "Due in ≤7d (${gestationItems.count { it.daysRemaining in 0..7 }})",
                "IMMINENT" to "Imminent (${gestationItems.count { it.daysRemaining in 0..3 }})",
                "OVERDUE" to "Overdue (${gestationItems.count { it.isOverdue }})",
                "3RD_TRIMESTER" to "Late Gestation (${gestationItems.count { it.trimester == GestationTrimester.THIRD || it.isOverdue }})",
                "MILESTONES" to "Vaccine/Care Due (${gestationItems.count { it.alerts.any { a -> a.urgency == KiddingAlertUrgency.CARE_MILESTONE } }})"
            )

            filters.forEach { (key, label) ->
                val isSelected = selectedFilter == key
                FilterChip(
                    selected = isSelected,
                    onClick = { selectedFilter = key },
                    label = { Text(label, fontSize = 11.sp, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = FarmPurple,
                        selectedLabelColor = Color.White
                    )
                )
            }
        }

        // Gestation Tracking Cards List
        if (filteredTrackers.isEmpty()) {
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = FarmGreenDark, modifier = Modifier.size(36.dp))
                    Text(
                        text = if (gestationItems.isEmpty()) "No active pregnancies recorded." else "No does matching this filter.",
                        fontWeight = FontWeight.Bold,
                        color = Color.DarkGray
                    )
                    Text(
                        text = "Use 'Record Pregnancy' or the Gestation Calculator to log newly confirmed does.",
                        fontSize = 12.sp,
                        color = Color.Gray
                    )
                }
            }
        } else {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                filteredTrackers.forEach { tracker ->
                    GestationTrackerCard(
                        tracker = tracker,
                        onLogKidding = { onNavigateToKiddingWithDoe(tracker.pregnancy.doe_id_c) },
                        onEditNotes = {
                            pregnancyToUpdateNotes = tracker.pregnancy
                            editedNotesText = tracker.pregnancy.notes_c ?: ""
                        },
                        onViewMilestones = { selectedTrackerForDetails = tracker }
                    )
                }
            }
        }
    }

    // Gestation Calculator Dialog
    if (showCalculatorDialog) {
        GestationCalculatorDialog(
            goats = goats,
            today = today,
            dateFormat = dateFormat,
            onDismiss = { showCalculatorDialog = false },
            onSavePregnancy = { doeId, serviceDate, expectedDate, notes ->
                coroutineScope.launch {
                    val record = PregnancyRecord(
                        doe_id_c = doeId,
                        confirmation_date_c = serviceDate,
                        expected_kidding_date_c = expectedDate,
                        status_c = "Confirmed",
                        notes_c = notes
                    )
                    val res = repository.recordPregnancy(record)
                    showCalculatorDialog = false
                    if (res.isSuccess) {
                        KiddingReminderScheduler.triggerImmediateCheck(context)
                        Toast.makeText(context, "Pregnancy saved! Kidding alert scheduled for $expectedDate", Toast.LENGTH_SHORT).show()
                    }
                    onPregnancyUpdated()
                }
            }
        )
    }

    // Device Kidding Notification Schedule Guide Dialog
    if (showNotificationGuideDialog) {
        KiddingNotificationGuideDialog(
            alertsEnabled = deviceAlertsEnabled,
            onDismiss = { showNotificationGuideDialog = false }
        )
    }

    // Kidding Kit & Labor Checklist Dialog
    if (showKiddingChecklistDialog) {
        KiddingKitChecklistDialog(onDismiss = { showKiddingChecklistDialog = false })
    }

    // Doe Gestation Timeline Milestones Dialog
    selectedTrackerForDetails?.let { tracker ->
        GestationMilestonesDetailDialog(
            tracker = tracker,
            onDismiss = { selectedTrackerForDetails = null },
            onLogKidding = {
                val doeId = tracker.pregnancy.doe_id_c
                selectedTrackerForDetails = null
                onNavigateToKiddingWithDoe(doeId)
            }
        )
    }

    // Edit Notes / Care Plan Dialog
    pregnancyToUpdateNotes?.let { preg ->
        AlertDialog(
            onDismissRequest = { pregnancyToUpdateNotes = null },
            title = { Text("Update Pregnancy Clinical Notes", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Record ultrasound scan findings, vaccination confirmation, or body condition score:", fontSize = 12.sp, color = Color.Gray)
                    OutlinedTextField(
                        value = editedNotesText,
                        onValueChange = { editedNotesText = it },
                        label = { Text("Clinical Notes") },
                        placeholder = { Text("e.g. Ultrasound confirmed twins; CD&T booster given 2026-09-28.") },
                        modifier = Modifier.fillMaxWidth(),
                        maxLines = 4
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        isUpdatingNotes = true
                        coroutineScope.launch {
                            val updated = preg.copy(notes_c = editedNotesText)
                            repository.recordPregnancy(updated)
                            isUpdatingNotes = false
                            pregnancyToUpdateNotes = null
                            onPregnancyUpdated()
                        }
                    },
                    enabled = !isUpdatingNotes,
                    colors = ButtonDefaults.buttonColors(containerColor = FarmGreenPrimary)
                ) {
                    if (isUpdatingNotes) CircularProgressIndicator(color = Color.White, modifier = Modifier.size(16.dp))
                    else Text("Save Notes")
                }
            },
            dismissButton = {
                TextButton(onClick = { pregnancyToUpdateNotes = null }) {
                    Text("Cancel")
                }
            }
        )
    }
}

/**
 * Individual Doe Gestation Progress Card
 */
@Composable
fun GestationTrackerCard(
    tracker: DoeGestationTrackerItem,
    onLogKidding: () -> Unit,
    onEditNotes: () -> Unit,
    onViewMilestones: () -> Unit
) {
    val doe = tracker.doe
    val doeTag = doe?.tag_c ?: "Doe"
    val doeName = doe?.name ?: "Unknown"
    val breed = doe?.breed_c ?: "Caprine"

    val (statusColor, badgeBg, badgeText) = when {
        tracker.isOverdue -> Triple(Color(0xFFDC2626), Color(0xFFFEE2E2), "🚨 ${-tracker.daysRemaining}d Overdue")
        tracker.daysRemaining in 0..3 -> Triple(Color(0xFFEA580C), Color(0xFFFFEDD5), "⚠️ Due in ${tracker.daysRemaining}d")
        tracker.daysRemaining in 4..7 -> Triple(Color(0xFFD97706), Color(0xFFFEF3C7), "🔔 Due in ${tracker.daysRemaining}d")
        else -> Triple(Color(0xFF16A34A), Color(0xFFDCFCE7), "${tracker.daysRemaining}d Remaining")
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("gestation_doe_card_${doeTag}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        border = if (tracker.isOverdue || tracker.daysRemaining in 0..3) BorderStroke(1.5.dp, statusColor) else null
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Header Row: Doe Tag, Name, Status Badge
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Surface(
                        shape = CircleShape,
                        color = tracker.trimester.color.copy(alpha = 0.15f),
                        modifier = Modifier.size(40.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Text(
                                text = "#$doeTag".take(4),
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                color = tracker.trimester.color
                            )
                        }
                    }

                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "Doe #$doeTag • $doeName",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = Color(0xFF1E293B)
                            )
                        }
                        Text(
                            text = "Breed: $breed • Mated: ${tracker.serviceDateStr}",
                            fontSize = 11.sp,
                            color = Color(0xFF64748B)
                        )
                    }
                }

                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = badgeBg
                ) {
                    Text(
                        text = badgeText,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        color = statusColor,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            // Progress Bar & Day Counter
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Gestation: Day ${tracker.currentGestationDay} of ${tracker.totalGestationDays} (${(tracker.progressPct * 100).toInt()}%)",
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        color = Color(0xFF334155)
                    )
                    Text(
                        text = tracker.trimester.label,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 11.sp,
                        color = tracker.trimester.color
                    )
                }

                LinearProgressIndicator(
                    progress = { tracker.progressPct },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(8.dp)
                        .clip(RoundedCornerShape(4.dp)),
                    color = tracker.trimester.color,
                    trackColor = Color(0xFFE2E8F0)
                )
            }

            // Key Dates & Sire Info
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFFF8FAFC), RoundedCornerShape(8.dp))
                    .padding(horizontal = 10.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("Expected Kidding:", fontSize = 10.sp, color = Color.Gray)
                    Text(tracker.expectedKiddingDateStr, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color(0xFF1E293B))
                }

                val sireTag = tracker.sire?.tag_c ?: tracker.matingRecord?.buck_id_c ?: "Natural Sire"
                Column(horizontalAlignment = Alignment.End) {
                    Text("Sire (Buck):", fontSize = 10.sp, color = Color.Gray)
                    Text(sireTag, fontWeight = FontWeight.SemiBold, fontSize = 12.sp, color = Color(0xFF475569))
                }
            }

            // Active Care Milestone Badges (if any)
            if (tracker.alerts.isNotEmpty()) {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    tracker.alerts.forEach { alert ->
                        val alertColor = when (alert.urgency) {
                            KiddingAlertUrgency.CRITICAL_OVERDUE -> Color(0xFFDC2626)
                            KiddingAlertUrgency.IMMINENT -> Color(0xFFEA580C)
                            KiddingAlertUrgency.DUE_THIS_WEEK -> Color(0xFFD97706)
                            else -> Color(0xFF16A34A)
                        }
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = alertColor.copy(alpha = 0.08f),
                            border = BorderStroke(1.dp, alertColor.copy(alpha = 0.3f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(Icons.Default.Info, contentDescription = null, tint = alertColor, modifier = Modifier.size(14.dp))
                                Text(
                                    text = alert.title,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = alertColor
                                )
                            }
                        }
                    }
                }
            }

            // Clinical Notes (if recorded)
            if (!tracker.pregnancy.notes_c.isNullOrBlank()) {
                Text(
                    text = "Notes: ${tracker.pregnancy.notes_c}",
                    fontSize = 11.sp,
                    color = Color(0xFF64748B),
                    maxLines = 2
                )
            }

            // Action Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = onViewMilestones,
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(vertical = 6.dp)
                ) {
                    Icon(Icons.Default.Timeline, contentDescription = null, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Timeline", fontSize = 11.sp)
                }

                OutlinedButton(
                    onClick = onEditNotes,
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(vertical = 6.dp)
                ) {
                    Icon(Icons.Default.EditNote, contentDescription = null, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Notes", fontSize = 11.sp)
                }

                Button(
                    onClick = onLogKidding,
                    modifier = Modifier
                        .weight(1.3f)
                        .testTag("btn_log_kidding_${doeTag}"),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = FarmPurple),
                    contentPadding = PaddingValues(vertical = 6.dp)
                ) {
                    Icon(Icons.Default.ChildCare, contentDescription = null, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Log Kidding", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

/**
 * Gestation Milestones Timeline Detail Dialog
 */
@Composable
fun GestationMilestonesDetailDialog(
    tracker: DoeGestationTrackerItem,
    onDismiss: () -> Unit,
    onLogKidding: () -> Unit
) {
    val doe = tracker.doe
    val doeTag = doe?.tag_c ?: "Doe"
    val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.US)
    val displayFormat = SimpleDateFormat("dd MMM yyyy", Locale.US)

    // Calculate milestone dates from serviceDate
    val serviceDate = try { dateFormat.parse(tracker.serviceDateStr) ?: Date() } catch (_: Exception) { Date() }

    fun addDays(days: Int): String {
        val cal = Calendar.getInstance().apply {
            time = serviceDate
            add(Calendar.DAY_OF_YEAR, days)
        }
        return displayFormat.format(cal.time)
    }

    val milestones = listOf(
        Triple("Day 0: Service / Conception", addDays(0), "Mating observed or artificial insemination logged."),
        Triple("Day 30–45: Ultrasound Viability Window", "${addDays(30)} to ${addDays(45)}", "Veterinary transabdominal ultrasound to confirm pregnancy & count fetuses."),
        Triple("Day 60: Blood PSPB Pregnancy Test", addDays(60), "Pregnancy-Specific Protein B blood serum test window."),
        Triple("Day 90: Abdominal Palpation / Bounce", addDays(90), "Fetal skeletal formation complete; gentle right abdominal palpation to feel kid movement."),
        Triple("Day 100: Late Gestation Feed Ramp-Up", addDays(100), "Transition to higher energy/protein ration & alfalfa to protect against pregnancy toxemia."),
        Triple("Day 120: CD&T Pre-Kidding Booster", addDays(120), "Crucial vaccination so maternal antibodies transfer into colostrum."),
        Triple("Day 143: Separate to Maternity Stall", addDays(143), "Clean, dry, bedded stall isolation. Check kidding kit supplies."),
        Triple("Day 150: Peak Kidding Due Date", addDays(tracker.totalGestationDays), "Expected natural delivery date (Normal range: 145–155 days).")
    )

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(Icons.Default.Timeline, contentDescription = null, tint = FarmPurple)
                Text("Gestation Timeline • Doe #$doeTag", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 420.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "Current Status: Day ${tracker.currentGestationDay} of ${tracker.totalGestationDays} • ${tracker.trimester.label}",
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    color = tracker.trimester.color
                )

                milestones.forEachIndexed { index, (title, dateStr, notes) ->
                    val isPast = when (index) {
                        0 -> tracker.currentGestationDay >= 0
                        1 -> tracker.currentGestationDay >= 45
                        2 -> tracker.currentGestationDay >= 60
                        3 -> tracker.currentGestationDay >= 90
                        4 -> tracker.currentGestationDay >= 100
                        5 -> tracker.currentGestationDay >= 120
                        6 -> tracker.currentGestationDay >= 143
                        7 -> tracker.currentGestationDay >= tracker.totalGestationDays
                        else -> false
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = if (isPast) FarmGreenPrimary else Color(0xFFCBD5E1),
                            modifier = Modifier.size(20.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                if (isPast) {
                                    Icon(Icons.Default.Check, contentDescription = null, tint = Color.White, modifier = Modifier.size(12.dp))
                                } else {
                                    Text("${index + 1}", fontSize = 10.sp, color = Color.White, fontWeight = FontWeight.Bold)
                                }
                            }
                        }

                        Column(modifier = Modifier.weight(1f)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(title, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = if (isPast) Color(0xFF1E293B) else Color(0xFF64748B))
                                Text(dateStr, fontSize = 10.sp, color = Color(0xFF64748B), fontWeight = FontWeight.SemiBold)
                            }
                            Text(notes, fontSize = 11.sp, color = Color(0xFF475569))
                        }
                    }
                    if (index < milestones.size - 1) {
                        Divider(color = Color(0xFFF1F5F9), modifier = Modifier.padding(start = 30.dp))
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onLogKidding,
                colors = ButtonDefaults.buttonColors(containerColor = FarmPurple)
            ) {
                Icon(Icons.Default.ChildCare, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Log Delivery Now")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Close")
            }
        }
    )
}

/**
 * Gestation Calculator & Milestone Simulator
 */
@Composable
fun GestationCalculatorDialog(
    goats: List<Goat>,
    today: String,
    dateFormat: SimpleDateFormat,
    onDismiss: () -> Unit,
    onSavePregnancy: (doeId: String, serviceDate: String, expectedDate: String, notes: String) -> Unit
) {
    val does = remember(goats) { goats.filter { it.sex_c.equals("Doe", ignoreCase = true) || it.sex_c.equals("Female", ignoreCase = true) } }
    var selectedDoeId by remember { mutableStateOf(does.firstOrNull()?.id ?: "") }
    var serviceDate by remember { mutableStateOf(today) }
    var selectedBreedType by remember { mutableStateOf("Standard (150 Days)") }
    var customDays by remember { mutableStateOf("150") }

    val totalDays = when (selectedBreedType) {
        "Miniature / Nigerian Dwarf (145 Days)" -> 145
        "Boer Meat Goat (149 Days)" -> 149
        "Nubian Dairy (151 Days)" -> 151
        "Custom Days" -> customDays.toIntOrNull() ?: 150
        else -> 150
    }

    val expectedKiddingDate = remember(serviceDate, totalDays) {
        try {
            val parsed = dateFormat.parse(serviceDate) ?: Date()
            val cal = Calendar.getInstance().apply {
                time = parsed
                add(Calendar.DAY_OF_YEAR, totalDays)
            }
            dateFormat.format(cal.time)
        } catch (_: Exception) {
            today
        }
    }

    val displayFormat = SimpleDateFormat("dd MMM yyyy", Locale.US)
    fun addDaysFromService(days: Int): String {
        return try {
            val parsed = dateFormat.parse(serviceDate) ?: Date()
            val cal = Calendar.getInstance().apply {
                time = parsed
                add(Calendar.DAY_OF_YEAR, days)
            }
            displayFormat.format(cal.time)
        } catch (_: Exception) { "" }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(Icons.Default.Calculate, contentDescription = null, tint = FarmGreenDark)
                Text("Caprine Gestation Calculator", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "Calculate expected delivery date & schedule all key clinical milestones for a bred doe.",
                    fontSize = 12.sp,
                    color = Color.Gray
                )

                if (does.isNotEmpty()) {
                    GoatSelector(
                        goats = does,
                        selectedGoatId = selectedDoeId,
                        onGoatSelected = { selectedDoeId = it.id },
                        label = "Select Bred Doe"
                    )
                }

                DatePickerField(
                    dateValue = serviceDate,
                    onDateSelected = { serviceDate = it },
                    label = "Service / Mating Date"
                )

                Text("Breed / Gestation Duration:", fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                val breedOptions = listOf(
                    "Standard (150 Days)",
                    "Boer Meat Goat (149 Days)",
                    "Miniature / Nigerian Dwarf (145 Days)",
                    "Nubian Dairy (151 Days)"
                )
                breedOptions.forEach { opt ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { selectedBreedType = opt }
                            .padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(
                            selected = selectedBreedType == opt,
                            onClick = { selectedBreedType = opt }
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(opt, fontSize = 12.sp)
                    }
                }

                // Calculated Results Card
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFF0FDF4)),
                    border = BorderStroke(1.dp, FarmGreenPrimary)
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text("CALCULATED KIDDING TIMELINE", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = FarmGreenDark)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Expected Kidding Date:", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                            Text(expectedKiddingDate, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = FarmPurple)
                        }
                        Text("• Day 30 Ultrasound: ${addDaysFromService(30)}", fontSize = 11.sp, color = Color(0xFF334155))
                        Text("• Day 100 Late Feed Ramp: ${addDaysFromService(100)}", fontSize = 11.sp, color = Color(0xFF334155))
                        Text("• Day 120 CD&T Booster: ${addDaysFromService(120)}", fontSize = 11.sp, color = Color(0xFF334155))
                        Text("• Day 143 Move to Maternity Stall: ${addDaysFromService(143)}", fontSize = 11.sp, color = Color(0xFF334155))
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onSavePregnancy(
                        selectedDoeId,
                        serviceDate,
                        expectedKiddingDate,
                        "Calculated via Gestation Tool ($selectedBreedType)"
                    )
                },
                colors = ButtonDefaults.buttonColors(containerColor = FarmGreenPrimary),
                enabled = selectedDoeId.isNotBlank()
            ) {
                Text("Save to Gestation Tracker")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Close")
            }
        }
    )
}

/**
 * Kidding Kit & Labor Signs Checklist Dialog
 */
@Composable
fun KiddingKitChecklistDialog(onDismiss: () -> Unit) {
    val checklistItems = listOf(
        "7% Tincture of Iodine (or Chlorhexidine) for newborn navel cord dip",
        "Clean, soft dry terrycloth towels for drying newborn kids",
        "Bulb syringe (aspirator) to clear kid nasal and oral passages",
        "Non-spermicidal obstetrical lubricant & sterile arm-length gloves",
        "Supplemental frozen or powdered maternal goat colostrum & 60ml syringe with feeding tube",
        "Digital hanging scale and weighing sling for newborn birth weights",
        "Clean dental floss or alcohol-sterilized scissors for umbilical cords",
        "Digital rectal thermometer (Normal doe temperature: 101.5°F–103.5°F / 38.6°C–39.7°C)",
        "Fresh clean dry wheat straw bedding in sanitized maternity stall",
        "Electrolyte drench and warm molasses water for newly kidded doe"
    )

    val laborSigns = listOf(
        "Stage 1: Restlessness, pawing bedding, tail flagging, vocalizing, loss of tailhead ligaments (lasts 2–12 hrs)",
        "Stage 2: Active contractions, presentation of water bag, appearance of front hooves with nose resting on them (<30 mins)",
        "Stage 3: Placenta expulsion (should complete within 4 hours; do NOT manually pull retained placenta!)"
    )

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(Icons.Default.MedicalServices, contentDescription = null, tint = Color(0xFF0D9488))
                Text("Kidding Kit & Labor Checklist", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 420.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text("LABOR SIGNS & TIMING", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = FarmPurple)
                laborSigns.forEach { sign ->
                    Surface(
                        color = Color(0xFFFAF5FF),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = sign,
                            fontSize = 11.sp,
                            color = Color(0xFF581C87),
                            modifier = Modifier.padding(8.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))
                Text("ESSENTIAL KIDDING KIT CHECKLIST", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = FarmGreenDark)
                checklistItems.forEach { item ->
                    Row(
                        verticalAlignment = Alignment.Top,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color(0xFF10B981), modifier = Modifier.size(16.dp))
                        Text(item, fontSize = 11.sp, color = Color(0xFF334155))
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Close")
            }
        }
    )
}

@Composable
fun KiddingNotificationGuideDialog(
    alertsEnabled: Boolean,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(Icons.Default.NotificationsActive, contentDescription = null, tint = FarmPurple)
                Text("Device Kidding Alerts Guide", fontSize = 16.sp, fontWeight = FontWeight.Bold)
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 440.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Surface(
                    color = if (alertsEnabled) Color(0xFFDCFCE7) else Color(0xFFFEF2F2),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            if (alertsEnabled) Icons.Default.CheckCircle else Icons.Default.Warning,
                            contentDescription = null,
                            tint = if (alertsEnabled) Color(0xFF16A34A) else Color(0xFFDC2626),
                            modifier = Modifier.size(18.dp)
                        )
                        Text(
                            text = if (alertsEnabled) "Local device alerts are ACTIVE and running in background." else "Device notifications are currently DISABLED.",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = if (alertsEnabled) Color(0xFF166534) else Color(0xFF991B1B)
                        )
                    }
                }

                Text(
                    text = "HOW EXPECTED KIDDING IS CALCULATED",
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    color = FarmPurple
                )
                Text(
                    text = "The breeding management engine computes expected kidding dates using caprine biological gestation averages:\n" +
                            "• Standard Goat Average: 150 Days\n" +
                            "• Nigerian Dwarf / Pygmy: ~145 Days\n" +
                            "• Boer: ~149 Days\n" +
                            "• Nubian: ~151 Days",
                    fontSize = 11.sp,
                    color = Color(0xFF334155)
                )

                Text(
                    text = "SCHEDULED DEVICE ALERT STAGES",
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    color = FarmPurple
                )

                val stages = listOf(
                    Triple("🚨 Overdue Alert", "1–7 days past due date", "Warns of uterine inertia, malpresentation, or prolonged labor requiring veterinary intervention."),
                    Triple("🐐 Delivery Day", "0 days (Due Today)", "Urgent notification to monitor nesting, pacing, and complete loss of tailhead ligaments."),
                    Triple("⚠️ 24-Hour Notice", "1 day before delivery", "Sanitize kidding stall, prepare warm water, towels, and 7% iodine navel dip."),
                    Triple("🔔 3-Day Notice", "3 days before delivery", "Begin twice-daily ligament palpation and udder fullness checks."),
                    Triple("📅 7-Day Warning", "7 days before delivery", "Isolate doe into maternity stall to prevent herd bullying and stress."),
                    Triple("💉 CD&T Booster", "21–28 days prior (~Day 120)", "Administer Clostridium perfringens C&D + Tetanus toxoid booster to ensure antibody-rich colostrum.")
                )

                stages.forEach { (title, timing, desc) ->
                    Surface(
                        color = Color(0xFFF8FAFC),
                        shape = RoundedCornerShape(8.dp),
                        border = BorderStroke(0.5.dp, Color(0xFFE2E8F0)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(title, fontWeight = FontWeight.Bold, fontSize = 11.sp, color = Color(0xFF1E293B))
                                Text(timing, fontSize = 10.sp, color = FarmPurple, fontWeight = FontWeight.SemiBold)
                            }
                            Text(desc, fontSize = 10.sp, color = Color(0xFF64748B))
                        }
                    }
                }

                Text(
                    text = "OFFLINE & BACKGROUND RELIABILITY",
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    color = FarmPurple
                )
                Text(
                    text = "Alerts are scheduled natively via Android WorkManager. They trigger reliably without network connection and persist across device reboots.",
                    fontSize = 11.sp,
                    color = Color(0xFF64748B)
                )
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Understood", fontWeight = FontWeight.Bold)
            }
        }
    )
}
