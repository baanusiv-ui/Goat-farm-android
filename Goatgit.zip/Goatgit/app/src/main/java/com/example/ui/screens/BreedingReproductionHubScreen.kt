package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.supabase.*
import com.example.data.weaning.WeaningRepository
import com.example.i18n.t
import com.example.ui.components.FarmBottomNavigation
import com.example.ui.components.FarmTopBar
import com.example.ui.screens.breeding.GestationTrackingAndKiddingAlertsView
import com.example.ui.screens.weaning.WeaningManagementScreen
import com.example.ui.theme.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val FarmPurple = Color(0xFF7B1FA2)

@Composable
private fun HubKpiChip(
    title: String,
    value: String,
    color: Color,
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null
) {
    Surface(
        color = color.copy(alpha = 0.08f),
        shape = RoundedCornerShape(8.dp),
        border = BorderStroke(1.dp, color.copy(alpha = 0.2f)),
        modifier = modifier.then(if (onClick != null) Modifier.clickable { onClick() } else Modifier)
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 4.dp, vertical = 6.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = value,
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
                color = color
            )
            Text(
                text = title,
                fontSize = 9.sp,
                fontWeight = FontWeight.SemiBold,
                color = Color.DarkGray,
                maxLines = 1
            )
        }
    }
}

/**
 * Consolidated Breeding & Reproduction hub featuring 4 primary subtabs:
 * 0 - Mating
 * 1 - Pregnancy (Gestation Tracking & Alerts, Record Pregnancy)
 * 2 - Delivery (Kidding Log & Newborn Registration)
 * 3 - Weaning (Due/Pending Weanings, Weaned History, Batches, Reports & Farm Rules)
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BreedingReproductionHubScreen(
    repository: GoatRepository,
    weaningRepository: WeaningRepository,
    onNavigateBack: () -> Unit,
    initialTab: Int = 0,
    preselectedDoeId: String? = null,
    onNavigateToKidProfile: (String) -> Unit = {},
    onNavigateToBreedingRecords: () -> Unit = {},
    onNavigateToBreedingDashboard: () -> Unit = {},
    onNavigateToDashboard: () -> Unit = {},
    onNavigateToGoats: () -> Unit = {},
    onNavigateToSales: () -> Unit = {},
    onNavigateToTasks: () -> Unit = {},
    onNavigateToAiEntry: () -> Unit = {}
) {
    BackHandler { onNavigateBack() }

    var selectedTab by remember(initialTab) { mutableIntStateOf(initialTab.coerceIn(0, 3)) }
    var preselectedKiddingDoeId by remember(preselectedDoeId) { mutableStateOf(preselectedDoeId) }
    var pregnancySubTab by remember { mutableIntStateOf(0) } // 0 = Gestation & Alerts, 1 = Record Pregnancy

    var goats by remember { mutableStateOf<List<Goat>>(emptyList()) }
    var matings by remember { mutableStateOf<List<MatingRecord>>(emptyList()) }
    var pregnancies by remember { mutableStateOf<List<PregnancyRecord>>(emptyList()) }
    var reproductiveEvents by remember { mutableStateOf<List<ReproductiveEvent>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }

    val dateFormat = remember { SimpleDateFormat("yyyy-MM-dd", Locale.US) }
    val today = remember { dateFormat.format(Date()) }
    val coroutineScope = rememberCoroutineScope()

    fun loadData() {
        isLoading = true
        coroutineScope.launch {
            val res = repository.getGoats()
            val mRes = repository.getMatingRecords()
            val pRes = repository.getPregnancies()
            val rRes = repository.insurance.getAbortions()
            isLoading = false
            if (res.isSuccess) goats = res.getOrThrow()
            if (mRes.isSuccess) matings = mRes.getOrThrow()
            if (pRes.isSuccess) pregnancies = pRes.getOrThrow()
            if (rRes.isSuccess) reproductiveEvents = rRes.getOrThrow()
        }
    }

    LaunchedEffect(Unit) {
        loadData()
    }

    // Breeding metrics for KPI chips
    val confirmedPregnancies = remember(pregnancies) {
        pregnancies.count { it.status_c.equals("Confirmed", ignoreCase = true) || it.status_c.equals("Delivered", ignoreCase = true) }
    }
    val successfulKidding = remember(pregnancies, reproductiveEvents) {
        reproductiveEvents.count { it.event_type.equals("NORMAL_DELIVERY", ignoreCase = true) || it.event_type.equals("KIDDING", ignoreCase = true) } +
                pregnancies.count { it.status_c.equals("Delivered", ignoreCase = true) }
    }
    val abortionsCount = remember(reproductiveEvents, pregnancies) {
        reproductiveEvents.count { it.event_type.equals("ABORTION", ignoreCase = true) } +
                pregnancies.count { it.status_c.equals("Aborted", ignoreCase = true) }
    }
    val stillbirthsCount = remember(reproductiveEvents) {
        reproductiveEvents.count { it.event_type.equals("STILLBIRTH", ignoreCase = true) }
    }
    val openDoesCount = remember(goats, pregnancies) {
        val pregnantDoeIds = pregnancies.filter { it.status_c.equals("Confirmed", ignoreCase = true) }.map { it.doe_id_c }.toSet()
        goats.count { (it.sex_c.equals("Doe", ignoreCase = true) || it.sex_c.equals("Female", ignoreCase = true)) && !pregnantDoeIds.contains(it.id) }
    }
    val dueSoonCount = remember(pregnancies) {
        pregnancies.count { p ->
            p.status_c.equals("Confirmed", ignoreCase = true) && !p.expected_kidding_date_c.isNullOrBlank()
        }
    }
    val abortionRateStr = remember(abortionsCount, confirmedPregnancies) {
        if (confirmedPregnancies == 0) "N/A"
        else {
            val rate = (abortionsCount.toDouble() / confirmedPregnancies.toDouble()) * 100.0
            String.format(Locale.US, "%.1f%%", rate)
        }
    }

    Scaffold(
        topBar = {
            FarmTopBar(
                title = t("breeding.hub_title"),
                canNavigateBack = true,
                onNavigateBack = onNavigateBack,
                actions = {
                    IconButton(
                        onClick = onNavigateToBreedingDashboard,
                        modifier = Modifier.testTag("btn_topbar_breeding_dashboard")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Dashboard,
                            contentDescription = "Breeding Dashboard",
                            tint = Color.White
                        )
                    }
                    IconButton(
                        onClick = onNavigateToBreedingRecords,
                        modifier = Modifier.testTag("btn_topbar_breeding_records")
                    ) {
                        Icon(
                            imageVector = Icons.Default.MenuBook,
                            contentDescription = "Breeding Records Log",
                            tint = Color.White
                        )
                    }
                    IconButton(
                        onClick = { loadData() },
                        modifier = Modifier.testTag("btn_topbar_refresh")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = "Refresh",
                            tint = Color.White
                        )
                    }
                }
            )
        },
        bottomBar = {
            FarmBottomNavigation(
                currentRoute = "breeding_reproduction",
                onNavigateToDashboard = onNavigateToDashboard,
                onNavigateToGoats = onNavigateToGoats,
                onNavigateToBreeding = { selectedTab = 0 },
                onNavigateToSales = onNavigateToSales,
                onNavigateToTasks = onNavigateToTasks,
                onNavigateToAiEntry = onNavigateToAiEntry
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(FarmBackgroundLight)
                .padding(paddingValues)
        ) {
            // 4 Primary Subtabs: Mating | Pregnancy | Delivery | Weaning
            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = Color.White,
                contentColor = FarmGreenDark,
                modifier = Modifier.fillMaxWidth().testTag("breeding_reproduction_tab_row")
            ) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = { Text(t("breeding.tab_mating"), fontWeight = if (selectedTab == 0) FontWeight.Bold else FontWeight.Normal, fontSize = 13.sp) },
                    icon = { Icon(Icons.Default.FavoriteBorder, contentDescription = null, modifier = Modifier.size(18.dp)) },
                    modifier = Modifier.testTag("tab_reproduction_mating")
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = { Text(t("breeding.tab_pregnancy"), fontWeight = if (selectedTab == 1) FontWeight.Bold else FontWeight.Normal, fontSize = 13.sp) },
                    icon = { Icon(Icons.Default.DateRange, contentDescription = null, modifier = Modifier.size(18.dp)) },
                    modifier = Modifier.testTag("tab_reproduction_pregnancy")
                )
                Tab(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    text = { Text(t("breeding.tab_delivery"), fontWeight = if (selectedTab == 2) FontWeight.Bold else FontWeight.Normal, fontSize = 13.sp) },
                    icon = { Icon(Icons.Default.ChildCare, contentDescription = null, modifier = Modifier.size(18.dp)) },
                    modifier = Modifier.testTag("tab_reproduction_delivery")
                )
                Tab(
                    selected = selectedTab == 3,
                    onClick = { selectedTab = 3 },
                    text = { Text(t("breeding.tab_weaning"), fontWeight = if (selectedTab == 3) FontWeight.Bold else FontWeight.Normal, fontSize = 13.sp) },
                    icon = { Icon(Icons.Default.GroupWork, contentDescription = null, modifier = Modifier.size(18.dp)) },
                    modifier = Modifier.testTag("tab_reproduction_weaning")
                )
            }

            // Quick Reproduction Metrics Banner for Mating, Pregnancy, Delivery tabs
            if (selectedTab != 3) {
                Surface(
                    color = Color.White,
                    shadowElevation = 1.dp,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "REPRODUCTION METRICS",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                fontSize = 10.sp,
                                color = FarmGreenDark
                            )
                            Surface(
                                color = if (abortionRateStr != "N/A" && abortionsCount > 0) Color(0xFFFFEBEE) else Color(0xFFF0FDF4),
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Text(
                                    text = "Abortion Rate: $abortionRateStr",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (abortionRateStr != "N/A" && abortionsCount > 0) Color(0xFFC62828) else FarmGreenDark,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            HubKpiChip("Preggo", "$confirmedPregnancies", FarmPurple, Modifier.weight(1f)) {
                                selectedTab = 1
                                pregnancySubTab = 0
                            }
                            HubKpiChip("Kidding", "$successfulKidding", FarmGreenDark, Modifier.weight(1f)) {
                                selectedTab = 2
                            }
                            HubKpiChip("Abortions", "$abortionsCount", Color(0xFFC62828), Modifier.weight(1f))
                            HubKpiChip("Stillborn", "$stillbirthsCount", Color(0xFFE65100), Modifier.weight(1f))
                            HubKpiChip("Open Does", "$openDoesCount", Color(0xFF0284C7), Modifier.weight(1f))
                            HubKpiChip("Due Soon", "$dueSoonCount", Color(0xFFD97706), Modifier.weight(1f)) {
                                selectedTab = 1
                                pregnancySubTab = 0
                            }
                        }
                    }
                }
            }

            // Tab Content
            when (selectedTab) {
                0 -> {
                    // Mating Tab
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .verticalScroll(rememberScrollState())
                            .padding(16.dp)
                    ) {
                        if (isLoading) {
                            CircularProgressIndicator(
                                modifier = Modifier.align(Alignment.Center),
                                color = FarmGreenPrimary
                            )
                        } else {
                            MatingTab(
                                repository = repository,
                                goats = goats,
                                today = today,
                                onMatingSaved = { loadData() },
                                onGoatsUpdated = { loadData() }
                            )
                        }
                    }
                }

                1 -> {
                    // Pregnancy Tab (Gestation & Alerts + Record Pregnancy)
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .verticalScroll(rememberScrollState())
                            .padding(16.dp)
                    ) {
                        if (isLoading) {
                            CircularProgressIndicator(
                                modifier = Modifier.align(Alignment.Center),
                                color = FarmGreenPrimary
                            )
                        } else {
                            Column(
                                modifier = Modifier.fillMaxWidth(),
                                verticalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                // Sub-navigation: Gestation & Alerts vs Record Pregnancy Form
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Surface(
                                        shape = RoundedCornerShape(10.dp),
                                        color = if (pregnancySubTab == 0) FarmPurple else Color.White,
                                        border = BorderStroke(1.dp, FarmPurple),
                                        modifier = Modifier
                                            .weight(1f)
                                            .clickable { pregnancySubTab = 0 }
                                            .testTag("tab_gestation_alerts")
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(vertical = 10.dp, horizontal = 10.dp),
                                            horizontalArrangement = Arrangement.Center,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Icon(
                                                Icons.Default.DateRange,
                                                contentDescription = null,
                                                tint = if (pregnancySubTab == 0) Color.White else FarmPurple,
                                                modifier = Modifier.size(16.dp)
                                            )
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text(
                                                "Gestation & Alerts (${pregnancies.count { it.status_c.equals("Confirmed", ignoreCase = true) }})",
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 12.sp,
                                                color = if (pregnancySubTab == 0) Color.White else FarmPurple
                                            )
                                        }
                                    }

                                    Surface(
                                        shape = RoundedCornerShape(10.dp),
                                        color = if (pregnancySubTab == 1) FarmGreenPrimary else Color.White,
                                        border = BorderStroke(1.dp, FarmGreenPrimary),
                                        modifier = Modifier
                                            .weight(1f)
                                            .clickable { pregnancySubTab = 1 }
                                            .testTag("tab_record_pregnancy")
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(vertical = 10.dp, horizontal = 10.dp),
                                            horizontalArrangement = Arrangement.Center,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Icon(
                                                Icons.Default.Add,
                                                contentDescription = null,
                                                tint = if (pregnancySubTab == 1) Color.White else FarmGreenPrimary,
                                                modifier = Modifier.size(16.dp)
                                            )
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text(
                                                "Record Pregnancy",
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 12.sp,
                                                color = if (pregnancySubTab == 1) Color.White else FarmGreenPrimary
                                            )
                                        }
                                    }
                                }

                                if (pregnancySubTab == 0) {
                                    GestationTrackingAndKiddingAlertsView(
                                        repository = repository,
                                        goats = goats,
                                        pregnancies = pregnancies,
                                        matings = matings,
                                        today = today,
                                        dateFormat = dateFormat,
                                        onNavigateToKiddingWithDoe = { doeId ->
                                            preselectedKiddingDoeId = doeId
                                            selectedTab = 2 // jump to Delivery tab!
                                        },
                                        onPregnancyUpdated = { loadData() }
                                    )
                                } else {
                                    PregnancyTab(
                                        repository = repository,
                                        goats = goats,
                                        today = today,
                                        dateFormat = dateFormat,
                                        onPregnancySaved = {
                                            loadData()
                                            pregnancySubTab = 0
                                        }
                                    )
                                }
                            }
                        }
                    }
                }

                2 -> {
                    // Delivery Tab (Kidding Log & Registration)
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .verticalScroll(rememberScrollState())
                            .padding(16.dp)
                    ) {
                        if (isLoading) {
                            CircularProgressIndicator(
                                modifier = Modifier.align(Alignment.Center),
                                color = FarmGreenPrimary
                            )
                        } else {
                            KiddingTab(
                                repository = repository,
                                goats = goats,
                                today = today,
                                preselectedDoeId = preselectedKiddingDoeId,
                                onKiddingSaved = {
                                    preselectedKiddingDoeId = null
                                    loadData()
                                }
                            )
                        }
                    }
                }

                3 -> {
                    // Weaning Tab (Embedded WeaningManagementScreen)
                    WeaningManagementScreen(
                        repository = repository,
                        weaningRepository = weaningRepository,
                        onNavigateBack = onNavigateBack,
                        onNavigateToKidProfile = onNavigateToKidProfile,
                        showTopBar = false
                    )
                }
            }
        }
    }
}
