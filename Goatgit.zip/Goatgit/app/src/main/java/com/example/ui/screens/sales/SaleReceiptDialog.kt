package com.example.ui.screens.sales

import android.content.Context
import android.content.Intent
import android.print.PrintAttributes
import android.print.PrintManager
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.payment.PaymentMethod
import com.example.data.payment.PaymentStatus
import com.example.data.supabase.Goat
import com.example.data.supabase.SaleRecord
import com.example.ui.theme.FarmGreenDark
import com.example.ui.theme.FarmSuccess
import com.example.util.CurrencyUtils

@Composable
fun SaleReceiptDialog(
    sale: SaleRecord,
    goat: Goat?,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val goatName = goat?.name?.ifBlank { "Goat" } ?: "Goat"
    val goatTag = goat?.tag_c ?: sale.goat_id_c
    val paymentMethodDisplay = PaymentMethod.displayName(sale.payment_mode_c)
    val formattedAmount = CurrencyUtils.formatInr(sale.amount_c)
    val formattedPaid = CurrencyUtils.formatInr(if (sale.amount_paid_c > 0) sale.amount_paid_c else if (PaymentStatus.isPaid(sale.payment_status_c)) sale.amount_c else 0.0)
    val formattedBalance = CurrencyUtils.formatInr(sale.balance_due_c)
    val referenceText = sale.reference_c ?: sale.transaction_id_c ?: sale.order_id_c ?: "REF-${sale.id.take(8)}"
    val timestampText = sale.payment_timestamp_c ?: sale.sale_date_c

    val modeDetail = if (sale.sale_type_c == "WEIGHT") {
        "Weight Sale (${sale.quantity_c} goats, ${sale.total_weight_kg_c} kg @ ${CurrencyUtils.formatInr(sale.rate_per_unit_c)}/kg)"
    } else {
        "Piece Sale (${sale.quantity_c} pcs @ ${CurrencyUtils.formatInr(sale.rate_per_unit_c)}/pc)"
    }

    val receiptText = buildString {
        appendLine("========================================")
        appendLine("           GOAT FARM MANAGEMENT         ")
        appendLine("             OFFICIAL RECEIPT           ")
        appendLine("========================================")
        appendLine("STATUS: ${sale.payment_status_c}")
        appendLine("DELIVERY: ${sale.delivery_status_c}")
        appendLine("DATE/TIME: $timestampText")
        appendLine("RECEIPT REF: $referenceText")
        if (!sale.order_id_c.isNullOrBlank()) {
            appendLine("ORDER ID: ${sale.order_id_c}")
        }
        appendLine("----------------------------------------")
        appendLine("SALE MODE & ITEMS:")
        appendLine("Sale Mode: ${sale.sale_type_c}")
        appendLine("Details: $modeDetail")
        appendLine("Goat: $goatName (Tag: $goatTag)")
        if (goat?.breed_c != null) appendLine("Breed: ${goat.breed_c}")
        appendLine("----------------------------------------")
        appendLine("BUYER DETAILS:")
        appendLine("Name: ${sale.buyer_name_c.ifBlank { "Customer" }}")
        if (sale.buyer_phone_c.isNotBlank()) appendLine("Phone: ${sale.buyer_phone_c}")
        if (sale.buyer_address_c.isNotBlank()) appendLine("Address: ${sale.buyer_address_c}")
        if (sale.buyer_village_c.isNotBlank()) appendLine("Village: ${sale.buyer_village_c}")
        appendLine("----------------------------------------")
        appendLine("PAYMENT SUMMARY:")
        appendLine("Payment Method: $paymentMethodDisplay")
        appendLine("Total Amount: $formattedAmount")
        appendLine("Amount Paid: $formattedPaid")
        appendLine("Balance Due: $formattedBalance")
        appendLine("========================================")
        appendLine("      Thank you for your business!      ")
        appendLine("========================================")
    }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp)
                .testTag("sale_receipt_dialog")
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Status Badge
                val isPaid = PaymentStatus.isPaid(sale.payment_status_c)
                val badgeColor = if (isPaid) FarmSuccess else Color(0xFFD97706)

                Box(
                    modifier = Modifier
                        .size(56.dp)
                        .clip(CircleShape)
                        .background(badgeColor.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (isPaid) Icons.Default.CheckCircle else Icons.Default.HourglassTop,
                        contentDescription = null,
                        tint = badgeColor,
                        modifier = Modifier.size(36.dp)
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = if (isPaid) "SALE COMPLETED" else "SALE RECORDED (${sale.payment_status_c})",
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 17.sp,
                    color = badgeColor,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "Delivery Status: ${sale.delivery_status_c}",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium,
                    color = Color.Gray
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Receipt Slip Paper Card
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = Color(0xFFFAFAFA),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        ReceiptRow("Goat:", "$goatName ($goatTag)")
                        ReceiptRow("Sale Mode:", sale.sale_type_c)
                        ReceiptRow("Breakdown:", modeDetail)
                        HorizontalDivider(color = Color(0xFFE2E8F0), thickness = 0.8.dp)
                        ReceiptRow("Total Sale:", formattedAmount, isAmount = true)
                        ReceiptRow("Amount Paid:", formattedPaid)
                        if (sale.balance_due_c > 0) {
                            ReceiptRow("Balance Due:", formattedBalance, isBalance = true)
                        }
                        ReceiptRow("Payment:", paymentMethodDisplay)
                        ReceiptRow("Status:", sale.payment_status_c, isPaid = isPaid)
                        ReceiptRow("Transaction/Ref:", referenceText)
                        ReceiptRow("Date/Time:", timestampText)
                        if (sale.buyer_name_c.isNotBlank()) {
                            ReceiptRow("Buyer:", sale.buyer_name_c)
                        }
                        if (sale.buyer_address_c.isNotBlank()) {
                            ReceiptRow("Address:", sale.buyer_address_c + if (sale.buyer_village_c.isNotBlank()) ", ${sale.buyer_village_c}" else "")
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Action Buttons: Print Receipt & Share Receipt
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = {
                            printReceipt(context, receiptText, referenceText)
                        },
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(46.dp)
                            .testTag("print_receipt_btn")
                    ) {
                        Icon(Icons.Default.Print, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Print", fontWeight = FontWeight.Bold)
                    }

                    Button(
                        onClick = {
                            shareReceipt(context, receiptText)
                        },
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = FarmGreenDark),
                        modifier = Modifier
                            .weight(1f)
                            .height(46.dp)
                            .testTag("share_receipt_btn")
                    ) {
                        Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Share", fontWeight = FontWeight.Bold)
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))
                TextButton(
                    onClick = onDismiss,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Done", color = Color.Gray)
                }
            }
        }
    }
}

@Composable
private fun ReceiptRow(
    label: String,
    value: String,
    isAmount: Boolean = false,
    isPaid: Boolean = false,
    isBalance: Boolean = false
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            fontSize = 12.sp,
            color = Color.Gray,
            fontWeight = FontWeight.Medium
        )
        Text(
            text = value,
            fontSize = if (isAmount) 15.sp else 12.sp,
            fontWeight = if (isAmount || isPaid || isBalance) FontWeight.Bold else FontWeight.SemiBold,
            color = when {
                isBalance -> Color(0xFFDC2626)
                isPaid -> FarmSuccess
                isAmount -> FarmGreenDark
                else -> Color(0xFF1E293B)
            }
        )
    }
}

private fun shareReceipt(context: Context, receiptText: String) {
    try {
        val sendIntent = Intent().apply {
            action = Intent.ACTION_SEND
            putExtra(Intent.EXTRA_TEXT, receiptText)
            type = "text/plain"
        }
        val shareIntent = Intent.createChooser(sendIntent, "Share Goat Sale Receipt")
        context.startActivity(shareIntent)
    } catch (e: Exception) {
        Toast.makeText(context, "Could not share receipt: ${e.message}", Toast.LENGTH_SHORT).show()
    }
}

private fun printReceipt(context: Context, receiptText: String, reference: String) {
    try {
        val printManager = context.getSystemService(Context.PRINT_SERVICE) as? PrintManager
        if (printManager != null) {
            val webView = WebView(context)
            val htmlDocument = """
                <html>
                <head>
                    <style>
                        body { font-family: monospace; padding: 20px; white-space: pre-wrap; font-size: 13px; }
                        h2 { text-align: center; }
                    </style>
                </head>
                <body>
                    <h2>GOAT FARM MANAGEMENT</h2>
                    <pre>$receiptText</pre>
                </body>
                </html>
            """.trimIndent()

            webView.webViewClient = object : WebViewClient() {
                override fun onPageFinished(view: WebView, url: String) {
                    val printAdapter = view.createPrintDocumentAdapter("Goat_Sale_Receipt_$reference")
                    printManager.print("Goat_Sale_Receipt_$reference", printAdapter, PrintAttributes.Builder().build())
                }
            }
            webView.loadDataWithBaseURL(null, htmlDocument, "text/HTML", "UTF-8", null)
        } else {
            shareReceipt(context, receiptText)
        }
    } catch (e: Exception) {
        shareReceipt(context, receiptText)
    }
}
