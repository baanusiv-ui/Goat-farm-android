package com.example.ui.screens

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.supabase.Goat
import com.example.data.supabase.GoatRepository
import com.example.i18n.t
import com.example.ui.components.FarmTopBar
import com.example.ui.components.camera.GoatAvatar
import com.example.ui.components.profile.calculateGoatAge
import com.example.ui.screens.population.*
import com.example.ui.theme.*
import kotlinx.coroutines.launch
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GoatPopulationDashboardScreen(
    repository: GoatRepository,
    onNavigateBack: () -> Unit,
    onNavigateToAddGoat: (String?) -> Unit,
    onNavigateToGoatProfile: (String) -> Unit
) {
    BackHandler { onNavigateBack() }

    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    var allGoats by remember { mutableStateOf<List<Goat>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    var selectedBreed by remember { mutableStateOf<String?>(null) }
    var selectedStatus by remember { mutableStateOf<String?>(null) }
    var selectedViewTab by remember { mutableIntStateOf(0) } // 0 = Visual Dashboard, 1 = Matrix, 2 = Roster
    var showExportCsvDialog by remember { mutableStateOf(false) }

    fun loadData() {
        coroutineScope.launch {
            isLoading = true
            errorMessage = null
            val res = repository.getGoats()
            isLoading = false
            if (res.isSuccess) {
                allGoats = res.getOrThrow()
            } else {
                errorMessage = res.exceptionOrNull()?.message ?: "Failed to load herd census"
            }
        }
    }

    LaunchedEffect(Unit) {
        loadData()
    }

    val summary = remember(allGoats) {
        computeHerdPopulationSummary(allGoats)
    }

    // Filtered roster of goats
    val filteredGoats = remember(allGoats, selectedBreed, selectedStatus) {
        allGoats.filter { goat ->
            val matchesBreed = selectedBreed == null || goat.breed_c.equals(selectedBreed, ignoreCase = true)
            val matchesStatus = selectedStatus == null || goat.status_c.equals(selectedStatus, ignoreCase = true)
            matchesBreed && matchesStatus
        }
    }

    Scaffold(
        topBar = {
            FarmTopBar(
                title = "Herd Population & Demographics",
                canNavigateBack = true,
                onNavigateBack = onNavigateBack,
                actions = {
                    IconButton(
                        onClick = { showExportCsvDialog = true },
                        modifier = Modifier.testTag("btn_population_export_csv")
                    ) {
                        Icon(Icons.Default.FileDownload, contentDescription = "Export CSV", tint = Color.White)
                    }
                    IconButton(onClick = { loadData() }) {
                        Icon(Icons.Default.Refresh, contentDescription = "Refresh", tint = Color.White)
                    }
                    IconButton(
                        onClick = { onNavigateToAddGoat(selectedBreed) },
                        modifier = Modifier.testTag("btn_add_goat_from_population")
                    ) {
                        Icon(Icons.Default.Add, contentDescription = "Add Goat", tint = Color.White)
                    }
                }
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { onNavigateToAddGoat(selectedBreed) },
                icon = { Icon(Icons.Default.Add, contentDescription = null) },
                text = {
                    Text(
                        if (selectedBreed != null) "Add $selectedBreed" else "Add New Goat",
                        fontWeight = FontWeight.Bold
                    )
                },
                containerColor = FarmGreenPrimary,
                contentColor = Color.White,
                modifier = Modifier.testTag("fab_add_goat_population")
            )
        }
    ) { paddingValues ->
        if (isLoading) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    CircularProgressIndicator(color = FarmGreenPrimary)
                    Spacer(modifier = Modifier.height(12.dp))
                    Text("Loading herd demographics...", color = Color.Gray, fontSize = 13.sp)
                }
            }
        } else {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
                    .background(FarmBackgroundLight)
            ) {
                // Secondary Tab Selector
                TabRow(
                    selectedTabIndex = selectedViewTab,
                    containerColor = Color.White,
                    contentColor = FarmGreenDark
                ) {
                    Tab(
                        selected = selectedViewTab == 0,
                        onClick = { selectedViewTab = 0 },
                        text = { Text("Visual Charts", fontWeight = FontWeight.Bold, fontSize = 13.sp) },
                        modifier = Modifier.testTag("tab_population_charts")
                    )
                    Tab(
                        selected = selectedViewTab == 1,
                        onClick = { selectedViewTab = 1 },
                        text = { Text("Census Matrix", fontWeight = FontWeight.Bold, fontSize = 13.sp) },
                        modifier = Modifier.testTag("tab_population_matrix")
                    )
                    Tab(
                        selected = selectedViewTab == 2,
                        onClick = { selectedViewTab = 2 },
                        text = {
                            Text(
                                "Goat Roster (${filteredGoats.size})",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                        },
                        modifier = Modifier.testTag("tab_population_roster")
                    )
                }

                // Active Filter Pill Indicator
                if (selectedBreed != null || selectedStatus != null) {
                    Surface(
                        color = FarmGreenContainer,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.FilterList, contentDescription = null, tint = FarmGreenDark, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = buildString {
                                        append("Filtered by: ")
                                        selectedBreed?.let { append("Breed: $it ") }
                                        selectedStatus?.let { append("• Status: $it") }
                                    },
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = FarmGreenDark
                                )
                            }
                            TextButton(
                                onClick = {
                                    selectedBreed = null
                                    selectedStatus = null
                                },
                                contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text("Reset", fontSize = 11.sp, color = FarmGreenDark, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }

                // Main Content Body based on selected tab
                Box(modifier = Modifier.fillMaxSize()) {
                    when (selectedViewTab) {
                        0 -> {
                            // Visual Dashboard View
                            Column(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .verticalScroll(rememberScrollState())
                                    .padding(14.dp),
                                verticalArrangement = Arrangement.spacedBy(14.dp)
                            ) {
                                // KPI Summary Cards
                                PopulationKpiCardsRow(summary = summary)

                                // Indigenous Breeds Spotlight Card (Salem Karupu & Kodi Adu)
                                IndigenousBreedsBanner(
                                    allGoats = allGoats,
                                    onSelectBreed = { b ->
                                        selectedBreed = b
                                        selectedViewTab = 2
                                    },
                                    onAddBreed = { b -> onNavigateToAddGoat(b) }
                                )

                                // Recharts Bar Chart: Population by Breed
                                RechartsBreedBarChart(
                                    breedStats = summary.breedStats,
                                    selectedBreed = selectedBreed,
                                    onSelectBreed = { b -> selectedBreed = b }
                                )

                                // Recharts Donut Chart: Population by Status
                                RechartsStatusDonutChart(
                                    statusStats = summary.statusStats,
                                    totalGoats = summary.totalGoats,
                                    selectedStatus = selectedStatus,
                                    onSelectStatus = { s -> selectedStatus = s }
                                )

                                // Stacked Breed Composition Chart
                                RechartsBreedStatusStackedChart(
                                    breedStats = summary.breedStats
                                )

                                Spacer(modifier = Modifier.height(60.dp))
                            }
                        }

                        1 -> {
                            // Cross-Tabulation Matrix Table
                            Column(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .verticalScroll(rememberScrollState())
                                    .padding(14.dp),
                                verticalArrangement = Arrangement.spacedBy(14.dp)
                            ) {
                                PopulationKpiCardsRow(summary = summary)

                                CrossTabulationPopulationMatrix(
                                    summary = summary,
                                    selectedBreed = selectedBreed,
                                    selectedStatus = selectedStatus,
                                    onSelectBreed = { b ->
                                        selectedBreed = b
                                        selectedViewTab = 2
                                    },
                                    onSelectStatus = { s ->
                                        selectedStatus = s
                                        selectedViewTab = 2
                                    }
                                )

                                Spacer(modifier = Modifier.height(60.dp))
                            }
                        }

                        2 -> {
                            // Filtered Goat Roster
                            LazyColumn(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(horizontal = 14.dp, vertical = 8.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                item {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(vertical = 4.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = "Matching Animals (${filteredGoats.size})",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 14.sp,
                                            color = Color(0xFF0F172A)
                                        )
                                        Text(
                                            text = "Tap to open profile",
                                            fontSize = 11.sp,
                                            color = Color.Gray
                                        )
                                    }
                                }

                                if (filteredGoats.isEmpty()) {
                                    item {
                                        Box(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(vertical = 40.dp),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Column(
                                                horizontalAlignment = Alignment.CenterHorizontally,
                                                verticalArrangement = Arrangement.spacedBy(8.dp)
                                            ) {
                                                Icon(Icons.Default.SearchOff, contentDescription = null, tint = Color.LightGray, modifier = Modifier.size(40.dp))
                                                Text("No goats match the selected filters", color = Color.Gray, fontSize = 13.sp)
                                                if (selectedBreed != null) {
                                                    Button(
                                                        onClick = { onNavigateToAddGoat(selectedBreed) },
                                                        colors = ButtonDefaults.buttonColors(containerColor = FarmGreenPrimary),
                                                        shape = RoundedCornerShape(8.dp)
                                                    ) {
                                                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                                        Spacer(modifier = Modifier.width(4.dp))
                                                        Text("Add $selectedBreed Goat")
                                                    }
                                                }
                                            }
                                        }
                                    }
                                } else {
                                    items(filteredGoats) { goat ->
                                        GoatDemographicRosterCard(
                                            goat = goat,
                                            onClick = { onNavigateToGoatProfile(goat.id) }
                                        )
                                    }
                                }

                                item { Spacer(modifier = Modifier.height(70.dp)) }
                            }
                        }
                    }
                }
            }
        }

        if (showExportCsvDialog) {
            com.example.ui.components.ExportPopulationAndHealthDialog(
                repository = repository,
                onDismiss = { showExportCsvDialog = false }
            )
        }
    }
}

// ==============================================================================
// 7. INDIGENOUS BREEDS SPOTLIGHT (SALEM KARUPU & KODI ADU)
// ==============================================================================

@Composable
fun IndigenousBreedsBanner(
    allGoats: List<Goat>,
    onSelectBreed: (String) -> Unit,
    onAddBreed: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val salemCount = remember(allGoats) {
        allGoats.count { it.breed_c.contains("Salem Karupu", ignoreCase = true) || it.breed_c.contains("Salem Black", ignoreCase = true) }
    }
    val kodiCount = remember(allGoats) {
        allGoats.count { it.breed_c.contains("Kodi Adu", ignoreCase = true) }
    }

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(modifier = Modifier.size(8.dp).background(Color(0xFFE11D48), CircleShape))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Native Indigenous Breeds Spotlight",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = Color(0xFF0F172A)
                    )
                }
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = Color(0xFFFFF1F2)
                ) {
                    Text(
                        text = "Hardy & Resilient",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFFE11D48),
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Salem Karupu Card
                NativeBreedCard(
                    breedName = "Salem Karupu",
                    tamilName = "சேலம் கருப்பு",
                    count = salemCount,
                    accentColor = Color(0xFF1E293B),
                    badgeBg = Color(0xFFF1F5F9),
                    onFilter = { onSelectBreed("Salem Karupu") },
                    onAdd = { onAddBreed("Salem Karupu") },
                    modifier = Modifier.weight(1f)
                )

                // Kodi Adu Card
                NativeBreedCard(
                    breedName = "Kodi Adu",
                    tamilName = "கொடி ஆடு",
                    count = kodiCount,
                    accentColor = Color(0xFF0284C7),
                    badgeBg = Color(0xFFE0F2FE),
                    onFilter = { onSelectBreed("Kodi Adu") },
                    onAdd = { onAddBreed("Kodi Adu") },
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}

@Composable
private fun NativeBreedCard(
    breedName: String,
    tamilName: String,
    count: Int,
    accentColor: Color,
    badgeBg: Color,
    onFilter: () -> Unit,
    onAdd: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = badgeBg,
        border = androidx.compose.foundation.BorderStroke(1.dp, accentColor.copy(alpha = 0.2f)),
        modifier = modifier
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = breedName,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = accentColor
                )
                Text(
                    text = "$count",
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 16.sp,
                    color = accentColor
                )
            }
            Text(
                text = tamilName,
                fontSize = 10.sp,
                color = Color.Gray
            )

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Button(
                    onClick = onFilter,
                    colors = ButtonDefaults.buttonColors(containerColor = accentColor),
                    shape = RoundedCornerShape(6.dp),
                    contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                    modifier = Modifier.weight(1f).height(28.dp)
                ) {
                    Text("View", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }

                OutlinedButton(
                    onClick = onAdd,
                    shape = RoundedCornerShape(6.dp),
                    contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                    modifier = Modifier.weight(1f).height(28.dp)
                ) {
                    Text("+ Add", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = accentColor)
                }
            }
        }
    }
}

// ==============================================================================
// 8. ROSTER ITEM CARD
// ==============================================================================

@Composable
fun GoatDemographicRosterCard(
    goat: Goat,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = modifier
            .fillMaxWidth()
            .clickable { onClick() }
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            GoatAvatar(
                photoUrl = goat.photo_url_c,
                tag = goat.tag_c,
                size = 46.dp
            )

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "${goat.name} (#${goat.tag_c})",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = Color(0xFF0F172A),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = getStatusColor(goat.status_c).copy(alpha = 0.15f)
                    ) {
                        Text(
                            text = goat.status_c,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = getStatusColor(goat.status_c),
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(2.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Breed: ${goat.breed_c} • ${goat.sex_c}",
                        fontSize = 11.sp,
                        color = Color(0xFF64748B)
                    )
                    Text(
                        text = calculateGoatAge(goat.birth_date_c),
                        fontSize = 10.sp,
                        color = Color.Gray
                    )
                }
            }
        }
    }
}
