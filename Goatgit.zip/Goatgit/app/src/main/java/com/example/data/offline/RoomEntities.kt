package com.example.data.offline

import androidx.room.Embedded
import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.Relation
import java.util.UUID

@Entity(tableName = "sync_queue")
data class SyncQueueEntity(
    @PrimaryKey
    val operationId: String = UUID.randomUUID().toString(),
    val entityTable: String, // e.g. "goats_c", "sales_c", "goat_weights_c", etc.
    val recordId: String,
    val operationType: String, // "CREATE", "UPDATE", "DELETE"
    val payloadJson: String,
    val createdAt: Long = System.currentTimeMillis(),
    val retryCount: Int = 0,
    val lastError: String? = null,
    val syncStatus: String = "PENDING", // "PENDING", "IN_PROGRESS", "FAILED", "CONFLICT"
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "sync_conflicts")
data class SyncConflictEntity(
    @PrimaryKey
    val conflictId: String = UUID.randomUUID().toString(),
    val operationId: String,
    val entityTable: String,
    val recordId: String,
    val localPayloadJson: String,
    val remotePayloadJson: String,
    val conflictReason: String,
    val createdAt: Long = System.currentTimeMillis(),
    val isResolved: Boolean = false
)

@Entity(tableName = "local_goats")
data class GoatEntity(
    @PrimaryKey
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val tag_c: String,
    val breed_c: String = "Boer",
    val sex_c: String = "Doe",
    val status_c: String = "Active", // Active, Pregnant, Lactating, Quarantine, Sold, Deceased
    val birth_date_c: String? = null,
    val weight_kg_c: Double? = null,
    val dam_c: String? = null,
    val sire_c: String? = null,
    val source_c: String? = "Born on farm",
    val purchase_date_c: String? = null,
    val purchase_cost_c: Double? = null,
    val farm_location_c: String? = "Barn A",
    val color_c: String? = null,
    val notes_c: String? = null,
    val created_at: String? = null,
    val updated_at: Long = System.currentTimeMillis(),
    val is_synced: Boolean = true,
    val origin_c: String? = null,
    val photo_url_c: String? = null,
    val health_status_c: String? = "Healthy"
) {
    val effectiveOrigin: String
        get() {
            if (!origin_c.isNullOrBlank()) {
                val upper = origin_c.trim().uppercase()
                if (upper in listOf("FARM_BORN", "MARKET_BOUGHT", "UNKNOWN")) return upper
            }
            return when (source_c?.trim()?.lowercase()) {
                "born on farm", "farm born", "farm_born" -> "FARM_BORN"
                "purchased", "market bought", "market_bought", "market" -> "MARKET_BOUGHT"
                else -> "UNKNOWN"
            }
        }

    val sire_id: String?
        get() = sire_c

    val dam_id: String?
        get() = dam_c

    val effectiveSireId: String?
        get() = sire_c?.takeIf { it.isNotBlank() }

    val effectiveDamId: String?
        get() = dam_c?.takeIf { it.isNotBlank() }

    val tagId: String get() = tag_c
    val earTagId: String get() = tag_c
    val breed: String get() = breed_c
    val dateOfBirth: String? get() = birth_date_c
    val gender: String get() = sex_c
}

@Entity(tableName = "local_goat_weights")
data class GoatWeightEntity(
    @PrimaryKey
    val id: String = UUID.randomUUID().toString(),
    val goat_id_c: String,
    val weight_kg_c: Double,
    val date_c: String,
    val method_c: String = "Scale",
    val notes_c: String? = null,
    val updated_at: Long = System.currentTimeMillis(),
    val is_synced: Boolean = true
)

/**
 * 1-to-many relationship linking a goat profile with its full chronological weight records.
 */
data class GoatWithWeightHistory(
    @Embedded val goat: GoatEntity,
    @Relation(
        parentColumn = "id",
        entityColumn = "goat_id_c"
    )
    val weightHistory: List<GoatWeightEntity>
)

@Entity(tableName = "local_vaccinations")
data class VaccinationEntity(
    @PrimaryKey
    val id: String = UUID.randomUUID().toString(),
    val goat_id_c: String,
    val vaccine_c: String,
    val dose_c: String = "1 ml",
    val administered_date_c: String,
    val next_due_date_c: String? = null,
    val batch_number_c: String? = null,
    val administered_by_c: String? = null,
    val notes_c: String? = null,
    val updated_at: Long = System.currentTimeMillis(),
    val is_synced: Boolean = true
)

@Entity(tableName = "local_dewormings")
data class DewormingEntity(
    @PrimaryKey
    val id: String = UUID.randomUUID().toString(),
    val goat_id_c: String,
    val medicine_c: String,
    val dose_c: String = "5 ml",
    val treatment_date_c: String,
    val next_due_date_c: String? = null,
    val weight_at_treatment_c: Double? = null,
    val administered_by_c: String? = null,
    val notes_c: String? = null,
    val updated_at: Long = System.currentTimeMillis(),
    val is_synced: Boolean = true
)

@Entity(tableName = "local_treatments")
data class TreatmentEntity(
    @PrimaryKey
    val id: String = UUID.randomUUID().toString(),
    val goat_id_c: String,
    val symptoms_c: String,
    val diagnosis_c: String,
    val medicine_c: String,
    val dose_c: String,
    val start_date_c: String,
    val end_date_c: String? = null,
    val veterinarian_c: String? = null,
    val outcome_c: String = "Under Treatment",
    val notes_c: String? = null,
    val updated_at: Long = System.currentTimeMillis(),
    val is_synced: Boolean = true
)

@Entity(tableName = "local_matings")
data class MatingEntity(
    @PrimaryKey
    val id: String = UUID.randomUUID().toString(),
    val doe_id_c: String,
    val buck_id_c: String,
    val mating_date_c: String,
    val heat_observed_c: Boolean = true,
    val method_c: String = "Natural",
    val notes_c: String? = null,
    val updated_at: Long = System.currentTimeMillis(),
    val is_synced: Boolean = true
)

@Entity(tableName = "local_pregnancies")
data class PregnancyEntity(
    @PrimaryKey
    val id: String = UUID.randomUUID().toString(),
    val doe_id_c: String,
    val mating_record_id_c: String? = null,
    val confirmation_date_c: String,
    val expected_kidding_date_c: String,
    val status_c: String = "Confirmed",
    val actual_kidding_date_c: String? = null,
    val notes_c: String? = null,
    val updated_at: Long = System.currentTimeMillis(),
    val is_synced: Boolean = true
)

@Entity(tableName = "local_kiddings")
data class KiddingEntity(
    @PrimaryKey
    val id: String = UUID.randomUUID().toString(),
    val doe_id_c: String,
    val pregnancy_id_c: String? = null,
    val kidding_date_c: String,
    val birth_type_c: String = "Single",
    val assistance_c: String = "None",
    val complications_c: String = "None",
    val notes_c: String? = null,
    val updated_at: Long = System.currentTimeMillis(),
    val is_synced: Boolean = true
)

@Entity(tableName = "local_kids")
data class KidEntity(
    @PrimaryKey
    val id: String = UUID.randomUUID().toString(),
    val kid_tag_c: String,
    val kidding_record_id_c: String,
    val birth_weight_c: Double? = null,
    val birth_order_c: Int = 1,
    val notes_c: String? = null,
    val updated_at: Long = System.currentTimeMillis(),
    val is_synced: Boolean = true
)

@Entity(tableName = "local_breeding_records")
data class BreedingRecordEntity(
    @PrimaryKey
    val id: String = UUID.randomUUID().toString(),
    val buck_id: String,
    val doe_id: String,
    val mating_date: String,
    val expected_kidding_date: String,
    val outcome_notes: String? = null,
    val status: String = "Active", // Active, Kidded, Failed, Aborted
    val created_at: Long = System.currentTimeMillis(),
    val updated_at: Long = System.currentTimeMillis(),
    val is_synced: Boolean = true
) {
    val buckId: String get() = buck_id
    val doeId: String get() = doe_id
    val matingDate: String get() = mating_date
    val expectedKiddingDate: String get() = expected_kidding_date
    val outcomeNotes: String? get() = outcome_notes
}

@Entity(tableName = "local_feed_inventory")
data class FeedItemEntity(
    @PrimaryKey
    val id: String = UUID.randomUUID().toString(),
    val name_c: String,
    val category_c: String? = "Green Fodder",
    val current_stock_kg_c: Double = 0.0,
    val unit_c: String = "kg",
    val cost_per_unit_c: Double? = null,
    val updated_at: Long = System.currentTimeMillis(),
    val is_synced: Boolean = true
)

@Entity(tableName = "local_feed_movements")
data class FeedMovementEntity(
    @PrimaryKey
    val id: String = UUID.randomUUID().toString(),
    val feed_id_c: String,
    val movement_type_c: String,
    val quantity_c: Double,
    val date_c: String,
    val notes_c: String? = null,
    val updated_at: Long = System.currentTimeMillis(),
    val is_synced: Boolean = true
)

@Entity(tableName = "local_medicine_inventory")
data class MedicineEntity(
    @PrimaryKey
    val id: String = UUID.randomUUID().toString(),
    val medicine_name_c: String,
    val category_c: String = "Antibiotic",
    val quantity_c: Double = 0.0,
    val unit_c: String = "ml",
    val reorder_level_c: Double = 10.0,
    val unit_cost_c: Double? = null,
    val expiry_date_c: String? = null,
    val supplier_c: String? = null,
    val updated_at: Long = System.currentTimeMillis(),
    val is_synced: Boolean = true
)

@Entity(tableName = "local_tasks")
data class TaskEntity(
    @PrimaryKey
    val id: String = UUID.randomUUID().toString(),
    val title_c: String,
    val description_c: String? = null,
    val due_date_c: String,
    val priority_c: String = "Normal",
    val status_c: String = "Pending",
    val assigned_to_c: String? = null,
    val related_goat_id_c: String? = null,
    val updated_at: Long = System.currentTimeMillis(),
    val is_synced: Boolean = true
)

@Entity(tableName = "local_sales")
data class SaleEntity(
    @PrimaryKey
    val id: String = UUID.randomUUID().toString(),
    val goat_id_c: String,
    val amount_c: Double,
    val sale_date_c: String,
    val buyer_name_c: String = "",
    val buyer_phone_c: String = "",
    val payment_mode_c: String = "CASH",
    val payment_status_c: String = "PAID",
    val notes_c: String? = null,
    val created_at: String? = null,
    val updated_at: Long = System.currentTimeMillis(),
    val is_synced: Boolean = true,
    val order_id_c: String? = null,
    val transaction_id_c: String? = null,
    val bank_transaction_id_c: String? = null,
    val reference_c: String? = null,
    val currency_c: String = "INR",
    val payment_timestamp_c: String? = null,
    val failure_reason_c: String? = null,
    val sale_type_c: String = "PIECE",
    val quantity_c: Int = 1,
    val total_weight_kg_c: Double = 0.0,
    val rate_per_unit_c: Double = 0.0,
    val buyer_address_c: String = "",
    val buyer_village_c: String = "",
    val amount_paid_c: Double = 0.0,
    val balance_due_c: Double = 0.0,
    val delivery_status_c: String = "DELIVERED",
    val expected_delivery_date_c: String? = null,
    val actual_delivery_date_c: String? = null,
    val delivery_photo_uri_c: String? = null,
    val delivery_notes_c: String? = null,
    val customer_id_c: String? = null
)

@Entity(tableName = "local_delivery_records")
data class DeliveryRecordEntity(
    @PrimaryKey
    val id: String = UUID.randomUUID().toString(),
    val sale_id_c: String,
    val goat_id_c: String? = null,
    val customer_id_c: String? = null,
    val recipient_name_c: String = "",
    val recipient_phone_c: String = "",
    val delivery_address_c: String = "",
    val expected_delivery_date_c: String? = null,
    val actual_delivery_date_c: String? = null,
    val delivery_status_c: String = "EXPECTED", // EXPECTED, READY, DISPATCHED, DELIVERED, CANCELLED
    val delivery_photo_uri_c: String? = null,
    val delivery_notes_c: String? = null,
    val outstanding_balance_c: Double = 0.0,
    val is_delivered: Boolean = false,
    val marked_by_c: String? = null,
    val created_at: Long = System.currentTimeMillis(),
    val updated_at: Long = System.currentTimeMillis(),
    val is_synced: Boolean = true
)

@Entity(tableName = "local_payment_ledger")
data class PaymentLedgerEntity(
    @PrimaryKey
    val id: String = UUID.randomUUID().toString(),
    val sale_id_c: String,
    val customer_id_c: String? = null,
    val amount_c: Double,
    val payment_method_c: String, // CASH, UPI_QR, PAYTM_GATEWAY
    val payment_date_c: String,
    val reference_number_c: String? = null,
    val notes_c: String? = null,
    val source_c: String = "MANUAL",
    val created_at: Long = System.currentTimeMillis(),
    val updated_at: Long = System.currentTimeMillis(),
    val is_synced: Boolean = true
)

@Entity(tableName = "local_customers")
data class CustomerEntity(
    @PrimaryKey
    val id: String = UUID.randomUUID().toString(),
    val name_c: String,
    val phone_c: String = "",
    val address_c: String = "",
    val village_c: String = "",
    val outstanding_balance_c: Double = 0.0,
    val total_purchases_c: Double = 0.0,
    val total_paid_c: Double = 0.0,
    val notes_c: String? = null,
    val created_at: String = "",
    val updated_at: Long = System.currentTimeMillis(),
    val is_synced: Boolean = true
)

@Entity(tableName = "local_sms_payment_candidates")
data class SmsPaymentCandidateEntity(
    @PrimaryKey
    val id: String = UUID.randomUUID().toString(),
    val amount: Double,
    val referenceNumber: String? = null,
    val upiId: String? = null,
    val sender: String = "",
    val rawSnippet: String = "",
    val timestamp: Long = System.currentTimeMillis(),
    val matchedSaleId: String? = null,
    val status: String = "PENDING" // PENDING, MATCHED, IGNORED
)

@Entity(tableName = "local_transactions")
data class TransactionEntity(
    @PrimaryKey
    val id: String = UUID.randomUUID().toString(),
    val transaction_type_c: String = "Sale", // Sale, Purchase, Expense
    val amount_c: Double,
    val date_c: String,
    val category_c: String? = null,
    val description_c: String? = null,
    val payment_mode_c: String = "Cash",
    val payment_status_c: String = "Received",
    val related_id_c: String? = null,
    val updated_at: Long = System.currentTimeMillis(),
    val is_synced: Boolean = true
)

@Entity(tableName = "local_farm_settings")
data class FarmSettingEntity(
    @PrimaryKey
    val key: String,
    val value_c: String,
    val updated_at: Long = System.currentTimeMillis()
)

@Entity(tableName = "local_backup_logs")
data class BackupLogEntity(
    @PrimaryKey
    val backupId: String = UUID.randomUUID().toString(),
    val startedAt: Long,
    val completedAt: Long? = null,
    val status: String, // "SUCCESS", "PENDING", "FAILED", "IN_PROGRESS"
    val googleDriveFileId: String? = null,
    val fileName: String? = null,
    val fileSize: Long = 0L,
    val recordCount: Int = 0,
    val appVersion: String = "1.0.0",
    val errorMessage: String? = null
)

@Entity(tableName = "local_milk_records")
data class MilkRecordEntity(
    @PrimaryKey
    val id: String = UUID.randomUUID().toString(),
    val goat_id_c: String,
    val date_c: String,
    val morning_milk_ltr_c: Double = 0.0,
    val evening_milk_ltr_c: Double = 0.0,
    val total_milk_ltr_c: Double = morning_milk_ltr_c + evening_milk_ltr_c,
    val fat_percentage_c: Double? = null,
    val notes_c: String? = null,
    val updated_at: Long = System.currentTimeMillis(),
    val is_synced: Boolean = true
)

@Entity(tableName = "local_audit_logs")
data class AuditLogEntity(
    @PrimaryKey
    val id: String = UUID.randomUUID().toString(),
    val user_email_c: String,
    val action_c: String,
    val entity_c: String,
    val record_id_c: String,
    val details_c: String,
    val timestamp_c: Long = System.currentTimeMillis()
)

@Entity(tableName = "local_farm_assets")
data class FarmAssetEntity(
    @PrimaryKey
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val category: String, // Farm Buildings, Farm Infrastructure, Equipment, Vehicles
    val purchase_date: String? = null,
    val cost: Double = 0.0,
    val useful_life: Int = 5,
    val current_condition: String = "Good",
    val location: String = "Main Shed",
    val warranty_expiry: String? = null,
    val maintenance_schedule: String? = "Monthly",
    val asset_id: String? = null,
    val supplier: String? = null,
    val quantity: Int = 1,
    val status: String = "Active",
    val amc_expiry: String? = null,
    val last_maintenance: String? = null,
    val next_maintenance: String? = null,
    val residual_value: Double = 0.0,
    val depreciation_method: String = "Straight-line",
    val accumulated_depreciation: Double = 0.0,
    val current_book_value: Double = 0.0,
    val is_capex: Boolean = true,
    val notes: String? = null,
    val photo_url: String? = null,
    val created_at: String? = null,
    val updated_at: Long = System.currentTimeMillis(),
    val is_synced: Boolean = true
)

@Entity(tableName = "local_goat_photos")
data class GoatPhotoEntity(
    @PrimaryKey
    val id: String = UUID.randomUUID().toString(),
    val goat_id_c: String,
    val photo_uri_c: String,
    val title_c: String? = null,
    val category_c: String = "Identification", // Profile, Identification, Ear Tag, Health, Growth, General
    val notes_c: String? = null,
    val date_taken_c: String,
    val is_primary_c: Boolean = false,
    val created_at: Long = System.currentTimeMillis()
)
