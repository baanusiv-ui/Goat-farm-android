package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.data.supabase.SupabaseClient
import com.example.data.supabase.SupabaseConfig
import kotlinx.coroutines.launch
import java.util.UUID

/**
 * Minimal authentication screen containing solely Email, Password, Sign In, and Create Account.
 * All extraneous headers, pills, footers, and auxiliary buttons have been removed.
 */
@Composable
fun AuthScreen(
    config: SupabaseConfig,
    client: SupabaseClient,
    onAuthSuccess: () -> Unit
) {
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var isLoading by remember { mutableStateOf(false) }
    var loadingMode by remember { mutableStateOf<String?>(null) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    val coroutineScope = rememberCoroutineScope()
    val focusManager = LocalFocusManager.current

    fun handleAuth(isSignUp: Boolean) {
        if (email.isBlank() || password.isBlank()) {
            errorMessage = "Please enter both email and password."
            return
        }
        if (isSignUp && password.length < 6) {
            errorMessage = "Password must be at least 6 characters."
            return
        }

        isLoading = true
        loadingMode = if (isSignUp) "signup" else "signin"
        errorMessage = null

        coroutineScope.launch {
            try {
                if (config.hasValidKey()) {
                    val result = if (isSignUp) {
                        client.signUp(email.trim(), password)
                    } else {
                        client.signIn(email.trim(), password)
                    }
                    isLoading = false
                    loadingMode = null
                    if (result.isSuccess) {
                        config.saveSession(
                            accessToken = "session_${System.currentTimeMillis()}",
                            refreshToken = null,
                            email = email.trim(),
                            userId = "user_${UUID.randomUUID().toString().take(8)}"
                        )
                        onAuthSuccess()
                    } else {
                        errorMessage = result.exceptionOrNull()?.message ?: "Authentication failed."
                    }
                } else {
                    // Offline / local database session
                    config.saveSession(
                        accessToken = "session_${System.currentTimeMillis()}",
                        refreshToken = null,
                        email = email.trim(),
                        userId = if (isSignUp) "user_${UUID.randomUUID().toString().take(8)}" else "farm_owner"
                    )
                    isLoading = false
                    loadingMode = null
                    onAuthSuccess()
                }
            } catch (e: Exception) {
                isLoading = false
                loadingMode = null
                errorMessage = e.message ?: "Authentication failed."
            }
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(horizontal = 24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .widthIn(max = 420.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // Email
            OutlinedTextField(
                value = email,
                onValueChange = {
                    email = it
                    errorMessage = null
                },
                label = { Text("Email") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Email,
                    imeAction = ImeAction.Next
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("auth_email_input"),
                shape = RoundedCornerShape(12.dp)
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Password
            OutlinedTextField(
                value = password,
                onValueChange = {
                    password = it
                    errorMessage = null
                },
                label = { Text("Password") },
                singleLine = true,
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Password,
                    imeAction = ImeAction.Done
                ),
                keyboardActions = KeyboardActions(onDone = { focusManager.clearFocus() }),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("auth_password_input"),
                shape = RoundedCornerShape(12.dp)
            )

            if (errorMessage != null) {
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = errorMessage ?: "",
                    color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodySmall,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Sign In
            Button(
                onClick = {
                    focusManager.clearFocus()
                    handleAuth(isSignUp = false)
                },
                enabled = !isLoading,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .testTag("auth_sign_in_button"),
                shape = RoundedCornerShape(12.dp)
            ) {
                if (isLoading && loadingMode == "signin") {
                    CircularProgressIndicator(
                        modifier = Modifier.size(20.dp),
                        strokeWidth = 2.dp,
                        color = MaterialTheme.colorScheme.onPrimary
                    )
                } else {
                    Text("Sign In")
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Create Account
            OutlinedButton(
                onClick = {
                    focusManager.clearFocus()
                    handleAuth(isSignUp = true)
                },
                enabled = !isLoading,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .testTag("auth_create_account_button"),
                shape = RoundedCornerShape(12.dp)
            ) {
                if (isLoading && loadingMode == "signup") {
                    CircularProgressIndicator(
                        modifier = Modifier.size(20.dp),
                        strokeWidth = 2.dp,
                        color = MaterialTheme.colorScheme.primary
                    )
                } else {
                    Text("Create Account")
                }
            }
        }
    }
}
