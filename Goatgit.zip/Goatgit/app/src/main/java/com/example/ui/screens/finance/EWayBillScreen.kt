package com.example.ui.screens.finance

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.supabase.*
import com.example.ui.components.DatePickerField
import com.example.ui.theme.*
import com.example.util.CurrencyUtils
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EWayBillScreen(
    repository: GoatRepository,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler { onNavigateBack() }

    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val dateFormat = remember { SimpleDateFormat("yyyy-MM-dd", Locale.US) }
    val today = remember { dateFormat.format(Date()) }

    var ewayBills by remember { mutableStateOf<List<EWayBill>>(emptyList()) }
    var sales by remember { mutableStateOf<List<SaleRecord>>(emptyList()) }
    var gstSettings by remember { mutableStateOf(GstSettings()) }
    var isLoading by remember { mutableStateOf(true) }

    var showCreateDialog by remember { mutableStateOf(false) }

    fun loadData() {
        isLoading = true
        coroutineScope.launch {
            val ebRes = repository.finance.getEWayBills()
            if (ebRes.isSuccess) ewayBills = ebRes.getOrThrow()

            val salesRes = repository.getSales()
            if (salesRes.isSuccess) sales = salesRes.getOrThrow()

            val gstRes = repository.finance.getGstSettings()
            if (gstRes.isSuccess) gstSettings = gstRes.getOrThrow()

            isLoading = false
        }
    }

    LaunchedEffect(Unit) {
        loadData()
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "E-Way Bill Register",
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp
                        )
                        Text(
                            text = "Transport Details & Consignment Tracking",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack, modifier = Modifier.testTag("eway_btn_back")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(onClick = { loadData() }, modifier = Modifier.testTag("eway_btn_refresh")) {
                        Icon(Icons.Default.Refresh, contentDescription = "Refresh")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.White)
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { showCreateDialog = true },
                containerColor = Color(0xFF1E3A8A),
                contentColor = Color.White,
                icon = { Icon(Icons.Default.LocalShipping, contentDescription = null) },
                text = { Text("Prepare E-Way Bill", fontWeight = FontWeight.Bold) },
                modifier = Modifier.testTag("btn_prepare_eway_bill")
            )
        },
        containerColor = Color(0xFFF8F9FA),
        modifier = modifier
    ) { innerPadding ->
        if (isLoading) {
            Box(modifier = Modifier.fillMaxSize().padding(innerPadding), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = FarmGreenDark)
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                item { Spacer(modifier = Modifier.height(4.dp)) }

                // Government API Warning Banner (MANDATORY REQUIREMENT)
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFFFFBEB)),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth().testTag("eway_api_warning_card")
                    ) {
                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.CloudOff, contentDescription = null, tint = Color(0xFFD97706), modifier = Modifier.size(20.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Government E-Way Bill API is not configured.",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    color = Color(0xFFB45309)
                                )
                            }
                            Text(
                                text = "Consignments and vehicle details are prepared and validated locally in compliance with tax rules. No simulated or fake E-Way Bill numbers are generated. Real API credentials can be configured server-side in AI Studio.",
                                fontSize = 11.sp,
                                color = Color.DarkGray,
                                lineHeight = 15.sp
                            )
                        }
                    }
                }

                item {
                    Text("Consignment Registers", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = FarmGreenDark)
                }

                if (ewayBills.isEmpty()) {
                    item {
                        Card(colors = CardDefaults.cardColors(containerColor = Color.White), modifier = Modifier.fillMaxWidth().padding(vertical = 16.dp)) {
                            Box(modifier = Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                                Text("No E-Way Bills prepared yet. Tap 'Prepare E-Way Bill' to generate consignment documentation.", color = Color.Gray, fontSize = 13.sp)
                            }
                        }
                    }
                } else {
                    items(ewayBills) { bill ->
                        EWayBillCardItem(bill = bill)
                    }
                }

                item { Spacer(modifier = Modifier.height(72.dp)) }
            }
        }
    }

    if (showCreateDialog) {
        PrepareEWayBillDialog(
            sales = sales,
            gstSettings = gstSettings,
            onDismiss = { showCreateDialog = false },
            onSave = { bill ->
                showCreateDialog = false
                coroutineScope.launch {
                    val res = repository.finance.createEWayBill(bill)
                    if (res.isSuccess) {
                        Toast.makeText(context, "E-Way Bill consignment record prepared & validated!", Toast.LENGTH_SHORT).show()
                        loadData()
                    } else {
                        Toast.makeText(context, "Failed: ${res.exceptionOrNull()?.message}", Toast.LENGTH_LONG).show()
                    }
                }
            }
        )
    }
}

@Composable
private fun EWayBillCardItem(bill: EWayBill) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(14.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier.fillMaxWidth().testTag("eway_card_${bill.id}")
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("Invoice: ${bill.invoice_number}", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    Text("Vehicle: ${bill.vehicle_number} (${bill.transport_mode})", fontSize = 12.sp, color = Color.DarkGray)
                }
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = when (bill.status.uppercase()) {
                        "READY", "DRAFT" -> Color(0xFFEFF6FF)
                        "ACTIVE", "GENERATED" -> Color(0xFFE8F5E9)
                        else -> Color(0xFFFFF3E0)
                    }
                ) {
                    Text(
                        text = bill.status,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = when (bill.status.uppercase()) {
                            "READY", "DRAFT" -> Color(0xFF1E40AF)
                            "ACTIVE", "GENERATED" -> FarmGreenDark
                            else -> Color(0xFFE65100)
                        },
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
            }

            HorizontalDivider(color = Color(0xFFF0F0F0))

            Text("Route: ${bill.place_of_supply} → ${bill.delivery_address}", fontSize = 11.sp, color = Color.Gray)
            Text("HSN: ${bill.hsn_code} • Consignment Value: ${CurrencyUtils.formatInr(bill.total_value)}", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)

            if (!bill.error_message.isNullOrBlank()) {
                Text(
                    text = "Status Note: ${bill.error_message}",
                    fontSize = 11.sp,
                    color = Color(0xFFB45309)
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun PrepareEWayBillDialog(
    sales: List<SaleRecord>,
    gstSettings: GstSettings,
    onDismiss: () -> Unit,
    onSave: (EWayBill) -> Unit
) {
    var invoiceNumber by remember { mutableStateOf("INV-" + System.currentTimeMillis().toString().takeLast(6)) }
    var vehicleNumber by remember { mutableStateOf("TN-58-AZ-4921") }
    var transportMode by remember { mutableStateOf("Road") }
    var transporterName by remember { mutableStateOf("Farm Logistics Carrier") }
    var placeOfSupply by remember { mutableStateOf(gstSettings.state_name) }
    var deliveryAddress by remember { mutableStateOf("Agri Market Yard, District Centre") }
    var taxableStr by remember { mutableStateOf("60000") }
    var gstStr by remember { mutableStateOf("3000") }
    var qtyStr by remember { mutableStateOf("12") }

    Dialog(onDismissRequest = onDismiss) {
        Surface(shape = RoundedCornerShape(16.dp), color = Color.White, modifier = Modifier.fillMaxWidth().fillMaxHeight(0.9f)) {
            Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Prepare E-Way Bill Consignment", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = Color(0xFF1E3A8A))
                Text("Prepares shipment compliance parameters. Consignment will be recorded as 'Ready' for government portal generation.", fontSize = 11.sp, color = Color.Gray)

                LazyColumn(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    item {
                        OutlinedTextField(value = invoiceNumber, onValueChange = { invoiceNumber = it }, label = { Text("Invoice Reference *") }, singleLine = true, modifier = Modifier.fillMaxWidth().testTag("input_eway_invoice"))
                    }
                    item {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(value = vehicleNumber, onValueChange = { vehicleNumber = it }, label = { Text("Vehicle Number *") }, singleLine = true, modifier = Modifier.weight(1.2f).testTag("input_eway_vehicle"))
                            OutlinedTextField(value = transportMode, onValueChange = { transportMode = it }, label = { Text("Mode") }, modifier = Modifier.weight(0.8f))
                        }
                    }
                    item {
                        OutlinedTextField(value = transporterName, onValueChange = { transporterName = it }, label = { Text("Transporter Name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    }
                    item {
                        OutlinedTextField(value = placeOfSupply, onValueChange = { placeOfSupply = it }, label = { Text("Place of Supply *") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    }
                    item {
                        OutlinedTextField(value = deliveryAddress, onValueChange = { deliveryAddress = it }, label = { Text("Delivery Address *") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    }
                    item {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(value = qtyStr, onValueChange = { qtyStr = it }, label = { Text("Goat Qty") }, modifier = Modifier.weight(0.8f))
                            OutlinedTextField(value = taxableStr, onValueChange = { taxableStr = it }, label = { Text("Taxable (₹) *") }, modifier = Modifier.weight(1.2f))
                        }
                    }
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    TextButton(onClick = onDismiss) { Text("Cancel") }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            val taxable = taxableStr.toDoubleOrNull() ?: 0.0
                            val gst = gstStr.toDoubleOrNull() ?: 0.0
                            if (invoiceNumber.isBlank() || vehicleNumber.isBlank() || taxable <= 0) return@Button

                            val bill = EWayBill(
                                invoice_id = "INV-" + UUID.randomUUID().toString().take(8),
                                invoice_number = invoiceNumber.trim(),
                                supplier_gstin = gstSettings.gstin.ifBlank { "33AABCF1234F1Z5" },
                                recipient_gstin = null,
                                place_of_supply = placeOfSupply.trim(),
                                delivery_address = deliveryAddress.trim(),
                                hsn_code = gstSettings.default_hsn,
                                quantity = qtyStr.toDoubleOrNull() ?: 1.0,
                                taxable_value = taxable,
                                gst_amount = gst,
                                total_value = taxable + gst,
                                vehicle_number = vehicleNumber.trim().uppercase(),
                                transport_mode = transportMode.trim(),
                                transporter_name = transporterName.trim().ifBlank { null },
                                document_date = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date()),
                                status = "Ready",
                                error_message = "Government E-Way Bill API is not configured."
                            )
                            onSave(bill)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E3A8A)),
                        enabled = vehicleNumber.isNotBlank() && (taxableStr.toDoubleOrNull() ?: 0.0) > 0,
                        modifier = Modifier.testTag("btn_save_eway_bill")
                    ) {
                        Text("Save Consignment")
                    }
                }
            }
        }
    }
}
