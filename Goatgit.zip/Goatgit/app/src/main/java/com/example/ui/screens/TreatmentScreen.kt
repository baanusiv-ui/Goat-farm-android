package com.example.ui.screens

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.supabase.*
import com.example.ui.components.DatePickerField
import com.example.ui.theme.*
import com.example.util.CurrencyUtils
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TreatmentScreen(
    repository: GoatRepository,
    initialGoatId: String? = null,
    onNavigateBack: () -> Unit,
    onTreatmentSaved: () -> Unit = {}
) {
    BackHandler { onNavigateBack() }

    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val dateFormat = remember { SimpleDateFormat("yyyy-MM-dd", Locale.US) }
    val today = remember { dateFormat.format(Date()) }

    var selectedTab by remember { mutableIntStateOf(if (initialGoatId != null) 1 else 0) } // 0: Active & Ongoing, 1: Record Treatment, 2: History
    var treatments by remember { mutableStateOf<List<TreatmentRecord>>(emptyList()) }
    var goats by remember { mutableStateOf<List<Goat>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }

    // Form fields
    var selectedGoatId by remember { mutableStateOf(initialGoatId ?: "") }
    var dateGiven by remember { mutableStateOf(today) }
    var complaint by remember { mutableStateOf("") }
    var symptoms by remember { mutableStateOf("") }
    var diagnosis by remember { mutableStateOf("") }
    var treatmentPlan by remember { mutableStateOf("") }
    var medicine by remember { mutableStateOf("") }
    var dose by remember { mutableStateOf("") }
    var route by remember { mutableStateOf("Intramuscular (I/M)") }
    var startDate by remember { mutableStateOf(today) }
    var endDate by remember { mutableStateOf("") }
    var followUpDate by remember { mutableStateOf("") }
    var veterinarian by remember { mutableStateOf("") }
    var costStr by remember { mutableStateOf("") }
    var outcomeStatus by remember { mutableStateOf("UNDER_TREATMENT") } // OPEN, UNDER_TREATMENT, FOLLOW_UP, RECOVERED, REFERRED, OTHER
    var notes by remember { mutableStateOf("") }
    var attachmentNote by remember { mutableStateOf("") }

    var isSaving by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var showGoatDropdown by remember { mutableStateOf(false) }
    var showRouteDropdown by remember { mutableStateOf(false) }
    var showOutcomeDropdown by remember { mutableStateOf(false) }

    fun loadData() {
        isLoading = true
        coroutineScope.launch {
            val tRes = repository.getTreatments()
            if (tRes.isSuccess) treatments = tRes.getOrThrow()

            val gRes = repository.getGoats()
            if (gRes.isSuccess) {
                goats = gRes.getOrThrow()
                if (selectedGoatId.isBlank() && goats.isNotEmpty()) {
                    selectedGoatId = goats.first().id
                }
            }
            isLoading = false
        }
    }

    LaunchedEffect(Unit) {
        loadData()
    }

    val routes = listOf(
        "Intramuscular (I/M)",
        "Subcutaneous (S/C)",
        "Oral (Drench / Bolus)",
        "Intravenous (I/V)",
        "Topical / Wound Spray",
        "Pour-on / External",
        "Intra-mammary",
        "Eye Drops",
        "Other"
    )

    // Allowed outcome statuses per Requirement 7:
    // OPEN, UNDER_TREATMENT, FOLLOW_UP, RECOVERED, REFERRED, OTHER
    val outcomeStatuses = listOf(
        "UNDER_TREATMENT",
        "OPEN",
        "FOLLOW_UP",
        "RECOVERED",
        "REFERRED",
        "OTHER"
    )

    val goatsMap = remember(goats) { goats.associateBy { it.id } }

    val activeTreatments = remember(treatments) {
        treatments.filter {
            val out = it.outcome_c.uppercase().replace(" ", "_")
            out in listOf("UNDER_TREATMENT", "OPEN", "FOLLOW_UP")
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "Clinical Treatment",
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp
                        )
                        Text(
                            text = "Diagnosis, Medication, Follow-up & Cost Ledger",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack, modifier = Modifier.testTag("treatment_btn_back")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(onClick = { selectedTab = 1 }, modifier = Modifier.testTag("btn_quick_new_treatment")) {
                        Icon(Icons.Default.AddCircle, contentDescription = "Add Treatment", tint = FarmGreenDark)
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFFF8FAFC))
                .padding(padding)
        ) {
            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = Color.White
            ) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = { Text("Active (${activeTreatments.size})", fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = { Text("+ Record Treatment", fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                )
                Tab(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    text = { Text("All History (${treatments.size})", fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                )
            }

            if (isLoading) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = FarmGreenPrimary)
                }
            } else if (selectedTab == 1) {
                // Record Treatment Form
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    item {
                        // AI Diagnosis Guard Banner (Requirement 7: Do not allow AI to make an automatic veterinary diagnosis)
                        Surface(
                            color = Color(0xFFF1F5F9),
                            shape = RoundedCornerShape(10.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFCBD5E1)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(modifier = Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.LocalHospital, contentDescription = null, tint = Color(0xFF475569), modifier = Modifier.size(20.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Column {
                                    Text("Clinical Examination Protocol", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = Color(0xFF1E293B))
                                    Text("Diagnosis is manual/veterinarian advised. AI automatic diagnosis is disabled per veterinary regulatory standards.", fontSize = 10.sp, color = Color(0xFF475569))
                                }
                            }
                        }
                    }

                    item {
                        Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(12.dp)) {
                            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                Text("PATIENT & CLINICAL PRESENTATION", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.Gray)

                                // Goat Selector
                                val selectedGoat = goats.find { it.id == selectedGoatId }
                                Box(modifier = Modifier.fillMaxWidth()) {
                                    OutlinedTextField(
                                        value = selectedGoat?.let { "${it.tag_c} - ${it.breed_c} (${it.sex_c}, ${it.status_c})" } ?: "Select Patient Goat",
                                        onValueChange = {},
                                        readOnly = true,
                                        label = { Text("Patient Goat ID / Tag *") },
                                        modifier = Modifier.fillMaxWidth().testTag("treatment_goat_selector"),
                                        trailingIcon = {
                                            IconButton(onClick = { showGoatDropdown = true }) {
                                                Icon(Icons.Default.ArrowDropDown, contentDescription = null)
                                            }
                                        }
                                    )
                                    DropdownMenu(expanded = showGoatDropdown, onDismissRequest = { showGoatDropdown = false }) {
                                        goats.forEach { g ->
                                            DropdownMenuItem(
                                                text = { Text("${g.tag_c} - ${g.name} (${g.breed_c})") },
                                                onClick = {
                                                    selectedGoatId = g.id
                                                    showGoatDropdown = false
                                                }
                                            )
                                        }
                                    }
                                }

                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                    Box(modifier = Modifier.weight(1f)) {
                                        DatePickerField(label = "Date Examined *", dateValue = dateGiven, onDateSelected = { dateGiven = it; startDate = it })
                                    }
                                    Box(modifier = Modifier.weight(1f)) {
                                        DatePickerField(label = "Follow-up Date", dateValue = followUpDate, onDateSelected = { followUpDate = it })
                                    }
                                }

                                OutlinedTextField(
                                    value = complaint,
                                    onValueChange = { complaint = it },
                                    label = { Text("Chief Complaint *") },
                                    placeholder = { Text("e.g. Off feed since morning, dullness, limping") },
                                    modifier = Modifier.fillMaxWidth().testTag("input_treatment_complaint")
                                )

                                OutlinedTextField(
                                    value = symptoms,
                                    onValueChange = { symptoms = it },
                                    label = { Text("Symptoms Observed *") },
                                    placeholder = { Text("e.g. High fever 104°F, heavy breathing, nasal discharge") },
                                    modifier = Modifier.fillMaxWidth().testTag("input_treatment_symptoms"),
                                    minLines = 2
                                )

                                OutlinedTextField(
                                    value = diagnosis,
                                    onValueChange = { diagnosis = it },
                                    label = { Text("Diagnosis (Optional / Manual by Veterinarian)") },
                                    placeholder = { Text("e.g. Bronchopneumonia / Foot rot / Ruminal bloat") },
                                    modifier = Modifier.fillMaxWidth().testTag("input_treatment_diagnosis")
                                )
                            }
                        }
                    }

                    item {
                        Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(12.dp)) {
                            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                Text("MEDICATION & THERAPEUTIC REGIMEN", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.Gray)

                                OutlinedTextField(
                                    value = treatmentPlan,
                                    onValueChange = { treatmentPlan = it },
                                    label = { Text("Treatment Protocol") },
                                    placeholder = { Text("e.g. Antibiotic course + supportive therapy + isolation") },
                                    modifier = Modifier.fillMaxWidth()
                                )

                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                    OutlinedTextField(
                                        value = medicine,
                                        onValueChange = { medicine = it },
                                        label = { Text("Medicine *") },
                                        placeholder = { Text("e.g. Oxytetracycline LA") },
                                        modifier = Modifier.weight(1.2f).testTag("input_treatment_medicine")
                                    )
                                    OutlinedTextField(
                                        value = dose,
                                        onValueChange = { dose = it },
                                        label = { Text("Dose *") },
                                        placeholder = { Text("e.g. 2 ml") },
                                        modifier = Modifier.weight(0.8f).testTag("input_treatment_dose")
                                    )
                                }

                                // Route selection dropdown
                                Box(modifier = Modifier.fillMaxWidth()) {
                                    OutlinedTextField(
                                        value = route,
                                        onValueChange = {},
                                        readOnly = true,
                                        label = { Text("Administration Route *") },
                                        modifier = Modifier.fillMaxWidth(),
                                        trailingIcon = {
                                            IconButton(onClick = { showRouteDropdown = true }) {
                                                Icon(Icons.Default.ArrowDropDown, contentDescription = null)
                                            }
                                        }
                                    )
                                    DropdownMenu(expanded = showRouteDropdown, onDismissRequest = { showRouteDropdown = false }) {
                                        routes.forEach { r ->
                                            DropdownMenuItem(text = { Text(r) }, onClick = {
                                                route = r
                                                showRouteDropdown = false
                                            })
                                        }
                                    }
                                }

                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                    Box(modifier = Modifier.weight(1f)) {
                                        DatePickerField(label = "Start Date", dateValue = startDate, onDateSelected = { startDate = it })
                                    }
                                    Box(modifier = Modifier.weight(1f)) {
                                        DatePickerField(label = "End Date", dateValue = endDate, onDateSelected = { endDate = it })
                                    }
                                }

                                OutlinedTextField(
                                    value = veterinarian,
                                    onValueChange = { veterinarian = it },
                                    label = { Text("Attending Veterinarian / Para-vet") },
                                    placeholder = { Text("e.g. Dr. Rajesh DVM") },
                                    modifier = Modifier.fillMaxWidth()
                                )

                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                    OutlinedTextField(
                                        value = costStr,
                                        onValueChange = { costStr = it },
                                        label = { Text("Cost (INR)") },
                                        placeholder = { Text("e.g. 350") },
                                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                        modifier = Modifier.weight(1f).testTag("input_treatment_cost")
                                    )

                                    // Outcome Status
                                    Box(modifier = Modifier.weight(1f)) {
                                        OutlinedTextField(
                                            value = outcomeStatus,
                                            onValueChange = {},
                                            readOnly = true,
                                            label = { Text("Outcome Status *") },
                                            modifier = Modifier.fillMaxWidth(),
                                            trailingIcon = {
                                                IconButton(onClick = { showOutcomeDropdown = true }) {
                                                    Icon(Icons.Default.ArrowDropDown, contentDescription = null)
                                                }
                                            }
                                        )
                                        DropdownMenu(expanded = showOutcomeDropdown, onDismissRequest = { showOutcomeDropdown = false }) {
                                            outcomeStatuses.forEach { s ->
                                                DropdownMenuItem(text = { Text(s) }, onClick = {
                                                    outcomeStatus = s
                                                    showOutcomeDropdown = false
                                                })
                                            }
                                        }
                                    }
                                }

                                OutlinedTextField(
                                    value = attachmentNote,
                                    onValueChange = { attachmentNote = it },
                                    label = { Text("Prescription / Lab Attachment Reference") },
                                    placeholder = { Text("e.g. Prescription slip #RX-882, Blood smear negative") },
                                    modifier = Modifier.fillMaxWidth()
                                )

                                OutlinedTextField(
                                    value = notes,
                                    onValueChange = { notes = it },
                                    label = { Text("Clinical Notes / Care Instructions") },
                                    placeholder = { Text("Isolate in dry pen, keep plenty of clean water, re-check temp tomorrow.") },
                                    modifier = Modifier.fillMaxWidth(),
                                    minLines = 2
                                )
                            }
                        }
                    }

                    if (errorMessage != null) {
                        item {
                            Surface(color = Color(0xFFFEE2E2), shape = RoundedCornerShape(8.dp), modifier = Modifier.fillMaxWidth()) {
                                Text(errorMessage ?: "", color = Color(0xFFDC2626), modifier = Modifier.padding(10.dp), fontSize = 12.sp)
                            }
                        }
                    }

                    item {
                        Button(
                            onClick = {
                                if (selectedGoatId.isBlank()) {
                                    errorMessage = "Please select a goat."
                                    return@Button
                                }
                                if (medicine.isBlank()) {
                                    errorMessage = "Please enter medication name."
                                    return@Button
                                }

                                isSaving = true
                                errorMessage = null
                                coroutineScope.launch {
                                    val costVal = costStr.toDoubleOrNull()
                                    val combinedNotes = buildString {
                                        if (complaint.isNotBlank()) append("[Complaint: $complaint] ")
                                        if (route.isNotBlank()) append("[Route: $route] ")
                                        if (treatmentPlan.isNotBlank()) append("[Plan: $treatmentPlan] ")
                                        if (followUpDate.isNotBlank()) append("[Follow-up: $followUpDate] ")
                                        if (attachmentNote.isNotBlank()) append("[Attachment: $attachmentNote] ")
                                        if (notes.isNotBlank()) append(notes)
                                    }

                                    val record = TreatmentRecord(
                                        goat_id_c = selectedGoatId,
                                        symptoms_c = symptoms.ifBlank { complaint.ifBlank { "Clinical illness" } },
                                        diagnosis_c = diagnosis.ifBlank { "General clinical care" },
                                        medicine_c = medicine,
                                        dose_c = dose.ifBlank { "Standard dose" },
                                        start_date_c = startDate,
                                        end_date_c = endDate.ifBlank { null },
                                        veterinarian_c = veterinarian.ifBlank { null },
                                        outcome_c = outcomeStatus,
                                        cost_c = costVal,
                                        notes_c = combinedNotes.ifBlank { null }
                                    )

                                    val res = repository.recordTreatmentWithExpense(record, costVal)
                                    isSaving = false
                                    if (res.isSuccess) {
                                        Toast.makeText(context, "Treatment record saved and financial ledger updated!", Toast.LENGTH_LONG).show()
                                        onTreatmentSaved()
                                        // Reset fields
                                        complaint = ""
                                        symptoms = ""
                                        diagnosis = ""
                                        medicine = ""
                                        dose = ""
                                        costStr = ""
                                        notes = ""
                                        selectedTab = 0
                                        loadData()
                                    } else {
                                        errorMessage = res.exceptionOrNull()?.message ?: "Failed to save treatment."
                                    }
                                }
                            },
                            enabled = !isSaving,
                            colors = ButtonDefaults.buttonColors(containerColor = FarmGreenPrimary),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth().height(50.dp).testTag("btn_save_treatment")
                        ) {
                            if (isSaving) {
                                CircularProgressIndicator(color = Color.White, modifier = Modifier.size(20.dp))
                            } else {
                                Text("SAVE TREATMENT RECORD", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color.White)
                            }
                        }
                    }

                    item {
                        Spacer(modifier = Modifier.height(40.dp))
                    }
                }
            } else {
                // List of Treatments (Active tab or All History tab)
                val listToShow = if (selectedTab == 0) activeTreatments else treatments
                if (listToShow.isEmpty()) {
                    Box(modifier = Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.Healing, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(48.dp))
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(if (selectedTab == 0) "No Active Treatments" else "No Treatment Records", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                            Text("Click '+ Record Treatment' to log clinical cases.", fontSize = 12.sp, color = Color.Gray)
                        }
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 12.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(listToShow) { t ->
                            val goat = goatsMap[t.goat_id_c]
                            val isRecovered = t.outcome_c.contains("Recovered", ignoreCase = true)
                            val statusColor = if (isRecovered) Color(0xFF059669) else if (t.outcome_c.contains("Deceased", ignoreCase = true)) Color(0xFFDC2626) else Color(0xFF9333EA)

                            Card(
                                colors = CardDefaults.cardColors(containerColor = Color.White),
                                shape = RoundedCornerShape(12.dp),
                                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = "Tag: ${goat?.tag_c ?: "Goat"} (${goat?.breed_c ?: ""})",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 14.sp
                                        )
                                        Surface(
                                            color = statusColor.copy(alpha = 0.12f),
                                            shape = RoundedCornerShape(6.dp)
                                        ) {
                                            Text(
                                                text = t.outcome_c.uppercase(),
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = statusColor,
                                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                            )
                                        }
                                    }

                                    Text(
                                        text = "Medicine: ${t.medicine_c} (${t.dose_c})",
                                        fontWeight = FontWeight.SemiBold,
                                        fontSize = 13.sp,
                                        color = FarmGreenDark
                                    )

                                    Text("Symptoms: ${t.symptoms_c}", fontSize = 12.sp, color = Color.DarkGray)
                                    if (t.diagnosis_c.isNotBlank()) {
                                        Text("Diagnosis: ${t.diagnosis_c}", fontSize = 12.sp, color = Color(0xFF475569))
                                    }

                                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                        Text("Start: ${t.start_date_c}${if (!t.end_date_c.isNullOrBlank()) " to ${t.end_date_c}" else ""}", fontSize = 11.sp, color = Color.Gray)
                                        if (t.cost_c != null && t.cost_c > 0) {
                                            Text("Cost: ${CurrencyUtils.format(t.cost_c)}", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = FarmGreenDark)
                                        }
                                    }

                                    if (!t.veterinarian_c.isNullOrBlank()) {
                                        Text("Vet: ${t.veterinarian_c}", fontSize = 11.sp, color = Color.Gray)
                                    }

                                    if (!t.notes_c.isNullOrBlank()) {
                                        Text(t.notes_c!!, fontSize = 11.sp, color = Color.DarkGray)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
