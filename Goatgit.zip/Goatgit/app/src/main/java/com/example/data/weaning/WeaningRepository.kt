package com.example.data.weaning

import com.example.data.offline.*
import com.example.data.supabase.Goat
import com.example.data.supabase.GoatRepository
import com.example.data.supabase.GoatWeight
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.TimeUnit

data class WeaningDashboardMetrics(
    val kidsDueCount: Int = 0,
    val weanedThisMonthCount: Int = 0,
    val avgWeaningAgeDays: Double = 0.0,
    val avgWeaningWeightKg: Double = 0.0,
    val pendingWeaningCount: Int = 0,
    val overdueWeaningCount: Int = 0,
    val alerts: List<WeaningAlert> = emptyList()
)

enum class WeaningAlertType {
    WEANING_TODAY,
    WEANING_DUE_SOON,
    WEANING_OVERDUE,
    WEIGHT_NOT_RECORDED
}

data class WeaningAlert(
    val recordId: String,
    val goatId: String,
    val goatTag: String,
    val goatName: String,
    val alertType: WeaningAlertType,
    val message: String,
    val dueDate: String,
    val daysDifference: Long
)

data class KidWeaningItem(
    val record: WeaningRecordEntity,
    val kidGoat: GoatEntity?,
    val motherGoat: GoatEntity?,
    val fatherGoat: GoatEntity?,
    val currentAgeDays: Int,
    val latestWeightKg: Double?,
    val latestWeightDate: String?,
    val birthWeightKg: Double?,
    val adgFromBirthGramsDay: Double?,
    val vaccinationStatus: String,
    val dewormingStatus: String,
    val treatmentStatus: String,
    val isQuarantined: Boolean,
    val dynamicStatus: String // PLANNED, DUE, WEANED, DELAYED, NOT_APPLICABLE
)

data class WeaningReportData(
    val totalRecords: Int = 0,
    val totalWeaned: Int = 0,
    val totalDue: Int = 0,
    val totalDelayed: Int = 0,
    val avgWeaningAgeDays: Double = 0.0,
    val avgWeaningWeightKg: Double = 0.0,
    val avgAdgGramsPerDay: Double = 0.0,
    val breedBreakdown: Map<String, BreedWeaningStats> = emptyMap(),
    val motherBreakdown: Map<String, MotherWeaningStats> = emptyMap(),
    val monthlySummary: List<MonthlyWeaningSummary> = emptyList(),
    val delayedKidsList: List<KidWeaningItem> = emptyList()
)

data class BreedWeaningStats(
    val breed: String,
    val count: Int,
    val avgWeightKg: Double,
    val avgAgeDays: Double,
    val avgAdgGramsDay: Double
)

data class MotherWeaningStats(
    val motherTag: String,
    val motherName: String,
    val weanedKidsCount: Int,
    val avgWeaningWeightKg: Double,
    val avgAdgGramsDay: Double
)

data class MonthlyWeaningSummary(
    val monthYear: String, // "YYYY-MM"
    val count: Int,
    val avgWeightKg: Double,
    val avgAgeDays: Double,
    val avgAdgGramsDay: Double
)

class WeaningRepository(
    private val database: AppDatabase,
    private val goatRepository: GoatRepository,
    private val syncManager: OfflineSyncManager
) {
    private val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.US)
    private val dateTimeFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)

    val weaningRecordsFlow: Flow<List<WeaningRecordEntity>> = database.weaningDao().getAllWeaningRecords()
    val weaningBatchesFlow: Flow<List<WeaningBatchEntity>> = database.weaningDao().getAllWeaningBatches()

    // Default breed days
    private val defaultBreedDays = mapOf(
        "Boer" to 90,
        "Sirohi" to 90,
        "Black Bengal" to 75,
        "Barbari" to 75,
        "Jamnapari" to 100,
        "Osmanabadi" to 85,
        "Beetal" to 90,
        "Malabari" to 90,
        "Sojat" to 90,
        "Tellicherry" to 85,
        "Kalahari Red" to 90,
        "Alpine" to 90,
        "Saanen" to 90,
        "Nubian" to 90
    )

    suspend fun getDefaultWeaningDays(): Int = withContext(Dispatchers.IO) {
        val setting = database.farmSettingsDao().getSetting("weaning_default_days")?.value_c
        setting?.toIntOrNull() ?: 90
    }

    suspend fun setDefaultWeaningDays(days: Int) = withContext(Dispatchers.IO) {
        database.farmSettingsDao().saveSetting(
            FarmSettingEntity(key = "weaning_default_days", value_c = days.toString())
        )
    }

    suspend fun getBreedWeaningDays(breed: String): Int = withContext(Dispatchers.IO) {
        val key = "weaning_breed_${breed.trim().lowercase().replace(" ", "_")}"
        val custom = database.farmSettingsDao().getSetting(key)?.value_c?.toIntOrNull()
        if (custom != null) return@withContext custom

        val foundDefault = defaultBreedDays.entries.firstOrNull {
            it.key.equals(breed.trim(), ignoreCase = true)
        }?.value
        foundDefault ?: getDefaultWeaningDays()
    }

    suspend fun setBreedWeaningDays(breed: String, days: Int) = withContext(Dispatchers.IO) {
        val key = "weaning_breed_${breed.trim().lowercase().replace(" ", "_")}"
        database.farmSettingsDao().saveSetting(
            FarmSettingEntity(key = key, value_c = days.toString())
        )
    }

    suspend fun getPostWeaningFeedGroupSetting(): String = withContext(Dispatchers.IO) {
        database.farmSettingsDao().getSetting("weaning_post_feed_group")?.value_c ?: "WEANED KID / GROWING KID"
    }

    suspend fun setPostWeaningFeedGroupSetting(group: String) = withContext(Dispatchers.IO) {
        database.farmSettingsDao().saveSetting(
            FarmSettingEntity(key = "weaning_post_feed_group", value_c = group)
        )
    }

    fun calculateExpectedWeaningDate(
        birthDateStr: String,
        weaningDays: Int
    ): String {
        return try {
            val birthDate = dateFormat.parse(birthDateStr.trim()) ?: Date()
            val cal = Calendar.getInstance().apply {
                time = birthDate
                add(Calendar.DAY_OF_YEAR, weaningDays)
            }
            dateFormat.format(cal.time)
        } catch (_: Exception) {
            val cal = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, weaningDays) }
            dateFormat.format(cal.time)
        }
    }

    fun calculateAgeInDays(startDateStr: String, endDateStr: String? = null): Int {
        return try {
            val start = dateFormat.parse(startDateStr.trim()) ?: return 0
            val end = if (!endDateStr.isNullOrBlank()) dateFormat.parse(endDateStr.trim()) ?: Date() else Date()
            val diffMs = end.time - start.time
            TimeUnit.MILLISECONDS.toDays(diffMs).toInt().coerceAtLeast(0)
        } catch (_: Exception) {
            0
        }
    }

    fun calculateAdg(currentWeight: Double, referenceWeight: Double, days: Int): Double {
        if (days <= 0) return 0.0
        val diffKg = currentWeight - referenceWeight
        val grams = diffKg * 1000.0
        return (grams / days)
    }

    fun resolveStatus(record: WeaningRecordEntity): String {
        if (record.status.equals("WEANED", ignoreCase = true)) return "WEANED"
        if (record.status.equals("NOT_APPLICABLE", ignoreCase = true)) return "NOT_APPLICABLE"

        return try {
            val dueDate = dateFormat.parse(record.weaning_due_date.trim()) ?: return record.status
            val today = dateFormat.parse(dateFormat.format(Date())) ?: Date()
            val diffDays = TimeUnit.MILLISECONDS.toDays(dueDate.time - today.time)

            when {
                diffDays < 0 -> "DELAYED"
                diffDays <= 7 -> "DUE"
                else -> "PLANNED"
            }
        } catch (_: Exception) {
            record.status
        }
    }

    /**
     * Automatically scans existing kids/goats in local database and creates
     * initial weaning_records if missing.
     */
    suspend fun syncMissingWeaningRecordsForKids(): Int = withContext(Dispatchers.IO) {
        try {
            val allGoats = database.goatDao().getAllGoats()
            val existingRecords = database.weaningDao().getAllWeaningRecordsSync()
            val existingGoatIds = existingRecords.map { it.goat_id }.toSet()

            val defaultDays = getDefaultWeaningDays()
            var createdCount = 0

            val nowStr = dateTimeFormat.format(Date())

            for (goat in allGoats) {
                // If already has record or has no birth date, skip
                if (existingGoatIds.contains(goat.id)) continue
                if (goat.birth_date_c.isNullOrBlank()) continue

                // Check if goat is a kid or born on farm or status is kid-related
                val isBornOnFarm = goat.source_c?.contains("born", ignoreCase = true) == true ||
                        goat.origin_c?.contains("FARM", ignoreCase = true) == true ||
                        !goat.dam_c.isNullOrBlank()

                val ageDays = calculateAgeInDays(goat.birth_date_c)
                // If it was born within the last 365 days or has dam or is suckling/weaned
                val isKidCandidate = isBornOnFarm || ageDays <= 300 ||
                        goat.status_c.contains("Kid", ignoreCase = true) ||
                        goat.status_c.contains("Suckling", ignoreCase = true) ||
                        goat.status_c.contains("Wean", ignoreCase = true)

                if (isKidCandidate) {
                    val breedDays = getBreedWeaningDays(goat.breed_c)
                    val expectedDueDate = calculateExpectedWeaningDate(goat.birth_date_c, breedDays)
                    val initialStatus = if (goat.status_c.equals("WEANED", ignoreCase = true)) {
                        "WEANED"
                    } else {
                        val ageVsDue = calculateAgeInDays(expectedDueDate)
                        if (ageDays >= breedDays) "DELAYED" else if (breedDays - ageDays <= 7) "DUE" else "PLANNED"
                    }

                    // Look for mother id if dam tag matches
                    var motherId: String? = null
                    if (!goat.dam_c.isNullOrBlank()) {
                        val damGoat = database.goatDao().getGoatByTag(goat.dam_c.trim())
                        motherId = damGoat?.id
                    }

                    val weights = database.healthDao().getWeightsByGoat(goat.id)
                    val birthWeight = weights.minByOrNull { it.date_c }?.weight_kg_c ?: goat.weight_kg_c

                    val newRecord = WeaningRecordEntity(
                        id = UUID.randomUUID().toString(),
                        farm_id = "default_farm",
                        goat_id = goat.id,
                        mother_goat_id = motherId,
                        kidding_id = null,
                        birth_date = goat.birth_date_c,
                        weaning_due_date = expectedDueDate,
                        actual_weaning_date = if (initialStatus == "WEANED") goat.birth_date_c else null,
                        age_at_weaning_days = if (initialStatus == "WEANED") breedDays else null,
                        weight_at_weaning = if (initialStatus == "WEANED") goat.weight_kg_c else null,
                        weight_unit = "kg",
                        weaning_method = if (initialStatus == "WEANED") "GRADUAL" else null,
                        status = initialStatus,
                        setting_source = "BREED_SPECIFIC",
                        post_weaning_feed_group = "WEANED KID / GROWING KID",
                        birth_weight = birthWeight,
                        prev_weight = goat.weight_kg_c,
                        created_at = nowStr,
                        updated_at = System.currentTimeMillis()
                    )

                    database.weaningDao().insertWeaningRecord(newRecord)
                    createdCount++
                }
            }
            createdCount
        } catch (e: Exception) {
            0
        }
    }

    suspend fun getDetailedKidWeaningItems(): List<KidWeaningItem> = withContext(Dispatchers.IO) {
        val records = database.weaningDao().getAllWeaningRecordsSync()
        val allGoats = database.goatDao().getAllGoats().associateBy { it.id }
        val allGoatsByTag = database.goatDao().getAllGoats().associateBy { it.tag_c.trim().uppercase() }
        val allQuarantines = try { database.quarantineDao().getAllQuarantineRecords() } catch (_: Exception) { emptyList() }
        val quarantinedGoatIds = allQuarantines.filter { it.status.equals("ACTIVE", ignoreCase = true) }.map { it.goat_id }.toSet()

        records.map { rec ->
            val kid = allGoats[rec.goat_id]
            val mother = if (!rec.mother_goat_id.isNullOrBlank()) {
                allGoats[rec.mother_goat_id]
            } else if (!kid?.dam_c.isNullOrBlank()) {
                allGoatsByTag[kid.dam_c.trim().uppercase()]
            } else null

            val father = if (!kid?.sire_c.isNullOrBlank()) {
                allGoatsByTag[kid.sire_c.trim().uppercase()]
            } else null

            val weights = database.healthDao().getWeightsByGoat(rec.goat_id)
            val latestWeightObj = weights.maxByOrNull { it.date_c }
            val latestWeight = latestWeightObj?.weight_kg_c ?: kid?.weight_kg_c
            val latestWeightDate = latestWeightObj?.date_c

            val birthWeight = rec.birth_weight ?: weights.minByOrNull { it.date_c }?.weight_kg_c ?: kid?.weight_kg_c
            val ageDays = calculateAgeInDays(rec.birth_date, rec.actual_weaning_date)

            val adg = if (latestWeight != null && birthWeight != null && ageDays > 0 && latestWeight > birthWeight) {
                calculateAdg(latestWeight, birthWeight, ageDays)
            } else rec.adg_g_per_day

            val vax = database.healthDao().getVaccinationsByGoat(rec.goat_id)
            val vaxStatus = if (vax.isNotEmpty()) {
                "Vaccinated (${vax.size} doses, last: ${vax.first().vaccine_c})"
            } else "Not vaccinated"

            val deworm = database.healthDao().getDewormingsByGoat(rec.goat_id)
            val dewormStatus = if (deworm.isNotEmpty()) {
                "Dewormed (${deworm.size} doses, last: ${deworm.first().medicine_c})"
            } else "Not dewormed"

            val treatments = database.healthDao().getTreatmentsByGoat(rec.goat_id)
            val treatStatus = if (treatments.isNotEmpty()) {
                val active = treatments.firstOrNull { it.outcome_c.contains("Treatment", ignoreCase = true) || it.outcome_c.contains("Active", ignoreCase = true) }
                if (active != null) "Active: ${active.diagnosis_c}" else "Past treatments: ${treatments.size}"
            } else "None"

            val isQuarantined = quarantinedGoatIds.contains(rec.goat_id)
            val dynamicStatus = resolveStatus(rec)

            KidWeaningItem(
                record = rec,
                kidGoat = kid,
                motherGoat = mother,
                fatherGoat = father,
                currentAgeDays = ageDays,
                latestWeightKg = latestWeight,
                latestWeightDate = latestWeightDate,
                birthWeightKg = birthWeight,
                adgFromBirthGramsDay = adg,
                vaccinationStatus = vaxStatus,
                dewormingStatus = dewormStatus,
                treatmentStatus = treatStatus,
                isQuarantined = isQuarantined,
                dynamicStatus = dynamicStatus
            )
        }
    }

    suspend fun getWeaningDashboardMetrics(): WeaningDashboardMetrics = withContext(Dispatchers.IO) {
        val items = getDetailedKidWeaningItems()
        val todayStr = dateFormat.format(Date())
        val thisMonthPrefix = todayStr.substring(0, 7) // "YYYY-MM"

        val kidsDue = items.filter { it.dynamicStatus == "DUE" }
        val weanedThisMonth = items.filter {
            it.record.status == "WEANED" &&
                    it.record.actual_weaning_date?.startsWith(thisMonthPrefix) == true
        }

        val allWeaned = items.filter { it.record.status == "WEANED" }
        val avgAge = if (allWeaned.isNotEmpty()) {
            allWeaned.mapNotNull { it.record.age_at_weaning_days ?: it.currentAgeDays }.map { it.toDouble() }.average()
        } else 0.0

        val avgWeight = if (allWeaned.isNotEmpty()) {
            val weightsWithValues = allWeaned.mapNotNull { it.record.weight_at_weaning ?: it.latestWeightKg }
            if (weightsWithValues.isNotEmpty()) weightsWithValues.average() else 0.0
        } else 0.0

        val pending = items.filter { it.dynamicStatus == "PLANNED" || it.dynamicStatus == "DUE" }
        val overdue = items.filter { it.dynamicStatus == "DELAYED" }

        // Generate alerts
        val alerts = mutableListOf<WeaningAlert>()
        for (item in items) {
            val tag = item.kidGoat?.tag_c ?: "ID-${item.record.goat_id.take(4)}"
            val name = item.kidGoat?.name ?: "Kid $tag"
            val dueDateStr = item.record.weaning_due_date

            if (item.dynamicStatus != "WEANED" && item.dynamicStatus != "NOT_APPLICABLE") {
                val diffDays = try {
                    val d = dateFormat.parse(dueDateStr) ?: Date()
                    val t = dateFormat.parse(todayStr) ?: Date()
                    TimeUnit.MILLISECONDS.toDays(d.time - t.time)
                } catch (_: Exception) { 0L }

                if (diffDays == 0L) {
                    alerts.add(
                        WeaningAlert(
                            recordId = item.record.id,
                            goatId = item.record.goat_id,
                            goatTag = tag,
                            goatName = name,
                            alertType = WeaningAlertType.WEANING_TODAY,
                            message = "Kid #$tag is due for weaning TODAY!",
                            dueDate = dueDateStr,
                            daysDifference = 0L
                        )
                    )
                } else if (diffDays in 1..7) {
                    alerts.add(
                        WeaningAlert(
                            recordId = item.record.id,
                            goatId = item.record.goat_id,
                            goatTag = tag,
                            goatName = name,
                            alertType = WeaningAlertType.WEANING_DUE_SOON,
                            message = "Kid #$tag is due for weaning in $diffDays day${if (diffDays > 1) "s" else ""}.",
                            dueDate = dueDateStr,
                            daysDifference = diffDays
                        )
                    )
                } else if (diffDays < 0) {
                    val overdueBy = -diffDays
                    alerts.add(
                        WeaningAlert(
                            recordId = item.record.id,
                            goatId = item.record.goat_id,
                            goatTag = tag,
                            goatName = name,
                            alertType = WeaningAlertType.WEANING_OVERDUE,
                            message = "Kid #$tag weaning is OVERDUE by $overdueBy day${if (overdueBy > 1) "s" else ""}.",
                            dueDate = dueDateStr,
                            daysDifference = diffDays
                        )
                    )
                }

                if (item.latestWeightKg == null || item.latestWeightKg <= 0.0) {
                    alerts.add(
                        WeaningAlert(
                            recordId = item.record.id,
                            goatId = item.record.goat_id,
                            goatTag = tag,
                            goatName = name,
                            alertType = WeaningAlertType.WEIGHT_NOT_RECORDED,
                            message = "Kid #$tag has no recent weight recorded before weaning.",
                            dueDate = dueDateStr,
                            daysDifference = diffDays
                        )
                    )
                }
            }
        }

        WeaningDashboardMetrics(
            kidsDueCount = kidsDue.size,
            weanedThisMonthCount = weanedThisMonth.size,
            avgWeaningAgeDays = avgAge,
            avgWeaningWeightKg = avgWeight,
            pendingWeaningCount = pending.size,
            overdueWeaningCount = overdue.size,
            alerts = alerts.sortedBy { it.daysDifference }
        )
    }

    /**
     * Executes the complete weaning procedure:
     * 1. Updates weaning_records entry
     * 2. Adds new weight record to local_goat_weights via recordWeight (does not overwrite previous weights)
     * 3. Updates kid lifecycle status to WEANED and updates goat weight
     * 4. Keeps mother-kid link intact
     * 5. Enqueues sync
     */
    suspend fun recordWeaning(
        recordId: String,
        actualWeaningDate: String,
        weightAtWeaning: Double,
        weaningMethod: String,
        postFeedGroup: String = "WEANED KID / GROWING KID",
        notes: String? = null,
        isDelayed: Boolean = false,
        delayReason: String? = null,
        batchId: String? = null
    ): Result<WeaningRecordEntity> = withContext(Dispatchers.IO) {
        try {
            val record = database.weaningDao().getWeaningRecordById(recordId)
                ?: return@withContext Result.failure(Exception("Weaning record not found"))

            val kidGoat = database.goatDao().getGoatById(record.goat_id)

            // Calculate age at weaning
            val ageAtWeaning = calculateAgeInDays(record.birth_date, actualWeaningDate)

            // Calculate ADG from birth and previous weight
            val weights = database.healthDao().getWeightsByGoat(record.goat_id)
            val birthWeight = record.birth_weight ?: weights.minByOrNull { it.date_c }?.weight_kg_c ?: kidGoat?.weight_kg_c
            val prevWeight = weights.firstOrNull()?.weight_kg_c ?: birthWeight

            val adgFromBirth = if (birthWeight != null && ageAtWeaning > 0) {
                calculateAdg(weightAtWeaning, birthWeight, ageAtWeaning)
            } else null

            // 1. Create a NEW weight record using existing Weight module
            val newWeight = GoatWeight(
                goat_id_c = record.goat_id,
                weight_kg_c = weightAtWeaning,
                date_c = actualWeaningDate,
                method_c = "WEANING",
                notes_c = "Weaning weight at $ageAtWeaning days (Method: $weaningMethod). " +
                        (if (adgFromBirth != null) "ADG: ${adgFromBirth.toInt()} g/day. " else "") +
                        (notes ?: "").trim()
            )
            goatRepository.recordWeight(newWeight)

            // 2. Update Kid lifecycle status to WEANED in local_goats
            if (kidGoat != null) {
                database.goatDao().updateStatus(record.goat_id, "WEANED")
                database.goatDao().updateWeight(record.goat_id, weightAtWeaning)
                syncManager.enqueueOperation(
                    "goats_c",
                    record.goat_id,
                    "UPDATE",
                    JSONObject().apply {
                        put("status_c", "WEANED")
                        put("weight_kg_c", weightAtWeaning)
                    }
                )
            }

            // 3. Update weaning_records
            val updatedRecord = record.copy(
                actual_weaning_date = actualWeaningDate,
                age_at_weaning_days = ageAtWeaning,
                weight_at_weaning = weightAtWeaning,
                weaning_method = weaningMethod,
                status = "WEANED",
                reason_if_delayed = if (isDelayed) delayReason else record.reason_if_delayed,
                notes = notes ?: record.notes,
                post_weaning_feed_group = postFeedGroup,
                birth_weight = birthWeight,
                prev_weight = prevWeight,
                adg_g_per_day = adgFromBirth,
                batch_id = batchId ?: record.batch_id,
                updated_at = System.currentTimeMillis()
            )
            database.weaningDao().updateWeaningRecord(updatedRecord)

            // 4. Enqueue weaning_records sync
            val recordJson = JSONObject().apply {
                put("id", updatedRecord.id)
                put("farm_id", updatedRecord.farm_id)
                put("goat_id", updatedRecord.goat_id)
                if (updatedRecord.mother_goat_id != null) put("mother_goat_id", updatedRecord.mother_goat_id)
                if (updatedRecord.kidding_id != null) put("kidding_id", updatedRecord.kidding_id)
                put("birth_date", updatedRecord.birth_date)
                put("weaning_due_date", updatedRecord.weaning_due_date)
                put("actual_weaning_date", updatedRecord.actual_weaning_date)
                put("age_at_weaning_days", updatedRecord.age_at_weaning_days)
                put("weight_at_weaning", updatedRecord.weight_at_weaning)
                put("weight_unit", updatedRecord.weight_unit)
                put("weaning_method", updatedRecord.weaning_method)
                put("status", updatedRecord.status)
                if (!updatedRecord.reason_if_delayed.isNullOrBlank()) put("reason_if_delayed", updatedRecord.reason_if_delayed)
                if (!updatedRecord.notes.isNullOrBlank()) put("notes", updatedRecord.notes)
                put("setting_source", updatedRecord.setting_source)
                put("post_weaning_feed_group", updatedRecord.post_weaning_feed_group)
                if (updatedRecord.adg_g_per_day != null) put("adg_g_per_day", updatedRecord.adg_g_per_day)
                if (updatedRecord.batch_id != null) put("batch_id", updatedRecord.batch_id)
            }
            syncManager.enqueueOperation("weaning_records_c", updatedRecord.id, "UPDATE", recordJson)

            Result.success(updatedRecord)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Creates a batch weaning event for multiple kids.
     */
    suspend fun createWeaningBatch(
        kidsWithWeights: List<Pair<String, Double>>, // recordId to weight
        weaningDate: String,
        method: String,
        postFeedGroup: String = "WEANED KID / GROWING KID",
        notes: String? = null
    ): Result<WeaningBatchEntity> = withContext(Dispatchers.IO) {
        try {
            if (kidsWithWeights.isEmpty()) {
                return@withContext Result.failure(Exception("No kids selected for batch weaning"))
            }

            val batchId = UUID.randomUUID().toString()
            val avgWeight = kidsWithWeights.map { it.second }.average()
            val nowStr = dateTimeFormat.format(Date())

            val batch = WeaningBatchEntity(
                id = batchId,
                farm_id = "default_farm",
                weaning_date = weaningDate,
                number_of_kids = kidsWithWeights.size,
                average_weight = avgWeight,
                notes = notes,
                created_at = nowStr,
                updated_at = System.currentTimeMillis()
            )
            database.weaningDao().insertWeaningBatch(batch)

            val batchJson = JSONObject().apply {
                put("id", batch.id)
                put("farm_id", batch.farm_id)
                put("weaning_date", batch.weaning_date)
                put("number_of_kids", batch.number_of_kids)
                put("average_weight", batch.average_weight)
                if (!batch.notes.isNullOrBlank()) put("notes", batch.notes)
            }
            syncManager.enqueueOperation("weaning_batches_c", batch.id, "CREATE", batchJson)

            // Record each kid's weaning individually
            for ((recordId, weight) in kidsWithWeights) {
                recordWeaning(
                    recordId = recordId,
                    actualWeaningDate = weaningDate,
                    weightAtWeaning = weight,
                    weaningMethod = method,
                    postFeedGroup = postFeedGroup,
                    notes = "Part of batch #$batchId. ${notes ?: ""}".trim(),
                    batchId = batchId
                )
            }

            Result.success(batch)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun updateWeaningPlan(
        recordId: String,
        expectedDate: String,
        settingSource: String,
        reasonIfDelayed: String?,
        notes: String?
    ): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val record = database.weaningDao().getWeaningRecordById(recordId)
                ?: return@withContext Result.failure(Exception("Record not found"))

            val updated = record.copy(
                weaning_due_date = expectedDate,
                setting_source = settingSource,
                reason_if_delayed = reasonIfDelayed ?: record.reason_if_delayed,
                notes = notes ?: record.notes,
                updated_at = System.currentTimeMillis()
            )
            database.weaningDao().updateWeaningRecord(updated)
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun exemptFromWeaning(recordId: String, reason: String): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val record = database.weaningDao().getWeaningRecordById(recordId)
                ?: return@withContext Result.failure(Exception("Record not found"))
            val updated = record.copy(
                status = "NOT_APPLICABLE",
                reason_if_delayed = reason,
                updated_at = System.currentTimeMillis()
            )
            database.weaningDao().updateWeaningRecord(updated)
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getWeaningRecordForGoat(goatId: String): WeaningRecordEntity? = withContext(Dispatchers.IO) {
        database.weaningDao().getWeaningRecordByGoatId(goatId)
    }

    suspend fun getWeaningReportsData(): WeaningReportData = withContext(Dispatchers.IO) {
        val items = getDetailedKidWeaningItems()
        val weanedItems = items.filter { it.record.status == "WEANED" }
        val dueItems = items.filter { it.dynamicStatus == "DUE" }
        val delayedItems = items.filter { it.dynamicStatus == "DELAYED" }

        val avgAge = if (weanedItems.isNotEmpty()) {
            weanedItems.mapNotNull { it.record.age_at_weaning_days ?: it.currentAgeDays }.map { it.toDouble() }.average()
        } else 0.0

        val avgWeight = if (weanedItems.isNotEmpty()) {
            val weights = weanedItems.mapNotNull { it.record.weight_at_weaning ?: it.latestWeightKg }
            if (weights.isNotEmpty()) weights.average() else 0.0
        } else 0.0

        val avgAdg = if (weanedItems.isNotEmpty()) {
            val adgs = weanedItems.mapNotNull { it.record.adg_g_per_day ?: it.adgFromBirthGramsDay }
            if (adgs.isNotEmpty()) adgs.average() else 0.0
        } else 0.0

        // Breed breakdown
        val breedMap = mutableMapOf<String, MutableList<KidWeaningItem>>()
        for (item in weanedItems) {
            val breed = item.kidGoat?.breed_c ?: "Unknown"
            breedMap.getOrPut(breed) { mutableListOf() }.add(item)
        }
        val breedStats = breedMap.mapValues { (breed, list) ->
            BreedWeaningStats(
                breed = breed,
                count = list.size,
                avgWeightKg = list.mapNotNull { it.record.weight_at_weaning ?: it.latestWeightKg }.ifEmpty { listOf(0.0) }.average(),
                avgAgeDays = list.mapNotNull { it.record.age_at_weaning_days ?: it.currentAgeDays }.map { it.toDouble() }.ifEmpty { listOf(0.0) }.average(),
                avgAdgGramsDay = list.mapNotNull { it.record.adg_g_per_day ?: it.adgFromBirthGramsDay }.ifEmpty { listOf(0.0) }.average()
            )
        }

        // Mother breakdown
        val motherMap = mutableMapOf<String, MutableList<KidWeaningItem>>()
        for (item in weanedItems) {
            val motherTag = item.motherGoat?.tag_c ?: item.kidGoat?.dam_c ?: "Unknown Mother"
            motherMap.getOrPut(motherTag) { mutableListOf() }.add(item)
        }
        val motherStats = motherMap.mapValues { (mTag, list) ->
            MotherWeaningStats(
                motherTag = mTag,
                motherName = list.firstNotNullOfOrNull { it.motherGoat?.name } ?: "Dam $mTag",
                weanedKidsCount = list.size,
                avgWeaningWeightKg = list.mapNotNull { it.record.weight_at_weaning ?: it.latestWeightKg }.ifEmpty { listOf(0.0) }.average(),
                avgAdgGramsDay = list.mapNotNull { it.record.adg_g_per_day ?: it.adgFromBirthGramsDay }.ifEmpty { listOf(0.0) }.average()
            )
        }

        // Monthly summary
        val monthMap = mutableMapOf<String, MutableList<KidWeaningItem>>()
        for (item in weanedItems) {
            val date = item.record.actual_weaning_date ?: item.record.created_at
            val month = if (date.length >= 7) date.substring(0, 7) else "Unknown"
            monthMap.getOrPut(month) { mutableListOf() }.add(item)
        }
        val monthlySummary = monthMap.entries.sortedByDescending { it.key }.map { (month, list) ->
            MonthlyWeaningSummary(
                monthYear = month,
                count = list.size,
                avgWeightKg = list.mapNotNull { it.record.weight_at_weaning ?: it.latestWeightKg }.ifEmpty { listOf(0.0) }.average(),
                avgAgeDays = list.mapNotNull { it.record.age_at_weaning_days ?: it.currentAgeDays }.map { it.toDouble() }.ifEmpty { listOf(0.0) }.average(),
                avgAdgGramsDay = list.mapNotNull { it.record.adg_g_per_day ?: it.adgFromBirthGramsDay }.ifEmpty { listOf(0.0) }.average()
            )
        }

        WeaningReportData(
            totalRecords = items.size,
            totalWeaned = weanedItems.size,
            totalDue = dueItems.size,
            totalDelayed = delayedItems.size,
            avgWeaningAgeDays = avgAge,
            avgWeaningWeightKg = avgWeight,
            avgAdgGramsPerDay = avgAdg,
            breedBreakdown = breedStats,
            motherBreakdown = motherStats,
            monthlySummary = monthlySummary,
            delayedKidsList = delayedItems
        )
    }

    /**
     * Creates a new Weaning record when kidding registers a kid
     */
    suspend fun createWeaningRecordForNewborn(
        kidId: String,
        motherId: String?,
        kiddingId: String?,
        birthDate: String,
        breed: String,
        birthWeight: Double?,
        overrideDays: Int? = null,
        settingSource: String = "FARM_DEFAULT"
    ): Result<WeaningRecordEntity> = withContext(Dispatchers.IO) {
        try {
            val days = overrideDays ?: getBreedWeaningDays(breed)
            val dueDate = calculateExpectedWeaningDate(birthDate, days)
            val nowStr = dateTimeFormat.format(Date())

            val record = WeaningRecordEntity(
                id = UUID.randomUUID().toString(),
                farm_id = "default_farm",
                goat_id = kidId,
                mother_goat_id = motherId,
                kidding_id = kiddingId,
                birth_date = birthDate,
                weaning_due_date = dueDate,
                status = "PLANNED",
                setting_source = settingSource,
                post_weaning_feed_group = "WEANED KID / GROWING KID",
                birth_weight = birthWeight,
                prev_weight = birthWeight,
                created_at = nowStr,
                updated_at = System.currentTimeMillis()
            )
            database.weaningDao().insertWeaningRecord(record)

            val recordJson = JSONObject().apply {
                put("id", record.id)
                put("farm_id", record.farm_id)
                put("goat_id", record.goat_id)
                if (record.mother_goat_id != null) put("mother_goat_id", record.mother_goat_id)
                if (record.kidding_id != null) put("kidding_id", record.kidding_id)
                put("birth_date", record.birth_date)
                put("weaning_due_date", record.weaning_due_date)
                put("status", record.status)
                put("setting_source", record.setting_source)
                put("post_weaning_feed_group", record.post_weaning_feed_group)
                if (record.birth_weight != null) put("birth_weight", record.birth_weight)
            }
            syncManager.enqueueOperation("weaning_records_c", record.id, "CREATE", recordJson)

            Result.success(record)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
