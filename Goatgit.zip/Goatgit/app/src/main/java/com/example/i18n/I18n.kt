package com.example.i18n

import androidx.compose.runtime.Composable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.staticCompositionLocalOf

val LocalLanguage = staticCompositionLocalOf { AppLanguage.ENGLISH }
val LocalLanguageManager = compositionLocalOf<LanguageManager?> { null }

@Composable
fun t(key: String, vararg args: Any): String {
    val lang = LocalLanguage.current
    return Translations.get(key, lang, *args)
}

fun tDirect(key: String, lang: AppLanguage, vararg args: Any): String {
    return Translations.get(key, lang, *args)
}
