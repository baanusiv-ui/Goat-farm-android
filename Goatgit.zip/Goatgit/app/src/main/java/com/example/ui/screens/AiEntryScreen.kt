package com.example.ui.screens

import android.app.Activity
import android.content.Intent
import android.speech.RecognizerIntent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.ai.AiEntryParser
import com.example.data.ai.ParsedFarmEntry
import com.example.data.supabase.*
import com.example.i18n.t
import com.example.ui.components.DatePickerField
import com.example.ui.components.FarmBottomNavigation
import com.example.ui.components.FarmTopBar
import com.example.ui.components.TagBadge
import com.example.ui.theme.*
import kotlinx.coroutines.launch

@Composable
fun AiEntryScreen(
    repository: GoatRepository,
    onNavigateBack: () -> Unit,
    onEntrySaved: () -> Unit,
    onNavigateToDashboard: () -> Unit = {},
    onNavigateToGoats: () -> Unit = {},
    onNavigateToSales: () -> Unit = {},
    onNavigateToTasks: () -> Unit = {},
    onNavigateToBreeding: () -> Unit = {}
) {
    var rawInput by remember { mutableStateOf("") }
    var isParsing by remember { mutableStateOf(false) }
    var isSavingToSupabase by remember { mutableStateOf(false) }
    var parseError by remember { mutableStateOf<String?>(null) }
    var parsedEntry by remember { mutableStateOf<ParsedFarmEntry?>(null) }
    var saveSuccessMessage by remember { mutableStateOf<String?>(null) }

    // Goats list for matching tags
    var goats by remember { mutableStateOf<List<Goat>>(emptyList()) }

    val coroutineScope = rememberCoroutineScope()
    val aiParser = remember { AiEntryParser() }

    // Speech-to-text launcher
    val speechLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val spokenText = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!spokenText.isNullOrBlank()) {
                rawInput = spokenText
            }
        }
    }

    LaunchedEffect(Unit) {
        val res = repository.getGoats()
        if (res.isSuccess) {
            goats = res.getOrThrow()
        }
    }

    Scaffold(
        topBar = {
            FarmTopBar(
                title = t("topbar.ai_field_entry"),
                canNavigateBack = true,
                onNavigateBack = onNavigateBack,
                syncManager = repository.syncManager
            )
        },
        bottomBar = {
            FarmBottomNavigation(
                currentRoute = "ai_entry",
                onNavigateToDashboard = onNavigateToDashboard,
                onNavigateToGoats = onNavigateToGoats,
                onNavigateToBreeding = onNavigateToBreeding,
                onNavigateToSales = onNavigateToSales,
                onNavigateToTasks = onNavigateToTasks,
                onNavigateToAiEntry = {}
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(FarmBackgroundLight)
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Speech / Voice Input Header Card
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = t("ai.natural_voice_title"),
                                fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.titleMedium,
                                color = FarmGreenDark
                            )
                            Text(
                                text = t("ai.natural_voice_desc"),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        // Microphone Button
                        IconButton(
                            onClick = {
                                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                                    putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak farm entry (e.g. Tag G102 weighed 32 kilos today)")
                                }
                                try {
                                    speechLauncher.launch(intent)
                                } catch (_: Exception) {}
                            },
                            modifier = Modifier
                                .size(50.dp)
                                .clip(CircleShape)
                                .background(FarmGreenPrimary)
                                .testTag("speech_mic_button")
                        ) {
                            Icon(Icons.Default.Mic, contentDescription = "Speak", tint = Color.White)
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    OutlinedTextField(
                        value = rawInput,
                        onValueChange = { rawInput = it; parseError = null },
                        placeholder = { Text("e.g. Tag G102 weighed 32 kilos today") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("ai_entry_text_input"),
                        minLines = 3,
                        maxLines = 5,
                        trailingIcon = {
                            if (rawInput.isNotEmpty()) {
                                IconButton(onClick = { rawInput = "" }) {
                                    Icon(Icons.Default.Close, contentDescription = "Clear")
                                }
                            }
                        }
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Example prompt chips
                    Text(
                        text = t("ai.quick_examples"),
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        ExampleChip("Tag G102 weighed 32 kilos today") { rawInput = it }
                        ExampleChip("Goat G102 vaccinated for PPR, next due in 6 months") { rawInput = it }
                        ExampleChip("Goat G105 was dewormed today with 5ml Albendazole") { rawInput = it }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Button(
                        onClick = {
                            if (rawInput.isBlank()) {
                                parseError = "Please enter or speak some text first."
                                return@Button
                            }
                            isParsing = true
                            parseError = null
                            parsedEntry = null
                            saveSuccessMessage = null
                            coroutineScope.launch {
                                val result = aiParser.parseFarmerInput(rawInput)
                                isParsing = false
                                if (result.isSuccess) {
                                    parsedEntry = result.getOrThrow()
                                } else {
                                    parseError = result.exceptionOrNull()?.message ?: "Failed to parse input"
                                }
                            }
                        },
                        enabled = !isParsing,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("parse_ai_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = FarmGreenDark),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        if (isParsing) {
                            CircularProgressIndicator(color = Color.White, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(t("ai.parsing"))
                        } else {
                            Icon(Icons.Default.AutoAwesome, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(t("ai.parse_with_ai"), fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            if (parseError != null) {
                Card(colors = CardDefaults.cardColors(containerColor = FarmErrorContainer)) {
                    Text(
                        text = parseError ?: "",
                        color = FarmError,
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier.padding(14.dp)
                    )
                }
            }

            // CRITICAL REQUIREMENT: DISPLAY PARSED DATA FOR CONFIRMATION
            parsedEntry?.let { entry ->
                ConfirmationCard(
                    entry = entry,
                    goats = goats,
                    isSaving = isSavingToSupabase,
                    onConfirm = { confirmedEntry ->
                        isSavingToSupabase = true
                        parseError = null
                        coroutineScope.launch {
                            val success = saveEntryToSupabase(confirmedEntry, repository, goats)
                            isSavingToSupabase = false
                            if (success.isSuccess) {
                                saveSuccessMessage = success.getOrThrow()
                                parsedEntry = null
                                rawInput = ""
                            } else {
                                parseError = success.exceptionOrNull()?.message ?: "Failed to save to Supabase"
                            }
                        }
                    },
                    onDiscard = {
                        parsedEntry = null
                    }
                )
            }

            // Success Confirmation
            saveSuccessMessage?.let { msg ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = FarmSuccessContainer),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.CheckCircle, contentDescription = null, tint = FarmSuccess)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(t("ai.saved_success"), fontWeight = FontWeight.Bold, color = FarmSuccess)
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(msg, color = FarmSuccess, style = MaterialTheme.typography.bodyMedium)
                        Spacer(modifier = Modifier.height(10.dp))
                        Button(
                            onClick = onEntrySaved,
                            colors = ButtonDefaults.buttonColors(containerColor = FarmGreenPrimary)
                        ) {
                            Text(t("ai.return_to_dashboard"))
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(32.dp))
        }
    }
}

@Composable
fun ExampleChip(
    text: String,
    onClick: (String) -> Unit
) {
    Surface(
        onClick = { onClick(text) },
        shape = RoundedCornerShape(8.dp),
        color = FarmGreenContainer.copy(alpha = 0.5f),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Default.FormatQuote, contentDescription = null, tint = FarmGreenDark, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text(text, fontSize = 12.sp, color = FarmGreenDark)
        }
    }
}

@Composable
fun ConfirmationCard(
    entry: ParsedFarmEntry,
    goats: List<Goat>,
    isSaving: Boolean,
    onConfirm: (ParsedFarmEntry) -> Unit,
    onDiscard: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("ai_confirmation_card")
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.FactCheck,
                        contentDescription = null,
                        tint = FarmGreenPrimary,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = t("ai.confirm_title"),
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleMedium,
                        color = FarmGreenDark
                    )
                }

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = FarmAmberContainer
                ) {
                    Text(
                        text = t("ai.review_before_save"),
                        color = FarmBrown,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))
            HorizontalDivider()
            Spacer(modifier = Modifier.height(12.dp))

            when (entry) {
                is ParsedFarmEntry.Weight -> {
                    var tag by remember { mutableStateOf(entry.tag) }
                    var weightStr by remember { mutableStateOf(entry.weightKg.toString()) }
                    var date by remember { mutableStateOf(entry.date) }
                    var notes by remember { mutableStateOf(entry.notes ?: "") }

                    val matchedGoat = goats.find { it.tag_c.equals(tag, ignoreCase = true) }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Record Type: ", fontWeight = FontWeight.Bold)
                        Text("Goat Weight", color = FarmGreenPrimary, fontWeight = FontWeight.Bold)
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = tag,
                        onValueChange = { tag = it },
                        label = { Text("Goat Tag") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    if (matchedGoat != null) {
                        Text(
                            text = "Found Goat: ${matchedGoat.name} (${matchedGoat.breed_c}, ${matchedGoat.sex_c})",
                            color = FarmSuccess,
                            style = MaterialTheme.typography.bodySmall,
                            modifier = Modifier.padding(top = 2.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = weightStr,
                        onValueChange = { weightStr = it },
                        label = { Text("Weight (kg)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    DatePickerField(dateValue = date, onDateSelected = { date = it }, label = "Date Weighed")

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = notes,
                        onValueChange = { notes = it },
                        label = { Text("Notes") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    ActionButtons(
                        isSaving = isSaving,
                        onConfirm = {
                            val w = weightStr.toDoubleOrNull() ?: entry.weightKg
                            onConfirm(ParsedFarmEntry.Weight(tag, w, date, entry.method, notes))
                        },
                        onDiscard = onDiscard
                    )
                }

                is ParsedFarmEntry.Vaccination -> {
                    var tag by remember { mutableStateOf(entry.tag) }
                    var vaccine by remember { mutableStateOf(entry.vaccine) }
                    var dose by remember { mutableStateOf(entry.dose) }
                    var date by remember { mutableStateOf(entry.administeredDate) }
                    var nextDue by remember { mutableStateOf(entry.nextDueDate ?: "") }
                    var notes by remember { mutableStateOf(entry.notes ?: "") }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Record Type: ", fontWeight = FontWeight.Bold)
                        Text("Vaccination", color = FarmGreenPrimary, fontWeight = FontWeight.Bold)
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(value = tag, onValueChange = { tag = it }, label = { Text("Goat Tag") }, modifier = Modifier.fillMaxWidth())
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(value = vaccine, onValueChange = { vaccine = it }, label = { Text("Vaccine") }, modifier = Modifier.fillMaxWidth())
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(value = dose, onValueChange = { dose = it }, label = { Text("Dose") }, modifier = Modifier.fillMaxWidth())
                    Spacer(modifier = Modifier.height(8.dp))
                    DatePickerField(dateValue = date, onDateSelected = { date = it }, label = "Administered Date")
                    Spacer(modifier = Modifier.height(8.dp))
                    DatePickerField(dateValue = nextDue, onDateSelected = { nextDue = it }, label = "Next Due Date")
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(value = notes, onValueChange = { notes = it }, label = { Text("Notes") }, modifier = Modifier.fillMaxWidth())

                    Spacer(modifier = Modifier.height(16.dp))

                    ActionButtons(
                        isSaving = isSaving,
                        onConfirm = {
                            onConfirm(ParsedFarmEntry.Vaccination(tag, vaccine, dose, date, nextDue.ifBlank { null }, null, null, notes))
                        },
                        onDiscard = onDiscard
                    )
                }

                is ParsedFarmEntry.Deworming -> {
                    var tag by remember { mutableStateOf(entry.tag) }
                    var medicine by remember { mutableStateOf(entry.medicine) }
                    var dose by remember { mutableStateOf(entry.dose) }
                    var date by remember { mutableStateOf(entry.treatmentDate) }
                    var nextDue by remember { mutableStateOf(entry.nextDueDate ?: "") }
                    var notes by remember { mutableStateOf(entry.notes ?: "") }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Record Type: ", fontWeight = FontWeight.Bold)
                        Text("Deworming", color = FarmGreenPrimary, fontWeight = FontWeight.Bold)
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(value = tag, onValueChange = { tag = it }, label = { Text("Goat Tag") }, modifier = Modifier.fillMaxWidth())
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(value = medicine, onValueChange = { medicine = it }, label = { Text("Medicine") }, modifier = Modifier.fillMaxWidth())
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(value = dose, onValueChange = { dose = it }, label = { Text("Dose") }, modifier = Modifier.fillMaxWidth())
                    Spacer(modifier = Modifier.height(8.dp))
                    DatePickerField(dateValue = date, onDateSelected = { date = it }, label = "Treatment Date")
                    Spacer(modifier = Modifier.height(8.dp))
                    DatePickerField(dateValue = nextDue, onDateSelected = { nextDue = it }, label = "Next Due Date")
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(value = notes, onValueChange = { notes = it }, label = { Text("Notes") }, modifier = Modifier.fillMaxWidth())

                    Spacer(modifier = Modifier.height(16.dp))

                    ActionButtons(
                        isSaving = isSaving,
                        onConfirm = {
                            onConfirm(ParsedFarmEntry.Deworming(tag, medicine, dose, date, nextDue.ifBlank { null }, entry.weightAtTreatment, null, notes))
                        },
                        onDiscard = onDiscard
                    )
                }

                is ParsedFarmEntry.Treatment -> {
                    var tag by remember { mutableStateOf(entry.tag) }
                    var symptoms by remember { mutableStateOf(entry.symptoms) }
                    var diagnosis by remember { mutableStateOf(entry.diagnosis) }
                    var med by remember { mutableStateOf(entry.medicine) }
                    var dose by remember { mutableStateOf(entry.dose) }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Record Type: ", fontWeight = FontWeight.Bold)
                        Text("Medical Treatment", color = FarmGreenPrimary, fontWeight = FontWeight.Bold)
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(value = tag, onValueChange = { tag = it }, label = { Text("Goat Tag") }, modifier = Modifier.fillMaxWidth())
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(value = symptoms, onValueChange = { symptoms = it }, label = { Text("Symptoms") }, modifier = Modifier.fillMaxWidth())
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(value = diagnosis, onValueChange = { diagnosis = it }, label = { Text("Diagnosis") }, modifier = Modifier.fillMaxWidth())
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(value = med, onValueChange = { med = it }, label = { Text("Medicine") }, modifier = Modifier.fillMaxWidth())

                    Spacer(modifier = Modifier.height(16.dp))

                    ActionButtons(
                        isSaving = isSaving,
                        onConfirm = {
                            onConfirm(ParsedFarmEntry.Treatment(tag, symptoms, diagnosis, med, dose, entry.startDate, entry.notes))
                        },
                        onDiscard = onDiscard
                    )
                }

                is ParsedFarmEntry.NewGoat -> {
                    var tag by remember { mutableStateOf(entry.tag) }
                    var name by remember { mutableStateOf(entry.name) }
                    var breed by remember { mutableStateOf(entry.breed) }
                    var sex by remember { mutableStateOf(entry.sex) }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Record Type: ", fontWeight = FontWeight.Bold)
                        Text("New Goat Registration", color = FarmGreenPrimary, fontWeight = FontWeight.Bold)
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(value = tag, onValueChange = { tag = it }, label = { Text("Tag") }, modifier = Modifier.fillMaxWidth())
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Name") }, modifier = Modifier.fillMaxWidth())
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(value = breed, onValueChange = { breed = it }, label = { Text("Breed") }, modifier = Modifier.fillMaxWidth())
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(value = sex, onValueChange = { sex = it }, label = { Text("Sex") }, modifier = Modifier.fillMaxWidth())

                    Spacer(modifier = Modifier.height(16.dp))

                    ActionButtons(
                        isSaving = isSaving,
                        onConfirm = {
                            onConfirm(ParsedFarmEntry.NewGoat(name, tag, breed, sex, entry.weightKg, entry.notes))
                        },
                        onDiscard = onDiscard
                    )
                }
            }
        }
    }
}

@Composable
fun ActionButtons(
    isSaving: Boolean,
    onConfirm: () -> Unit,
    onDiscard: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        OutlinedButton(
            onClick = onDiscard,
            modifier = Modifier.weight(1f).height(48.dp),
            enabled = !isSaving
        ) {
            Text(t("ai.discard"))
        }

        Button(
            onClick = onConfirm,
            modifier = Modifier.weight(1.5f).height(48.dp).testTag("confirm_save_to_supabase_button"),
            colors = ButtonDefaults.buttonColors(containerColor = FarmGreenPrimary),
            enabled = !isSaving
        ) {
            if (isSaving) {
                CircularProgressIndicator(color = Color.White, modifier = Modifier.size(20.dp))
            } else {
                Icon(Icons.Default.Check, contentDescription = null)
                Spacer(modifier = Modifier.width(6.dp))
                Text(t("ai.confirm_and_save"), fontWeight = FontWeight.Bold)
            }
        }
    }
}

suspend fun saveEntryToSupabase(
    entry: ParsedFarmEntry,
    repository: GoatRepository,
    goats: List<Goat>
): Result<String> {
    return when (entry) {
        is ParsedFarmEntry.Weight -> {
            var goat = goats.find { it.tag_c.equals(entry.tag, ignoreCase = true) }
            if (goat == null) {
                // If goat not found, create goat with this tag
                val newGoat = Goat(name = "Goat ${entry.tag}", tag_c = entry.tag, weight_kg_c = entry.weightKg)
                val addRes = repository.addGoat(newGoat)
                if (addRes.isFailure) return Result.failure(addRes.exceptionOrNull() ?: Exception("Cannot add goat"))
                goat = addRes.getOrThrow()
            }
            val record = GoatWeight(
                goat_id_c = goat.id,
                weight_kg_c = entry.weightKg,
                date_c = entry.date,
                method_c = entry.method,
                notes_c = entry.notes
            )
            val res = repository.recordWeight(record)
            if (res.isSuccess) {
                Result.success("Recorded ${entry.weightKg} kg for ${goat.name} (${goat.tag_c}) and updated goats_c.weight_kg_c.")
            } else {
                Result.failure(res.exceptionOrNull() ?: Exception("Failed to save weight"))
            }
        }

        is ParsedFarmEntry.Vaccination -> {
            var goat = goats.find { it.tag_c.equals(entry.tag, ignoreCase = true) }
            if (goat == null) {
                val newGoat = Goat(name = "Goat ${entry.tag}", tag_c = entry.tag)
                val addRes = repository.addGoat(newGoat)
                if (addRes.isFailure) return Result.failure(addRes.exceptionOrNull() ?: Exception("Cannot add goat"))
                goat = addRes.getOrThrow()
            }
            val vac = VaccinationRecord(
                goat_id_c = goat.id,
                vaccine_c = entry.vaccine,
                dose_c = entry.dose,
                administered_date_c = entry.administeredDate,
                next_due_date_c = entry.nextDueDate,
                notes_c = entry.notes
            )
            val res = repository.recordVaccination(vac)
            if (res.isSuccess) {
                Result.success("Recorded ${entry.vaccine} vaccination for ${goat.name} (${goat.tag_c}) in vaccinations_c.")
            } else {
                Result.failure(res.exceptionOrNull() ?: Exception("Failed to save vaccination"))
            }
        }

        is ParsedFarmEntry.Deworming -> {
            var goat = goats.find { it.tag_c.equals(entry.tag, ignoreCase = true) }
            if (goat == null) {
                val newGoat = Goat(name = "Goat ${entry.tag}", tag_c = entry.tag)
                val addRes = repository.addGoat(newGoat)
                if (addRes.isFailure) return Result.failure(addRes.exceptionOrNull() ?: Exception("Cannot add goat"))
                goat = addRes.getOrThrow()
            }
            val deworm = DewormingRecord(
                goat_id_c = goat.id,
                medicine_c = entry.medicine,
                dose_c = entry.dose,
                treatment_date_c = entry.treatmentDate,
                next_due_date_c = entry.nextDueDate,
                weight_at_treatment_c = entry.weightAtTreatment,
                notes_c = entry.notes
            )
            val res = repository.recordDeworming(deworm)
            if (res.isSuccess) {
                Result.success("Recorded ${entry.medicine} deworming for ${goat.name} (${goat.tag_c}) in deworming_records_c.")
            } else {
                Result.failure(res.exceptionOrNull() ?: Exception("Failed to save deworming"))
            }
        }

        is ParsedFarmEntry.Treatment -> {
            var goat = goats.find { it.tag_c.equals(entry.tag, ignoreCase = true) }
            if (goat == null) {
                val newGoat = Goat(name = "Goat ${entry.tag}", tag_c = entry.tag)
                val addRes = repository.addGoat(newGoat)
                if (addRes.isFailure) return Result.failure(addRes.exceptionOrNull() ?: Exception("Cannot add goat"))
                goat = addRes.getOrThrow()
            }
            val treatment = TreatmentRecord(
                goat_id_c = goat.id,
                symptoms_c = entry.symptoms,
                diagnosis_c = entry.diagnosis,
                medicine_c = entry.medicine,
                dose_c = entry.dose,
                start_date_c = entry.startDate,
                notes_c = entry.notes
            )
            val res = repository.recordTreatment(treatment)
            if (res.isSuccess) {
                Result.success("Recorded treatment for ${goat.name} (${goat.tag_c}) in treatments_c.")
            } else {
                Result.failure(res.exceptionOrNull() ?: Exception("Failed to save treatment"))
            }
        }

        is ParsedFarmEntry.NewGoat -> {
            val newGoat = Goat(
                name = entry.name,
                tag_c = entry.tag,
                breed_c = entry.breed,
                sex_c = entry.sex,
                weight_kg_c = entry.weightKg,
                notes_c = entry.notes
            )
            val res = repository.addGoat(newGoat)
            if (res.isSuccess) {
                Result.success("Added new goat ${entry.name} (${entry.tag}) to goats_c.")
            } else {
                Result.failure(res.exceptionOrNull() ?: Exception("Failed to add goat"))
            }
        }
    }
}
