package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.pedigree.AnimalOrigin
import com.example.data.pedigree.GoatPedigree
import com.example.data.pedigree.PedigreeManager
import com.example.data.pedigree.PedigreeNode
import com.example.data.supabase.*
import com.example.i18n.t
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.TimeUnit

/**
 * Reusable, commercial-grade Goat Profile screen component.
 * Features a dedicated Pedigree section differentiating between 'Farm Born' and 'Market Bought'
 * origins, displaying lineage via sire_id / dam_id for Farm Born goats, and showing 'Unknown' status
 * for Market Bought goats as required.
 */
@Composable
fun GoatProfileComponent(
    goat: Goat,
    allGoats: List<Goat>,
    weights: List<GoatWeight> = emptyList(),
    vaccinations: List<VaccinationRecord> = emptyList(),
    dewormings: List<DewormingRecord> = emptyList(),
    treatments: List<TreatmentRecord> = emptyList(),
    matings: List<MatingRecord> = emptyList(),
    pregnancies: List<PregnancyRecord> = emptyList(),
    kiddings: List<KiddingRecord> = emptyList(),
    initialTab: Int = 0,
    onOpenGoat: (Goat) -> Unit = {},
    onRecordWeight: () -> Unit = {},
    onVaccinate: () -> Unit = {},
    onDeworm: () -> Unit = {},
    onTreatment: () -> Unit = {},
    onBreeding: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    var selectedTab by remember { mutableIntStateOf(initialTab) }

    // Direct offspring / progeny in the herd
    val offspring = remember(goat.id, goat.tag_c, allGoats) {
        allGoats.filter { g ->
            val matchesSire = !goat.tag_c.isBlank() && (g.sire_c?.trim()?.equals(goat.tag_c.trim(), ignoreCase = true) == true ||
                    g.sire_id?.trim()?.equals(goat.id, ignoreCase = true) == true ||
                    g.sire_id?.trim()?.equals(goat.tag_c.trim(), ignoreCase = true) == true)
            val matchesDam = !goat.tag_c.isBlank() && (g.dam_c?.trim()?.equals(goat.tag_c.trim(), ignoreCase = true) == true ||
                    g.dam_id?.trim()?.equals(goat.id, ignoreCase = true) == true ||
                    g.dam_id?.trim()?.equals(goat.tag_c.trim(), ignoreCase = true) == true)
            matchesSire || matchesDam
        }
    }

    val latestWeight = weights.firstOrNull()?.weight_kg_c ?: goat.weight_kg_c

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFFF8F9FA))
    ) {
        // Hero Header & Identity Card
        ProfileHeroCard(
            goat = goat,
            latestWeight = latestWeight,
            offspringCount = offspring.size,
            onRecordWeight = onRecordWeight,
            onVaccinate = onVaccinate,
            onDeworm = onDeworm,
            onTreatment = onTreatment,
            onBreeding = onBreeding
        )

        // Navigation Tabs
        ScrollableTabRow(
            selectedTabIndex = selectedTab,
            containerColor = Color.White,
            contentColor = FarmGreenDark,
            edgePadding = 12.dp
        ) {
            Tab(
                selected = selectedTab == 0,
                onClick = { selectedTab = 0 },
                text = { Text(t("profile.tab_overview"), fontWeight = FontWeight.Bold) },
                modifier = Modifier.testTag("profile_tab_overview")
            )
            Tab(
                selected = selectedTab == 1,
                onClick = { selectedTab = 1 },
                text = { Text(t("profile.tab_pedigree"), fontWeight = FontWeight.Bold) },
                modifier = Modifier.testTag("profile_tab_pedigree")
            )
            Tab(
                selected = selectedTab == 2,
                onClick = { selectedTab = 2 },
                text = {
                    val healthCount = vaccinations.size + dewormings.size + treatments.size
                    Text("${t("profile.tab_health")} ($healthCount)", fontWeight = FontWeight.Bold)
                },
                modifier = Modifier.testTag("profile_tab_health")
            )
            Tab(
                selected = selectedTab == 3,
                onClick = { selectedTab = 3 },
                text = {
                    val breedingCount = matings.size + pregnancies.size + kiddings.size
                    Text("${t("profile.tab_breeding")} ($breedingCount)", fontWeight = FontWeight.Bold)
                },
                modifier = Modifier.testTag("profile_tab_breeding")
            )
        }

        // Tab Content
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            when (selectedTab) {
                0 -> ProfileOverviewContent(
                    goat = goat,
                    offspringCount = offspring.size
                )
                1 -> GoatPedigreeSection(
                    goat = goat,
                    allGoats = allGoats,
                    offspring = offspring,
                    onOpenGoat = onOpenGoat
                )
                2 -> ProfileHealthContent(
                    weights = weights,
                    vaccinations = vaccinations,
                    dewormings = dewormings,
                    treatments = treatments,
                    onRecordWeight = onRecordWeight,
                    onVaccinate = onVaccinate,
                    onDeworm = onDeworm,
                    onTreatment = onTreatment
                )
                3 -> ProfileBreedingContent(
                    goat = goat,
                    allGoats = allGoats,
                    matings = matings,
                    pregnancies = pregnancies,
                    kiddings = kiddings,
                    offspring = offspring,
                    onNavigateToBreeding = onBreeding
                )
            }
        }
    }
}

/**
 * Dedicated Pedigree Section Component.
 * - Differentiates between 'Farm Born' and 'Market Bought' origins
 * - For 'Farm Born': displays parents/lineage via sire_id and dam_id, 3-generation pedigree tree, and progeny
 * - For 'Market Bought': displays 'Unknown' status for sire and dam, purchase details, and no invented ancestors
 */
@Composable
fun GoatPedigreeSection(
    goat: Goat,
    allGoats: List<Goat>,
    offspring: List<Goat> = emptyList(),
    onOpenGoat: (Goat) -> Unit = {},
    modifier: Modifier = Modifier
) {
    val isFarmBorn = goat.effectiveOrigin == AnimalOrigin.FARM_BORN
    val isMarketBought = goat.effectiveOrigin == AnimalOrigin.MARKET_BOUGHT
    val pedigree = PedigreeManager.buildPedigree(goat, allGoats)

    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Primary Origin & Pedigree Status Banner
        Card(
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(
                containerColor = if (isFarmBorn) Color(0xFFF1F8E9) else if (isMarketBought) Color(0xFFE3F2FD) else Color(0xFFFAFAFA)
            ),
            border = androidx.compose.foundation.BorderStroke(
                1.5.dp,
                if (isFarmBorn) FarmGreenPrimary else if (isMarketBought) Color(0xFF1976D2) else Color(0xFFBDBDBD)
            ),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Header with Origin Title and Badge
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = if (isFarmBorn) Icons.Default.AccountTree else if (isMarketBought) Icons.Default.Storefront else Icons.Default.HelpOutline,
                            contentDescription = null,
                            tint = if (isFarmBorn) FarmGreenDark else if (isMarketBought) Color(0xFF0D47A1) else Color(0xFF616161),
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = if (isFarmBorn) "Farm-Born Heritage & Lineage" else if (isMarketBought) "Market-Bought Animal (No On-Farm Pedigree)" else "Origin: Unknown",
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp,
                                color = if (isFarmBorn) FarmGreenDark else if (isMarketBought) Color(0xFF0D47A1) else Color(0xFF212121)
                            )
                            Text(
                                text = if (isFarmBorn) "Tracked lineage via on-farm sire and dam IDs" else if (isMarketBought) "Ancestral status: Unknown • No artificial ancestors" else "Origin not verified",
                                fontSize = 11.sp,
                                color = if (isFarmBorn) FarmGreenPrimary else if (isMarketBought) Color(0xFF1565C0) else Color(0xFF757575)
                            )
                        }
                    }
                    OriginBadge(origin = goat.effectiveOrigin)
                }

                HorizontalDivider(
                    color = if (isFarmBorn) FarmGreenContainer else if (isMarketBought) Color(0xFFBBDEFB) else Color(0xFFE0E0E0),
                    thickness = 1.dp
                )

                // Differentiated Display by Origin
                if (isMarketBought) {
                    // Market Bought: Display Parents as 'Unknown'
                    MarketBoughtPedigreeCard(goat = goat)
                } else if (isFarmBorn) {
                    // Farm Born: Display Parents via sire_id / dam_id
                    FarmBornPedigreeCard(
                        goat = goat,
                        allGoats = allGoats,
                        onOpenGoat = onOpenGoat
                    )
                } else {
                    // Unknown Origin fallback
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Info, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Origin is not confirmed. Lineage cannot be conclusively verified.",
                            fontSize = 12.sp,
                            color = Color.DarkGray
                        )
                    }
                }
            }
        }

        // Multi-generation Pedigree Tree (for Farm-Born or goats with recorded parents)
        if (isFarmBorn || pedigree.hasPedigreeData) {
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Multi-Generation Pedigree Tree",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = FarmGreenDark
                        )
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = FarmGreenContainer
                        ) {
                            Text(
                                text = "3 Generations",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = FarmGreenDark,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                            )
                        }
                    }
                    Text(
                        text = "Complete ancestral pedigree reconstructed from on-farm birth records. Click any ancestor to view their profile.",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    HorizontalDivider(color = Color(0xFFEEEEEE))

                    PedigreeColumnView(
                        goat = goat,
                        allGoats = allGoats,
                        onOpenGoat = onOpenGoat
                    )
                }
            }
        }

        // Offspring / Progeny in Herd
        Card(
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "${t("profile.section_offspring")} (${offspring.size})",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = FarmGreenDark
                    )
                    if (offspring.isNotEmpty()) {
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = FarmGreenContainer
                        ) {
                            Text(
                                text = "${offspring.size} Offspring",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = FarmGreenDark,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                            )
                        }
                    }
                }
                HorizontalDivider(color = Color(0xFFEEEEEE))

                if (offspring.isEmpty()) {
                    Text(
                        text = if (isMarketBought) "No offspring recorded on this farm since acquisition." else t("profile.no_offspring"),
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(vertical = 8.dp)
                    )
                } else {
                    offspring.forEach { kid ->
                        OffspringRowCard(kid = kid, onOpenGoat = onOpenGoat)
                    }
                }
            }
        }
    }
}

/**
 * Dedicated display for Farm-Born goats using sire_id and dam_id fields.
 */
@Composable
private fun FarmBornPedigreeCard(
    goat: Goat,
    allGoats: List<Goat>,
    onOpenGoat: (Goat) -> Unit
) {
    val sireId = goat.effectiveSireId
    val damId = goat.effectiveDamId

    val sireGoat = PedigreeManager.findGoat(sireId, allGoats)
    val damGoat = PedigreeManager.findGoat(damId, allGoats)

    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        // Sire Information Row
        ParentRecordCard(
            roleLabel = "Sire (Father)",
            idFieldLabel = "sire_id",
            recordedId = sireId,
            parentGoat = sireGoat,
            isSire = true,
            onOpenGoat = onOpenGoat
        )

        // Dam Information Row
        ParentRecordCard(
            roleLabel = "Dam (Mother)",
            idFieldLabel = "dam_id",
            recordedId = damId,
            parentGoat = damGoat,
            isSire = false,
            onOpenGoat = onOpenGoat
        )

        Surface(
            shape = RoundedCornerShape(8.dp),
            color = Color(0xFFE8F5E9),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier.padding(10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.Verified, contentDescription = null, tint = FarmGreenDark, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Farm-born lineage verified using registered sire_id and dam_id records.",
                    fontSize = 11.sp,
                    color = FarmGreenDark,
                    fontWeight = FontWeight.Medium
                )
            }
        }
    }
}

/**
 * Dedicated display for Market-Bought goats showing 'Unknown' status for sire and dam as required.
 */
@Composable
private fun MarketBoughtPedigreeCard(goat: Goat) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        // Unknown Status Grid
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = Color.White,
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFBBDEFB)),
                modifier = Modifier.weight(1f)
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text(
                        text = "Sire (Father)",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Color(0xFF0D47A1)
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "sire_id: Unknown",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF1565C0)
                    )
                    Text(
                        text = "Status: Unknown",
                        fontSize = 11.sp,
                        color = Color(0xFF1976D2)
                    )
                }
            }

            Surface(
                shape = RoundedCornerShape(8.dp),
                color = Color.White,
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFBBDEFB)),
                modifier = Modifier.weight(1f)
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text(
                        text = "Dam (Mother)",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Color(0xFF0D47A1)
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "dam_id: Unknown",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF1565C0)
                    )
                    Text(
                        text = "Status: Unknown",
                        fontSize = 11.sp,
                        color = Color(0xFF1976D2)
                    )
                }
            }
        }

        // Informational Explanation Card
        Surface(
            shape = RoundedCornerShape(8.dp),
            color = Color(0xFFE3F2FD),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Info, contentDescription = null, tint = Color(0xFF0D47A1), modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Market-Bought Lineage Policy",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF0D47A1)
                    )
                }
                Text(
                    text = "Market-bought goats do not require farm pedigree information. Parents remain Unknown as per farm breeding rules. No artificial lineage is invented.",
                    fontSize = 11.sp,
                    color = Color(0xFF1565C0),
                    lineHeight = 15.sp
                )
            }
        }

        // Acquisition Info Card if available
        if (!goat.purchase_date_c.isNullOrBlank() || goat.purchase_cost_c != null) {
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = Color.White,
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE0E0E0)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        text = "Acquisition Record",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF424242)
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Purchase Date: ${goat.purchase_date_c ?: "--"}",
                            fontSize = 12.sp,
                            color = Color(0xFF616161)
                        )
                        if (goat.purchase_cost_c != null) {
                            Text(
                                text = "Cost: ₹${goat.purchase_cost_c}",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = FarmGreenDark
                            )
                        }
                    }
                    if (!goat.source_c.isNullOrBlank()) {
                        Text(
                            text = "Source: ${goat.source_c}",
                            fontSize = 11.sp,
                            color = Color(0xFF757575)
                        )
                    }
                }
            }
        }
    }
}

/**
 * Reusable Parent Card displaying sire_id or dam_id with herd lookup.
 */
@Composable
private fun ParentRecordCard(
    roleLabel: String,
    idFieldLabel: String,
    recordedId: String?,
    parentGoat: Goat?,
    isSire: Boolean,
    onOpenGoat: (Goat) -> Unit
) {
    Card(
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE0E0E0)),
        modifier = Modifier
            .fillMaxWidth()
            .then(if (parentGoat != null) Modifier.clickable { onOpenGoat(parentGoat) } else Modifier)
            .testTag("parent_card_$idFieldLabel")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = roleLabel,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        color = if (isSire) Color(0xFF1565C0) else Color(0xFFC2185B)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Surface(
                        shape = RoundedCornerShape(4.dp),
                        color = Color(0xFFF5F5F5)
                    ) {
                        Text(
                            text = "$idFieldLabel: ${recordedId ?: "Not recorded"}",
                            fontSize = 10.sp,
                            color = Color(0xFF616161),
                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                        )
                    }
                }

                if (parentGoat != null) {
                    Text(
                        text = "${parentGoat.name} (${parentGoat.tag_c})",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = Color(0xFF212121)
                    )
                    Text(
                        text = "Breed: ${parentGoat.breed_c} • Status: ${parentGoat.status_c}",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                } else if (!recordedId.isNullOrBlank()) {
                    Text(
                        text = "Tag: $recordedId",
                        fontWeight = FontWeight.Medium,
                        fontSize = 13.sp,
                        color = Color(0xFF424242)
                    )
                    Text(
                        text = "Recorded in birth record",
                        fontSize = 11.sp,
                        color = Color.Gray
                    )
                } else {
                    Text(
                        text = "Not recorded",
                        fontSize = 12.sp,
                        color = Color.Gray
                    )
                }
            }

            if (parentGoat != null) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "View",
                        fontSize = 12.sp,
                        color = FarmGreenPrimary,
                        fontWeight = FontWeight.SemiBold
                    )
                    Icon(
                        imageVector = Icons.Default.ChevronRight,
                        contentDescription = "View Parent",
                        tint = FarmGreenPrimary,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
    }
}

/**
 * Clickable row for offspring in herd.
 */
@Composable
private fun OffspringRowCard(
    kid: Goat,
    onOpenGoat: (Goat) -> Unit
) {
    Card(
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFFAFAFA)),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onOpenGoat(kid) }
            .testTag("offspring_item_${kid.tag_c}")
    ) {
        Row(
            modifier = Modifier
                .padding(10.dp)
                .fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                TagBadge(
                    tag = kid.tag_c,
                    isBuck = kid.sex_c.equals("Buck", ignoreCase = true),
                    isKid = kid.sex_c.equals("Kid", ignoreCase = true)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = kid.name,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                    Text(
                        text = "${kid.breed_c} • ${kid.sex_c} • DOB: ${kid.birth_date_c ?: "--"}",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "Profile",
                    fontSize = 11.sp,
                    color = FarmGreenPrimary,
                    fontWeight = FontWeight.SemiBold
                )
                Icon(
                    imageVector = Icons.Default.ChevronRight,
                    contentDescription = null,
                    tint = FarmGreenPrimary,
                    modifier = Modifier.size(16.dp)
                )
            }
        }
    }
}

/**
 * Hero identity card showing picture, tags, age, weight, and quick actions.
 */
@Composable
private fun ProfileHeroCard(
    goat: Goat,
    latestWeight: Double?,
    offspringCount: Int,
    onRecordWeight: () -> Unit,
    onVaccinate: () -> Unit,
    onDeworm: () -> Unit,
    onTreatment: () -> Unit,
    onBreeding: () -> Unit
) {
    val isBuck = goat.sex_c.equals("Buck", ignoreCase = true)
    val isKid = goat.sex_c.equals("Kid", ignoreCase = true)

    Card(
        shape = RoundedCornerShape(0.dp, 0.dp, 16.dp, 16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Identity Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(54.dp)
                            .clip(CircleShape)
                            .background(if (isBuck) Color(0xFFE3F2FD) else FarmGreenContainer),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Pets,
                            contentDescription = null,
                            tint = if (isBuck) Color(0xFF1565C0) else FarmGreenDark,
                            modifier = Modifier.size(28.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            TagBadge(tag = goat.tag_c, isBuck = isBuck, isKid = isKid)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = goat.name,
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold,
                                color = FarmGreenDark
                            )
                        }
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "${goat.breed_c} • ${goat.sex_c}",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    OriginBadge(origin = goat.effectiveOrigin)
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = when (goat.status_c.lowercase()) {
                            "active" -> FarmGreenContainer
                            "pregnant" -> Color(0xFFFFF3E0)
                            "sold" -> Color(0xFFE0E0E0)
                            "quarantine", "sick" -> FarmErrorContainer
                            else -> Color(0xFFF5F5F5)
                        }
                    ) {
                        Text(
                            text = goat.status_c,
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = when (goat.status_c.lowercase()) {
                                "active" -> FarmGreenDark
                                "pregnant" -> Color(0xFFE65100)
                                "sold" -> Color(0xFF616161)
                                "quarantine", "sick" -> FarmError
                                else -> Color(0xFF424242)
                            },
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Quick Stats Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                QuickStatCard(
                    icon = Icons.Default.Scale,
                    label = "Weight",
                    value = if (latestWeight != null) "$latestWeight kg" else "--",
                    modifier = Modifier.weight(1f)
                )
                QuickStatCard(
                    icon = Icons.Default.Cake,
                    label = "Age",
                    value = formatAge(goat.birth_date_c),
                    modifier = Modifier.weight(1f)
                )
                QuickStatCard(
                    icon = Icons.Default.Favorite,
                    label = "Health",
                    value = goat.health_status_c ?: "Healthy",
                    modifier = Modifier.weight(1f)
                )
                QuickStatCard(
                    icon = Icons.Default.ChildCare,
                    label = "Kids",
                    value = "$offspringCount",
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Quick Action Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                ActionChip(
                    label = "+ Weight",
                    icon = Icons.Default.Scale,
                    onClick = onRecordWeight,
                    tag = "hero_action_weight",
                    modifier = Modifier.weight(1f)
                )
                ActionChip(
                    label = "+ Vaccine",
                    icon = Icons.Default.Vaccines,
                    onClick = onVaccinate,
                    tag = "hero_action_vaccine",
                    modifier = Modifier.weight(1f)
                )
                ActionChip(
                    label = "+ Deworm",
                    icon = Icons.Default.Medication,
                    onClick = onDeworm,
                    tag = "hero_action_deworm",
                    modifier = Modifier.weight(1f)
                )
                ActionChip(
                    label = "Breeding",
                    icon = Icons.Default.FavoriteBorder,
                    onClick = onBreeding,
                    tag = "hero_action_breeding",
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}

@Composable
private fun QuickStatCard(
    icon: ImageVector,
    label: String,
    value: String,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(10.dp),
        color = Color(0xFFF7F8F7),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE8ECE8)),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(icon, contentDescription = null, tint = FarmGreenPrimary, modifier = Modifier.size(13.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = label,
                    fontSize = 10.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1
                )
            }
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = value,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = FarmGreenDark,
                maxLines = 1
            )
        }
    }
}

@Composable
private fun ActionChip(
    label: String,
    icon: ImageVector,
    onClick: () -> Unit,
    tag: String,
    modifier: Modifier = Modifier
) {
    OutlinedButton(
        onClick = onClick,
        shape = RoundedCornerShape(8.dp),
        contentPadding = PaddingValues(horizontal = 6.dp, vertical = 6.dp),
        colors = ButtonDefaults.outlinedButtonColors(contentColor = FarmGreenDark),
        modifier = modifier.testTag(tag)
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(icon, contentDescription = null, modifier = Modifier.size(14.dp))
            Text(text = label, fontSize = 10.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
        }
    }
}

@Composable
private fun ProfileOverviewContent(
    goat: Goat,
    offspringCount: Int
) {
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Card(
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = t("profile.section_basic"),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = FarmGreenDark
                )
                HorizontalDivider(color = Color(0xFFEEEEEE))

                InfoRow(label = t("add_goat.tag_label"), value = goat.tag_c)
                InfoRow(label = t("add_goat.name_label"), value = goat.name)
                InfoRow(label = t("pedigree.breed"), value = goat.breed_c)
                InfoRow(label = t("add_goat.sex_label"), value = goat.sex_c)
                InfoRow(label = t("herd.status"), value = goat.status_c)
                InfoRow(label = t("add_goat.dob_label"), value = goat.birth_date_c ?: "--")
                InfoRow(label = t("add_goat.weight_label"), value = "${goat.weight_kg_c ?: "--"} kg")
                InfoRow(label = "Color / Coat", value = goat.color_c ?: "--")
                InfoRow(label = "Pen / Location", value = goat.farm_location_c ?: "Barn A")
            }
        }

        Card(
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = t("profile.section_origin"),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = FarmGreenDark
                    )
                    OriginBadge(origin = goat.effectiveOrigin)
                }
                HorizontalDivider(color = Color(0xFFEEEEEE))

                when (goat.effectiveOrigin) {
                    AnimalOrigin.MARKET_BOUGHT -> {
                        InfoRow(label = "Acquisition", value = t("pedigree.market_bought"))
                        InfoRow(label = "Purchase Date", value = goat.purchase_date_c ?: "--")
                        InfoRow(label = "Purchase Cost", value = if (goat.purchase_cost_c != null) "₹${goat.purchase_cost_c}" else "--")
                        InfoRow(label = "Sire (sire_id)", value = t("pedigree.status_unknown"))
                        InfoRow(label = "Dam (dam_id)", value = t("pedigree.status_unknown"))
                    }
                    AnimalOrigin.FARM_BORN -> {
                        InfoRow(label = "Origin", value = t("pedigree.farm_born"))
                        InfoRow(label = "${t("pedigree.sire")} (sire_id)", value = goat.effectiveSireId ?: "Not recorded")
                        InfoRow(label = "${t("pedigree.dam")} (dam_id)", value = goat.effectiveDamId ?: "Not recorded")
                        InfoRow(label = "Recorded Birth", value = goat.birth_date_c ?: "--")
                    }
                    else -> {
                        InfoRow(label = "Origin", value = t("pedigree.unknown_origin"))
                    }
                }
            }
        }
    }
}

@Composable
private fun ProfileHealthContent(
    weights: List<GoatWeight>,
    vaccinations: List<VaccinationRecord>,
    dewormings: List<DewormingRecord>,
    treatments: List<TreatmentRecord>,
    onRecordWeight: () -> Unit,
    onVaccinate: () -> Unit,
    onDeworm: () -> Unit,
    onTreatment: () -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        // Vaccination Section
        Card(
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Vaccinations (${vaccinations.size})",
                        fontWeight = FontWeight.Bold,
                        color = FarmGreenDark
                    )
                    TextButton(onClick = onVaccinate) {
                        Text("+ Add Vaccine", color = FarmGreenPrimary, fontSize = 12.sp)
                    }
                }
                HorizontalDivider(color = Color(0xFFEEEEEE))

                if (vaccinations.isEmpty()) {
                    Text(text = "No vaccinations recorded yet.", fontSize = 12.sp, color = Color.Gray)
                } else {
                    vaccinations.forEach { vac ->
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = Color(0xFFFAFAFA),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(8.dp)) {
                                Text(text = vac.vaccine_c, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                Text(
                                    text = "Date: ${vac.administered_date_c} • Next Due: ${vac.next_due_date_c ?: "--"}",
                                    fontSize = 11.sp,
                                    color = Color.DarkGray
                                )
                            }
                        }
                    }
                }
            }
        }

        // Deworming Section
        Card(
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Dewormings (${dewormings.size})",
                        fontWeight = FontWeight.Bold,
                        color = FarmGreenDark
                    )
                    TextButton(onClick = onDeworm) {
                        Text("+ Add Deworming", color = FarmGreenPrimary, fontSize = 12.sp)
                    }
                }
                HorizontalDivider(color = Color(0xFFEEEEEE))

                if (dewormings.isEmpty()) {
                    Text(text = "No deworming records logged yet.", fontSize = 12.sp, color = Color.Gray)
                } else {
                    dewormings.forEach { dew ->
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = Color(0xFFFAFAFA),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(8.dp)) {
                                Text(text = dew.medicine_c, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                Text(
                                    text = "Date: ${dew.treatment_date_c} • Dose: ${dew.dose_c}",
                                    fontSize = 11.sp,
                                    color = Color.DarkGray
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ProfileBreedingContent(
    goat: Goat,
    allGoats: List<Goat>,
    matings: List<MatingRecord>,
    pregnancies: List<PregnancyRecord>,
    kiddings: List<KiddingRecord>,
    offspring: List<Goat>,
    onNavigateToBreeding: () -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Card(
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Breeding History (${matings.size})",
                        fontWeight = FontWeight.Bold,
                        color = FarmGreenDark
                    )
                    TextButton(onClick = onNavigateToBreeding) {
                        Text("Breeding Hub", color = FarmGreenPrimary, fontSize = 12.sp)
                    }
                }
                HorizontalDivider(color = Color(0xFFEEEEEE))

                if (matings.isEmpty()) {
                    Text(text = "No mating records logged for this animal.", fontSize = 12.sp, color = Color.Gray)
                } else {
                    matings.forEach { m ->
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = Color(0xFFFAFAFA),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(8.dp)) {
                                Text(text = "Mating Date: ${m.mating_date_c}", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                Text(
                                    text = "Method: ${m.method_c} • Heat: ${if (m.heat_observed_c) "Observed" else "No"} • Notes: ${m.notes_c ?: "--"}",
                                    fontSize = 11.sp,
                                    color = Color.DarkGray
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun InfoRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = label, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(text = value, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFF212121))
    }
}

private fun formatAge(birthDateStr: String?): String {
    if (birthDateStr.isNullOrBlank()) return "--"
    return try {
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        val birthDate = sdf.parse(birthDateStr) ?: return "--"
        val diffMs = System.currentTimeMillis() - birthDate.time
        val days = TimeUnit.MILLISECONDS.toDays(diffMs)
        if (days < 0) return "--"
        val months = (days / 30.4375).toInt()
        val years = months / 12
        val remMonths = months % 12
        when {
            years > 0 -> "${years}y ${remMonths}m"
            months > 0 -> "${months}m"
            else -> "${days}d"
        }
    } catch (e: Exception) {
        "--"
    }
}
