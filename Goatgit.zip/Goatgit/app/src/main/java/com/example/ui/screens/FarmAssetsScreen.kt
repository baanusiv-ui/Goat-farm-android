package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.supabase.FarmAsset
import com.example.data.supabase.FarmAssetsSummary
import com.example.data.supabase.GoatRepository
import com.example.i18n.t
import com.example.ui.components.DatePickerField
import com.example.ui.theme.*
import com.example.util.CurrencyUtils
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FarmAssetsScreen(
    repository: GoatRepository,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler { onNavigateBack() }

    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val dateFormat = remember { SimpleDateFormat("yyyy-MM-dd", Locale.US) }
    val today = remember { dateFormat.format(Date()) }

    var assets by remember { mutableStateOf<List<FarmAsset>>(emptyList()) }
    var summary by remember { mutableStateOf(FarmAssetsSummary()) }
    var isLoading by remember { mutableStateOf(true) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    // Category Filter: "ALL", "Farm Buildings", "Farm Infrastructure", "Equipment", "Vehicles"
    var selectedCategory by remember { mutableStateOf("ALL") }
    var selectedConditionFilter by remember { mutableStateOf("ALL") }
    var searchQuery by remember { mutableStateOf("") }

    // Dialog states
    var showAddEditDialog by remember { mutableStateOf(false) }
    var editingAsset by remember { mutableStateOf<FarmAsset?>(null) }
    var viewingAssetDetail by remember { mutableStateOf<FarmAsset?>(null) }
    var assetToDelete by remember { mutableStateOf<FarmAsset?>(null) }
    var showSqlSchemaDialog by remember { mutableStateOf(false) }

    fun loadData() {
        isLoading = true
        errorMessage = null
        coroutineScope.launch {
            val assetsRes = repository.getFarmAssets()
            if (assetsRes.isSuccess) {
                assets = assetsRes.getOrThrow()
            } else {
                errorMessage = assetsRes.exceptionOrNull()?.message
            }

            val sumRes = repository.getFarmAssetsSummary()
            if (sumRes.isSuccess) {
                summary = sumRes.getOrThrow()
            }
            isLoading = false
        }
    }

    LaunchedEffect(Unit) {
        loadData()
    }

    val categories = listOf("ALL", "Farm Buildings", "Farm Infrastructure", "Equipment", "Vehicles")

    val filteredAssets = remember(assets, selectedCategory, selectedConditionFilter, searchQuery) {
        assets.filter { asset ->
            val matchesCategory = if (selectedCategory == "ALL") true else asset.category.equals(selectedCategory, ignoreCase = true)
            val matchesCondition = if (selectedConditionFilter == "ALL") true else asset.current_condition.equals(selectedConditionFilter, ignoreCase = true)
            val matchesSearch = if (searchQuery.isBlank()) true else {
                asset.name.contains(searchQuery, ignoreCase = true) ||
                (asset.asset_id?.contains(searchQuery, ignoreCase = true) == true) ||
                asset.location.contains(searchQuery, ignoreCase = true) ||
                (asset.supplier?.contains(searchQuery, ignoreCase = true) == true)
            }
            matchesCategory && matchesCondition && matchesSearch
        }.sortedByDescending { it.created_at ?: it.purchase_date ?: "" }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "Farm Assets & Infrastructure",
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp
                        )
                        Text(
                            text = "Live Sync with Supabase 'farm_assets' table",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack, modifier = Modifier.testTag("assets_back_btn")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    // SQL Schema button for Supabase table DDL
                    IconButton(
                        onClick = { showSqlSchemaDialog = true },
                        modifier = Modifier.testTag("assets_sql_schema_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.DataObject,
                            contentDescription = "Supabase Schema",
                            tint = FarmGreenDark
                        )
                    }
                    IconButton(
                        onClick = { loadData() },
                        modifier = Modifier.testTag("assets_refresh_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = "Refresh"
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color.White
                )
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = {
                    editingAsset = null
                    showAddEditDialog = true
                },
                containerColor = FarmGreenDark,
                contentColor = Color.White,
                icon = { Icon(Icons.Default.Add, contentDescription = "Add New Asset") },
                text = { Text("Add Asset", fontWeight = FontWeight.Bold) },
                modifier = Modifier
                    .testTag("fab_add_asset")
                    .testTag("assets_fab_add")
            )
        },
        modifier = modifier
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(Color(0xFFF8F9FA))
        ) {
            // Live Search Bar
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Search assets by name, ID, or location...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = FarmGreenDark) },
                trailingIcon = {
                    if (searchQuery.isNotBlank()) {
                        IconButton(onClick = { searchQuery = "" }) {
                            Icon(Icons.Default.Clear, contentDescription = "Clear search")
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = Color.White,
                    unfocusedContainerColor = Color.White,
                    focusedBorderColor = FarmGreenDark,
                    unfocusedBorderColor = Color(0xFFE0E0E0)
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp)
                    .testTag("assets_search_input")
            )

            // Category Filter Chips
            LazyRow(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(categories) { cat ->
                    val isSelected = selectedCategory == cat
                    FilterChip(
                        selected = isSelected,
                        onClick = { selectedCategory = cat },
                        label = { Text(if (cat == "ALL") "All Categories" else cat, fontSize = 12.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = FarmGreenDark,
                            selectedLabelColor = Color.White
                        )
                    )
                }
            }

            if (isLoading) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator(color = FarmGreenDark)
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .weight(1f)
                        .padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    contentPadding = PaddingValues(bottom = 80.dp)
                ) {
                    // Summary Banner Card
                    item {
                        Card(
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("assets_summary_card")
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Surface(
                                            shape = CircleShape,
                                            color = FarmGreenDark,
                                            modifier = Modifier.size(36.dp)
                                        ) {
                                            Box(contentAlignment = Alignment.Center) {
                                                Icon(
                                                    imageVector = Icons.Default.AccountBalance,
                                                    contentDescription = null,
                                                    tint = Color.White,
                                                    modifier = Modifier.size(20.dp)
                                                )
                                            }
                                        }
                                        Spacer(modifier = Modifier.width(10.dp))
                                        Column {
                                            Text(
                                                text = "Total Asset Portfolio",
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 15.sp,
                                                color = FarmGreenDark
                                            )
                                            Text(
                                                text = "${summary.totalAssetsCount} Assets Tracked • Straight-Line Depreciation",
                                                fontSize = 11.sp,
                                                color = Color.DarkGray
                                            )
                                        }
                                    }

                                    Surface(
                                        shape = RoundedCornerShape(8.dp),
                                        color = FarmGreenContainer
                                    ) {
                                        Text(
                                            text = "CAPEX",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = FarmGreenDark,
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(14.dp))
                                HorizontalDivider(color = Color(0xFFEEEEEE))
                                Spacer(modifier = Modifier.height(14.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    // Total CAPEX
                                    Surface(
                                        shape = RoundedCornerShape(10.dp),
                                        color = Color(0xFFF1F8E9),
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Column(modifier = Modifier.padding(10.dp)) {
                                            Text(
                                                text = "Total Cost (CAPEX)",
                                                fontSize = 10.sp,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                            Text(
                                                text = CurrencyUtils.formatInr(summary.totalCostCapex, includeDecimals = false),
                                                fontSize = 15.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = FarmGreenDark
                                            )
                                        }
                                    }

                                    // Book Value
                                    Surface(
                                        shape = RoundedCornerShape(10.dp),
                                        color = Color(0xFFE8F5E9),
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Column(modifier = Modifier.padding(10.dp)) {
                                            Text(
                                                text = "Current Book Value",
                                                fontSize = 10.sp,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                            Text(
                                                text = CurrencyUtils.formatInr(summary.currentBookValue, includeDecimals = false),
                                                fontSize = 15.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = FarmGreenDark
                                            )
                                        }
                                    }

                                    // Accumulated Depreciation
                                    Surface(
                                        shape = RoundedCornerShape(10.dp),
                                        color = Color(0xFFFFF3E0),
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Column(modifier = Modifier.padding(10.dp)) {
                                            Text(
                                                text = "Accum. Depreciation",
                                                fontSize = 10.sp,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                            Text(
                                                text = CurrencyUtils.formatInr(summary.accumulatedDepreciation, includeDecimals = false),
                                                fontSize = 15.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = Color(0xFFE65100)
                                            )
                                        }
                                    }
                                }

                                Spacer(modifier = Modifier.height(10.dp))

                                // Status chips row
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Text(
                                        text = "Active: ${summary.activeCount} • Maint: ${summary.underMaintenanceCount} • Damaged: ${summary.damagedCount}",
                                        fontSize = 11.sp,
                                        color = Color.DarkGray
                                    )
                                }
                            }
                        }
                    }

                    // Asset List Section Header
                    item {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Assets (${filteredAssets.size})",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = FarmGreenDark
                            )
                        }
                    }

                    if (filteredAssets.isEmpty()) {
                        item {
                            Card(
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = Color.White),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(24.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Construction,
                                        contentDescription = null,
                                        modifier = Modifier.size(48.dp),
                                        tint = Color.LightGray
                                    )
                                    Spacer(modifier = Modifier.height(12.dp))
                                    Text(
                                        text = "No farm assets recorded yet",
                                        fontWeight = FontWeight.Bold,
                                        color = Color.DarkGray
                                    )
                                    Text(
                                        text = "Add sheds, fencing, borewells, equipment, and vehicles to track CAPEX and depreciation.",
                                        fontSize = 12.sp,
                                        color = Color.Gray,
                                        textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                                        modifier = Modifier.padding(top = 4.dp)
                                    )
                                    Spacer(modifier = Modifier.height(16.dp))
                                    Button(
                                        onClick = {
                                            editingAsset = null
                                            showAddEditDialog = true
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = FarmGreenDark)
                                    ) {
                                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("Add First Asset")
                                    }
                                }
                            }
                        }
                    } else {
                        items(filteredAssets, key = { it.id }) { asset ->
                            AssetItemCard(
                                asset = asset,
                                onClick = { viewingAssetDetail = asset },
                                onEdit = {
                                    editingAsset = asset
                                    showAddEditDialog = true
                                },
                                onDelete = {
                                    assetToDelete = asset
                                }
                            )
                        }
                    }
                }
            }
        }
    }

    // View Asset Detail Dialog
    if (viewingAssetDetail != null) {
        AssetDetailDialog(
            asset = viewingAssetDetail!!,
            onDismiss = { viewingAssetDetail = null },
            onEdit = {
                val toEdit = viewingAssetDetail
                viewingAssetDetail = null
                editingAsset = toEdit
                showAddEditDialog = true
            },
            onDelete = {
                val toDelete = viewingAssetDetail
                viewingAssetDetail = null
                assetToDelete = toDelete
            }
        )
    }

    // Add / Edit Dialog
    if (showAddEditDialog) {
        AddEditAssetDialog(
            initialAsset = editingAsset,
            onDismiss = { showAddEditDialog = false },
            onSave = { asset ->
                showAddEditDialog = false
                coroutineScope.launch {
                    if (editingAsset == null) {
                        val res = repository.addFarmAsset(asset)
                        if (res.isSuccess) {
                            Toast.makeText(context, "Asset saved & queued to Supabase 'farm_assets'", Toast.LENGTH_SHORT).show()
                            loadData()
                        } else {
                            Toast.makeText(context, "Error: ${res.exceptionOrNull()?.message}", Toast.LENGTH_LONG).show()
                        }
                    } else {
                        val res = repository.updateFarmAsset(asset)
                        if (res.isSuccess) {
                            Toast.makeText(context, "Asset updated", Toast.LENGTH_SHORT).show()
                            loadData()
                        } else {
                            Toast.makeText(context, "Error: ${res.exceptionOrNull()?.message}", Toast.LENGTH_LONG).show()
                        }
                    }
                }
            }
        )
    }

    // Delete Confirmation Dialog
    if (assetToDelete != null) {
        AlertDialog(
            onDismissRequest = { assetToDelete = null },
            title = { Text("Delete Asset") },
            text = { Text("Are you sure you want to delete '${assetToDelete?.name}'? This will also remove it from Supabase.") },
            confirmButton = {
                Button(
                    onClick = {
                        val id = assetToDelete!!.id
                        assetToDelete = null
                        coroutineScope.launch {
                            val res = repository.deleteFarmAsset(id)
                            if (res.isSuccess) {
                                Toast.makeText(context, "Asset deleted", Toast.LENGTH_SHORT).show()
                                loadData()
                            } else {
                                Toast.makeText(context, "Failed to delete: ${res.exceptionOrNull()?.message}", Toast.LENGTH_LONG).show()
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = FarmError)
                ) {
                    Text("Delete")
                }
            },
            dismissButton = {
                TextButton(onClick = { assetToDelete = null }) {
                    Text("Cancel")
                }
            }
        )
    }

    // Supabase SQL Schema Dialog
    if (showSqlSchemaDialog) {
        val sqlScript = remember {
            """
CREATE TABLE IF NOT EXISTS public.farm_assets (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name TEXT NOT NULL,
    category TEXT NOT NULL,
    purchase_date DATE,
    cost NUMERIC(14, 2) NOT NULL DEFAULT 0.00,
    useful_life INTEGER NOT NULL DEFAULT 5,
    current_condition TEXT NOT NULL DEFAULT 'Good',
    location TEXT NOT NULL DEFAULT 'Main Shed',
    warranty_expiry DATE,
    maintenance_schedule TEXT DEFAULT 'Monthly',
    asset_id TEXT,
    supplier TEXT,
    quantity INTEGER NOT NULL DEFAULT 1,
    status TEXT NOT NULL DEFAULT 'Active',
    amc_expiry DATE,
    last_maintenance DATE,
    next_maintenance DATE,
    residual_value NUMERIC(14, 2) NOT NULL DEFAULT 0.00,
    depreciation_method TEXT NOT NULL DEFAULT 'Straight-line',
    accumulated_depreciation NUMERIC(14, 2) NOT NULL DEFAULT 0.00,
    current_book_value NUMERIC(14, 2) NOT NULL DEFAULT 0.00,
    is_capex BOOLEAN NOT NULL DEFAULT true,
    notes TEXT,
    photo_url TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.farm_assets ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Allow public read access to farm_assets"
    ON public.farm_assets FOR SELECT USING (true);
CREATE POLICY "Allow public insert to farm_assets"
    ON public.farm_assets FOR INSERT WITH CHECK (true);
CREATE POLICY "Allow public update to farm_assets"
    ON public.farm_assets FOR UPDATE USING (true) WITH CHECK (true);
CREATE POLICY "Allow public delete from farm_assets"
    ON public.farm_assets FOR DELETE USING (true);
            """.trimIndent()
        }

        Dialog(onDismissRequest = { showSqlSchemaDialog = false }) {
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = Color.White,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp)
            ) {
                Column(
                    modifier = Modifier
                        .padding(16.dp)
                        .fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Supabase 'farm_assets' SQL",
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            color = FarmGreenDark
                        )
                        IconButton(onClick = { showSqlSchemaDialog = false }) {
                            Icon(Icons.Default.Close, contentDescription = "Close")
                        }
                    }

                    Text(
                        text = "Run this SQL in your Supabase SQL Editor if you want to deploy the schema directly to PostgreSQL.",
                        fontSize = 12.sp,
                        color = Color.Gray,
                        modifier = Modifier.padding(vertical = 6.dp)
                    )

                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = Color(0xFF263238),
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(max = 280.dp)
                    ) {
                        LazyColumn(modifier = Modifier.padding(12.dp)) {
                            item {
                                Text(
                                    text = sqlScript,
                                    color = Color(0xFFECEFF1),
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Button(
                        onClick = {
                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            clipboard.setPrimaryClip(ClipData.newPlainText("Supabase Schema", sqlScript))
                            Toast.makeText(context, "SQL schema copied to clipboard", Toast.LENGTH_SHORT).show()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = FarmGreenDark),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Copy SQL to Clipboard", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
private fun AssetDetailDialog(
    asset: FarmAsset,
    onDismiss: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = Color.White,
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 16.dp)
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .fillMaxWidth()
            ) {
                // Header with Category Icon and Status Pill
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = asset.name,
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp,
                            color = FarmGreenDark
                        )
                        Text(
                            text = "${asset.category} • ID: ${asset.asset_id ?: "--"}",
                            fontSize = 12.sp,
                            color = Color.DarkGray
                        )
                    }

                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = when (asset.status.lowercase()) {
                            "active" -> FarmGreenContainer
                            "under maintenance" -> Color(0xFFFFF3E0)
                            "damaged" -> Color(0xFFFFEBEE)
                            else -> Color(0xFFF5F5F5)
                        }
                    ) {
                        Text(
                            text = asset.status,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = when (asset.status.lowercase()) {
                                "active" -> FarmGreenDark
                                "under maintenance" -> Color(0xFFE65100)
                                "damaged" -> FarmError
                                else -> Color.DarkGray
                            },
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))
                HorizontalDivider(color = Color(0xFFEEEEEE))
                Spacer(modifier = Modifier.height(14.dp))

                LazyColumn(
                    modifier = Modifier
                        .weight(1f, fill = false)
                        .fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Depreciation & Cost Banner
                    item {
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = Color(0xFFF1F8E9),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text("Straight-Line Depreciation & Book Value", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = FarmGreenDark)
                                Spacer(modifier = Modifier.height(6.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column {
                                        Text("Initial Cost (CAPEX)", fontSize = 10.sp, color = Color.Gray)
                                        Text(CurrencyUtils.formatInr(asset.cost, includeDecimals = false), fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                    }
                                    Column {
                                        Text("Residual Salvage", fontSize = 10.sp, color = Color.Gray)
                                        Text(CurrencyUtils.formatInr(asset.residual_value, includeDecimals = false), fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                    }
                                    Column(horizontalAlignment = Alignment.End) {
                                        Text("Current Book Value", fontSize = 10.sp, color = Color.Gray)
                                        Text(CurrencyUtils.formatInr(asset.current_book_value, includeDecimals = false), fontWeight = FontWeight.Bold, fontSize = 13.sp, color = FarmGreenDark)
                                    }
                                }
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = "Annual Depreciation: ${CurrencyUtils.formatInr(asset.annualDepreciation, includeDecimals = false)}/yr (${CurrencyUtils.formatInr(asset.monthlyDepreciation, includeDecimals = false)}/mo) over ${asset.useful_life} yrs",
                                    fontSize = 11.sp,
                                    color = Color.DarkGray
                                )
                            }
                        }
                    }

                    // Key Details Grid
                    item {
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            DetailRow(label = "Physical Condition", value = asset.current_condition)
                            DetailRow(label = "Location", value = asset.location.ifBlank { "--" })
                            DetailRow(label = "Purchase Date", value = asset.purchase_date ?: "--")
                            DetailRow(label = "Useful Life", value = "${asset.useful_life} years")
                            DetailRow(label = "Maintenance Schedule", value = asset.maintenance_schedule ?: "Monthly")
                            DetailRow(label = "Next Maintenance", value = asset.next_maintenance ?: "Not Scheduled")
                            DetailRow(label = "Supplier / Contractor", value = asset.supplier ?: "--")
                            DetailRow(label = "Warranty Expiry", value = asset.warranty_expiry ?: "--")
                            DetailRow(label = "AMC Expiry", value = asset.amc_expiry ?: "--")
                            if (!asset.notes.isNullOrBlank()) {
                                DetailRow(label = "Notes / Specs", value = asset.notes)
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Action Buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedButton(
                        onClick = onDelete,
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = FarmError)
                    ) {
                        Icon(Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Delete")
                    }

                    Row {
                        TextButton(onClick = onDismiss) {
                            Text("Close")
                        }
                        Spacer(modifier = Modifier.width(6.dp))
                        Button(
                            onClick = onEdit,
                            colors = ButtonDefaults.buttonColors(containerColor = FarmGreenDark)
                        ) {
                            Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Edit")
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun DetailRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, fontSize = 12.sp, color = Color.Gray)
        Text(text = value, fontSize = 12.sp, fontWeight = FontWeight.Medium, color = Color.Black)
    }
}

@Composable
private fun AssetItemCard(
    asset: FarmAsset,
    onClick: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .testTag("asset_card_${asset.id}")
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Top Row: Category Icon & Title & Condition Badge
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    val icon = when (asset.category.lowercase()) {
                        "farm buildings", "building" -> Icons.Default.Apartment
                        "farm infrastructure", "infrastructure" -> Icons.Default.Fence
                        "equipment" -> Icons.Default.PrecisionManufacturing
                        "vehicles", "vehicle" -> Icons.Default.LocalShipping
                        else -> Icons.Default.Construction
                    }

                    Surface(
                        shape = CircleShape,
                        color = Color(0xFFF1F8E9),
                        modifier = Modifier.size(36.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(icon, contentDescription = null, tint = FarmGreenDark, modifier = Modifier.size(20.dp))
                        }
                    }

                    Spacer(modifier = Modifier.width(10.dp))

                    Column {
                        Text(
                            text = asset.name,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = Color(0xFF212121)
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = asset.category,
                                fontSize = 11.sp,
                                color = Color.Gray
                            )
                            if (!asset.asset_id.isNullOrBlank()) {
                                Text(" • ", fontSize = 11.sp, color = Color.Gray)
                                Text(
                                    text = asset.asset_id,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = FarmGreenDark
                                )
                            }
                        }
                    }
                }

                // Condition Badge
                val conditionColor = when (asset.current_condition.lowercase()) {
                    "excellent" -> Color(0xFF2E7D32)
                    "good" -> Color(0xFF388E3C)
                    "fair" -> Color(0xFFF57C00)
                    "poor" -> Color(0xFFE65100)
                    "damaged" -> Color(0xFFC62828)
                    else -> Color.DarkGray
                }

                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = conditionColor.copy(alpha = 0.12f)
                ) {
                    Text(
                        text = asset.current_condition,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = conditionColor,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))
            HorizontalDivider(color = Color(0xFFF5F5F5))
            Spacer(modifier = Modifier.height(10.dp))

            // Metrics row: Purchase Date, Useful Life, Location, Cost & Book Value
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text("Purchase Date", fontSize = 10.sp, color = Color.Gray)
                    Text(asset.purchase_date ?: "--", fontSize = 12.sp, fontWeight = FontWeight.Medium)
                }
                Column {
                    Text("Useful Life", fontSize = 10.sp, color = Color.Gray)
                    Text("${asset.useful_life} yrs", fontSize = 12.sp, fontWeight = FontWeight.Medium)
                }
                Column {
                    Text("Location", fontSize = 10.sp, color = Color.Gray)
                    Text(asset.location.ifBlank { "--" }, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text("Cost (CAPEX)", fontSize = 10.sp, color = Color.Gray)
                    Text(
                        CurrencyUtils.formatInr(asset.cost, includeDecimals = false),
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = FarmGreenDark
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Maintenance & Status details
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Build, contentDescription = null, modifier = Modifier.size(12.dp), tint = Color.Gray)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "Schedule: ${asset.maintenance_schedule ?: "Monthly"}" +
                                if (!asset.next_maintenance.isNullOrBlank()) " • Next: ${asset.next_maintenance}" else "",
                        fontSize = 11.sp,
                        color = Color.DarkGray
                    )
                }

                Row {
                    IconButton(onClick = onEdit, modifier = Modifier.size(30.dp)) {
                        Icon(Icons.Default.Edit, contentDescription = "Edit", modifier = Modifier.size(16.dp), tint = FarmGreenDark)
                    }
                    IconButton(onClick = onDelete, modifier = Modifier.size(30.dp)) {
                        Icon(Icons.Default.Delete, contentDescription = "Delete", modifier = Modifier.size(16.dp), tint = FarmError)
                    }
                }
            }

            if (!asset.warranty_expiry.isNullOrBlank() || !asset.amc_expiry.isNullOrBlank()) {
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    if (!asset.warranty_expiry.isNullOrBlank()) {
                        Text(
                            text = "Warranty Expiry: ${asset.warranty_expiry}",
                            fontSize = 10.sp,
                            color = Color.DarkGray
                        )
                    }
                    if (!asset.amc_expiry.isNullOrBlank()) {
                        Text(
                            text = "AMC Expiry: ${asset.amc_expiry}",
                            fontSize = 10.sp,
                            color = Color.DarkGray
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AddEditAssetDialog(
    initialAsset: FarmAsset?,
    onDismiss: () -> Unit,
    onSave: (FarmAsset) -> Unit
) {
    val isEdit = initialAsset != null
    var name by remember { mutableStateOf(initialAsset?.name ?: "") }
    var category by remember { mutableStateOf(initialAsset?.category ?: "Farm Buildings") }
    var purchaseDate by remember { mutableStateOf(initialAsset?.purchase_date ?: SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())) }
    var costStr by remember { mutableStateOf(if (initialAsset != null && initialAsset.cost > 0) initialAsset.cost.toString() else "") }
    var usefulLifeStr by remember { mutableStateOf(if (initialAsset != null) initialAsset.useful_life.toString() else "5") }
    var condition by remember { mutableStateOf(initialAsset?.current_condition ?: "Good") }
    var location by remember { mutableStateOf(initialAsset?.location ?: "Main Shed") }
    var warrantyExpiry by remember { mutableStateOf(initialAsset?.warranty_expiry ?: "") }
    var maintenanceSchedule by remember { mutableStateOf(initialAsset?.maintenance_schedule ?: "Monthly") }
    var nextMaintenance by remember { mutableStateOf(initialAsset?.next_maintenance ?: "") }
    var assetId by remember { mutableStateOf(initialAsset?.asset_id ?: "") }
    var supplier by remember { mutableStateOf(initialAsset?.supplier ?: "") }
    var residualValueStr by remember { mutableStateOf(if (initialAsset != null && initialAsset.residual_value > 0) initialAsset.residual_value.toString() else "0") }
    var status by remember { mutableStateOf(initialAsset?.status ?: "Active") }
    var notes by remember { mutableStateOf(initialAsset?.notes ?: "") }

    val categories = listOf("Farm Buildings", "Farm Infrastructure", "Equipment", "Vehicles")
    val conditions = listOf("Excellent", "Good", "Fair", "Poor", "Damaged")
    val schedules = listOf("Daily", "Weekly", "Monthly", "Quarterly", "Half-yearly", "Yearly")
    val statuses = listOf("Active", "Under maintenance", "Damaged", "Sold", "Disposed")

    var categoryExpanded by remember { mutableStateOf(false) }
    var conditionExpanded by remember { mutableStateOf(false) }
    var scheduleExpanded by remember { mutableStateOf(false) }
    var statusExpanded by remember { mutableStateOf(false) }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = Color.White,
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 16.dp)
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .fillMaxWidth()
            ) {
                Text(
                    text = if (isEdit) "Edit Farm Asset" else "Add New Farm Asset",
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    color = FarmGreenDark
                )
                Text(
                    text = "Stored in Supabase 'farm_assets' table",
                    fontSize = 11.sp,
                    color = Color.Gray,
                    modifier = Modifier.padding(bottom = 12.dp)
                )

                LazyColumn(
                    modifier = Modifier
                        .weight(1f, fill = false)
                        .fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Asset Name
                    item {
                        OutlinedTextField(
                            value = name,
                            onValueChange = { name = it },
                            label = { Text("Asset Name *") },
                            placeholder = { Text("e.g. Goat Shed A, Chaff Cutter, Tractor") },
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("asset_input_name")
                        )
                    }

                    // Category Dropdown
                    item {
                        ExposedDropdownMenuBox(
                            expanded = categoryExpanded,
                            onExpandedChange = { categoryExpanded = !categoryExpanded }
                        ) {
                            OutlinedTextField(
                                value = category,
                                onValueChange = {},
                                readOnly = true,
                                label = { Text("Category *") },
                                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = categoryExpanded) },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .menuAnchor()
                            )
                            ExposedDropdownMenu(
                                expanded = categoryExpanded,
                                onDismissRequest = { categoryExpanded = false }
                            ) {
                                categories.forEach { cat ->
                                    DropdownMenuItem(
                                        text = { Text(cat) },
                                        onClick = {
                                            category = cat
                                            categoryExpanded = false
                                        }
                                    )
                                }
                            }
                        }
                    }

                    // Asset ID / Tag & Location
                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedTextField(
                                value = assetId,
                                onValueChange = { assetId = it },
                                label = { Text("Asset ID") },
                                placeholder = { Text("AST-001") },
                                singleLine = true,
                                modifier = Modifier.weight(1f)
                            )
                            OutlinedTextField(
                                value = location,
                                onValueChange = { location = it },
                                label = { Text("Location") },
                                placeholder = { Text("Barn A") },
                                singleLine = true,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }

                    // Cost (₹ CAPEX) & Useful Life (Years)
                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedTextField(
                                value = costStr,
                                onValueChange = { costStr = it },
                                label = { Text("Cost (₹ CAPEX) *") },
                                placeholder = { Text("50000") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                singleLine = true,
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("asset_input_cost")
                            )
                            OutlinedTextField(
                                value = usefulLifeStr,
                                onValueChange = { usefulLifeStr = it },
                                label = { Text("Useful Life (Yrs)") },
                                placeholder = { Text("5") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                singleLine = true,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }

                    // Purchase Date
                    item {
                        DatePickerField(
                            dateValue = purchaseDate,
                            onDateSelected = { purchaseDate = it },
                            label = "Purchase / Construction Date"
                        )
                    }

                    // Current Condition & Status
                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            // Condition
                            ExposedDropdownMenuBox(
                                expanded = conditionExpanded,
                                onExpandedChange = { conditionExpanded = !conditionExpanded },
                                modifier = Modifier.weight(1f)
                            ) {
                                OutlinedTextField(
                                    value = condition,
                                    onValueChange = {},
                                    readOnly = true,
                                    label = { Text("Condition") },
                                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = conditionExpanded) },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .menuAnchor()
                                )
                                ExposedDropdownMenu(
                                    expanded = conditionExpanded,
                                    onDismissRequest = { conditionExpanded = false }
                                ) {
                                    conditions.forEach { cond ->
                                        DropdownMenuItem(
                                            text = { Text(cond) },
                                            onClick = {
                                                condition = cond
                                                conditionExpanded = false
                                            }
                                        )
                                    }
                                }
                            }

                            // Status
                            ExposedDropdownMenuBox(
                                expanded = statusExpanded,
                                onExpandedChange = { statusExpanded = !statusExpanded },
                                modifier = Modifier.weight(1f)
                            ) {
                                OutlinedTextField(
                                    value = status,
                                    onValueChange = {},
                                    readOnly = true,
                                    label = { Text("Status") },
                                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = statusExpanded) },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .menuAnchor()
                                )
                                ExposedDropdownMenu(
                                    expanded = statusExpanded,
                                    onDismissRequest = { statusExpanded = false }
                                ) {
                                    statuses.forEach { st ->
                                        DropdownMenuItem(
                                            text = { Text(st) },
                                            onClick = {
                                                status = st
                                                statusExpanded = false
                                            }
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // Maintenance Schedule Dropdown & Next Maintenance Date
                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            ExposedDropdownMenuBox(
                                expanded = scheduleExpanded,
                                onExpandedChange = { scheduleExpanded = !scheduleExpanded },
                                modifier = Modifier.weight(1f)
                            ) {
                                OutlinedTextField(
                                    value = maintenanceSchedule,
                                    onValueChange = {},
                                    readOnly = true,
                                    label = { Text("Maintenance") },
                                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = scheduleExpanded) },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .menuAnchor()
                                )
                                ExposedDropdownMenu(
                                    expanded = scheduleExpanded,
                                    onDismissRequest = { scheduleExpanded = false }
                                ) {
                                    schedules.forEach { sc ->
                                        DropdownMenuItem(
                                            text = { Text(sc) },
                                            onClick = {
                                                maintenanceSchedule = sc
                                                scheduleExpanded = false
                                            }
                                        )
                                    }
                                }
                            }

                            DatePickerField(
                                dateValue = nextMaintenance,
                                onDateSelected = { nextMaintenance = it },
                                label = "Next Maintenance",
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }

                    // Warranty Expiry Date
                    item {
                        DatePickerField(
                            dateValue = warrantyExpiry,
                            onDateSelected = { warrantyExpiry = it },
                            label = "Warranty Expiry (Optional)"
                        )
                    }

                    // Supplier & Residual Value
                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedTextField(
                                value = supplier,
                                onValueChange = { supplier = it },
                                label = { Text("Supplier / Contractor") },
                                placeholder = { Text("Vendor Name") },
                                singleLine = true,
                                modifier = Modifier.weight(1f)
                            )
                            OutlinedTextField(
                                value = residualValueStr,
                                onValueChange = { residualValueStr = it },
                                label = { Text("Residual Salvage (₹)") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                singleLine = true,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }

                    // Notes
                    item {
                        OutlinedTextField(
                            value = notes,
                            onValueChange = { notes = it },
                            label = { Text("Notes / Specifications") },
                            placeholder = { Text("Capacities, dimensions, power ratings, model numbers...") },
                            maxLines = 3,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Actions
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(onClick = onDismiss) {
                        Text("Cancel")
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            if (name.isBlank()) {
                                return@Button
                            }
                            val costVal = costStr.toDoubleOrNull() ?: 0.0
                            val lifeVal = usefulLifeStr.toIntOrNull() ?: 5
                            val residualVal = residualValueStr.toDoubleOrNull() ?: 0.0

                            val updated = (initialAsset ?: FarmAsset(name = name.trim())).copy(
                                name = name.trim(),
                                category = category,
                                purchase_date = purchaseDate.ifBlank { null },
                                cost = costVal,
                                useful_life = lifeVal,
                                current_condition = condition,
                                location = location.trim(),
                                warranty_expiry = warrantyExpiry.ifBlank { null },
                                maintenance_schedule = maintenanceSchedule,
                                next_maintenance = nextMaintenance.ifBlank { null },
                                asset_id = assetId.trim().ifBlank { null },
                                supplier = supplier.trim().ifBlank { null },
                                residual_value = residualVal,
                                status = status,
                                current_book_value = if (initialAsset == null) costVal else initialAsset.current_book_value,
                                notes = notes.trim().ifBlank { null }
                            )
                            onSave(updated)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = FarmGreenDark),
                        enabled = name.isNotBlank(),
                        modifier = Modifier.testTag("asset_btn_save")
                    ) {
                        Text(if (isEdit) "Update" else "Save Asset")
                    }
                }
            }
        }
    }
}
