package com.example.ui.components.camera

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.ContextCompat
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.data.offline.GoatPhotoEntity
import com.example.data.photo.GoatPhotoStorageHelper
import com.example.data.supabase.Goat
import com.example.data.supabase.GoatRepository
import com.example.ui.theme.FarmGreenContainer
import com.example.ui.theme.FarmGreenDark
import com.example.ui.theme.FarmGreenPrimary
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Dialog for capturing goat photos using the device camera or gallery,
 * tagging with metadata (category, notes, profile photo toggle), and storing locally.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GoatCameraCaptureDialog(
    goatId: String,
    goatTag: String,
    repository: GoatRepository,
    initialCategory: String = "Profile",
    onDismiss: () -> Unit,
    onPhotoSaved: (photoFile: File, entity: GoatPhotoEntity) -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    var tempCameraFile by remember { mutableStateOf<File?>(null) }
    var tempCameraUri by remember { mutableStateOf<Uri?>(null) }
    var capturedPhotoFile by remember { mutableStateOf<File?>(null) }

    var selectedCategory by remember { mutableStateOf(initialCategory) }
    var photoNotes by remember { mutableStateOf("") }
    var isSetAsProfilePhoto by remember { mutableStateOf(initialCategory == "Profile") }
    var isSaving by remember { mutableStateOf(false) }

    val categories = listOf("Profile", "Identification", "Ear Tag", "Health", "Growth", "General")

    // Camera Launcher with FileProvider URI
    val cameraLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.TakePicture()
    ) { success ->
        if (success && tempCameraFile != null && tempCameraFile!!.exists() && tempCameraFile!!.length() > 0) {
            capturedPhotoFile = tempCameraFile
        } else {
            // Delete empty temp file
            tempCameraFile?.delete()
            tempCameraFile = null
            tempCameraUri = null
        }
    }

    // Camera Permission Launcher
    val cameraPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            try {
                val file = GoatPhotoStorageHelper.createCameraOutputFile(context, goatId)
                val uri = GoatPhotoStorageHelper.getFileUri(context, file)
                tempCameraFile = file
                tempCameraUri = uri
                cameraLauncher.launch(uri)
            } catch (e: Exception) {
                Toast.makeText(context, "Error starting camera: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
            }
        } else {
            Toast.makeText(context, "Camera permission is required to capture photos", Toast.LENGTH_SHORT).show()
        }
    }

    fun launchCamera() {
        val hasPermission = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.CAMERA
        ) == PackageManager.PERMISSION_GRANTED

        if (hasPermission) {
            try {
                val file = GoatPhotoStorageHelper.createCameraOutputFile(context, goatId)
                val uri = GoatPhotoStorageHelper.getFileUri(context, file)
                tempCameraFile = file
                tempCameraUri = uri
                cameraLauncher.launch(uri)
            } catch (e: Exception) {
                Toast.makeText(context, "Error starting camera: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
            }
        } else {
            cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
        }
    }

    // Photo Picker Launcher
    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            coroutineScope.launch(Dispatchers.IO) {
                val savedFile = GoatPhotoStorageHelper.saveImageUriToPermanentStorage(context, uri, goatId)
                withContext(Dispatchers.Main) {
                    if (savedFile != null) {
                        capturedPhotoFile = savedFile
                    } else {
                        Toast.makeText(context, "Failed to load selected photo", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
    }

    Dialog(
        onDismissRequest = { if (!isSaving) onDismiss() },
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .wrapContentHeight()
                .padding(16.dp),
            shape = RoundedCornerShape(24.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 6.dp
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Goat Photo Capture",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = FarmGreenDark
                        )
                        Text(
                            text = "Tag: $goatTag",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    IconButton(
                        onClick = onDismiss,
                        enabled = !isSaving,
                        modifier = Modifier.testTag("btn_close_photo_dialog")
                    ) {
                        Icon(Icons.Default.Close, contentDescription = "Close")
                    }
                }

                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))

                // Captured Image Preview or Capture Buttons
                if (capturedPhotoFile == null) {
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = FarmGreenContainer.copy(alpha = 0.4f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(72.dp)
                                    .clip(CircleShape)
                                    .background(FarmGreenPrimary.copy(alpha = 0.15f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.PhotoCamera,
                                    contentDescription = null,
                                    tint = FarmGreenPrimary,
                                    modifier = Modifier.size(36.dp)
                                )
                            }

                            Text(
                                text = "Capture or select a photo for goat $goatTag",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Medium,
                                color = MaterialTheme.colorScheme.onSurface
                            )

                            // Primary Action: Open Device Camera
                            Button(
                                onClick = { launchCamera() },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(50.dp)
                                    .testTag("btn_launch_camera"),
                                colors = ButtonDefaults.buttonColors(containerColor = FarmGreenPrimary),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Icon(Icons.Default.PhotoCamera, contentDescription = null, modifier = Modifier.size(20.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Take Photo with Camera", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                            }

                            // Secondary Action: Choose from Device Gallery
                            OutlinedButton(
                                onClick = {
                                    photoPickerLauncher.launch(
                                        androidx.activity.result.PickVisualMediaRequest(
                                            ActivityResultContracts.PickVisualMedia.ImageOnly
                                        )
                                    )
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(48.dp)
                                    .testTag("btn_pick_gallery"),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Icon(Icons.Default.PhotoLibrary, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Choose from Gallery", fontWeight = FontWeight.Medium)
                            }
                        }
                    }
                } else {
                    // Photo Preview Card
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.fillMaxWidth()) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(240.dp)
                                    .background(Color.Black)
                            ) {
                                AsyncImage(
                                    model = ImageRequest.Builder(context)
                                        .data(capturedPhotoFile)
                                        .crossfade(true)
                                        .build(),
                                    contentDescription = "Captured Goat Photo",
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier.fillMaxSize()
                                )

                                // Retake button overlay
                                Surface(
                                    modifier = Modifier
                                        .align(Alignment.TopEnd)
                                        .padding(12.dp),
                                    shape = CircleShape,
                                    color = Color.Black.copy(alpha = 0.6f)
                                ) {
                                    IconButton(
                                        onClick = {
                                            capturedPhotoFile?.delete()
                                            capturedPhotoFile = null
                                        },
                                        modifier = Modifier.size(36.dp).testTag("btn_retake_photo")
                                    ) {
                                        Icon(Icons.Default.Refresh, contentDescription = "Retake", tint = Color.White, modifier = Modifier.size(20.dp))
                                    }
                                }
                            }

                            // Retake / Change Button Row
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                TextButton(
                                    onClick = { launchCamera() },
                                    modifier = Modifier.testTag("btn_retake_camera")
                                ) {
                                    Icon(Icons.Default.PhotoCamera, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Retake Photo")
                                }
                                TextButton(
                                    onClick = {
                                        photoPickerLauncher.launch(
                                            androidx.activity.result.PickVisualMediaRequest(
                                                ActivityResultContracts.PickVisualMedia.ImageOnly
                                            )
                                        )
                                    }
                                ) {
                                    Icon(Icons.Default.PhotoLibrary, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Change Image")
                                }
                            }
                        }
                    }

                    // Metadata Inputs
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text(
                            text = "Photo Category",
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.SemiBold
                        )

                        // Category Chips
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            categories.take(3).forEach { cat ->
                                FilterChip(
                                    selected = selectedCategory == cat,
                                    onClick = {
                                        selectedCategory = cat
                                        if (cat == "Profile") isSetAsProfilePhoto = true
                                    },
                                    label = { Text(cat, fontSize = 12.sp) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = FarmGreenPrimary,
                                        selectedLabelColor = Color.White
                                    )
                                )
                            }
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            categories.drop(3).forEach { cat ->
                                FilterChip(
                                    selected = selectedCategory == cat,
                                    onClick = { selectedCategory = cat },
                                    label = { Text(cat, fontSize = 12.sp) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = FarmGreenPrimary,
                                        selectedLabelColor = Color.White
                                    )
                                )
                            }
                        }

                        // Notes field
                        OutlinedTextField(
                            value = photoNotes,
                            onValueChange = { photoNotes = it },
                            label = { Text("Notes / Observations (Optional)") },
                            placeholder = { Text("e.g. Ear tag readable, healthy posture, front view") },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("photo_notes_input"),
                            maxLines = 2,
                            shape = RoundedCornerShape(12.dp)
                        )

                        // Set as Profile Photo Toggle
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(FarmGreenContainer.copy(alpha = 0.3f))
                                .clickable { isSetAsProfilePhoto = !isSetAsProfilePhoto }
                                .padding(horizontal = 12.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    Icons.Default.AccountBox,
                                    contentDescription = null,
                                    tint = FarmGreenDark,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Set as Primary Profile Photo",
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Medium,
                                    color = FarmGreenDark
                                )
                            }
                            Switch(
                                checked = isSetAsProfilePhoto,
                                onCheckedChange = { isSetAsProfilePhoto = it },
                                modifier = Modifier.testTag("switch_set_profile_photo")
                            )
                        }

                        // Save Button
                        Button(
                            onClick = {
                                val file = capturedPhotoFile ?: return@Button
                                isSaving = true
                                coroutineScope.launch {
                                    val photoUriString = file.absolutePath
                                    val result = repository.saveGoatPhotoRecord(
                                        goatId = goatId,
                                        photoUri = photoUriString,
                                        title = "$goatTag $selectedCategory",
                                        category = selectedCategory,
                                        notes = photoNotes.ifBlank { null },
                                        isPrimary = isSetAsProfilePhoto
                                    )

                                    isSaving = false
                                    if (result.isSuccess) {
                                        Toast.makeText(context, "Goat photo saved successfully!", Toast.LENGTH_SHORT).show()
                                        onPhotoSaved(file, result.getOrThrow())
                                        onDismiss()
                                    } else {
                                        Toast.makeText(context, "Failed to save photo: ${result.exceptionOrNull()?.message}", Toast.LENGTH_LONG).show()
                                    }
                                }
                            },
                            enabled = !isSaving,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(52.dp)
                                .testTag("btn_save_goat_photo"),
                            colors = ButtonDefaults.buttonColors(containerColor = FarmGreenPrimary),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            if (isSaving) {
                                CircularProgressIndicator(color = Color.White, modifier = Modifier.size(22.dp))
                            } else {
                                Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Save Goat Photo", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}

/**
 * Avatar Composable that displays a goat's photo if present or fallback gender badge,
 * with optional camera badge to capture photos directly.
 */
@Composable
fun GoatAvatar(
    photoUrl: String?,
    tag: String,
    isBuck: Boolean = false,
    size: androidx.compose.ui.unit.Dp = 54.dp,
    showCameraBadge: Boolean = false,
    onCameraClick: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val shape = CircleShape

    Box(
        modifier = modifier.size(size)
    ) {
        if (!photoUrl.isNullOrBlank()) {
            AsyncImage(
                model = ImageRequest.Builder(context)
                    .data(if (photoUrl.startsWith("/")) File(photoUrl) else photoUrl)
                    .crossfade(true)
                    .build(),
                contentDescription = "Goat Photo ($tag)",
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .fillMaxSize()
                    .clip(shape)
                    .border(2.dp, if (isBuck) Color(0xFF90CAF9) else FarmGreenPrimary.copy(alpha = 0.5f), shape)
            )
        } else {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .clip(shape)
                    .background(if (isBuck) Color(0xFFE3F2FD) else FarmGreenContainer),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Pets,
                    contentDescription = null,
                    tint = if (isBuck) Color(0xFF1565C0) else FarmGreenDark,
                    modifier = Modifier.size(size * 0.52f)
                )
            }
        }

        if (showCameraBadge && onCameraClick != null) {
            Surface(
                modifier = Modifier
                    .size(size * 0.42f)
                    .align(Alignment.BottomEnd)
                    .clip(CircleShape)
                    .clickable { onCameraClick() }
                    .testTag("avatar_camera_badge"),
                color = FarmGreenPrimary,
                contentColor = Color.White,
                shape = CircleShape,
                shadowElevation = 2.dp
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = Icons.Default.PhotoCamera,
                        contentDescription = "Take Photo",
                        modifier = Modifier.size(size * 0.24f)
                    )
                }
            }
        }
    }
}
