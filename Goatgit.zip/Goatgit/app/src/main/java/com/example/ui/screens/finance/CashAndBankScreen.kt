package com.example.ui.screens.finance

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.CompareArrows
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.supabase.*
import com.example.ui.components.DatePickerField
import com.example.ui.theme.*
import com.example.util.CurrencyUtils
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CashAndBankScreen(
    repository: GoatRepository,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler { onNavigateBack() }

    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val dateFormat = remember { SimpleDateFormat("yyyy-MM-dd", Locale.US) }
    val today = remember { dateFormat.format(Date()) }

    var accounts by remember { mutableStateOf<List<FinancialAccount>>(emptyList()) }
    var transactions by remember { mutableStateOf<List<AccountTransaction>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }

    // Filters
    var selectedAccountTypeFilter by remember { mutableStateOf("ALL") } // ALL, CASH, BANK, UPI
    var selectedAccountId by remember { mutableStateOf<String?>("ALL") }
    var selectedTxTypeFilter by remember { mutableStateOf("ALL") } // ALL, INCOME, EXPENSE, TRANSFER
    var searchQuery by remember { mutableStateOf("") }

    // Dialogs
    var showAddAccountDialog by remember { mutableStateOf(false) }
    var showTransferDialog by remember { mutableStateOf(false) }
    var showRecordIncomeDialog by remember { mutableStateOf(false) }
    var showRecordExpenseDialog by remember { mutableStateOf(false) }

    fun loadData() {
        isLoading = true
        coroutineScope.launch {
            val accRes = repository.finance.getAccounts()
            if (accRes.isSuccess) {
                accounts = accRes.getOrThrow()
            }
            val txRes = repository.finance.getTransactions()
            if (txRes.isSuccess) {
                transactions = txRes.getOrThrow()
            }
            isLoading = false
        }
    }

    LaunchedEffect(Unit) {
        loadData()
    }

    val totalLiquidFunds = remember(accounts) {
        accounts.filter { it.is_active }.sumOf { it.current_balance }
    }

    val cashBalance = remember(accounts) {
        accounts.filter { it.is_active && it.account_type.equals("CASH", ignoreCase = true) }
            .sumOf { it.current_balance }
    }

    val bankBalance = remember(accounts) {
        accounts.filter {
            it.is_active && (it.account_type.contains("BANK", ignoreCase = true))
        }.sumOf { it.current_balance }
    }

    val upiBalance = remember(accounts) {
        accounts.filter { it.is_active && it.account_type.equals("UPI", ignoreCase = true) }
            .sumOf { it.current_balance }
    }

    val filteredAccounts = remember(accounts, selectedAccountTypeFilter) {
        when (selectedAccountTypeFilter) {
            "CASH" -> accounts.filter { it.account_type.equals("CASH", ignoreCase = true) }
            "BANK" -> accounts.filter { it.account_type.contains("BANK", ignoreCase = true) }
            "UPI" -> accounts.filter { it.account_type.equals("UPI", ignoreCase = true) }
            else -> accounts
        }
    }

    val filteredTransactions = remember(transactions, selectedAccountId, selectedTxTypeFilter, searchQuery) {
        transactions.filter { tx ->
            val matchAccount = if (selectedAccountId == "ALL" || selectedAccountId == null) true
            else tx.account_id == selectedAccountId || tx.to_account_id == selectedAccountId

            val matchType = when (selectedTxTypeFilter) {
                "INCOME" -> tx.transaction_type.equals("INCOME", ignoreCase = true) || tx.transaction_type.equals("CUSTOMER_RECEIPT", ignoreCase = true)
                "EXPENSE" -> tx.transaction_type.equals("EXPENSE", ignoreCase = true) || tx.transaction_type.equals("SUPPLIER_PAYMENT", ignoreCase = true)
                "TRANSFER" -> tx.transaction_type.equals("TRANSFER", ignoreCase = true)
                else -> true
            }

            val matchSearch = if (searchQuery.isBlank()) true else {
                tx.category.contains(searchQuery, ignoreCase = true) ||
                (tx.description ?: "").contains(searchQuery, ignoreCase = true) ||
                (tx.reference_id ?: "").contains(searchQuery, ignoreCase = true) ||
                (tx.payment_mode).contains(searchQuery, ignoreCase = true)
            }

            matchAccount && matchType && matchSearch
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "Cash, Bank & UPI Ledgers",
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp
                        )
                        Text(
                            text = "Multi-Account Liquidity • Transfers Do Not Affect P&L",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                navigationIcon = {
                    IconButton(
                        onClick = onNavigateBack,
                        modifier = Modifier.testTag("cash_bank_btn_back")
                    ) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(
                        onClick = { loadData() },
                        modifier = Modifier.testTag("cash_bank_btn_refresh")
                    ) {
                        Icon(Icons.Default.Refresh, contentDescription = "Refresh")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.White)
            )
        },
        bottomBar = {
            Surface(
                color = Color.White,
                tonalElevation = 8.dp,
                shadowElevation = 8.dp
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // + Income
                    Button(
                        onClick = { showRecordIncomeDialog = true },
                        colors = ButtonDefaults.buttonColors(containerColor = FarmGreenDark),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("btn_quick_income"),
                        contentPadding = PaddingValues(vertical = 10.dp)
                    ) {
                        Icon(Icons.Default.ArrowDownward, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("+ Income", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }

                    // - Expense
                    Button(
                        onClick = { showRecordExpenseDialog = true },
                        colors = ButtonDefaults.buttonColors(containerColor = FarmError),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("btn_quick_expense"),
                        contentPadding = PaddingValues(vertical = 10.dp)
                    ) {
                        Icon(Icons.Default.ArrowUpward, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("- Expense", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }

                    // ⇄ Transfer (Non-P&L)
                    Button(
                        onClick = { showTransferDialog = true },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E3A8A)),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .weight(1.2f)
                            .testTag("btn_internal_transfer"),
                        contentPadding = PaddingValues(vertical = 10.dp)
                    ) {
                        Icon(Icons.AutoMirrored.Filled.CompareArrows, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("⇄ Transfer", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        },
        containerColor = Color(0xFFF8F9FA),
        modifier = modifier
    ) { innerPadding ->
        if (isLoading) {
            Box(modifier = Modifier.fillMaxSize().padding(innerPadding), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = FarmGreenDark)
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    Spacer(modifier = Modifier.height(4.dp))
                    // Total Liquid Funds Master Hero Card
                    Card(
                        colors = CardDefaults.cardColors(containerColor = FarmGreenDark),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.fillMaxWidth().testTag("liquid_funds_card")
                    ) {
                        Column(modifier = Modifier.padding(18.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("Total Liquid Farm Funds", color = Color.White.copy(alpha = 0.85f), fontSize = 12.sp)
                                Surface(
                                    color = Color.White.copy(alpha = 0.2f),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text(
                                        text = "${accounts.count { it.is_active }} Active Accounts",
                                        color = Color.White,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = CurrencyUtils.formatInr(totalLiquidFunds),
                                color = Color.White,
                                fontSize = 28.sp,
                                fontWeight = FontWeight.ExtraBold
                            )

                            Spacer(modifier = Modifier.height(14.dp))
                            HorizontalDivider(color = Color.White.copy(alpha = 0.2f))
                            Spacer(modifier = Modifier.height(12.dp))

                            // 3 Pillars of liquidity: Cash, Bank, UPI
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                AccountTypeSummaryPill(
                                    title = "Cash",
                                    amount = cashBalance,
                                    icon = Icons.Default.Payments,
                                    bgColor = Color(0xFF2E7D32)
                                )
                                AccountTypeSummaryPill(
                                    title = "Bank",
                                    amount = bankBalance,
                                    icon = Icons.Default.AccountBalance,
                                    bgColor = Color(0xFF1565C0)
                                )
                                AccountTypeSummaryPill(
                                    title = "UPI",
                                    amount = upiBalance,
                                    icon = Icons.Default.QrCode,
                                    bgColor = Color(0xFF7B1FA2)
                                )
                            }
                        }
                    }
                }

                // Accounting Rule Box
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFEFF6FF)),
                        shape = RoundedCornerShape(12.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFBFDBFE)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.VerifiedUser, contentDescription = null, tint = Color(0xFF1D4ED8), modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "Strict Non-P&L Transfer Guarantee",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp,
                                    color = Color(0xFF1E3A8A)
                                )
                                Text(
                                    text = "Transfers between Cash, Bank, and UPI move funds without altering revenue or expense ledgers. P&L Net Profit remains 100% unaffected.",
                                    fontSize = 11.sp,
                                    color = Color(0xFF1E40AF),
                                    lineHeight = 15.sp
                                )
                            }
                        }
                    }
                }

                // Accounts Header & Add Button
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Financial Accounts",
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            color = FarmGreenDark
                        )
                        Button(
                            onClick = { showAddAccountDialog = true },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E3A8A)),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                            modifier = Modifier.testTag("btn_add_account")
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("New Account", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                // Account Filter Chips
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        FilterChip(
                            selected = selectedAccountTypeFilter == "ALL",
                            onClick = { selectedAccountTypeFilter = "ALL"; selectedAccountId = "ALL" },
                            label = { Text("All (${accounts.size})") }
                        )
                        FilterChip(
                            selected = selectedAccountTypeFilter == "CASH",
                            onClick = { selectedAccountTypeFilter = "CASH"; selectedAccountId = "ALL" },
                            label = { Text("Cash") },
                            leadingIcon = { Icon(Icons.Default.Payments, contentDescription = null, modifier = Modifier.size(14.dp)) }
                        )
                        FilterChip(
                            selected = selectedAccountTypeFilter == "BANK",
                            onClick = { selectedAccountTypeFilter = "BANK"; selectedAccountId = "ALL" },
                            label = { Text("Bank") },
                            leadingIcon = { Icon(Icons.Default.AccountBalance, contentDescription = null, modifier = Modifier.size(14.dp)) }
                        )
                        FilterChip(
                            selected = selectedAccountTypeFilter == "UPI",
                            onClick = { selectedAccountTypeFilter = "UPI"; selectedAccountId = "ALL" },
                            label = { Text("UPI") },
                            leadingIcon = { Icon(Icons.Default.QrCode, contentDescription = null, modifier = Modifier.size(14.dp)) }
                        )
                    }
                }

                // Accounts List Cards
                items(filteredAccounts) { account ->
                    AccountCardItem(
                        account = account,
                        isSelected = selectedAccountId == account.id,
                        onClick = {
                            selectedAccountId = if (selectedAccountId == account.id) "ALL" else account.id
                        }
                    )
                }

                // Shared Transactions Ledger Header
                item {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Shared Transactions Ledger",
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp,
                                color = FarmGreenDark
                            )
                            if (selectedAccountId != "ALL" && selectedAccountId != null) {
                                TextButton(onClick = { selectedAccountId = "ALL" }) {
                                    Text("Reset Account Filter", fontSize = 11.sp)
                                }
                            }
                        }

                        // Search Field
                        OutlinedTextField(
                            value = searchQuery,
                            onValueChange = { searchQuery = it },
                            placeholder = { Text("Search by category, reference, mode, or notes...") },
                            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                            trailingIcon = {
                                if (searchQuery.isNotBlank()) {
                                    IconButton(onClick = { searchQuery = "" }) {
                                        Icon(Icons.Default.Close, contentDescription = "Clear")
                                    }
                                }
                            },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth().testTag("input_tx_search")
                        )

                        // Type Filter Chips: All, Income, Expense, Transfer
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            FilterChip(
                                selected = selectedTxTypeFilter == "ALL",
                                onClick = { selectedTxTypeFilter = "ALL" },
                                label = { Text("All Types") }
                            )
                            FilterChip(
                                selected = selectedTxTypeFilter == "INCOME",
                                onClick = { selectedTxTypeFilter = "INCOME" },
                                label = { Text("Income (+)") },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = Color(0xFFDCFCE7),
                                    selectedLabelColor = Color(0xFF166534)
                                )
                            )
                            FilterChip(
                                selected = selectedTxTypeFilter == "EXPENSE",
                                onClick = { selectedTxTypeFilter = "EXPENSE" },
                                label = { Text("Expense (-)") },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = Color(0xFFFEE2E2),
                                    selectedLabelColor = Color(0xFF991B1B)
                                )
                            )
                            FilterChip(
                                selected = selectedTxTypeFilter == "TRANSFER",
                                onClick = { selectedTxTypeFilter = "TRANSFER" },
                                label = { Text("Transfers (⇄ Non-P&L)") },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = Color(0xFFEDE9FE),
                                    selectedLabelColor = Color(0xFF5B21B6)
                                )
                            )
                        }
                    }
                }

                if (filteredTransactions.isEmpty()) {
                    item {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp)
                        ) {
                            Box(modifier = Modifier.fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Icon(Icons.Default.ReceiptLong, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(32.dp))
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text("No transactions found for the selected filter.", color = Color.Gray, fontSize = 13.sp)
                                }
                            }
                        }
                    }
                } else {
                    items(filteredTransactions) { tx ->
                        TransactionRowItem(tx = tx, accountsMap = accounts.associateBy { it.id })
                    }
                }

                item {
                    Spacer(modifier = Modifier.height(80.dp))
                }
            }
        }
    }

    // Add Account Dialog
    if (showAddAccountDialog) {
        AddAccountDialog(
            onDismiss = { showAddAccountDialog = false },
            onSave = { acc ->
                showAddAccountDialog = false
                coroutineScope.launch {
                    val res = repository.finance.addAccount(acc)
                    if (res.isSuccess) {
                        Toast.makeText(context, "${acc.account_name} created & synced", Toast.LENGTH_SHORT).show()
                        loadData()
                    } else {
                        Toast.makeText(context, "Failed: ${res.exceptionOrNull()?.message}", Toast.LENGTH_LONG).show()
                    }
                }
            }
        )
    }

    // Transfer Funds Dialog
    if (showTransferDialog) {
        TransferFundsDialog(
            accounts = accounts,
            onDismiss = { showTransferDialog = false },
            onTransfer = { fromId, toId, amt, date, desc, ref ->
                showTransferDialog = false
                coroutineScope.launch {
                    val res = repository.finance.recordTransfer(
                        fromAccountId = fromId,
                        toAccountId = toId,
                        amount = amt,
                        date = date,
                        description = desc,
                        referenceId = ref
                    )
                    if (res.isSuccess) {
                        Toast.makeText(context, "Transfer recorded (Guaranteed Non-P&L Contra)", Toast.LENGTH_SHORT).show()
                        loadData()
                    } else {
                        Toast.makeText(context, "Transfer error: ${res.exceptionOrNull()?.message}", Toast.LENGTH_LONG).show()
                    }
                }
            }
        )
    }

    // Record Income Dialog
    if (showRecordIncomeDialog) {
        RecordIncomeDialog(
            accounts = accounts,
            onDismiss = { showRecordIncomeDialog = false },
            onSave = { accountId, amount, category, date, mode, desc, ref ->
                showRecordIncomeDialog = false
                coroutineScope.launch {
                    val res = repository.finance.recordIncome(
                        accountId = accountId,
                        amount = amount,
                        category = category,
                        date = date,
                        paymentMode = mode,
                        description = desc,
                        referenceId = ref
                    )
                    if (res.isSuccess) {
                        Toast.makeText(context, "Income recorded & synced", Toast.LENGTH_SHORT).show()
                        loadData()
                    } else {
                        Toast.makeText(context, "Error: ${res.exceptionOrNull()?.message}", Toast.LENGTH_LONG).show()
                    }
                }
            }
        )
    }

    // Record Expense Dialog
    if (showRecordExpenseDialog) {
        RecordExpenseDialog(
            accounts = accounts,
            onDismiss = { showRecordExpenseDialog = false },
            onSave = { accountId, amount, category, date, mode, desc, ref, isCapex ->
                showRecordExpenseDialog = false
                coroutineScope.launch {
                    val res = repository.finance.recordExpense(
                        accountId = accountId,
                        amount = amount,
                        category = category,
                        date = date,
                        paymentMode = mode,
                        description = desc,
                        referenceId = ref,
                        isCapex = isCapex
                    )
                    if (res.isSuccess) {
                        Toast.makeText(context, "Expense recorded & synced", Toast.LENGTH_SHORT).show()
                        loadData()
                    } else {
                        Toast.makeText(context, "Error: ${res.exceptionOrNull()?.message}", Toast.LENGTH_LONG).show()
                    }
                }
            }
        )
    }
}

@Composable
private fun AccountTypeSummaryPill(
    title: String,
    amount: Double,
    icon: ImageVector,
    bgColor: Color
) {
    Surface(
        color = bgColor.copy(alpha = 0.35f),
        shape = RoundedCornerShape(10.dp),
        modifier = Modifier.padding(horizontal = 2.dp)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(icon, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Column {
                Text(title, color = Color.White.copy(alpha = 0.85f), fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                Text(CurrencyUtils.formatInr(amount), color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun AccountCardItem(
    account: FinancialAccount,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = if (isSelected) Color(0xFFF1F8E9) else Color.White),
        shape = RoundedCornerShape(14.dp),
        border = if (isSelected) androidx.compose.foundation.BorderStroke(1.5.dp, FarmGreenPrimary) else null,
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .testTag("account_card_${account.id}")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                Box(
                    modifier = Modifier
                        .size(42.dp)
                        .clip(CircleShape)
                        .background(
                            when (account.account_type.uppercase()) {
                                "CASH" -> Color(0xFFE8F5E9)
                                "UPI" -> Color(0xFFF3E8FF)
                                else -> Color(0xFFE0F2FE)
                            }
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = when (account.account_type.uppercase()) {
                            "CASH" -> Icons.Default.Payments
                            "UPI" -> Icons.Default.QrCode
                            else -> Icons.Default.AccountBalance
                        },
                        contentDescription = null,
                        tint = when (account.account_type.uppercase()) {
                            "CASH" -> FarmGreenDark
                            "UPI" -> Color(0xFF7E22CE)
                            else -> Color(0xFF0369A1)
                        },
                        modifier = Modifier.size(22.dp)
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(account.account_name, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Spacer(modifier = Modifier.width(6.dp))
                        Surface(
                            color = when (account.account_type.uppercase()) {
                                "CASH" -> Color(0xFFE8F5E9)
                                "UPI" -> Color(0xFFF3E8FF)
                                else -> Color(0xFFE0F2FE)
                            },
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Text(
                                text = account.account_type,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = when (account.account_type.uppercase()) {
                                    "CASH" -> FarmGreenDark
                                    "UPI" -> Color(0xFF7E22CE)
                                    else -> Color(0xFF0369A1)
                                },
                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                            )
                        }
                    }

                    val sub = buildString {
                        if (!account.upi_id.isNullOrBlank()) {
                            append("UPI: ${account.upi_id}")
                        } else {
                            if (!account.account_number.isNullOrBlank()) append(account.maskedAccountNumber)
                            if (!account.bank_name.isNullOrBlank()) append(" • ${account.bank_name}")
                        }
                    }
                    if (sub.isNotBlank()) {
                        Text(sub, fontSize = 11.sp, color = Color.Gray)
                    }
                }
            }

            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = CurrencyUtils.formatInr(account.current_balance),
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 15.sp,
                    color = if (account.current_balance >= 0) FarmGreenDark else FarmError
                )
                Text(
                    text = if (isSelected) "Filtering Ledger" else "Tap to filter",
                    fontSize = 10.sp,
                    color = if (isSelected) FarmGreenDark else Color.LightGray
                )
            }
        }
    }
}

@Composable
private fun TransactionRowItem(
    tx: AccountTransaction,
    accountsMap: Map<String, FinancialAccount>
) {
    val isTransfer = tx.transaction_type.equals("TRANSFER", ignoreCase = true)
    val isCredit = when (tx.transaction_type.uppercase()) {
        "INCOME", "DEPOSIT", "CUSTOMER_RECEIPT", "LOAN_RECEIPT", "OWNER_INVESTMENT" -> true
        else -> false
    }

    val fromAcc = accountsMap[tx.account_id]
    val toAcc = if (!tx.to_account_id.isNullOrBlank()) accountsMap[tx.to_account_id] else null

    Card(
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(10.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.5.dp),
        modifier = Modifier.fillMaxWidth().testTag("tx_row_${tx.id}")
    ) {
        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Category & Icon
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .clip(CircleShape)
                            .background(
                                if (isTransfer) Color(0xFFEDE9FE)
                                else if (isCredit) Color(0xFFE8F5E9)
                                else Color(0xFFFFEBEE)
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (isTransfer) Icons.AutoMirrored.Filled.CompareArrows
                            else if (isCredit) Icons.Default.ArrowDownward
                            else Icons.Default.ArrowUpward,
                            contentDescription = null,
                            tint = if (isTransfer) Color(0xFF7C3AED)
                            else if (isCredit) FarmGreenDark
                            else FarmError,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(tx.category, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Text(
                            text = tx.date,
                            fontSize = 10.sp,
                            color = Color.Gray
                        )
                    }
                }

                // Amount & P&L Impact Status
                Column(horizontalAlignment = Alignment.End) {
                    val prefix = if (isTransfer) "⇄ " else if (isCredit) "+ " else "- "
                    Text(
                        text = prefix + CurrencyUtils.formatInr(tx.amount),
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 15.sp,
                        color = if (isTransfer) Color(0xFF7C3AED) else if (isCredit) FarmGreenDark else FarmError
                    )

                    // P&L badge
                    Surface(
                        color = if (isTransfer) Color(0xFFEDE9FE)
                        else if (isCredit) Color(0xFFDCFCE7)
                        else Color(0xFFFEE2E2),
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Text(
                            text = if (isTransfer) "Non-P&L Contra (₹0 P&L)"
                            else if (isCredit) "Income • Affects P&L"
                            else "Expense • Affects P&L",
                            fontSize = 9.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = if (isTransfer) Color(0xFF5B21B6)
                            else if (isCredit) Color(0xFF166534)
                            else Color(0xFF991B1B),
                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                        )
                    }
                }
            }

            HorizontalDivider(color = Color(0xFFF3F4F6))

            // Account & Routing Line
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (isTransfer) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = fromAcc?.account_name ?: "Source",
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 11.sp,
                            color = Color(0xFF374151)
                        )
                        Icon(
                            imageVector = Icons.Default.ArrowForward,
                            contentDescription = null,
                            tint = Color(0xFF7C3AED),
                            modifier = Modifier.size(12.dp).padding(horizontal = 2.dp)
                        )
                        Text(
                            text = toAcc?.account_name ?: "Destination",
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 11.sp,
                            color = Color(0xFF374151)
                        )
                    }
                } else {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = fromAcc?.account_name ?: "Account",
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 11.sp,
                            color = Color(0xFF374151)
                        )
                        if (!tx.payment_mode.isNullOrBlank()) {
                            Text(
                                text = " • ${tx.payment_mode}",
                                fontSize = 11.sp,
                                color = Color.Gray
                            )
                        }
                    }
                }

                if (!tx.reference_id.isNullOrBlank()) {
                    Text(
                        text = "Ref: ${tx.reference_id}",
                        fontSize = 10.sp,
                        color = Color.Gray
                    )
                }
            }

            if (!tx.description.isNullOrBlank()) {
                Text(
                    text = tx.description,
                    fontSize = 11.sp,
                    color = Color(0xFF6B7280),
                    maxLines = 2
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AddAccountDialog(
    onDismiss: () -> Unit,
    onSave: (FinancialAccount) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var type by remember { mutableStateOf("BANK") } // CASH, BANK, UPI
    var upiId by remember { mutableStateOf("") }
    var accNumber by remember { mutableStateOf("") }
    var bankName by remember { mutableStateOf("") }
    var ifsc by remember { mutableStateOf("") }
    var branch by remember { mutableStateOf("") }
    var openingBalStr by remember { mutableStateOf("0") }
    var typeExpanded by remember { mutableStateOf(false) }

    val accountTypes = listOf("CASH", "BANK", "UPI")

    Dialog(onDismissRequest = onDismiss) {
        Surface(shape = RoundedCornerShape(16.dp), color = Color.White, modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Add Financial Account", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = FarmGreenDark)

                // Account Type Selector
                ExposedDropdownMenuBox(expanded = typeExpanded, onExpandedChange = { typeExpanded = !typeExpanded }) {
                    OutlinedTextField(
                        value = when (type) {
                            "CASH" -> "Cash in Hand / Vault"
                            "BANK" -> "Bank Account (Current / Savings)"
                            "UPI" -> "UPI Wallet (PhonePe / GPay / Paytm)"
                            else -> type
                        },
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Account Type *") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = typeExpanded) },
                        modifier = Modifier.fillMaxWidth().menuAnchor().testTag("add_account_type_dropdown")
                    )
                    ExposedDropdownMenu(expanded = typeExpanded, onDismissRequest = { typeExpanded = false }) {
                        accountTypes.forEach { t ->
                            DropdownMenuItem(
                                text = {
                                    Text(
                                        when (t) {
                                            "CASH" -> "Cash in Hand / Vault"
                                            "BANK" -> "Bank Account (Current / Savings)"
                                            "UPI" -> "UPI Wallet (PhonePe / GPay / Paytm)"
                                            else -> t
                                        }
                                    )
                                },
                                onClick = { type = t; typeExpanded = false }
                            )
                        }
                    }
                }

                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Account Name *") },
                    placeholder = {
                        Text(
                            when (type) {
                                "CASH" -> "e.g. Farm Cash in Hand, Petty Cash"
                                "BANK" -> "e.g. SBI Current Account, HDFC Savings"
                                "UPI" -> "e.g. Google Pay Business, PhonePe Farm"
                                else -> "Account Name"
                            }
                        )
                    },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("input_account_name")
                )

                // UPI specific inputs
                if (type == "UPI") {
                    OutlinedTextField(
                        value = upiId,
                        onValueChange = { upiId = it },
                        label = { Text("UPI ID / VPA *") },
                        placeholder = { Text("e.g. goatfarm@okhdfcbank, 9876543210@paytm") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("input_upi_id")
                    )
                    OutlinedTextField(
                        value = bankName,
                        onValueChange = { bankName = it },
                        label = { Text("App / Provider") },
                        placeholder = { Text("PhonePe, Google Pay, Paytm, BHIM...") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                // Bank specific inputs
                if (type == "BANK") {
                    OutlinedTextField(
                        value = bankName,
                        onValueChange = { bankName = it },
                        label = { Text("Bank Name *") },
                        placeholder = { Text("State Bank of India, HDFC, ICICI...") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("input_bank_name")
                    )
                    OutlinedTextField(
                        value = accNumber,
                        onValueChange = { accNumber = it },
                        label = { Text("Account Number") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("input_account_number")
                    )
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = ifsc,
                            onValueChange = { ifsc = it },
                            label = { Text("IFSC Code") },
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = branch,
                            onValueChange = { branch = it },
                            label = { Text("Branch") },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                OutlinedTextField(
                    value = openingBalStr,
                    onValueChange = { openingBalStr = it },
                    label = { Text("Opening Balance (₹) *") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("input_opening_balance")
                )

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    TextButton(onClick = onDismiss) { Text("Cancel") }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            if (name.isBlank()) return@Button
                            val bal = openingBalStr.toDoubleOrNull() ?: 0.0
                            val acc = FinancialAccount(
                                account_name = name.trim(),
                                account_type = type,
                                account_number = accNumber.trim().ifBlank { null },
                                upi_id = upiId.trim().ifBlank { null },
                                bank_name = bankName.trim().ifBlank { null },
                                ifsc_code = ifsc.trim().ifBlank { null },
                                branch = branch.trim().ifBlank { null },
                                opening_balance = bal,
                                current_balance = bal,
                                is_active = true
                            )
                            onSave(acc)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = FarmGreenDark),
                        enabled = name.isNotBlank(),
                        modifier = Modifier.testTag("btn_save_account")
                    ) {
                        Text("Save Account")
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun TransferFundsDialog(
    accounts: List<FinancialAccount>,
    onDismiss: () -> Unit,
    onTransfer: (fromId: String, toId: String, amount: Double, date: String, desc: String?, ref: String?) -> Unit
) {
    var fromAccountId by remember { mutableStateOf(accounts.firstOrNull()?.id ?: "") }
    var toAccountId by remember { mutableStateOf(accounts.getOrNull(1)?.id ?: "") }
    var amountStr by remember { mutableStateOf("") }
    var dateStr by remember { mutableStateOf(SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())) }
    var referenceStr by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }

    var fromExpanded by remember { mutableStateOf(false) }
    var toExpanded by remember { mutableStateOf(false) }

    Dialog(onDismissRequest = onDismiss) {
        Surface(shape = RoundedCornerShape(16.dp), color = Color.White, modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Transfer Funds (Non-P&L Contra)", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = Color(0xFF1E3A8A))
                Surface(
                    color = Color(0xFFEFF6FF),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "Transfers move funds between Cash, Bank, and UPI without affecting farm revenue or operating expenses.",
                        fontSize = 11.sp,
                        color = Color(0xFF1E40AF),
                        modifier = Modifier.padding(8.dp)
                    )
                }

                // From Account
                ExposedDropdownMenuBox(expanded = fromExpanded, onExpandedChange = { fromExpanded = !fromExpanded }) {
                    val selFrom = accounts.firstOrNull { it.id == fromAccountId }
                    OutlinedTextField(
                        value = "${selFrom?.account_name ?: "Select"} (${CurrencyUtils.formatInr(selFrom?.current_balance ?: 0.0)})",
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Transfer From *") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = fromExpanded) },
                        modifier = Modifier.fillMaxWidth().menuAnchor().testTag("transfer_from_dropdown")
                    )
                    ExposedDropdownMenu(expanded = fromExpanded, onDismissRequest = { fromExpanded = false }) {
                        accounts.forEach { acc ->
                            DropdownMenuItem(
                                text = { Text("${acc.account_name} [${acc.account_type}] (${CurrencyUtils.formatInr(acc.current_balance)})") },
                                onClick = { fromAccountId = acc.id; fromExpanded = false }
                            )
                        }
                    }
                }

                // To Account
                ExposedDropdownMenuBox(expanded = toExpanded, onExpandedChange = { toExpanded = !toExpanded }) {
                    val selTo = accounts.firstOrNull { it.id == toAccountId }
                    OutlinedTextField(
                        value = "${selTo?.account_name ?: "Select"} (${CurrencyUtils.formatInr(selTo?.current_balance ?: 0.0)})",
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Transfer To *") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = toExpanded) },
                        modifier = Modifier.fillMaxWidth().menuAnchor().testTag("transfer_to_dropdown")
                    )
                    ExposedDropdownMenu(expanded = toExpanded, onDismissRequest = { toExpanded = false }) {
                        accounts.filter { it.id != fromAccountId }.forEach { acc ->
                            DropdownMenuItem(
                                text = { Text("${acc.account_name} [${acc.account_type}] (${CurrencyUtils.formatInr(acc.current_balance)})") },
                                onClick = { toAccountId = acc.id; toExpanded = false }
                            )
                        }
                    }
                }

                OutlinedTextField(
                    value = amountStr,
                    onValueChange = { amountStr = it },
                    label = { Text("Amount (₹) *") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("transfer_amount_input")
                )

                DatePickerField(
                    dateValue = dateStr,
                    onDateSelected = { dateStr = it },
                    label = "Transfer Date"
                )

                OutlinedTextField(
                    value = referenceStr,
                    onValueChange = { referenceStr = it },
                    label = { Text("UTR / Cheque / Ref No") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Notes") },
                    placeholder = { Text("e.g. Bank to Cash ATM withdrawal, UPI load...") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    TextButton(onClick = onDismiss) { Text("Cancel") }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            val amt = amountStr.toDoubleOrNull() ?: 0.0
                            if (amt <= 0 || fromAccountId.isBlank() || toAccountId.isBlank() || fromAccountId == toAccountId) return@Button
                            onTransfer(
                                fromAccountId,
                                toAccountId,
                                amt,
                                dateStr,
                                notes.trim().ifBlank { null },
                                referenceStr.trim().ifBlank { null }
                            )
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E3A8A)),
                        enabled = (amountStr.toDoubleOrNull() ?: 0.0) > 0 && fromAccountId.isNotBlank() && toAccountId.isNotBlank() && fromAccountId != toAccountId,
                        modifier = Modifier.testTag("btn_confirm_transfer")
                    ) {
                        Text("Confirm Transfer")
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun RecordIncomeDialog(
    accounts: List<FinancialAccount>,
    onDismiss: () -> Unit,
    onSave: (accountId: String, amount: Double, category: String, date: String, mode: String, desc: String?, ref: String?) -> Unit
) {
    var accountId by remember { mutableStateOf(accounts.firstOrNull()?.id ?: "") }
    var amountStr by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("Goat Sale") }
    var mode by remember { mutableStateOf("UPI") }
    var dateStr by remember { mutableStateOf(SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())) }
    var referenceStr by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }

    var accountExpanded by remember { mutableStateOf(false) }
    var categoryExpanded by remember { mutableStateOf(false) }
    var modeExpanded by remember { mutableStateOf(false) }

    val categories = listOf("Goat Sale", "Manure / Byproducts", "Breeding Service", "Farm Tour / Training", "Subsidy / Grant", "Other Income")
    val modes = listOf("Cash", "Bank Transfer", "UPI", "Cheque", "Card")

    Dialog(onDismissRequest = onDismiss) {
        Surface(shape = RoundedCornerShape(16.dp), color = Color.White, modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Record Farm Income", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = FarmGreenDark)

                // Destination Account
                ExposedDropdownMenuBox(expanded = accountExpanded, onExpandedChange = { accountExpanded = !accountExpanded }) {
                    val selAcc = accounts.firstOrNull { it.id == accountId }
                    OutlinedTextField(
                        value = "${selAcc?.account_name ?: "Select Account"} [${selAcc?.account_type ?: ""}]",
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Deposit into Account *") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = accountExpanded) },
                        modifier = Modifier.fillMaxWidth().menuAnchor()
                    )
                    ExposedDropdownMenu(expanded = accountExpanded, onDismissRequest = { accountExpanded = false }) {
                        accounts.forEach { acc ->
                            DropdownMenuItem(
                                text = { Text("${acc.account_name} [${acc.account_type}]") },
                                onClick = { accountId = acc.id; accountExpanded = false }
                            )
                        }
                    }
                }

                // Category
                ExposedDropdownMenuBox(expanded = categoryExpanded, onExpandedChange = { categoryExpanded = !categoryExpanded }) {
                    OutlinedTextField(
                        value = category,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Category *") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = categoryExpanded) },
                        modifier = Modifier.fillMaxWidth().menuAnchor()
                    )
                    ExposedDropdownMenu(expanded = categoryExpanded, onDismissRequest = { categoryExpanded = false }) {
                        categories.forEach { c ->
                            DropdownMenuItem(text = { Text(c) }, onClick = { category = c; categoryExpanded = false })
                        }
                    }
                }

                OutlinedTextField(
                    value = amountStr,
                    onValueChange = { amountStr = it },
                    label = { Text("Amount (₹) *") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("income_amount_input")
                )

                // Payment Mode
                ExposedDropdownMenuBox(expanded = modeExpanded, onExpandedChange = { modeExpanded = !modeExpanded }) {
                    OutlinedTextField(
                        value = mode,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Payment Mode") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = modeExpanded) },
                        modifier = Modifier.fillMaxWidth().menuAnchor()
                    )
                    ExposedDropdownMenu(expanded = modeExpanded, onDismissRequest = { modeExpanded = false }) {
                        modes.forEach { m ->
                            DropdownMenuItem(text = { Text(m) }, onClick = { mode = m; modeExpanded = false })
                        }
                    }
                }

                DatePickerField(
                    dateValue = dateStr,
                    onDateSelected = { dateStr = it },
                    label = "Receipt Date"
                )

                OutlinedTextField(
                    value = referenceStr,
                    onValueChange = { referenceStr = it },
                    label = { Text("Reference / Receipt No") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Notes") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    TextButton(onClick = onDismiss) { Text("Cancel") }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            val amt = amountStr.toDoubleOrNull() ?: 0.0
                            if (amt <= 0 || accountId.isBlank()) return@Button
                            onSave(accountId, amt, category, dateStr, mode, notes.trim().ifBlank { null }, referenceStr.trim().ifBlank { null })
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = FarmGreenDark),
                        enabled = (amountStr.toDoubleOrNull() ?: 0.0) > 0 && accountId.isNotBlank(),
                        modifier = Modifier.testTag("btn_save_income")
                    ) {
                        Text("Record Income")
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun RecordExpenseDialog(
    accounts: List<FinancialAccount>,
    onDismiss: () -> Unit,
    onSave: (accountId: String, amount: Double, category: String, date: String, mode: String, desc: String?, ref: String?, isCapex: Boolean) -> Unit
) {
    var accountId by remember { mutableStateOf(accounts.firstOrNull()?.id ?: "") }
    var amountStr by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("Feed & Fodder") }
    var mode by remember { mutableStateOf("UPI") }
    var isCapex by remember { mutableStateOf(false) }
    var dateStr by remember { mutableStateOf(SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())) }
    var referenceStr by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }

    var accountExpanded by remember { mutableStateOf(false) }
    var categoryExpanded by remember { mutableStateOf(false) }
    var modeExpanded by remember { mutableStateOf(false) }

    val categories = listOf(
        "Feed & Fodder",
        "Medicines & Vaccines",
        "Veterinary Doctor Fees",
        "Labour & Salary",
        "Electricity / EB",
        "Farm Rent",
        "Repairs & Maintenance",
        "Fuel & Transport",
        "Farm Equipment (CAPEX)",
        "Shed & Fencing (CAPEX)",
        "Consumables & Other"
    )
    val modes = listOf("Cash", "Bank Transfer", "UPI", "Cheque", "Card")

    Dialog(onDismissRequest = onDismiss) {
        Surface(shape = RoundedCornerShape(16.dp), color = Color.White, modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Record Farm Expense", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = FarmError)

                // Paid From Account
                ExposedDropdownMenuBox(expanded = accountExpanded, onExpandedChange = { accountExpanded = !accountExpanded }) {
                    val selAcc = accounts.firstOrNull { it.id == accountId }
                    OutlinedTextField(
                        value = "${selAcc?.account_name ?: "Select Account"} [${selAcc?.account_type ?: ""}]",
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Paid From Account *") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = accountExpanded) },
                        modifier = Modifier.fillMaxWidth().menuAnchor()
                    )
                    ExposedDropdownMenu(expanded = accountExpanded, onDismissRequest = { accountExpanded = false }) {
                        accounts.forEach { acc ->
                            DropdownMenuItem(
                                text = { Text("${acc.account_name} [${acc.account_type}] (${CurrencyUtils.formatInr(acc.current_balance)})") },
                                onClick = { accountId = acc.id; accountExpanded = false }
                            )
                        }
                    }
                }

                // Category
                ExposedDropdownMenuBox(expanded = categoryExpanded, onExpandedChange = { categoryExpanded = !categoryExpanded }) {
                    OutlinedTextField(
                        value = category,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Expense Category *") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = categoryExpanded) },
                        modifier = Modifier.fillMaxWidth().menuAnchor()
                    )
                    ExposedDropdownMenu(expanded = categoryExpanded, onDismissRequest = { categoryExpanded = false }) {
                        categories.forEach { c ->
                            DropdownMenuItem(
                                text = { Text(c) },
                                onClick = {
                                    category = c
                                    categoryExpanded = false
                                    isCapex = c.contains("CAPEX", ignoreCase = true)
                                }
                            )
                        }
                    }
                }

                OutlinedTextField(
                    value = amountStr,
                    onValueChange = { amountStr = it },
                    label = { Text("Amount (₹) *") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("expense_amount_input")
                )

                // Payment Mode
                ExposedDropdownMenuBox(expanded = modeExpanded, onExpandedChange = { modeExpanded = !modeExpanded }) {
                    OutlinedTextField(
                        value = mode,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Payment Mode") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = modeExpanded) },
                        modifier = Modifier.fillMaxWidth().menuAnchor()
                    )
                    ExposedDropdownMenu(expanded = modeExpanded, onDismissRequest = { modeExpanded = false }) {
                        modes.forEach { m ->
                            DropdownMenuItem(text = { Text(m) }, onClick = { mode = m; modeExpanded = false })
                        }
                    }
                }

                DatePickerField(
                    dateValue = dateStr,
                    onDateSelected = { dateStr = it },
                    label = "Payment Date"
                )

                OutlinedTextField(
                    value = referenceStr,
                    onValueChange = { referenceStr = it },
                    label = { Text("Bill / Invoice / Ref No") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Notes / Vendor") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    TextButton(onClick = onDismiss) { Text("Cancel") }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            val amt = amountStr.toDoubleOrNull() ?: 0.0
                            if (amt <= 0 || accountId.isBlank()) return@Button
                            onSave(accountId, amt, category, dateStr, mode, notes.trim().ifBlank { null }, referenceStr.trim().ifBlank { null }, isCapex)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = FarmError),
                        enabled = (amountStr.toDoubleOrNull() ?: 0.0) > 0 && accountId.isNotBlank(),
                        modifier = Modifier.testTag("btn_save_expense")
                    ) {
                        Text("Record Expense")
                    }
                }
            }
        }
    }
}
