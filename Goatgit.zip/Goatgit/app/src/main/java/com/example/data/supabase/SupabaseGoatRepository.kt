package com.example.data.supabase

import android.content.Context
import android.util.Log
import com.example.data.offline.AppDatabase
import com.example.data.offline.GoatEntity
import com.example.data.offline.OfflineSyncManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.filter
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/**
 * Extension mapper from Room GoatEntity to domain Goat.
 */
fun GoatEntity.toDomain(): Goat = Goat(
    id = id,
    name = name,
    tag_c = tag_c,
    breed_c = breed_c,
    sex_c = sex_c,
    status_c = status_c,
    birth_date_c = birth_date_c,
    weight_kg_c = weight_kg_c,
    dam_c = dam_c,
    sire_c = sire_c,
    source_c = source_c,
    purchase_date_c = purchase_date_c,
    purchase_cost_c = purchase_cost_c,
    farm_location_c = farm_location_c,
    color_c = color_c,
    notes_c = notes_c,
    created_at = created_at,
    origin_c = origin_c ?: effectiveOrigin,
    sire_id = sire_c,
    dam_id = dam_c,
    photo_url_c = photo_url_c,
    health_status_c = health_status_c ?: "Healthy"
)

/**
 * Extension mapper from domain Goat to Room GoatEntity.
 */
fun Goat.toEntity(isSynced: Boolean = true): GoatEntity = GoatEntity(
    id = id,
    name = name,
    tag_c = tag_c,
    breed_c = breed_c,
    sex_c = sex_c,
    status_c = status_c,
    birth_date_c = birth_date_c,
    weight_kg_c = weight_kg_c,
    dam_c = dam_c,
    sire_c = sire_c,
    source_c = source_c,
    purchase_date_c = purchase_date_c,
    purchase_cost_c = purchase_cost_c,
    farm_location_c = farm_location_c,
    color_c = color_c,
    notes_c = notes_c,
    created_at = created_at,
    updated_at = System.currentTimeMillis(),
    is_synced = isSynced,
    origin_c = origin_c ?: effectiveOrigin,
    photo_url_c = photo_url_c,
    health_status_c = health_status_c
)

/**
 * Repository class responsible for real-time synchronization of Goat data
 * between the local Room database and Supabase (WebSocket Realtime + REST API).
 */
class SupabaseGoatRepository(
    private val client: SupabaseClient,
    private val database: AppDatabase,
    private val syncManager: OfflineSyncManager? = null,
    private val coroutineScope: CoroutineScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
) {
    private val tag = "SupabaseGoatRepo"
    val tableName = "goats_c"

    // Secondary constructor taking Application Context for convenience
    constructor(context: Context) : this(
        client = SupabaseClient(SupabaseConfig(context)),
        database = AppDatabase.getDatabase(context)
    )

    // Secondary constructor with client configuration
    constructor(config: SupabaseClientConfig, database: AppDatabase) : this(
        client = SupabaseClient(config),
        database = database
    )

    // Real-time WebSocket connection status from Supabase
    val realtimeStatus: StateFlow<RealtimeStatus> = client.realtime.status

    // Continuous flow of goats from local database, auto-updating on real-time changes
    val goatsFlow: Flow<List<Goat>> = database.goatDao().getAllGoatsFlow()
        .map { list -> list.map { it.toDomain() } }

    private val _isSyncing = MutableStateFlow(false)
    val isSyncing: StateFlow<Boolean> = _isSyncing.asStateFlow()

    private val _lastSyncTimestamp = MutableStateFlow(0L)
    val lastSyncTimestamp: StateFlow<Long> = _lastSyncTimestamp.asStateFlow()

    private val _syncError = MutableStateFlow<String?>(null)
    val syncError: StateFlow<String?> = _syncError.asStateFlow()

    private val _realtimeEventCount = MutableStateFlow(0)
    val realtimeEventCount: StateFlow<Int> = _realtimeEventCount.asStateFlow()

    private var realtimeJob: Job? = null

    init {
        startRealtimeSync()
    }

    /**
     * Start listening to real-time events for goats from Supabase via WebSocket.
     */
    fun startRealtimeSync() {
        if (realtimeJob?.isActive == true) return

        client.connectRealtime()

        realtimeJob = coroutineScope.launch {
            client.realtime.realtimeEvents
                .filter { it.table.equals(tableName, ignoreCase = true) || it.table.equals("goats", ignoreCase = true) }
                .collect { event ->
                    _realtimeEventCount.value++
                    handleRealtimeEvent(event)
                }
        }
        Log.i(tag, "Real-time sync started for table '$tableName'")
    }

    /**
     * Stop real-time synchronization.
     */
    fun stopRealtimeSync() {
        realtimeJob?.cancel()
        realtimeJob = null
        Log.i(tag, "Real-time sync stopped")
    }

    /**
     * Reconnect the real-time channel.
     */
    fun reconnectRealtimeSync() {
        stopRealtimeSync()
        client.reconnectRealtime()
        startRealtimeSync()
    }

    /**
     * Handle incoming real-time change event (INSERT, UPDATE, DELETE)
     * and persist directly to the local Room database.
     */
    suspend fun handleRealtimeEvent(event: SupabaseRealtimeEvent) = withContext(Dispatchers.IO) {
        try {
            val record = event.record
            val oldRecord = event.oldRecord
            val recordId = record?.optString("id")?.ifBlank { null }
                ?: oldRecord?.optString("id")?.ifBlank { null }

            Log.i(tag, "Handling realtime event: ${event.eventType} for goat id=$recordId")

            when (event.eventType) {
                SupabaseRealtimeEvent.EventType.DELETE -> {
                    if (!recordId.isNullOrBlank()) {
                        database.goatDao().deleteById(recordId)
                    }
                }
                SupabaseRealtimeEvent.EventType.INSERT,
                SupabaseRealtimeEvent.EventType.UPDATE -> {
                    if (record != null && !recordId.isNullOrBlank()) {
                        val entity = parseGoatEntityFromJson(record, recordId)
                        database.goatDao().insertOrUpdate(entity)
                    }
                }
                SupabaseRealtimeEvent.EventType.UNKNOWN -> {
                    syncGoats()
                }
            }
        } catch (e: Exception) {
            Log.e(tag, "Error processing realtime goat event: ${e.message}", e)
        }
    }

    /**
     * Fetch all goats from remote Supabase and sync with local Room database.
     */
    suspend fun syncGoats(): Result<List<Goat>> = withContext(Dispatchers.IO) {
        _isSyncing.value = true
        _syncError.value = null
        try {
            val res = client.get(tableName, "select=*&order=created_at.desc")
            if (res.isSuccess) {
                val array: JSONArray = res.getOrThrow()
                val entities = mutableListOf<GoatEntity>()
                for (i in 0 until array.length()) {
                    val obj = array.getJSONObject(i)
                    val id = obj.optString("id").ifBlank { UUID.randomUUID().toString() }
                    entities.add(parseGoatEntityFromJson(obj, id))
                }
                database.goatDao().insertAll(entities)
                _lastSyncTimestamp.value = System.currentTimeMillis()
                val goats = entities.map { it.toDomain() }
                Result.success(goats)
            } else {
                val msg = res.exceptionOrNull()?.message ?: "Sync failed"
                _syncError.value = msg
                val local = database.goatDao().getAllGoats().map { it.toDomain() }
                Result.success(local)
            }
        } catch (e: Exception) {
            _syncError.value = e.message
            Result.failure(e)
        } finally {
            _isSyncing.value = false
        }
    }

    /**
     * Get all goats from local cache.
     */
    suspend fun getGoats(): List<Goat> = withContext(Dispatchers.IO) {
        database.goatDao().getAllGoats().map { it.toDomain() }
    }

    /**
     * Get reactive flow of all goats.
     */
    fun getLocalGoatsFlow(): Flow<List<Goat>> = goatsFlow

    /**
     * Get a goat by ID from local cache.
     */
    suspend fun getGoatById(id: String): Goat? = withContext(Dispatchers.IO) {
        database.goatDao().getGoatById(id)?.toDomain()
    }

    /**
     * Observe a goat reactively by ID.
     */
    fun observeGoat(id: String): Flow<Goat?> {
        return database.goatDao().getGoatByIdFlow(id).map { it?.toDomain() }
    }

    /**
     * Find a goat by Tag ID.
     */
    suspend fun getGoatByTag(tagId: String): Goat? = withContext(Dispatchers.IO) {
        database.goatDao().getAllGoats().firstOrNull { it.tag_c.equals(tagId, ignoreCase = true) }?.toDomain()
    }

    /**
     * Add a new Goat. Saves locally immediately, enqueues sync or uploads to Supabase,
     * which broadcasts real-time update to all subscribers.
     */
    suspend fun addGoat(goat: Goat): Result<Goat> = withContext(Dispatchers.IO) {
        try {
            val entity = goat.toEntity(isSynced = false)
            database.goatDao().insertOrUpdate(entity)

            val json = goatToJson(goat)
            if (syncManager != null) {
                syncManager.enqueueOperation(tableName, goat.id, "CREATE", json)
            } else {
                val res = client.insert(tableName, json)
                if (res.isSuccess) {
                    database.goatDao().insertOrUpdate(goat.toEntity(isSynced = true))
                }
            }
            Result.success(goat)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Alias for addGoat.
     */
    suspend fun insertGoat(goat: Goat): Result<Goat> = addGoat(goat)

    /**
     * Update an existing Goat. Saves locally, enqueues/pushes to Supabase.
     */
    suspend fun updateGoat(goat: Goat): Result<Goat> = withContext(Dispatchers.IO) {
        try {
            val entity = goat.toEntity(isSynced = false)
            database.goatDao().insertOrUpdate(entity)

            val json = goatToJson(goat)
            if (syncManager != null) {
                syncManager.enqueueOperation(tableName, goat.id, "UPDATE", json)
            } else {
                val res = client.update(tableName, "id=eq.${goat.id}", json)
                if (res.isSuccess) {
                    database.goatDao().insertOrUpdate(goat.toEntity(isSynced = true))
                }
            }
            Result.success(goat)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Delete a Goat by ID. Removes locally and from Supabase.
     */
    suspend fun deleteGoat(goatId: String): Result<Boolean> = withContext(Dispatchers.IO) {
        try {
            database.goatDao().deleteById(goatId)
            if (syncManager != null) {
                syncManager.enqueueOperation(tableName, goatId, "DELETE", JSONObject().apply { put("id", goatId) })
            } else {
                client.delete(tableName, "id=eq.$goatId")
            }
            Result.success(true)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Helper to convert a Goat domain object to JSON for Supabase REST API.
     */
    fun goatToJson(goat: Goat): JSONObject {
        return JSONObject().apply {
            put("id", goat.id)
            put("name", goat.name)
            put("tag_c", goat.tag_c)
            put("breed_c", goat.breed_c)
            put("sex_c", goat.sex_c)
            put("status_c", goat.status_c)
            if (!goat.birth_date_c.isNullOrBlank()) put("birth_date_c", goat.birth_date_c)
            if (goat.weight_kg_c != null) put("weight_kg_c", goat.weight_kg_c)
            if (!goat.dam_c.isNullOrBlank()) put("dam_c", goat.dam_c)
            if (!goat.sire_c.isNullOrBlank()) put("sire_c", goat.sire_c)
            if (!goat.source_c.isNullOrBlank()) put("source_c", goat.source_c)
            if (!goat.purchase_date_c.isNullOrBlank()) put("purchase_date_c", goat.purchase_date_c)
            if (goat.purchase_cost_c != null) put("purchase_cost_c", goat.purchase_cost_c)
            if (!goat.farm_location_c.isNullOrBlank()) put("farm_location_c", goat.farm_location_c)
            if (!goat.color_c.isNullOrBlank()) put("color_c", goat.color_c)
            if (!goat.notes_c.isNullOrBlank()) put("notes_c", goat.notes_c)
            put("origin_c", goat.effectiveOrigin)
            if (!goat.photo_url_c.isNullOrBlank()) put("photo_url_c", goat.photo_url_c)
            put("health_status_c", goat.health_status_c)
        }
    }

    /**
     * Helper to parse a JSON record from Supabase into a Room GoatEntity.
     */
    fun parseGoatEntityFromJson(obj: JSONObject, recordId: String): GoatEntity {
        fun JSONObject.optNullable(key: String): String? =
            if (has(key) && !isNull(key) && optString(key).isNotBlank()) optString(key) else null

        return GoatEntity(
            id = recordId,
            name = obj.optString("name", "Goat"),
            tag_c = obj.optString("tag_c", obj.optString("tag", "")),
            breed_c = obj.optString("breed_c", obj.optString("breed", "Boer")),
            sex_c = obj.optString("sex_c", obj.optString("sex", "Doe")),
            status_c = obj.optString("status_c", obj.optString("status", "Active")),
            birth_date_c = obj.optNullable("birth_date_c"),
            weight_kg_c = if (obj.has("weight_kg_c") && !obj.isNull("weight_kg_c")) obj.optDouble("weight_kg_c") else null,
            dam_c = obj.optNullable("dam_c"),
            sire_c = obj.optNullable("sire_c"),
            source_c = obj.optString("source_c", "Born on farm"),
            purchase_date_c = obj.optNullable("purchase_date_c"),
            purchase_cost_c = if (obj.has("purchase_cost_c") && !obj.isNull("purchase_cost_c")) obj.optDouble("purchase_cost_c") else null,
            farm_location_c = obj.optString("farm_location_c", "Barn A"),
            color_c = obj.optNullable("color_c"),
            notes_c = obj.optNullable("notes_c"),
            created_at = obj.optNullable("created_at"),
            updated_at = System.currentTimeMillis(),
            is_synced = true,
            origin_c = obj.optNullable("origin_c"),
            photo_url_c = obj.optNullable("photo_url_c"),
            health_status_c = obj.optString("health_status_c", "Healthy")
        )
    }
}
