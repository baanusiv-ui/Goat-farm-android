package com.example.ui.screens.weaning

import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.weaning.KidWeaningItem
import com.example.data.weaning.WeaningReportData
import java.util.Locale

@Composable
fun WeaningReportsView(
    reportsData: WeaningReportData,
    items: List<KidWeaningItem>,
    onShowMessage: (String) -> Unit
) {
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current
    var selectedReportSubTab by remember { mutableIntStateOf(0) }
    val subTabs = listOf(
        "Register",
        "By Breed",
        "By Mother",
        "ADG Growth",
        "Delayed",
        "Monthly",
        "Cost Separation"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Export Action Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text("Weaning Analytics & Reports", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Color(0xFF1B5E20))
                Text("Complete register, breed benchmarks and gain metrics", fontSize = 11.sp, color = Color.Gray)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedButton(
                    onClick = {
                        val csv = generateWeaningCsv(items)
                        clipboardManager.setText(AnnotatedString(csv))
                        onShowMessage("Weaning Register CSV copied to clipboard!")
                    },
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                    modifier = Modifier.testTag("export_csv_btn")
                ) {
                    Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Copy CSV", fontSize = 11.sp)
                }

                Button(
                    onClick = {
                        val csv = generateWeaningCsv(items)
                        val sendIntent = Intent().apply {
                            action = Intent.ACTION_SEND
                            putExtra(Intent.EXTRA_TEXT, csv)
                            type = "text/plain"
                        }
                        val shareIntent = Intent.createChooser(sendIntent, "Export Weaning Register")
                        context.startActivity(shareIntent)
                    },
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32)),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                    modifier = Modifier.testTag("share_csv_btn")
                ) {
                    Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Share", fontSize = 11.sp)
                }
            }
        }

        // Subtabs
        ScrollableTabRow(
            selectedTabIndex = selectedReportSubTab,
            edgePadding = 0.dp,
            containerColor = Color.Transparent,
            divider = {}
        ) {
            subTabs.forEachIndexed { idx, title ->
                Tab(
                    selected = selectedReportSubTab == idx,
                    onClick = { selectedReportSubTab = idx },
                    text = { Text(title, fontSize = 12.sp, fontWeight = if (selectedReportSubTab == idx) FontWeight.Bold else FontWeight.Normal) }
                )
            }
        }

        // Body based on subtab
        when (selectedReportSubTab) {
            0 -> WeaningRegisterTab(items)
            1 -> WeaningByBreedTab(reportsData)
            2 -> WeaningByMotherTab(reportsData)
            3 -> WeaningAdgTab(items)
            4 -> WeaningDelayedTab(reportsData.delayedKidsList)
            5 -> WeaningMonthlyTab(reportsData)
            6 -> WeaningCostSeparationTab(items)
        }
    }
}

@Composable
fun WeaningRegisterTab(items: List<KidWeaningItem>) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items(items) { item ->
            Card(
                shape = RoundedCornerShape(10.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        val tag = item.kidGoat?.tag_c ?: "Tag-${item.record.goat_id.take(4)}"
                        Text("Kid #$tag", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color(0xFF1B5E20))
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = when (item.dynamicStatus) {
                                "WEANED" -> Color(0xFFE8F5E9)
                                "DUE" -> Color(0xFFFFF3E0)
                                "DELAYED" -> Color(0xFFFFEBEE)
                                else -> Color(0xFFF5F5F5)
                            }
                        ) {
                            Text(
                                text = item.dynamicStatus,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = when (item.dynamicStatus) {
                                    "WEANED" -> Color(0xFF2E7D32)
                                    "DUE" -> Color(0xFFE65100)
                                    "DELAYED" -> Color(0xFFC62828)
                                    else -> Color.DarkGray
                                }
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Breed: ${item.kidGoat?.breed_c ?: "Boer"} • Sex: ${item.kidGoat?.sex_c ?: "Doe"}", fontSize = 12.sp, color = Color.Gray)
                        Text("Dam: ${item.motherGoat?.tag_c ?: item.kidGoat?.dam_c ?: "—"}", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    }

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Birth: ${item.record.birth_date} (Age: ${item.currentAgeDays}d)", fontSize = 12.sp, color = Color.Gray)
                        val w = item.record.weight_at_weaning ?: item.latestWeightKg
                        Text("Weight: ${w?.let { "$it kg" } ?: "Not weighed"}", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }

                    if (item.adgFromBirthGramsDay != null && item.adgFromBirthGramsDay > 0) {
                        Text(
                            text = "ADG (Gain): ${item.adgFromBirthGramsDay.toInt()} g/day",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFE65100)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun WeaningByBreedTab(reportsData: WeaningReportData) {
    if (reportsData.breedBreakdown.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("No weaned kids recorded yet to generate breed benchmarks.", color = Color.Gray, fontSize = 13.sp)
        }
    } else {
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(reportsData.breedBreakdown.values.toList()) { stat ->
                Card(
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(stat.breed, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color(0xFF1B5E20))
                            Text("${stat.count} kids weaned", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color(0xFF2E7D32))
                        }
                        HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Avg Weaning Weight:", fontSize = 12.sp, color = Color.Gray)
                            Text("${String.format(Locale.US, "%.2f", stat.avgWeightKg)} kg", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Avg Weaning Age:", fontSize = 12.sp, color = Color.Gray)
                            Text("${stat.avgAgeDays.toInt()} days", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Avg ADG (Gain):", fontSize = 12.sp, color = Color.Gray)
                            Text("${stat.avgAdgGramsDay.toInt()} g/day", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color(0xFFE65100))
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun WeaningByMotherTab(reportsData: WeaningReportData) {
    if (reportsData.motherBreakdown.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("No weaned kids linked to mothers recorded yet.", color = Color.Gray, fontSize = 13.sp)
        }
    } else {
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(reportsData.motherBreakdown.values.toList()) { stat ->
                Card(
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Dam #${stat.motherTag} (${stat.motherName})", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color(0xFF1B5E20))
                            Text("${stat.weanedKidsCount} kids", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color(0xFF2E7D32))
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Avg Kid Weaning Weight:", fontSize = 12.sp, color = Color.Gray)
                            Text("${String.format(Locale.US, "%.2f", stat.avgWeaningWeightKg)} kg", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Avg Kid ADG:", fontSize = 12.sp, color = Color.Gray)
                            Text("${stat.avgAdgGramsDay.toInt()} g/day", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color(0xFFE65100))
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun WeaningAdgTab(items: List<KidWeaningItem>) {
    val itemsWithAdg = items.filter { (it.adgFromBirthGramsDay ?: 0.0) > 0 }.sortedByDescending { it.adgFromBirthGramsDay }
    if (itemsWithAdg.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("No ADG gain data available yet. Record weaning weights to populate growth curves.", color = Color.Gray, fontSize = 13.sp)
        }
    } else {
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(itemsWithAdg) { item ->
                Card(
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            val tag = item.kidGoat?.tag_c ?: "Tag-${item.record.goat_id.take(4)}"
                            Text("Kid #$tag • ${item.kidGoat?.breed_c ?: "Boer"}", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Text("Age: ${item.currentAgeDays}d • Weight: ${item.latestWeightKg ?: 0.0} kg", fontSize = 11.sp, color = Color.Gray)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                "${item.adgFromBirthGramsDay?.toInt()} g/day",
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp,
                                color = Color(0xFFE65100)
                            )
                            Text("Daily Growth", fontSize = 10.sp, color = Color.Gray)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun WeaningDelayedTab(delayedList: List<KidWeaningItem>) {
    if (delayedList.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color(0xFF2E7D32), modifier = Modifier.size(36.dp))
                Spacer(modifier = Modifier.height(6.dp))
                Text("All kids are currently on schedule! No overdue or delayed weaning.", fontWeight = FontWeight.SemiBold, fontSize = 13.sp, color = Color(0xFF2E7D32))
            }
        }
    } else {
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(delayedList) { item ->
                Card(
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFFFEBEE)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            val tag = item.kidGoat?.tag_c ?: "Tag-${item.record.goat_id.take(4)}"
                            Text("Kid #$tag (OVERDUE)", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color(0xFFC62828))
                            Text("Target: ${item.record.weaning_due_date}", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color(0xFFC62828))
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("Current Age: ${item.currentAgeDays} days • Mother: ${item.motherGoat?.tag_c ?: item.kidGoat?.dam_c ?: "—"}", fontSize = 12.sp)
                        if (!item.record.reason_if_delayed.isNullOrBlank()) {
                            Text("Reason for Delay: ${item.record.reason_if_delayed}", fontSize = 11.sp, color = Color.DarkGray, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun WeaningMonthlyTab(reportsData: WeaningReportData) {
    if (reportsData.monthlySummary.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("No monthly weaning history recorded yet.", color = Color.Gray, fontSize = 13.sp)
        }
    } else {
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(reportsData.monthlySummary) { m ->
                Card(
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Month: ${m.monthYear}", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color(0xFF1B5E20))
                            Text("${m.count} kids weaned", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color(0xFF2E7D32))
                        }
                        HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Avg Weight: ${String.format(Locale.US, "%.2f", m.avgWeightKg)} kg", fontSize = 12.sp)
                            Text("Avg Age: ${m.avgAgeDays.toInt()} days", fontSize = 12.sp)
                            Text("Avg ADG: ${m.avgAdgGramsDay.toInt()} g/d", fontSize = 12.sp, color = Color(0xFFE65100), fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun WeaningCostSeparationTab(items: List<KidWeaningItem>) {
    // Requirement 15: Separate Pre-weaning cost vs Post-weaning cost breakdown
    val weanedItems = items.filter { it.record.status == "WEANED" }

    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item {
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFF1F8E9)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("Pre-Weaning vs Post-Weaning Cost Allocation", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color(0xFF1B5E20))
                    Text(
                        "Transparently accounts for dam lactation/colostrum/creep feed allocation prior to weaning versus grower concentrate, green fodder, and health upkeep after weaning.",
                        fontSize = 11.sp,
                        color = Color.DarkGray
                    )
                }
            }
        }

        items(weanedItems) { item ->
            val tag = item.kidGoat?.tag_c ?: "Tag-${item.record.goat_id.take(4)}"
            val ageAtWean = item.record.age_at_weaning_days ?: 90
            val totalAge = item.currentAgeDays.coerceAtLeast(ageAtWean)
            val postWeanDays = (totalAge - ageAtWean).coerceAtLeast(0)

            // Realistic estimated farm cost calculation:
            // Pre-weaning: ~₹12/day (Dam nursing share + creep starter)
            // Post-weaning: ~₹22/day (Green fodder 3kg + dry hay + grower ration)
            val preWeanCost = ageAtWean * 12.0
            val postWeanCost = postWeanDays * 22.0
            val totalCost = preWeanCost + postWeanCost

            Card(
                shape = RoundedCornerShape(10.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Kid #$tag (${item.kidGoat?.breed_c ?: "Boer"})", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Text("Total: ₹${String.format(Locale.US, "%.0f", totalCost)}", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color(0xFF1B5E20))
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Pre-Weaning Cost ($ageAtWean d):", fontSize = 12.sp, color = Color.Gray)
                        Text("₹${String.format(Locale.US, "%.0f", preWeanCost)}", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color(0xFFE65100))
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Post-Weaning Cost ($postWeanDays d):", fontSize = 12.sp, color = Color.Gray)
                        Text("₹${String.format(Locale.US, "%.0f", postWeanCost)}", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color(0xFF0288D1))
                    }
                    val weight = item.record.weight_at_weaning ?: item.latestWeightKg ?: 1.0
                    val costPerKgAtWean = preWeanCost / weight
                    Text("Cost per kg at Weaning: ₹${String.format(Locale.US, "%.2f", costPerKgAtWean)} / kg", fontSize = 11.sp, color = Color.DarkGray, fontWeight = FontWeight.SemiBold)
                }
            }
        }
    }
}

fun generateWeaningCsv(items: List<KidWeaningItem>): String {
    val sb = StringBuilder()
    sb.append("Goat Tag,Name,Breed,Sex,Mother,Birth Date,Due Date,Actual Weaning Date,Age at Wean (Days),Weaning Weight (kg),ADG (g/day),Method,Status,Feed Group,Vaccination Status,Deworming Status\n")
    for (it in items) {
        val tag = it.kidGoat?.tag_c ?: ""
        val name = it.kidGoat?.name ?: ""
        val breed = it.kidGoat?.breed_c ?: ""
        val sex = it.kidGoat?.sex_c ?: ""
        val dam = it.motherGoat?.tag_c ?: it.kidGoat?.dam_c ?: ""
        val bDate = it.record.birth_date
        val dueDate = it.record.weaning_due_date
        val actDate = it.record.actual_weaning_date ?: ""
        val age = it.record.age_at_weaning_days ?: it.currentAgeDays
        val weight = it.record.weight_at_weaning ?: it.latestWeightKg ?: ""
        val adg = it.adgFromBirthGramsDay?.toInt() ?: ""
        val method = it.record.weaning_method ?: ""
        val status = it.dynamicStatus
        val feed = it.record.post_weaning_feed_group
        val vax = it.vaccinationStatus.replace(",", ";")
        val deworm = it.dewormingStatus.replace(",", ";")

        sb.append("\"$tag\",\"$name\",\"$breed\",\"$sex\",\"$dam\",\"$bDate\",\"$dueDate\",\"$actDate\",\"$age\",\"$weight\",\"$adg\",\"$method\",\"$status\",\"$feed\",\"$vax\",\"$deworm\"\n")
    }
    return sb.toString()
}
