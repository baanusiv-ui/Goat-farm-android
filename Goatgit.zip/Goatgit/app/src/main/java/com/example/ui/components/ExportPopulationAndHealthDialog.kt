package com.example.ui.components

import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.offline.DailyHealthObservationEntity
import com.example.data.supabase.*
import com.example.ui.theme.*
import com.example.util.CsvExportHelper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.*

enum class ExportCsvType(val label: String, val subtitle: String) {
    COMBINED(
        "Combined: Population & Health",
        "Complete herd demographic roster + all clinical & observation logs"
    ),
    POPULATION_ONLY(
        "Goat Population Census",
        "Headcount roster, tags, breeds, sex, status, current weight & pedigree"
    ),
    HEALTH_ONLY(
        "Health & Clinical Register",
        "All timestamped weights, vaccinations, dewormings & treatments"
    ),
    WEIGHTS_ONLY(
        "Weight & Growth Logs",
        "Periodic weigh-in history, methods, BCS scores & health notes"
    )
}

@Composable
fun ExportPopulationAndHealthDialog(
    repository: GoatRepository,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current
    val coroutineScope = rememberCoroutineScope()

    var selectedExportType by remember { mutableStateOf(ExportCsvType.COMBINED) }
    var isLoadingData by remember { mutableStateOf(true) }
    var showPreviewText by remember { mutableStateOf(false) }

    // Loaded data states
    var goats by remember { mutableStateOf<List<Goat>>(emptyList()) }
    var weights by remember { mutableStateOf<List<GoatWeight>>(emptyList()) }
    var vaccinations by remember { mutableStateOf<List<VaccinationRecord>>(emptyList()) }
    var dewormings by remember { mutableStateOf<List<DewormingRecord>>(emptyList()) }
    var treatments by remember { mutableStateOf<List<TreatmentRecord>>(emptyList()) }
    var observations by remember { mutableStateOf<List<DailyHealthObservationEntity>>(emptyList()) }

    // Fetch all current population and health logs from Room DB
    LaunchedEffect(Unit) {
        isLoadingData = true
        withContext(Dispatchers.IO) {
            val goatsRes = repository.getGoats()
            if (goatsRes.isSuccess) goats = goatsRes.getOrThrow()

            val weightsRes = repository.getAllWeights()
            if (weightsRes.isSuccess) weights = weightsRes.getOrThrow()

            val vacRes = repository.getVaccinations()
            if (vacRes.isSuccess) vaccinations = vacRes.getOrThrow()

            val dewRes = repository.getDewormings()
            if (dewRes.isSuccess) dewormings = dewRes.getOrThrow()

            val treatRes = repository.getTreatments()
            if (treatRes.isSuccess) treatments = treatRes.getOrThrow()

            observations = repository.database.dailyHealthObservationDao().getAllObservations()
        }
        isLoadingData = false
    }

    // Dynamic CSV Content Generation
    val csvContent = remember(selectedExportType, goats, weights, vaccinations, dewormings, treatments, observations) {
        when (selectedExportType) {
            ExportCsvType.COMBINED -> CsvExportHelper.generateCombinedPopulationAndHealthCsv(
                goats, weights, vaccinations, dewormings, treatments, observations
            )
            ExportCsvType.POPULATION_ONLY -> CsvExportHelper.generateGoatPopulationCsv(goats)
            ExportCsvType.HEALTH_ONLY -> CsvExportHelper.generateHealthLogsCsv(
                goats, weights, vaccinations, dewormings, treatments, observations
            )
            ExportCsvType.WEIGHTS_ONLY -> CsvExportHelper.generateWeightLogsOnlyCsv(goats, weights)
        }
    }

    // Default File Name based on type and timestamp
    val todayFormatted = remember { SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(Date()) }
    val defaultFileName = remember(selectedExportType, todayFormatted) {
        when (selectedExportType) {
            ExportCsvType.COMBINED -> "goat_population_and_health_audit_$todayFormatted.csv"
            ExportCsvType.POPULATION_ONLY -> "goat_population_census_$todayFormatted.csv"
            ExportCsvType.HEALTH_ONLY -> "goat_health_clinical_register_$todayFormatted.csv"
            ExportCsvType.WEIGHTS_ONLY -> "goat_weight_growth_logs_$todayFormatted.csv"
        }
    }

    // Modern Android Storage Access Framework (SAF) Launcher for Download / Save
    val createDocumentLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("text/csv")
    ) { uri ->
        if (uri != null) {
            val success = CsvExportHelper.writeCsvToUri(context, uri, csvContent)
            if (success) {
                Toast.makeText(context, "CSV downloaded & saved to device successfully!", Toast.LENGTH_LONG).show()
                onDismiss()
            } else {
                Toast.makeText(context, "Failed to save CSV file.", Toast.LENGTH_SHORT).show()
            }
        }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(defaultElevation = 6.dp),
            modifier = Modifier
                .fillMaxWidth(0.94f)
                .fillMaxHeight(0.90f)
                .testTag("export_csv_modal_dialog")
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Top Header Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = FarmGreenLight.copy(alpha = 0.25f),
                            modifier = Modifier.size(42.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(Icons.Default.FileDownload, contentDescription = null, tint = FarmGreenDark, modifier = Modifier.size(24.dp))
                            }
                        }
                        Column {
                            Text(
                                text = "Export Population & Health",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF0F172A)
                            )
                            Text(
                                text = "Downloadable CSV Spreadsheet Format",
                                fontSize = 11.sp,
                                color = Color(0xFF64748B)
                            )
                        }
                    }

                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.Gray)
                    }
                }

                HorizontalDivider(color = Color(0xFFF1F5F9))

                if (isLoadingData) {
                    Box(modifier = Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            CircularProgressIndicator(color = FarmGreenPrimary)
                            Text("Compiling census and health database...", fontSize = 12.sp, color = Color.Gray)
                        }
                    }
                } else {
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        // Data Summary Banner
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = Color(0xFFF8FAFC),
                            border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text("Live Room Database Counts", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF475569))
                                    Text(
                                        text = "${goats.size} Goats • ${weights.size} Weights • ${vaccinations.size} Vaccines • ${dewormings.size} Dewormings • ${treatments.size} Treatments",
                                        fontSize = 11.sp,
                                        color = FarmGreenDark,
                                        fontWeight = FontWeight.Medium
                                    )
                                }
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = FarmGreenContainer
                                ) {
                                    Text(
                                        text = "UTF-8 CSV",
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = FarmGreenDark,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                        }

                        // Select Export Scope
                        Text("Select Export Scope:", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFF334155))

                        ExportCsvType.values().forEach { type ->
                            val isSelected = selectedExportType == type
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = if (isSelected) Color(0xFFF0FDF4) else Color.White,
                                border = BorderStroke(1.dp, if (isSelected) FarmGreenPrimary else Color(0xFFE2E8F0)),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { selectedExportType = type }
                                    .testTag("export_type_option_${type.name.lowercase()}")
                            ) {
                                Row(
                                    modifier = Modifier.padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    RadioButton(
                                        selected = isSelected,
                                        onClick = { selectedExportType = type },
                                        colors = RadioButtonDefaults.colors(selectedColor = FarmGreenPrimary)
                                    )
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = type.label,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 13.sp,
                                            color = if (isSelected) FarmGreenDark else Color(0xFF0F172A)
                                        )
                                        Text(
                                            text = type.subtitle,
                                            fontSize = 11.sp,
                                            color = Color(0xFF64748B),
                                            lineHeight = 15.sp
                                        )
                                    }
                                }
                            }
                        }

                        // File Details Card
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = Color(0xFFEFF6FF),
                            border = BorderStroke(1.dp, Color(0xFFBFDBFE)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text("Output File:", fontSize = 10.sp, color = Color(0xFF1E40AF), fontWeight = FontWeight.SemiBold)
                                    Text("${csvContent.lines().size} lines • ${csvContent.toByteArray().size} bytes", fontSize = 10.sp, color = Color(0xFF1E40AF))
                                }
                                Text(
                                    text = defaultFileName,
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF1E3A8A)
                                )
                            }
                        }

                        // Toggle Live Text Preview
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { showPreviewText = !showPreviewText },
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = if (showPreviewText) "Hide CSV Raw Preview" else "Show CSV Raw Preview",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = FarmGreenDark
                            )
                            Icon(
                                imageVector = if (showPreviewText) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                                contentDescription = null,
                                tint = FarmGreenDark
                            )
                        }

                        AnimatedVisibility(visible = showPreviewText) {
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = Color(0xFF0F172A),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .heightIn(max = 200.dp)
                            ) {
                                Column(
                                    modifier = Modifier
                                        .padding(10.dp)
                                        .verticalScroll(rememberScrollState())
                                        .horizontalScroll(rememberScrollState())
                                ) {
                                    Text(
                                        text = csvContent.lines().take(40).joinToString("\n"),
                                        fontFamily = FontFamily.Monospace,
                                        fontSize = 10.sp,
                                        color = Color(0xFFE2E8F0),
                                        lineHeight = 14.sp
                                    )
                                }
                            }
                        }
                    }

                    // Action Buttons Row
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        // 1. Primary Action: Download CSV File to Device via SAF
                        Button(
                            onClick = {
                                createDocumentLauncher.launch(defaultFileName)
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = FarmGreenPrimary),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("btn_download_csv_file")
                        ) {
                            Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Download CSV File", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        }

                        // 2. Secondary Actions: Share / Open App & Copy
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            // Share / Open in Excel/Sheets
                            OutlinedButton(
                                onClick = {
                                    coroutineScope.launch {
                                        val tempFile = CsvExportHelper.writeCsvToCacheFile(context, defaultFileName, csvContent)
                                        val shareIntent = CsvExportHelper.createShareIntent(
                                            context,
                                            tempFile,
                                            "Goat Population & Health CSV Export"
                                        )
                                        context.startActivity(Intent.createChooser(shareIntent, "Share / Open CSV File"))
                                    }
                                },
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(42.dp)
                                    .testTag("btn_share_csv_export")
                            ) {
                                Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Share / Open", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                            }

                            // Copy to Clipboard
                            OutlinedButton(
                                onClick = {
                                    clipboardManager.setText(AnnotatedString(csvContent))
                                    Toast.makeText(context, "CSV copied to clipboard!", Toast.LENGTH_SHORT).show()
                                },
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(42.dp)
                                    .testTag("btn_copy_csv_clipboard")
                            ) {
                                Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Copy CSV", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                            }
                        }
                    }
                }
            }
        }
    }
}
