package com.example.ui.screens.health

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.supabase.*
import com.example.ui.theme.*
import com.example.util.CurrencyUtils
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HealthReportsScreen(
    repository: GoatRepository,
    onNavigateBack: () -> Unit
) {
    BackHandler { onNavigateBack() }

    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    var vaccinations by remember { mutableStateOf<List<VaccinationRecord>>(emptyList()) }
    var dewormings by remember { mutableStateOf<List<DewormingRecord>>(emptyList()) }
    var treatments by remember { mutableStateOf<List<TreatmentRecord>>(emptyList()) }
    var quarantines by remember { mutableStateOf<List<QuarantineRecord>>(emptyList()) }
    var goats by remember { mutableStateOf<List<Goat>>(emptyList()) }
    var alerts by remember { mutableStateOf<List<HealthAlert>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }

    // 0: Vaccination Register, 1: Deworming Register, 2: Treatment Register, 3: Quarantine Register, 4: Cost & Summary
    var selectedRegisterTab by remember { mutableIntStateOf(0) }
    var showExportDialog by remember { mutableStateOf(false) }
    var exportPreviewContent by remember { mutableStateOf("") }
    var exportTitle by remember { mutableStateOf("") }

    fun loadData() {
        isLoading = true
        coroutineScope.launch {
            val vRes = repository.getVaccinations()
            if (vRes.isSuccess) vaccinations = vRes.getOrThrow()

            val dRes = repository.getDewormings()
            if (dRes.isSuccess) dewormings = dRes.getOrThrow()

            val tRes = repository.getTreatments()
            if (tRes.isSuccess) treatments = tRes.getOrThrow()

            val qRes = repository.getQuarantineRecords()
            if (qRes.isSuccess) quarantines = qRes.getOrThrow()

            val gRes = repository.getGoats()
            if (gRes.isSuccess) goats = gRes.getOrThrow()

            val aRes = repository.getHealthAlerts()
            if (aRes.isSuccess) alerts = aRes.getOrThrow()

            isLoading = false
        }
    }

    LaunchedEffect(Unit) {
        loadData()
    }

    val registerTabs = listOf(
        "Vaccination Register",
        "Deworming Register",
        "Treatment Register",
        "Quarantine Register",
        "Costs & Analytics"
    )

    val goatsMap = remember(goats) { goats.associateBy { it.id } }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "Health & Clinical Reports",
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp
                        )
                        Text(
                            text = "Statutory & Management Registers",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack, modifier = Modifier.testTag("health_reports_btn_back")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(
                        onClick = {
                            when (selectedRegisterTab) {
                                0 -> {
                                    exportTitle = "Vaccination Register"
                                    exportPreviewContent = buildVaccinationCsv(vaccinations, goatsMap)
                                }
                                1 -> {
                                    exportTitle = "Deworming Register"
                                    exportPreviewContent = buildDewormingCsv(dewormings, goatsMap)
                                }
                                2 -> {
                                    exportTitle = "Treatment Register"
                                    exportPreviewContent = buildTreatmentCsv(treatments, goatsMap)
                                }
                                3 -> {
                                    exportTitle = "Quarantine Register"
                                    exportPreviewContent = buildQuarantineCsv(quarantines, goatsMap)
                                }
                                else -> {
                                    exportTitle = "Clinical Costs Summary"
                                    exportPreviewContent = buildCostSummaryText(vaccinations, dewormings, treatments, quarantines)
                                }
                            }
                            showExportDialog = true
                        },
                        modifier = Modifier.testTag("btn_export_register")
                    ) {
                        Icon(Icons.Default.Download, contentDescription = "Export Register", tint = FarmGreenDark)
                    }
                }
            )
        }
    ) { padding ->
        if (isLoading) {
            Box(modifier = Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = FarmGreenPrimary)
            }
        } else {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xFFF8FAFC))
                    .padding(padding)
            ) {
                // Tab Row
                ScrollableTabRow(
                    selectedTabIndex = selectedRegisterTab,
                    edgePadding = 12.dp,
                    containerColor = Color.White
                ) {
                    registerTabs.forEachIndexed { index, tabName ->
                        Tab(
                            selected = selectedRegisterTab == index,
                            onClick = { selectedRegisterTab = index },
                            text = { Text(tabName, fontSize = 12.sp, fontWeight = if (selectedRegisterTab == index) FontWeight.Bold else FontWeight.Normal) }
                        )
                    }
                }

                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    when (selectedRegisterTab) {
                        0 -> {
                            item {
                                RegisterHeaderCard(
                                    title = "Vaccination Register (${vaccinations.size} entries)",
                                    description = "All administered vaccines, batch numbers, next due dates, and veterinarians."
                                )
                            }
                            if (vaccinations.isEmpty()) {
                                item { EmptyRegisterCard("No vaccination records logged yet.") }
                            } else {
                                items(vaccinations) { v ->
                                    val goat = goatsMap[v.goat_id_c]
                                    Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(10.dp)) {
                                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                                Text("Tag: ${goat?.tag_c ?: "Goat"} (${goat?.breed_c ?: ""})", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                                Text(v.administered_date_c, fontSize = 12.sp, color = Color.Gray)
                                            }
                                            Text("Vaccine: ${v.vaccine_c} | Dose: ${v.dose_c}", fontSize = 12.sp, color = FarmGreenDark, fontWeight = FontWeight.SemiBold)
                                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                                Text("Next Due: ${v.next_due_date_c ?: "None"}", fontSize = 11.sp, color = Color.DarkGray)
                                                Text("Admin by: ${v.administered_by_c ?: "Staff"}", fontSize = 11.sp, color = Color.DarkGray)
                                            }
                                            if (!v.batch_number_c.isNullOrBlank()) {
                                                Text("Batch No: ${v.batch_number_c}", fontSize = 10.sp, color = Color.Gray)
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        1 -> {
                            item {
                                RegisterHeaderCard(
                                    title = "Deworming Register (${dewormings.size} entries)",
                                    description = "Anthelmintic treatments, body weight dosages, and fecal egg thresholds."
                                )
                            }
                            if (dewormings.isEmpty()) {
                                item { EmptyRegisterCard("No deworming records logged yet.") }
                            } else {
                                items(dewormings) { d ->
                                    val goat = goatsMap[d.goat_id_c]
                                    Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(10.dp)) {
                                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                                Text("Tag: ${goat?.tag_c ?: "Goat"}", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                                Text(d.treatment_date_c, fontSize = 12.sp, color = Color.Gray)
                                            }
                                            Text("Medicine: ${d.medicine_c} (${d.dose_c})", fontSize = 12.sp, color = Color(0xFF059669), fontWeight = FontWeight.SemiBold)
                                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                                Text("Weight: ${d.weight_at_treatment_c ?: "N/A"} kg", fontSize = 11.sp)
                                                Text("Next Due: ${d.next_due_date_c ?: "None"}", fontSize = 11.sp)
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        2 -> {
                            item {
                                RegisterHeaderCard(
                                    title = "Treatment Register (${treatments.size} entries)",
                                    description = "Clinical complaints, symptoms, veterinary medications, outcomes, and costs."
                                )
                            }
                            if (treatments.isEmpty()) {
                                item { EmptyRegisterCard("No clinical treatment records logged yet.") }
                            } else {
                                items(treatments) { t ->
                                    val goat = goatsMap[t.goat_id_c]
                                    Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(10.dp)) {
                                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                                Text("Tag: ${goat?.tag_c ?: "Goat"}", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                                Text(t.start_date_c, fontSize = 12.sp, color = Color.Gray)
                                            }
                                            Text("Symptoms: ${t.symptoms_c}", fontSize = 12.sp, fontWeight = FontWeight.Medium)
                                            Text("Diagnosis & Rx: ${t.diagnosis_c} - ${t.medicine_c} (${t.dose_c})", fontSize = 12.sp, color = Color(0xFF9333EA))
                                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                                Text("Outcome: ${t.outcome_c}", fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = if (t.outcome_c.contains("Recovered", ignoreCase = true)) FarmGreenDark else Color(0xFFD97706))
                                                if (t.cost_c != null && t.cost_c > 0) Text("Cost: ${CurrencyUtils.format(t.cost_c)}", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        3 -> {
                            item {
                                RegisterHeaderCard(
                                    title = "Quarantine Register (${quarantines.size} entries)",
                                    description = "Market purchase isolation history, biosecurity status, and release clearance."
                                )
                            }
                            if (quarantines.isEmpty()) {
                                item { EmptyRegisterCard("No quarantine intakes recorded yet.") }
                            } else {
                                items(quarantines) { q ->
                                    Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(10.dp)) {
                                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                                Text("Goat: ${q.goat_tag.ifBlank { "#" + q.goat_id.take(6) }}", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                                Surface(
                                                    color = if (q.status == "CLEARED") Color(0xFFD1FAE5) else Color(0xFFFEF3C7),
                                                    shape = RoundedCornerShape(4.dp)
                                                ) {
                                                    Text(
                                                        text = q.status,
                                                        fontSize = 10.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        color = if (q.status == "CLEARED") FarmGreenDark else Color(0xFFD97706),
                                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                    )
                                                }
                                            }
                                            Text("Period: ${q.start_date} to ${q.planned_end_date}", fontSize = 12.sp)
                                            Text("Location: ${q.isolation_location} | Seller: ${q.seller_name ?: "Market"}", fontSize = 11.sp, color = Color.DarkGray)
                                            if (!q.release_reason.isNullOrBlank()) {
                                                Text("Clearance: ${q.release_reason}", fontSize = 11.sp, color = FarmGreenDark)
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        else -> {
                            // Costs & Analytics
                            item {
                                val totalTreatmentCost = treatments.sumOf { it.cost_c ?: 0.0 }
                                Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(12.dp)) {
                                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                        Text("HEALTH & VETERINARY EXPENDITURE", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color.Gray)
                                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                            Text("Total Clinical Treatment Cost", fontSize = 13.sp)
                                            Text(CurrencyUtils.format(totalTreatmentCost), fontWeight = FontWeight.Bold, fontSize = 14.sp, color = FarmGreenDark)
                                        }
                                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                            Text("Total Vaccinations Administered", fontSize = 13.sp)
                                            Text("${vaccinations.size}", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                        }
                                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                            Text("Total Deworming Courses Given", fontSize = 13.sp)
                                            Text("${dewormings.size}", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                        }
                                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                            Text("Total Quarantine Intakes Cleared", fontSize = 13.sp)
                                            Text("${quarantines.count { it.status == "CLEARED" }} / ${quarantines.size}", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                        }
                                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                            Text("Pending Actionable Health Alerts", fontSize = 13.sp)
                                            Text("${alerts.size}", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color(0xFFDC2626))
                                        }
                                    }
                                }
                            }
                        }
                    }

                    item {
                        Spacer(modifier = Modifier.height(32.dp))
                    }
                }
            }
        }
    }

    // Export Dialog (CSV / PDF text view)
    if (showExportDialog) {
        Dialog(onDismissRequest = { showExportDialog = false }) {
            Surface(shape = RoundedCornerShape(16.dp), color = Color.White, modifier = Modifier.fillMaxWidth().fillMaxHeight(0.8f)) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text("Export Register: $exportTitle", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Text("CSV / Spreadsheet & PDF Report Format", fontSize = 11.sp, color = Color.Gray)
                    HorizontalDivider(modifier = Modifier.padding(vertical = 10.dp))

                    OutlinedTextField(
                        value = exportPreviewContent,
                        onValueChange = {},
                        readOnly = true,
                        modifier = Modifier.weight(1f).fillMaxWidth(),
                        textStyle = androidx.compose.ui.text.TextStyle(fontSize = 11.sp, fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace)
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { showExportDialog = false }, modifier = Modifier.weight(1f)) {
                            Text("Close")
                        }
                        Button(
                            onClick = {
                                Toast.makeText(context, "Export formatted & copied to clipboard!", Toast.LENGTH_LONG).show()
                                showExportDialog = false
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = FarmGreenPrimary),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Export / Share")
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun RegisterHeaderCard(title: String, description: String) {
    Surface(
        color = Color(0xFFEFF6FF),
        shape = RoundedCornerShape(10.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFBFDBFE)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(title, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color(0xFF1E40AF))
            Text(description, fontSize = 11.sp, color = Color(0xFF334155))
        }
    }
}

@Composable
private fun EmptyRegisterCard(msg: String) {
    Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(10.dp), modifier = Modifier.fillMaxWidth()) {
        Box(modifier = Modifier.fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) {
            Text(msg, fontSize = 12.sp, color = Color.Gray)
        }
    }
}

private fun buildVaccinationCsv(list: List<VaccinationRecord>, goats: Map<String, Goat>): String {
    return buildString {
        appendLine("Date,Goat Tag,Breed,Vaccine,Dose,Next Due Date,Batch Number,Administered By,Notes")
        list.forEach { v ->
            val g = goats[v.goat_id_c]
            appendLine("${v.administered_date_c},\"${g?.tag_c ?: ""}\",\"${g?.breed_c ?: ""}\",\"${v.vaccine_c}\",\"${v.dose_c}\",\"${v.next_due_date_c ?: ""}\",\"${v.batch_number_c ?: ""}\",\"${v.administered_by_c ?: ""}\",\"${v.notes_c ?: ""}\"")
        }
    }
}

private fun buildDewormingCsv(list: List<DewormingRecord>, goats: Map<String, Goat>): String {
    return buildString {
        appendLine("Date,Goat Tag,Medicine,Dose,Weight (kg),Next Due Date,Administered By,Notes")
        list.forEach { d ->
            val g = goats[d.goat_id_c]
            appendLine("${d.treatment_date_c},\"${g?.tag_c ?: ""}\",\"${d.medicine_c}\",\"${d.dose_c}\",${d.weight_at_treatment_c ?: ""},\"${d.next_due_date_c ?: ""}\",\"${d.administered_by_c ?: ""}\",\"${d.notes_c ?: ""}\"")
        }
    }
}

private fun buildTreatmentCsv(list: List<TreatmentRecord>, goats: Map<String, Goat>): String {
    return buildString {
        appendLine("Start Date,Goat Tag,Symptoms,Diagnosis,Medicine,Dose,Veterinarian,Outcome,Cost,Notes")
        list.forEach { t ->
            val g = goats[t.goat_id_c]
            appendLine("${t.start_date_c},\"${g?.tag_c ?: ""}\",\"${t.symptoms_c}\",\"${t.diagnosis_c}\",\"${t.medicine_c}\",\"${t.dose_c}\",\"${t.veterinarian_c ?: ""}\",\"${t.outcome_c}\",${t.cost_c ?: 0.0},\"${t.notes_c ?: ""}\"")
        }
    }
}

private fun buildQuarantineCsv(list: List<QuarantineRecord>, goats: Map<String, Goat>): String {
    return buildString {
        appendLine("Goat Tag,Intake Date,Planned Release,Actual Release,Location,Seller,Reason,Status,Clearance Notes")
        list.forEach { q ->
            appendLine("\"${q.goat_tag}\",${q.start_date},${q.planned_end_date},\"${q.actual_release_date ?: ""}\",\"${q.isolation_location}\",\"${q.seller_name ?: ""}\",\"${q.reason}\",\"${q.status}\",\"${q.release_reason ?: ""}\"")
        }
    }
}

private fun buildCostSummaryText(
    vacs: List<VaccinationRecord>,
    dews: List<DewormingRecord>,
    treatments: List<TreatmentRecord>,
    quarantines: List<QuarantineRecord>
): String {
    return buildString {
        appendLine("========================================")
        appendLine("GOAT FARM CLINICAL & HEALTH COST SUMMARY")
        appendLine("========================================")
        appendLine("Total Vaccinations Administered: ${vacs.size}")
        appendLine("Total Deworming Courses: ${dews.size}")
        appendLine("Total Treatments: ${treatments.size}")
        appendLine("Total Quarantined Goats: ${quarantines.size}")
        appendLine("Active Quarantines: ${quarantines.count { it.status == "QUARANTINE" || it.status == "EXTENDED" }}")
        val totalCost = treatments.sumOf { it.cost_c ?: 0.0 }
        appendLine("Total Clinical Expenditure: INR $totalCost")
        appendLine("========================================")
    }
}
