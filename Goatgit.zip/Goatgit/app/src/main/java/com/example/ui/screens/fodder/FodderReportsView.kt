package com.example.ui.screens.fodder

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.fodder.CropCostSummary
import com.example.data.fodder.FodderRepository
import com.example.data.fodder.FodderStockSummary
import com.example.data.fodder.PlotReportItem
import com.example.data.fodder.SpeciesReportItem
import com.example.data.offline.FodderCuttingEntity
import com.example.ui.theme.*
import kotlinx.coroutines.launch
import java.util.*

@Composable
fun FodderReportsView(
    repository: FodderRepository,
    modifier: Modifier = Modifier
) {
    var selectedReportSubTab by remember { mutableStateOf(0) }
    val subTabs = listOf("Production", "Plots & Rows", "Crop Costs", "Species", "Traceability")

    var speciesReport by remember { mutableStateOf<List<SpeciesReportItem>>(emptyList()) }
    var plotReport by remember { mutableStateOf<List<PlotReportItem>>(emptyList()) }
    var stockSummary by remember { mutableStateOf(FodderStockSummary()) }
    var costSummary by remember { mutableStateOf(CropCostSummary()) }
    var cuttingsList by remember { mutableStateOf<List<FodderCuttingEntity>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }

    val coroutineScope = rememberCoroutineScope()

    LaunchedEffect(selectedReportSubTab) {
        isLoading = true
        speciesReport = repository.compileSpeciesReport()
        plotReport = repository.compilePlotReport()
        stockSummary = repository.getStockSummary()
        costSummary = repository.getCropCostSummary()
        isLoading = false
    }

    val cuttingsFromFlow by repository.cuttingsFlow.collectAsState(initial = emptyList())
    LaunchedEffect(cuttingsFromFlow) {
        cuttingsList = cuttingsFromFlow
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text(
            text = "Green Fodder Analytics & Reports",
            fontWeight = FontWeight.Bold,
            style = MaterialTheme.typography.titleLarge,
            color = FarmGreenDark
        )

        // Sub-tabs: Production | Plots & Rows | Crop Costs | Species | Traceability
        ScrollableTabRow(
            selectedTabIndex = selectedReportSubTab,
            containerColor = Color(0xFFF1F8E9),
            contentColor = FarmGreenDark,
            edgePadding = 8.dp,
            modifier = Modifier.clip(RoundedCornerShape(10.dp))
        ) {
            subTabs.forEachIndexed { index, title ->
                Tab(
                    selected = selectedReportSubTab == index,
                    onClick = { selectedReportSubTab = index },
                    text = { Text(title, fontWeight = FontWeight.SemiBold, fontSize = 12.sp) },
                    modifier = Modifier.testTag("report_tab_$index")
                )
            }
        }

        if (isLoading) {
            Box(modifier = Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = FarmGreenDark)
            }
        } else {
            when (selectedReportSubTab) {
                0 -> ProductionAnalyticsSection(plotReport, stockSummary, cuttingsList)
                1 -> PlotReportSection(plotReport)
                2 -> CropCostsSection(costSummary)
                3 -> SpeciesReportSection(speciesReport)
                4 -> CropTraceabilitySection(cuttingsList)
            }
        }
    }
}

// ==========================================
// 1. PRODUCTION & YIELD ANALYTICS (Requirement 15)
// ==========================================
@Composable
fun ProductionAnalyticsSection(
    plotReport: List<PlotReportItem>,
    stockSummary: FodderStockSummary,
    cuttingsList: List<FodderCuttingEntity>
) {
    val totalPlantedRows = plotReport.sumOf { it.totalRows }
    val totalPlantedRowLengthM = plotReport.sumOf { it.totalRowLengthM }
    val totalHarvestedRows = cuttingsList.sumOf { it.rows_harvested_count }
    val totalHarvestedRowLengthM = cuttingsList.sumOf { it.total_harvested_row_length_m }
    val totalProductionKg = stockSummary.totalHarvestedKg

    val prodPerRow = if (totalHarvestedRows > 0) totalProductionKg / totalHarvestedRows else 0.0
    val prodPerMetre = if (totalHarvestedRowLengthM > 0) totalProductionKg / totalHarvestedRowLengthM else 0.0
    val totalAcres = plotReport.sumOf { it.areaAcres }
    val prodPerAcre = if (totalAcres > 0) totalProductionKg / totalAcres else 0.0
    val prodPerHectare = prodPerAcre * 2.47105

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Production & Yield Metrics", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium, color = FarmGreenDark)

        // KPI Summary Cards
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            MetricHighlightCard(
                title = "Total Production",
                value = "${totalProductionKg.toInt()} kg",
                subtitle = "${(totalProductionKg / 1000.0).let { String.format(Locale.US, "%.2f", it) }} Tonnes",
                color = FarmGreenDark,
                modifier = Modifier.weight(1f)
            )
            MetricHighlightCard(
                title = "Total Harvested",
                value = "$totalHarvestedRows rows",
                subtitle = "${totalHarvestedRowLengthM.toInt()} m row length",
                color = Color(0xFF0277BD),
                modifier = Modifier.weight(1f)
            )
        }

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            MetricHighlightCard(
                title = "Yield per Metre",
                value = "${String.format(Locale.US, "%.2f", prodPerMetre)} kg/m",
                subtitle = "Linear production",
                color = FarmSuccess,
                modifier = Modifier.weight(1f)
            )
            MetricHighlightCard(
                title = "Yield per Row",
                value = "${String.format(Locale.US, "%.1f", prodPerRow)} kg",
                subtitle = "Avg per cultivated row",
                color = FarmBrown,
                modifier = Modifier.weight(1f)
            )
        }

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            MetricHighlightCard(
                title = "Yield per Acre",
                value = "${prodPerAcre.toInt()} kg/ac",
                subtitle = "Field productivity",
                color = FarmGreenDark,
                modifier = Modifier.weight(1f)
            )
            MetricHighlightCard(
                title = "Yield per Hectare",
                value = "${prodPerHectare.toInt()} kg/ha",
                subtitle = "Metric equivalent",
                color = Color(0xFF5C6BC0),
                modifier = Modifier.weight(1f)
            )
        }

        // Cultivated Infrastructure summary
        Surface(
            shape = RoundedCornerShape(12.dp),
            color = Color.White,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Cultivated Field Infrastructure:", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color.DarkGray)
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("• Total Planted Rows:", fontSize = 11.sp, color = Color.Gray)
                    Text("$totalPlantedRows rows across ${plotReport.size} fields", fontWeight = FontWeight.SemiBold, fontSize = 11.sp)
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("• Total Planted Row Length:", fontSize = 11.sp, color = Color.Gray)
                    Text("${totalPlantedRowLengthM.toInt()} metres", fontWeight = FontWeight.SemiBold, fontSize = 11.sp)
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("• Total Cultivated Area:", fontSize = 11.sp, color = Color.Gray)
                    Text("${String.format(Locale.US, "%.2f", totalAcres)} Acres", fontWeight = FontWeight.SemiBold, fontSize = 11.sp)
                }
            }
        }
    }
}

// ==========================================
// 2. PLOT & ROW REPORTS
// ==========================================
@Composable
fun PlotReportSection(plotList: List<PlotReportItem>) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(
            text = "Field & Row Performance",
            fontWeight = FontWeight.Bold,
            style = MaterialTheme.typography.titleMedium,
            color = FarmGreenDark
        )

        if (plotList.isEmpty()) {
            Text("No fields registered yet.", color = Color.Gray, fontSize = 13.sp)
        } else {
            plotList.forEach { plot ->
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(text = plot.plotName, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = FarmGreenDark)
                                Text(text = "${plot.speciesName} • ${plot.areaAcres} ac • ${plot.totalRows} rows (${plot.totalRowLengthM.toInt()}m)", fontSize = 11.sp, color = Color.Gray)
                            }
                            Surface(shape = RoundedCornerShape(4.dp), color = FarmGreenContainer) {
                                Text(
                                    text = "${plot.harvestedRowCount} / ${plot.totalRows} cut",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = FarmGreenDark,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Total Harvest: ${plot.totalHarvestedKg.toInt()} kg", fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = FarmGreenDark)
                            Text("Yield: ${plot.yieldPerAcreKg.toInt()} kg/ac", fontSize = 11.sp, color = Color.DarkGray)
                            Text("Cuts Done: ${plot.currentCutCount}", fontSize = 11.sp, color = Color.Gray)
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// 3. CROP COST TRACKING (Requirement 16)
// ==========================================
@Composable
fun CropCostsSection(costSummary: CropCostSummary) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Crop Production Cost Tracking", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium, color = FarmGreenDark)

        // KPI Highlights
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            MetricHighlightCard(
                title = "Total Crop Cost",
                value = com.example.util.CurrencyUtils.formatInr(costSummary.totalCost),
                subtitle = "All operations",
                color = FarmBrown,
                modifier = Modifier.weight(1f)
            )
            MetricHighlightCard(
                title = "Cost per kg Harvested",
                value = "₹${String.format(Locale.US, "%.3f", costSummary.costPerKgHarvested)}",
                subtitle = "Per kg green fodder",
                color = FarmGreenDark,
                modifier = Modifier.weight(1f)
            )
        }

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            MetricHighlightCard(
                title = "Cost per Row",
                value = com.example.util.CurrencyUtils.formatInr(costSummary.costPerRow),
                subtitle = "Across ${costSummary.totalRows} rows",
                color = Color(0xFF0277BD),
                modifier = Modifier.weight(1f)
            )
            MetricHighlightCard(
                title = "Cost per Metre",
                value = "₹${String.format(Locale.US, "%.3f", costSummary.costPerMetre)}",
                subtitle = "Linear field cost",
                color = Color(0xFF5C6BC0),
                modifier = Modifier.weight(1f)
            )
        }

        // Cost Breakdown by Activity
        Card(
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Cost Breakdown by Expense Category:", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = FarmGreenDark)

                CostItemRow(label = "Seed / Slips / Planting Material", amount = costSummary.seedMaterialCost, total = costSummary.totalCost)
                CostItemRow(label = "Fertilizers & Soil Amendments", amount = costSummary.fertilizerCost, total = costSummary.totalCost)
                CostItemRow(label = "Irrigation & Power", amount = costSummary.irrigationCost, total = costSummary.totalCost)
                CostItemRow(label = "Labour (Planting, Weeding, Cutting)", amount = costSummary.labourCost, total = costSummary.totalCost)
                CostItemRow(label = "Other Field Activities", amount = costSummary.otherCost, total = costSummary.totalCost)
            }
        }
    }
}

@Composable
fun CostItemRow(label: String, amount: Double, total: Double) {
    val pct = if (total > 0) ((amount / total) * 100.0).toInt() else 0
    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(label, fontSize = 11.sp, color = Color.DarkGray)
            Text("${com.example.util.CurrencyUtils.formatInr(amount)} ($pct%)", fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
        LinearProgressIndicator(
            progress = { if (total > 0) (amount / total).toFloat().coerceIn(0f, 1f) else 0f },
            modifier = Modifier
                .fillMaxWidth()
                .height(4.dp)
                .padding(top = 2.dp)
                .clip(RoundedCornerShape(2.dp)),
            color = FarmGreenDark,
            trackColor = Color(0xFFEEEEEE)
        )
    }
}

// ==========================================
// 4. SPECIES REPORT
// ==========================================
@Composable
fun SpeciesReportSection(speciesList: List<SpeciesReportItem>) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Species Performance Breakdown", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium, color = FarmGreenDark)

        speciesList.forEach { sp ->
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(sp.speciesName, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = FarmGreenDark)
                            Text("${sp.category} • CP: ${sp.crudeProteinPct}%", fontSize = 11.sp, color = Color.Gray)
                        }
                        Text("${sp.totalHarvestedKg.toInt()} kg", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = FarmGreenDark)
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("Plots: ${sp.totalPlots} (${sp.totalAreaAcres} ac) • Total Cuts: ${sp.totalCuts} • Avg/Cut: ${sp.avgYieldPerCutKg.toInt()} kg", fontSize = 10.sp, color = Color.DarkGray)
                }
            }
        }
    }
}

// ==========================================
// 5. CROP TRACEABILITY CHAIN (Requirement 14)
// ==========================================
@Composable
fun CropTraceabilitySection(cuttingsList: List<FodderCuttingEntity>) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Planting → Harvest Complete Traceability", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium, color = FarmGreenDark)
        Text("Every harvest linked back to Field, Species, Variety, Planting Method, Rows, and Cut #:", fontSize = 11.sp, color = Color.Gray)

        if (cuttingsList.isEmpty()) {
            Text("No harvest records logged yet.", fontSize = 12.sp, color = Color.Gray)
        } else {
            cuttingsList.forEach { cut ->
                Card(
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("${cut.plot_name} → Cut #${cut.cut_number}", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = FarmGreenDark)
                            Text("${cut.harvested_weight_kg.toInt()} kg", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = FarmGreenDark)
                        }

                        // Traceability Flow Chain
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = Color(0xFFF9FBF9),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                Text("🌱 Species: ${cut.species_name}", fontSize = 11.sp, color = Color.DarkGray)
                                Text("🌾 Target Rows: ${cut.row_codes} (${cut.rows_harvested_count} rows • ${cut.total_harvested_row_length_m.toInt()}m)", fontSize = 11.sp, color = Color.DarkGray)
                                Text("📅 Harvest Date: ${cut.cutting_date} • Quality: ${cut.quality_rating}", fontSize = 10.sp, color = Color.Gray)
                                if (!cut.weather_summary.isNullOrBlank()) {
                                    Text("☁ Weather at Harvest: ${cut.weather_summary}", fontSize = 10.sp, color = Color.Gray)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun MetricHighlightCard(title: String, value: String, subtitle: String, color: Color, modifier: Modifier = Modifier) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = modifier
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(title, fontSize = 11.sp, color = Color.Gray)
            Text(value, fontWeight = FontWeight.Bold, fontSize = 16.sp, color = color)
            Text(subtitle, fontSize = 10.sp, color = Color.DarkGray)
        }
    }
}
