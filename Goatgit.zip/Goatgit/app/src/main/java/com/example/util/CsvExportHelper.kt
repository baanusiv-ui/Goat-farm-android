package com.example.util

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.core.content.FileProvider
import com.example.data.offline.DailyHealthObservationEntity
import com.example.data.supabase.*
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.*

object CsvExportHelper {

    private val sdfIso = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)
    private val sdfDateOnly = SimpleDateFormat("yyyy-MM-dd", Locale.US)

    /**
     * Escapes a single CSV field compliant with RFC 4180.
     */
    fun escapeCsv(value: Any?): String {
        if (value == null) return ""
        val str = value.toString()
        return if (str.contains(",") || str.contains("\"") || str.contains("\n") || str.contains("\r")) {
            "\"" + str.replace("\"", "\"\"") + "\""
        } else {
            str
        }
    }

    /**
     * Exports full goat population census into CSV format.
     */
    fun generateGoatPopulationCsv(goats: List<Goat>): String {
        val sb = StringBuilder()
        // Header
        sb.append(
            listOf(
                "Goat ID",
                "Ear Tag",
                "Name",
                "Breed",
                "Sex",
                "Status",
                "Weight (kg)",
                "Birth Date",
                "Color / Markings",
                "Dam Tag",
                "Sire Tag",
                "Origin",
                "Health Status",
                "Quarantine Status",
                "Created Date",
                "Notes"
            ).joinToString(",") { escapeCsv(it) }
        ).append("\n")

        for (g in goats) {
            sb.append(
                listOf(
                    g.id,
                    g.tag_c,
                    g.name,
                    g.breed_c,
                    g.sex_c,
                    g.status_c,
                    g.weight_kg_c?.let { String.format(Locale.US, "%.1f", it) } ?: "",
                    g.birth_date_c ?: "",
                    g.color_c ?: "",
                    g.dam_c ?: "",
                    g.sire_c ?: "",
                    g.origin_c ?: "Farm Born",
                    g.health_status_c ?: "Healthy",
                    if (g.status_c.equals("Quarantine", ignoreCase = true)) "Isolated" else "None",
                    g.created_at ?: "",
                    g.notes_c ?: ""
                ).joinToString(",") { escapeCsv(it) }
            ).append("\n")
        }

        return sb.toString()
    }

    /**
     * Exports all clinical, preventive, and observation health logs into CSV format.
     */
    fun generateHealthLogsCsv(
        goats: List<Goat>,
        weights: List<GoatWeight>,
        vaccinations: List<VaccinationRecord>,
        dewormings: List<DewormingRecord>,
        treatments: List<TreatmentRecord>,
        observations: List<DailyHealthObservationEntity>
    ): String {
        val sb = StringBuilder()
        val goatsMap = goats.associateBy { it.id }

        // Unified Health Log Row model for chronological sorting
        data class UnifiedHealthLogRow(
            val id: String,
            val recordType: String,
            val date: String,
            val timestampFormatted: String,
            val timestampEpoch: Long,
            val goatTag: String,
            val goatName: String,
            val breed: String,
            val primaryMetric: String,
            val detailOrDose: String,
            val adminOrMethod: String,
            val outcomeOrStatus: String,
            val notes: String
        )

        val rows = mutableListOf<UnifiedHealthLogRow>()

        // 1. Weight Logs
        for (w in weights) {
            val goat = goatsMap[w.goat_id_c]
            val timestampStr = sdfIso.format(Date(w.timestamp))
            rows.add(
                UnifiedHealthLogRow(
                    id = w.id,
                    recordType = "WEIGHT_LOG",
                    date = w.date_c,
                    timestampFormatted = timestampStr,
                    timestampEpoch = w.timestamp,
                    goatTag = goat?.tag_c ?: "Unknown",
                    goatName = goat?.name ?: "",
                    breed = goat?.breed_c ?: "",
                    primaryMetric = "${String.format(Locale.US, "%.1f", w.weight_kg_c)} kg",
                    detailOrDose = "Weigh-in Measurement",
                    adminOrMethod = w.method_c,
                    outcomeOrStatus = "Recorded",
                    notes = w.notes_c ?: ""
                )
            )
        }

        // 2. Vaccinations
        for (v in vaccinations) {
            val goat = goatsMap[v.goat_id_c]
            rows.add(
                UnifiedHealthLogRow(
                    id = v.id,
                    recordType = "VACCINATION",
                    date = v.administered_date_c,
                    timestampFormatted = v.administered_date_c,
                    timestampEpoch = parseDateEpoch(v.administered_date_c),
                    goatTag = goat?.tag_c ?: "Unknown",
                    goatName = goat?.name ?: "",
                    breed = goat?.breed_c ?: "",
                    primaryMetric = v.vaccine_c,
                    detailOrDose = "Batch: ${v.batch_number_c ?: "N/A"}, Next: ${v.next_due_date_c ?: "N/A"}",
                    adminOrMethod = v.administered_by_c ?: "Farm Staff",
                    outcomeOrStatus = "Administered",
                    notes = v.notes_c ?: ""
                )
            )
        }

        // 3. Dewormings
        for (d in dewormings) {
            val goat = goatsMap[d.goat_id_c]
            rows.add(
                UnifiedHealthLogRow(
                    id = d.id,
                    recordType = "DEWORMING",
                    date = d.treatment_date_c,
                    timestampFormatted = d.treatment_date_c,
                    timestampEpoch = parseDateEpoch(d.treatment_date_c),
                    goatTag = goat?.tag_c ?: "Unknown",
                    goatName = goat?.name ?: "",
                    breed = goat?.breed_c ?: "",
                    primaryMetric = d.medicine_c,
                    detailOrDose = "Dose: ${d.dose_c}",
                    adminOrMethod = "Weight: ${d.weight_at_treatment_c ?: "N/A"} kg",
                    outcomeOrStatus = "Next Due: ${d.next_due_date_c ?: "N/A"}",
                    notes = d.notes_c ?: ""
                )
            )
        }

        // 4. Clinical Treatments
        for (t in treatments) {
            val goat = goatsMap[t.goat_id_c]
            rows.add(
                UnifiedHealthLogRow(
                    id = t.id,
                    recordType = "TREATMENT",
                    date = t.start_date_c,
                    timestampFormatted = t.start_date_c,
                    timestampEpoch = parseDateEpoch(t.start_date_c),
                    goatTag = goat?.tag_c ?: "Unknown",
                    goatName = goat?.name ?: "",
                    breed = goat?.breed_c ?: "",
                    primaryMetric = t.diagnosis_c,
                    detailOrDose = "Symptoms: ${t.symptoms_c}, Rx: ${t.medicine_c} (${t.dose_c})",
                    adminOrMethod = "Vet: ${t.veterinarian_c ?: "On-duty"}",
                    outcomeOrStatus = t.outcome_c,
                    notes = t.notes_c ?: ""
                )
            )
        }

        // 5. Daily Health Observations
        for (obs in observations) {
            val goat = goatsMap[obs.goat_id]
            val timestampStr = sdfIso.format(Date(obs.created_at))
            rows.add(
                UnifiedHealthLogRow(
                    id = obs.id,
                    recordType = "DAILY_OBSERVATION",
                    date = obs.observation_date,
                    timestampFormatted = timestampStr,
                    timestampEpoch = obs.created_at,
                    goatTag = goat?.tag_c ?: obs.goat_tag,
                    goatName = goat?.name ?: obs.goat_name,
                    breed = goat?.breed_c ?: "",
                    primaryMetric = "Temp: ${obs.temperature_celsius?.let { "$it°C" } ?: "N/A"}",
                    detailOrDose = "FAMACHA: ${obs.mucous_membrane_famacha}, Appetite: ${obs.appetite_status}, Rumen: ${obs.rumen_motility}",
                    adminOrMethod = "Observer: ${obs.observer_name}",
                    outcomeOrStatus = obs.overall_health_rating,
                    notes = "${obs.notes ?: ""} ${if (obs.abnormal_symptoms != "None") "Symptoms: ${obs.abnormal_symptoms}" else ""}".trim()
                )
            )
        }

        // Sort descending by timestamp
        rows.sortByDescending { it.timestampEpoch }

        // CSV Header
        sb.append(
            listOf(
                "Log ID",
                "Record Type",
                "Date",
                "Timestamp",
                "Goat Tag",
                "Goat Name",
                "Breed",
                "Primary Metric / Medicine",
                "Details / Dose / Symptoms",
                "Administered By / Method",
                "Outcome / Status",
                "Notes"
            ).joinToString(",") { escapeCsv(it) }
        ).append("\n")

        for (r in rows) {
            sb.append(
                listOf(
                    r.id,
                    r.recordType,
                    r.date,
                    r.timestampFormatted,
                    r.goatTag,
                    r.goatName,
                    r.breed,
                    r.primaryMetric,
                    r.detailOrDose,
                    r.adminOrMethod,
                    r.outcomeOrStatus,
                    r.notes
                ).joinToString(",") { escapeCsv(it) }
            ).append("\n")
        }

        return sb.toString()
    }

    /**
     * Exports a comprehensive master report containing both herd census and all health logs.
     */
    fun generateCombinedPopulationAndHealthCsv(
        goats: List<Goat>,
        weights: List<GoatWeight>,
        vaccinations: List<VaccinationRecord>,
        dewormings: List<DewormingRecord>,
        treatments: List<TreatmentRecord>,
        observations: List<DailyHealthObservationEntity>
    ): String {
        val sb = StringBuilder()
        val nowStr = sdfIso.format(Date())

        // 1. Meta / Summary Section
        sb.append("=== GOAT FARM HERD DEMOGRAPHICS & POPULATION AUDIT ===\n")
        sb.append("Export Timestamp,").append(escapeCsv(nowStr)).append("\n")
        sb.append("Total Headcount,").append(goats.size).append("\n")

        val breedsCount = goats.groupBy { it.breed_c }.mapValues { it.value.size }
        sb.append("Breeds Represented,").append(escapeCsv(breedsCount.entries.joinToString("; ") { "${it.key}: ${it.value}" })).append("\n")

        val statusCount = goats.groupBy { it.status_c }.mapValues { it.value.size }
        sb.append("Status Breakdown,").append(escapeCsv(statusCount.entries.joinToString("; ") { "${it.key}: ${it.value}" })).append("\n")

        val avgWeight = goats.mapNotNull { it.weight_kg_c }.filter { it > 0.0 }.let {
            if (it.isNotEmpty()) String.format(Locale.US, "%.1f kg", it.average()) else "N/A"
        }
        sb.append("Average Herd Weight,").append(escapeCsv(avgWeight)).append("\n\n")

        // 2. Population Census Table
        sb.append("=== SECTION 1: GOAT POPULATION ROSTER ===\n")
        sb.append(generateGoatPopulationCsv(goats))
        sb.append("\n")

        // 3. Health & Clinical Logs Table
        sb.append("=== SECTION 2: HEALTH & CLINICAL LOGS REGISTER ===\n")
        sb.append(generateHealthLogsCsv(goats, weights, vaccinations, dewormings, treatments, observations))

        return sb.toString()
    }

    /**
     * Exports only weight logs with recurring schedule metrics and ADG calculations.
     */
    fun generateWeightLogsOnlyCsv(goats: List<Goat>, weights: List<GoatWeight>): String {
        val sb = StringBuilder()
        val goatsMap = goats.associateBy { it.id }

        sb.append(
            listOf(
                "Weight Log ID",
                "Goat Tag",
                "Goat Name",
                "Breed",
                "Sex",
                "Date",
                "Exact Timestamp",
                "Weight (kg)",
                "Weighing Method",
                "Notes / BCS / Observations"
            ).joinToString(",") { escapeCsv(it) }
        ).append("\n")

        val sortedWeights = weights.sortedByDescending { it.timestamp }
        for (w in sortedWeights) {
            val goat = goatsMap[w.goat_id_c]
            val timestampStr = sdfIso.format(Date(w.timestamp))
            sb.append(
                listOf(
                    w.id,
                    goat?.tag_c ?: "Unknown",
                    goat?.name ?: "",
                    goat?.breed_c ?: "",
                    goat?.sex_c ?: "",
                    w.date_c,
                    timestampStr,
                    String.format(Locale.US, "%.1f", w.weight_kg_c),
                    w.method_c,
                    w.notes_c ?: ""
                ).joinToString(",") { escapeCsv(it) }
            ).append("\n")
        }

        return sb.toString()
    }

    /**
     * Saves CSV string to a temporary file in context.cacheDir/exports.
     */
    fun writeCsvToCacheFile(context: Context, fileName: String, csvContent: String): File {
        val exportsDir = File(context.cacheDir, "exports").apply { mkdirs() }
        val file = File(exportsDir, fileName)
        FileOutputStream(file).use { out ->
            out.write(csvContent.toByteArray(Charsets.UTF_8))
        }
        return file
    }

    /**
     * Writes CSV string directly to a SAF Uri (e.g. from ActivityResultContracts.CreateDocument).
     */
    fun writeCsvToUri(context: Context, uri: Uri, csvContent: String): Boolean {
        return try {
            context.contentResolver.openOutputStream(uri)?.use { out ->
                out.write(csvContent.toByteArray(Charsets.UTF_8))
                out.flush()
            }
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    /**
     * Creates an ACTION_SEND Intent with FileProvider for sharing the CSV file.
     */
    fun createShareIntent(context: Context, file: File, title: String): Intent {
        val uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file
        )
        return Intent(Intent.ACTION_SEND).apply {
            type = "text/csv"
            putExtra(Intent.EXTRA_SUBJECT, title)
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
    }

    private fun parseDateEpoch(dateStr: String): Long {
        return try {
            sdfDateOnly.parse(dateStr)?.time ?: System.currentTimeMillis()
        } catch (_: Exception) {
            System.currentTimeMillis()
        }
    }
}
