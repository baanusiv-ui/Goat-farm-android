package com.example.data.offline

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        SyncQueueEntity::class,
        SyncConflictEntity::class,
        GoatEntity::class,
        GoatWeightEntity::class,
        VaccinationEntity::class,
        DewormingEntity::class,
        TreatmentEntity::class,
        MatingEntity::class,
        PregnancyEntity::class,
        KiddingEntity::class,
        KidEntity::class,
        FeedItemEntity::class,
        FeedMovementEntity::class,
        MedicineEntity::class,
        TaskEntity::class,
        SaleEntity::class,
        TransactionEntity::class,
        FarmSettingEntity::class,
        BackupLogEntity::class,
        FodderSpeciesEntity::class,
        FodderPlotEntity::class,
        FodderRowEntity::class,
        FodderCropCycleEntity::class,
        FodderPlantingMaterialEntity::class,
        FodderActivityEntity::class,
        FodderCuttingEntity::class,
        FodderFeedingEntity::class,
        FodderStockAdjustmentEntity::class,
        FodderMasterSettingEntity::class,
        PaymentLedgerEntity::class,
        CustomerEntity::class,
        SmsPaymentCandidateEntity::class,
        DeliveryRecordEntity::class,
        MilkRecordEntity::class,
        AuditLogEntity::class,
        FarmAssetEntity::class,
        FinancialAccountEntity::class,
        AccountTransactionEntity::class,
        RecurringExpenseEntity::class,
        ElectricityConnectionEntity::class,
        ElectricityBillEntity::class,
        LoanEntity::class,
        LoanScheduleEntity::class,
        SupplierEntity::class,
        SupplierInvoiceEntity::class,
        SupplierPaymentEntity::class,
        GstSettingsEntity::class,
        EWayBillEntity::class,
        InsuranceProviderEntity::class,
        InsurancePolicyEntity::class,
        InsuranceQuoteEntity::class,
        InsuranceClaimEntity::class,
        InsuranceAlertEntity::class,
        ReproductiveEventEntity::class,
        PostDeliveryCheckEntity::class,
        MortalityEventEntity::class,
        VaccinationScheduleEntity::class,
        DewormingScheduleEntity::class,
        QuarantineRecordEntity::class,
        WeaningRecordEntity::class,
        WeaningBatchEntity::class,
        BreedingRecordEntity::class,
        DailyHealthObservationEntity::class,
        GoatPhotoEntity::class
    ],
    version = 20,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun syncQueueDao(): SyncQueueDao
    abstract fun syncConflictDao(): SyncConflictDao
    abstract fun goatDao(): GoatDao
    abstract fun goatPhotoDao(): GoatPhotoDao
    abstract fun healthDao(): HealthDao
    abstract fun healthScheduleDao(): HealthScheduleDao
    abstract fun quarantineDao(): QuarantineDao
    abstract fun breedingDao(): BreedingDao
    abstract fun breedingRecordDao(): BreedingRecordDao
    abstract fun dailyHealthObservationDao(): DailyHealthObservationDao
    abstract fun inventoryDao(): InventoryDao
    abstract fun salesDao(): SalesDao
    abstract fun tasksDao(): TasksDao
    abstract fun transactionDao(): TransactionDao
    abstract fun farmSettingsDao(): FarmSettingsDao
    abstract fun backupLogDao(): BackupLogDao
    abstract fun fodderDao(): FodderDao
    abstract fun paymentLedgerDao(): PaymentLedgerDao
    abstract fun customerDao(): CustomerDao
    abstract fun smsReconciliationDao(): SmsReconciliationDao
    abstract fun deliveryDao(): DeliveryDao
    abstract fun milkDao(): MilkDao
    abstract fun auditLogDao(): AuditLogDao
    abstract fun farmAssetDao(): FarmAssetDao
    abstract fun financialAccountDao(): FinancialAccountDao
    abstract fun accountTransactionDao(): AccountTransactionDao
    abstract fun recurringExpenseDao(): RecurringExpenseDao
    abstract fun electricityDao(): ElectricityDao
    abstract fun loanDao(): LoanDao
    abstract fun supplierDao(): SupplierDao
    abstract fun gstDao(): GstDao
    abstract fun ewayBillDao(): EWayBillDao
    abstract fun insuranceDao(): InsuranceDao
    abstract fun mortalityAndReproductionDao(): MortalityAndReproductionDao
    abstract fun weaningDao(): WeaningDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        val MIGRATION_7_8 = object : androidx.room.migration.Migration(7, 8) {
            override fun migrate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE local_goats ADD COLUMN origin_c TEXT DEFAULT NULL")
            }
        }

        val MIGRATION_8_9 = object : androidx.room.migration.Migration(8, 9) {
            override fun migrate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE local_goats ADD COLUMN photo_url_c TEXT DEFAULT NULL")
                db.execSQL("ALTER TABLE local_goats ADD COLUMN health_status_c TEXT DEFAULT 'Healthy'")
                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS local_milk_records (
                        id TEXT PRIMARY KEY NOT NULL,
                        goat_id_c TEXT NOT NULL,
                        date_c TEXT NOT NULL,
                        morning_milk_ltr_c REAL NOT NULL,
                        evening_milk_ltr_c REAL NOT NULL,
                        total_milk_ltr_c REAL NOT NULL,
                        fat_percentage_c REAL,
                        notes_c TEXT,
                        updated_at INTEGER NOT NULL,
                        is_synced INTEGER NOT NULL
                    )
                """.trimIndent())
                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS local_audit_logs (
                        id TEXT PRIMARY KEY NOT NULL,
                        user_email_c TEXT NOT NULL,
                        action_c TEXT NOT NULL,
                        entity_c TEXT NOT NULL,
                        record_id_c TEXT NOT NULL,
                        details_c TEXT NOT NULL,
                        timestamp_c INTEGER NOT NULL
                    )
                """.trimIndent())
            }
        }

        val MIGRATION_9_10 = object : androidx.room.migration.Migration(9, 10) {
            override fun migrate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS local_farm_assets (
                        id TEXT PRIMARY KEY NOT NULL,
                        name TEXT NOT NULL,
                        category TEXT NOT NULL,
                        purchase_date TEXT,
                        cost REAL NOT NULL,
                        useful_life INTEGER NOT NULL,
                        current_condition TEXT NOT NULL,
                        location TEXT NOT NULL,
                        warranty_expiry TEXT,
                        maintenance_schedule TEXT,
                        asset_id TEXT,
                        supplier TEXT,
                        quantity INTEGER NOT NULL,
                        status TEXT NOT NULL,
                        amc_expiry TEXT,
                        last_maintenance TEXT,
                        next_maintenance TEXT,
                        residual_value REAL NOT NULL,
                        depreciation_method TEXT NOT NULL,
                        accumulated_depreciation REAL NOT NULL,
                        current_book_value REAL NOT NULL,
                        is_capex INTEGER NOT NULL,
                        notes TEXT,
                        photo_url TEXT,
                        created_at TEXT,
                        updated_at INTEGER NOT NULL,
                        is_synced INTEGER NOT NULL
                    )
                """.trimIndent())
            }
        }

        val MIGRATION_10_11 = object : androidx.room.migration.Migration(10, 11) {
            override fun migrate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS local_financial_accounts (
                        id TEXT PRIMARY KEY NOT NULL,
                        account_name TEXT NOT NULL,
                        account_type TEXT NOT NULL,
                        account_number TEXT,
                        bank_name TEXT,
                        ifsc_code TEXT,
                        branch TEXT,
                        opening_balance REAL NOT NULL,
                        current_balance REAL NOT NULL,
                        opening_date TEXT,
                        is_active INTEGER NOT NULL,
                        created_at TEXT,
                        updated_at INTEGER NOT NULL,
                        is_synced INTEGER NOT NULL
                    )
                """.trimIndent())
                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS local_account_transactions (
                        id TEXT PRIMARY KEY NOT NULL,
                        date TEXT NOT NULL,
                        account_id TEXT NOT NULL,
                        transaction_type TEXT NOT NULL,
                        amount REAL NOT NULL,
                        category TEXT NOT NULL,
                        reference_id TEXT,
                        to_account_id TEXT,
                        pillar TEXT NOT NULL,
                        description TEXT,
                        related_entity_type TEXT,
                        related_entity_id TEXT,
                        created_by TEXT NOT NULL,
                        created_at TEXT,
                        updated_at INTEGER NOT NULL,
                        is_synced INTEGER NOT NULL
                    )
                """.trimIndent())
                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS local_recurring_expenses (
                        id TEXT PRIMARY KEY NOT NULL,
                        expense_name TEXT NOT NULL,
                        category TEXT NOT NULL,
                        vendor TEXT,
                        amount REAL NOT NULL,
                        frequency TEXT NOT NULL,
                        start_date TEXT NOT NULL,
                        end_date TEXT,
                        next_due_date TEXT NOT NULL,
                        payment_account_id TEXT,
                        payment_method TEXT NOT NULL,
                        gst_applicable INTEGER NOT NULL,
                        gst_rate REAL NOT NULL,
                        notes TEXT,
                        is_active INTEGER NOT NULL,
                        created_at TEXT,
                        updated_at INTEGER NOT NULL,
                        is_synced INTEGER NOT NULL
                    )
                """.trimIndent())
                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS local_electricity_connections (
                        id TEXT PRIMARY KEY NOT NULL,
                        connection_name TEXT NOT NULL,
                        consumer_number TEXT NOT NULL,
                        meter_number TEXT NOT NULL,
                        service_provider TEXT NOT NULL,
                        tariff_category TEXT NOT NULL,
                        location TEXT NOT NULL,
                        billing_cycle TEXT NOT NULL,
                        is_active INTEGER NOT NULL,
                        created_at TEXT,
                        updated_at INTEGER NOT NULL,
                        is_synced INTEGER NOT NULL
                    )
                """.trimIndent())
                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS local_electricity_bills (
                        id TEXT PRIMARY KEY NOT NULL,
                        connection_id TEXT NOT NULL,
                        billing_period TEXT NOT NULL,
                        bill_date TEXT NOT NULL,
                        due_date TEXT NOT NULL,
                        previous_reading REAL NOT NULL,
                        current_reading REAL NOT NULL,
                        units_consumed REAL NOT NULL,
                        base_amount REAL NOT NULL,
                        other_charges REAL NOT NULL,
                        tax_amount REAL NOT NULL,
                        total_bill REAL NOT NULL,
                        paid_amount REAL NOT NULL,
                        balance_amount REAL NOT NULL,
                        payment_date TEXT,
                        payment_account_id TEXT,
                        payment_status TEXT NOT NULL,
                        notes TEXT,
                        created_at TEXT,
                        updated_at INTEGER NOT NULL,
                        is_synced INTEGER NOT NULL
                    )
                """.trimIndent())
                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS local_loans (
                        id TEXT PRIMARY KEY NOT NULL,
                        lender TEXT NOT NULL,
                        loan_name TEXT NOT NULL,
                        loan_account_number TEXT NOT NULL,
                        loan_type TEXT NOT NULL,
                        sanctioned_amount REAL NOT NULL,
                        disbursed_amount REAL NOT NULL,
                        interest_rate REAL NOT NULL,
                        interest_type TEXT NOT NULL,
                        tenure_months INTEGER NOT NULL,
                        emi_amount REAL NOT NULL,
                        start_date TEXT NOT NULL,
                        first_emi_date TEXT NOT NULL,
                        maturity_date TEXT NOT NULL,
                        processing_fee REAL NOT NULL,
                        outstanding_principal REAL NOT NULL,
                        total_interest_paid REAL NOT NULL,
                        total_principal_paid REAL NOT NULL,
                        disbursement_account_id TEXT,
                        status TEXT NOT NULL,
                        notes TEXT,
                        created_at TEXT,
                        updated_at INTEGER NOT NULL,
                        is_synced INTEGER NOT NULL
                    )
                """.trimIndent())
                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS local_loan_schedules (
                        id TEXT PRIMARY KEY NOT NULL,
                        loan_id TEXT NOT NULL,
                        emi_number INTEGER NOT NULL,
                        due_date TEXT NOT NULL,
                        opening_principal REAL NOT NULL,
                        principal_component REAL NOT NULL,
                        interest_component REAL NOT NULL,
                        emi_amount REAL NOT NULL,
                        closing_principal REAL NOT NULL,
                        paid_date TEXT,
                        paid_amount REAL NOT NULL,
                        payment_account_id TEXT,
                        status TEXT NOT NULL,
                        created_at TEXT,
                        updated_at INTEGER NOT NULL,
                        is_synced INTEGER NOT NULL
                    )
                """.trimIndent())
                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS local_suppliers (
                        id TEXT PRIMARY KEY NOT NULL,
                        name TEXT NOT NULL,
                        phone TEXT,
                        address TEXT,
                        gstin TEXT,
                        credit_limit REAL NOT NULL,
                        credit_period_days INTEGER NOT NULL,
                        opening_balance REAL NOT NULL,
                        current_outstanding REAL NOT NULL,
                        is_active INTEGER NOT NULL,
                        created_at TEXT,
                        updated_at INTEGER NOT NULL,
                        is_synced INTEGER NOT NULL
                    )
                """.trimIndent())
                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS local_supplier_invoices (
                        id TEXT PRIMARY KEY NOT NULL,
                        supplier_id TEXT NOT NULL,
                        invoice_number TEXT NOT NULL,
                        invoice_date TEXT NOT NULL,
                        due_date TEXT NOT NULL,
                        items_description TEXT NOT NULL,
                        quantity REAL NOT NULL,
                        rate REAL NOT NULL,
                        taxable_value REAL NOT NULL,
                        gst_rate REAL NOT NULL,
                        gst_amount REAL NOT NULL,
                        total_amount REAL NOT NULL,
                        paid_amount REAL NOT NULL,
                        balance_due REAL NOT NULL,
                        status TEXT NOT NULL,
                        notes TEXT,
                        created_at TEXT,
                        updated_at INTEGER NOT NULL,
                        is_synced INTEGER NOT NULL
                    )
                """.trimIndent())
                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS local_supplier_payments (
                        id TEXT PRIMARY KEY NOT NULL,
                        invoice_id TEXT NOT NULL,
                        supplier_id TEXT NOT NULL,
                        payment_date TEXT NOT NULL,
                        amount REAL NOT NULL,
                        payment_account_id TEXT NOT NULL,
                        payment_mode TEXT NOT NULL,
                        reference_number TEXT,
                        notes TEXT,
                        created_at TEXT,
                        updated_at INTEGER NOT NULL,
                        is_synced INTEGER NOT NULL
                    )
                """.trimIndent())
                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS local_gst_settings (
                        id TEXT PRIMARY KEY NOT NULL,
                        gst_enabled INTEGER NOT NULL,
                        business_name TEXT NOT NULL,
                        business_address TEXT NOT NULL,
                        gstin TEXT NOT NULL,
                        state_name TEXT NOT NULL,
                        state_code TEXT NOT NULL,
                        invoice_prefix TEXT NOT NULL,
                        next_invoice_number INTEGER NOT NULL,
                        default_hsn TEXT NOT NULL,
                        default_tax_rate REAL NOT NULL,
                        updated_at INTEGER NOT NULL
                    )
                """.trimIndent())
                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS local_eway_bills (
                        id TEXT PRIMARY KEY NOT NULL,
                        invoice_id TEXT NOT NULL,
                        invoice_number TEXT NOT NULL,
                        supplier_gstin TEXT NOT NULL,
                        recipient_gstin TEXT,
                        place_of_supply TEXT NOT NULL,
                        delivery_address TEXT NOT NULL,
                        hsn_code TEXT NOT NULL,
                        quantity REAL NOT NULL,
                        taxable_value REAL NOT NULL,
                        gst_amount REAL NOT NULL,
                        total_value REAL NOT NULL,
                        transporter_id TEXT,
                        transporter_name TEXT,
                        vehicle_number TEXT NOT NULL,
                        transport_mode TEXT NOT NULL,
                        transport_doc_number TEXT,
                        document_date TEXT NOT NULL,
                        eway_bill_number TEXT,
                        status TEXT NOT NULL,
                        error_message TEXT,
                        created_at TEXT,
                        updated_at INTEGER NOT NULL,
                        is_synced INTEGER NOT NULL
                    )
                """.trimIndent())
            }
        }

        val MIGRATION_11_12 = object : androidx.room.migration.Migration(11, 12) {
            override fun migrate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE local_financial_accounts ADD COLUMN upi_id TEXT")
                db.execSQL("ALTER TABLE local_account_transactions ADD COLUMN payment_mode TEXT NOT NULL DEFAULT 'Cash'")
                db.execSQL("ALTER TABLE local_account_transactions ADD COLUMN affects_pnl INTEGER NOT NULL DEFAULT 1")
            }
        }

        val MIGRATION_12_13 = object : androidx.room.migration.Migration(12, 13) {
            override fun migrate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS local_insurance_providers (
                        id TEXT PRIMARY KEY NOT NULL,
                        name TEXT NOT NULL,
                        company_name TEXT NOT NULL,
                        api_base_url TEXT,
                        sandbox_url TEXT,
                        production_url TEXT,
                        api_version TEXT NOT NULL,
                        auth_type TEXT NOT NULL,
                        webhook_url TEXT,
                        is_active INTEGER NOT NULL,
                        is_sandbox INTEGER NOT NULL,
                        notes TEXT,
                        created_at TEXT,
                        updated_at INTEGER NOT NULL,
                        is_synced INTEGER NOT NULL
                    )
                """.trimIndent())

                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS local_insurance_policies (
                        id TEXT PRIMARY KEY NOT NULL,
                        goat_id TEXT NOT NULL,
                        goat_tag TEXT NOT NULL,
                        rfid TEXT,
                        goat_name TEXT,
                        provider_id TEXT,
                        insurance_company TEXT NOT NULL,
                        policy_name TEXT NOT NULL,
                        policy_number TEXT,
                        proposal_number TEXT,
                        sum_insured REAL NOT NULL,
                        market_value REAL NOT NULL,
                        premium REAL NOT NULL,
                        tax_amount REAL NOT NULL,
                        total_premium REAL NOT NULL,
                        start_date TEXT NOT NULL,
                        expiry_date TEXT NOT NULL,
                        renewal_date TEXT,
                        status TEXT NOT NULL,
                        coverage_type TEXT NOT NULL,
                        deductible REAL NOT NULL,
                        claim_eligibility TEXT,
                        agent_name TEXT,
                        agent_contact TEXT,
                        policy_document_url TEXT,
                        vet_certificate_url TEXT,
                        animal_photo_url TEXT,
                        eartag_photo_url TEXT,
                        payment_account_id TEXT,
                        created_at TEXT,
                        updated_at INTEGER NOT NULL,
                        is_synced INTEGER NOT NULL
                    )
                """.trimIndent())

                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS local_insurance_quotes (
                        id TEXT PRIMARY KEY NOT NULL,
                        goat_id TEXT NOT NULL,
                        goat_tag TEXT NOT NULL,
                        provider_id TEXT,
                        provider_name TEXT NOT NULL,
                        product_name TEXT NOT NULL,
                        sum_insured REAL NOT NULL,
                        premium REAL NOT NULL,
                        tax_amount REAL NOT NULL,
                        total_premium REAL NOT NULL,
                        validity_date TEXT NOT NULL,
                        coverage_details TEXT,
                        terms_and_conditions TEXT,
                        exclusions TEXT,
                        status TEXT NOT NULL,
                        created_at TEXT,
                        updated_at INTEGER NOT NULL,
                        is_synced INTEGER NOT NULL
                    )
                """.trimIndent())

                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS local_insurance_claims (
                        id TEXT PRIMARY KEY NOT NULL,
                        policy_id TEXT NOT NULL,
                        goat_id TEXT NOT NULL,
                        goat_tag TEXT NOT NULL,
                        mortality_event_id TEXT,
                        incident_date TEXT NOT NULL,
                        incident_type TEXT NOT NULL,
                        cause TEXT NOT NULL,
                        description TEXT,
                        location TEXT,
                        vet_doctor TEXT,
                        vet_certificate_url TEXT,
                        photos_urls TEXT,
                        eartag_photo_url TEXT,
                        post_mortem_report_url TEXT,
                        police_report_url TEXT,
                        claim_amount REAL NOT NULL,
                        claim_number TEXT,
                        submitted_date TEXT,
                        insurer_response TEXT,
                        approved_amount REAL,
                        settlement_date TEXT,
                        settlement_amount REAL,
                        settlement_account_id TEXT,
                        rejection_reason TEXT,
                        status TEXT NOT NULL,
                        notes TEXT,
                        created_at TEXT,
                        updated_at INTEGER NOT NULL,
                        is_synced INTEGER NOT NULL
                    )
                """.trimIndent())

                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS local_insurance_alerts (
                        id TEXT PRIMARY KEY NOT NULL,
                        policy_id TEXT,
                        claim_id TEXT,
                        goat_id TEXT,
                        alert_type TEXT NOT NULL,
                        title TEXT NOT NULL,
                        message TEXT NOT NULL,
                        due_date TEXT NOT NULL,
                        days_before_expiry INTEGER NOT NULL,
                        is_dismissed INTEGER NOT NULL,
                        created_at TEXT,
                        updated_at INTEGER NOT NULL
                    )
                """.trimIndent())

                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS local_reproductive_events (
                        id TEXT PRIMARY KEY NOT NULL,
                        doe_id TEXT NOT NULL,
                        pregnancy_id TEXT,
                        sire_id TEXT,
                        event_type TEXT NOT NULL,
                        event_date TEXT NOT NULL,
                        mating_date TEXT,
                        expected_delivery_date TEXT,
                        pregnancy_age_days INTEGER,
                        number_of_fetuses INTEGER,
                        suspected_cause TEXT,
                        confirmed_cause TEXT,
                        cause_category TEXT,
                        vet_diagnosis TEXT,
                        symptoms TEXT,
                        treatment TEXT,
                        vet_doctor TEXT,
                        certificate_url TEXT,
                        photo_url TEXT,
                        notes TEXT,
                        created_at TEXT,
                        updated_at INTEGER NOT NULL,
                        is_synced INTEGER NOT NULL
                    )
                """.trimIndent())

                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS local_post_delivery_checks (
                        id TEXT PRIMARY KEY NOT NULL,
                        doe_id TEXT NOT NULL,
                        delivery_date TEXT NOT NULL,
                        check_date TEXT NOT NULL,
                        days_post_delivery INTEGER NOT NULL,
                        appetite TEXT NOT NULL,
                        temperature REAL,
                        milk_production_ltr REAL,
                        complications TEXT,
                        treatment TEXT,
                        medication TEXT,
                        vet_visit INTEGER NOT NULL,
                        vet_doctor TEXT,
                        recovery_status TEXT NOT NULL,
                        notes TEXT,
                        created_at TEXT,
                        updated_at INTEGER NOT NULL,
                        is_synced INTEGER NOT NULL
                    )
                """.trimIndent())

                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS local_mortality_events (
                        id TEXT PRIMARY KEY NOT NULL,
                        goat_id TEXT NOT NULL,
                        goat_tag TEXT NOT NULL,
                        event_type TEXT NOT NULL,
                        death_date TEXT NOT NULL,
                        death_time TEXT,
                        age_at_death_days INTEGER,
                        weight_at_death REAL,
                        delivery_date TEXT,
                        days_post_delivery INTEGER,
                        immediate_cause TEXT NOT NULL,
                        underlying_cause TEXT,
                        cause_certainty TEXT NOT NULL,
                        cause_category TEXT NOT NULL,
                        disease_name TEXT,
                        injury_details TEXT,
                        treatment_history TEXT,
                        vet_doctor TEXT,
                        post_mortem_performed INTEGER NOT NULL,
                        post_mortem_report_url TEXT,
                        photos_urls TEXT,
                        insurance_policy_id TEXT,
                        insurance_claim_id TEXT,
                        notes TEXT,
                        created_at TEXT,
                        updated_at INTEGER NOT NULL,
                        is_synced INTEGER NOT NULL
                    )
                """.trimIndent())
            }
        }

        val MIGRATION_13_14 = object : androidx.room.migration.Migration(13, 14) {
            override fun migrate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
                createHealthAndQuarantineTables(db)
            }
        }

        val MIGRATION_14_15 = object : androidx.room.migration.Migration(14, 15) {
            override fun migrate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
                createHealthAndQuarantineTables(db)
            }
        }

        val MIGRATION_15_16 = object : androidx.room.migration.Migration(15, 16) {
            override fun migrate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
                createHealthAndQuarantineTables(db)
            }
        }

        private fun createHealthAndQuarantineTables(db: androidx.sqlite.db.SupportSQLiteDatabase) {
            db.execSQL("""
                CREATE TABLE IF NOT EXISTS local_vaccination_schedules (
                    id TEXT PRIMARY KEY NOT NULL,
                    name TEXT NOT NULL,
                    disease TEXT NOT NULL,
                    vaccine_name TEXT NOT NULL,
                    species TEXT NOT NULL,
                    recommended_age TEXT NOT NULL,
                    recommended_interval TEXT NOT NULL,
                    dose_reference TEXT NOT NULL,
                    notes TEXT,
                    source TEXT NOT NULL,
                    active INTEGER NOT NULL,
                    created_at TEXT,
                    updated_at INTEGER NOT NULL
                )
            """.trimIndent())

            db.execSQL("""
                CREATE TABLE IF NOT EXISTS local_deworming_schedules (
                    id TEXT PRIMARY KEY NOT NULL,
                    name TEXT NOT NULL,
                    species TEXT NOT NULL,
                    trigger_type TEXT NOT NULL,
                    interval_days INTEGER NOT NULL,
                    fec_reference TEXT,
                    notes TEXT,
                    source TEXT NOT NULL,
                    active INTEGER NOT NULL,
                    created_at TEXT,
                    updated_at INTEGER NOT NULL
                )
            """.trimIndent())

            db.execSQL("""
                CREATE TABLE IF NOT EXISTS local_quarantine_records (
                    id TEXT PRIMARY KEY NOT NULL,
                    farm_id TEXT NOT NULL,
                    goat_id TEXT NOT NULL,
                    purchase_id TEXT,
                    start_date TEXT NOT NULL,
                    planned_end_date TEXT NOT NULL,
                    actual_release_date TEXT,
                    source_location TEXT,
                    seller_name TEXT,
                    seller_contact TEXT,
                    reason TEXT NOT NULL,
                    initial_health_status TEXT NOT NULL,
                    temperature REAL,
                    weight REAL,
                    vaccination_status TEXT NOT NULL,
                    deworming_status TEXT NOT NULL,
                    fecal_test TEXT,
                    clinical_exam TEXT,
                    veterinarian TEXT,
                    isolation_location TEXT NOT NULL,
                    status TEXT NOT NULL,
                    release_reason TEXT,
                    notes TEXT,
                    checklist_json TEXT,
                    extensions_json TEXT,
                    created_at TEXT,
                    updated_at INTEGER NOT NULL,
                    is_synced INTEGER NOT NULL
                )
            """.trimIndent())
        }

        val MIGRATION_16_17 = object : androidx.room.migration.Migration(16, 17) {
            override fun migrate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS weaning_records (
                        id TEXT PRIMARY KEY NOT NULL,
                        farm_id TEXT NOT NULL,
                        goat_id TEXT NOT NULL,
                        mother_goat_id TEXT,
                        kidding_id TEXT,
                        birth_date TEXT NOT NULL,
                        weaning_due_date TEXT NOT NULL,
                        actual_weaning_date TEXT,
                        age_at_weaning_days INTEGER,
                        weight_at_weaning REAL,
                        weight_unit TEXT NOT NULL,
                        weaning_method TEXT,
                        status TEXT NOT NULL,
                        reason_if_delayed TEXT,
                        notes TEXT,
                        setting_source TEXT NOT NULL,
                        post_weaning_feed_group TEXT NOT NULL,
                        birth_weight REAL,
                        prev_weight REAL,
                        adg_g_per_day REAL,
                        batch_id TEXT,
                        created_at TEXT NOT NULL,
                        updated_at INTEGER NOT NULL,
                        is_synced INTEGER NOT NULL
                    )
                """.trimIndent())

                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS weaning_batches (
                        id TEXT PRIMARY KEY NOT NULL,
                        farm_id TEXT NOT NULL,
                        weaning_date TEXT NOT NULL,
                        number_of_kids INTEGER NOT NULL,
                        average_weight REAL,
                        notes TEXT,
                        created_at TEXT NOT NULL,
                        updated_at INTEGER NOT NULL,
                        is_synced INTEGER NOT NULL
                    )
                """.trimIndent())
            }
        }

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "goat_farm_offline.db"
                )
                    .addMigrations(
                        MIGRATION_7_8, MIGRATION_8_9, MIGRATION_9_10, MIGRATION_10_11, MIGRATION_11_12, MIGRATION_12_13,
                        MIGRATION_13_14, MIGRATION_14_15, MIGRATION_15_16, MIGRATION_16_17
                    )
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
