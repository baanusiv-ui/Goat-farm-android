package com.example.data.offline

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface WeaningDao {
    @Query("SELECT * FROM weaning_records ORDER BY weaning_due_date ASC")
    fun getAllWeaningRecords(): Flow<List<WeaningRecordEntity>>

    @Query("SELECT * FROM weaning_records ORDER BY weaning_due_date ASC")
    suspend fun getAllWeaningRecordsSync(): List<WeaningRecordEntity>

    @Query("SELECT * FROM weaning_records WHERE goat_id = :goatId LIMIT 1")
    suspend fun getWeaningRecordByGoatId(goatId: String): WeaningRecordEntity?

    @Query("SELECT * FROM weaning_records WHERE id = :id LIMIT 1")
    suspend fun getWeaningRecordById(id: String): WeaningRecordEntity?

    @Query("SELECT * FROM weaning_records WHERE status = :status ORDER BY weaning_due_date ASC")
    suspend fun getWeaningRecordsByStatus(status: String): List<WeaningRecordEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWeaningRecord(record: WeaningRecordEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllWeaningRecords(records: List<WeaningRecordEntity>)

    @Update
    suspend fun updateWeaningRecord(record: WeaningRecordEntity)

    @Query("DELETE FROM weaning_records WHERE id = :id")
    suspend fun deleteWeaningRecord(id: String)

    // Batches
    @Query("SELECT * FROM weaning_batches ORDER BY weaning_date DESC")
    fun getAllWeaningBatches(): Flow<List<WeaningBatchEntity>>

    @Query("SELECT * FROM weaning_batches ORDER BY weaning_date DESC")
    suspend fun getAllWeaningBatchesSync(): List<WeaningBatchEntity>

    @Query("SELECT * FROM weaning_batches WHERE id = :id LIMIT 1")
    suspend fun getWeaningBatchById(id: String): WeaningBatchEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWeaningBatch(batch: WeaningBatchEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllWeaningBatches(batches: List<WeaningBatchEntity>)

    @Query("DELETE FROM weaning_batches WHERE id = :id")
    suspend fun deleteWeaningBatch(id: String)
}
