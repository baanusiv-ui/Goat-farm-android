package com.example.ui.components.breeding

import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.offline.BreedingRecordEntity
import com.example.data.supabase.Goat
import com.example.data.supabase.GoatRepository
import com.example.ui.components.DatePickerField
import com.example.ui.theme.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.TimeUnit

/**
 * Breeding management section for tracking mating dates, gestation progress,
 * and expected kidding dates for an individual goat.
 */
@Composable
fun GoatIndividualBreedingSection(
    goat: Goat,
    allGoats: List<Goat>,
    repository: GoatRepository,
    onNavigateToAllBreeding: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val isDoe = goat.sex_c.equals("Doe", ignoreCase = true)
    val isBuck = goat.sex_c.equals("Buck", ignoreCase = true)

    val breedingRecords by repository.getBreedingRecordsForGoatFlow(goat.id)
        .collectAsState(initial = emptyList())

    var showMatingDialog by remember { mutableStateOf(false) }
    var recordToUpdateStatus by remember { mutableStateOf<BreedingRecordEntity?>(null) }
    var recordToDelete by remember { mutableStateOf<BreedingRecordEntity?>(null) }

    val goatsMap = remember(allGoats) { allGoats.associateBy { it.id } }

    val activeGestation = remember(breedingRecords) {
        breedingRecords.firstOrNull { it.status.equals("Active", ignoreCase = true) }
    }

    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Active Gestation & Expected Kidding Banner (if Doe with active mating)
        if (activeGestation != null) {
            ActiveGestationTrackerCard(
                goat = goat,
                record = activeGestation,
                mate = if (isDoe) goatsMap[activeGestation.buck_id] else goatsMap[activeGestation.doe_id],
                isDoe = isDoe,
                onUpdateStatus = { recordToUpdateStatus = activeGestation }
            )
        }

        // Action Header Card
        Card(
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Breeding & Mating Tracker",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = FarmGreenDark
                        )
                        Text(
                            text = if (isDoe) "Doe Breeding Cycle & Expected Kidding" else "Sire / Buck Service History",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    Button(
                        onClick = { showMatingDialog = true },
                        colors = ButtonDefaults.buttonColors(containerColor = FarmGreenPrimary),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.testTag("btn_record_mating_for_goat")
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Log Mating", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }

                HorizontalDivider(color = Color(0xFFF1F5F9))

                // Summary Stats Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    BreedingStatCard(
                        title = "Total Matings",
                        value = "${breedingRecords.size}",
                        icon = Icons.Default.Favorite,
                        iconTint = Color(0xFFD81B60),
                        modifier = Modifier.weight(1f)
                    )

                    val kiddedCount = breedingRecords.count { it.status.equals("Kidded", true) }
                    BreedingStatCard(
                        title = if (isDoe) "Delivered / Kidded" else "Sired Deliveries",
                        value = "$kiddedCount",
                        icon = Icons.Default.ChildCare,
                        iconTint = FarmGreenPrimary,
                        modifier = Modifier.weight(1f)
                    )

                    BreedingStatCard(
                        title = "Active Cycles",
                        value = "${if (activeGestation != null) 1 else 0}",
                        icon = Icons.Default.Event,
                        iconTint = Color(0xFF7B1FA2),
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        // Mating Records & Expected Kidding Dates History
        Card(
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Mating History & Expected Kidding (${breedingRecords.size})",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = FarmGreenDark
                    )
                    TextButton(onClick = onNavigateToAllBreeding) {
                        Text("All Herd Records", fontSize = 12.sp)
                    }
                }

                HorizontalDivider(color = Color(0xFFF1F5F9))

                if (breedingRecords.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 24.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                Icons.Default.FavoriteBorder,
                                contentDescription = null,
                                tint = Color.LightGray,
                                modifier = Modifier.size(36.dp)
                            )
                            Text(
                                text = "No mating records logged for ${goat.name} (${goat.tag_c})",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Medium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = "Tap 'Log Mating' to track mating date and compute expected kidding date.",
                                fontSize = 11.sp,
                                color = Color.Gray
                            )
                        }
                    }
                } else {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        breedingRecords.forEach { record ->
                            val mate = if (isDoe) goatsMap[record.buck_id] else goatsMap[record.doe_id]
                            IndividualMatingRecordItem(
                                record = record,
                                goat = goat,
                                mate = mate,
                                isDoe = isDoe,
                                onUpdateStatus = { recordToUpdateStatus = record },
                                onDelete = { recordToDelete = record }
                            )
                        }
                    }
                }
            }
        }
    }

    // Dialog to record new mating with expected kidding calculation
    if (showMatingDialog) {
        RecordIndividualMatingDialog(
            currentGoat = goat,
            allGoats = allGoats,
            onDismiss = { showMatingDialog = false },
            onSave = { buckId, doeId, matingDate, expectedDate, notes, status ->
                coroutineScope.launch {
                    val record = BreedingRecordEntity(
                        id = UUID.randomUUID().toString(),
                        buck_id = buckId,
                        doe_id = doeId,
                        mating_date = matingDate,
                        expected_kidding_date = expectedDate,
                        outcome_notes = notes.ifBlank { null },
                        status = status
                    )
                    val res = repository.saveBreedingRecord(record)
                    if (res.isSuccess) {
                        // If Doe and status is Active, update goat status to Pregnant
                        if (isDoe && status.equals("Active", ignoreCase = true)) {
                            repository.updateGoatProfileDetails(
                                goatId = goat.id,
                                name = goat.name,
                                tag = goat.tag_c,
                                breed = goat.breed_c,
                                sex = goat.sex_c,
                                status = "Pregnant",
                                birthDate = goat.birth_date_c,
                                color = goat.color_c,
                                dam = goat.dam_c,
                                sire = goat.sire_c,
                                notes = goat.notes_c
                            )
                        }
                        Toast.makeText(context, "Mating record saved! Expected kidding: $expectedDate", Toast.LENGTH_LONG).show()
                        showMatingDialog = false
                    } else {
                        Toast.makeText(context, "Failed: ${res.exceptionOrNull()?.message}", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        )
    }

    // Dialog to update status (Kidded, Failed, Aborted)
    recordToUpdateStatus?.let { record ->
        UpdateMatingStatusDialog(
            record = record,
            onDismiss = { recordToUpdateStatus = null },
            onConfirm = { newStatus, notes ->
                coroutineScope.launch {
                    val combinedNotes = buildString {
                        if (!record.outcome_notes.isNullOrBlank()) append(record.outcome_notes).append(" | ")
                        if (notes.isNotBlank()) append(notes.trim())
                    }.ifBlank { null }
                    val res = repository.updateBreedingRecordStatus(record.id, newStatus, combinedNotes)
                    if (res.isSuccess) {
                        if (isDoe && newStatus.equals("Kidded", true)) {
                            repository.updateGoatProfileDetails(
                                goatId = goat.id,
                                name = goat.name,
                                tag = goat.tag_c,
                                breed = goat.breed_c,
                                sex = goat.sex_c,
                                status = "Lactating",
                                birthDate = goat.birth_date_c,
                                color = goat.color_c,
                                dam = goat.dam_c,
                                sire = goat.sire_c,
                                notes = goat.notes_c
                            )
                        }
                        Toast.makeText(context, "Status updated to $newStatus", Toast.LENGTH_SHORT).show()
                        recordToUpdateStatus = null
                    }
                }
            }
        )
    }

    // Delete Confirmation Dialog
    recordToDelete?.let { record ->
        AlertDialog(
            onDismissRequest = { recordToDelete = null },
            title = { Text("Delete Mating Record?", fontWeight = FontWeight.Bold) },
            text = { Text("Are you sure you want to delete this breeding record dated ${record.mating_date}?") },
            confirmButton = {
                TextButton(
                    onClick = {
                        coroutineScope.launch {
                            repository.deleteBreedingRecord(record.id)
                            recordToDelete = null
                            Toast.makeText(context, "Record deleted", Toast.LENGTH_SHORT).show()
                        }
                    },
                    colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("Delete", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { recordToDelete = null }) { Text("Cancel") }
            }
        )
    }
}

/**
 * Card displaying live gestation countdown and milestones for an active pregnancy.
 */
@Composable
private fun ActiveGestationTrackerCard(
    goat: Goat,
    record: BreedingRecordEntity,
    mate: Goat?,
    isDoe: Boolean,
    onUpdateStatus: () -> Unit
) {
    val dateFormat = remember { SimpleDateFormat("yyyy-MM-dd", Locale.US) }
    val today = remember { Date() }

    val daysElapsed = remember(record.mating_date) {
        try {
            val mating = dateFormat.parse(record.mating_date) ?: today
            val diff = today.time - mating.time
            (TimeUnit.MILLISECONDS.toDays(diff)).coerceAtLeast(0).toInt()
        } catch (_: Exception) { 0 }
    }

    val daysRemaining = remember(record.expected_kidding_date) {
        try {
            val due = dateFormat.parse(record.expected_kidding_date) ?: today
            val diff = due.time - today.time
            (TimeUnit.MILLISECONDS.toDays(diff)).toInt()
        } catch (_: Exception) { 0 }
    }

    val progress = (daysElapsed / 150f).coerceIn(0f, 1f)

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFF3E5F5)),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth().testTag("active_gestation_tracker_card")
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Surface(shape = CircleShape, color = Color(0xFF7B1FA2), modifier = Modifier.size(28.dp)) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(Icons.Default.HourglassTop, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                        }
                    }
                    Text(
                        text = "Active Gestation Tracker",
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF7B1FA2),
                        fontSize = 14.sp
                    )
                }

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = when {
                        daysRemaining < 0 -> Color(0xFFFFEBEE)
                        daysRemaining <= 7 -> Color(0xFFFFF3E0)
                        else -> Color(0xFFEDE7F6)
                    }
                ) {
                    Text(
                        text = when {
                            daysRemaining < 0 -> "Overdue (${-daysRemaining}d)"
                            daysRemaining == 0 -> "Due Today!"
                            daysRemaining <= 7 -> "Due in $daysRemaining days!"
                            else -> "$daysRemaining days remaining"
                        },
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = when {
                            daysRemaining < 0 -> Color(0xFFC62828)
                            daysRemaining <= 7 -> Color(0xFFE65100)
                            else -> Color(0xFF512DA8)
                        },
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
            }

            // Key Dates Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text("Mating Date", fontSize = 11.sp, color = Color.Gray, fontWeight = FontWeight.Medium)
                    Text(record.mating_date, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color(0xFF2E1065))
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text("Expected Kidding Date", fontSize = 11.sp, color = Color.Gray, fontWeight = FontWeight.Medium)
                    Text(
                        record.expected_kidding_date,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF7B1FA2)
                    )
                }
            }

            // Progress Bar
            LinearProgressIndicator(
                progress = { progress },
                color = Color(0xFF9C27B0),
                trackColor = Color(0xFFE1BEE7),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(8.dp)
                    .clip(RoundedCornerShape(4.dp))
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Day $daysElapsed / 150 days gestation",
                    fontSize = 11.sp,
                    color = Color(0xFF4A148C),
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    text = mate?.let { "Sire: ${it.tag_c} (${it.breed_c})" } ?: "Sire Recorded",
                    fontSize = 11.sp,
                    color = Color.DarkGray
                )
            }

            // Milestone Care Notice
            val milestoneAdvice = when {
                daysElapsed < 50 -> "Early Gestation: Maintain standard nutrition; avoid transport stress."
                daysElapsed in 50..100 -> "Mid Gestation: Confirm fetus with scan; gentle feeding increase."
                daysElapsed in 101..135 -> "Late Gestation: Administer CD&T vaccine booster; increase energy feed."
                else -> "Pre-Kidding Window: Disinfect kidding pen, clean bedding, watch for nesting behavior!"
            }

            Surface(
                shape = RoundedCornerShape(8.dp),
                color = Color.White.copy(alpha = 0.8f),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(Icons.Default.Info, contentDescription = null, tint = Color(0xFF7B1FA2), modifier = Modifier.size(14.dp))
                    Text(text = milestoneAdvice, fontSize = 11.sp, color = Color(0xFF4A148C), lineHeight = 14.sp)
                }
            }

            // Action row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End
            ) {
                OutlinedButton(
                    onClick = onUpdateStatus,
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.height(34.dp)
                ) {
                    Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Update Status / Log Kidding", fontSize = 11.sp)
                }
            }
        }
    }
}

/**
 * Individual row item for a mating record.
 */
@Composable
private fun IndividualMatingRecordItem(
    record: BreedingRecordEntity,
    goat: Goat,
    mate: Goat?,
    isDoe: Boolean,
    onUpdateStatus: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFFAFAFA)),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFF1F5F9)),
        modifier = Modifier.fillMaxWidth().testTag("individual_mating_item_${record.id}")
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Icon(Icons.Default.Favorite, contentDescription = null, tint = Color(0xFFD81B60), modifier = Modifier.size(16.dp))
                    Text(
                        text = "Mated on ${record.mating_date}",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = Color(0xFF0F172A)
                    )
                }

                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = when (record.status.lowercase()) {
                        "active" -> Color(0xFFEDE7F6)
                        "kidded" -> Color(0xFFE8F5E9)
                        "failed", "aborted" -> Color(0xFFFFEBEE)
                        else -> Color(0xFFF1F5F9)
                    }
                ) {
                    Text(
                        text = record.status,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = when (record.status.lowercase()) {
                            "active" -> Color(0xFF673AB7)
                            "kidded" -> Color(0xFF2E7D32)
                            "failed", "aborted" -> Color(0xFFC62828)
                            else -> Color.DarkGray
                        },
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                    )
                }
            }

            // Expected Kidding Date highlight
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    Icon(Icons.Default.Event, contentDescription = null, tint = FarmAmber, modifier = Modifier.size(14.dp))
                    Text(
                        text = "Expected Kidding: ${record.expected_kidding_date}",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = FarmAmberDark
                    )
                }

                Text(
                    text = mate?.let { "${if (isDoe) "Sire" else "Doe"}: ${it.tag_c} (${it.breed_c})" } ?: "Partner ID: ${if (isDoe) record.buck_id else record.doe_id}",
                    fontSize = 11.sp,
                    color = Color.Gray
                )
            }

            if (!record.outcome_notes.isNullOrBlank()) {
                Text(
                    text = "Notes: ${record.outcome_notes}",
                    fontSize = 11.sp,
                    color = Color(0xFF64748B)
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
            ) {
                TextButton(onClick = onUpdateStatus, contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp)) {
                    Text("Change Status", fontSize = 11.sp)
                }
                IconButton(onClick = onDelete, modifier = Modifier.size(24.dp)) {
                    Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color.LightGray, modifier = Modifier.size(16.dp))
                }
            }
        }
    }
}

@Composable
private fun BreedingStatCard(
    title: String,
    value: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    iconTint: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(10.dp),
        color = Color(0xFFF8FAFC),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(icon, contentDescription = null, tint = iconTint, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.height(4.dp))
            Text(value, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color(0xFF0F172A))
            Text(title, fontSize = 9.sp, color = Color.Gray, maxLines = 1)
        }
    }
}

/**
 * Dialog to record mating date for an individual goat and calculate expected kidding date.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RecordIndividualMatingDialog(
    currentGoat: Goat,
    allGoats: List<Goat>,
    onDismiss: () -> Unit,
    onSave: (buckId: String, doeId: String, matingDate: String, expectedDate: String, notes: String, status: String) -> Unit
) {
    val dateFormat = remember { SimpleDateFormat("yyyy-MM-dd", Locale.US) }
    val today = remember { dateFormat.format(Date()) }
    val isDoe = currentGoat.sex_c.equals("Doe", ignoreCase = true)

    var matingDate by remember { mutableStateOf(today) }
    var expectedKiddingDate by remember { mutableStateOf(computeExpectedDate(today, 150)) }
    var gestationDaysInput by remember { mutableIntStateOf(150) }
    var selectedPartnerId by remember { mutableStateOf("") }
    var partnerExpanded by remember { mutableStateOf(false) }
    var method by remember { mutableStateOf("Natural Service") }
    var notes by remember { mutableStateOf("") }

    val eligiblePartners = remember(allGoats, currentGoat) {
        if (isDoe) {
            allGoats.filter { it.sex_c.equals("Buck", ignoreCase = true) && it.id != currentGoat.id }
        } else {
            allGoats.filter { it.sex_c.equals("Doe", ignoreCase = true) && it.id != currentGoat.id }
        }
    }

    LaunchedEffect(matingDate, gestationDaysInput) {
        expectedKiddingDate = computeExpectedDate(matingDate, gestationDaysInput)
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(Icons.Default.Favorite, contentDescription = null, tint = Color(0xFFD81B60))
                Text("Log Mating & Expected Kidding", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(androidx.compose.foundation.rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Focus Goat Card
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = FarmGreenContainer,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(
                                text = if (isDoe) "Mother (Doe): ${currentGoat.name} (${currentGoat.tag_c})" else "Sire (Buck): ${currentGoat.name} (${currentGoat.tag_c})",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = FarmGreenDark
                            )
                            Text("Breed: ${currentGoat.breed_c}", fontSize = 11.sp, color = FarmGreenDark)
                        }
                        Surface(shape = RoundedCornerShape(6.dp), color = Color.White) {
                            Text(
                                text = if (isDoe) "DOE" else "BUCK",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = FarmGreenDark,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                }

                // Partner Dropdown
                ExposedDropdownMenuBox(
                    expanded = partnerExpanded,
                    onExpandedChange = { partnerExpanded = it },
                    modifier = Modifier.fillMaxWidth().testTag("dropdown_mating_partner")
                ) {
                    val partner = eligiblePartners.firstOrNull { it.id == selectedPartnerId }
                    OutlinedTextField(
                        value = partner?.let { "${it.tag_c} - ${it.name} (${it.breed_c})" } ?: "",
                        onValueChange = {},
                        readOnly = true,
                        label = { Text(if (isDoe) "Select Sire (Buck) *" else "Select Dam (Doe) *") },
                        placeholder = { Text("Choose eligible mate") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = partnerExpanded) },
                        modifier = Modifier.menuAnchor().fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp)
                    )
                    ExposedDropdownMenu(
                        expanded = partnerExpanded,
                        onDismissRequest = { partnerExpanded = false }
                    ) {
                        eligiblePartners.forEach { p ->
                            val isSameBreed = p.breed_c.equals(currentGoat.breed_c, ignoreCase = true)
                            DropdownMenuItem(
                                text = {
                                    Column {
                                        Text("${p.tag_c} - ${p.name} (${p.breed_c})", fontWeight = FontWeight.SemiBold)
                                        Text(
                                            text = if (isSameBreed) "Purebred Match (${p.breed_c})" else "Cross-Breed (${currentGoat.breed_c} x ${p.breed_c})",
                                            fontSize = 10.sp,
                                            color = if (isSameBreed) FarmGreenPrimary else Color(0xFFE65100)
                                        )
                                    }
                                },
                                onClick = {
                                    selectedPartnerId = p.id
                                    partnerExpanded = false
                                }
                            )
                        }
                    }
                }

                // Mating Date Picker
                DatePickerField(
                    dateValue = matingDate,
                    onDateSelected = { matingDate = it },
                    label = "Mating / Service Date *",
                    modifier = Modifier.fillMaxWidth().testTag("input_mating_date")
                )

                // Expected Kidding Date Computed Box
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFF3E5F5)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Expected Kidding Date",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF7B1FA2)
                            )
                            Text(
                                text = "$gestationDaysInput Days",
                                fontSize = 11.sp,
                                color = Color(0xFF7B1FA2),
                                fontWeight = FontWeight.SemiBold
                            )
                        }

                        Text(
                            text = expectedKiddingDate,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF4A148C)
                        )

                        Text(
                            text = "Standard goat gestation is 145–155 days (avg. 150 days). Calculated automatically from mating date.",
                            fontSize = 10.sp,
                            color = Color(0xFF6A1B9A),
                            lineHeight = 13.sp
                        )
                    }
                }

                // Breeding Method Chips
                Text("Breeding Method", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf("Natural Service", "Artificial Insemination (AI)").forEach { m ->
                        FilterChip(
                            selected = method == m,
                            onClick = { method = m },
                            label = { Text(m, fontSize = 11.sp) }
                        )
                    }
                }

                // Clinical & Mating Notes
                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Mating Notes / Heat Observations") },
                    placeholder = { Text("e.g. Standing heat, natural cover, pen A") },
                    modifier = Modifier.fillMaxWidth().testTag("input_mating_notes"),
                    maxLines = 3,
                    shape = RoundedCornerShape(10.dp)
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (selectedPartnerId.isNotBlank() && matingDate.isNotBlank()) {
                        val buckId = if (isDoe) selectedPartnerId else currentGoat.id
                        val doeId = if (isDoe) currentGoat.id else selectedPartnerId
                        val fullNotes = buildString {
                            append("Method: ").append(method)
                            if (notes.isNotBlank()) append(" | ").append(notes.trim())
                        }
                        onSave(buckId, doeId, matingDate, expectedKiddingDate, fullNotes, "Active")
                    }
                },
                enabled = selectedPartnerId.isNotBlank() && matingDate.isNotBlank(),
                colors = ButtonDefaults.buttonColors(containerColor = FarmGreenDark),
                modifier = Modifier.testTag("btn_save_individual_mating")
            ) {
                Text("Save Mating Record", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

/**
 * Dialog to update the status of an existing mating record (e.g. Kidded, Open/Failed).
 */
@Composable
private fun UpdateMatingStatusDialog(
    record: BreedingRecordEntity,
    onDismiss: () -> Unit,
    onConfirm: (status: String, notes: String) -> Unit
) {
    var selectedStatus by remember { mutableStateOf("Kidded") }
    var notes by remember { mutableStateOf("") }

    val statuses = listOf("Kidded", "Active", "Failed", "Aborted")

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Update Breeding Status", fontWeight = FontWeight.Bold, fontSize = 16.sp) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "Mating on ${record.mating_date} • Expected: ${record.expected_kidding_date}",
                    fontSize = 12.sp,
                    color = Color.Gray
                )

                Text("Select Outcome Status:", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    statuses.forEach { st ->
                        FilterChip(
                            selected = selectedStatus == st,
                            onClick = { selectedStatus = st },
                            label = { Text(st, fontSize = 11.sp) }
                        )
                    }
                }

                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Delivery / Outcome Notes") },
                    placeholder = { Text("e.g. Healthy single doe delivered, weight 2.8kg") },
                    modifier = Modifier.fillMaxWidth(),
                    maxLines = 2,
                    shape = RoundedCornerShape(10.dp)
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onConfirm(selectedStatus, notes) },
                colors = ButtonDefaults.buttonColors(containerColor = FarmGreenPrimary)
            ) {
                Text("Update Status")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

private fun computeExpectedDate(matingDateStr: String, daysToAdd: Int = 150): String {
    val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
    return try {
        val date = sdf.parse(matingDateStr) ?: Date()
        val cal = Calendar.getInstance()
        cal.time = date
        cal.add(Calendar.DAY_OF_YEAR, daysToAdd)
        sdf.format(cal.time)
    } catch (_: Exception) {
        matingDateStr
    }
}
