package com.example.data.supabase

import java.util.UUID

data class Goat(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val tag_c: String,
    val breed_c: String = "Boer",
    val sex_c: String = "Doe", // Buck, Doe, Wether, Kid
    val status_c: String = "Active", // Active, Pregnant, Lactating, Quarantine, Sold, Deceased
    val birth_date_c: String? = null,
    val weight_kg_c: Double? = null,
    val dam_c: String? = null,
    val sire_c: String? = null,
    val source_c: String? = "Born on farm",
    val purchase_date_c: String? = null,
    val purchase_cost_c: Double? = null,
    val farm_location_c: String? = "Barn A",
    val color_c: String? = null,
    val notes_c: String? = null,
    val created_at: String? = null,
    val origin_c: String? = null,
    val sire_id: String? = null,
    val dam_id: String? = null,
    val photo_url_c: String? = null,
    val health_status_c: String? = "Healthy" // Healthy, Sick, Under Observation, Quarantined
) {
    val effectiveOrigin: String
        get() {
            if (!origin_c.isNullOrBlank()) {
                val upper = origin_c.trim().uppercase()
                if (upper in listOf("FARM_BORN", "MARKET_BOUGHT", "UNKNOWN")) return upper
            }
            return when (source_c?.trim()?.lowercase()) {
                "born on farm", "farm born", "farm_born" -> "FARM_BORN"
                "purchased", "market bought", "market_bought", "market" -> "MARKET_BOUGHT"
                else -> "UNKNOWN"
            }
        }

    val effectiveSireId: String?
        get() = sire_id?.takeIf { it.isNotBlank() } ?: sire_c?.takeIf { it.isNotBlank() }

    val effectiveDamId: String?
        get() = dam_id?.takeIf { it.isNotBlank() } ?: dam_c?.takeIf { it.isNotBlank() }

    val tagId: String get() = tag_c
    val earTagId: String get() = tag_c
    val breed: String get() = breed_c
    val dateOfBirth: String? get() = birth_date_c
    val gender: String get() = sex_c

    constructor(
        id: String = UUID.randomUUID().toString(),
        name: String = "Goat",
        tagId: String,
        breed: String = "Boer",
        gender: String = "Doe",
        dateOfBirth: String? = null,
        status: String = "Active",
        weightKg: Double? = null
    ) : this(
        id = id,
        name = name,
        tag_c = tagId,
        breed_c = breed,
        sex_c = gender,
        status_c = status,
        birth_date_c = dateOfBirth,
        weight_kg_c = weightKg
    )
}

data class GoatWeight(
    val id: String = UUID.randomUUID().toString(),
    val goat_id_c: String,
    val weight_kg_c: Double,
    val date_c: String,
    val method_c: String = "Scale", // Scale, Weight Tape, Visual Estimate
    val notes_c: String? = null,
    val timestamp: Long = System.currentTimeMillis()
)

data class VaccinationRecord(
    val id: String = UUID.randomUUID().toString(),
    val goat_id_c: String,
    val vaccine_c: String,
    val dose_c: String = "1 ml",
    val administered_date_c: String,
    val next_due_date_c: String? = null,
    val batch_number_c: String? = null,
    val administered_by_c: String? = null,
    val notes_c: String? = null
)

data class DewormingRecord(
    val id: String = UUID.randomUUID().toString(),
    val goat_id_c: String,
    val medicine_c: String,
    val dose_c: String = "5 ml",
    val treatment_date_c: String,
    val next_due_date_c: String? = null,
    val weight_at_treatment_c: Double? = null,
    val administered_by_c: String? = null,
    val notes_c: String? = null
)

data class TreatmentRecord(
    val id: String = UUID.randomUUID().toString(),
    val goat_id_c: String,
    val symptoms_c: String,
    val diagnosis_c: String,
    val medicine_c: String,
    val dose_c: String,
    val start_date_c: String,
    val end_date_c: String? = null,
    val veterinarian_c: String? = null,
    val outcome_c: String = "Under Treatment", // Recovered, Under Treatment, Relapsed, Deceased
    val temperature_c: Double? = null,
    val cost_c: Double? = null,
    val record_type_c: String = "Treatment", // Treatment, Illness, Vet Visit, Health Observation
    val notes_c: String? = null
)

data class MatingRecord(
    val id: String = UUID.randomUUID().toString(),
    val doe_id_c: String,
    val buck_id_c: String,
    val mating_date_c: String,
    val heat_observed_c: Boolean = true,
    val method_c: String = "Natural", // Natural, Artificial Insemination
    val notes_c: String? = null
)

data class PregnancyRecord(
    val id: String = UUID.randomUUID().toString(),
    val doe_id_c: String,
    val mating_record_id_c: String? = null,
    val confirmation_date_c: String,
    val expected_kidding_date_c: String,
    val status_c: String = "Confirmed", // Confirmed, Suspected, Delivered, Aborted
    val actual_kidding_date_c: String? = null,
    val notes_c: String? = null
)

data class KiddingRecord(
    val id: String = UUID.randomUUID().toString(),
    val doe_id_c: String,
    val pregnancy_id_c: String? = null,
    val kidding_date_c: String,
    val birth_type_c: String = "Single", // Single, Twin, Triplet, Quadruplet
    val assistance_c: String = "None", // None, Easy Pull, Hard Pull, Surgical
    val complications_c: String = "None",
    val sire_id_c: String? = null,
    val notes_c: String? = null
)

data class KidRecord(
    val id: String = UUID.randomUUID().toString(),
    val kid_tag_c: String,
    val kidding_record_id_c: String,
    val birth_weight_c: Double? = null,
    val birth_order_c: Int = 1,
    val sex_c: String = "Doe", // Doe, Buck
    val birth_status_c: String = "Alive", // Alive, Stillborn
    val photo_url_c: String? = null,
    val notes_c: String? = null
)

data class FeedItem(
    val id: String = UUID.randomUUID().toString(),
    val name_c: String,
    val category_c: String? = "Green Fodder",
    val current_stock_kg_c: Double = 0.0,
    val unit_c: String = "kg",
    val cost_per_unit_c: Double? = null
)

data class FeedMovement(
    val id: String = UUID.randomUUID().toString(),
    val feed_id_c: String,
    val movement_type_c: String, // Purchase, Consumption, Wastage, Adjustment
    val quantity_c: Double,
    val date_c: String,
    val notes_c: String? = null
)

data class MedicineItem(
    val id: String = UUID.randomUUID().toString(),
    val medicine_name_c: String,
    val category_c: String = "Antibiotic", // Antibiotic, Dewormer, Vaccine, Vitamin, Antiseptic
    val quantity_c: Double = 0.0,
    val unit_c: String = "ml",
    val reorder_level_c: Double = 10.0,
    val unit_cost_c: Double? = null,
    val expiry_date_c: String? = null,
    val supplier_c: String? = null
)

data class FarmTask(
    val id: String = UUID.randomUUID().toString(),
    val title_c: String,
    val description_c: String? = null,
    val due_date_c: String,
    val priority_c: String = "Normal", // High, Normal, Low
    val status_c: String = "Pending", // Pending, Completed
    val assigned_to_c: String? = null,
    val related_goat_id_c: String? = null
)

data class QuickDueItem(
    val id: String,
    val goat_id_c: String,
    val goat_tag: String,
    val goat_name: String,
    val record_type: String, // "Vaccination", "Deworming", "Pregnancy Check", "Task"
    val detail: String,
    val due_date: String,
    val days_diff: Int // negative = overdue, positive = due in X days
)

data class FarmFinanceSummary(
    val totalIncome: Double = 0.0,
    val goatSalesIncome: Double = 0.0,
    val manureSalesIncome: Double = 0.0,
    val milkSalesIncome: Double = 0.0,
    val otherIncome: Double = 0.0,
    val totalExpenses: Double = 0.0,
    val feedExpenses: Double = 0.0,
    val medicineExpenses: Double = 0.0,
    val veterinaryExpenses: Double = 0.0,
    val labourExpenses: Double = 0.0,
    val otherExpenses: Double = 0.0,
    val netProfit: Double = 0.0,
    val netCashFlow: Double = 0.0,
    val isProfitable: Boolean = true,
    val totalTransactions: Int = 0,
    val totalManureBags: Int = 0,
    val totalMilkLiters: Double = 0.0
)

data class DashboardSummary(
    val totalGoats: Int = 0,
    val bucks: Int = 0,
    val does: Int = 0,
    val kids: Int = 0,
    val pregnantDoes: Int = 0,
    val vaccinationsDue: Int = 0,
    val dewormingDue: Int = 0,
    val todayTasks: Int = 0,
    val totalSales: Double = 0.0,
    val financeSummary: FarmFinanceSummary = FarmFinanceSummary()
)

data class SaleRecord(
    val id: String = UUID.randomUUID().toString(),
    val goat_id_c: String,
    val amount_c: Double,
    val sale_date_c: String,
    val buyer_name_c: String = "",
    val buyer_phone_c: String = "",
    val payment_mode_c: String = "CASH", // CASH, UPI_QR, PAYTM_GATEWAY, CREDIT
    val payment_status_c: String = "PAID", // PAID, PARTIALLY_PAID, UNPAID, PENDING, FAILED, CANCELLED, REFUNDED
    val notes_c: String? = null,
    val created_at: String? = null,
    val order_id_c: String? = null,
    val transaction_id_c: String? = null,
    val bank_transaction_id_c: String? = null,
    val reference_c: String? = null,
    val currency_c: String = "INR",
    val payment_timestamp_c: String? = null,
    val failure_reason_c: String? = null,
    val sale_type_c: String = "PIECE", // PIECE, WEIGHT
    val quantity_c: Int = 1,
    val total_weight_kg_c: Double = 0.0,
    val rate_per_unit_c: Double = 0.0, // Rate per piece or rate per kg
    val buyer_address_c: String = "",
    val buyer_village_c: String = "",
    val amount_paid_c: Double = 0.0,
    val balance_due_c: Double = 0.0,
    val delivery_status_c: String = "DELIVERED", // EXPECTED, READY, DISPATCHED, DELIVERED, CANCELLED
    val expected_delivery_date_c: String? = null,
    val actual_delivery_date_c: String? = null,
    val delivery_photo_uri_c: String? = null,
    val customer_id_c: String? = null
)

data class DeliveryRecord(
    val id: String = UUID.randomUUID().toString(),
    val sale_id_c: String,
    val goat_id_c: String? = null,
    val customer_id_c: String? = null,
    val recipient_name_c: String = "",
    val recipient_phone_c: String = "",
    val delivery_address_c: String = "",
    val expected_delivery_date_c: String? = null,
    val actual_delivery_date_c: String? = null,
    val delivery_status_c: String = "EXPECTED", // EXPECTED, READY, DISPATCHED, DELIVERED, CANCELLED
    val delivery_photo_uri_c: String? = null,
    val delivery_notes_c: String? = null,
    val outstanding_balance_c: Double = 0.0,
    val is_delivered: Boolean = false,
    val marked_by_c: String? = null,
    val created_at: String? = null
)

data class PaymentLedgerRecord(
    val id: String = UUID.randomUUID().toString(),
    val sale_id_c: String,
    val customer_id_c: String? = null,
    val amount_c: Double,
    val payment_method_c: String, // CASH, UPI_QR, PAYTM_GATEWAY
    val payment_date_c: String,
    val reference_number_c: String? = null,
    val notes_c: String? = null,
    val source_c: String = "MANUAL", // MANUAL, SMS, PAYTM_GATEWAY
    val created_at: String? = null
)

data class CustomerRecord(
    val id: String = UUID.randomUUID().toString(),
    val name_c: String,
    val phone_c: String = "",
    val address_c: String = "",
    val village_c: String = "",
    val outstanding_balance_c: Double = 0.0,
    val total_purchases_c: Double = 0.0,
    val total_paid_c: Double = 0.0,
    val notes_c: String? = null,
    val created_at: String? = null
)

data class MilkRecord(
    val id: String = UUID.randomUUID().toString(),
    val goat_id_c: String,
    val date_c: String,
    val morning_milk_ltr_c: Double = 0.0,
    val evening_milk_ltr_c: Double = 0.0,
    val total_milk_ltr_c: Double = morning_milk_ltr_c + evening_milk_ltr_c,
    val fat_percentage_c: Double? = null,
    val notes_c: String? = null,
    val created_at: String? = null
)

data class FinanceTransaction(
    val id: String = UUID.randomUUID().toString(),
    val type_c: String, // "INCOME", "EXPENSE"
    val category_c: String, // "Goat Sale", "Milk Sale", "Feed", "Medicine", "Veterinary", "Labour", "Other Income", "Other Expense"
    val amount_c: Double,
    val date_c: String,
    val reference_id_c: String? = null, // e.g. goat_id, sale_id, feed_id
    val payment_mode_c: String = "CASH",
    val description_c: String? = null,
    val notes_c: String? = null,
    val created_at: String? = null
)

data class AuditLogEntry(
    val id: String = UUID.randomUUID().toString(),
    val user_email_c: String = "admin@goatfarm.local",
    val action_c: String, // "CREATE", "UPDATE", "DELETE"
    val entity_c: String, // "GOAT", "WEIGHT", "BREEDING", "PREGNANCY", "KIDDING", "HEALTH", "SALE", "MILK", "FINANCE"
    val record_id_c: String,
    val details_c: String,
    val timestamp_c: Long = System.currentTimeMillis()
)

data class FarmTimelineEvent(
    val id: String,
    val date: String,
    val type: String, // "WEIGHT", "VACCINATION", "DEWORMING", "TREATMENT", "MATING", "PREGNANCY", "KIDDING", "MILK", "SALE"
    val title: String,
    val subtitle: String,
    val details: String? = null,
    val referenceId: String? = null,
    val timestamp: Long = 0L
)

data class FarmAsset(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val category: String = "Farm Buildings", // Farm Buildings, Farm Infrastructure, Equipment, Vehicles
    val purchase_date: String? = null,
    val cost: Double = 0.0,
    val useful_life: Int = 5, // Useful life in years
    val current_condition: String = "Good", // Excellent, Good, Fair, Poor, Damaged
    val location: String = "Main Shed",
    val warranty_expiry: String? = null,
    val maintenance_schedule: String? = "Monthly", // Daily, Weekly, Monthly, Quarterly, Half-yearly, Yearly
    val asset_id: String? = null,
    val supplier: String? = null,
    val quantity: Int = 1,
    val status: String = "Active", // Active, Under maintenance, Damaged, Sold, Disposed
    val amc_expiry: String? = null,
    val last_maintenance: String? = null,
    val next_maintenance: String? = null,
    val residual_value: Double = 0.0,
    val depreciation_method: String = "Straight-line",
    val accumulated_depreciation: Double = 0.0,
    val current_book_value: Double = cost,
    val is_capex: Boolean = true,
    val notes: String? = null,
    val photo_url: String? = null,
    val created_at: String? = null
) {
    /**
     * Straight-line annual depreciation calculation:
     * (Cost - Residual Value) / Useful Life
     */
    val annualDepreciation: Double
        get() {
            if (useful_life <= 0) return 0.0
            val depreciableAmount = (cost - residual_value).coerceAtLeast(0.0)
            return depreciableAmount / useful_life
        }

    val monthlyDepreciation: Double
        get() = annualDepreciation / 12.0

    /**
     * Calculates the estimated current book value using straight-line depreciation
     * based on years elapsed since purchase date (or defaults to cost - accumulated_depreciation).
     */
    fun calculateBookValue(yearsElapsed: Double? = null): Double {
        val elapsed = yearsElapsed ?: 0.0
        val totalDepreciation = (annualDepreciation * elapsed).coerceAtMost((cost - residual_value).coerceAtLeast(0.0))
        return (cost - totalDepreciation).coerceAtLeast(residual_value)
    }
}

data class FarmAssetsSummary(
    val totalAssetsCount: Int = 0,
    val totalCostCapex: Double = 0.0,
    val currentBookValue: Double = 0.0,
    val accumulatedDepreciation: Double = 0.0,
    val activeCount: Int = 0,
    val underMaintenanceCount: Int = 0,
    val damagedCount: Int = 0,
    val upcomingMaintenanceCount: Int = 0,
    val categoryBreakdown: Map<String, Double> = emptyMap()
)

// ==============================================================================
// 1. FINANCIAL ACCOUNTS (Multi-Account Cash & Bank Ledger)
// ==============================================================================
data class FinancialAccount(
    val id: String = UUID.randomUUID().toString(),
    val account_name: String,
    val account_type: String = "CASH", // CASH, CURRENT_BANK, SAVINGS_BANK, UPI, OTHER
    val account_number: String? = null,
    val upi_id: String? = null,
    val bank_name: String? = null,
    val ifsc_code: String? = null,
    val branch: String? = null,
    val opening_balance: Double = 0.0,
    val current_balance: Double = opening_balance,
    val opening_date: String? = null,
    val is_active: Boolean = true,
    val created_at: String? = null
) {
    val maskedAccountNumber: String
        get() {
            if (!upi_id.isNullOrBlank()) return upi_id
            val num = account_number ?: return ""
            return if (num.length > 4) "•••• " + num.takeLast(4) else num
        }
}

// ==============================================================================
// 2. ACCOUNT TRANSACTIONS (Audit Trail & 3-Pillar Cash Flow Movements)
// ==============================================================================
data class AccountTransaction(
    val id: String = UUID.randomUUID().toString(),
    val date: String,
    val account_id: String,
    val transaction_type: String, // INCOME, EXPENSE, TRANSFER, DEPOSIT, WITHDRAWAL, CUSTOMER_RECEIPT, SUPPLIER_PAYMENT, LOAN_RECEIPT, LOAN_REPAYMENT, OWNER_INVESTMENT, OWNER_WITHDRAWAL
    val amount: Double,
    val category: String,
    val payment_mode: String = "Cash", // Cash, Bank Transfer, UPI, Cheque, Card
    val reference_id: String? = null,
    val to_account_id: String? = null, // Set for TRANSFER / CONTRA transactions
    val affects_pnl: Boolean = when (transaction_type.uppercase()) {
        "TRANSFER", "DEPOSIT", "WITHDRAWAL", "LOAN_RECEIPT", "LOAN_REPAYMENT", "OWNER_INVESTMENT", "OWNER_WITHDRAWAL" -> false
        else -> true
    },
    val pillar: String = if (transaction_type.equals("TRANSFER", ignoreCase = true)) "NON_CASH" else "OPERATING", // OPERATING, INVESTING, FINANCING, NON_CASH
    val description: String? = null,
    val related_entity_type: String? = null, // GOAT, SALE, FEED, MEDICINE, EB, SUPPLIER, LOAN, ASSET
    val related_entity_id: String? = null,
    val created_by: String = "user",
    val created_at: String? = null
)

// ==============================================================================
// 3. RECURRING EXPENSES (Upcoming, Overdue & Template Manager)
// ==============================================================================
data class RecurringExpense(
    val id: String = UUID.randomUUID().toString(),
    val expense_name: String,
    val category: String, // Electricity/EB, Water, Rent, Labour, Security, Internet, Mobile, Insurance, AMC, Vehicle EMI, Loan EMI, Software/subscriptions, Other
    val vendor: String? = null,
    val amount: Double,
    val frequency: String = "MONTHLY", // DAILY, WEEKLY, MONTHLY, QUARTERLY, HALF_YEARLY, YEARLY
    val start_date: String,
    val end_date: String? = null,
    val next_due_date: String,
    val payment_account_id: String? = null,
    val payment_method: String = "BANK",
    val gst_applicable: Boolean = false,
    val gst_rate: Double = 0.0,
    val notes: String? = null,
    val is_active: Boolean = true,
    val created_at: String? = null
)

// ==============================================================================
// 4. ELECTRICITY / EB (Meter Connections & Billing History)
// ==============================================================================
data class ElectricityConnection(
    val id: String = UUID.randomUUID().toString(),
    val connection_name: String,
    val consumer_number: String,
    val meter_number: String,
    val service_provider: String,
    val tariff_category: String = "Agricultural",
    val location: String = "Main Shed",
    val billing_cycle: String = "Monthly",
    val is_active: Boolean = true,
    val created_at: String? = null
)

data class ElectricityBill(
    val id: String = UUID.randomUUID().toString(),
    val connection_id: String,
    val billing_period: String,
    val bill_date: String,
    val due_date: String,
    val previous_reading: Double,
    val current_reading: Double,
    val units_consumed: Double = (current_reading - previous_reading).coerceAtLeast(0.0),
    val base_amount: Double,
    val other_charges: Double = 0.0,
    val tax_amount: Double = 0.0,
    val total_bill: Double = base_amount + other_charges + tax_amount,
    val paid_amount: Double = 0.0,
    val balance_amount: Double = (total_bill - paid_amount).coerceAtLeast(0.0),
    val payment_date: String? = null,
    val payment_account_id: String? = null,
    val payment_status: String = "UNPAID", // UNPAID, PARTIALLY_PAID, PAID
    val notes: String? = null,
    val created_at: String? = null
)

// ==============================================================================
// 5. LOANS & BORROWINGS (Principal, Interest & EMI Schedules)
// ==============================================================================
data class Loan(
    val id: String = UUID.randomUUID().toString(),
    val lender: String,
    val loan_name: String,
    val loan_account_number: String,
    val loan_type: String = "BANK_LOAN", // BANK_LOAN, NBFC_LOAN, VEHICLE_LOAN, EQUIPMENT_LOAN, BUSINESS_LOAN, PERSONAL_LOAN, OTHER
    val sanctioned_amount: Double,
    val disbursed_amount: Double,
    val interest_rate: Double, // Annual percentage rate
    val interest_type: String = "Diminishing", // Diminishing, Flat
    val tenure_months: Int,
    val emi_amount: Double,
    val start_date: String,
    val first_emi_date: String,
    val maturity_date: String,
    val processing_fee: Double = 0.0,
    val outstanding_principal: Double = disbursed_amount,
    val total_interest_paid: Double = 0.0,
    val total_principal_paid: Double = 0.0,
    val disbursement_account_id: String? = null,
    val status: String = "ACTIVE", // ACTIVE, CLOSED, DEFAULTED
    val notes: String? = null,
    val created_at: String? = null
)

data class LoanSchedule(
    val id: String = UUID.randomUUID().toString(),
    val loan_id: String,
    val emi_number: Int,
    val due_date: String,
    val opening_principal: Double,
    val principal_component: Double,
    val interest_component: Double,
    val emi_amount: Double,
    val closing_principal: Double,
    val paid_date: String? = null,
    val paid_amount: Double = 0.0,
    val payment_account_id: String? = null,
    val status: String = "PENDING", // PENDING, PAID, OVERDUE, PARTIAL
    val created_at: String? = null
)

// ==============================================================================
// 6. CREDITORS / SUPPLIERS (Accounts Payable & Invoices)
// ==============================================================================
data class Supplier(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val phone: String? = null,
    val address: String? = null,
    val gstin: String? = null,
    val credit_limit: Double = 0.0,
    val credit_period_days: Int = 30,
    val opening_balance: Double = 0.0,
    val current_outstanding: Double = opening_balance,
    val is_active: Boolean = true,
    val created_at: String? = null
)

data class SupplierInvoice(
    val id: String = UUID.randomUUID().toString(),
    val supplier_id: String,
    val invoice_number: String,
    val invoice_date: String,
    val due_date: String,
    val items_description: String,
    val quantity: Double = 1.0,
    val rate: Double = 0.0,
    val taxable_value: Double,
    val gst_rate: Double = 0.0,
    val gst_amount: Double = (taxable_value * gst_rate / 100.0),
    val total_amount: Double = taxable_value + gst_amount,
    val paid_amount: Double = 0.0,
    val balance_due: Double = (total_amount - paid_amount).coerceAtLeast(0.0),
    val status: String = "UNPAID", // UNPAID, PARTIALLY_PAID, PAID, OVERDUE
    val notes: String? = null,
    val created_at: String? = null
)

data class SupplierPayment(
    val id: String = UUID.randomUUID().toString(),
    val invoice_id: String,
    val supplier_id: String,
    val payment_date: String,
    val amount: Double,
    val payment_account_id: String,
    val payment_mode: String = "BANK",
    val reference_number: String? = null,
    val notes: String? = null,
    val created_at: String? = null
)

// ==============================================================================
// 7. GST CONFIGURATION & INVOICING
// ==============================================================================
data class GstSettings(
    val id: String = "default_gst_settings",
    val gst_enabled: Boolean = false,
    val business_name: String = "Green Pastures Goat Farm",
    val business_address: String = "Farm Road, Rural District",
    val gstin: String = "",
    val state_name: String = "Tamil Nadu",
    val state_code: String = "33",
    val invoice_prefix: String = "INV",
    val next_invoice_number: Int = 1001,
    val default_hsn: String = "0104",
    val default_tax_rate: Double = 5.0,
    val updated_at: Long = System.currentTimeMillis()
)

data class GstTaxBreakdown(
    val taxableValue: Double,
    val gstRate: Double,
    val isInterState: Boolean,
    val cgstRate: Double = if (isInterState) 0.0 else gstRate / 2.0,
    val cgstAmount: Double = if (isInterState) 0.0 else taxableValue * (gstRate / 200.0),
    val sgstRate: Double = if (isInterState) 0.0 else gstRate / 2.0,
    val sgstAmount: Double = if (isInterState) 0.0 else taxableValue * (gstRate / 200.0),
    val igstRate: Double = if (isInterState) gstRate else 0.0,
    val igstAmount: Double = if (isInterState) taxableValue * (gstRate / 100.0) else 0.0,
    val totalTax: Double = if (isInterState) igstAmount else cgstAmount + sgstAmount,
    val grandTotal: Double = taxableValue + totalTax
)

// ==============================================================================
// 8. E-WAY BILL
// ==============================================================================
data class EWayBill(
    val id: String = UUID.randomUUID().toString(),
    val invoice_id: String,
    val invoice_number: String,
    val supplier_gstin: String,
    val recipient_gstin: String? = null,
    val place_of_supply: String,
    val delivery_address: String,
    val hsn_code: String = "0104",
    val quantity: Double,
    val taxable_value: Double,
    val gst_amount: Double,
    val total_value: Double,
    val transporter_id: String? = null,
    val transporter_name: String? = null,
    val vehicle_number: String,
    val transport_mode: String = "Road",
    val transport_doc_number: String? = null,
    val document_date: String,
    val eway_bill_number: String? = null, // Stored if government API provides, null if unconfigured
    val status: String = "Draft", // Draft, Ready, Submitted, Generated, Active, Cancelled, Expired, Error
    val error_message: String? = null,
    val created_at: String? = null
)

// ==============================================================================
// 9. THREE-PILLAR CASH FLOW & FINANCIAL REPORT MODELS
// ==============================================================================
data class ThreePillarCashFlowSummary(
    val openingCashAndBank: Double = 0.0,
    // Operating Cash Flow
    val operatingInflow: Double = 0.0,
    val operatingOutflow: Double = 0.0,
    val netOperatingCashFlow: Double = operatingInflow - operatingOutflow,
    // Investing Cash Flow (CAPEX & Assets)
    val investingInflow: Double = 0.0,
    val investingOutflow: Double = 0.0,
    val netInvestingCashFlow: Double = investingInflow - investingOutflow,
    // Financing Cash Flow (Owner investment, loans, repayments)
    val financingInflow: Double = 0.0,
    val financingOutflow: Double = 0.0,
    val netFinancingCashFlow: Double = financingInflow - financingOutflow,
    // Reconciled Closing Balance
    val closingCashAndBank: Double = openingCashAndBank + netOperatingCashFlow + netInvestingCashFlow + netFinancingCashFlow,
    val totalLiquidFundsInAccounts: Double = 0.0,
    val isReconciled: Boolean = Math.abs(closingCashAndBank - totalLiquidFundsInAccounts) < 0.05
)

data class UnifiedPaymentsDueItem(
    val id: String,
    val type: String, // "EB", "SUPPLIER", "LOAN_EMI", "RECURRING"
    val title: String,
    val subtitle: String,
    val dueDate: String,
    val amount: Double,
    val isOverdue: Boolean,
    val daysRemaining: Int,
    val referenceId: String
)


