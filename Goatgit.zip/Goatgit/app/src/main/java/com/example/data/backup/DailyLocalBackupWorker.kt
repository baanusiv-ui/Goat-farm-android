package com.example.data.backup

import android.content.Context
import android.util.Log
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.example.data.offline.AppDatabase
import com.example.data.offline.NetworkMonitor
import com.example.data.offline.OfflineSyncManager
import com.example.data.supabase.SupabaseClient
import com.example.data.supabase.SupabaseConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Android WorkManager Worker that performs daily automatic local backups to device storage.
 * Works completely offline with zero internet or cloud dependencies.
 */
class DailyLocalBackupWorker(
    appContext: Context,
    workerParams: WorkerParameters
) : CoroutineWorker(appContext, workerParams) {

    companion object {
        private const val TAG = "DailyLocalBackupWorker"
    }

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        Log.d(TAG, "Starting scheduled daily local device backup...")

        val context = applicationContext
        val database = AppDatabase.getDatabase(context)
        val networkMonitor = NetworkMonitor(context)
        val config = SupabaseConfig(context)
        val client = SupabaseClient(config)
        val syncManager = OfflineSyncManager(context, database, client, networkMonitor)
        val authManager = GoogleAuthManager(context)
        val backupManager = BackupManager(context, database, syncManager, authManager)

        // 1. Check if auto backup is enabled
        if (!backupManager.isAutoBackupEnabled.value) {
            Log.d(TAG, "Automatic backup is disabled in settings. Skipping worker execution.")
            return@withContext Result.success()
        }

        // 2. Perform local backup to device storage
        try {
            val result = backupManager.createLocalDeviceBackup(isScheduled = true)
            if (result.isSuccess) {
                val backupFile = result.getOrNull()
                Log.d(TAG, "Daily local device backup completed successfully: ${backupFile?.fileName}")
                Result.success()
            } else {
                val error = result.exceptionOrNull()?.message ?: "Unknown local backup failure"
                Log.e(TAG, "Daily local backup failed: $error")
                Result.retry()
            }
        } catch (e: Exception) {
            Log.e(TAG, "Exception during daily local backup: ${e.message}", e)
            Result.retry()
        }
    }
}
