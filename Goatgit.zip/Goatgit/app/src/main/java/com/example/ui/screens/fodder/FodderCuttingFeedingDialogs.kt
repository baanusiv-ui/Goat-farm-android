package com.example.ui.screens.fodder

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.offline.*
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RecordCuttingDialog(
    plots: List<FodderPlotEntity>,
    preselectedPlotId: String? = null,
    preselectedRows: List<String> = emptyList(),
    onDismiss: () -> Unit,
    onSave: (
        plotId: String,
        selectedRowCodes: List<String>,
        harvestedWeightKg: Double,
        cuttingDate: String,
        laborCost: Double?,
        harvesterName: String?,
        qualityRating: String,
        notes: String?
    ) -> Unit
) {
    var selectedPlotId by remember { mutableStateOf(preselectedPlotId ?: plots.firstOrNull()?.id ?: "") }
    val selectedPlot = remember(selectedPlotId, plots) { plots.find { it.id == selectedPlotId } ?: plots.firstOrNull() }

    var harvestMode by remember { mutableStateOf(if (preselectedRows.isNotEmpty()) "Rows" else "Entire") } // "Entire" or "Rows"
    var startRowIndexStr by remember {
        mutableStateOf(
            if (preselectedRows.isNotEmpty()) preselectedRows.first().replace("R", "").toIntOrNull()?.toString() ?: "1" else "1"
        )
    }
    var endRowIndexStr by remember {
        mutableStateOf(
            if (preselectedRows.isNotEmpty()) preselectedRows.last().replace("R", "").toIntOrNull()?.toString() ?: "5" else "5"
        )
    }

    var harvestedWeight by remember { mutableStateOf("") }
    var cuttingDate by remember { mutableStateOf(SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())) }
    var laborCost by remember { mutableStateOf("") }
    var harvesterName by remember { mutableStateOf("") }
    var qualityRating by remember { mutableStateOf("Tender & Leafy") }
    var notes by remember { mutableStateOf("") }

    var plotDropdownExpanded by remember { mutableStateOf(false) }

    val qualityOptions = listOf("Tender & Leafy", "Good Standard", "Fibrous / Late Cut")

    // Calculations (Requirement 6)
    val maxRows = selectedPlot?.row_count ?: 40
    val rowLength = selectedPlot?.row_length ?: 25.0
    val rowLengthUnit = selectedPlot?.row_length_unit ?: "metre"

    val startRow = (startRowIndexStr.toIntOrNull() ?: 1).coerceIn(1, maxRows)
    val endRow = (endRowIndexStr.toIntOrNull() ?: 1).coerceIn(startRow, maxRows)

    val effectiveRowCount = if (harvestMode == "Entire") maxRows else (endRow - startRow + 1)
    val totalHarvestedLength = effectiveRowCount * rowLength

    val parsedWeight = harvestedWeight.toDoubleOrNull() ?: 0.0
    val yieldPerMetre = if (totalHarvestedLength > 0 && parsedWeight > 0) parsedWeight / totalHarvestedLength else 0.0
    val yieldPerRow = if (effectiveRowCount > 0 && parsedWeight > 0) parsedWeight / effectiveRowCount else 0.0

    val generatedRowCodes: List<String> = if (harvestMode == "Entire") {
        (1..maxRows).map { "R%02d".format(it) }
    } else {
        (startRow..endRow).map { "R%02d".format(it) }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.ContentCut, contentDescription = null, tint = FarmGreenDark)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Record Fodder Cutting", fontWeight = FontWeight.Bold)
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 500.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Plot Dropdown
                ExposedDropdownMenuBox(
                    expanded = plotDropdownExpanded,
                    onExpandedChange = { plotDropdownExpanded = !plotDropdownExpanded }
                ) {
                    OutlinedTextField(
                        value = selectedPlot?.let { "${it.plot_name} (${it.species_name})" } ?: "Select Plot",
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Field / Plot *") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = plotDropdownExpanded) },
                        modifier = Modifier.fillMaxWidth().menuAnchor()
                    )
                    ExposedDropdownMenu(
                        expanded = plotDropdownExpanded,
                        onDismissRequest = { plotDropdownExpanded = false }
                    ) {
                        plots.forEach { p ->
                            DropdownMenuItem(
                                text = { Text("${p.plot_name} (${p.species_name})") },
                                onClick = {
                                    selectedPlotId = p.id
                                    plotDropdownExpanded = false
                                }
                            )
                        }
                    }
                }

                // ==========================================
                // ROW-LEVEL HARVEST SELECTION (Requirement 6)
                // ==========================================
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Color(0xFFF1F8E9),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(
                            text = "HARVEST SCOPE (Entire Field or Row Range):",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = FarmGreenDark
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            FilterChip(
                                selected = harvestMode == "Rows",
                                onClick = { harvestMode = "Rows" },
                                label = { Text("Selected Rows / Range", fontSize = 11.sp) },
                                modifier = Modifier.weight(1f)
                            )
                            FilterChip(
                                selected = harvestMode == "Entire",
                                onClick = { harvestMode = "Entire" },
                                label = { Text("Entire Field ($maxRows Rows)", fontSize = 11.sp) },
                                modifier = Modifier.weight(1f)
                            )
                        }

                        if (harvestMode == "Rows") {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                OutlinedTextField(
                                    value = startRowIndexStr,
                                    onValueChange = { startRowIndexStr = it },
                                    label = { Text("Start Row (e.g. 1)") },
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                    modifier = Modifier.weight(1f),
                                    singleLine = true
                                )
                                Text("to", fontWeight = FontWeight.Bold, color = Color.Gray)
                                OutlinedTextField(
                                    value = endRowIndexStr,
                                    onValueChange = { endRowIndexStr = it },
                                    label = { Text("End Row (e.g. 5)") },
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                    modifier = Modifier.weight(1f),
                                    singleLine = true
                                )
                            }
                        }

                        // Harvest Row Stats Banner
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = Color.White,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = if (harvestMode == "Entire") "All $maxRows Rows (R01–R%02d)".format(maxRows) else "Rows R%02d–R%02d ($effectiveRowCount rows)".format(startRow, endRow),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = FarmGreenDark
                                )
                                Text(
                                    text = "${totalHarvestedLength.toInt()} $rowLengthUnit total length",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = Color.DarkGray
                                )
                            }
                        }
                    }
                }

                // Weight in Kg & Date
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = harvestedWeight,
                        onValueChange = { harvestedWeight = it },
                        label = { Text("Fresh Fodder (kg) *") },
                        placeholder = { Text("e.g. 150") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.weight(1.2f).testTag("cutting_weight_input"),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = cuttingDate,
                        onValueChange = { cuttingDate = it },
                        label = { Text("Date") },
                        placeholder = { Text("YYYY-MM-DD") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                }

                // Live Yield Calculation Display (Requirement 6)
                if (parsedWeight > 0) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = Color(0xFFE8F5E9),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 10.dp, vertical = 6.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "Yield/m: ${String.format(Locale.US, "%.2f", yieldPerMetre)} kg/m",
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp,
                                color = FarmGreenDark
                            )
                            Text(
                                text = "Yield/row: ${String.format(Locale.US, "%.1f", yieldPerRow)} kg/row",
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp,
                                color = FarmGreenDark
                            )
                        }
                    }
                }

                // Quality Rating
                Text("Fodder Quality / Maturity:", fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    qualityOptions.forEach { q ->
                        FilterChip(
                            selected = qualityRating == q,
                            onClick = { qualityRating = q },
                            label = { Text(q.take(15), fontSize = 10.sp) }
                        )
                    }
                }

                // Harvester & Labor Cost
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = harvesterName,
                        onValueChange = { harvesterName = it },
                        label = { Text("Harvester Name") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = laborCost,
                        onValueChange = { laborCost = it },
                        label = { Text("Labor Cost ($)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                }

                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Harvest Notes (e.g. Cut for morning ration)") },
                    modifier = Modifier.fillMaxWidth(),
                    maxLines = 2
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val weight = harvestedWeight.toDoubleOrNull()
                    if (selectedPlotId.isNotBlank() && weight != null && weight > 0) {
                        onSave(
                            selectedPlotId,
                            generatedRowCodes,
                            weight,
                            cuttingDate,
                            laborCost.toDoubleOrNull(),
                            harvesterName.trim().ifBlank { null },
                            qualityRating,
                            notes.trim().ifBlank { null }
                        )
                    }
                },
                enabled = harvestedWeight.toDoubleOrNull() != null && (harvestedWeight.toDoubleOrNull() ?: 0.0) > 0,
                colors = ButtonDefaults.buttonColors(containerColor = FarmGreenDark),
                modifier = Modifier.testTag("save_cutting_btn")
            ) {
                Text("Save Cutting")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

// ==========================================
// RECORD CROP ACTIVITY DIALOG (Requirement 5)
// ==========================================
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RecordCropActivityDialog(
    plots: List<FodderPlotEntity>,
    activityTypes: List<String>,
    onDismiss: () -> Unit,
    onSave: (
        plotId: String,
        rowCodes: String,
        activityType: String,
        date: String,
        quantity: Double?,
        unit: String?,
        labourHours: Double?,
        labourCost: Double?,
        materialCost: Double?,
        notes: String?
    ) -> Unit
) {
    var selectedPlotId by remember { mutableStateOf(plots.firstOrNull()?.id ?: "") }
    val selectedPlot = remember(selectedPlotId, plots) { plots.find { it.id == selectedPlotId } ?: plots.firstOrNull() }

    val defaultTypes = listOf(
        "Land preparation", "Seed purchase", "Slips purchase", "Labour", "Fertilizer",
        "Manure", "Irrigation", "Electricity", "Diesel / Fuel", "Machinery",
        "Harvest labour", "Transport", "Pest control", "Weeding", "Other inputs"
    )
    val effectiveTypes = remember(activityTypes) { (defaultTypes + activityTypes).distinct() }
    var selectedType by remember { mutableStateOf(effectiveTypes.first()) }
    var rowSelectionMode by remember { mutableStateOf("All Rows") } // "All Rows", "R01–R05", "Custom"
    var customRows by remember { mutableStateOf("R01–R05") }
    var activityDate by remember { mutableStateOf(SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())) }

    var quantityStr by remember { mutableStateOf("") }
    var unitStr by remember { mutableStateOf("kg") }
    var labourHoursStr by remember { mutableStateOf("2.0") }
    var labourCostStr by remember { mutableStateOf("0.0") }
    var materialCostStr by remember { mutableStateOf("0.0") }
    var notes by remember { mutableStateOf("") }

    var plotDropdownExpanded by remember { mutableStateOf(false) }
    var typeDropdownExpanded by remember { mutableStateOf(false) }

    val totalCost = (labourCostStr.toDoubleOrNull() ?: 0.0) + (materialCostStr.toDoubleOrNull() ?: 0.0)

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.EventNote, contentDescription = null, tint = FarmGreenDark)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Record Cultivation Expense / Activity", fontWeight = FontWeight.Bold)
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 500.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Accounting Note
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Color(0xFFF1F8E9),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "Cultivation expenses (seed, slips, labour, land prep, fertilizer, irrigation, diesel, electricity) automatically link to this field/crop and update Farm P&L.",
                        fontSize = 10.sp,
                        color = FarmGreenDark,
                        modifier = Modifier.padding(8.dp),
                        lineHeight = 14.sp
                    )
                }

                // Plot dropdown
                ExposedDropdownMenuBox(
                    expanded = plotDropdownExpanded,
                    onExpandedChange = { plotDropdownExpanded = !plotDropdownExpanded }
                ) {
                    OutlinedTextField(
                        value = selectedPlot?.plot_name ?: "Select Field",
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Field / Plot *") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = plotDropdownExpanded) },
                        modifier = Modifier.fillMaxWidth().menuAnchor()
                    )
                    ExposedDropdownMenu(
                        expanded = plotDropdownExpanded,
                        onDismissRequest = { plotDropdownExpanded = false }
                    ) {
                        plots.forEach { p ->
                            DropdownMenuItem(
                                text = { Text(p.plot_name) },
                                onClick = {
                                    selectedPlotId = p.id
                                    plotDropdownExpanded = false
                                }
                            )
                        }
                    }
                }

                // Activity Type Dropdown
                ExposedDropdownMenuBox(
                    expanded = typeDropdownExpanded,
                    onExpandedChange = { typeDropdownExpanded = !typeDropdownExpanded }
                ) {
                    OutlinedTextField(
                        value = selectedType,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Expense / Activity Type *") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = typeDropdownExpanded) },
                        modifier = Modifier.fillMaxWidth().menuAnchor()
                    )
                    ExposedDropdownMenu(
                        expanded = typeDropdownExpanded,
                        onDismissRequest = { typeDropdownExpanded = false }
                    ) {
                        effectiveTypes.forEach { t ->
                            DropdownMenuItem(
                                text = { Text(t) },
                                onClick = {
                                    selectedType = t
                                    typeDropdownExpanded = false
                                }
                            )
                        }
                    }
                }

                OutlinedTextField(
                    value = activityDate,
                    onValueChange = { activityDate = it },
                    label = { Text("Date") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                // Cost inputs
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = labourCostStr,
                        onValueChange = { labourCostStr = it },
                        label = { Text("Labour Cost (₹)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = materialCostStr,
                        onValueChange = { materialCostStr = it },
                        label = { Text("Material/Input (₹)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                }

                if (totalCost > 0.0) {
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = Color(0xFFFFF8E1),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Total Cultivation Expense:", fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = FarmBrown)
                            Text("₹${String.format(Locale.US, "%.2f", totalCost)}", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = FarmBrown)
                        }
                    }
                }

                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Activity / Invoice Notes") },
                    modifier = Modifier.fillMaxWidth(),
                    maxLines = 2
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val lc = labourCostStr.toDoubleOrNull() ?: 0.0
                    val mc = materialCostStr.toDoubleOrNull() ?: 0.0
                    val q = quantityStr.toDoubleOrNull()
                    val lh = labourHoursStr.toDoubleOrNull()

                    val targetRowDisplay = if (rowSelectionMode == "All Rows") "All Rows" else customRows

                    onSave(
                        selectedPlotId,
                        targetRowDisplay,
                        selectedType,
                        activityDate,
                        q,
                        unitStr.ifBlank { null },
                        lh,
                        lc,
                        mc,
                        notes.trim().ifBlank { null }
                    )
                },
                enabled = selectedPlotId.isNotBlank(),
                colors = ButtonDefaults.buttonColors(containerColor = FarmGreenDark),
                modifier = Modifier.testTag("save_activity_btn")
            ) {
                Text("Save Activity & Expense")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

// ==========================================
// RECORD PLANTING MATERIAL PURCHASE DIALOG (Requirement 6, 7, 8)
// ==========================================
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RecordMaterialPurchaseDialog(
    speciesList: List<FodderSpeciesEntity>,
    plots: List<FodderPlotEntity> = emptyList(),
    onDismiss: () -> Unit,
    onSave: (
        material: FodderPlantingMaterialEntity,
        plotId: String?,
        plotName: String?,
        cropCycleId: String?,
        paymentMode: String
    ) -> Unit
) {
    var materialType by remember { mutableStateOf("Slips") }
    var speciesName by remember { mutableStateOf(speciesList.firstOrNull()?.name ?: "Super Napier") }
    var variety by remember { mutableStateOf("Pakchong 1") }
    var quantity by remember { mutableStateOf("1000") }
    var unit by remember { mutableStateOf("slips") }
    var unitCost by remember { mutableStateOf("0.50") }
    var supplier by remember { mutableStateOf("Government Agronomy Centre") }
    var purchaseDate by remember { mutableStateOf(SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())) }
    var batchLotNumber by remember { mutableStateOf("LOT-2026-05") }
    var paymentMode by remember { mutableStateOf("Cash") } // Cash, UPI, Bank Transfer
    var notes by remember { mutableStateOf("") }

    var selectedPlotId by remember { mutableStateOf(plots.firstOrNull()?.id ?: "") }
    var selectedCropCycleName by remember { mutableStateOf("Cycle 1") }

    val materialTypes = listOf("Slips", "Rooted slips", "Seed", "Cuttings", "Transplants")
    val paymentModes = listOf("Cash", "UPI", "Bank Transfer")

    val q = quantity.toDoubleOrNull() ?: 0.0
    val uc = unitCost.toDoubleOrNull() ?: 0.0
    val totalCost = q * uc

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Inventory2, contentDescription = null, tint = FarmGreenDark)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Seed / Slip Purchase (Expense)", fontWeight = FontWeight.Bold)
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 500.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Accounting Rule Banner
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Color(0xFFF1F8E9),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "CRITICAL ACCOUNTING: Seed/slip purchase automatically records an EXPENSE transaction in Cash/Bank/UPI ledger and links to the field & cultivation cycle.",
                        fontSize = 10.sp,
                        color = FarmGreenDark,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.padding(8.dp),
                        lineHeight = 13.sp
                    )
                }

                // Field Linking
                if (plots.isNotEmpty()) {
                    Text("Destination Field / Plot *:", fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        plots.take(3).forEach { p ->
                            FilterChip(
                                selected = selectedPlotId == p.id,
                                onClick = {
                                    selectedPlotId = p.id
                                    speciesName = p.species_name
                                },
                                label = { Text(p.plot_name, fontSize = 10.sp) }
                            )
                        }
                    }
                }

                // Type chips
                Text("Material Type:", fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    materialTypes.forEach { t ->
                        FilterChip(
                            selected = materialType == t,
                            onClick = { materialType = t },
                            label = { Text(t, fontSize = 10.sp) }
                        )
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = speciesName,
                        onValueChange = { speciesName = it },
                        label = { Text("Species *") },
                        modifier = Modifier.weight(1.2f),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = variety,
                        onValueChange = { variety = it },
                        label = { Text("Variety") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = quantity,
                        onValueChange = { quantity = it },
                        label = { Text("Quantity *") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = unit,
                        onValueChange = { unit = it },
                        label = { Text("Unit") },
                        modifier = Modifier.weight(0.8f),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = unitCost,
                        onValueChange = { unitCost = it },
                        label = { Text("Cost/Unit (₹)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                }

                // Payment Mode Selection
                Text("Payment Mode *:", fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    paymentModes.forEach { mode ->
                        FilterChip(
                            selected = paymentMode == mode,
                            onClick = { paymentMode = mode },
                            label = { Text(mode, fontSize = 11.sp) },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                if (totalCost > 0.0) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = Color(0xFFFFF8E1),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Total Purchase Expense:", fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = FarmBrown)
                            Text("₹${String.format(Locale.US, "%.2f", totalCost)} ($paymentMode)", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = FarmBrown)
                        }
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = supplier,
                        onValueChange = { supplier = it },
                        label = { Text("Supplier / Nursery") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = batchLotNumber,
                        onValueChange = { batchLotNumber = it },
                        label = { Text("Batch / Lot #") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                }

                OutlinedTextField(
                    value = purchaseDate,
                    onValueChange = { purchaseDate = it },
                    label = { Text("Purchase Date") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val qNum = quantity.toDoubleOrNull() ?: 1.0
                    val ucNum = unitCost.toDoubleOrNull() ?: 0.0
                    val plot = plots.find { it.id == selectedPlotId }
                    onSave(
                        FodderPlantingMaterialEntity(
                            material_type = materialType,
                            species_name = speciesName,
                            variety = variety.trim().ifBlank { null },
                            quantity_purchased = qNum,
                            quantity_remaining = qNum,
                            unit = unit,
                            unit_cost = ucNum,
                            total_cost = qNum * ucNum,
                            supplier = supplier.trim().ifBlank { null },
                            purchase_date = purchaseDate,
                            batch_lot_number = batchLotNumber.trim().ifBlank { null },
                            notes = notes.trim().ifBlank { null }
                        ),
                        selectedPlotId.ifBlank { null },
                        plot?.plot_name,
                        selectedCropCycleName,
                        paymentMode
                    )
                },
                enabled = quantity.toDoubleOrNull() != null && speciesName.isNotBlank(),
                colors = ButtonDefaults.buttonColors(containerColor = FarmGreenDark),
                modifier = Modifier.testTag("save_material_btn")
            ) {
                Text("Confirm Purchase & Expense")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

// ==========================================
// RECORD DAILY FEEDING DIALOG (Requirement 12, 13)
// ==========================================
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RecordFeedingDialog(
    speciesList: List<FodderSpeciesEntity>,
    onDismiss: () -> Unit,
    onSave: (
        speciesId: String?,
        speciesName: String,
        targetGroup: String,
        goatsCount: Int,
        quantityFedKg: Double,
        feedingDate: String,
        feedingTime: String,
        chaffedMethod: String,
        wastageKg: Double,
        isPurchasedFodder: Boolean,
        notes: String?
    ) -> Unit
) {
    var selectedSpeciesName by remember { mutableStateOf(speciesList.firstOrNull()?.name ?: "Super Napier") }
    var selectedSpeciesId by remember { mutableStateOf(speciesList.firstOrNull()?.id) }
    var targetGroup by remember { mutableStateOf("All Does") }
    var goatsCount by remember { mutableStateOf("25") }
    var quantityFed by remember { mutableStateOf("") }
    var feedingDate by remember { mutableStateOf(SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())) }
    var feedingTime by remember { mutableStateOf("Morning") }
    var chaffedMethod by remember { mutableStateOf("Chaff Cut Machine") }
    var wastageKg by remember { mutableStateOf("5.0") }
    var isPurchasedFodder by remember { mutableStateOf(false) } // Home-Grown vs Purchased distinction
    var notes by remember { mutableStateOf("") }

    val targetGroups = listOf("All Does", "Bucks Shed", "Growing Kids", "Lactating Mothers", "Whole Herd")
    val timeOptions = listOf("Morning", "Afternoon", "Evening")

    val fedQty = quantityFed.toDoubleOrNull() ?: 0.0
    val estCostPerKg = if (isPurchasedFodder) 3.50 else 1.75
    val consumptionValue = fedQty * estCostPerKg

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Restaurant, contentDescription = null, tint = FarmGreenDark)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Record Fodder Feeding & Consumption", fontWeight = FontWeight.Bold)
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 500.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Home-Grown vs Purchased Fodder Toggle (Requirement 12)
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Color(0xFFF1F8E9),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("Fodder Source (Home-Grown vs Purchased):", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = FarmGreenDark)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            FilterChip(
                                selected = !isPurchasedFodder,
                                onClick = { isPurchasedFodder = false },
                                label = { Text("🌱 Home-Grown", fontSize = 11.sp) },
                                modifier = Modifier.weight(1f)
                            )
                            FilterChip(
                                selected = isPurchasedFodder,
                                onClick = { isPurchasedFodder = true },
                                label = { Text("🛒 Purchased", fontSize = 11.sp) },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }

                Text("Target Goat Herd:", fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    targetGroups.take(3).forEach { g ->
                        FilterChip(
                            selected = targetGroup == g,
                            onClick = { targetGroup = g },
                            label = { Text(g.take(12), fontSize = 10.sp) }
                        )
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = quantityFed,
                        onValueChange = { quantityFed = it },
                        label = { Text("Quantity Fed (kg) *") },
                        placeholder = { Text("e.g. 75") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.weight(1.2f).testTag("feeding_qty_input"),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = goatsCount,
                        onValueChange = { goatsCount = it },
                        label = { Text("Head Count") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(0.8f),
                        singleLine = true
                    )
                }

                // Consumption Cost Accounting Banner
                if (fedQty > 0.0) {
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = Color(0xFFE8F5E9),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Feed Consumption Value (Cost):",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = FarmGreenDark
                            )
                            Text(
                                text = "₹${String.format(Locale.US, "%.2f", consumptionValue)} (@ ₹${estCostPerKg}/kg)",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = FarmGreenDark
                            )
                        }
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = feedingDate,
                        onValueChange = { feedingDate = it },
                        label = { Text("Date") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = wastageKg,
                        onValueChange = { wastageKg = it },
                        label = { Text("Estimated Wastage (kg)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    timeOptions.forEach { t ->
                        FilterChip(
                            selected = feedingTime == t,
                            onClick = { feedingTime = t },
                            label = { Text(t, fontSize = 10.sp) }
                        )
                    }
                }

                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Notes (e.g. Mixed with dry bhusa)") },
                    modifier = Modifier.fillMaxWidth(),
                    maxLines = 2
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val qty = quantityFed.toDoubleOrNull()
                    if (qty != null && qty > 0) {
                        onSave(
                            selectedSpeciesId,
                            selectedSpeciesName,
                            targetGroup,
                            goatsCount.toIntOrNull() ?: 1,
                            qty,
                            feedingDate,
                            feedingTime,
                            chaffedMethod,
                            wastageKg.toDoubleOrNull() ?: 0.0,
                            isPurchasedFodder,
                            notes.trim().ifBlank { null }
                        )
                    }
                },
                enabled = quantityFed.toDoubleOrNull() != null,
                colors = ButtonDefaults.buttonColors(containerColor = FarmGreenDark),
                modifier = Modifier.testTag("save_feeding_btn")
            ) {
                Text("Save Feeding & Record Cost")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

// ==========================================
// RECORD PURCHASED FODDER STOCK DIALOG (Requirement 12)
// ==========================================
@Composable
fun RecordPurchasedFodderDialog(
    onDismiss: () -> Unit,
    onSave: (quantityKg: Double, costPerKg: Double, supplier: String, purchaseDate: String, paymentMode: String, notes: String?) -> Unit
) {
    var quantityKg by remember { mutableStateOf("500") }
    var costPerKg by remember { mutableStateOf("3.50") }
    var supplier by remember { mutableStateOf("Local Fodder Vendor") }
    var purchaseDate by remember { mutableStateOf(SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())) }
    var paymentMode by remember { mutableStateOf("Cash") }
    var notes by remember { mutableStateOf("") }

    val q = quantityKg.toDoubleOrNull() ?: 0.0
    val c = costPerKg.toDoubleOrNull() ?: 0.0
    val total = q * c

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.ShoppingCart, contentDescription = null, tint = FarmGreenDark)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Purchase Green Fodder Stock", fontWeight = FontWeight.Bold)
            }
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth().heightIn(max = 450.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text("Record purchased fodder intake (distinguished from home-grown harvest). Creates purchase expense and increases purchased stock.", fontSize = 11.sp, color = Color.Gray)

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = quantityKg,
                        onValueChange = { quantityKg = it },
                        label = { Text("Quantity (kg) *") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = costPerKg,
                        onValueChange = { costPerKg = it },
                        label = { Text("Cost / kg (₹) *") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                }

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Color(0xFFFFF8E1),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Total Purchase Outflow:", fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = FarmBrown)
                        Text("₹${String.format(Locale.US, "%.2f", total)}", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = FarmBrown)
                    }
                }

                OutlinedTextField(
                    value = supplier,
                    onValueChange = { supplier = it },
                    label = { Text("Supplier / Vendor") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    listOf("Cash", "UPI", "Bank Transfer").forEach { m ->
                        FilterChip(
                            selected = paymentMode == m,
                            onClick = { paymentMode = m },
                            label = { Text(m, fontSize = 11.sp) },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                OutlinedTextField(
                    value = purchaseDate,
                    onValueChange = { purchaseDate = it },
                    label = { Text("Purchase Date") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (q > 0 && c > 0) {
                        onSave(q, c, supplier, purchaseDate, paymentMode, notes.trim().ifBlank { null })
                    }
                },
                enabled = q > 0 && c > 0,
                colors = ButtonDefaults.buttonColors(containerColor = FarmGreenDark)
            ) {
                Text("Confirm Purchase")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

// ==========================================
// START CROP CYCLE DIALOG (Requirement 5)
// ==========================================
@Composable
fun StartCropCycleDialog(
    plots: List<FodderPlotEntity>,
    onDismiss: () -> Unit,
    onSave: (plotId: String, cycleName: String, speciesName: String, variety: String?, plantingDate: String, plantingMethod: String, notes: String?) -> Unit
) {
    var selectedPlotId by remember { mutableStateOf(plots.firstOrNull()?.id ?: "") }
    val selectedPlot = remember(selectedPlotId, plots) { plots.find { it.id == selectedPlotId } ?: plots.firstOrNull() }

    var cycleName by remember { mutableStateOf("Cycle 1") }
    var speciesName by remember { mutableStateOf(selectedPlot?.species_name ?: "Super Napier") }
    var variety by remember { mutableStateOf(selectedPlot?.variety ?: "Pakchong 1") }
    var plantingDate by remember { mutableStateOf(SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())) }
    var plantingMethod by remember { mutableStateOf("Rooted Slips") }
    var notes by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Recycling, contentDescription = null, tint = FarmGreenDark)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Start New Cultivation Cycle", fontWeight = FontWeight.Bold)
            }
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth().heightIn(max = 450.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text("Start an active cultivation cycle to track seeds, inputs, expenses, and harvests for cost-per-kg calculation.", fontSize = 11.sp, color = Color.Gray)

                if (plots.isNotEmpty()) {
                    Text("Select Field / Plot *:", fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        plots.take(3).forEach { p ->
                            FilterChip(
                                selected = selectedPlotId == p.id,
                                onClick = {
                                    selectedPlotId = p.id
                                    speciesName = p.species_name
                                    variety = p.variety ?: ""
                                },
                                label = { Text(p.plot_name, fontSize = 10.sp) }
                            )
                        }
                    }
                }

                OutlinedTextField(
                    value = cycleName,
                    onValueChange = { cycleName = it },
                    label = { Text("Cycle Name *") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = speciesName,
                        onValueChange = { speciesName = it },
                        label = { Text("Species *") },
                        modifier = Modifier.weight(1.2f),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = plantingMethod,
                        onValueChange = { plantingMethod = it },
                        label = { Text("Method") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                }

                OutlinedTextField(
                    value = plantingDate,
                    onValueChange = { plantingDate = it },
                    label = { Text("Planting Date") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (selectedPlotId.isNotBlank() && cycleName.isNotBlank()) {
                        onSave(selectedPlotId, cycleName, speciesName, variety.ifBlank { null }, plantingDate, plantingMethod, notes.ifBlank { null })
                    }
                },
                enabled = selectedPlotId.isNotBlank() && cycleName.isNotBlank(),
                colors = ButtonDefaults.buttonColors(containerColor = FarmGreenDark)
            ) {
                Text("Start Cycle")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

// ==========================================
// HISTORY ITEM ROWS
// ==========================================
@Composable
fun CuttingHistoryItemRow(
    cutting: FodderCuttingEntity,
    onDelete: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "${cutting.plot_name} • Cut #${cutting.cut_number}",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = FarmGreenDark
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Surface(
                            shape = RoundedCornerShape(4.dp),
                            color = FarmGreenContainer
                        ) {
                            Text(
                                text = cutting.row_codes,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = FarmGreenDark,
                                modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp)
                            )
                        }
                    }
                    Text(
                        text = "Harvested: ${cutting.cutting_date} • ${cutting.species_name}",
                        fontSize = 11.sp,
                        color = Color.Gray
                    )
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = "${cutting.harvested_weight_kg.toInt()} kg",
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        color = FarmGreenDark
                    )
                    Text(
                        text = "${cutting.rows_harvested_count} rows • ${cutting.total_harvested_row_length_m.toInt()}m",
                        fontSize = 10.sp,
                        color = Color.Gray
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Yield metrics strip
            Surface(
                shape = RoundedCornerShape(6.dp),
                color = Color(0xFFF9FBF9),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Yield/m: ${String.format(Locale.US, "%.2f", cutting.yield_per_metre)} kg/m", fontSize = 10.sp, color = Color.DarkGray)
                    Text("Yield/row: ${String.format(Locale.US, "%.1f", cutting.yield_per_row)} kg", fontSize = 10.sp, color = Color.DarkGray)
                    if (!cutting.weather_summary.isNullOrBlank()) {
                        Text("☁ ${cutting.weather_summary}", fontSize = 10.sp, color = Color.Gray)
                    }
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Quality: ${cutting.quality_rating}${if (!cutting.harvester_name.isNullOrBlank()) " • By ${cutting.harvester_name}" else ""}",
                    fontSize = 10.sp,
                    color = Color.Gray
                )
                IconButton(onClick = onDelete, modifier = Modifier.size(28.dp)) {
                    Icon(Icons.Default.Delete, contentDescription = "Delete", tint = FarmError, modifier = Modifier.size(15.dp))
                }
            }
        }
    }
}

@Composable
fun CropActivityItemRow(
    activity: FodderActivityEntity,
    onDelete: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = activity.activity_type,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = FarmGreenDark
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Surface(
                            shape = RoundedCornerShape(4.dp),
                            color = Color(0xFFF1F8E9)
                        ) {
                            Text(
                                text = activity.row_codes,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = FarmGreenDark,
                                modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp)
                            )
                        }
                    }
                    Text(
                        text = "${activity.plot_name} • ${activity.activity_date}",
                        fontSize = 11.sp,
                        color = Color.Gray
                    )
                }

                if (activity.total_cost > 0) {
                    Text(
                        text = com.example.util.CurrencyUtils.formatInr(activity.total_cost),
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = FarmBrown
                    )
                }
            }

            if (!activity.notes.isNullOrBlank()) {
                Text(
                    text = activity.notes,
                    fontSize = 10.sp,
                    color = Color.DarkGray,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }
        }
    }
}

@Composable
fun PlantingMaterialItemRow(
    material: FodderPlantingMaterialEntity,
    onDelete: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "${material.material_type} — ${material.species_name}",
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = FarmGreenDark
                )
                Text(
                    text = "Purchased: ${material.quantity_purchased.toInt()} ${material.unit} • Remaining: ${material.quantity_remaining.toInt()} ${material.unit}",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = Color.DarkGray
                )
                if (!material.supplier.isNullOrBlank()) {
                    Text("Source: ${material.supplier}", fontSize = 10.sp, color = Color.Gray)
                }
            }

            IconButton(onClick = onDelete, modifier = Modifier.size(28.dp)) {
                Icon(Icons.Default.Delete, contentDescription = "Delete", tint = FarmError, modifier = Modifier.size(15.dp))
            }
        }
    }
}

@Composable
fun FeedingHistoryItemRow(
    feeding: FodderFeedingEntity,
    onDelete: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text(
                    text = "${feeding.target_group} (${feeding.goats_count} goats)",
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = FarmBrown
                )
                Text(
                    text = "${feeding.feeding_date} (${feeding.feeding_time}) • ${feeding.species_name}",
                    fontSize = 11.sp,
                    color = Color.Gray
                )
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = "${feeding.quantity_fed_kg.toInt()} kg",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = FarmBrown
                    )
                    if (feeding.wastage_kg > 0) {
                        Text(
                            text = "waste: ${feeding.wastage_kg.toInt()} kg",
                            fontSize = 10.sp,
                            color = FarmWarning
                        )
                    }
                }
                Spacer(modifier = Modifier.width(8.dp))
                IconButton(onClick = onDelete, modifier = Modifier.size(28.dp)) {
                    Icon(Icons.Default.Delete, contentDescription = "Delete", tint = FarmError, modifier = Modifier.size(15.dp))
                }
            }
        }
    }
}
