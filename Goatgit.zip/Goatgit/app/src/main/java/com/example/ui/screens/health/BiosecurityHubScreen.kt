package com.example.ui.screens.health

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.supabase.Goat
import com.example.data.supabase.GoatRepository
import com.example.data.supabase.InsurancePolicy
import com.example.data.supabase.MortalityEvent
import com.example.data.supabase.QuarantineRecord
import com.example.i18n.t
import com.example.ui.components.FarmBottomNavigation
import com.example.ui.components.FarmTopBar
import com.example.ui.screens.insurance.LivestockInsuranceScreen
import com.example.ui.screens.mortality.MortalityManagementScreen
import com.example.ui.theme.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
private fun BiosecurityKpiChip(
    title: String,
    value: String,
    icon: ImageVector,
    color: Color,
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null
) {
    Surface(
        color = color.copy(alpha = 0.08f),
        shape = RoundedCornerShape(10.dp),
        border = BorderStroke(1.dp, color.copy(alpha = 0.25f)),
        modifier = modifier.then(if (onClick != null) Modifier.clickable { onClick() } else Modifier)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = color,
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Column {
                Text(
                    text = value,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = color
                )
                Text(
                    text = title,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Medium,
                    color = Color.DarkGray,
                    maxLines = 1
                )
            }
        }
    }
}

/**
 * Consolidated Biosecurity, Mortality & Insurance Hub Screen:
 * Subtab 0: Quarantine (Isolation pens & release checklists)
 * Subtab 1: Mortality (Death records, root cause analysis & losses)
 * Subtab 2: Insurance (Policies, claim submissions & renewals)
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BiosecurityHubScreen(
    repository: GoatRepository,
    initialTab: Int = 0,
    initialGoatId: String? = null,
    onNavigateBack: () -> Unit,
    onNavigateToVaccination: (String) -> Unit = {},
    onNavigateToDeworming: (String) -> Unit = {},
    onNavigateToTreatment: (String) -> Unit = {},
    onNavigateToDashboard: () -> Unit = {},
    onNavigateToGoats: () -> Unit = {},
    onNavigateToBreeding: () -> Unit = {},
    onNavigateToSales: () -> Unit = {},
    onNavigateToTasks: () -> Unit = {},
    onNavigateToAiEntry: () -> Unit = {}
) {
    BackHandler { onNavigateBack() }

    var selectedTab by remember(initialTab) { mutableIntStateOf(initialTab.coerceIn(0, 2)) }

    val coroutineScope = rememberCoroutineScope()
    val dateFormat = remember { SimpleDateFormat("yyyy-MM-dd", Locale.US) }
    val today = remember { dateFormat.format(Date()) }
    val currentMonth = today.take(7)

    var quarantineRecords by remember { mutableStateOf<List<QuarantineRecord>>(emptyList()) }
    var mortalities by remember { mutableStateOf<List<MortalityEvent>>(emptyList()) }
    var policies by remember { mutableStateOf<List<InsurancePolicy>>(emptyList()) }
    var goats by remember { mutableStateOf<List<Goat>>(emptyList()) }
    var refreshKey by remember { mutableIntStateOf(0) }

    fun loadSummaryData() {
        coroutineScope.launch {
            val qRes = repository.getQuarantineRecords()
            if (qRes.isSuccess) quarantineRecords = qRes.getOrThrow()

            val mRes = repository.insurance.getMortalityEvents()
            if (mRes.isSuccess) mortalities = mRes.getOrThrow()

            val pRes = repository.insurance.getPolicies()
            if (pRes.isSuccess) policies = pRes.getOrThrow()

            val gRes = repository.getGoats()
            if (gRes.isSuccess) goats = gRes.getOrThrow()
        }
    }

    LaunchedEffect(refreshKey) {
        loadSummaryData()
    }

    val activeQuarantinedCount = remember(quarantineRecords) {
        quarantineRecords.count { it.status == "QUARANTINE" || it.status == "EXTENDED" }
    }
    val monthlyMortalityCount = remember(mortalities, currentMonth) {
        mortalities.count { it.death_date.startsWith(currentMonth) }
    }
    val activePoliciesCount = remember(policies) {
        policies.count { it.isActive }
    }
    val expiringPolicies = remember(policies, today) {
        policies.filter { p ->
            p.isActive && try {
                val exp = dateFormat.parse(p.expiry_date)
                val curr = dateFormat.parse(today)
                if (exp != null && curr != null) {
                    val diffDays = ((exp.time - curr.time) / (1000 * 60 * 60 * 24)).toInt()
                    diffDays in 0..30
                } else false
            } catch (e: Exception) {
                p.isExpiringSoon
            }
        }
    }

    Scaffold(
        topBar = {
            FarmTopBar(
                title = t("biosecurity.hub_title"),
                canNavigateBack = true,
                onNavigateBack = onNavigateBack,
                actions = {
                    IconButton(
                        onClick = { refreshKey++ },
                        modifier = Modifier.testTag("btn_topbar_biosecurity_refresh")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = "Refresh Data",
                            tint = Color.White
                        )
                    }
                }
            )
        },
        bottomBar = {
            FarmBottomNavigation(
                currentRoute = "biosecurity_hub",
                onNavigateToDashboard = onNavigateToDashboard,
                onNavigateToGoats = onNavigateToGoats,
                onNavigateToBreeding = onNavigateToBreeding,
                onNavigateToSales = onNavigateToSales,
                onNavigateToTasks = onNavigateToTasks,
                onNavigateToAiEntry = onNavigateToAiEntry
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(FarmBackgroundLight)
                .padding(paddingValues)
        ) {
            // 30-Day Insurance Expiration Urgent Alert Banner
            if (expiringPolicies.isNotEmpty()) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = Color(0xFFFEF2F2),
                    border = BorderStroke(1.5.dp, Color(0xFFEF4444)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 8.dp)
                        .clickable { selectedTab = 2 }
                        .testTag("banner_biosecurity_insurance_expiring")
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(34.dp)
                                .background(Color(0xFFFEE2E2), RoundedCornerShape(8.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Warning,
                                contentDescription = "Expiring Insurance",
                                tint = Color(0xFFDC2626),
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "⚠️ Urgent: ${expiringPolicies.size} Insurance ${if (expiringPolicies.size == 1) "Policy" else "Policies"} Expiring Within 30 Days",
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.5.sp,
                                color = Color(0xFFB91C1C)
                            )
                            Text(
                                text = "Tap to view policies and process renewals before coverage lapses.",
                                fontSize = 11.sp,
                                color = Color(0xFF7F1D1D)
                            )
                        }
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = Color(0xFFDC2626)
                        ) {
                            Text(
                                text = "Review",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }
                }
            }

            // Three primary subtabs in requested order: Quarantine, Mortality, Insurance
            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = Color.White,
                contentColor = FarmGreenDark,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("biosecurity_hub_tab_row")
            ) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = {
                        Text(
                            text = t("biosecurity.tab_quarantine"),
                            fontWeight = if (selectedTab == 0) FontWeight.Bold else FontWeight.Normal,
                            fontSize = 13.sp
                        )
                    },
                    icon = {
                        BadgedBox(
                            badge = {
                                if (activeQuarantinedCount > 0) {
                                    Badge(
                                        containerColor = Color(0xFFD97706),
                                        contentColor = Color.White
                                    ) {
                                        Text("$activeQuarantinedCount")
                                    }
                                }
                            }
                        ) {
                            Icon(Icons.Default.Security, contentDescription = null, modifier = Modifier.size(18.dp))
                        }
                    },
                    modifier = Modifier.testTag("tab_biosecurity_quarantine")
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = {
                        Text(
                            text = t("biosecurity.tab_mortality"),
                            fontWeight = if (selectedTab == 1) FontWeight.Bold else FontWeight.Normal,
                            fontSize = 13.sp
                        )
                    },
                    icon = {
                        BadgedBox(
                            badge = {
                                if (monthlyMortalityCount > 0) {
                                    Badge(
                                        containerColor = Color(0xFFD32F2F),
                                        contentColor = Color.White
                                    ) {
                                        Text("$monthlyMortalityCount")
                                    }
                                }
                            }
                        ) {
                            Icon(Icons.Default.WarningAmber, contentDescription = null, modifier = Modifier.size(18.dp))
                        }
                    },
                    modifier = Modifier.testTag("tab_biosecurity_mortality")
                )
                Tab(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    text = {
                        Text(
                            text = t("biosecurity.tab_insurance"),
                            fontWeight = if (selectedTab == 2) FontWeight.Bold else FontWeight.Normal,
                            fontSize = 13.sp
                        )
                    },
                    icon = {
                        BadgedBox(
                            badge = {
                                if (expiringPolicies.isNotEmpty()) {
                                    Badge(
                                        containerColor = Color(0xFFDC2626),
                                        contentColor = Color.White
                                    ) {
                                        Text("${expiringPolicies.size}")
                                    }
                                } else if (activePoliciesCount > 0) {
                                    Badge(
                                        containerColor = Color(0xFF1976D2),
                                        contentColor = Color.White
                                    ) {
                                        Text("$activePoliciesCount")
                                    }
                                }
                            }
                        ) {
                            Icon(Icons.Default.VerifiedUser, contentDescription = null, modifier = Modifier.size(18.dp))
                        }
                    },
                    modifier = Modifier.testTag("tab_biosecurity_insurance")
                )
            }

            // Quick KPI Banner across the 3 domains
            Surface(
                color = Color.White,
                shadowElevation = 1.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    BiosecurityKpiChip(
                        title = t("biosecurity.tab_quarantine"),
                        value = "$activeQuarantinedCount Active",
                        icon = Icons.Default.Shield,
                        color = Color(0xFFD97706),
                        modifier = Modifier.weight(1f),
                        onClick = { selectedTab = 0 }
                    )
                    BiosecurityKpiChip(
                        title = t("biosecurity.month_mortality"),
                        value = "$monthlyMortalityCount Deaths",
                        icon = Icons.Default.WarningAmber,
                        color = Color(0xFFD32F2F),
                        modifier = Modifier.weight(1f),
                        onClick = { selectedTab = 1 }
                    )
                    BiosecurityKpiChip(
                        title = t("biosecurity.tab_insurance"),
                        value = "$activePoliciesCount Policies",
                        icon = Icons.Default.VerifiedUser,
                        color = Color(0xFF1976D2),
                        modifier = Modifier.weight(1f),
                        onClick = { selectedTab = 2 }
                    )
                }
            }

            // Body content corresponding to the selected subtab
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .weight(1f)
            ) {
                key(selectedTab, refreshKey) {
                    when (selectedTab) {
                        0 -> {
                            QuarantineScreen(
                                repository = repository,
                                initialGoatId = initialGoatId,
                                onNavigateBack = onNavigateBack,
                                onNavigateToVaccination = onNavigateToVaccination,
                                onNavigateToDeworming = onNavigateToDeworming,
                                onNavigateToTreatment = onNavigateToTreatment,
                                showTopBar = false
                            )
                        }
                        1 -> {
                            MortalityManagementScreen(
                                repository = repository,
                                onNavigateBack = onNavigateBack,
                                onNavigateToInsurance = { selectedTab = 2 },
                                showTopBar = false
                            )
                        }
                        2 -> {
                            LivestockInsuranceScreen(
                                repository = repository,
                                initialGoatId = initialGoatId,
                                onNavigateBack = onNavigateBack,
                                onNavigateToMortality = { selectedTab = 1 },
                                showTopBar = false
                            )
                        }
                    }
                }
            }
        }
    }
}
