package com.example.ui.screens

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.supabase.*
import com.example.ui.components.DatePickerField
import com.example.ui.theme.*
import com.example.util.CurrencyUtils
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VaccinationScreen(
    repository: GoatRepository,
    initialGoatId: String? = null,
    onNavigateBack: () -> Unit,
    onVaccinationSaved: () -> Unit = {}
) {
    BackHandler { onNavigateBack() }

    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val dateFormat = remember { SimpleDateFormat("yyyy-MM-dd", Locale.US) }
    val today = remember { dateFormat.format(Date()) }

    var selectedTab by remember { mutableIntStateOf(0) } // 0: Upcoming, 1: Due Today, 2: Overdue, 3: Completed, 4: TANUVAS Schedule
    var vaccinations by remember { mutableStateOf<List<VaccinationRecord>>(emptyList()) }
    var schedules by remember { mutableStateOf<List<VaccinationSchedule>>(emptyList()) }
    var goats by remember { mutableStateOf<List<Goat>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }

    var showRecordDialog by remember { mutableStateOf(false) }
    var showScheduleDialog by remember { mutableStateOf(false) }
    var showEditScheduleDialog by remember { mutableStateOf<VaccinationSchedule?>(null) }

    fun loadData() {
        isLoading = true
        coroutineScope.launch {
            repository.seedTanuvasSchedulesIfEmpty()
            val vacRes = repository.getVaccinations()
            if (vacRes.isSuccess) vaccinations = vacRes.getOrThrow()

            val schRes = repository.getVaccinationSchedules()
            if (schRes.isSuccess) schedules = schRes.getOrThrow()

            val gRes = repository.getGoats()
            if (gRes.isSuccess) goats = gRes.getOrThrow()

            isLoading = false
        }
    }

    LaunchedEffect(Unit) {
        loadData()
        if (initialGoatId != null) {
            showRecordDialog = true
        }
    }

    // Due calculations
    val todayDate = remember(today) { dateFormat.parse(today) ?: Date() }
    val goatsMap = remember(goats) { goats.associateBy { it.id } }

    val recordsWithDue = remember(vaccinations) {
        vaccinations.filter { !it.next_due_date_c.isNullOrBlank() }
    }

    val dueToday = remember(recordsWithDue, today) {
        recordsWithDue.filter { it.next_due_date_c == today }
    }

    val overdue = remember(recordsWithDue, todayDate) {
        recordsWithDue.filter { rec ->
            try {
                val d = dateFormat.parse(rec.next_due_date_c!!)
                d != null && d.before(todayDate) && rec.next_due_date_c != today
            } catch (_: Exception) { false }
        }
    }

    val upcoming = remember(recordsWithDue, todayDate) {
        recordsWithDue.filter { rec ->
            try {
                val d = dateFormat.parse(rec.next_due_date_c!!)
                d != null && d.after(todayDate)
            } catch (_: Exception) { false }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "Vaccination Management",
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp
                        )
                        Text(
                            text = "Upcoming, Overdue, Batch Entry & TANUVAS Schedule",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack, modifier = Modifier.testTag("vaccination_btn_back")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(onClick = { showScheduleDialog = true }) {
                        Icon(Icons.Default.CalendarToday, contentDescription = "Schedule")
                    }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showRecordDialog = true },
                containerColor = FarmGreenDark,
                contentColor = Color.White,
                modifier = Modifier.testTag("btn_add_vaccination")
            ) {
                Row(modifier = Modifier.padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Add, contentDescription = null)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Record Vaccination", fontWeight = FontWeight.Bold)
                }
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(Color(0xFFF8FAFC))
        ) {
            // Scrollable Tab Row (Requirement 2)
            ScrollableTabRow(
                selectedTabIndex = selectedTab,
                edgePadding = 12.dp,
                containerColor = Color.White
            ) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = {
                        Text("Upcoming (${upcoming.size})", fontWeight = FontWeight.Bold)
                    }
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = {
                        Text("Due Today (${dueToday.size})", fontWeight = FontWeight.Bold, color = if (dueToday.isNotEmpty()) Color(0xFFD97706) else Color.Unspecified)
                    }
                )
                Tab(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    text = {
                        Text("Overdue (${overdue.size})", fontWeight = FontWeight.Bold, color = if (overdue.isNotEmpty()) Color(0xFFDC2626) else Color.Unspecified)
                    }
                )
                Tab(
                    selected = selectedTab == 3,
                    onClick = { selectedTab = 3 },
                    text = { Text("Completed (${vaccinations.size})", fontWeight = FontWeight.Bold) }
                )
                Tab(
                    selected = selectedTab == 4,
                    onClick = { selectedTab = 4 },
                    text = { Text("TANUVAS Schedule", fontWeight = FontWeight.Bold, color = Color(0xFF1D4ED8)) }
                )
            }

            if (isLoading) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = FarmGreenPrimary)
                }
            } else {
                when (selectedTab) {
                    0 -> VaccinationRecordsList(records = upcoming, goatsMap = goatsMap, label = "Upcoming Vaccinations", onRecordClick = { showRecordDialog = true })
                    1 -> VaccinationRecordsList(records = dueToday, goatsMap = goatsMap, label = "Vaccinations Due Today", onRecordClick = { showRecordDialog = true })
                    2 -> VaccinationRecordsList(records = overdue, goatsMap = goatsMap, label = "Overdue Vaccinations", onRecordClick = { showRecordDialog = true })
                    3 -> VaccinationRecordsList(records = vaccinations, goatsMap = goatsMap, label = "All Completed Records", onRecordClick = { showRecordDialog = true })
                    4 -> TanuvasVaccinationScheduleView(
                        schedules = schedules,
                        onEditSchedule = { showEditScheduleDialog = it }
                    )
                }
            }
        }
    }

    // Record Vaccination Dialog with Drug Types and Automated Booster Reminders
    if (showRecordDialog) {
        com.example.ui.screens.health.VaccinationRecordDialog(
            goats = goats,
            initialGoatId = initialGoatId,
            today = today,
            onDismiss = { showRecordDialog = false },
            onSaveSuccess = {
                showRecordDialog = false
                loadData()
                onVaccinationSaved()
            },
            repository = repository
        )
    }

    // Schedule Future Vaccination Dialog
    if (showScheduleDialog) {
        ScheduleVaccinationReminderDialog(
            goats = goats,
            schedules = schedules,
            today = today,
            onDismiss = { showScheduleDialog = false },
            onSave = { records ->
                coroutineScope.launch {
                    val res = repository.recordVaccinationsForGoats(records, totalCost = null)
                    showScheduleDialog = false
                    if (res.isSuccess) {
                        Toast.makeText(context, "Scheduled reminders for ${records.size} goat(s)!", Toast.LENGTH_SHORT).show()
                        loadData()
                    }
                }
            }
        )
    }

    // Edit Schedule Dialog (Requirement 3)
    showEditScheduleDialog?.let { targetSchedule ->
        EditVaccinationScheduleDialog(
            schedule = targetSchedule,
            onDismiss = { showEditScheduleDialog = null },
            onSave = { updated ->
                coroutineScope.launch {
                    repository.saveVaccinationSchedule(updated)
                    showEditScheduleDialog = null
                    loadData()
                }
            }
        )
    }
}

@Composable
private fun VaccinationRecordsList(
    records: List<VaccinationRecord>,
    goatsMap: Map<String, Goat>,
    label: String,
    onRecordClick: () -> Unit
) {
    if (records.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(Icons.Default.CheckCircle, contentDescription = null, tint = FarmGreenDark, modifier = Modifier.size(48.dp))
                Text("No records in this category", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Text("Tap + to record new vaccinations or configure reminders.", fontSize = 12.sp, color = Color.Gray)
            }
        }
    } else {
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(horizontal = 14.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                Text(label, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.Gray, modifier = Modifier.padding(vertical = 4.dp))
            }
            items(records) { rec ->
                VaccinationCardItem(record = rec, goat = goatsMap[rec.goat_id_c])
            }
            item {
                Spacer(modifier = Modifier.height(72.dp))
            }
        }
    }
}

@Composable
private fun VaccinationCardItem(record: VaccinationRecord, goat: Goat?) {
    val dateFormat = remember { SimpleDateFormat("yyyy-MM-dd", Locale.US) }
    val today = remember { dateFormat.format(Date()) }
    val todayDate = remember(today) { dateFormat.parse(today) ?: Date() }

    val dueText: String
    val dueColor: Color
    val isOverdue: Boolean

    if (!record.next_due_date_c.isNullOrBlank()) {
        val d = try { dateFormat.parse(record.next_due_date_c) } catch (_: Exception) { null }
        if (d != null) {
            val diffDays = ((d.time - todayDate.time) / (1000 * 60 * 60 * 24)).toInt()
            when {
                diffDays < 0 -> {
                    dueText = "OVERDUE BY ${-diffDays} DAYS"
                    dueColor = Color(0xFFDC2626)
                    isOverdue = true
                }
                diffDays == 0 -> {
                    dueText = "DUE TODAY"
                    dueColor = Color(0xFFD97706)
                    isOverdue = false
                }
                else -> {
                    dueText = "DUE IN $diffDays DAYS"
                    dueColor = Color(0xFF0284C7)
                    isOverdue = false
                }
            }
        } else {
            dueText = "Next Due: ${record.next_due_date_c}"
            dueColor = Color.DarkGray
            isOverdue = false
        }
    } else {
        dueText = "No booster scheduled"
        dueColor = Color.Gray
        isOverdue = false
    }

    Card(
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(12.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(34.dp)
                            .clip(CircleShape)
                            .background(Color(0xFFE0F2FE)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.Vaccines, contentDescription = null, tint = Color(0xFF0284C7), modifier = Modifier.size(18.dp))
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(record.vaccine_c, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text("Goat: ${goat?.tag_c ?: "Goat"} (${goat?.name ?: ""})", fontSize = 11.sp, color = Color.Gray)
                    }
                }

                Surface(
                    color = dueColor.copy(alpha = 0.12f),
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text(
                        text = dueText,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = dueColor,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            HorizontalDivider(color = Color(0xFFF1F5F9))

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Administered: ${record.administered_date_c}", fontSize = 11.sp, color = Color.DarkGray)
                Text("Dose: ${record.dose_c}", fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
            }

            if (!record.batch_number_c.isNullOrBlank() || !record.administered_by_c.isNullOrBlank()) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    if (!record.batch_number_c.isNullOrBlank()) Text("Batch: ${record.batch_number_c}", fontSize = 10.sp, color = Color.Gray)
                    if (!record.administered_by_c.isNullOrBlank()) Text("Vet: ${record.administered_by_c}", fontSize = 10.sp, color = Color.Gray)
                }
            }

            if (!record.notes_c.isNullOrBlank()) {
                Text(record.notes_c, fontSize = 11.sp, color = Color.DarkGray)
            }
        }
    }
}

@Composable
private fun TanuvasVaccinationScheduleView(
    schedules: List<VaccinationSchedule>,
    onEditSchedule: (VaccinationSchedule) -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Surface(
                color = Color(0xFFEFF6FF),
                shape = RoundedCornerShape(12.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFBFDBFE)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Verified, contentDescription = null, tint = Color(0xFF1D4ED8), modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("TANUVAS Reference Schedule", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color(0xFF1E40AF))
                    }
                    Text(
                        text = "Source: Tamil Nadu Veterinary and Animal Sciences University (TANUVAS) Goat Farm Protocol. Confirm timing, endemic disease profiles, and booster intervals with your veterinarian or local animal-health authority. This reference is configurable.",
                        fontSize = 11.sp,
                        color = Color(0xFF334155),
                        lineHeight = 15.sp
                    )
                }
            }
        }

        items(schedules) { sch ->
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(12.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(sch.name, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color(0xFF1E293B))
                            Text("Disease: ${sch.disease} • Species: ${sch.species}", fontSize = 11.sp, color = Color.Gray)
                        }

                        IconButton(onClick = { onEditSchedule(sch) }) {
                            Icon(Icons.Default.Edit, contentDescription = "Edit Schedule", tint = Color.Gray, modifier = Modifier.size(18.dp))
                        }
                    }

                    HorizontalDivider(color = Color(0xFFF1F5F9))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text("Recommended Age", fontSize = 10.sp, color = Color.Gray)
                            Text(sch.recommended_age, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("Interval / Frequency", fontSize = 10.sp, color = Color.Gray)
                            Text(sch.recommended_interval, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFF1D4ED8))
                        }
                    }

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text("Standard Dose & Route", fontSize = 10.sp, color = Color.Gray)
                            Text(sch.dose_reference, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("Source", fontSize = 10.sp, color = Color.Gray)
                            Text(sch.source, fontSize = 11.sp, color = Color.DarkGray)
                        }
                    }

                    if (!sch.notes.isNullOrBlank()) {
                        Surface(color = Color(0xFFF8FAFC), shape = RoundedCornerShape(6.dp), modifier = Modifier.fillMaxWidth()) {
                            Text(sch.notes, fontSize = 11.sp, color = Color(0xFF475569), modifier = Modifier.padding(8.dp))
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(72.dp))
        }
    }
}

// Dialog for recording vaccination (Requirement 2 & 4)
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun RecordVaccinationDialog(
    goats: List<Goat>,
    schedules: List<VaccinationSchedule>,
    initialGoatId: String?,
    today: String,
    onDismiss: () -> Unit,
    onSave: (List<VaccinationRecord>, cost: Double?, diseaseName: String) -> Unit
) {
    val activeGoats = remember(goats) { goats.filter { !it.status_c.equals("Deceased", ignoreCase = true) } }

    var selectionMode by remember { mutableStateOf(if (initialGoatId != null) "INDIVIDUAL" else "INDIVIDUAL") }
    var singleGoatId by remember { mutableStateOf(initialGoatId ?: activeGoats.firstOrNull()?.id ?: "") }
    var singleGoatExpanded by remember { mutableStateOf(false) }
    val multipleSelectedIds = remember { mutableStateListOf<String>().apply { if (initialGoatId != null) add(initialGoatId) } }

    // Schedule selection
    var selectedSchedule by remember { mutableStateOf(schedules.firstOrNull()) }
    var scheduleExpanded by remember { mutableStateOf(false) }

    var vaccineName by remember { mutableStateOf(selectedSchedule?.vaccine_name ?: "PPR Vaccine") }
    var diseaseName by remember { mutableStateOf(selectedSchedule?.disease ?: "PPR") }
    var dose by remember { mutableStateOf(selectedSchedule?.dose_reference ?: "1 ml Subcutaneously (S/C)") }
    var route by remember { mutableStateOf("Subcutaneous (S/C)") }
    var administeredDate by remember { mutableStateOf(today) }

    // Auto calculate next due date from schedule
    var nextDueDate by remember {
        val cal = Calendar.getInstance()
        cal.add(Calendar.YEAR, 1)
        mutableStateOf(SimpleDateFormat("yyyy-MM-dd", Locale.US).format(cal.time))
    }

    var batchNumber by remember { mutableStateOf("") }
    var expiryDate by remember { mutableStateOf("") }
    var manufacturer by remember { mutableStateOf("") }
    var veterinarian by remember { mutableStateOf("") }
    var totalCostStr by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }
    var attachmentNote by remember { mutableStateOf("") }

    val coveredGoats = remember(selectionMode, singleGoatId, multipleSelectedIds.toList(), activeGoats) {
        when (selectionMode) {
            "INDIVIDUAL" -> activeGoats.filter { it.id == singleGoatId }
            "MULTIPLE" -> activeGoats.filter { multipleSelectedIds.contains(it.id) }
            "ALL_HERD" -> activeGoats
            "DOES" -> activeGoats.filter { it.sex_c.equals("Doe", ignoreCase = true) }
            "BUCKS" -> activeGoats.filter { it.sex_c.equals("Buck", ignoreCase = true) }
            "KIDS" -> activeGoats.filter { it.sex_c.equals("Kid", ignoreCase = true) || it.tag_c.contains("K", ignoreCase = true) }
            else -> activeGoats.filter { it.id == singleGoatId }
        }
    }

    Dialog(onDismissRequest = onDismiss) {
        Surface(shape = RoundedCornerShape(16.dp), color = Color.White, modifier = Modifier.fillMaxWidth().fillMaxHeight(0.92f)) {
            LazyColumn(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                item {
                    Text("Record Vaccination", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = FarmGreenDark)
                    Text("Administer to individual animal or herd cohort with automatic next-due calculation.", fontSize = 11.sp, color = Color.Gray)
                }

                // 1. Reference Schedule Selection (Requirement 3 & 4)
                item {
                    ExposedDropdownMenuBox(expanded = scheduleExpanded, onExpandedChange = { scheduleExpanded = !scheduleExpanded }) {
                        OutlinedTextField(
                            value = selectedSchedule?.name ?: "Select Schedule",
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("TANUVAS Reference Protocol *") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = scheduleExpanded) },
                            modifier = Modifier.fillMaxWidth().menuAnchor().testTag("select_vaccine_schedule")
                        )
                        ExposedDropdownMenu(expanded = scheduleExpanded, onDismissRequest = { scheduleExpanded = false }) {
                            schedules.forEach { s ->
                                DropdownMenuItem(
                                    text = {
                                        Column {
                                            Text(s.name, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                                            Text("Interval: ${s.recommended_interval} • Age: ${s.recommended_age}", fontSize = 10.sp, color = Color.Gray)
                                        }
                                    },
                                    onClick = {
                                        selectedSchedule = s
                                        vaccineName = s.vaccine_name
                                        diseaseName = s.disease
                                        dose = s.dose_reference
                                        // Calculate next due date
                                        val cal = Calendar.getInstance()
                                        when {
                                            s.recommended_interval.contains("3 years", ignoreCase = true) -> cal.add(Calendar.YEAR, 3)
                                            s.recommended_interval.contains("6 months", ignoreCase = true) || s.recommended_interval.contains("Bi-annual", ignoreCase = true) -> cal.add(Calendar.MONTH, 6)
                                            else -> cal.add(Calendar.YEAR, 1)
                                        }
                                        nextDueDate = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(cal.time)
                                        scheduleExpanded = false
                                    }
                                )
                            }
                        }
                    }
                }

                // Covered Goats Mode
                item {
                    Text("Target Animals *", fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        listOf("INDIVIDUAL", "MULTIPLE", "ALL_HERD", "DOES", "KIDS").forEach { m ->
                            FilterChip(
                                selected = selectionMode == m,
                                onClick = { selectionMode = m },
                                label = { Text(m.replace("_", " "), fontSize = 10.sp) },
                                colors = FilterChipDefaults.filterChipColors(selectedContainerColor = FarmGreenDark, selectedLabelColor = Color.White)
                            )
                        }
                    }
                }

                if (selectionMode == "INDIVIDUAL") {
                    item {
                        ExposedDropdownMenuBox(expanded = singleGoatExpanded, onExpandedChange = { singleGoatExpanded = !singleGoatExpanded }) {
                            val cur = activeGoats.find { it.id == singleGoatId }
                            OutlinedTextField(
                                value = "${cur?.tag_c ?: "Select"} - ${cur?.name ?: ""}",
                                onValueChange = {},
                                readOnly = true,
                                label = { Text("Select Goat *") },
                                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = singleGoatExpanded) },
                                modifier = Modifier.fillMaxWidth().menuAnchor()
                            )
                            ExposedDropdownMenu(expanded = singleGoatExpanded, onDismissRequest = { singleGoatExpanded = false }) {
                                activeGoats.forEach { g ->
                                    DropdownMenuItem(
                                        text = { Text("${g.tag_c} - ${g.name} (${g.sex_c})") },
                                        onClick = { singleGoatId = g.id; singleGoatExpanded = false }
                                    )
                                }
                            }
                        }
                    }
                } else if (selectionMode == "MULTIPLE") {
                    item {
                        Surface(color = Color(0xFFF8FAFC), shape = RoundedCornerShape(8.dp), modifier = Modifier.fillMaxWidth()) {
                            Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text("Select Multiple Goats (${multipleSelectedIds.size} selected):", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                activeGoats.take(20).forEach { g ->
                                    Row(
                                        modifier = Modifier.fillMaxWidth().clickable {
                                            if (multipleSelectedIds.contains(g.id)) multipleSelectedIds.remove(g.id)
                                            else multipleSelectedIds.add(g.id)
                                        },
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Checkbox(
                                            checked = multipleSelectedIds.contains(g.id),
                                            onCheckedChange = { chk ->
                                                if (chk) multipleSelectedIds.add(g.id)
                                                else multipleSelectedIds.remove(g.id)
                                            }
                                        )
                                        Text("${g.tag_c} - ${g.name} (${g.sex_c})", fontSize = 12.sp)
                                    }
                                }
                            }
                        }
                    }
                }

                item {
                    Text("Selected: ${coveredGoats.size} animal(s)", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = FarmGreenDark)
                }

                item {
                    OutlinedTextField(
                        value = vaccineName,
                        onValueChange = { vaccineName = it },
                        label = { Text("Vaccine Product *") },
                        modifier = Modifier.fillMaxWidth().testTag("input_vaccine_name")
                    )
                }

                item {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = dose,
                            onValueChange = { dose = it },
                            label = { Text("Dose & Route *") },
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = manufacturer,
                            onValueChange = { manufacturer = it },
                            label = { Text("Manufacturer") },
                            placeholder = { Text("e.g. Indian Immunologicals") },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                item {
                    DatePickerField(dateValue = administeredDate, onDateSelected = { administeredDate = it }, label = "Date Given *")
                }

                // Next Due Date (with user override)
                item {
                    DatePickerField(dateValue = nextDueDate, onDateSelected = { nextDueDate = it }, label = "Next Due Date (Auto-calculated, Editable) *")
                }

                item {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = batchNumber,
                            onValueChange = { batchNumber = it },
                            label = { Text("Batch Number") },
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = expiryDate,
                            onValueChange = { expiryDate = it },
                            label = { Text("Batch Expiry") },
                            placeholder = { Text("YYYY-MM") },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                item {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = veterinarian,
                            onValueChange = { veterinarian = it },
                            label = { Text("Veterinarian / Staff") },
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = totalCostStr,
                            onValueChange = { totalCostStr = it },
                            label = { Text("Total Cost (₹)") },
                            placeholder = { Text("Creates Expense") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                item {
                    OutlinedTextField(
                        value = notes,
                        onValueChange = { notes = it },
                        label = { Text("Clinical Notes / Vaccine Site Observations") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                item {
                    OutlinedTextField(
                        value = attachmentNote,
                        onValueChange = { attachmentNote = it },
                        label = { Text("Vial Photo / Invoice Note") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                item {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                        TextButton(onClick = onDismiss) { Text("Cancel") }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = {
                                if (coveredGoats.isEmpty()) return@Button
                                val records = coveredGoats.map { g ->
                                    VaccinationRecord(
                                        goat_id_c = g.id,
                                        vaccine_c = vaccineName.ifBlank { "Vaccination" },
                                        dose_c = dose.ifBlank { "1 ml S/C" },
                                        administered_date_c = administeredDate,
                                        next_due_date_c = nextDueDate.ifBlank { null },
                                        batch_number_c = batchNumber.ifBlank { null },
                                        administered_by_c = veterinarian.ifBlank { null },
                                        notes_c = buildString {
                                            if (manufacturer.isNotBlank()) append("Mfg: $manufacturer. ")
                                            if (expiryDate.isNotBlank()) append("Exp: $expiryDate. ")
                                            if (notes.isNotBlank()) append(notes)
                                            if (attachmentNote.isNotBlank()) append(" [Doc: $attachmentNote]")
                                        }.ifBlank { null }
                                    )
                                }
                                val cost = totalCostStr.toDoubleOrNull()
                                onSave(records, cost, diseaseName)
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = FarmGreenDark),
                            modifier = Modifier.testTag("btn_save_vaccination")
                        ) {
                            Text("Save for ${coveredGoats.size} Goat(s)")
                        }
                    }
                }
            }
        }
    }
}

// Dialog for scheduling future vaccination reminder
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ScheduleVaccinationReminderDialog(
    goats: List<Goat>,
    schedules: List<VaccinationSchedule>,
    today: String,
    onDismiss: () -> Unit,
    onSave: (List<VaccinationRecord>) -> Unit
) {
    var selectedSchedule by remember { mutableStateOf(schedules.firstOrNull()) }
    var scheduleExpanded by remember { mutableStateOf(false) }
    var scheduledDueDate by remember { mutableStateOf(today) }

    Dialog(onDismissRequest = onDismiss) {
        Surface(shape = RoundedCornerShape(16.dp), color = Color.White, modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Schedule Vaccination Campaign", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Color(0xFF1D4ED8))
                Text("Create calendar and dashboard reminders for upcoming herd vaccine drives without recording actual expenses.", fontSize = 11.sp, color = Color.Gray)

                ExposedDropdownMenuBox(expanded = scheduleExpanded, onExpandedChange = { scheduleExpanded = !scheduleExpanded }) {
                    OutlinedTextField(
                        value = selectedSchedule?.name ?: "Select Vaccine Protocol",
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Protocol *") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = scheduleExpanded) },
                        modifier = Modifier.fillMaxWidth().menuAnchor()
                    )
                    ExposedDropdownMenu(expanded = scheduleExpanded, onDismissRequest = { scheduleExpanded = false }) {
                        schedules.forEach { s ->
                            DropdownMenuItem(
                                text = { Text(s.name) },
                                onClick = { selectedSchedule = s; scheduleExpanded = false }
                            )
                        }
                    }
                }

                DatePickerField(dateValue = scheduledDueDate, onDateSelected = { scheduledDueDate = it }, label = "Scheduled Drive Date *")

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    TextButton(onClick = onDismiss) { Text("Cancel") }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            val active = goats.filter { !it.status_c.equals("Deceased", ignoreCase = true) }
                            val records = active.map { g ->
                                VaccinationRecord(
                                    goat_id_c = g.id,
                                    vaccine_c = selectedSchedule?.vaccine_name ?: "Scheduled Vaccine",
                                    dose_c = selectedSchedule?.dose_reference ?: "1 ml",
                                    administered_date_c = today,
                                    next_due_date_c = scheduledDueDate,
                                    notes_c = "Scheduled herd campaign: ${selectedSchedule?.name}"
                                )
                            }
                            onSave(records)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1D4ED8))
                    ) {
                        Text("Schedule for All Active Goats")
                    }
                }
            }
        }
    }
}

// Dialog for editing TANUVAS reference schedule (Requirement 3)
@Composable
private fun EditVaccinationScheduleDialog(
    schedule: VaccinationSchedule,
    onDismiss: () -> Unit,
    onSave: (VaccinationSchedule) -> Unit
) {
    var name by remember { mutableStateOf(schedule.name) }
    var disease by remember { mutableStateOf(schedule.disease) }
    var age by remember { mutableStateOf(schedule.recommended_age) }
    var interval by remember { mutableStateOf(schedule.recommended_interval) }
    var dose by remember { mutableStateOf(schedule.dose_reference) }
    var notes by remember { mutableStateOf(schedule.notes ?: "") }

    Dialog(onDismissRequest = onDismiss) {
        Surface(shape = RoundedCornerShape(16.dp), color = Color.White, modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Edit Schedule Protocol", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = FarmGreenDark)
                Text("Customise protocol timing under veterinary consultation without affecting historical vaccination records.", fontSize = 11.sp, color = Color.Gray)

                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Protocol Name *") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = disease, onValueChange = { disease = it }, label = { Text("Target Disease *") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = age, onValueChange = { age = it }, label = { Text("Recommended Age *") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = interval, onValueChange = { interval = it }, label = { Text("Booster Interval *") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = dose, onValueChange = { dose = it }, label = { Text("Standard Dose & Route *") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = notes, onValueChange = { notes = it }, label = { Text("Clinical Notes & Warnings") }, modifier = Modifier.fillMaxWidth())

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    TextButton(onClick = onDismiss) { Text("Cancel") }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            val updated = schedule.copy(
                                name = name,
                                disease = disease,
                                recommended_age = age,
                                recommended_interval = interval,
                                dose_reference = dose,
                                notes = notes,
                                source = "Farm Custom Protocol (TANUVAS Baseline)"
                            )
                            onSave(updated)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = FarmGreenDark)
                    ) {
                        Text("Save Protocol")
                    }
                }
            }
        }
    }
}
