package com.example.ui.screens.health

import androidx.activity.compose.BackHandler
import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.TrendingUp
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.supabase.Goat
import com.example.data.supabase.GoatRepository
import com.example.data.supabase.GoatWeight
import com.example.ui.components.DatePickerField
import com.example.ui.theme.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.TimeUnit

enum class WeighInScheduleStatus {
    OVERDUE,
    DUE_TODAY,
    DUE_SOON,
    UP_TO_DATE,
    NEVER_WEIGHED
}

data class GoatWeighInSummary(
    val goat: Goat,
    val latestWeight: GoatWeight?,
    val previousWeight: GoatWeight?,
    val totalLogsCount: Int,
    val daysSinceLastWeighIn: Int?,
    val nextDueDateStr: String?,
    val status: WeighInScheduleStatus,
    val overdueDays: Int,
    val netGainKg: Double?,
    val adgGramsPerDay: Int?
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RecurringHealthTrackingScreen(
    repository: GoatRepository,
    initialGoatId: String? = null,
    onNavigateBack: () -> Unit,
    onNavigateToGoatProfile: (String) -> Unit = {},
    modifier: Modifier = Modifier
) {
    BackHandler { onNavigateBack() }

    val coroutineScope = rememberCoroutineScope()
    val sdfDate = remember { SimpleDateFormat("yyyy-MM-dd", Locale.US) }
    val sdfDisplay = remember { SimpleDateFormat("MMM dd, yyyy", Locale.US) }
    val sdfFull = remember { SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US) }

    // State collections
    val allGoats by repository.getLocalGoatsFlow().collectAsState(initial = emptyList())
    val allWeights by repository.getAllWeightsFlow().collectAsState(initial = emptyList())

    // Configurable Recurring Cadence: 7, 14, 30, 60 days
    var recurringIntervalDays by remember { mutableStateOf(14) }
    var selectedTab by remember { mutableStateOf(0) } // 0: All, 1: Due & Overdue, 2: Kids, 3: Weight Logs Audit
    var searchQuery by remember { mutableStateOf("") }
    var selectedBreedFilter by remember { mutableStateOf("All") }

    // Dialog & Flow States
    var selectedGoatForWeight by remember { mutableStateOf<Goat?>(null) }
    var selectedGoatForHistory by remember { mutableStateOf<Goat?>(null) }
    var showBatchRapidMode by remember { mutableStateOf(false) }
    var weightToDelete by remember { mutableStateOf<GoatWeight?>(null) }
    var successToastMessage by remember { mutableStateOf<String?>(null) }

    // Handle initial goat selection
    LaunchedEffect(initialGoatId, allGoats) {
        if (!initialGoatId.isNullOrBlank() && selectedGoatForWeight == null && selectedGoatForHistory == null) {
            val found = allGoats.find { it.id == initialGoatId }
            if (found != null) {
                selectedGoatForWeight = found
            }
        }
    }

    // Compute Summaries for each goat
    val todayDate = remember { Date() }
    val todayStr = remember { sdfDate.format(todayDate) }

    val goatSummaries = remember(allGoats, allWeights, recurringIntervalDays) {
        val weightsByGoat = allWeights.groupBy { it.goat_id_c }
        allGoats.map { goat ->
            val logs = (weightsByGoat[goat.id] ?: emptyList()).sortedByDescending { it.date_c }
            val latest = logs.firstOrNull()
            val previous = logs.getOrNull(1)

            val daysSince: Int? = if (latest != null) {
                try {
                    val parsed = sdfDate.parse(latest.date_c) ?: todayDate
                    val diff = todayDate.time - parsed.time
                    maxOf(0, TimeUnit.MILLISECONDS.toDays(diff).toInt())
                } catch (_: Exception) { null }
            } else null

            val nextDueDateStr: String? = if (latest != null) {
                try {
                    val parsed = sdfDate.parse(latest.date_c) ?: todayDate
                    val nextCal = Calendar.getInstance().apply {
                        time = parsed
                        add(Calendar.DAY_OF_YEAR, recurringIntervalDays)
                    }
                    sdfDate.format(nextCal.time)
                } catch (_: Exception) { null }
            } else todayStr

            val status: WeighInScheduleStatus
            val overdueDays: Int
            if (latest == null) {
                status = WeighInScheduleStatus.NEVER_WEIGHED
                overdueDays = 0
            } else if (daysSince != null) {
                when {
                    daysSince > recurringIntervalDays -> {
                        status = WeighInScheduleStatus.OVERDUE
                        overdueDays = daysSince - recurringIntervalDays
                    }
                    daysSince == recurringIntervalDays -> {
                        status = WeighInScheduleStatus.DUE_TODAY
                        overdueDays = 0
                    }
                    daysSince >= recurringIntervalDays - 2 -> {
                        status = WeighInScheduleStatus.DUE_SOON
                        overdueDays = 0
                    }
                    else -> {
                        status = WeighInScheduleStatus.UP_TO_DATE
                        overdueDays = 0
                    }
                }
            } else {
                status = WeighInScheduleStatus.UP_TO_DATE
                overdueDays = 0
            }

            val netGain = if (latest != null && previous != null) {
                latest.weight_kg_c - previous.weight_kg_c
            } else null

            val adg = if (latest != null && previous != null) {
                try {
                    val d1 = sdfDate.parse(previous.date_c) ?: todayDate
                    val d2 = sdfDate.parse(latest.date_c) ?: todayDate
                    val dDiff = TimeUnit.MILLISECONDS.toDays(d2.time - d1.time).toInt()
                    if (dDiff > 0) {
                        val gainKg = latest.weight_kg_c - previous.weight_kg_c
                        ((gainKg * 1000.0) / dDiff).toInt()
                    } else null
                } catch (_: Exception) { null }
            } else null

            GoatWeighInSummary(
                goat = goat,
                latestWeight = latest,
                previousWeight = previous,
                totalLogsCount = logs.size,
                daysSinceLastWeighIn = daysSince,
                nextDueDateStr = nextDueDateStr,
                status = status,
                overdueDays = overdueDays,
                netGainKg = netGain,
                adgGramsPerDay = adg
            )
        }
    }

    // Available breeds in the current herd
    val distinctBreeds = remember(allGoats) {
        listOf("All") + allGoats.map { it.breed_c }.distinct().filter { it.isNotBlank() }
    }

    // Filtered Goat Summaries
    val filteredSummaries = remember(goatSummaries, selectedTab, searchQuery, selectedBreedFilter) {
        goatSummaries.filter { summary ->
            val matchesBreed = selectedBreedFilter == "All" || summary.goat.breed_c.equals(selectedBreedFilter, ignoreCase = true)
            val matchesQuery = searchQuery.isBlank() ||
                    summary.goat.tag_c.contains(searchQuery, ignoreCase = true) ||
                    summary.goat.name.contains(searchQuery, ignoreCase = true)

            val matchesTab = when (selectedTab) {
                1 -> summary.status == WeighInScheduleStatus.OVERDUE ||
                        summary.status == WeighInScheduleStatus.DUE_TODAY ||
                        summary.status == WeighInScheduleStatus.DUE_SOON ||
                        summary.status == WeighInScheduleStatus.NEVER_WEIGHED
                2 -> summary.goat.status_c.contains("Kid", ignoreCase = true) ||
                        summary.goat.status_c.contains("Weaned", ignoreCase = true) ||
                        (summary.goat.weight_kg_c ?: 0.0) < 20.0
                else -> true
            }

            matchesBreed && matchesQuery && matchesTab
        }.sortedWith(compareBy(
            { if (it.status == WeighInScheduleStatus.OVERDUE) 0 else if (it.status == WeighInScheduleStatus.DUE_TODAY) 1 else if (it.status == WeighInScheduleStatus.NEVER_WEIGHED) 2 else 3 },
            { -(it.overdueDays) },
            { it.goat.tag_c }
        ))
    }

    // Top Level Counts
    val overdueCount = remember(goatSummaries) { goatSummaries.count { it.status == WeighInScheduleStatus.OVERDUE } }
    val dueTodayCount = remember(goatSummaries) { goatSummaries.count { it.status == WeighInScheduleStatus.DUE_TODAY || it.status == WeighInScheduleStatus.NEVER_WEIGHED } }
    val upToDateCount = remember(goatSummaries) { goatSummaries.count { it.status == WeighInScheduleStatus.UP_TO_DATE } }
    val avgHerdWeight = remember(allGoats) {
        val weights = allGoats.mapNotNull { it.weight_kg_c }.filter { it > 0.0 }
        if (weights.isNotEmpty()) weights.average() else null
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "Recurring Health Tracking",
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp
                        )
                        Text(
                            text = "Scheduled Weigh-in Cadence & Weight Logs Database",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                navigationIcon = {
                    IconButton(
                        onClick = onNavigateBack,
                        modifier = Modifier.testTag("recurring_health_btn_back")
                    ) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(
                        onClick = {
                            val nextGoat = filteredSummaries.firstOrNull {
                                it.status == WeighInScheduleStatus.OVERDUE ||
                                        it.status == WeighInScheduleStatus.DUE_TODAY ||
                                        it.status == WeighInScheduleStatus.NEVER_WEIGHED
                            }?.goat ?: allGoats.firstOrNull()
                            if (nextGoat != null) {
                                selectedGoatForWeight = nextGoat
                            }
                        },
                        modifier = Modifier.testTag("btn_rapid_weigh_in")
                    ) {
                        Icon(Icons.Default.AddCircle, contentDescription = "Quick Weigh", tint = FarmGreenDark)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.White)
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = {
                    val candidate = filteredSummaries.firstOrNull {
                        it.status == WeighInScheduleStatus.OVERDUE ||
                                it.status == WeighInScheduleStatus.DUE_TODAY ||
                                it.status == WeighInScheduleStatus.NEVER_WEIGHED
                    }?.goat ?: allGoats.firstOrNull()
                    if (candidate != null) {
                        selectedGoatForWeight = candidate
                    }
                },
                icon = { Icon(Icons.Default.Scale, contentDescription = null) },
                text = { Text("Record Weight Log", fontWeight = FontWeight.Bold) },
                containerColor = FarmGreenPrimary,
                contentColor = Color.White,
                modifier = Modifier.testTag("fab_record_recurring_weight")
            )
        }
    ) { padding ->
        val sortedWeights = remember(allWeights) {
            allWeights.sortedByDescending { it.timestamp }
        }
        val allGoatsMap = remember(allGoats) {
            allGoats.associateBy { it.id }
        }

        LazyColumn(
            modifier = modifier
                .fillMaxSize()
                .background(Color(0xFFF8FAFC))
                .padding(padding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item { Spacer(modifier = Modifier.height(4.dp)) }

            // 1. Hero KPI Overview Cards
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(CircleShape)
                                        .background(FarmGreenLight.copy(alpha = 0.2f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(Icons.Default.MonitorWeight, contentDescription = null, tint = FarmGreenDark, modifier = Modifier.size(20.dp))
                                }
                                Column {
                                    Text(
                                        text = "Herd Weigh-in Overview",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 15.sp,
                                        color = Color(0xFF0F172A)
                                    )
                                    Text(
                                        text = "${allGoats.size} goats monitored • ${allWeights.size} weight logs in Room DB",
                                        fontSize = 11.sp,
                                        color = Color(0xFF64748B)
                                    )
                                }
                            }

                            // Cadence selector pill
                            Surface(
                                shape = RoundedCornerShape(20.dp),
                                color = Color(0xFFF1F5F9),
                                border = BorderStroke(1.dp, Color(0xFFCBD5E1))
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Icon(Icons.Default.Repeat, contentDescription = null, modifier = Modifier.size(14.dp), tint = Color(0xFF475569))
                                    Text(
                                        text = "Every ${recurringIntervalDays}d",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF334155)
                                    )
                                }
                            }
                        }

                        // 4-Tile Metric Strip
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            MetricPillTile(
                                label = "Overdue",
                                value = "$overdueCount",
                                color = Color(0xFFDC2626),
                                bgColor = Color(0xFFFEE2E2),
                                modifier = Modifier.weight(1f),
                                onClick = { selectedTab = 1 }
                            )
                            MetricPillTile(
                                label = "Due Today",
                                value = "$dueTodayCount",
                                color = Color(0xFFD97706),
                                bgColor = Color(0xFFFEF3C7),
                                modifier = Modifier.weight(1f),
                                onClick = { selectedTab = 1 }
                            )
                            MetricPillTile(
                                label = "Up-to-Date",
                                value = "$upToDateCount",
                                color = FarmGreenDark,
                                bgColor = Color(0xFFDCFCE7),
                                modifier = Modifier.weight(1f),
                                onClick = { selectedTab = 0 }
                            )
                            MetricPillTile(
                                label = "Avg Weight",
                                value = if (avgHerdWeight != null) String.format(Locale.US, "%.1fkg", avgHerdWeight) else "--",
                                color = Color(0xFF2563EB),
                                bgColor = Color(0xFFEFF6FF),
                                modifier = Modifier.weight(1f)
                            )
                        }

                        // Quick Cadence Settings Selector
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "Recurring Schedule Interval:",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = Color(0xFF475569)
                            )
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                listOf(7 to "7d (Weekly)", 14 to "14d (Bi-wk)", 30 to "30d (Monthly)").forEach { (days, label) ->
                                    val isSelected = recurringIntervalDays == days
                                    FilterChip(
                                        selected = isSelected,
                                        onClick = { recurringIntervalDays = days },
                                        label = { Text(label, fontSize = 11.sp, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal) },
                                        colors = FilterChipDefaults.filterChipColors(
                                            selectedContainerColor = FarmGreenPrimary,
                                            selectedLabelColor = Color.White
                                        ),
                                        border = null,
                                        modifier = Modifier.height(28.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // 2. Search & Breed Filter Bar
            item {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("recurring_health_search_input"),
                        placeholder = { Text("Search by Tag ID, Name or Breed...") },
                        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = Color.Gray) },
                        trailingIcon = {
                            if (searchQuery.isNotEmpty()) {
                                IconButton(onClick = { searchQuery = "" }) {
                                    Icon(Icons.Default.Clear, contentDescription = "Clear")
                                }
                            }
                        },
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = Color.White,
                            unfocusedContainerColor = Color.White,
                            focusedBorderColor = FarmGreenPrimary,
                            unfocusedBorderColor = Color(0xFFE2E8F0)
                        )
                    )

                    // Breed horizontal scroll pills (including Salem Karupu, Kodi Adu, etc.)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        distinctBreeds.forEach { breed ->
                            val isSelected = selectedBreedFilter == breed
                            FilterChip(
                                selected = isSelected,
                                onClick = { selectedBreedFilter = breed },
                                label = { Text(breed, fontSize = 11.sp, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = FarmGreenDark,
                                    selectedLabelColor = Color.White,
                                    containerColor = Color.White
                                ),
                                border = BorderStroke(1.dp, if (isSelected) FarmGreenDark else Color(0xFFE2E8F0)),
                                modifier = Modifier.height(30.dp)
                            )
                        }
                    }
                }
            }

            // 3. Tab Bar
            item {
                TabRow(
                    selectedTabIndex = selectedTab,
                    containerColor = Color.White,
                    contentColor = FarmGreenDark,
                    modifier = Modifier.clip(RoundedCornerShape(12.dp))
                ) {
                    Tab(
                        selected = selectedTab == 0,
                        onClick = { selectedTab = 0 },
                        text = { Text("All Herd (${allGoats.size})", fontWeight = FontWeight.SemiBold, fontSize = 12.sp) }
                    )
                    Tab(
                        selected = selectedTab == 1,
                        onClick = { selectedTab = 1 },
                        text = {
                            val dueTotal = overdueCount + dueTodayCount
                            Text(
                                "Due & Overdue ($dueTotal)",
                                fontWeight = FontWeight.Bold,
                                color = if (dueTotal > 0) Color(0xFFDC2626) else Color.Unspecified,
                                fontSize = 12.sp
                            )
                        }
                    )
                    Tab(
                        selected = selectedTab == 2,
                        onClick = { selectedTab = 2 },
                        text = { Text("Kids / Growing", fontWeight = FontWeight.SemiBold, fontSize = 12.sp) }
                    )
                    Tab(
                        selected = selectedTab == 3,
                        onClick = { selectedTab = 3 },
                        text = { Text("Recent Logs (${allWeights.size})", fontWeight = FontWeight.SemiBold, fontSize = 12.sp) }
                    )
                }
            }

            // Tab 3: Weight Logs Audit Trail / Timeline
            if (selectedTab == 3) {
                if (allWeights.isEmpty()) {
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Column(
                                modifier = Modifier.padding(32.dp).fillMaxWidth(),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Icon(Icons.Default.History, contentDescription = null, modifier = Modifier.size(48.dp), tint = Color.LightGray)
                                Spacer(modifier = Modifier.height(12.dp))
                                Text("No weight records in database yet.", fontWeight = FontWeight.Bold, color = Color.Gray)
                                Text("Use 'Record Weight Log' to save recurring weigh-ins with notes and timestamps.", fontSize = 12.sp, color = Color.Gray)
                            }
                        }
                    }
                } else {
                    items(sortedWeights) { weight ->
                        val goat = allGoatsMap[weight.goat_id_c]
                        WeightLogAuditItemCard(
                            weight = weight,
                            goat = goat,
                            onDelete = { weightToDelete = weight },
                            onGoatClick = {
                                if (goat != null) onNavigateToGoatProfile(goat.id)
                            }
                        )
                    }
                }
            } else {
                // Tab 0, 1, 2: Goat Cards with Status & Next Due
                if (filteredSummaries.isEmpty()) {
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Column(
                                modifier = Modifier.padding(32.dp).fillMaxWidth(),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Icon(Icons.Default.SearchOff, contentDescription = null, modifier = Modifier.size(48.dp), tint = Color.LightGray)
                                Spacer(modifier = Modifier.height(12.dp))
                                Text("No goats match current filter.", fontWeight = FontWeight.Bold, color = Color.Gray)
                                Text("Try adjusting search or selecting a different tab.", fontSize = 12.sp, color = Color.Gray)
                            }
                        }
                    }
                } else {
                    items(filteredSummaries, key = { it.goat.id }) { summary ->
                        RecurringGoatCard(
                            summary = summary,
                            onRecordWeight = { selectedGoatForWeight = summary.goat },
                            onViewHistory = { selectedGoatForHistory = summary.goat },
                            onOpenProfile = { onNavigateToGoatProfile(summary.goat.id) }
                        )
                    }
                }
            }

            item { Spacer(modifier = Modifier.height(80.dp)) }
        }
    }

    // Modal Dialog: Record Weight Log (Timestamp, Weight, Method, BCS, Notes, Recurrence)
    selectedGoatForWeight?.let { goat ->
        val candidateWeights = remember(allWeights, goat.id) {
            allWeights.filter { it.goat_id_c == goat.id }.sortedByDescending { it.date_c }
        }
        val lastWeight = candidateWeights.firstOrNull()

        RecordWeightLogModalDialog(
            goat = goat,
            lastWeight = lastWeight,
            defaultRecurringIntervalDays = recurringIntervalDays,
            onDismiss = { selectedGoatForWeight = null },
            onSave = { weightKg, dateStr, timeStr, method, bcs, notes, nextCadenceDays ->
                coroutineScope.launch {
                    val fullNotesBuilder = StringBuilder()
                    if (!bcs.isNullOrBlank()) fullNotesBuilder.append("[BCS $bcs] ")
                    if (!notes.isNullOrBlank()) fullNotesBuilder.append(notes.trim())
                    fullNotesBuilder.append(" [Cadence: ${nextCadenceDays}d]")

                    // Build timestamp millis
                    val timestampMillis = try {
                        val parsed = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).parse("$dateStr $timeStr")
                        parsed?.time ?: System.currentTimeMillis()
                    } catch (_: Exception) {
                        System.currentTimeMillis()
                    }

                    val newWeightRecord = GoatWeight(
                        id = UUID.randomUUID().toString(),
                        goat_id_c = goat.id,
                        weight_kg_c = weightKg,
                        date_c = dateStr,
                        method_c = method,
                        notes_c = fullNotesBuilder.toString().ifBlank { null },
                        timestamp = timestampMillis
                    )

                    val res = repository.recordWeight(newWeightRecord)
                    if (res.isSuccess) {
                        successToastMessage = "Weight of ${String.format(Locale.US, "%.1f", weightKg)} kg recorded for ${goat.tag_c} with timestamp!"
                        selectedGoatForWeight = null
                    }
                }
            }
        )
    }

    // Modal Dialog: Goat Weight History Logs
    selectedGoatForHistory?.let { goat ->
        val goatLogs = remember(allWeights, goat.id) {
            allWeights.filter { it.goat_id_c == goat.id }.sortedByDescending { it.timestamp }
        }
        GoatWeightHistoryModalDialog(
            goat = goat,
            logs = goatLogs,
            onDismiss = { selectedGoatForHistory = null },
            onDeleteWeight = { weightId ->
                coroutineScope.launch {
                    repository.deleteWeightRecord(weightId, goat.id)
                }
            },
            onAddNewWeight = {
                selectedGoatForHistory = null
                selectedGoatForWeight = goat
            }
        )
    }

    // Delete Confirmation Dialog
    weightToDelete?.let { wt ->
        val associatedGoat = remember(allGoats, wt.goat_id_c) {
            allGoats.find { it.id == wt.goat_id_c }
        }
        AlertDialog(
            onDismissRequest = { weightToDelete = null },
            title = { Text("Delete Weight Entry", fontWeight = FontWeight.Bold) },
            text = {
                Text("Are you sure you want to remove the weight measurement of ${wt.weight_kg_c} kg recorded on ${wt.date_c} for goat ${associatedGoat?.tag_c ?: wt.goat_id_c}?")
            },
            confirmButton = {
                Button(
                    onClick = {
                        coroutineScope.launch {
                            repository.deleteWeightRecord(wt.id, wt.goat_id_c)
                            weightToDelete = null
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626))
                ) {
                    Text("Delete")
                }
            },
            dismissButton = {
                TextButton(onClick = { weightToDelete = null }) {
                    Text("Cancel")
                }
            }
        )
    }
}

// ==============================================================================
// COMPONENT: Recurring Goat Card
// ==============================================================================

@Composable
fun RecurringGoatCard(
    summary: GoatWeighInSummary,
    onRecordWeight: () -> Unit,
    onViewHistory: () -> Unit,
    onOpenProfile: () -> Unit,
    modifier: Modifier = Modifier
) {
    val goat = summary.goat
    val latest = summary.latestWeight

    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = modifier
            .fillMaxWidth()
            .testTag("goat_recurring_card_${goat.tag_c}")
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Header Row: Avatar, Tag, Breed, Status Badge
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .clip(CircleShape)
                            .background(
                                when (summary.status) {
                                    WeighInScheduleStatus.OVERDUE -> Color(0xFFFEE2E2)
                                    WeighInScheduleStatus.DUE_TODAY -> Color(0xFFFEF3C7)
                                    WeighInScheduleStatus.DUE_SOON -> Color(0xFFEFF6FF)
                                    WeighInScheduleStatus.UP_TO_DATE -> Color(0xFFDCFCE7)
                                    WeighInScheduleStatus.NEVER_WEIGHED -> Color(0xFFF1F5F9)
                                }
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = goat.tag_c.takeLast(3),
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = when (summary.status) {
                                WeighInScheduleStatus.OVERDUE -> Color(0xFFDC2626)
                                WeighInScheduleStatus.DUE_TODAY -> Color(0xFFB45309)
                                WeighInScheduleStatus.DUE_SOON -> Color(0xFF1D4ED8)
                                WeighInScheduleStatus.UP_TO_DATE -> FarmGreenDark
                                WeighInScheduleStatus.NEVER_WEIGHED -> Color.Gray
                            }
                        )
                    }

                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(
                                text = goat.tag_c,
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp,
                                color = Color(0xFF0F172A)
                            )
                            if (goat.name.isNotBlank()) {
                                Text(
                                    text = "(${goat.name})",
                                    fontSize = 13.sp,
                                    color = Color(0xFF475569)
                                )
                            }
                        }
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(
                                text = goat.breed_c,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Medium,
                                color = FarmGreenDark
                            )
                            Text("•", fontSize = 10.sp, color = Color.Gray)
                            Text(
                                text = "${goat.sex_c} • ${goat.status_c}",
                                fontSize = 11.sp,
                                color = Color(0xFF64748B)
                            )
                        }
                    }
                }

                // Schedule Urgency Badge
                ScheduleStatusPill(status = summary.status, overdueDays = summary.overdueDays)
            }

            HorizontalDivider(color = Color(0xFFF1F5F9))

            // Body Metrics Row: Last Weight, Gain/Loss, Last Date, Next Due Date
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Latest Weight
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Color(0xFFF8FAFC),
                    border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
                    modifier = Modifier.weight(1f)
                ) {
                    Column(modifier = Modifier.padding(8.dp)) {
                        Text("Latest Weight", fontSize = 10.sp, color = Color.Gray, fontWeight = FontWeight.SemiBold)
                        val wStr = if (latest != null) "${String.format(Locale.US, "%.1f", latest.weight_kg_c)} kg" else "--"
                        Text(wStr, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color(0xFF0F172A))
                        if (summary.daysSinceLastWeighIn != null) {
                            Text(
                                text = "${summary.daysSinceLastWeighIn}d ago (${latest?.date_c})",
                                fontSize = 9.sp,
                                color = Color(0xFF64748B),
                                maxLines = 1
                            )
                        } else {
                            Text("No weigh-in yet", fontSize = 9.sp, color = Color.Gray)
                        }
                    }
                }

                // Weight Gain / Loss (Delta)
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = if (summary.netGainKg != null && summary.netGainKg >= 0) Color(0xFFF0FDF4) else Color(0xFFF8FAFC),
                    border = BorderStroke(1.dp, if (summary.netGainKg != null && summary.netGainKg >= 0) Color(0xFFBBF7D0) else Color(0xFFE2E8F0)),
                    modifier = Modifier.weight(1f)
                ) {
                    Column(modifier = Modifier.padding(8.dp)) {
                        Text("Growth Delta", fontSize = 10.sp, color = Color.Gray, fontWeight = FontWeight.SemiBold)
                        val deltaStr = if (summary.netGainKg != null) {
                            "${if (summary.netGainKg >= 0) "+" else ""}${String.format(Locale.US, "%.1f", summary.netGainKg)} kg"
                        } else "--"
                        Text(
                            text = deltaStr,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = if (summary.netGainKg != null && summary.netGainKg >= 0) FarmGreenDark else if (summary.netGainKg != null) Color(0xFFDC2626) else Color.DarkGray
                        )
                        if (summary.adgGramsPerDay != null) {
                            Text(
                                text = "ADG: ${summary.adgGramsPerDay} g/d",
                                fontSize = 9.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = Color(0xFF2563EB)
                            )
                        } else {
                            Text("Need 2+ weigh-ins", fontSize = 9.sp, color = Color.Gray)
                        }
                    }
                }

                // Next Scheduled Weigh-in Date
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = when (summary.status) {
                        WeighInScheduleStatus.OVERDUE -> Color(0xFFFEF2F2)
                        WeighInScheduleStatus.DUE_TODAY -> Color(0xFFFFFBEB)
                        else -> Color(0xFFF8FAFC)
                    },
                    border = BorderStroke(
                        1.dp,
                        when (summary.status) {
                            WeighInScheduleStatus.OVERDUE -> Color(0xFFFECACA)
                            WeighInScheduleStatus.DUE_TODAY -> Color(0xFFFDE68A)
                            else -> Color(0xFFE2E8F0)
                        }
                    ),
                    modifier = Modifier.weight(1f)
                ) {
                    Column(modifier = Modifier.padding(8.dp)) {
                        Text("Next Weigh-in", fontSize = 10.sp, color = Color.Gray, fontWeight = FontWeight.SemiBold)
                        Text(
                            text = summary.nextDueDateStr ?: "Today",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = when (summary.status) {
                                WeighInScheduleStatus.OVERDUE -> Color(0xFFDC2626)
                                WeighInScheduleStatus.DUE_TODAY -> Color(0xFFD97706)
                                else -> Color(0xFF334155)
                            }
                        )
                        Text(
                            text = when (summary.status) {
                                WeighInScheduleStatus.OVERDUE -> "Overdue!"
                                WeighInScheduleStatus.DUE_TODAY -> "Due today"
                                WeighInScheduleStatus.DUE_SOON -> "Upcoming"
                                WeighInScheduleStatus.UP_TO_DATE -> "On schedule"
                                WeighInScheduleStatus.NEVER_WEIGHED -> "First entry"
                            },
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Medium,
                            color = when (summary.status) {
                                WeighInScheduleStatus.OVERDUE -> Color(0xFFDC2626)
                                WeighInScheduleStatus.DUE_TODAY -> Color(0xFFD97706)
                                else -> Color.Gray
                            }
                        )
                    }
                }
            }

            // Action Buttons Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Secondary: View History
                OutlinedButton(
                    onClick = onViewHistory,
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(38.dp)
                        .testTag("btn_history_${goat.tag_c}"),
                    contentPadding = PaddingValues(horizontal = 8.dp)
                ) {
                    Icon(Icons.Default.History, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Logs (${summary.totalLogsCount})", fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                }

                // Primary: Record Weight
                Button(
                    onClick = onRecordWeight,
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (summary.status == WeighInScheduleStatus.OVERDUE) Color(0xFFDC2626) else FarmGreenPrimary
                    ),
                    modifier = Modifier
                        .weight(1.3f)
                        .height(38.dp)
                        .testTag("btn_record_weight_${goat.tag_c}"),
                    contentPadding = PaddingValues(horizontal = 8.dp)
                ) {
                    Icon(Icons.Default.Scale, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        if (latest == null) "Initial Weigh-in" else "Log Weight",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

// ==============================================================================
// COMPONENT: Schedule Status Pill
// ==============================================================================

@Composable
fun ScheduleStatusPill(status: WeighInScheduleStatus, overdueDays: Int) {
    val (label, bg, text, icon) = when (status) {
        WeighInScheduleStatus.OVERDUE -> {
            Quadruple(
                "${overdueDays}d Overdue",
                Color(0xFFFEE2E2),
                Color(0xFFDC2626),
                Icons.Default.WarningAmber
            )
        }
        WeighInScheduleStatus.DUE_TODAY -> {
            Quadruple(
                "Due Today",
                Color(0xFFFEF3C7),
                Color(0xFFD97706),
                Icons.Default.NotificationsActive
            )
        }
        WeighInScheduleStatus.DUE_SOON -> {
            Quadruple(
                "Due Soon",
                Color(0xFFEFF6FF),
                Color(0xFF2563EB),
                Icons.Default.Event
            )
        }
        WeighInScheduleStatus.UP_TO_DATE -> {
            Quadruple(
                "Up-to-Date",
                Color(0xFFDCFCE7),
                FarmGreenDark,
                Icons.Default.CheckCircle
            )
        }
        WeighInScheduleStatus.NEVER_WEIGHED -> {
            Quadruple(
                "Unweighed",
                Color(0xFFF1F5F9),
                Color(0xFF64748B),
                Icons.Default.Add
            )
        }
    }

    Surface(
        shape = RoundedCornerShape(20.dp),
        color = bg
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(3.dp)
        ) {
            Icon(icon, contentDescription = null, modifier = Modifier.size(12.dp), tint = text)
            Text(label, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = text)
        }
    }
}

data class Quadruple<A, B, C, D>(val first: A, val second: B, val third: C, val fourth: D)

// ==============================================================================
// COMPONENT: Weight Log Audit Item Card (Database Audit Trail)
// ==============================================================================

@Composable
fun WeightLogAuditItemCard(
    weight: GoatWeight,
    goat: Goat?,
    onDelete: () -> Unit,
    onGoatClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val formattedTimestamp = remember(weight.timestamp) {
        val sdf = SimpleDateFormat("yyyy-MM-dd • hh:mm a", Locale.US)
        sdf.format(Date(weight.timestamp))
    }

    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.weight(1f)
            ) {
                Surface(
                    shape = CircleShape,
                    color = FarmGreenLight.copy(alpha = 0.2f),
                    modifier = Modifier.size(40.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.Scale, contentDescription = null, tint = FarmGreenDark, modifier = Modifier.size(20.dp))
                    }
                }

                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = "${String.format(Locale.US, "%.1f", weight.weight_kg_c)} kg",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = Color(0xFF0F172A)
                        )
                        Surface(
                            shape = RoundedCornerShape(4.dp),
                            color = Color(0xFFF1F5F9)
                        ) {
                            Text(
                                text = weight.method_c,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = Color(0xFF475569),
                                modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp)
                            )
                        }
                    }

                    // Goat info link
                    Text(
                        text = if (goat != null) "Goat: ${goat.tag_c} • ${goat.breed_c} (${goat.name})" else "Goat ID: ${weight.goat_id_c.take(8)}",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium,
                        color = FarmGreenDark,
                        modifier = Modifier.clickable { onGoatClick() }
                    )

                    // Formatted Timestamp & Date
                    Text(
                        text = "Timestamp: $formattedTimestamp",
                        fontSize = 10.sp,
                        color = Color(0xFF64748B)
                    )

                    if (!weight.notes_c.isNullOrBlank()) {
                        Text(
                            text = "Notes: ${weight.notes_c}",
                            fontSize = 11.sp,
                            color = Color(0xFF334155),
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }

            IconButton(onClick = onDelete) {
                Icon(Icons.Default.Delete, contentDescription = "Delete Log", tint = Color(0xFF94A3B8), modifier = Modifier.size(18.dp))
            }
        }
    }
}

// ==============================================================================
// MODAL DIALOG: Record Weight Log
// ==============================================================================

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RecordWeightLogModalDialog(
    goat: Goat,
    lastWeight: GoatWeight?,
    defaultRecurringIntervalDays: Int,
    onDismiss: () -> Unit,
    onSave: (weightKg: Double, dateStr: String, timeStr: String, method: String, bcs: String?, notes: String?, nextCadenceDays: Int) -> Unit
) {
    val sdfDate = remember { SimpleDateFormat("yyyy-MM-dd", Locale.US) }
    val sdfTime = remember { SimpleDateFormat("HH:mm", Locale.US) }
    val now = remember { Date() }

    var weightStr by remember {
        mutableStateOf(
            if (lastWeight != null && lastWeight.weight_kg_c > 0) {
                String.format(Locale.US, "%.1f", lastWeight.weight_kg_c)
            } else if (goat.weight_kg_c != null && goat.weight_kg_c > 0) {
                String.format(Locale.US, "%.1f", goat.weight_kg_c)
            } else {
                "30.0"
            }
        )
    }

    var dateStr by remember { mutableStateOf(sdfDate.format(now)) }
    var timeStr by remember { mutableStateOf(sdfTime.format(now)) }
    var method by remember { mutableStateOf(lastWeight?.method_c ?: "Electronic Scale") }
    var bcsScore by remember { mutableStateOf("3.0") } // Body Condition Score 1.0 - 5.0
    var notes by remember { mutableStateOf("") }
    var cadenceDays by remember { mutableStateOf(defaultRecurringIntervalDays) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    val methods = listOf("Electronic Scale", "Weight Tape", "Hanging Spring Scale", "Visual Estimate")
    val bcsOptions = listOf("1.0 (Thin)", "2.0 (Lean)", "3.0 (Ideal)", "4.0 (Heavy)", "5.0 (Obese)")
    val quickNotes = listOf("Healthy & active", "Normal rumen fill", "Good appetite", "Post-kidding recovery", "Needs booster feed")

    val currentWeightDouble = weightStr.toDoubleOrNull() ?: 0.0
    val weightGain = if (lastWeight != null && currentWeightDouble > 0) {
        currentWeightDouble - lastWeight.weight_kg_c
    } else null

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(Icons.Default.Scale, contentDescription = null, tint = FarmGreenDark)
                Column {
                    Text("Record Weight Log", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Text("${goat.tag_c} • ${goat.breed_c} (${goat.name.ifBlank { goat.sex_c }})", fontSize = 11.sp, color = Color.Gray)
                }
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Previous Weight & Live Gain Comparison Callout
                if (lastWeight != null) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = Color(0xFFF1F5F9),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("Previous Record", fontSize = 10.sp, color = Color.Gray)
                                Text("${lastWeight.weight_kg_c} kg on ${lastWeight.date_c}", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                            }
                            if (weightGain != null) {
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = if (weightGain >= 0) Color(0xFFDCFCE7) else Color(0xFFFEE2E2)
                                ) {
                                    Text(
                                        text = "${if (weightGain >= 0) "+" else ""}${String.format(Locale.US, "%.1f", weightGain)} kg",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp,
                                        color = if (weightGain >= 0) FarmGreenDark else Color(0xFFDC2626),
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                        }
                    }
                }

                // Weight Input Field with Digits
                OutlinedTextField(
                    value = weightStr,
                    onValueChange = { weightStr = it; errorMessage = null },
                    label = { Text("Weight (kg) *") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    textStyle = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold, color = FarmGreenDark),
                    trailingIcon = { Text("kg", fontWeight = FontWeight.Bold, fontSize = 16.sp, modifier = Modifier.padding(end = 12.dp)) },
                    modifier = Modifier.fillMaxWidth().testTag("modal_weight_input")
                )

                // Quick Increment Steppers
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    listOf(-1.0, -0.5, -0.1, 0.1, 0.5, 1.0).forEach { delta ->
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = Color(0xFFF1F5F9),
                            border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
                            modifier = Modifier
                                .weight(1f)
                                .clickable {
                                    val curr = weightStr.toDoubleOrNull() ?: 25.0
                                    val updated = maxOf(0.1, curr + delta)
                                    weightStr = String.format(Locale.US, "%.1f", updated)
                                }
                        ) {
                            Text(
                                text = "${if (delta > 0) "+" else ""}$delta",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.padding(vertical = 6.dp)
                            )
                        }
                    }
                }

                // Date & Time Timestamp Row
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    DatePickerField(
                        dateValue = dateStr,
                        onDateSelected = { dateStr = it },
                        label = "Date",
                        modifier = Modifier.weight(1.2f)
                    )

                    OutlinedTextField(
                        value = timeStr,
                        onValueChange = { timeStr = it },
                        label = { Text("Time (HH:mm)") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }

                // Weighing Method Dropdown
                var methodExpanded by remember { mutableStateOf(false) }
                ExposedDropdownMenuBox(
                    expanded = methodExpanded,
                    onExpandedChange = { methodExpanded = !methodExpanded }
                ) {
                    OutlinedTextField(
                        value = method,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Method *") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = methodExpanded) },
                        modifier = Modifier.fillMaxWidth().menuAnchor()
                    )
                    ExposedDropdownMenu(
                        expanded = methodExpanded,
                        onDismissRequest = { methodExpanded = false }
                    ) {
                        methods.forEach { m ->
                            DropdownMenuItem(
                                text = { Text(m) },
                                onClick = {
                                    method = m
                                    methodExpanded = false
                                }
                            )
                        }
                    }
                }

                // Body Condition Score (BCS)
                Text("Body Condition Score (BCS 1-5):", fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = Color.Gray)
                Row(
                    modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    bcsOptions.forEach { opt ->
                        val code = opt.substringBefore(" ")
                        val isSelected = bcsScore.startsWith(code)
                        FilterChip(
                            selected = isSelected,
                            onClick = { bcsScore = code },
                            label = { Text(opt, fontSize = 10.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = FarmGreenDark,
                                selectedLabelColor = Color.White
                            ),
                            modifier = Modifier.height(28.dp)
                        )
                    }
                }

                // Recurring Follow-up Cadence Setting
                Text("Next Scheduled Weigh-in:", fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = Color.Gray)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(7 to "In 7 Days", 14 to "In 14 Days", 30 to "In 30 Days").forEach { (days, label) ->
                        val isSelected = cadenceDays == days
                        FilterChip(
                            selected = isSelected,
                            onClick = { cadenceDays = days },
                            label = { Text(label, fontSize = 10.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = FarmGreenPrimary,
                                selectedLabelColor = Color.White
                            ),
                            modifier = Modifier.height(28.dp)
                        )
                    }
                }

                // Quick Note Chips
                Row(
                    modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    quickNotes.forEach { qn ->
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = Color(0xFFF1F5F9),
                            modifier = Modifier.clickable {
                                notes = if (notes.isBlank()) qn else "$notes, $qn"
                            }
                        ) {
                            Text(qn, fontSize = 10.sp, color = Color(0xFF334155), modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp))
                        }
                    }
                }

                // Notes input
                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Observations & Health Notes") },
                    placeholder = { Text("e.g. Weighing after grazing, healthy growth") },
                    minLines = 2,
                    maxLines = 3,
                    modifier = Modifier.fillMaxWidth().testTag("modal_weight_notes")
                )

                if (errorMessage != null) {
                    Text(text = errorMessage ?: "", color = Color(0xFFDC2626), fontSize = 12.sp)
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val weight = weightStr.toDoubleOrNull()
                    if (weight == null || weight <= 0.0) {
                        errorMessage = "Please enter a valid weight in kg."
                        return@Button
                    }
                    onSave(weight, dateStr, timeStr, method, bcsScore, notes.ifBlank { null }, cadenceDays)
                },
                colors = ButtonDefaults.buttonColors(containerColor = FarmGreenPrimary),
                modifier = Modifier.testTag("btn_modal_save_weight")
            ) {
                Text("Save Weight Log", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

// ==============================================================================
// MODAL DIALOG: Goat Weight History Logs
// ==============================================================================

@Composable
fun GoatWeightHistoryModalDialog(
    goat: Goat,
    logs: List<GoatWeight>,
    onDismiss: () -> Unit,
    onDeleteWeight: (String) -> Unit,
    onAddNewWeight: () -> Unit
) {
    val sdfDisplay = remember { SimpleDateFormat("yyyy-MM-dd • hh:mm a", Locale.US) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("Weight History Log", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Text("${goat.tag_c} • ${goat.breed_c} (${logs.size} entries)", fontSize = 11.sp, color = Color.Gray)
                }
                IconButton(onClick = onAddNewWeight) {
                    Icon(Icons.Default.AddCircle, contentDescription = "Add Entry", tint = FarmGreenDark)
                }
            }
        },
        text = {
            if (logs.isEmpty()) {
                Box(
                    modifier = Modifier.fillMaxWidth().padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("No weight records recorded yet.", color = Color.Gray, fontSize = 12.sp)
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxWidth().heightIn(max = 400.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(logs) { entry ->
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = Color(0xFFF8FAFC),
                            border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Text(
                                            text = "${String.format(Locale.US, "%.1f", entry.weight_kg_c)} kg",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 14.sp,
                                            color = Color(0xFF0F172A)
                                        )
                                        Surface(
                                            shape = RoundedCornerShape(4.dp),
                                            color = Color(0xFFE2E8F0)
                                        ) {
                                            Text(
                                                text = entry.method_c,
                                                fontSize = 9.sp,
                                                fontWeight = FontWeight.SemiBold,
                                                color = Color(0xFF475569),
                                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                            )
                                        }
                                    }
                                    Text(
                                        text = "Timestamp: ${sdfDisplay.format(Date(entry.timestamp))}",
                                        fontSize = 10.sp,
                                        color = Color(0xFF64748B)
                                    )
                                    if (!entry.notes_c.isNullOrBlank()) {
                                        Text(
                                            text = entry.notes_c,
                                            fontSize = 11.sp,
                                            color = Color(0xFF334155)
                                        )
                                    }
                                }
                                IconButton(
                                    onClick = { onDeleteWeight(entry.id) },
                                    modifier = Modifier.size(28.dp)
                                ) {
                                    Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color(0xFF94A3B8), modifier = Modifier.size(16.dp))
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(containerColor = FarmGreenPrimary)
            ) {
                Text("Close")
            }
        }
    )
}

// ==============================================================================
// COMPONENT: Metric Pill Tile
// ==============================================================================

@Composable
fun MetricPillTile(
    label: String,
    value: String,
    color: Color,
    bgColor: Color,
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null
) {
    Surface(
        shape = RoundedCornerShape(10.dp),
        color = bgColor,
        modifier = modifier.then(
            if (onClick != null) Modifier.clickable { onClick() } else Modifier
        )
    ) {
        Column(
            modifier = Modifier.padding(vertical = 8.dp, horizontal = 4.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(value, fontWeight = FontWeight.Bold, fontSize = 15.sp, color = color)
            Text(label, fontSize = 10.sp, color = color.copy(alpha = 0.85f), fontWeight = FontWeight.SemiBold)
        }
    }
}
