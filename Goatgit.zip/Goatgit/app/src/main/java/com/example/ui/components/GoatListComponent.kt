package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.offline.AppDatabase
import com.example.data.offline.GoatDao
import com.example.data.offline.GoatEntity
import com.example.data.supabase.Goat
import com.example.data.supabase.GoatRepository
import com.example.ui.theme.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

/**
 * 'Goat List' Component that retrieves all goat entries from the local Room database
 * and displays them in a scrollable list with basic details.
 *
 * Sourced directly from local Room database table `local_goats`.
 */
@Composable
fun GoatListComponent(
    repository: GoatRepository,
    modifier: Modifier = Modifier,
    onGoatClick: (Goat) -> Unit = {},
    onRecordWeight: (Goat) -> Unit = {},
    onViewProfile: (Goat) -> Unit = {},
    onAddNewGoat: () -> Unit = {},
    isSelectionMode: Boolean = false,
    selectedGoatIds: Set<String> = emptySet(),
    onToggleSelectGoat: (Goat) -> Unit = {},
    onEnterSelectionMode: () -> Unit = {},
    onExitSelectionMode: () -> Unit = {},
    onSelectAll: (List<Goat>) -> Unit = {},
    onDeselectAll: () -> Unit = {},
    onBatchHealthCheck: (List<Goat>) -> Unit = {},
    onBatchTreatment: (List<Goat>) -> Unit = {}
) {
    GoatListRoomContent(
        goatDao = repository.database.goatDao(),
        repository = repository,
        modifier = modifier,
        onGoatClick = onGoatClick,
        onRecordWeight = onRecordWeight,
        onViewProfile = onViewProfile,
        onAddNewGoat = onAddNewGoat,
        externalSelectionMode = isSelectionMode,
        externalSelectedIds = selectedGoatIds,
        onToggleSelectGoat = onToggleSelectGoat,
        onEnterSelectionMode = onEnterSelectionMode,
        onExitSelectionMode = onExitSelectionMode,
        onSelectAll = onSelectAll,
        onDeselectAll = onDeselectAll,
        onBatchHealthCheck = onBatchHealthCheck,
        onBatchTreatment = onBatchTreatment
    )
}

/**
 * Overload accepting direct AppDatabase instance.
 */
@Composable
fun GoatListComponent(
    database: AppDatabase,
    modifier: Modifier = Modifier,
    onGoatClick: (Goat) -> Unit = {},
    onRecordWeight: (Goat) -> Unit = {},
    onViewProfile: (Goat) -> Unit = {},
    onAddNewGoat: () -> Unit = {},
    isSelectionMode: Boolean = false,
    selectedGoatIds: Set<String> = emptySet(),
    onToggleSelectGoat: (Goat) -> Unit = {}
) {
    GoatListRoomContent(
        goatDao = database.goatDao(),
        repository = null,
        modifier = modifier,
        onGoatClick = onGoatClick,
        onRecordWeight = onRecordWeight,
        onViewProfile = onViewProfile,
        onAddNewGoat = onAddNewGoat,
        externalSelectionMode = isSelectionMode,
        externalSelectedIds = selectedGoatIds,
        onToggleSelectGoat = onToggleSelectGoat
    )
}

/**
 * Overload accepting direct GoatDao from Room.
 */
@Composable
fun GoatListComponent(
    goatDao: GoatDao,
    modifier: Modifier = Modifier,
    onGoatClick: (Goat) -> Unit = {},
    onRecordWeight: (Goat) -> Unit = {},
    onViewProfile: (Goat) -> Unit = {},
    onAddNewGoat: () -> Unit = {},
    isSelectionMode: Boolean = false,
    selectedGoatIds: Set<String> = emptySet(),
    onToggleSelectGoat: (Goat) -> Unit = {}
) {
    GoatListRoomContent(
        goatDao = goatDao,
        repository = null,
        modifier = modifier,
        onGoatClick = onGoatClick,
        onRecordWeight = onRecordWeight,
        onViewProfile = onViewProfile,
        onAddNewGoat = onAddNewGoat,
        externalSelectionMode = isSelectionMode,
        externalSelectedIds = selectedGoatIds,
        onToggleSelectGoat = onToggleSelectGoat
    )
}

/**
 * Internal implementation that observes Room database Flow reactively.
 */
@Composable
private fun GoatListRoomContent(
    goatDao: GoatDao,
    repository: GoatRepository? = null,
    modifier: Modifier = Modifier,
    onGoatClick: (Goat) -> Unit,
    onRecordWeight: (Goat) -> Unit,
    onViewProfile: (Goat) -> Unit,
    onAddNewGoat: () -> Unit,
    externalSelectionMode: Boolean = false,
    externalSelectedIds: Set<String> = emptySet(),
    onToggleSelectGoat: ((Goat) -> Unit)? = null,
    onEnterSelectionMode: (() -> Unit)? = null,
    onExitSelectionMode: (() -> Unit)? = null,
    onSelectAll: ((List<Goat>) -> Unit)? = null,
    onDeselectAll: (() -> Unit)? = null,
    onBatchHealthCheck: ((List<Goat>) -> Unit)? = null,
    onBatchTreatment: ((List<Goat>) -> Unit)? = null
) {
    // 1. Reactive flow observation directly from Room database
    val roomGoats by goatDao.getAllGoatsFlow().collectAsStateWithLifecycle(initialValue = emptyList())

    // Convert Room entities to Domain models
    val allGoats = remember(roomGoats) {
        roomGoats.map { entity ->
            Goat(
                id = entity.id,
                name = entity.name,
                tag_c = entity.tag_c,
                breed_c = entity.breed_c,
                sex_c = entity.sex_c,
                status_c = entity.status_c,
                birth_date_c = entity.birth_date_c,
                weight_kg_c = entity.weight_kg_c,
                dam_c = entity.dam_c,
                sire_c = entity.sire_c,
                source_c = entity.source_c,
                purchase_date_c = entity.purchase_date_c,
                purchase_cost_c = entity.purchase_cost_c,
                farm_location_c = entity.farm_location_c,
                color_c = entity.color_c,
                notes_c = entity.notes_c,
                created_at = entity.created_at,
                origin_c = entity.origin_c ?: "FARM_BORN",
                photo_url_c = entity.photo_url_c,
                health_status_c = entity.health_status_c ?: "Healthy"
            )
        }
    }

    // Local Search & Filter State
    var searchQuery by remember { mutableStateOf("") }
    var selectedFilter by remember { mutableStateOf("All") } // All, Does, Bucks, Kids, Pregnant, Lactating
    var selectedSort by remember { mutableStateOf("Tag") } // Tag, Weight, Age

    // Selection Mode State (Internal fallback if not managed externally)
    var internalSelectionMode by remember { mutableStateOf(false) }
    var internalSelectedIds by remember { mutableStateOf(setOf<String>()) }
    var showLocalBatchHealthDialog by remember { mutableStateOf(false) }
    var showLocalBatchTreatmentDialog by remember { mutableStateOf(false) }

    val effectiveSelectionMode = externalSelectionMode || internalSelectionMode
    val effectiveSelectedIds = if (externalSelectionMode) externalSelectedIds else internalSelectedIds

    val filteredGoats = remember(allGoats, searchQuery, selectedFilter, selectedSort) {
        val query = searchQuery.trim().lowercase()
        allGoats
            .filter { goat ->
                val matchesSearch = query.isEmpty() ||
                    goat.tag_c.lowercase().contains(query) ||
                    goat.name.lowercase().contains(query) ||
                    goat.breed_c.lowercase().contains(query) ||
                    (goat.farm_location_c?.lowercase()?.contains(query) == true)

                val matchesFilter = when (selectedFilter) {
                    "Does" -> goat.sex_c.equals("Doe", ignoreCase = true)
                    "Bucks" -> goat.sex_c.equals("Buck", ignoreCase = true)
                    "Kids" -> goat.sex_c.equals("Kid", ignoreCase = true) || goat.status_c.equals("Kid", ignoreCase = true)
                    "Pregnant" -> goat.status_c.equals("Pregnant", ignoreCase = true)
                    "Lactating" -> goat.status_c.equals("Lactating", ignoreCase = true)
                    else -> true
                }

                matchesSearch && matchesFilter
            }
            .sortedWith { a, b ->
                when (selectedSort) {
                    "Weight" -> (b.weight_kg_c ?: 0.0).compareTo(a.weight_kg_c ?: 0.0)
                    "Age" -> (b.birth_date_c ?: "").compareTo(a.birth_date_c ?: "")
                    else -> a.tag_c.compareTo(b.tag_c, ignoreCase = true)
                }
            }
    }

    Card(
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = modifier
            .fillMaxWidth()
            .testTag("goat_list_component")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            // Header: Component Title, Selection Mode Toggle, and Count Badge
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Pets,
                            contentDescription = null,
                            tint = Color(0xFF003893),
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "GOAT HERD LIST",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF003893),
                            letterSpacing = 0.5.sp
                        )
                    }
                    Text(
                        text = "Sourced directly from local Room Database",
                        style = MaterialTheme.typography.labelSmall,
                        color = Color.Gray,
                        fontSize = 11.sp
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    // Multi-select toggle button
                    IconButton(
                        onClick = {
                            if (effectiveSelectionMode) {
                                onExitSelectionMode?.invoke()
                                internalSelectionMode = false
                                internalSelectedIds = emptySet()
                            } else {
                                onEnterSelectionMode?.invoke()
                                internalSelectionMode = true
                            }
                        },
                        modifier = Modifier.testTag("btn_component_multi_select")
                    ) {
                        Icon(
                            imageVector = if (effectiveSelectionMode) Icons.Default.Close else Icons.Default.Checklist,
                            contentDescription = if (effectiveSelectionMode) "Cancel Selection" else "Enter Selection Mode",
                            tint = if (effectiveSelectionMode) FarmError else Color(0xFF003893)
                        )
                    }

                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = if (effectiveSelectionMode) Color(0xFFE8F5E9) else Color(0xFFE8F0FE),
                        modifier = Modifier.padding(start = 2.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .clip(CircleShape)
                                    .background(if (effectiveSelectionMode) FarmGreenDark else Color(0xFF2E7D32))
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (effectiveSelectionMode) "${effectiveSelectedIds.size} Selected" else "${allGoats.size} Records",
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp,
                                color = if (effectiveSelectionMode) FarmGreenDark else Color(0xFF003893)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Search Bar
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("goat_list_search_input"),
                placeholder = { Text("Search by Tag ID, Name, Breed, Barn...", fontSize = 13.sp) },
                leadingIcon = {
                    Icon(Icons.Default.Search, contentDescription = "Search", tint = Color.Gray)
                },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { searchQuery = "" }) {
                            Icon(Icons.Default.Clear, contentDescription = "Clear", tint = Color.Gray)
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(10.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    unfocusedContainerColor = Color(0xFFF8F9FA),
                    focusedContainerColor = Color.White
                )
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Filter Chips (All, Does, Bucks, Kids, Pregnant, Lactating)
            val filters = listOf("All", "Does", "Bucks", "Kids", "Pregnant", "Lactating")
            LazyRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                items(filters) { filter ->
                    val isSelected = selectedFilter == filter
                    FilterChip(
                        selected = isSelected,
                        onClick = { selectedFilter = filter },
                        label = { Text(filter, fontSize = 12.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = Color(0xFF003893),
                            selectedLabelColor = Color.White
                        )
                    )
                }
            }

            // Selection Controls Banner
            if (effectiveSelectionMode) {
                Spacer(modifier = Modifier.height(6.dp))
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = Color(0xFFF1F8E9),
                    border = androidx.compose.foundation.BorderStroke(1.dp, FarmGreenPrimary.copy(alpha = 0.5f)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("selection_mode_bar")
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 10.dp, vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "${effectiveSelectedIds.size} of ${filteredGoats.size} selected",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = FarmGreenDark
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            TextButton(
                                onClick = {
                                    if (onSelectAll != null) {
                                        onSelectAll(filteredGoats)
                                    } else {
                                        internalSelectedIds = filteredGoats.map { it.id }.toSet()
                                    }
                                },
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                modifier = Modifier.testTag("btn_select_all_goats")
                            ) {
                                Text("Select All", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                            TextButton(
                                onClick = {
                                    if (onDeselectAll != null) {
                                        onDeselectAll()
                                    } else {
                                        internalSelectedIds = emptySet()
                                    }
                                },
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                modifier = Modifier.testTag("btn_deselect_all_goats")
                            ) {
                                Text("Clear", fontSize = 11.sp, color = Color.Gray)
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Scrollable List of Goats
            if (filteredGoats.isEmpty()) {
                // Empty State
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFF8F9FA)),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Pets,
                            contentDescription = null,
                            tint = Color.Gray,
                            modifier = Modifier.size(40.dp)
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = if (allGoats.isEmpty()) "No goats found in local Room database" else "No matching goats found",
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 14.sp,
                            color = Color(0xFF37474F)
                        )
                        Text(
                            text = if (allGoats.isEmpty()) "Use the button below to add your first goat to the local database." else "Try adjusting your search query or active filter.",
                            fontSize = 12.sp,
                            color = Color.Gray,
                            modifier = Modifier.padding(top = 4.dp)
                        )
                        if (allGoats.isEmpty()) {
                            Spacer(modifier = Modifier.height(14.dp))
                            Button(
                                onClick = onAddNewGoat,
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF003893)),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.testTag("empty_state_add_goat_btn")
                            ) {
                                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Add New Goat")
                            }
                        }
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 520.dp)
                        .testTag("goat_list_scrollable"),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(filteredGoats, key = { it.id }) { goat ->
                        val isSelected = effectiveSelectedIds.contains(goat.id)
                        GoatItemCard(
                            goat = goat,
                            isSelectionMode = effectiveSelectionMode,
                            isSelected = isSelected,
                            onToggleSelect = {
                                if (onToggleSelectGoat != null) {
                                    onToggleSelectGoat(goat)
                                } else {
                                    internalSelectedIds = if (internalSelectedIds.contains(goat.id)) {
                                        internalSelectedIds - goat.id
                                    } else {
                                        internalSelectedIds + goat.id
                                    }
                                }
                            },
                            onClick = {
                                if (effectiveSelectionMode) {
                                    if (onToggleSelectGoat != null) {
                                        onToggleSelectGoat(goat)
                                    } else {
                                        internalSelectedIds = if (internalSelectedIds.contains(goat.id)) {
                                            internalSelectedIds - goat.id
                                        } else {
                                            internalSelectedIds + goat.id
                                        }
                                    }
                                } else {
                                    onGoatClick(goat)
                                }
                            },
                            onRecordWeight = { onRecordWeight(goat) },
                            onViewProfile = { onViewProfile(goat) }
                        )
                    }
                }

                // Batch Actions Bar when goats are selected
                if (effectiveSelectedIds.isNotEmpty()) {
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = Color(0xFFF1F8E9),
                        border = androidx.compose.foundation.BorderStroke(1.5.dp, FarmGreenPrimary),
                        shadowElevation = 4.dp,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 10.dp)
                            .testTag("batch_action_bar")
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "${effectiveSelectedIds.size} Selected",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp,
                                    color = FarmGreenDark
                                )
                                Text(
                                    text = "Apply batch action",
                                    fontSize = 10.sp,
                                    color = Color.Gray
                                )
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(
                                    onClick = {
                                        val selected = allGoats.filter { effectiveSelectedIds.contains(it.id) }
                                        if (onBatchHealthCheck != null) {
                                            onBatchHealthCheck(selected)
                                        } else if (repository != null) {
                                            showLocalBatchHealthDialog = true
                                        }
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = FarmGreenPrimary),
                                    shape = RoundedCornerShape(8.dp),
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                                    modifier = Modifier.testTag("btn_batch_health_check")
                                ) {
                                    Icon(Icons.Default.HealthAndSafety, contentDescription = null, modifier = Modifier.size(15.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Health Check", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }

                                Button(
                                    onClick = {
                                        val selected = allGoats.filter { effectiveSelectedIds.contains(it.id) }
                                        if (onBatchTreatment != null) {
                                            onBatchTreatment(selected)
                                        } else if (repository != null) {
                                            showLocalBatchTreatmentDialog = true
                                        }
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1565C0)),
                                    shape = RoundedCornerShape(8.dp),
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                                    modifier = Modifier.testTag("btn_batch_treatment")
                                ) {
                                    Icon(Icons.Default.Medication, contentDescription = null, modifier = Modifier.size(15.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Treatment", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Local dialogs if triggered from component directly
    if (showLocalBatchHealthDialog && repository != null) {
        val selected = allGoats.filter { effectiveSelectedIds.contains(it.id) }
        BatchHealthCheckDialog(
            selectedGoats = selected,
            repository = repository,
            onDismiss = { showLocalBatchHealthDialog = false },
            onSuccess = {
                showLocalBatchHealthDialog = false
                internalSelectedIds = emptySet()
                internalSelectionMode = false
            }
        )
    }

    if (showLocalBatchTreatmentDialog && repository != null) {
        val selected = allGoats.filter { effectiveSelectedIds.contains(it.id) }
        BatchTreatmentDialog(
            selectedGoats = selected,
            repository = repository,
            onDismiss = { showLocalBatchTreatmentDialog = false },
            onSuccess = {
                showLocalBatchTreatmentDialog = false
                internalSelectedIds = emptySet()
                internalSelectionMode = false
            }
        )
    }
}

/**
 * Individual Goat Card in the scrollable list displaying basic details:
 * - Ear Tag / UID
 * - Name
 * - Breed
 * - Gender / Sex (avatar / icon)
 * - Status (Active, Pregnant, Lactating, Quarantine, Sold, etc.)
 * - Birth Date / Age
 * - Weight (kg)
 * - Barn / Pen Location
 */
@Composable
fun GoatItemCard(
    goat: Goat,
    onClick: () -> Unit,
    onRecordWeight: () -> Unit = {},
    onViewProfile: () -> Unit = {},
    modifier: Modifier = Modifier,
    isSelectionMode: Boolean = false,
    isSelected: Boolean = false,
    onToggleSelect: () -> Unit = {}
) {
    val sexColor = when (goat.sex_c.lowercase(Locale.ROOT)) {
        "buck" -> Color(0xFF1565C0) // Blue
        "doe" -> Color(0xFFC2185B) // Pink / Magenta
        "kid" -> Color(0xFF00897B) // Teal
        else -> Color(0xFF5E35B1) // Purple (wether)
    }

    val statusBgColor = when (goat.status_c.lowercase(Locale.ROOT)) {
        "active" -> Color(0xFFE8F5E9)
        "pregnant" -> Color(0xFFF3E5F5)
        "lactating" -> Color(0xFFE0F7FA)
        "quarantine" -> Color(0xFFFFF3E0)
        "sold" -> Color(0xFFECEFF1)
        "deceased" -> Color(0xFFFFEBEE)
        else -> Color(0xFFF5F5F5)
    }

    val statusTextColor = when (goat.status_c.lowercase(Locale.ROOT)) {
        "active" -> Color(0xFF2E7D32)
        "pregnant" -> Color(0xFF8E24AA)
        "lactating" -> Color(0xFF00838F)
        "quarantine" -> Color(0xFFE65100)
        "sold" -> Color(0xFF546E7A)
        "deceased" -> Color(0xFFC62828)
        else -> Color(0xFF424242)
    }

    Surface(
        onClick = if (isSelectionMode) onToggleSelect else onClick,
        shape = RoundedCornerShape(12.dp),
        color = if (isSelected) Color(0xFFF1F8E9) else Color(0xFFFBFBFA),
        border = if (isSelected) androidx.compose.foundation.BorderStroke(2.dp, FarmGreenPrimary) else androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFEEEEEE)),
        modifier = modifier
            .fillMaxWidth()
            .testTag("goat_card_${goat.tag_c}")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp)
        ) {
            // Row 1: Checkbox (if in selection mode) | Tag Badge | Breed Pill | Status Chip
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (isSelectionMode) {
                        Checkbox(
                            checked = isSelected,
                            onCheckedChange = { onToggleSelect() },
                            colors = CheckboxDefaults.colors(checkedColor = FarmGreenDark),
                            modifier = Modifier
                                .size(24.dp)
                                .padding(end = 4.dp)
                                .testTag("checkbox_select_${goat.tag_c}")
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                    }
                    // Tag ID Pill
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = Color(0xFF003893)
                    ) {
                        Text(
                            text = goat.tag_c,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            color = Color.White,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(6.dp))

                    // Breed Pill
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = Color(0xFFF0F4F8)
                    ) {
                        Text(
                            text = goat.breed_c,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium,
                            color = Color(0xFF37474F),
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }

                // Status Badge
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = statusBgColor
                ) {
                    Text(
                        text = goat.status_c,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = statusTextColor,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Row 2: Goat Name & Sex Indicator
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Sex avatar icon
                Box(
                    modifier = Modifier
                        .size(28.dp)
                        .clip(CircleShape)
                        .background(sexColor.copy(alpha = 0.12f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (goat.sex_c.equals("Buck", ignoreCase = true)) Icons.Default.Male else Icons.Default.Female,
                        contentDescription = goat.sex_c,
                        tint = sexColor,
                        modifier = Modifier.size(16.dp)
                    )
                }

                Spacer(modifier = Modifier.width(8.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = goat.name,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF212121),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = "${goat.sex_c} • ${goat.farm_location_c ?: "Main Shed"}",
                        fontSize = 11.sp,
                        color = Color.Gray
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Row 3: Basic Details Strip (DOB/Age, Weight, Pen)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color.White, RoundedCornerShape(8.dp))
                    .padding(horizontal = 10.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Age / Birth Date
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.CalendarToday,
                        contentDescription = null,
                        tint = Color.Gray,
                        modifier = Modifier.size(12.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = calculateAgeString(goat.birth_date_c),
                        fontSize = 11.sp,
                        color = Color(0xFF455A64)
                    )
                }

                // Weight
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Scale,
                        contentDescription = null,
                        tint = Color(0xFF00796B),
                        modifier = Modifier.size(13.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (goat.weight_kg_c != null && goat.weight_kg_c > 0) "${goat.weight_kg_c} kg" else "No weight",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = if (goat.weight_kg_c != null) Color(0xFF00796B) else Color.Gray
                    )
                }

                // Quick Profile Link
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.clickable { onViewProfile() }
                ) {
                    Text(
                        text = "View",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF003893)
                    )
                    Icon(
                        imageVector = Icons.Default.ChevronRight,
                        contentDescription = null,
                        tint = Color(0xFF003893),
                        modifier = Modifier.size(14.dp)
                    )
                }
            }
        }
    }
}

/**
 * Calculates human-readable age string from yyyy-MM-dd date string.
 */
private fun calculateAgeString(birthDate: String?): String {
    if (birthDate.isNullOrBlank()) return "Age: N/A"
    return try {
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        val birth = sdf.parse(birthDate) ?: return "DOB: $birthDate"
        val now = Date()
        val diffMs = now.time - birth.time
        if (diffMs < 0) return "DOB: $birthDate"
        val days = TimeUnit.MILLISECONDS.toDays(diffMs)
        val months = (days / 30.4375).toInt()
        val years = months / 12
        val remainingMonths = months % 12

        when {
            years > 0 && remainingMonths > 0 -> "$years yr $remainingMonths mo"
            years > 0 -> "$years yr"
            months > 0 -> "$months mo"
            days > 0 -> "$days d"
            else -> "Newborn"
        }
    } catch (_: Exception) {
        "DOB: $birthDate"
    }
}
