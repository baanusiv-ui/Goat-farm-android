package com.example.data.offline

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface FinancialAccountDao {
    @Query("SELECT * FROM local_financial_accounts WHERE is_active = 1 ORDER BY account_name ASC")
    fun getAllAccountsFlow(): Flow<List<FinancialAccountEntity>>

    @Query("SELECT * FROM local_financial_accounts WHERE is_active = 1 ORDER BY account_name ASC")
    suspend fun getAllAccounts(): List<FinancialAccountEntity>

    @Query("SELECT * FROM local_financial_accounts WHERE id = :id LIMIT 1")
    suspend fun getAccountById(id: String): FinancialAccountEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(account: FinancialAccountEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(accounts: List<FinancialAccountEntity>)

    @Query("UPDATE local_financial_accounts SET current_balance = :newBalance, updated_at = :timestamp WHERE id = :id")
    suspend fun updateBalance(id: String, newBalance: Double, timestamp: Long = System.currentTimeMillis())

    @Query("DELETE FROM local_financial_accounts WHERE id = :id")
    suspend fun deleteById(id: String)
}

@Dao
interface AccountTransactionDao {
    @Query("SELECT * FROM local_account_transactions ORDER BY date DESC, created_at DESC")
    fun getAllTransactionsFlow(): Flow<List<AccountTransactionEntity>>

    @Query("SELECT * FROM local_account_transactions ORDER BY date DESC, created_at DESC")
    suspend fun getAllTransactions(): List<AccountTransactionEntity>

    @Query("SELECT * FROM local_account_transactions WHERE account_id = :accountId OR to_account_id = :accountId ORDER BY date DESC")
    suspend fun getTransactionsByAccount(accountId: String): List<AccountTransactionEntity>

    @Query("SELECT * FROM local_account_transactions WHERE affects_pnl = 1 ORDER BY date DESC")
    suspend fun getPnlTransactions(): List<AccountTransactionEntity>

    @Query("SELECT * FROM local_account_transactions WHERE transaction_type = 'TRANSFER' ORDER BY date DESC")
    suspend fun getTransfers(): List<AccountTransactionEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(transaction: AccountTransactionEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(transactions: List<AccountTransactionEntity>)

    @Query("DELETE FROM local_account_transactions WHERE id = :id")
    suspend fun deleteById(id: String)
}

@Dao
interface RecurringExpenseDao {
    @Query("SELECT * FROM local_recurring_expenses WHERE is_active = 1 ORDER BY next_due_date ASC")
    fun getAllRecurringFlow(): Flow<List<RecurringExpenseEntity>>

    @Query("SELECT * FROM local_recurring_expenses ORDER BY next_due_date ASC")
    suspend fun getAllRecurring(): List<RecurringExpenseEntity>

    @Query("SELECT * FROM local_recurring_expenses WHERE id = :id LIMIT 1")
    suspend fun getById(id: String): RecurringExpenseEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(expense: RecurringExpenseEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(expenses: List<RecurringExpenseEntity>)

    @Query("DELETE FROM local_recurring_expenses WHERE id = :id")
    suspend fun deleteById(id: String)
}

@Dao
interface ElectricityDao {
    // Connections
    @Query("SELECT * FROM local_electricity_connections WHERE is_active = 1 ORDER BY connection_name ASC")
    fun getAllConnectionsFlow(): Flow<List<ElectricityConnectionEntity>>

    @Query("SELECT * FROM local_electricity_connections ORDER BY connection_name ASC")
    suspend fun getAllConnections(): List<ElectricityConnectionEntity>

    @Query("SELECT * FROM local_electricity_connections WHERE id = :id LIMIT 1")
    suspend fun getConnectionById(id: String): ElectricityConnectionEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertConnection(conn: ElectricityConnectionEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllConnections(conns: List<ElectricityConnectionEntity>)

    @Query("DELETE FROM local_electricity_connections WHERE id = :id")
    suspend fun deleteConnectionById(id: String)

    // Bills
    @Query("SELECT * FROM local_electricity_bills ORDER BY bill_date DESC")
    fun getAllBillsFlow(): Flow<List<ElectricityBillEntity>>

    @Query("SELECT * FROM local_electricity_bills ORDER BY bill_date DESC")
    suspend fun getAllBills(): List<ElectricityBillEntity>

    @Query("SELECT * FROM local_electricity_bills WHERE connection_id = :connId ORDER BY bill_date DESC")
    suspend fun getBillsForConnection(connId: String): List<ElectricityBillEntity>

    @Query("SELECT * FROM local_electricity_bills WHERE id = :id LIMIT 1")
    suspend fun getBillById(id: String): ElectricityBillEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBill(bill: ElectricityBillEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllBills(bills: List<ElectricityBillEntity>)

    @Query("DELETE FROM local_electricity_bills WHERE id = :id")
    suspend fun deleteBillById(id: String)
}

@Dao
interface LoanDao {
    // Loans
    @Query("SELECT * FROM local_loans ORDER BY created_at DESC")
    fun getAllLoansFlow(): Flow<List<LoanEntity>>

    @Query("SELECT * FROM local_loans ORDER BY created_at DESC")
    suspend fun getAllLoans(): List<LoanEntity>

    @Query("SELECT * FROM local_loans WHERE id = :id LIMIT 1")
    suspend fun getLoanById(id: String): LoanEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLoan(loan: LoanEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllLoans(loans: List<LoanEntity>)

    @Query("DELETE FROM local_loans WHERE id = :id")
    suspend fun deleteLoanById(id: String)

    // Schedules
    @Query("SELECT * FROM local_loan_schedules WHERE loan_id = :loanId ORDER BY emi_number ASC")
    suspend fun getSchedulesForLoan(loanId: String): List<LoanScheduleEntity>

    @Query("SELECT * FROM local_loan_schedules WHERE status != 'PAID' ORDER BY due_date ASC")
    suspend fun getUpcomingEmiSchedules(): List<LoanScheduleEntity>

    @Query("SELECT * FROM local_loan_schedules WHERE id = :id LIMIT 1")
    suspend fun getScheduleById(id: String): LoanScheduleEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSchedule(schedule: LoanScheduleEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllSchedules(schedules: List<LoanScheduleEntity>)

    @Query("DELETE FROM local_loan_schedules WHERE loan_id = :loanId")
    suspend fun deleteSchedulesForLoan(loanId: String)
}

@Dao
interface SupplierDao {
    // Suppliers
    @Query("SELECT * FROM local_suppliers WHERE is_active = 1 ORDER BY name ASC")
    fun getAllSuppliersFlow(): Flow<List<SupplierEntity>>

    @Query("SELECT * FROM local_suppliers ORDER BY name ASC")
    suspend fun getAllSuppliers(): List<SupplierEntity>

    @Query("SELECT * FROM local_suppliers WHERE id = :id LIMIT 1")
    suspend fun getSupplierById(id: String): SupplierEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSupplier(supplier: SupplierEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllSuppliers(suppliers: List<SupplierEntity>)

    @Query("UPDATE local_suppliers SET current_outstanding = :newOutstanding, updated_at = :timestamp WHERE id = :id")
    suspend fun updateOutstanding(id: String, newOutstanding: Double, timestamp: Long = System.currentTimeMillis())

    @Query("DELETE FROM local_suppliers WHERE id = :id")
    suspend fun deleteSupplierById(id: String)

    // Invoices
    @Query("SELECT * FROM local_supplier_invoices ORDER BY invoice_date DESC")
    fun getAllInvoicesFlow(): Flow<List<SupplierInvoiceEntity>>

    @Query("SELECT * FROM local_supplier_invoices ORDER BY invoice_date DESC")
    suspend fun getAllInvoices(): List<SupplierInvoiceEntity>

    @Query("SELECT * FROM local_supplier_invoices WHERE supplier_id = :supplierId ORDER BY invoice_date DESC")
    suspend fun getInvoicesForSupplier(supplierId: String): List<SupplierInvoiceEntity>

    @Query("SELECT * FROM local_supplier_invoices WHERE id = :id LIMIT 1")
    suspend fun getInvoiceById(id: String): SupplierInvoiceEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertInvoice(invoice: SupplierInvoiceEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllInvoices(invoices: List<SupplierInvoiceEntity>)

    @Query("DELETE FROM local_supplier_invoices WHERE id = :id")
    suspend fun deleteInvoiceById(id: String)

    // Payments
    @Query("SELECT * FROM local_supplier_payments ORDER BY payment_date DESC")
    suspend fun getAllPayments(): List<SupplierPaymentEntity>

    @Query("SELECT * FROM local_supplier_payments WHERE supplier_id = :supplierId ORDER BY payment_date DESC")
    suspend fun getPaymentsForSupplier(supplierId: String): List<SupplierPaymentEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPayment(payment: SupplierPaymentEntity)
}

@Dao
interface GstDao {
    @Query("SELECT * FROM local_gst_settings WHERE id = 'default_gst_settings' LIMIT 1")
    suspend fun getSettings(): GstSettingsEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveSettings(settings: GstSettingsEntity)
}

@Dao
interface EWayBillDao {
    @Query("SELECT * FROM local_eway_bills ORDER BY created_at DESC")
    fun getAllEWayBillsFlow(): Flow<List<EWayBillEntity>>

    @Query("SELECT * FROM local_eway_bills ORDER BY created_at DESC")
    suspend fun getAllEWayBills(): List<EWayBillEntity>

    @Query("SELECT * FROM local_eway_bills WHERE id = :id LIMIT 1")
    suspend fun getById(id: String): EWayBillEntity?

    @Query("SELECT * FROM local_eway_bills WHERE invoice_id = :invId LIMIT 1")
    suspend fun getByInvoiceId(invId: String): EWayBillEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(bill: EWayBillEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(bills: List<EWayBillEntity>)

    @Query("DELETE FROM local_eway_bills WHERE id = :id")
    suspend fun deleteById(id: String)
}
