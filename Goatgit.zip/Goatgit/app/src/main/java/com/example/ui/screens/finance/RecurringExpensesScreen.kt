package com.example.ui.screens.finance

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.supabase.*
import com.example.ui.components.DatePickerField
import com.example.ui.theme.*
import com.example.util.CurrencyUtils
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RecurringExpensesScreen(
    repository: GoatRepository,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler { onNavigateBack() }

    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val dateFormat = remember { SimpleDateFormat("yyyy-MM-dd", Locale.US) }
    val today = remember { dateFormat.format(Date()) }

    var recurringList by remember { mutableStateOf<List<RecurringExpense>>(emptyList()) }
    var accounts by remember { mutableStateOf<List<FinancialAccount>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }

    var showAddDialog by remember { mutableStateOf(false) }
    var payingExpense by remember { mutableStateOf<RecurringExpense?>(null) }
    var selectedTab by remember { mutableStateOf(0) } // 0: Upcoming, 1: Active Schedules, 2: Monthly Summary

    fun loadData() {
        isLoading = true
        coroutineScope.launch {
            val recRes = repository.finance.getRecurringExpenses()
            if (recRes.isSuccess) {
                recurringList = recRes.getOrThrow()
            }
            val accRes = repository.finance.getAccounts()
            if (accRes.isSuccess) {
                accounts = accRes.getOrThrow()
            }
            isLoading = false
        }
    }

    LaunchedEffect(Unit) {
        loadData()
    }

    val upcoming = remember(recurringList) {
        recurringList.filter { it.is_active }.sortedBy { it.next_due_date }
    }

    val overdueCount = remember(upcoming, today) {
        upcoming.count { it.next_due_date < today }
    }

    val totalMonthlyBudget = remember(recurringList) {
        recurringList.filter { it.is_active }.sumOf {
            when (it.frequency.uppercase()) {
                "DAILY" -> it.amount * 30
                "WEEKLY" -> it.amount * 4
                "MONTHLY" -> it.amount
                "QUARTERLY" -> it.amount / 3
                "HALF_YEARLY" -> it.amount / 6
                "YEARLY" -> it.amount / 12
                else -> it.amount
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "Recurring Expenses",
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp
                        )
                        Text(
                            text = "EB, Labour, Rent, Subscriptions & EMI Schedules",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack, modifier = Modifier.testTag("recurring_btn_back")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(onClick = { loadData() }, modifier = Modifier.testTag("recurring_btn_refresh")) {
                        Icon(Icons.Default.Refresh, contentDescription = "Refresh")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.White)
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { showAddDialog = true },
                containerColor = FarmGreenDark,
                contentColor = Color.White,
                icon = { Icon(Icons.Default.Add, contentDescription = null) },
                text = { Text("New Recurring", fontWeight = FontWeight.Bold) },
                modifier = Modifier.testTag("btn_add_recurring")
            )
        },
        containerColor = Color(0xFFF8F9FA),
        modifier = modifier
    ) { innerPadding ->
        if (isLoading) {
            Box(modifier = Modifier.fillMaxSize().padding(innerPadding), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = FarmGreenDark)
            }
        } else {
            Column(modifier = Modifier.fillMaxSize().padding(innerPadding)) {
                // Tab Row
                TabRow(
                    selectedTabIndex = selectedTab,
                    containerColor = Color.White,
                    contentColor = FarmGreenDark
                ) {
                    Tab(
                        selected = selectedTab == 0,
                        onClick = { selectedTab = 0 },
                        text = {
                            Text(
                                text = "Upcoming Due (${upcoming.size})",
                                fontWeight = if (selectedTab == 0) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                    )
                    Tab(
                        selected = selectedTab == 1,
                        onClick = { selectedTab = 1 },
                        text = {
                            Text(
                                text = "All Schedules",
                                fontWeight = if (selectedTab == 1) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                    )
                    Tab(
                        selected = selectedTab == 2,
                        onClick = { selectedTab = 2 },
                        text = {
                            Text(
                                text = "Monthly Budget",
                                fontWeight = if (selectedTab == 2) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                    )
                }

                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    item { Spacer(modifier = Modifier.height(6.dp)) }

                    // Overdue Warning Banner
                    if (overdueCount > 0) {
                        item {
                            Card(
                                colors = CardDefaults.cardColors(containerColor = Color(0xFFFFEBEE)),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.fillMaxWidth().testTag("recurring_overdue_banner")
                            ) {
                                Row(
                                    modifier = Modifier.padding(14.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(Icons.Default.Warning, contentDescription = null, tint = FarmError)
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column {
                                        Text(
                                            text = "$overdueCount Recurring Expenses Overdue!",
                                            fontWeight = FontWeight.Bold,
                                            color = FarmError,
                                            fontSize = 14.sp
                                        )
                                        Text(
                                            text = "Tap 'Pay Now' to record the payment and update account ledger.",
                                            fontSize = 11.sp,
                                            color = Color.DarkGray
                                        )
                                    }
                                }
                            }
                        }
                    }

                    if (selectedTab == 0 || selectedTab == 1) {
                        val displayList = if (selectedTab == 0) upcoming else recurringList
                        if (displayList.isEmpty()) {
                            item {
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = Color.White),
                                    modifier = Modifier.fillMaxWidth().padding(vertical = 20.dp)
                                ) {
                                    Box(modifier = Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                                        Text("No recurring expenses found. Tap '+ New Recurring' to add EB, rent, salary, etc.", color = Color.Gray, fontSize = 13.sp)
                                    }
                                }
                            }
                        } else {
                            items(displayList) { item ->
                                RecurringExpenseCard(
                                    item = item,
                                    today = today,
                                    onPayNow = { payingExpense = item }
                                )
                            }
                        }
                    } else {
                        // Monthly Summary
                        item {
                            Card(
                                colors = CardDefaults.cardColors(containerColor = Color.White),
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)
                            ) {
                                Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                    Text("Estimated Monthly Recurring Commitment", fontSize = 13.sp, color = Color.Gray)
                                    Text(
                                        text = CurrencyUtils.formatInr(totalMonthlyBudget),
                                        fontSize = 26.sp,
                                        fontWeight = FontWeight.ExtraBold,
                                        color = FarmGreenDark
                                    )
                                    HorizontalDivider(color = Color(0xFFEEEEEE))
                                    Text("Category Commitments:", fontWeight = FontWeight.Bold, fontSize = 13.sp)

                                    val byCat = recurringList.filter { it.is_active }.groupBy { it.category }
                                    byCat.forEach { (cat, list) ->
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Text(cat, fontSize = 12.sp)
                                            val sum = list.sumOf { it.amount }
                                            Text(CurrencyUtils.formatInr(sum), fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                                        }
                                    }
                                }
                            }
                        }
                    }

                    item { Spacer(modifier = Modifier.height(72.dp)) }
                }
            }
        }
    }

    // Add Recurring Dialog
    if (showAddDialog) {
        AddRecurringExpenseDialog(
            accounts = accounts,
            onDismiss = { showAddDialog = false },
            onSave = { expense ->
                showAddDialog = false
                coroutineScope.launch {
                    val res = repository.finance.addRecurringExpense(expense)
                    if (res.isSuccess) {
                        Toast.makeText(context, "Recurring expense created & synced", Toast.LENGTH_SHORT).show()
                        loadData()
                    } else {
                        Toast.makeText(context, "Failed: ${res.exceptionOrNull()?.message}", Toast.LENGTH_LONG).show()
                    }
                }
            }
        )
    }

    // Pay Recurring Dialog
    if (payingExpense != null) {
        PayRecurringDialog(
            expense = payingExpense!!,
            accounts = accounts,
            onDismiss = { payingExpense = null },
            onConfirmPay = { recId, accId, date, notes ->
                payingExpense = null
                coroutineScope.launch {
                    val res = repository.finance.payRecurringExpense(recId, accId, date, notes)
                    if (res.isSuccess) {
                        Toast.makeText(context, "Payment posted & next due date auto-advanced!", Toast.LENGTH_SHORT).show()
                        loadData()
                    } else {
                        Toast.makeText(context, "Payment error: ${res.exceptionOrNull()?.message}", Toast.LENGTH_LONG).show()
                    }
                }
            }
        )
    }
}

@Composable
private fun RecurringExpenseCard(
    item: RecurringExpense,
    today: String,
    onPayNow: () -> Unit
) {
    val isOverdue = item.next_due_date < today

    Card(
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(14.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier.fillMaxWidth().testTag("recurring_card_${item.id}")
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(item.expense_name, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    val vendorStr = if (!item.vendor.isNullOrBlank()) " • ${item.vendor}" else ""
                    Text("${item.category}$vendorStr", fontSize = 11.sp, color = Color.Gray)
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = CurrencyUtils.formatInr(item.amount),
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 16.sp,
                        color = FarmGreenDark
                    )
                    Text(item.frequency, fontSize = 10.sp, color = Color.Gray)
                }
            }

            HorizontalDivider(color = Color(0xFFF0F0F0))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = if (isOverdue) Icons.Default.EventBusy else Icons.Default.Event,
                        contentDescription = null,
                        tint = if (isOverdue) FarmError else Color.Gray,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (isOverdue) "Overdue: ${item.next_due_date}" else "Next Due: ${item.next_due_date}",
                        fontSize = 12.sp,
                        fontWeight = if (isOverdue) FontWeight.Bold else FontWeight.Normal,
                        color = if (isOverdue) FarmError else Color.DarkGray
                    )
                }

                Button(
                    onClick = onPayNow,
                    colors = ButtonDefaults.buttonColors(containerColor = if (isOverdue) FarmError else FarmGreenDark),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                    modifier = Modifier.height(32.dp).testTag("btn_pay_recurring_${item.id}")
                ) {
                    Text("Pay Now", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AddRecurringExpenseDialog(
    accounts: List<FinancialAccount>,
    onDismiss: () -> Unit,
    onSave: (RecurringExpense) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("Electricity/EB") }
    var vendor by remember { mutableStateOf("") }
    var amountStr by remember { mutableStateOf("") }
    var frequency by remember { mutableStateOf("MONTHLY") }
    var startDate by remember { mutableStateOf(SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())) }
    var nextDueDate by remember { mutableStateOf(SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())) }
    var accountId by remember { mutableStateOf(accounts.firstOrNull()?.id ?: "") }
    var notes by remember { mutableStateOf("") }

    val categories = listOf("Electricity/EB", "Water", "Rent", "Labour salary", "Security", "Internet", "Mobile", "Insurance", "AMC", "Vehicle EMI", "Loan EMI", "Software subscriptions", "Other")
    val frequencies = listOf("DAILY", "WEEKLY", "MONTHLY", "QUARTERLY", "HALF_YEARLY", "YEARLY")

    var catExpanded by remember { mutableStateOf(false) }
    var freqExpanded by remember { mutableStateOf(false) }

    Dialog(onDismissRequest = onDismiss) {
        Surface(shape = RoundedCornerShape(16.dp), color = Color.White, modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Add Recurring Expense", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = FarmGreenDark)

                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Expense Name *") },
                    placeholder = { Text("e.g. EB Barn Bill, Worker Salary, Farm Rent") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("input_recurring_name")
                )

                // Category Dropdown
                ExposedDropdownMenuBox(expanded = catExpanded, onExpandedChange = { catExpanded = !catExpanded }) {
                    OutlinedTextField(
                        value = category,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Category *") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = catExpanded) },
                        modifier = Modifier.fillMaxWidth().menuAnchor()
                    )
                    ExposedDropdownMenu(expanded = catExpanded, onDismissRequest = { catExpanded = false }) {
                        categories.forEach { c ->
                            DropdownMenuItem(text = { Text(c) }, onClick = { category = c; catExpanded = false })
                        }
                    }
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = amountStr,
                        onValueChange = { amountStr = it },
                        label = { Text("Amount (₹) *") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f).testTag("input_recurring_amount")
                    )

                    // Frequency Dropdown
                    ExposedDropdownMenuBox(expanded = freqExpanded, onExpandedChange = { freqExpanded = !freqExpanded }, modifier = Modifier.weight(1f)) {
                        OutlinedTextField(
                            value = frequency,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Frequency *") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = freqExpanded) },
                            modifier = Modifier.fillMaxWidth().menuAnchor()
                        )
                        ExposedDropdownMenu(expanded = freqExpanded, onDismissRequest = { freqExpanded = false }) {
                            frequencies.forEach { f ->
                                DropdownMenuItem(text = { Text(f) }, onClick = { frequency = f; freqExpanded = false })
                            }
                        }
                    }
                }

                OutlinedTextField(
                    value = vendor,
                    onValueChange = { vendor = it },
                    label = { Text("Vendor / Service Provider") },
                    placeholder = { Text("e.g. State Electricity Board, Landlord") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                DatePickerField(
                    dateValue = nextDueDate,
                    onDateSelected = { nextDueDate = it },
                    label = "Next Due Date *"
                )

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    TextButton(onClick = onDismiss) { Text("Cancel") }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            val amt = amountStr.toDoubleOrNull() ?: 0.0
                            if (name.isBlank() || amt <= 0) return@Button
                            val item = RecurringExpense(
                                expense_name = name.trim(),
                                category = category,
                                vendor = vendor.trim().ifBlank { null },
                                amount = amt,
                                frequency = frequency,
                                start_date = startDate,
                                next_due_date = nextDueDate,
                                payment_account_id = accountId.ifBlank { null },
                                is_active = true,
                                notes = notes.trim().ifBlank { null }
                            )
                            onSave(item)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = FarmGreenDark),
                        enabled = name.isNotBlank() && (amountStr.toDoubleOrNull() ?: 0.0) > 0,
                        modifier = Modifier.testTag("btn_save_recurring")
                    ) {
                        Text("Create Schedule")
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun PayRecurringDialog(
    expense: RecurringExpense,
    accounts: List<FinancialAccount>,
    onDismiss: () -> Unit,
    onConfirmPay: (recId: String, accountId: String, date: String, notes: String?) -> Unit
) {
    var accountId by remember { mutableStateOf(expense.payment_account_id ?: accounts.firstOrNull()?.id ?: "") }
    var paymentDate by remember { mutableStateOf(SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())) }
    var notes by remember { mutableStateOf("") }
    var accExpanded by remember { mutableStateOf(false) }

    Dialog(onDismissRequest = onDismiss) {
        Surface(shape = RoundedCornerShape(16.dp), color = Color.White, modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Pay Recurring Expense", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = FarmGreenDark)
                Text(
                    text = "Recording this payment will deduct ${CurrencyUtils.formatInr(expense.amount)} from your account ledger and auto-advance the next due date.",
                    fontSize = 11.sp,
                    color = Color.Gray
                )

                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFF1F8E9)), modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(expense.expense_name, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text("${expense.category} • Due: ${expense.next_due_date}", fontSize = 12.sp, color = Color.DarkGray)
                        Text(
                            text = CurrencyUtils.formatInr(expense.amount),
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 18.sp,
                            color = FarmGreenDark
                        )
                    }
                }

                // Account Selector
                ExposedDropdownMenuBox(expanded = accExpanded, onExpandedChange = { accExpanded = !accExpanded }) {
                    val selAcc = accounts.firstOrNull { it.id == accountId }
                    OutlinedTextField(
                        value = "${selAcc?.account_name ?: "Select Account"} (${CurrencyUtils.formatInr(selAcc?.current_balance ?: 0.0)})",
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Payment Account *") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = accExpanded) },
                        modifier = Modifier.fillMaxWidth().menuAnchor().testTag("select_pay_account")
                    )
                    ExposedDropdownMenu(expanded = accExpanded, onDismissRequest = { accExpanded = false }) {
                        accounts.forEach { acc ->
                            DropdownMenuItem(
                                text = { Text("${acc.account_name} (${CurrencyUtils.formatInr(acc.current_balance)})") },
                                onClick = { accountId = acc.id; accExpanded = false }
                            )
                        }
                    }
                }

                DatePickerField(
                    dateValue = paymentDate,
                    onDateSelected = { paymentDate = it },
                    label = "Payment Date *"
                )

                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Notes / Cheque / Txn ID") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    TextButton(onClick = onDismiss) { Text("Cancel") }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            if (accountId.isNotBlank()) {
                                onConfirmPay(expense.id, accountId, paymentDate, notes.trim().ifBlank { null })
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = FarmGreenDark),
                        enabled = accountId.isNotBlank(),
                        modifier = Modifier.testTag("btn_confirm_pay_recurring")
                    ) {
                        Text("Confirm & Post Payment")
                    }
                }
            }
        }
    }
}
