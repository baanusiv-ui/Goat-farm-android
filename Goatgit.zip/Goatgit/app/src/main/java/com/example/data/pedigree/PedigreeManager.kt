package com.example.data.pedigree

import com.example.data.supabase.Goat
import com.example.data.supabase.MatingRecord
import java.util.Locale

object AnimalOrigin {
    const val FARM_BORN = "FARM_BORN"
    const val MARKET_BOUGHT = "MARKET_BOUGHT"
    const val UNKNOWN = "UNKNOWN"

    fun normalize(origin: String?): String {
        if (origin.isNullOrBlank()) return UNKNOWN
        val upper = origin.trim().uppercase(Locale.US)
        return when {
            upper == FARM_BORN || upper == "BORN ON FARM" || upper == "FARM BORN" -> FARM_BORN
            upper == MARKET_BOUGHT || upper == "PURCHASED" || upper == "MARKET" || upper == "MARKET BOUGHT" -> MARKET_BOUGHT
            else -> UNKNOWN
        }
    }

    fun isFarmBorn(goat: Goat): Boolean = normalize(goat.effectiveOrigin) == FARM_BORN
    fun isMarketBought(goat: Goat): Boolean = normalize(goat.effectiveOrigin) == MARKET_BOUGHT
}

data class PedigreeNode(
    val goat: Goat?,
    val tag: String,
    val name: String,
    val relationship: String, // e.g. "Sire (Father)", "Dam (Mother)", "Paternal Grandfather", etc.
    val origin: String,
    val breed: String?,
    val generation: Int,
    val sire: PedigreeNode? = null,
    val dam: PedigreeNode? = null
)

data class GoatPedigree(
    val goat: Goat,
    val origin: String,
    val isFarmBorn: Boolean,
    val isMarketBought: Boolean,
    val sireNode: PedigreeNode? = null,
    val damNode: PedigreeNode? = null,
    val generation1Parents: List<PedigreeNode> = emptyList(),
    val generation2Grandparents: List<PedigreeNode> = emptyList(),
    val generation3GreatGrandparents: List<PedigreeNode> = emptyList(),
    val hasPedigreeData: Boolean = false
)

sealed class BreedCheckResult {
    data class AllowedSameBreed(val breed: String) : BreedCheckResult()
    data class BlockedCrossBreeding(
        val doeBreed: String,
        val buckBreed: String,
        val titleEn: String = "CROSS-BREEDING NOT ALLOWED",
        val titleTa: String = "கலப்பின இனச்சேர்க்கை அனுமதிக்கப்படாது.",
        val detailEn: String = "Select a buck of the same breed.",
        val detailTa: String = "அதே இனத்தைச் சேர்ந்த ஆட்டைத் தேர்வு செய்யவும்."
    ) : BreedCheckResult()
    data class BreedMissing(
        val isDoeMissing: Boolean,
        val isBuckMissing: Boolean,
        val messageEn: String = "Breed information required before farm mating.",
        val messageTa: String = "பண்ணை இனச்சேர்க்கைக்கு முன் இனத் தகவல் தேவை."
    ) : BreedCheckResult()

    val isAllowed: Boolean get() = this is AllowedSameBreed
}

sealed class PedigreeCheckResult {
    data object AllowedNoRelationship : PedigreeCheckResult()
    data class BlockedCloseRelative(
        val titleEn: String = "Close-relative mating is not allowed.",
        val titleTa: String = "நெருங்கிய உறவினர் இனச்சேர்க்கை அனுமதிக்கப்படாது.",
        val reasonEn: String,
        val reasonTa: String,
        val relationshipType: String
    ) : PedigreeCheckResult()
    data class BlockedSameAnimal(
        val messageEn: String = "Cannot mate a goat with itself.",
        val messageTa: String = "ஒரு ஆட்டை அதனுடனேயே இணை சேர்க்க முடியாது."
    ) : PedigreeCheckResult()

    val isAllowed: Boolean get() = this is AllowedNoRelationship
}

data class MatingEligibility(
    val doe: Goat,
    val buck: Goat,
    val breedCheck: BreedCheckResult,
    val pedigreeCheck: PedigreeCheckResult,
    val canRecordMating: Boolean,
    val rejectionReasonEn: String? = null,
    val rejectionReasonTa: String? = null
)

data class BreedingAuditReport(
    val goatsWithMissingBreed: List<Goat>,
    val farmBornMissingParents: List<Goat>,
    val marketBoughtUnknownPedigree: List<Goat>,
    val historicalCrossBreedMatings: List<HistoricalMatingAudit>,
    val historicalCloseRelativeMatings: List<HistoricalMatingAudit>
)

data class HistoricalMatingAudit(
    val mating: MatingRecord,
    val doe: Goat?,
    val buck: Goat?,
    val issueType: String, // "CROSS_BREED", "CLOSE_RELATIVE"
    val descriptionEn: String,
    val descriptionTa: String
)

object PedigreeManager {

    /**
     * Resolves a goat from the herd by matching either its internal UUID ID or its Tag identifier.
     */
    fun findGoat(idOrTag: String?, goats: List<Goat>): Goat? {
        if (idOrTag.isNullOrBlank()) return null
        val clean = idOrTag.trim()
        return goats.firstOrNull { it.id.equals(clean, ignoreCase = true) }
            ?: goats.firstOrNull { it.tag_c.equals(clean, ignoreCase = true) }
    }

    /**
     * Builds full multi-generation pedigree for a goat up to 3 generations.
     * Stops when ancestry is unknown; never invents missing ancestors.
     * For market-bought goats, maintains clean unrecorded pedigree without artificial ancestors.
     */
    fun buildPedigree(goat: Goat, allGoats: List<Goat>): GoatPedigree {
        val origin = AnimalOrigin.normalize(goat.effectiveOrigin)
        val isFarmBorn = origin == AnimalOrigin.FARM_BORN
        val isMarketBought = origin == AnimalOrigin.MARKET_BOUGHT

        val sRef = goat.effectiveSireId
        val dRef = goat.effectiveDamId

        // For market-bought goats without parents, return clean unrecorded status
        if (isMarketBought && sRef.isNullOrBlank() && dRef.isNullOrBlank()) {
            return GoatPedigree(
                goat = goat,
                origin = origin,
                isFarmBorn = false,
                isMarketBought = true,
                hasPedigreeData = false
            )
        }

        // Gen 1: Parents
        val sireGoat = findGoat(sRef, allGoats)
        val damGoat = findGoat(dRef, allGoats)

        val sireNode: PedigreeNode? = if (!sRef.isNullOrBlank() || sireGoat != null) {
            val tag = sireGoat?.tag_c ?: sRef?.trim().orEmpty()
            val name = sireGoat?.name ?: "Sire $tag"
            val breed = sireGoat?.breed_c
            val o = sireGoat?.let { AnimalOrigin.normalize(it.effectiveOrigin) } ?: AnimalOrigin.UNKNOWN
            buildAncestorNode(sireGoat, tag, name, "Sire (Father)", o, breed, 1, allGoats, maxGen = 3)
        } else null

        val damNode: PedigreeNode? = if (!dRef.isNullOrBlank() || damGoat != null) {
            val tag = damGoat?.tag_c ?: dRef?.trim().orEmpty()
            val name = damGoat?.name ?: "Dam $tag"
            val breed = damGoat?.breed_c
            val o = damGoat?.let { AnimalOrigin.normalize(it.effectiveOrigin) } ?: AnimalOrigin.UNKNOWN
            buildAncestorNode(damGoat, tag, name, "Dam (Mother)", o, breed, 1, allGoats, maxGen = 3)
        } else null

        val gen1 = listOfNotNull(sireNode, damNode)

        // Gen 2: Grandparents
        val gen2 = mutableListOf<PedigreeNode>()
        sireNode?.sire?.let { gen2.add(it) }
        sireNode?.dam?.let { gen2.add(it) }
        damNode?.sire?.let { gen2.add(it) }
        damNode?.dam?.let { gen2.add(it) }

        // Gen 3: Great-Grandparents
        val gen3 = mutableListOf<PedigreeNode>()
        for (gp in gen2) {
            gp.sire?.let { gen3.add(it) }
            gp.dam?.let { gen3.add(it) }
        }

        val hasPedigree = gen1.isNotEmpty()

        return GoatPedigree(
            goat = goat,
            origin = origin,
            isFarmBorn = isFarmBorn,
            isMarketBought = isMarketBought,
            sireNode = sireNode,
            damNode = damNode,
            generation1Parents = gen1,
            generation2Grandparents = gen2,
            generation3GreatGrandparents = gen3,
            hasPedigreeData = hasPedigree
        )
    }

    private fun buildAncestorNode(
        goat: Goat?,
        tag: String,
        name: String,
        role: String,
        origin: String,
        breed: String?,
        currentGen: Int,
        allGoats: List<Goat>,
        maxGen: Int
    ): PedigreeNode {
        var subSire: PedigreeNode? = null
        var subDam: PedigreeNode? = null

        if (currentGen < maxGen && goat != null) {
            val sRef = goat.effectiveSireId
            val dRef = goat.effectiveDamId
            val sGoat = findGoat(sRef, allGoats)
            val dGoat = findGoat(dRef, allGoats)

            if (!sRef.isNullOrBlank() || sGoat != null) {
                val sTag = sGoat?.tag_c ?: sRef?.trim().orEmpty()
                val sName = sGoat?.name ?: "Sire $sTag"
                val sRole = if (currentGen == 1) {
                    if (role.contains("Sire", ignoreCase = true)) "Paternal Grandfather" else "Maternal Grandfather"
                } else {
                    "Great-Grandfather ($tag)"
                }
                val sOrigin = sGoat?.let { AnimalOrigin.normalize(it.effectiveOrigin) } ?: AnimalOrigin.UNKNOWN
                subSire = buildAncestorNode(sGoat, sTag, sName, sRole, sOrigin, sGoat?.breed_c, currentGen + 1, allGoats, maxGen)
            }

            if (!dRef.isNullOrBlank() || dGoat != null) {
                val dTag = dGoat?.tag_c ?: dRef?.trim().orEmpty()
                val dName = dGoat?.name ?: "Dam $dTag"
                val dRole = if (currentGen == 1) {
                    if (role.contains("Sire", ignoreCase = true)) "Paternal Grandmother" else "Maternal Grandmother"
                } else {
                    "Great-Grandmother ($tag)"
                }
                val dOrigin = dGoat?.let { AnimalOrigin.normalize(it.effectiveOrigin) } ?: AnimalOrigin.UNKNOWN
                subDam = buildAncestorNode(dGoat, dTag, dName, dRole, dOrigin, dGoat?.breed_c, currentGen + 1, allGoats, maxGen)
            }
        }

        return PedigreeNode(
            goat = goat,
            tag = tag,
            name = name,
            relationship = role,
            origin = origin,
            breed = breed,
            generation = currentGen,
            sire = subSire,
            dam = subDam
        )
    }

    /**
     * Avoid cross-breeding rule:
     * Compares Doe breed with Buck breed using normalized exact identity.
     * If different: BLOCKS MATING with clear warning.
     * If either breed is unknown or blank: BLOCKS with "Breed information required before farm mating."
     */
    fun checkBreedCompatibility(doe: Goat, buck: Goat): BreedCheckResult {
        val doeBreed = doe.breed_c.trim()
        val buckBreed = buck.breed_c.trim()

        val isDoeMissing = doeBreed.isBlank() || doeBreed.equals("unknown", ignoreCase = true)
        val isBuckMissing = buckBreed.isBlank() || buckBreed.equals("unknown", ignoreCase = true)

        if (isDoeMissing || isBuckMissing) {
            return BreedCheckResult.BreedMissing(
                isDoeMissing = isDoeMissing,
                isBuckMissing = isBuckMissing
            )
        }

        if (!doeBreed.equals(buckBreed, ignoreCase = true)) {
            return BreedCheckResult.BlockedCrossBreeding(
                doeBreed = doeBreed,
                buckBreed = buckBreed
            )
        }

        return BreedCheckResult.AllowedSameBreed(doeBreed)
    }

    /**
     * Pedigree & Kinship checks for mating:
     * - Parent-child relationships blocked
     * - Sibling relationships (shared sire or shared dam) blocked
     * - Close ancestor line relationships (grandparent, uncle-niece, aunt-nephew, first cousins) blocked
     */
    fun checkPedigreeCompatibility(doe: Goat, buck: Goat, allGoats: List<Goat>): PedigreeCheckResult {
        // 1. Same animal
        if (doe.id.equals(buck.id, ignoreCase = true) ||
            (doe.tag_c.isNotBlank() && doe.tag_c.equals(buck.tag_c, ignoreCase = true))) {
            return PedigreeCheckResult.BlockedSameAnimal()
        }

        val doeTag = doe.tag_c.trim().uppercase(Locale.US)
        val buckTag = buck.tag_c.trim().uppercase(Locale.US)
        val doeId = doe.id.trim()
        val buckId = buck.id.trim()

        // 2. Direct Parent - Offspring
        // Buck is father of Doe
        if (isMatch(doe.sire_c, buckId, buckTag)) {
            return PedigreeCheckResult.BlockedCloseRelative(
                reasonEn = "Buck is the Sire (Father) of this Doe.",
                reasonTa = "இந்த கிடா பெட்டை ஆட்டின் தந்தை ஆகும்.",
                relationshipType = "PARENT_OFFSPRING"
            )
        }
        // Doe is mother of Buck
        if (isMatch(buck.dam_c, doeId, doeTag)) {
            return PedigreeCheckResult.BlockedCloseRelative(
                reasonEn = "Doe is the Dam (Mother) of this Buck.",
                reasonTa = "இந்த பெட்டை ஆடு கிடாவின் தாய் ஆகும்.",
                relationshipType = "PARENT_OFFSPRING"
            )
        }

        // 3. Sibling relationship (Full or Half siblings)
        // Shared Sire
        if (!doe.sire_c.isNullOrBlank() && !buck.sire_c.isNullOrBlank()) {
            if (areReferencesEqual(doe.sire_c, buck.sire_c, allGoats)) {
                val sireLabel = doe.sire_c.trim()
                return PedigreeCheckResult.BlockedCloseRelative(
                    reasonEn = "Sibling mating detected: Both goats share the same Sire ($sireLabel).",
                    reasonTa = "உடன்பிறந்தவை கண்டறியப்பட்டது: இரண்டு ஆடுகளும் ஒரே தந்தையைக் ($sireLabel) கொண்டுள்ளன.",
                    relationshipType = "SIBLINGS_SHARED_SIRE"
                )
            }
        }

        // Shared Dam
        if (!doe.dam_c.isNullOrBlank() && !buck.dam_c.isNullOrBlank()) {
            if (areReferencesEqual(doe.dam_c, buck.dam_c, allGoats)) {
                val damLabel = doe.dam_c.trim()
                return PedigreeCheckResult.BlockedCloseRelative(
                    reasonEn = "Sibling mating detected: Both goats share the same Dam ($damLabel).",
                    reasonTa = "உடன்பிறந்தவை கண்டறியப்பட்டது: இரண்டு ஆடுகளும் ஒரே தாயைக் ($damLabel) கொண்டுள்ளன.",
                    relationshipType = "SIBLINGS_SHARED_DAM"
                )
            }
        }

        // 4. Ancestor line checks up to 3 generations
        val doeAncestors = collectAncestors(doe, allGoats, maxDepth = 3)
        val buckAncestors = collectAncestors(buck, allGoats, maxDepth = 3)

        // Buck is an ancestor of Doe (e.g. Grandfather, Great-grandfather)
        val buckInDoeAncestors = doeAncestors.firstOrNull { it.matches(buckId, buckTag) }
        if (buckInDoeAncestors != null) {
            return PedigreeCheckResult.BlockedCloseRelative(
                reasonEn = "Buck is an ancestor of the Doe (${buckInDoeAncestors.roleLabel}).",
                reasonTa = "கிடா பெட்டை ஆட்டின் மூதாதையர் ஆகும் (${buckInDoeAncestors.roleLabel}).",
                relationshipType = "ANCESTOR_DESCENDANT"
            )
        }

        // Doe is an ancestor of Buck (e.g. Grandmother, Great-grandmother)
        val doeInBuckAncestors = buckAncestors.firstOrNull { it.matches(doeId, doeTag) }
        if (doeInBuckAncestors != null) {
            return PedigreeCheckResult.BlockedCloseRelative(
                reasonEn = "Doe is an ancestor of the Buck (${doeInBuckAncestors.roleLabel}).",
                reasonTa = "பெட்டை ஆடு கிடாவின் மூதாதையர் ஆகும் (${doeInBuckAncestors.roleLabel}).",
                relationshipType = "ANCESTOR_DESCENDANT"
            )
        }

        // Shared Grandparents (First cousins or Uncle/Aunt - Nephew/Niece)
        for (da in doeAncestors) {
            if (da.generation <= 2) {
                val shared = buckAncestors.firstOrNull { ba -> ba.generation <= 2 && ba.matches(da.id, da.tag) }
                if (shared != null) {
                    val label = if (da.tag.isNotBlank()) da.tag else da.id
                    return PedigreeCheckResult.BlockedCloseRelative(
                        reasonEn = "Close-line mating detected: Shared ancestor within 2 generations ($label).",
                        reasonTa = "நெருங்கிய வம்சாவளி இனச்சேர்க்கை கண்டறியப்பட்டது: 2 தலைமுறைக்குள் பொதுவான மூதாதையர் ($label).",
                        relationshipType = "SHARED_CLOSE_ANCESTOR"
                    )
                }
            }
        }

        return PedigreeCheckResult.AllowedNoRelationship
    }

    /**
     * Evaluates full mating eligibility combining breed and pedigree checks.
     */
    fun evaluateMating(doe: Goat, buck: Goat, allGoats: List<Goat>): MatingEligibility {
        val breedCheck = checkBreedCompatibility(doe, buck)
        val pedigreeCheck = checkPedigreeCompatibility(doe, buck, allGoats)

        val canRecord = breedCheck.isAllowed && pedigreeCheck.isAllowed

        var rejectEn: String? = null
        var rejectTa: String? = null

        if (!breedCheck.isAllowed) {
            when (breedCheck) {
                is BreedCheckResult.BlockedCrossBreeding -> {
                    rejectEn = "${breedCheck.titleEn}: ${breedCheck.detailEn} (Doe: ${breedCheck.doeBreed}, Buck: ${breedCheck.buckBreed})"
                    rejectTa = "${breedCheck.titleTa} ${breedCheck.detailTa}"
                }
                is BreedCheckResult.BreedMissing -> {
                    rejectEn = breedCheck.messageEn
                    rejectTa = breedCheck.messageTa
                }
                is BreedCheckResult.AllowedSameBreed -> {}
            }
        } else if (!pedigreeCheck.isAllowed) {
            when (pedigreeCheck) {
                is PedigreeCheckResult.BlockedCloseRelative -> {
                    rejectEn = "${pedigreeCheck.titleEn} ${pedigreeCheck.reasonEn}"
                    rejectTa = "${pedigreeCheck.titleTa} ${pedigreeCheck.reasonTa}"
                }
                is PedigreeCheckResult.BlockedSameAnimal -> {
                    rejectEn = pedigreeCheck.messageEn
                    rejectTa = pedigreeCheck.messageTa
                }
                is PedigreeCheckResult.AllowedNoRelationship -> {}
            }
        }

        return MatingEligibility(
            doe = doe,
            buck = buck,
            breedCheck = breedCheck,
            pedigreeCheck = pedigreeCheck,
            canRecordMating = canRecord,
            rejectionReasonEn = rejectEn,
            rejectionReasonTa = rejectTa
        )
    }

    /**
     * Generates a comprehensive breeding & lineage audit report across the herd and mating history.
     */
    fun generateAuditReport(goats: List<Goat>, matings: List<MatingRecord>): BreedingAuditReport {
        val goatsMissingBreed = goats.filter { it.breed_c.isBlank() || it.breed_c.equals("unknown", ignoreCase = true) }

        val farmBornMissingParents = goats.filter {
            AnimalOrigin.isFarmBorn(it) && (it.sire_c.isNullOrBlank() || it.dam_c.isNullOrBlank())
        }

        val marketBoughtUnknownPedigree = goats.filter {
            AnimalOrigin.isMarketBought(it) && it.sire_c.isNullOrBlank() && it.dam_c.isNullOrBlank()
        }

        val crossBreedMatings = mutableListOf<HistoricalMatingAudit>()
        val closeRelativeMatings = mutableListOf<HistoricalMatingAudit>()

        for (m in matings) {
            val doe = findGoat(m.doe_id_c, goats)
            val buck = findGoat(m.buck_id_c, goats)
            if (doe != null && buck != null) {
                val bCheck = checkBreedCompatibility(doe, buck)
                if (bCheck is BreedCheckResult.BlockedCrossBreeding) {
                    crossBreedMatings.add(
                        HistoricalMatingAudit(
                            mating = m,
                            doe = doe,
                            buck = buck,
                            issueType = "CROSS_BREED",
                            descriptionEn = "Cross-breed mating: Doe ${doe.tag_c} (${bCheck.doeBreed}) × Buck ${buck.tag_c} (${bCheck.buckBreed})",
                            descriptionTa = "கலப்பின இனச்சேர்க்கை: பெட்டை ${doe.tag_c} (${bCheck.doeBreed}) × கிடா ${buck.tag_c} (${bCheck.buckBreed})"
                        )
                    )
                }

                val pCheck = checkPedigreeCompatibility(doe, buck, goats)
                if (pCheck is PedigreeCheckResult.BlockedCloseRelative) {
                    closeRelativeMatings.add(
                        HistoricalMatingAudit(
                            mating = m,
                            doe = doe,
                            buck = buck,
                            issueType = "CLOSE_RELATIVE",
                            descriptionEn = "Close-relative mating: ${pCheck.reasonEn}",
                            descriptionTa = "நெருங்கிய உறவினர் இணைசேர்ப்பு: ${pCheck.reasonTa}"
                        )
                    )
                }
            }
        }

        return BreedingAuditReport(
            goatsWithMissingBreed = goatsMissingBreed,
            farmBornMissingParents = farmBornMissingParents,
            marketBoughtUnknownPedigree = marketBoughtUnknownPedigree,
            historicalCrossBreedMatings = crossBreedMatings,
            historicalCloseRelativeMatings = closeRelativeMatings
        )
    }

    // --- Private Kinship Helpers ---

    private data class AncestorRef(
        val id: String?,
        val tag: String,
        val roleLabel: String,
        val generation: Int
    ) {
        fun matches(targetId: String?, targetTag: String?): Boolean {
            if (id != null && !targetId.isNullOrBlank() && id.equals(targetId, ignoreCase = true)) return true
            if (tag.isNotBlank() && !targetTag.isNullOrBlank() && tag.equals(targetTag, ignoreCase = true)) return true
            return false
        }
    }

    private fun collectAncestors(root: Goat, allGoats: List<Goat>, maxDepth: Int): List<AncestorRef> {
        val list = mutableListOf<AncestorRef>()
        fun recurse(goat: Goat?, gen: Int, role: String) {
            if (goat == null || gen > maxDepth) return
            val sRef = goat.effectiveSireId?.trim()
            val dRef = goat.effectiveDamId?.trim()

            if (!sRef.isNullOrBlank()) {
                val sGoat = findGoat(sRef, allGoats)
                val sTag = sGoat?.tag_c ?: sRef
                val sId = sGoat?.id
                list.add(AncestorRef(sId, sTag, if (gen == 1) "Father" else "$role's Father", gen))
                recurse(sGoat, gen + 1, "Paternal Line")
            }

            if (!dRef.isNullOrBlank()) {
                val dGoat = findGoat(dRef, allGoats)
                val dTag = dGoat?.tag_c ?: dRef
                val dId = dGoat?.id
                list.add(AncestorRef(dId, dTag, if (gen == 1) "Mother" else "$role's Mother", gen))
                recurse(dGoat, gen + 1, "Maternal Line")
            }
        }
        recurse(root, 1, "Root")
        return list
    }

    private fun isMatch(reference: String?, targetId: String, targetTag: String): Boolean {
        if (reference.isNullOrBlank()) return false
        val clean = reference.trim()
        if (clean.equals(targetId, ignoreCase = true)) return true
        if (clean.equals(targetTag, ignoreCase = true)) return true
        return false
    }

    private fun areReferencesEqual(ref1: String, ref2: String, allGoats: List<Goat>): Boolean {
        val c1 = ref1.trim()
        val c2 = ref2.trim()
        if (c1.equals(c2, ignoreCase = true)) return true

        val g1 = findGoat(c1, allGoats)
        val g2 = findGoat(c2, allGoats)
        if (g1 != null && g2 != null && g1.id.equals(g2.id, ignoreCase = true)) return true
        return false
    }
}
