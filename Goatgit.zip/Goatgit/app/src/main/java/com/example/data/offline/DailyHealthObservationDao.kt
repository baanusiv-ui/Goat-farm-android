package com.example.data.offline

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface DailyHealthObservationDao {
    @Query("SELECT * FROM local_daily_health_observations ORDER BY observation_date DESC, created_at DESC")
    fun getAllObservationsFlow(): Flow<List<DailyHealthObservationEntity>>

    @Query("SELECT * FROM local_daily_health_observations ORDER BY observation_date DESC, created_at DESC")
    suspend fun getAllObservations(): List<DailyHealthObservationEntity>

    @Query("SELECT * FROM local_daily_health_observations WHERE goat_id = :goatId ORDER BY observation_date DESC, created_at DESC")
    fun getObservationsForGoatFlow(goatId: String): Flow<List<DailyHealthObservationEntity>>

    @Query("SELECT * FROM local_daily_health_observations WHERE goat_id = :goatId ORDER BY observation_date DESC, created_at DESC")
    suspend fun getObservationsForGoat(goatId: String): List<DailyHealthObservationEntity>

    @Query("SELECT * FROM local_daily_health_observations WHERE id = :id LIMIT 1")
    suspend fun getObservationById(id: String): DailyHealthObservationEntity?

    @Query("SELECT * FROM local_daily_health_observations WHERE observation_date = :date ORDER BY created_at DESC")
    suspend fun getObservationsByDate(date: String): List<DailyHealthObservationEntity>

    @Query("SELECT COUNT(*) FROM local_daily_health_observations WHERE observation_date = :date")
    fun getCountForDateFlow(date: String): Flow<Int>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertObservation(observation: DailyHealthObservationEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(list: List<DailyHealthObservationEntity>)

    @Update
    suspend fun updateObservation(observation: DailyHealthObservationEntity)

    @Query("DELETE FROM local_daily_health_observations WHERE id = :id")
    suspend fun deleteObservationById(id: String)
}
