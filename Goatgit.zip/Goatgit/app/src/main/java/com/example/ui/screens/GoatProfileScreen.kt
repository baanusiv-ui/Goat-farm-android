package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.TrendingUp
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.pedigree.AnimalOrigin
import com.example.data.pedigree.PedigreeManager
import com.example.data.supabase.*
import com.example.i18n.t
import com.example.ui.components.GoatPedigreeSection
import com.example.ui.components.GoatProfileComponent
import com.example.ui.components.OriginBadge
import com.example.ui.components.PedigreeColumnView
import com.example.ui.components.TagBadge
import com.example.ui.components.breeding.GoatIndividualBreedingSection
import com.example.ui.components.camera.GoatCameraCaptureDialog
import com.example.ui.components.camera.GoatAvatar
import com.example.ui.components.profile.GoatPhotosGalleryTab
import com.example.ui.components.profile.GoatProfileEditDialog
import com.example.ui.components.profile.GoatWeightHistoryComponent
import com.example.ui.components.profile.calculateGoatAge
import com.example.ui.screens.weight.BreedGrowthBenchmark
import com.example.ui.screens.weight.DefaultBreedBenchmarks
import com.example.ui.screens.weight.RechartsChartPoint
import com.example.ui.screens.weight.RechartsComposeCanvasChart
import com.example.ui.screens.weight.RechartsWebInteractiveChart
import com.example.ui.theme.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.TimeUnit
import kotlin.math.roundToInt

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GoatProfileScreen(
    goatId: String,
    repository: GoatRepository,
    onNavigateBack: () -> Unit,
    onNavigateToProfile: (String) -> Unit,
    onNavigateToRecordWeight: (String) -> Unit,
    onNavigateToVaccination: (String) -> Unit,
    onNavigateToDeworming: (String) -> Unit,
    onNavigateToTreatment: (String) -> Unit,
    onNavigateToBreeding: () -> Unit,
    onNavigateToHealthCamera: ((String) -> Unit)? = null,
    onNavigateToDailyObservation: ((String) -> Unit)? = null,
    onNavigateToTrends: ((String) -> Unit)? = null,
    onNavigateToRecurringHealthTracking: ((String) -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    BackHandler { onNavigateBack() }

    val coroutineScope = rememberCoroutineScope()
    var isLoading by remember { mutableStateOf(true) }
    var currentGoat by remember { mutableStateOf<Goat?>(null) }
    var allGoats by remember { mutableStateOf<List<Goat>>(emptyList()) }
    var weights by remember { mutableStateOf<List<GoatWeight>>(emptyList()) }
    var vaccinations by remember { mutableStateOf<List<VaccinationRecord>>(emptyList()) }
    var dewormings by remember { mutableStateOf<List<DewormingRecord>>(emptyList()) }
    var treatments by remember { mutableStateOf<List<TreatmentRecord>>(emptyList()) }
    var matings by remember { mutableStateOf<List<MatingRecord>>(emptyList()) }
    var pregnancies by remember { mutableStateOf<List<PregnancyRecord>>(emptyList()) }
    var kiddings by remember { mutableStateOf<List<KiddingRecord>>(emptyList()) }
    var weaningRecord by remember { mutableStateOf<com.example.data.offline.WeaningRecordEntity?>(null) }
    var selectedTab by remember { mutableIntStateOf(0) }
    var showEditProfileDialog by remember { mutableStateOf(false) }
    var showCameraCaptureDialog by remember { mutableStateOf(false) }
    val breedingRecords by repository.getBreedingRecordsForGoatFlow(goatId)
        .collectAsState(initial = emptyList())

    fun loadData() {
        coroutineScope.launch {
            isLoading = true
            val goatsRes = repository.getGoats()
            if (goatsRes.isSuccess) {
                allGoats = goatsRes.getOrThrow()
                currentGoat = allGoats.firstOrNull { it.id == goatId }
            }
            if (currentGoat != null) {
                val gid = currentGoat!!.id
                val wRes = repository.getWeights(gid)
                if (wRes.isSuccess) weights = wRes.getOrThrow().sortedByDescending { it.date_c }

                val vRes = repository.getVaccinations(gid)
                if (vRes.isSuccess) vaccinations = vRes.getOrThrow().sortedByDescending { it.administered_date_c }

                val dRes = repository.getDewormings(gid)
                if (dRes.isSuccess) dewormings = dRes.getOrThrow().sortedByDescending { it.treatment_date_c }

                val tRes = repository.getTreatments(gid)
                if (tRes.isSuccess) treatments = tRes.getOrThrow().sortedByDescending { it.start_date_c }

                val mRes = repository.getMatingRecords()
                if (mRes.isSuccess) {
                    matings = mRes.getOrThrow().filter { it.doe_id_c == gid || it.buck_id_c == gid }
                        .sortedByDescending { it.mating_date_c }
                }

                val pRes = repository.getPregnancies()
                if (pRes.isSuccess) {
                    pregnancies = pRes.getOrThrow().filter { it.doe_id_c == gid }
                        .sortedByDescending { it.confirmation_date_c }
                }

                val kRes = repository.getKiddings()
                if (kRes.isSuccess) {
                    kiddings = kRes.getOrThrow().filter { it.doe_id_c == gid }
                        .sortedByDescending { it.kidding_date_c }
                }

                weaningRecord = repository.database.weaningDao().getWeaningRecordByGoatId(gid)
            }
            isLoading = false
        }
    }

    LaunchedEffect(goatId) {
        loadData()
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = t("profile.title"),
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp
                        )
                        currentGoat?.let {
                            Text(
                                text = "${it.name} • Tag: ${it.tag_c} • ID: ${it.id.take(8)}",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                },
                navigationIcon = {
                    IconButton(
                        onClick = onNavigateBack,
                        modifier = Modifier.testTag("profile_btn_back")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = t("btn.back")
                        )
                    }
                },
                actions = {
                    IconButton(
                        onClick = { showEditProfileDialog = true },
                        modifier = Modifier.testTag("profile_btn_edit")
                    ) {
                        Icon(Icons.Default.Edit, contentDescription = "Edit Profile", tint = FarmGreenDark)
                    }
                    IconButton(
                        onClick = { loadData() },
                        modifier = Modifier.testTag("profile_btn_refresh")
                    ) {
                        Icon(Icons.Default.Refresh, contentDescription = t("btn.refresh"))
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = FarmSurfaceLight,
                    titleContentColor = FarmGreenDark
                )
            )
        },
        containerColor = FarmSurfaceLight,
        modifier = modifier
    ) { innerPadding ->
        if (isLoading) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator(color = FarmGreenPrimary)
            }
        } else if (currentGoat == null) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.Pets,
                        contentDescription = null,
                        tint = Color.Gray,
                        modifier = Modifier.size(64.dp)
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "Goat not found",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Button(
                        onClick = onNavigateBack,
                        colors = ButtonDefaults.buttonColors(containerColor = FarmGreenPrimary)
                    ) {
                        Text(t("btn.back"))
                    }
                }
            }
        } else {
            val goat = currentGoat!!
            val isBuck = goat.sex_c.equals("Buck", ignoreCase = true)
            val isDoe = goat.sex_c.equals("Doe", ignoreCase = true)

            // Direct offspring in the herd
            val offspring = remember(goat.id, goat.tag_c, allGoats) {
                allGoats.filter { g ->
                    val matchesSire = !goat.tag_c.isBlank() && (g.sire_c?.trim()?.equals(goat.tag_c.trim(), ignoreCase = true) == true || g.sire_c == goat.id)
                    val matchesDam = !goat.tag_c.isBlank() && (g.dam_c?.trim()?.equals(goat.tag_c.trim(), ignoreCase = true) == true || g.dam_c == goat.id)
                    matchesSire || matchesDam
                }
            }

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                // Header Hero Summary
                ProfileHeroHeader(
                    goat = goat,
                    latestWeight = weights.firstOrNull()?.weight_kg_c ?: goat.weight_kg_c,
                    onEditProfile = { showEditProfileDialog = true },
                    onCapturePhoto = { showCameraCaptureDialog = true },
                    onRecordWeight = { onNavigateToRecordWeight(goat.id) },
                    onVaccinate = { onNavigateToVaccination(goat.id) },
                    onDeworm = { onNavigateToDeworming(goat.id) },
                    onTreatment = { onNavigateToTreatment(goat.id) },
                    onMating = onNavigateToBreeding
                )

                // Tabs Navigation
                ScrollableTabRow(
                    selectedTabIndex = selectedTab,
                    edgePadding = 16.dp,
                    containerColor = Color.White,
                    contentColor = FarmGreenDark
                ) {
                    Tab(
                        selected = selectedTab == 0,
                        onClick = { selectedTab = 0 },
                        text = { Text(t("profile.tab_overview"), fontWeight = FontWeight.Bold) },
                        modifier = Modifier.testTag("profile_tab_overview")
                    )
                    Tab(
                        selected = selectedTab == 1,
                        onClick = { selectedTab = 1 },
                        text = {
                            val totalHealth = weights.size + vaccinations.size + dewormings.size + treatments.size
                            Text("${t("profile.tab_health")} ($totalHealth)", fontWeight = FontWeight.Bold)
                        },
                        modifier = Modifier.testTag("profile_tab_health")
                    )
                    Tab(
                        selected = selectedTab == 2,
                        onClick = { selectedTab = 2 },
                        text = { Text(t("profile.tab_pedigree"), fontWeight = FontWeight.Bold) },
                        modifier = Modifier.testTag("profile_tab_pedigree")
                    )
                    Tab(
                        selected = selectedTab == 3,
                        onClick = { selectedTab = 3 },
                        text = {
                            val totalBreeding = matings.size + pregnancies.size + kiddings.size + breedingRecords.size
                            Text("${t("profile.tab_breeding")} ($totalBreeding)", fontWeight = FontWeight.Bold)
                        },
                        modifier = Modifier.testTag("profile_tab_breeding")
                    )
                    Tab(
                        selected = selectedTab == 4,
                        onClick = { selectedTab = 4 },
                        text = { Text("Photos", fontWeight = FontWeight.Bold) },
                        modifier = Modifier.testTag("profile_tab_photos")
                    )
                }

                // Tab Content Body
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .verticalScroll(rememberScrollState())
                        .padding(16.dp)
                ) {
                    when (selectedTab) {
                        0 -> ProfileOverviewTab(
                            goat = goat,
                            weights = weights,
                            vaccinations = vaccinations,
                            offspringCount = offspring.size,
                            weaningRecord = weaningRecord,
                            vaccinationsCount = vaccinations.size,
                            dewormingsCount = dewormings.size,
                            onEditProfile = { showEditProfileDialog = true },
                            onVaccinate = { onNavigateToVaccination(goat.id) },
                            onRecordNewWeight = { weightKg, dateStr, method, notes ->
                                coroutineScope.launch {
                                    val newWeight = GoatWeight(
                                        id = UUID.randomUUID().toString(),
                                        goat_id_c = goat.id,
                                        weight_kg_c = weightKg,
                                        date_c = dateStr,
                                        method_c = method,
                                        notes_c = notes
                                    )
                                    repository.recordWeight(newWeight)
                                    loadData()
                                }
                            },
                            onNavigateToFullHistory = { selectedTab = 1 },
                            onNavigateToTrends = { onNavigateToTrends?.invoke(goat.id) }
                        )
                        1 -> ProfileHealthHistoryTab(
                            goat = goat,
                            weights = weights,
                            vaccinations = vaccinations,
                            dewormings = dewormings,
                            treatments = treatments,
                            repository = repository,
                            onReloadData = { loadData() },
                            onRecordWeight = { onNavigateToRecordWeight(goat.id) },
                            onVaccinate = { onNavigateToVaccination(goat.id) },
                            onDeworm = { onNavigateToDeworming(goat.id) },
                            onTreatment = { onNavigateToTreatment(goat.id) },
                            onCaptureHealthPhoto = { onNavigateToHealthCamera?.invoke(goat.id) },
                            onDailyObservation = { onNavigateToDailyObservation?.invoke(goat.id) },
                            onTrendsAnalytics = { onNavigateToTrends?.invoke(goat.id) },
                            onRecurringHealthTracking = { onNavigateToRecurringHealthTracking?.invoke(goat.id) }
                        )
                        2 -> ProfilePedigreeTab(
                            goat = goat,
                            allGoats = allGoats,
                            offspring = offspring,
                            onOpenGoat = { targetGoat ->
                                onNavigateToProfile(targetGoat.id)
                            }
                        )
                        3 -> {
                            Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                                GoatIndividualBreedingSection(
                                    goat = goat,
                                    allGoats = allGoats,
                                    repository = repository,
                                    onNavigateToAllBreeding = onNavigateToBreeding
                                )
                                ProfileBreedingStatusTab(
                                    goat = goat,
                                    allGoats = allGoats,
                                    matings = matings,
                                    pregnancies = pregnancies,
                                    kiddings = kiddings,
                                    offspring = offspring,
                                    onNavigateToBreeding = onNavigateToBreeding
                                )
                            }
                        }
                        4 -> GoatPhotosGalleryTab(
                            goat = goat,
                            repository = repository,
                            onCaptureNewPhoto = { showCameraCaptureDialog = true }
                        )
                    }
                }
            }
        }
    }

    if (showCameraCaptureDialog && currentGoat != null) {
        GoatCameraCaptureDialog(
            goatId = currentGoat!!.id,
            goatTag = currentGoat!!.tag_c,
            repository = repository,
            initialCategory = if (currentGoat!!.photo_url_c.isNullOrBlank()) "Profile" else "Identification",
            onDismiss = { showCameraCaptureDialog = false },
            onPhotoSaved = { _, _ ->
                loadData()
            }
        )
    }

    if (showEditProfileDialog && currentGoat != null) {
        GoatProfileEditDialog(
            goat = currentGoat!!,
            allGoats = allGoats,
            onDismiss = { showEditProfileDialog = false },
            onSaveProfile = { name, tag, breed, sex, status, birthDate, color, dam, sire, notes ->
                coroutineScope.launch {
                    val res = repository.updateGoatProfileDetails(
                        goatId = currentGoat!!.id,
                        name = name,
                        tag = tag,
                        breed = breed,
                        sex = sex,
                        status = status,
                        birthDate = birthDate,
                        color = color,
                        dam = dam,
                        sire = sire,
                        notes = notes
                    )
                    if (res.isSuccess) {
                        showEditProfileDialog = false
                        loadData()
                    }
                }
            }
        )
    }
}

@Composable
private fun ProfileHeroHeader(
    goat: Goat,
    latestWeight: Double?,
    onEditProfile: () -> Unit = {},
    onCapturePhoto: () -> Unit = {},
    onRecordWeight: () -> Unit,
    onVaccinate: () -> Unit,
    onDeworm: () -> Unit,
    onTreatment: () -> Unit,
    onMating: () -> Unit
) {
    val isBuck = goat.sex_c.equals("Buck", ignoreCase = true)
    val isKid = goat.sex_c.equals("Kid", ignoreCase = true)

    Card(
        shape = RoundedCornerShape(0.dp, 0.dp, 16.dp, 16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Top identity row
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    GoatAvatar(
                        photoUrl = goat.photo_url_c,
                        tag = goat.tag_c,
                        isBuck = isBuck,
                        size = 58.dp,
                        showCameraBadge = true,
                        onCameraClick = onCapturePhoto,
                        modifier = Modifier.testTag("profile_avatar_image")
                    )

                    Spacer(modifier = Modifier.width(12.dp))

                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            TagBadge(tag = goat.tag_c, isBuck = isBuck, isKid = isKid)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = goat.name,
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold,
                                color = FarmGreenDark
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            IconButton(
                                onClick = onEditProfile,
                                modifier = Modifier.size(26.dp).testTag("profile_hero_edit_btn")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Edit,
                                    contentDescription = "Edit Profile",
                                    tint = FarmGreenDark,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                            IconButton(
                                onClick = onCapturePhoto,
                                modifier = Modifier.size(26.dp).testTag("profile_hero_camera_btn")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.PhotoCamera,
                                    contentDescription = "Take Photo",
                                    tint = FarmGreenDark,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "${goat.breed_c} • ${goat.sex_c}",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                // Origin & Status badges
                Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    OriginBadge(origin = goat.effectiveOrigin)
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = when (goat.status_c.lowercase()) {
                            "pregnant" -> Color(0xFFF3E5F5)
                            "lactating" -> Color(0xFFE8F5E9)
                            "quarantine" -> Color(0xFFFEF3C7)
                            "sold", "deceased" -> Color(0xFFEEEEEE)
                            else -> FarmGreenContainer
                        }
                    ) {
                        Text(
                            text = if (goat.status_c.equals("Quarantine", ignoreCase = true)) "QUARANTINE" else goat.status_c,
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = when (goat.status_c.lowercase()) {
                                "pregnant" -> Color(0xFF7B1FA2)
                                "lactating" -> FarmGreenDark
                                "quarantine" -> Color(0xFFB45309)
                                "sold", "deceased" -> Color(0xFF616161)
                                else -> FarmGreenDark
                            },
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                        )
                    }
                }
            }

            if (goat.status_c.equals("Quarantine", ignoreCase = true)) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Color(0xFFFEF3C7),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFF59E0B)),
                    modifier = Modifier.fillMaxWidth().padding(top = 10.dp)
                ) {
                    Row(modifier = Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Security, contentDescription = null, tint = Color(0xFFB45309), modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "QUARANTINE ISOLATION ACTIVE - HERD ACCESS RESTRICTED",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF92400E)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Quick Stats Grid
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                MetricChip(
                    label = t("profile.metrics_weight"),
                    value = if (latestWeight != null) "$latestWeight kg" else "--",
                    icon = Icons.Default.Scale,
                    modifier = Modifier.weight(1f)
                )
                MetricChip(
                    label = t("profile.metrics_age"),
                    value = calculateGoatAge(goat.birth_date_c),
                    icon = Icons.Default.CalendarToday,
                    modifier = Modifier.weight(1f)
                )
                MetricChip(
                    label = t("profile.metrics_location"),
                    value = goat.farm_location_c ?: "Barn A",
                    icon = Icons.Default.Home,
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Quick Action Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                OutlinedButton(
                    onClick = onRecordWeight,
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.weight(1f).height(38.dp).testTag("profile_quick_weight")
                ) {
                    Icon(Icons.Default.Scale, contentDescription = null, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(t("profile.action_record_weight"), fontSize = 11.sp, maxLines = 1)
                }

                OutlinedButton(
                    onClick = onVaccinate,
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.weight(1f).height(38.dp).testTag("profile_quick_vaccine")
                ) {
                    Icon(Icons.Default.Vaccines, contentDescription = null, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(t("profile.action_vaccinate"), fontSize = 11.sp, maxLines = 1)
                }

                OutlinedButton(
                    onClick = onDeworm,
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.weight(1f).height(38.dp).testTag("profile_quick_deworm")
                ) {
                    Icon(Icons.Default.Healing, contentDescription = null, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(t("profile.action_deworm"), fontSize = 11.sp, maxLines = 1)
                }

                FilledTonalButton(
                    onClick = onMating,
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.filledTonalButtonColors(
                        containerColor = FarmGreenContainer,
                        contentColor = FarmGreenDark
                    ),
                    modifier = Modifier.weight(1f).height(38.dp).testTag("profile_quick_mating")
                ) {
                    Icon(Icons.Default.Favorite, contentDescription = null, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(t("profile.action_mating"), fontSize = 11.sp, maxLines = 1)
                }
            }
        }
    }
}

@Composable
private fun MetricChip(
    label: String,
    value: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(10.dp),
        color = Color(0xFFF7F8F7),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE8ECE8)),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(icon, contentDescription = null, tint = FarmGreenPrimary, modifier = Modifier.size(13.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = label,
                    fontSize = 10.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1
                )
            }
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = value,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = FarmGreenDark,
                maxLines = 1
            )
        }
    }
}

@Composable
private fun ProfileOverviewTab(
    goat: Goat,
    weights: List<GoatWeight> = emptyList(),
    vaccinations: List<VaccinationRecord> = emptyList(),
    offspringCount: Int,
    weaningRecord: com.example.data.offline.WeaningRecordEntity? = null,
    vaccinationsCount: Int = 0,
    dewormingsCount: Int = 0,
    onEditProfile: () -> Unit = {},
    onVaccinate: () -> Unit = {},
    onRecordNewWeight: (weightKg: Double, dateStr: String, method: String, notes: String?) -> Unit = { _, _, _, _ -> },
    onNavigateToFullHistory: () -> Unit = {},
    onNavigateToTrends: (() -> Unit)? = null
) {
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        // Basic Info Card
        Card(
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = t("profile.section_basic"),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = FarmGreenDark
                    )
                    OutlinedButton(
                        onClick = onEditProfile,
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.testTag("btn_edit_profile_overview")
                    ) {
                        Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Edit", fontSize = 12.sp)
                    }
                }
                HorizontalDivider(color = Color(0xFFEEEEEE))

                InfoRow(label = "Goat ID", value = goat.id)
                InfoRow(label = t("add_goat.tag_label"), value = goat.tag_c)
                InfoRow(label = t("add_goat.name_label"), value = goat.name)
                InfoRow(label = t("pedigree.breed"), value = goat.breed_c)
                InfoRow(label = t("add_goat.sex_label"), value = goat.sex_c)
                InfoRow(label = t("herd.status"), value = goat.status_c)
                InfoRow(label = t("add_goat.dob_label"), value = goat.birth_date_c ?: "--")
                InfoRow(label = "Calculated Age", value = calculateGoatAge(goat.birth_date_c))
                InfoRow(label = "Current Weight", value = if (weights.firstOrNull() != null) "${weights.first().weight_kg_c} kg (${weights.first().date_c})" else "${goat.weight_kg_c ?: "--"} kg")
                InfoRow(label = "Color / Coat", value = goat.color_c ?: "--")
                InfoRow(label = "Pen / Location", value = goat.farm_location_c ?: "Barn A")
            }
        }

        // Weight History & Recharts Growth Trends Curve (Queries Room Database)
        com.example.ui.components.profile.GoatWeightTrendsCard(
            goat = goat,
            weights = weights,
            onRecordNewWeight = onRecordNewWeight,
            onNavigateToFullHistory = onNavigateToFullHistory,
            onNavigateToTrends = onNavigateToTrends
        )

        // Vaccination History & Schedule Card
        Card(
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
            modifier = Modifier.fillMaxWidth().testTag("profile_overview_vaccination_card")
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            shape = CircleShape,
                            color = Color(0xFFE0F2FE),
                            modifier = Modifier.size(30.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.Vaccines,
                                    contentDescription = null,
                                    tint = Color(0xFF0284C7),
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Vaccination History",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = FarmGreenDark
                        )
                    }

                    OutlinedButton(
                        onClick = onVaccinate,
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.testTag("btn_overview_quick_vaccinate")
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Add Vaccine", fontSize = 12.sp)
                    }
                }

                HorizontalDivider(color = Color(0xFFEEEEEE))

                if (vaccinations.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 10.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.MedicalServices, contentDescription = null, tint = Color.LightGray, modifier = Modifier.size(28.dp))
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "No vaccination records logged yet for this goat.",
                                fontSize = 12.sp,
                                color = Color.Gray
                            )
                        }
                    }
                } else {
                    val lastVac = vaccinations.firstOrNull()
                    val nextDueVac = vaccinations.mapNotNull { it.next_due_date_c }.minOrNull()

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = Color(0xFFF0FDF4),
                            border = BorderStroke(1.dp, Color(0xFFDCFCE7)),
                            modifier = Modifier.weight(1f)
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Text("Last Vaccinated", fontSize = 10.sp, color = Color.Gray)
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = lastVac?.vaccine_c ?: "--",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF166534),
                                    maxLines = 1
                                )
                                Text(
                                    text = lastVac?.administered_date_c ?: "--",
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = if (nextDueVac != null) Color(0xFFFFFBEB) else Color(0xFFF8FAFC),
                            border = BorderStroke(1.dp, if (nextDueVac != null) Color(0xFFFDE68A) else Color(0xFFE2E8F0)),
                            modifier = Modifier.weight(1f)
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Text("Next Due Date", fontSize = 10.sp, color = Color.Gray)
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = nextDueVac ?: "None scheduled",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (nextDueVac != null) Color(0xFFB45309) else Color.Gray,
                                    maxLines = 1
                                )
                                Text(
                                    text = if (nextDueVac != null) "Immunization due" else "Up to date",
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Recent Immunizations (${vaccinations.size}):",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Color.DarkGray
                    )

                    vaccinations.take(3).forEach { vac ->
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = Color(0xFFF8FAFC),
                            border = BorderStroke(1.dp, Color(0xFFF1F5F9)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 10.dp, vertical = 8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = vac.vaccine_c,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp,
                                        color = Color(0xFF0F172A)
                                    )
                                    val doseInfo = buildString {
                                        if (!vac.dose_c.isNullOrBlank()) append("Dose: ${vac.dose_c}")
                                        if (!vac.administered_by_c.isNullOrBlank()) {
                                            if (isNotEmpty()) append(" • ")
                                            append("By: ${vac.administered_by_c}")
                                        }
                                    }
                                    if (doseInfo.isNotEmpty()) {
                                        Text(text = doseInfo, fontSize = 11.sp, color = Color.Gray)
                                    }
                                }

                                Column(horizontalAlignment = Alignment.End) {
                                    Text(
                                        text = vac.administered_date_c,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Medium,
                                        color = Color(0xFF0284C7)
                                    )
                                    if (!vac.next_due_date_c.isNullOrBlank()) {
                                        Text(
                                            text = "Due: ${vac.next_due_date_c}",
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.SemiBold,
                                            color = Color(0xFFD97706)
                                        )
                                    }
                                }
                            }
                        }
                    }

                    if (vaccinations.size > 3) {
                        TextButton(
                            onClick = onNavigateToFullHistory,
                            modifier = Modifier.align(Alignment.End)
                        ) {
                            Text("View all ${vaccinations.size} records", fontSize = 12.sp, color = FarmGreenDark)
                            Spacer(modifier = Modifier.width(4.dp))
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = null, modifier = Modifier.size(14.dp), tint = FarmGreenDark)
                        }
                    }
                }
            }
        }

        // Weaning Section (Requirement 13)
        if (weaningRecord != null || goat.status_c.equals("WEANED", ignoreCase = true) || !goat.dam_c.isNullOrBlank() || !goat.birth_date_c.isNullOrBlank()) {
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                modifier = Modifier.fillMaxWidth().testTag("goat_profile_weaning_card")
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Surface(
                                shape = CircleShape,
                                color = Color(0xFFE8F5E9),
                                modifier = Modifier.size(28.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(Icons.Default.ChildCare, contentDescription = null, tint = Color(0xFF2E7D32), modifier = Modifier.size(16.dp))
                                }
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Weaning & Growth Profile",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF1B5E20)
                            )
                        }
                        val statusText = weaningRecord?.status ?: if (goat.status_c.equals("WEANED", ignoreCase = true)) "WEANED" else "PLANNED"
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = if (statusText == "WEANED") Color(0xFFE8F5E9) else Color(0xFFFFF3E0)
                        ) {
                            Text(
                                text = statusText,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (statusText == "WEANED") Color(0xFF2E7D32) else Color(0xFFE65100),
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                            )
                        }
                    }
                    HorizontalDivider(color = Color(0xFFEEEEEE))

                    InfoRow(label = "Birth Date", value = weaningRecord?.birth_date ?: goat.birth_date_c ?: "--")
                    InfoRow(label = "Mother (Dam)", value = goat.dam_c ?: goat.effectiveDamId ?: "--")
                    val bWeight = weaningRecord?.birth_weight ?: goat.weight_kg_c
                    InfoRow(label = "Birth Weight", value = bWeight?.let { "$it kg" } ?: "--")
                    InfoRow(label = "Expected Weaning Date", value = weaningRecord?.weaning_due_date ?: "--")
                    InfoRow(label = "Actual Weaning Date", value = weaningRecord?.actual_weaning_date ?: "Pending Weaning")
                    InfoRow(label = "Age at Weaning", value = weaningRecord?.age_at_weaning_days?.let { "$it days" } ?: "--")
                    val wWeight = weaningRecord?.weight_at_weaning ?: if (goat.status_c.equals("WEANED", ignoreCase = true)) goat.weight_kg_c else null
                    InfoRow(label = "Weaning Weight", value = wWeight?.let { "$it kg" } ?: "--")
                    val adgStr = weaningRecord?.adg_g_per_day?.let { "${it.toInt()} g/day" }
                    InfoRow(label = "Average Daily Gain (ADG)", value = adgStr ?: "--")
                    InfoRow(label = "Weaning Method", value = weaningRecord?.weaning_method ?: "GRADUAL")
                    InfoRow(label = "Health Status", value = "${goat.health_status_c} • $vaccinationsCount vaccines • $dewormingsCount dewormings")
                }
            }
        }

        // Origin & Acquisition Card
        Card(
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = t("profile.section_origin"),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = FarmGreenDark
                    )
                    OriginBadge(origin = goat.effectiveOrigin)
                }
                HorizontalDivider(color = Color(0xFFEEEEEE))

                when (goat.effectiveOrigin) {
                    AnimalOrigin.MARKET_BOUGHT -> {
                        InfoRow(label = "Acquisition", value = t("pedigree.market_bought"))
                        InfoRow(label = "Purchase Date", value = goat.purchase_date_c ?: "--")
                        InfoRow(label = "Purchase Cost", value = if (goat.purchase_cost_c != null) "₹${goat.purchase_cost_c}" else "--")
                        InfoRow(label = "${t("pedigree.sire")} (sire_id)", value = t("pedigree.status_unknown"))
                        InfoRow(label = "${t("pedigree.dam")} (dam_id)", value = t("pedigree.status_unknown"))
                        InfoRow(label = "Source", value = goat.source_c ?: "Purchased from Market")
                        Spacer(modifier = Modifier.height(4.dp))
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = Color(0xFFE3F2FD),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = t("pedigree.market_bought_notice"),
                                fontSize = 12.sp,
                                color = Color(0xFF0D47A1),
                                modifier = Modifier.padding(10.dp)
                            )
                        }
                    }
                    AnimalOrigin.FARM_BORN -> {
                        InfoRow(label = "Origin", value = t("pedigree.farm_born"))
                        InfoRow(label = "${t("pedigree.sire")} (sire_id)", value = goat.effectiveSireId ?: "Not recorded")
                        InfoRow(label = "${t("pedigree.dam")} (dam_id)", value = goat.effectiveDamId ?: "Not recorded")
                        InfoRow(label = "Recorded Birth", value = goat.birth_date_c ?: "--")
                    }
                    else -> {
                        InfoRow(label = "Origin", value = t("pedigree.unknown_origin"))
                        Text(
                            text = "Origin has not been explicitly confirmed for this animal record.",
                            fontSize = 12.sp,
                            color = Color.Gray
                        )
                    }
                }
            }
        }

        // Remarks Card
        if (!goat.notes_c.isNullOrBlank()) {
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = t("herd.notes"),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = FarmGreenDark
                    )
                    Text(
                        text = goat.notes_c,
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }
        }

        // Summary Card for Offspring
        Card(
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = FarmGreenContainer.copy(alpha = 0.4f)),
            elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(14.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = t("profile.section_offspring"),
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = FarmGreenDark
                    )
                    Text(
                        text = if (offspringCount > 0) "$offspringCount offspring registered in herd" else t("profile.no_offspring"),
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Surface(
                    shape = CircleShape,
                    color = FarmGreenDark
                ) {
                    Text(
                        text = "$offspringCount",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun ProfileHealthHistoryTab(
    goat: Goat,
    weights: List<GoatWeight>,
    vaccinations: List<VaccinationRecord>,
    dewormings: List<DewormingRecord>,
    treatments: List<TreatmentRecord>,
    repository: GoatRepository? = null,
    onReloadData: () -> Unit = {},
    onRecordWeight: () -> Unit,
    onVaccinate: () -> Unit,
    onDeworm: () -> Unit,
    onTreatment: () -> Unit,
    onCaptureHealthPhoto: () -> Unit = {},
    onDailyObservation: () -> Unit = {},
    onTrendsAnalytics: () -> Unit = {},
    onRecurringHealthTracking: () -> Unit = {}
) {
    val coroutineScope = rememberCoroutineScope()
    val isQuarantined = goat.status_c.equals("Quarantine", ignoreCase = true)

    Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
        // Prominent Quarantine Alert Banner (Requirement 18)
        if (isQuarantined) {
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = Color(0xFFFEF3C7),
                border = androidx.compose.foundation.BorderStroke(1.5.dp, Color(0xFFF59E0B)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Security, contentDescription = null, tint = Color(0xFFB45309), modifier = Modifier.size(22.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "QUARANTINE PROTOCOL ACTIVE",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = Color(0xFF92400E)
                        )
                    }
                    Text(
                        text = "This animal is in biosecurity isolation. Do not integrate into the general herd, pasture grazing, or breeding pens until quarantine clearance is granted.",
                        fontSize = 11.sp,
                        color = Color(0xFF78350F)
                    )
                }
            }
        }

        // Requirement 18: HEALTH STATUS Section
        Card(
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
            modifier = Modifier.fillMaxWidth().testTag("profile_health_status_card")
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "HEALTH STATUS",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = FarmGreenDark
                    )
                    Surface(
                        color = if (isQuarantined) Color(0xFFFEF3C7) else Color(0xFFDCFCE7),
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text(
                            text = if (isQuarantined) "QUARANTINE" else "HERD ACTIVE",
                            fontWeight = FontWeight.Bold,
                            fontSize = 10.sp,
                            color = if (isQuarantined) Color(0xFFB45309) else FarmGreenDark,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                        )
                    }
                }

                HorizontalDivider(color = Color(0xFFF1F5F9))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Current Status", fontSize = 10.sp, color = Color.Gray)
                        Text(goat.status_c, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Quarantine Status", fontSize = 10.sp, color = Color.Gray)
                        Text(if (isQuarantined) "Active Isolation" else "Cleared / None", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    }
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Last Vaccination", fontSize = 10.sp, color = Color.Gray)
                        val lastVac = vaccinations.firstOrNull()
                        Text(lastVac?.let { "${it.vaccine_c} (${it.administered_date_c})" } ?: "None recorded", fontSize = 12.sp, fontWeight = FontWeight.Medium)
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Next Vaccination", fontSize = 10.sp, color = Color.Gray)
                        val nextVac = vaccinations.mapNotNull { it.next_due_date_c }.minOrNull()
                        Text(nextVac ?: "None scheduled", fontSize = 12.sp, fontWeight = FontWeight.Medium)
                    }
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Last Deworming", fontSize = 10.sp, color = Color.Gray)
                        val lastDew = dewormings.firstOrNull()
                        Text(lastDew?.let { "${it.medicine_c} (${it.treatment_date_c})" } ?: "None recorded", fontSize = 12.sp, fontWeight = FontWeight.Medium)
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Next Deworming", fontSize = 10.sp, color = Color.Gray)
                        val nextDew = dewormings.mapNotNull { it.next_due_date_c }.minOrNull()
                        Text(nextDew ?: "None scheduled", fontSize = 12.sp, fontWeight = FontWeight.Medium)
                    }
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Current Treatment", fontSize = 10.sp, color = Color.Gray)
                        val activeTr = treatments.firstOrNull { it.outcome_c.contains("Under", ignoreCase = true) }
                        Text(activeTr?.let { "${it.medicine_c} (${it.symptoms_c})" } ?: "None (Healthy)", fontSize = 12.sp, fontWeight = FontWeight.Medium)
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Next Follow-up", fontSize = 10.sp, color = Color.Gray)
                        val activeTr = treatments.firstOrNull { it.outcome_c.contains("Under", ignoreCase = true) }
                        Text(activeTr?.end_date_c ?: "N/A", fontSize = 12.sp, fontWeight = FontWeight.Medium)
                    }
                }

                // Quick buttons: Vaccinate, Deworm, Treatment, View History
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Button(
                        onClick = onVaccinate,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7)),
                        contentPadding = PaddingValues(horizontal = 6.dp, vertical = 6.dp),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.weight(1f).testTag("btn_profile_quick_vaccinate")
                    ) {
                        Text("Vaccinate", fontSize = 11.sp, color = Color.White)
                    }
                    Button(
                        onClick = onDeworm,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF059669)),
                        contentPadding = PaddingValues(horizontal = 6.dp, vertical = 6.dp),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.weight(1f).testTag("btn_profile_quick_deworm")
                    ) {
                        Text("Deworm", fontSize = 11.sp, color = Color.White)
                    }
                    Button(
                        onClick = onTreatment,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF9333EA)),
                        contentPadding = PaddingValues(horizontal = 6.dp, vertical = 6.dp),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.weight(1f).testTag("btn_profile_quick_treatment")
                    ) {
                        Text("Treatment", fontSize = 11.sp, color = Color.White)
                    }
                    OutlinedButton(
                        onClick = onRecordWeight,
                        contentPadding = PaddingValues(horizontal = 6.dp, vertical = 6.dp),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.weight(1f).testTag("btn_profile_quick_history")
                    ) {
                        Text("Weight", fontSize = 11.sp)
                    }
                }

                Button(
                    onClick = onCaptureHealthPhoto,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0D9488)),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth().testTag("btn_profile_capture_health_photo")
                ) {
                    Icon(Icons.Default.PhotoCamera, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Capture Health Documentation Photo", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }

                OutlinedButton(
                    onClick = onDailyObservation,
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = FarmGreenDark),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth().testTag("btn_profile_daily_health_obs")
                ) {
                    Icon(Icons.Default.EditNote, contentDescription = null, modifier = Modifier.size(18.dp), tint = FarmGreenDark)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Daily Health Observation (Vitals, FAMACHA, Appetite)", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }

                FilledTonalButton(
                    onClick = onTrendsAnalytics,
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth().testTag("btn_profile_trends_analytics")
                ) {
                    Icon(Icons.AutoMirrored.Filled.TrendingUp, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Historical Trends & ADG Analytics (Room DB)", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }

                OutlinedButton(
                    onClick = onRecurringHealthTracking,
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFF0D9488)),
                    border = BorderStroke(1.dp, Color(0xFF0D9488)),
                    modifier = Modifier.fillMaxWidth().testTag("btn_profile_recurring_health_tracking")
                ) {
                    Icon(Icons.Default.Scale, contentDescription = null, modifier = Modifier.size(18.dp), tint = Color(0xFF0D9488))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Recurring Health & Weight Tracking Module", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
        // Weight History, Growth Trajectory & Interactive Chart (Requirement: Weight History Component)
        GoatWeightHistoryComponent(
            goatId = goat.id,
            weights = weights,
            birthDateStr = goat.birth_date_c,
            goatBreed = goat.breed_c,
            onRecordNewWeight = { weightKg, dateStr, method, notes ->
                coroutineScope.launch {
                    val newWeight = GoatWeight(
                        id = UUID.randomUUID().toString(),
                        goat_id_c = goat.id,
                        weight_kg_c = weightKg,
                        date_c = dateStr,
                        method_c = method,
                        notes_c = notes
                    )
                    repository?.recordWeight(newWeight)
                    onReloadData()
                }
            },
            onDeleteWeight = { weightId ->
                coroutineScope.launch {
                    repository?.deleteWeightRecord(weightId, goat.id)
                    onReloadData()
                }
            },
            onNavigateToTrends = onTrendsAnalytics
        )

        // Vaccination Section
        SectionHeaderWithAction(
            title = t("profile.recent_vaccinations"),
            count = vaccinations.size,
            actionLabel = t("profile.action_vaccinate"),
            onAction = onVaccinate,
            icon = Icons.Default.Vaccines
        )
        if (vaccinations.isEmpty()) {
            EmptySectionCard(message = "No vaccination records logged yet.")
        } else {
            vaccinations.forEach { vac ->
                Card(
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = vac.vaccine_c,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                            Text(
                                text = vac.administered_date_c,
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        if (!vac.dose_c.isNullOrBlank() || !vac.administered_by_c.isNullOrBlank()) {
                            Text(
                                text = "Dose: ${vac.dose_c ?: "--"} • Vet/Admin: ${vac.administered_by_c ?: "--"}",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        if (!vac.next_due_date_c.isNullOrBlank()) {
                            Text(
                                text = "Next Due: ${vac.next_due_date_c}",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = Color(0xFFE65100)
                            )
                        }
                    }
                }
            }
        }

        // Deworming Section
        SectionHeaderWithAction(
            title = t("profile.recent_dewormings"),
            count = dewormings.size,
            actionLabel = t("profile.action_deworm"),
            onAction = onDeworm,
            icon = Icons.Default.Healing
        )
        if (dewormings.isEmpty()) {
            EmptySectionCard(message = "No deworming records logged yet.")
        } else {
            dewormings.forEach { deworm ->
                Card(
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = deworm.medicine_c,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                            Text(
                                text = deworm.treatment_date_c,
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Text(
                            text = "Dose: ${deworm.dose_c}${if (deworm.administered_by_c != null) " • Admin: ${deworm.administered_by_c}" else ""}",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        if (!deworm.next_due_date_c.isNullOrBlank()) {
                            Text(
                                text = "Next Deworming Due: ${deworm.next_due_date_c}",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = Color(0xFFE65100)
                            )
                        }
                    }
                }
            }
        }

        // Treatment Section
        SectionHeaderWithAction(
            title = t("profile.recent_treatments"),
            count = treatments.size,
            actionLabel = t("profile.action_treatment"),
            onAction = onTreatment,
            icon = Icons.Default.MedicalServices
        )
        if (treatments.isEmpty()) {
            EmptySectionCard(message = "No illness or treatment records logged yet.")
        } else {
            treatments.forEach { treat ->
                Card(
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = treat.diagnosis_c.ifBlank { treat.symptoms_c },
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = if (treat.outcome_c.contains("Recovered", ignoreCase = true)) FarmGreenContainer else FarmErrorContainer
                            ) {
                                Text(
                                    text = treat.outcome_c,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (treat.outcome_c.contains("Recovered", ignoreCase = true)) FarmGreenDark else FarmError,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                        Text(
                            text = "Medicine: ${treat.medicine_c} (${treat.dose_c}) • Date: ${treat.start_date_c}",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        if (!treat.veterinarian_c.isNullOrBlank()) {
                            Text(
                                text = "Veterinarian: ${treat.veterinarian_c}",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ProfilePedigreeTab(
    goat: Goat,
    allGoats: List<Goat>,
    offspring: List<Goat>,
    onOpenGoat: (Goat) -> Unit
) {
    GoatPedigreeSection(
        goat = goat,
        allGoats = allGoats,
        offspring = offspring,
        onOpenGoat = onOpenGoat
    )
}

@Composable
private fun ProfileBreedingStatusTab(
    goat: Goat,
    allGoats: List<Goat>,
    matings: List<MatingRecord>,
    pregnancies: List<PregnancyRecord>,
    kiddings: List<KiddingRecord>,
    offspring: List<Goat>,
    onNavigateToBreeding: () -> Unit
) {
    val isDoe = goat.sex_c.equals("Doe", ignoreCase = true)
    val isBuck = goat.sex_c.equals("Buck", ignoreCase = true)

    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        // Breeding State Overview Card
        Card(
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = t("profile.metrics_status"),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = FarmGreenDark
                    )
                    Button(
                        onClick = onNavigateToBreeding,
                        colors = ButtonDefaults.buttonColors(containerColor = FarmGreenPrimary),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                        modifier = Modifier.height(34.dp).testTag("profile_breeding_module_btn")
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(t("profile.action_mating"), fontSize = 11.sp)
                    }
                }
                HorizontalDivider(color = Color(0xFFEEEEEE))

                if (isDoe) {
                    // Check if current pregnancy is active
                    val activePregnancy = pregnancies.firstOrNull {
                        it.status_c.equals("Confirmed", ignoreCase = true) || it.status_c.equals("Suspected", ignoreCase = true)
                    }

                    if (activePregnancy != null) {
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = Color(0xFFF3E5F5),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "Active Pregnancy (Confirmed)",
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF7B1FA2),
                                        fontSize = 13.sp
                                    )
                                    Text(
                                        text = "Due: ${activePregnancy.expected_kidding_date_c}",
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF7B1FA2),
                                        fontSize = 12.sp
                                    )
                                }

                                val daysPregnant = calculateDaysPregnant(activePregnancy.confirmation_date_c)
                                val progress = (daysPregnant / 150.0).coerceIn(0.0, 1.0).toFloat()
                                val daysLeft = (150 - daysPregnant).coerceAtLeast(0)

                                LinearProgressIndicator(
                                    progress = { progress },
                                    color = Color(0xFFAB47BC),
                                    trackColor = Color(0xFFE1BEE7),
                                    modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp))
                                )

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = "$daysPregnant days into gestation",
                                        fontSize = 11.sp,
                                        color = Color(0xFF4A148C)
                                    )
                                    Text(
                                        text = "~$daysLeft days remaining",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = Color(0xFF4A148C)
                                    )
                                }
                            }
                        }
                    } else {
                        InfoRow(label = "Reproductive State", value = if (goat.status_c.equals("Pregnant", true)) "Pregnant" else "Open / Ready to mate")
                    }

                    InfoRow(label = t("profile.kiddings_count"), value = "${kiddings.size}")
                    InfoRow(label = t("profile.offspring_count"), value = "${offspring.size}")
                    InfoRow(label = t("profile.matings_count"), value = "${matings.size}")
                } else if (isBuck) {
                    InfoRow(label = "Buck Status", value = "Active Breeding Sire")
                    InfoRow(label = t("profile.matings_count"), value = "${matings.size}")
                    InfoRow(label = "Offspring Sired", value = "${offspring.size}")
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = Color(0xFFE8F5E9),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "Pure-breed rule enforced: Must only be mated with Does of the same breed (${goat.breed_c}).",
                            fontSize = 12.sp,
                            color = FarmGreenDark,
                            modifier = Modifier.padding(10.dp)
                        )
                    }
                } else {
                    InfoRow(label = "Status", value = goat.status_c)
                }
            }
        }

        // Matings History List
        Card(
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "${t("profile.mating_history")} (${matings.size})",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = FarmGreenDark
                )
                HorizontalDivider(color = Color(0xFFEEEEEE))

                if (matings.isEmpty()) {
                    Text(
                        text = "No mating records logged for this animal.",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(vertical = 4.dp)
                    )
                } else {
                    matings.forEach { mating ->
                        val mateId = if (isDoe) mating.buck_id_c else mating.doe_id_c
                        val mate = allGoats.firstOrNull { it.id == mateId }

                        Card(
                            shape = RoundedCornerShape(10.dp),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFFFAFAFA)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "Mate: ${mate?.name ?: "Tag #"} (${mate?.tag_c ?: mateId})",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp
                                    )
                                    Text(
                                        text = mating.mating_date_c,
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Text(
                                    text = "Breed: ${mate?.breed_c ?: goat.breed_c} • Method: ${mating.method_c}",
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }
        }

        // Kiddings / Deliveries List (if Doe)
        if (isDoe) {
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "${t("profile.kidding_history")} (${kiddings.size})",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = FarmGreenDark
                    )
                    HorizontalDivider(color = Color(0xFFEEEEEE))

                    if (kiddings.isEmpty()) {
                        Text(
                            text = "No kidding / delivery records logged yet.",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(vertical = 4.dp)
                        )
                    } else {
                        kiddings.forEach { kidding ->
                            Card(
                                shape = RoundedCornerShape(10.dp),
                                colors = CardDefaults.cardColors(containerColor = Color(0xFFFAFAFA)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = "Delivery Date: ${kidding.kidding_date_c}",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 13.sp,
                                            color = FarmGreenDark
                                        )
                                        Surface(
                                            shape = RoundedCornerShape(6.dp),
                                            color = FarmGreenContainer
                                        ) {
                                            Text(
                                                text = kidding.birth_type_c,
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = FarmGreenDark,
                                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                            )
                                        }
                                    }
                                    Text(
                                        text = "Assistance: ${kidding.assistance_c} • Complications: ${kidding.complications_c}",
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SectionHeaderWithAction(
    title: String,
    count: Int,
    actionLabel: String,
    onAction: () -> Unit,
    icon: androidx.compose.ui.graphics.vector.ImageVector
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, contentDescription = null, tint = FarmGreenDark, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = "$title ($count)",
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                color = FarmGreenDark
            )
        }

        OutlinedButton(
            onClick = onAction,
            shape = RoundedCornerShape(8.dp),
            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
            modifier = Modifier.height(30.dp)
        ) {
            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(12.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text(actionLabel, fontSize = 11.sp)
        }
    }
}

@Composable
private fun EmptySectionCard(message: String) {
    Card(
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        modifier = Modifier.fillMaxWidth()
    ) {
        Text(
            text = message,
            fontSize = 12.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(14.dp)
        )
    }
}

@Composable
private fun InfoRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            fontSize = 12.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(
            text = value,
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold,
            color = Color.Black
        )
    }
}

private fun calculateAgeDisplay(birthDate: String?): String {
    if (birthDate.isNullOrBlank()) return "--"
    return try {
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        val date = sdf.parse(birthDate) ?: return birthDate
        val now = Calendar.getInstance().time
        val diffMs = now.time - date.time
        if (diffMs < 0) return birthDate
        val days = TimeUnit.MILLISECONDS.toDays(diffMs)
        when {
            days < 30 -> "$days days"
            days < 365 -> "${days / 30} mos"
            else -> {
                val years = days / 365
                val remMonths = (days % 365) / 30
                if (remMonths > 0) "$years y $remMonths m" else "$years yrs"
            }
        }
    } catch (_: Exception) {
        birthDate
    }
}

private fun calculateDaysPregnant(confirmationOrConceptionDate: String): Int {
    return try {
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        val date = sdf.parse(confirmationOrConceptionDate) ?: return 30
        val diffMs = Calendar.getInstance().timeInMillis - date.time
        (TimeUnit.MILLISECONDS.toDays(diffMs).toInt() + 30).coerceAtLeast(30)
    } catch (_: Exception) {
        45
    }
}
