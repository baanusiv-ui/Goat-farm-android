package com.example.data.supabase

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

class SupabaseClient(val config: SupabaseConfig) {

    constructor(clientConfig: SupabaseClientConfig) : this(clientConfig.toSupabaseConfig())

    val clientConfig: SupabaseClientConfig
        get() = SupabaseClientConfig(
            url = config.url,
            apiKey = config.publishableKey,
            accessToken = config.accessToken,
            refreshToken = config.refreshToken,
            userId = config.userId,
            userEmail = config.userEmail
        )

    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    val realtime: SupabaseRealtimeClient by lazy {
        SupabaseRealtimeClient(config, client)
    }

    fun connectRealtime() = realtime.connect()
    fun disconnectRealtime() = realtime.disconnect()
    fun reconnectRealtime() = realtime.reconnect()
    val realtimeStatus get() = realtime.status
    val realtimeEvents get() = realtime.realtimeEvents
    fun observeTable(table: String) = realtime.observeTable(table)

    private fun buildHeaders(requestBuilder: Request.Builder) {
        val apiKey = config.publishableKey
        if (apiKey.isNotBlank()) {
            requestBuilder.header("apikey", apiKey)
        }
        val token = config.accessToken ?: apiKey
        if (token.isNotBlank()) {
            requestBuilder.header("Authorization", "Bearer $token")
        }
    }

    suspend fun signIn(email: String, pass: String): Result<String> = withContext(Dispatchers.IO) {
        val url = "${config.url}/auth/v1/token?grant_type=password"
        val bodyObj = JSONObject().apply {
            put("email", email)
            put("password", pass)
        }
        val request = Request.Builder()
            .url(url)
            .post(bodyObj.toString().toRequestBody(jsonMediaType))
            .apply {
                val apiKey = config.publishableKey
                if (apiKey.isNotBlank()) {
                    header("apikey", apiKey)
                }
            }
            .build()

        try {
            client.newCall(request).execute().use { response ->
                val bodyStr = response.body?.string() ?: ""
                if (response.isSuccessful) {
                    val json = JSONObject(bodyStr)
                    val accessToken = json.getString("access_token")
                    val refreshToken = json.optString("refresh_token")
                    val userObj = json.optJSONObject("user")
                    val userId = userObj?.optString("id")
                    val userEmail = userObj?.optString("email") ?: email
                    config.saveSession(accessToken, refreshToken, userEmail, userId)
                    Result.success(userEmail)
                } else {
                    val errorMsg = try {
                        val errObj = JSONObject(bodyStr)
                        errObj.optString("error_description", errObj.optString("msg", errObj.optString("message", "Authentication failed")))
                    } catch (e: Exception) {
                        "Error ${response.code}: $bodyStr"
                    }
                    Result.failure(Exception(errorMsg))
                }
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun signUp(email: String, pass: String): Result<String> = withContext(Dispatchers.IO) {
        val url = "${config.url}/auth/v1/signup"
        val bodyObj = JSONObject().apply {
            put("email", email)
            put("password", pass)
        }
        val request = Request.Builder()
            .url(url)
            .post(bodyObj.toString().toRequestBody(jsonMediaType))
            .apply {
                val apiKey = config.publishableKey
                if (apiKey.isNotBlank()) {
                    header("apikey", apiKey)
                }
            }
            .build()

        try {
            client.newCall(request).execute().use { response ->
                val bodyStr = response.body?.string() ?: ""
                if (response.isSuccessful) {
                    val json = JSONObject(bodyStr)
                    val accessToken = json.optString("access_token")
                    if (accessToken.isNotEmpty()) {
                        val refreshToken = json.optString("refresh_token")
                        val userObj = json.optJSONObject("user")
                        config.saveSession(accessToken, refreshToken, email, userObj?.optString("id"))
                    }
                    Result.success("Account created successfully. Check your email if confirmation is required.")
                } else {
                    val err = parseError(bodyStr, response.code)
                    Result.failure(Exception(err))
                }
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun signOut() = withContext(Dispatchers.IO) {
        val token = config.accessToken
        if (!token.isNullOrBlank()) {
            val url = "${config.url}/auth/v1/logout"
            val request = Request.Builder()
                .url(url)
                .post("{}".toRequestBody(jsonMediaType))
                .apply { buildHeaders(this) }
                .build()
            try {
                client.newCall(request).execute().close()
            } catch (_: Exception) {}
        }
        config.clearSession()
    }

    suspend fun testConnection(): Result<String> = withContext(Dispatchers.IO) {
        val url = "${config.url}/rest/v1/goats_c?select=id&limit=1"
        val request = Request.Builder()
            .url(url)
            .get()
            .apply { buildHeaders(this) }
            .build()

        try {
            client.newCall(request).execute().use { response ->
                val body = response.body?.string() ?: ""
                if (response.isSuccessful) {
                    Result.success("Connected to Supabase successfully!")
                } else {
                    Result.failure(Exception(parseError(body, response.code)))
                }
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun get(table: String, queryParams: String = ""): Result<JSONArray> = withContext(Dispatchers.IO) {
        val separator = if (queryParams.startsWith("?") || queryParams.isEmpty()) "" else "?"
        val fullUrl = "${config.url}/rest/v1/$table$separator$queryParams"
        val request = Request.Builder()
            .url(fullUrl)
            .get()
            .apply { buildHeaders(this) }
            .build()

        try {
            client.newCall(request).execute().use { response ->
                val body = response.body?.string() ?: "[]"
                if (response.isSuccessful) {
                    Result.success(JSONArray(body))
                } else {
                    Result.failure(Exception(parseError(body, response.code)))
                }
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun insert(table: String, jsonObject: JSONObject): Result<JSONObject> = withContext(Dispatchers.IO) {
        val url = "${config.url}/rest/v1/$table"
        val request = Request.Builder()
            .url(url)
            .post(jsonObject.toString().toRequestBody(jsonMediaType))
            .header("Prefer", "return=representation")
            .apply { buildHeaders(this) }
            .build()

        try {
            client.newCall(request).execute().use { response ->
                val body = response.body?.string() ?: ""
                if (response.isSuccessful) {
                    val result = if (body.startsWith("[")) {
                        val arr = JSONArray(body)
                        if (arr.length() > 0) arr.getJSONObject(0) else jsonObject
                    } else if (body.startsWith("{")) {
                        JSONObject(body)
                    } else {
                        jsonObject
                    }
                    Result.success(result)
                } else {
                    Result.failure(Exception(parseError(body, response.code)))
                }
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun update(table: String, idFilter: String, jsonObject: JSONObject): Result<JSONObject> = withContext(Dispatchers.IO) {
        val url = "${config.url}/rest/v1/$table?$idFilter"
        val request = Request.Builder()
            .url(url)
            .patch(jsonObject.toString().toRequestBody(jsonMediaType))
            .header("Prefer", "return=representation")
            .apply { buildHeaders(this) }
            .build()

        try {
            client.newCall(request).execute().use { response ->
                val body = response.body?.string() ?: ""
                if (response.isSuccessful) {
                    val result = if (body.startsWith("[")) {
                        val arr = JSONArray(body)
                        if (arr.length() > 0) arr.getJSONObject(0) else jsonObject
                    } else if (body.startsWith("{")) {
                        JSONObject(body)
                    } else {
                        jsonObject
                    }
                    Result.success(result)
                } else {
                    Result.failure(Exception(parseError(body, response.code)))
                }
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun delete(table: String, idFilter: String): Result<Boolean> = withContext(Dispatchers.IO) {
        val url = "${config.url}/rest/v1/$table?$idFilter"
        val request = Request.Builder()
            .url(url)
            .delete()
            .apply { buildHeaders(this) }
            .build()

        try {
            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    Result.success(true)
                } else {
                    val body = response.body?.string() ?: ""
                    Result.failure(Exception(parseError(body, response.code)))
                }
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun parseError(body: String, code: Int): String {
        return try {
            val json = JSONObject(body)
            val msg = json.optString("message", json.optString("msg", json.optString("error_description", "")))
            val hint = json.optString("hint", "")
            val details = json.optString("details", "")
            listOf(msg, hint, details).filter { it.isNotBlank() }.joinToString(" - ")
                .ifEmpty { "Server error code $code" }
        } catch (e: Exception) {
            if (body.isNotBlank() && body.length < 200) body else "HTTP Error $code"
        }
    }
}
