package com.example.ui.screens.sales

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.payment.PaymentMethod
import com.example.data.supabase.Goat
import com.example.data.supabase.SaleRecord
import com.example.ui.theme.FarmGreenDark
import com.example.ui.components.PaytmCyan
import com.example.ui.components.PaytmNavy
import com.example.util.CurrencyUtils

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RecordCreditPaymentDialog(
    sale: SaleRecord,
    goat: Goat?,
    onDismiss: () -> Unit,
    onConfirmPayment: (amount: Double, method: String, reference: String?, notes: String?) -> Unit
) {
    var amountInput by remember { mutableStateOf(if (sale.balance_due_c > 0) sale.balance_due_c.toString() else "") }
    var selectedMethod by remember { mutableStateOf(PaymentMethod.CASH) }
    var referenceInput by remember { mutableStateOf("") }
    var notesInput by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Payments,
                    contentDescription = null,
                    tint = FarmGreenDark,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text("Record Credit Payment", fontWeight = FontWeight.Bold, fontSize = 18.sp)
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Info Summary Card
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = Color(0xFFF8FAFC),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(
                            text = "Customer: ${sale.buyer_name_c}",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                        if (goat != null) {
                            Text(
                                text = "Goat: ${goat.name} (${goat.tag_c})",
                                fontSize = 12.sp,
                                color = Color.Gray
                            )
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Total Sale:", fontSize = 12.sp, color = Color.Gray)
                            Text(CurrencyUtils.formatInr(sale.amount_c), fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Already Paid:", fontSize = 12.sp, color = Color.Gray)
                            Text(CurrencyUtils.formatInr(sale.amount_paid_c), fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFF15803D))
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Balance Due:", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color(0xFFDC2626))
                            Text(CurrencyUtils.formatInr(sale.balance_due_c), fontSize = 14.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFFDC2626))
                        }
                    }
                }

                // Amount to Collect
                Text("Amount to Collect *", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold)
                OutlinedTextField(
                    value = amountInput,
                    onValueChange = { amountInput = it; errorMessage = null },
                    leadingIcon = {
                        Text("₹", fontWeight = FontWeight.Bold, fontSize = 16.sp, modifier = Modifier.padding(start = 12.dp))
                    },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("credit_payment_amount_input")
                )

                // Quick buttons: Pay Full Balance
                if (sale.balance_due_c > 0) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilledTonalButton(
                            onClick = { amountInput = sale.balance_due_c.toString() },
                            modifier = Modifier.weight(1f).height(36.dp),
                            contentPadding = PaddingValues(0.dp)
                        ) {
                            Text("Full: ${CurrencyUtils.formatInr(sale.balance_due_c)}", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                        if (sale.balance_due_c >= 2000) {
                            FilledTonalButton(
                                onClick = { amountInput = ((sale.balance_due_c / 2).toInt()).toString() },
                                modifier = Modifier.weight(1f).height(36.dp),
                                contentPadding = PaddingValues(0.dp)
                            ) {
                                Text("Half: ${CurrencyUtils.formatInr(sale.balance_due_c / 2)}", fontSize = 11.sp)
                            }
                        }
                    }
                }

                // Payment Method Selector: Cash, UPI / QR, Paytm Gateway
                Text("Payment Method *", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold)
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    FilterChip(
                        selected = selectedMethod == PaymentMethod.CASH,
                        onClick = { selectedMethod = PaymentMethod.CASH },
                        label = { Text("Cash", fontSize = 11.sp) },
                        leadingIcon = { Icon(Icons.Default.AccountBalanceWallet, null, modifier = Modifier.size(14.dp)) },
                        modifier = Modifier.weight(1f).height(40.dp)
                    )
                    FilterChip(
                        selected = selectedMethod == PaymentMethod.UPI_QR,
                        onClick = { selectedMethod = PaymentMethod.UPI_QR },
                        label = { Text("UPI / QR", fontSize = 11.sp) },
                        leadingIcon = { Icon(Icons.Default.QrCode, null, modifier = Modifier.size(14.dp)) },
                        modifier = Modifier.weight(1.1f).height(40.dp)
                    )
                    FilterChip(
                        selected = selectedMethod == PaymentMethod.PAYTM_GATEWAY,
                        onClick = { selectedMethod = PaymentMethod.PAYTM_GATEWAY },
                        label = { Text("Paytm", fontSize = 11.sp) },
                        leadingIcon = { Icon(Icons.Default.PhoneAndroid, null, modifier = Modifier.size(14.dp)) },
                        modifier = Modifier.weight(1f).height(40.dp)
                    )
                }

                // Reference / Txn ID
                OutlinedTextField(
                    value = referenceInput,
                    onValueChange = { referenceInput = it },
                    label = { Text("Reference / UTR / Txn ID") },
                    placeholder = { Text("e.g. UPI Ref / Bank Txn ID") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = notesInput,
                    onValueChange = { notesInput = it },
                    label = { Text("Notes (Optional)") },
                    placeholder = { Text("e.g. Paid in cash at farm") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                if (errorMessage != null) {
                    Text(errorMessage ?: "", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val amt = amountInput.toDoubleOrNull()
                    if (amt == null || amt <= 0) {
                        errorMessage = "Please enter a valid positive payment amount."
                        return@Button
                    }
                    if (amt > sale.balance_due_c && sale.balance_due_c > 0) {
                        errorMessage = "Payment amount cannot exceed outstanding balance of ${CurrencyUtils.formatInr(sale.balance_due_c)}."
                        return@Button
                    }
                    onConfirmPayment(amt, selectedMethod, referenceInput.ifBlank { null }, notesInput.ifBlank { null })
                },
                colors = ButtonDefaults.buttonColors(containerColor = FarmGreenDark),
                modifier = Modifier.height(44.dp).testTag("confirm_credit_payment_btn")
            ) {
                Text("Confirm Payment", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
