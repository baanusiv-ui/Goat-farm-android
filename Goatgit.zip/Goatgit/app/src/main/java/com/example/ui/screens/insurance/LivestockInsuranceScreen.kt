package com.example.ui.screens.insurance

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.supabase.*
import com.example.ui.components.DatePickerField
import com.example.ui.theme.*
import com.example.util.CurrencyUtils
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.TimeUnit

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LivestockInsuranceScreen(
    repository: GoatRepository,
    initialGoatId: String? = null,
    onNavigateBack: () -> Unit,
    onNavigateToMortality: () -> Unit = {},
    showTopBar: Boolean = true,
    modifier: Modifier = Modifier
) {
    if (showTopBar) {
        BackHandler { onNavigateBack() }
    }

    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val dateFormat = remember { SimpleDateFormat("yyyy-MM-dd", Locale.US) }
    val today = remember { dateFormat.format(Date()) }

    // Tabs: 0: Policies, 1: Claims, 2: Alerts, 3: Documents, 4: Providers, 5: Get Quote
    var selectedTab by remember { mutableIntStateOf(0) }
    var policyFilterSubSection by remember { mutableStateOf("ALL") } // ALL, ACTIVE, EXPIRING, DUE

    var policies by remember { mutableStateOf<List<InsurancePolicy>>(emptyList()) }
    var claims by remember { mutableStateOf<List<InsuranceClaim>>(emptyList()) }
    var providers by remember { mutableStateOf<List<InsuranceProvider>>(emptyList()) }
    var dueItems by remember { mutableStateOf<List<InsuranceDueItem>>(emptyList()) }
    var alerts by remember { mutableStateOf<List<InsuranceAlert>>(emptyList()) }
    var goats by remember { mutableStateOf<List<Goat>>(emptyList()) }
    var accounts by remember { mutableStateOf<List<FinancialAccount>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }

    // Dialog states
    var showNewPolicyDialog by remember { mutableStateOf(false) }
    var showRenewPolicyDialog by remember { mutableStateOf(false) }
    var showNewClaimDialog by remember { mutableStateOf(false) }
    var showUploadDocDialog by remember { mutableStateOf(false) }
    var showAddProviderDialog by remember { mutableStateOf(false) }
    var providerToEdit by remember { mutableStateOf<InsuranceProvider?>(null) }
    var claimToSettle by remember { mutableStateOf<InsuranceClaim?>(null) }
    var claimToUpdateStatus by remember { mutableStateOf<InsuranceClaim?>(null) }
    var selectedPolicyForClaim by remember { mutableStateOf<InsurancePolicy?>(null) }
    var selectedPolicyForRenew by remember { mutableStateOf<InsurancePolicy?>(null) }

    fun loadData() {
        isLoading = true
        coroutineScope.launch {
            val polRes = repository.insurance.getPolicies()
            if (polRes.isSuccess) policies = polRes.getOrThrow()

            val claimRes = repository.insurance.getClaims()
            if (claimRes.isSuccess) claims = claimRes.getOrThrow()

            val provRes = repository.insurance.getProviders(includeInactive = true)
            if (provRes.isSuccess) providers = provRes.getOrThrow()

            val dueRes = repository.insurance.getInsuranceDueItems()
            if (dueRes.isSuccess) dueItems = dueRes.getOrThrow()

            val alertRes = repository.insurance.getActiveAlerts()
            if (alertRes.isSuccess) alerts = alertRes.getOrThrow()

            val goatsRes = repository.getGoats()
            if (goatsRes.isSuccess) goats = goatsRes.getOrThrow()

            val accRes = repository.finance.getAccounts()
            if (accRes.isSuccess) accounts = accRes.getOrThrow()

            isLoading = false
        }
    }

    LaunchedEffect(Unit) {
        loadData()
    }

    val activePolicies = remember(policies) { policies.filter { it.isActive } }
    val expiringPolicies = remember(policies) { policies.filter { it.isExpiringSoon } }
    val premiumDuePolicies = remember(policies, dueItems) {
        policies.filter { p ->
            p.status.equals("Expiring Soon", ignoreCase = true) || p.status.equals("Expired", ignoreCase = true)
        }
    }
    val pendingClaims = remember(claims) {
        claims.filter { !it.status.equals("Settled", ignoreCase = true) && !it.status.equals("Closed", ignoreCase = true) && !it.status.equals("Rejected", ignoreCase = true) }
    }

    Scaffold(
        topBar = {
            if (showTopBar) {
                TopAppBar(
                    title = {
                        Column {
                            Text(
                                text = "Insurance Management",
                                fontWeight = FontWeight.Bold,
                                fontSize = 18.sp
                            )
                            Text(
                                text = "Policies, Claims, Alerts & Insurer Master",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    },
                    navigationIcon = {
                        IconButton(
                            onClick = onNavigateBack,
                            modifier = Modifier.testTag("insurance_btn_back")
                        ) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                        }
                    },
                    actions = {
                        IconButton(
                            onClick = { showRenewPolicyDialog = true },
                            modifier = Modifier.testTag("insurance_btn_renew_top")
                        ) {
                            Icon(Icons.Default.Autorenew, contentDescription = "Renew Policy")
                        }
                        IconButton(
                            onClick = { showUploadDocDialog = true },
                            modifier = Modifier.testTag("insurance_btn_upload_top")
                        ) {
                            Icon(Icons.Default.UploadFile, contentDescription = "Upload Document")
                        }
                        IconButton(
                            onClick = { loadData() },
                            modifier = Modifier.testTag("insurance_btn_refresh")
                        ) {
                            Icon(Icons.Default.Refresh, contentDescription = "Refresh")
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.White)
                )
            }
        },
        floatingActionButton = {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (selectedTab == 0) {
                    ExtendedFloatingActionButton(
                        onClick = { showRenewPolicyDialog = true },
                        containerColor = Color(0xFF0284C7),
                        contentColor = Color.White,
                        icon = { Icon(Icons.Default.Autorenew, contentDescription = null) },
                        text = { Text("Renew", fontWeight = FontWeight.Bold) },
                        modifier = Modifier.testTag("fab_renew_policy")
                    )
                    ExtendedFloatingActionButton(
                        onClick = { showNewPolicyDialog = true },
                        containerColor = FarmGreenDark,
                        contentColor = Color.White,
                        icon = { Icon(Icons.Default.AddModerator, contentDescription = null) },
                        text = { Text("+ Add Policy", fontWeight = FontWeight.Bold) },
                        modifier = Modifier.testTag("fab_new_policy")
                    )
                } else if (selectedTab == 1) {
                    ExtendedFloatingActionButton(
                        onClick = { showNewClaimDialog = true },
                        containerColor = Color(0xFFC2410C),
                        contentColor = Color.White,
                        icon = { Icon(Icons.Default.ReportProblem, contentDescription = null) },
                        text = { Text("+ Submit Claim", fontWeight = FontWeight.Bold) },
                        modifier = Modifier.testTag("fab_new_claim")
                    )
                } else if (selectedTab == 3) {
                    ExtendedFloatingActionButton(
                        onClick = { showUploadDocDialog = true },
                        containerColor = Color(0xFF1E3A8A),
                        contentColor = Color.White,
                        icon = { Icon(Icons.Default.UploadFile, contentDescription = null) },
                        text = { Text("+ Upload Doc", fontWeight = FontWeight.Bold) },
                        modifier = Modifier.testTag("fab_upload_doc")
                    )
                } else if (selectedTab == 4) {
                    ExtendedFloatingActionButton(
                        onClick = { showAddProviderDialog = true },
                        containerColor = FarmGreenDark,
                        contentColor = Color.White,
                        icon = { Icon(Icons.Default.Domain, contentDescription = null) },
                        text = { Text("+ Add Insurer", fontWeight = FontWeight.Bold) },
                        modifier = Modifier.testTag("fab_add_provider")
                    )
                }
            }
        },
        containerColor = Color(0xFFF8F9FA),
        modifier = modifier
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Action shortcuts strip
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color.White)
                    .padding(horizontal = 12.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = { showNewPolicyDialog = true },
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                    modifier = Modifier.height(30.dp)
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Add Policy", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
                OutlinedButton(
                    onClick = { showRenewPolicyDialog = true },
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                    modifier = Modifier.height(30.dp)
                ) {
                    Icon(Icons.Default.Autorenew, contentDescription = null, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Renew Policy", fontSize = 11.sp)
                }
                OutlinedButton(
                    onClick = { showNewClaimDialog = true },
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                    modifier = Modifier.height(30.dp)
                ) {
                    Icon(Icons.Default.ReportProblem, contentDescription = null, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Submit Claim", fontSize = 11.sp)
                }
                OutlinedButton(
                    onClick = { showUploadDocDialog = true },
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                    modifier = Modifier.height(30.dp)
                ) {
                    Icon(Icons.Default.UploadFile, contentDescription = null, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Upload Doc", fontSize = 11.sp)
                }
            }

            // Tabs
            ScrollableTabRow(
                selectedTabIndex = selectedTab,
                containerColor = Color.White,
                edgePadding = 12.dp
            ) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = { Text("Policies (${policies.size})", fontSize = 12.sp, fontWeight = FontWeight.Bold) },
                    modifier = Modifier.testTag("tab_policies")
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Claims (${claims.size})", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            if (pendingClaims.isNotEmpty()) {
                                Spacer(modifier = Modifier.width(4.dp))
                                Badge(containerColor = Color(0xFFC2410C)) { Text("${pendingClaims.size}") }
                            }
                        }
                    },
                    modifier = Modifier.testTag("tab_claims")
                )
                Tab(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    text = {
                        val alertBadgeCount = alerts.size + dueItems.size
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Alerts", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            if (alertBadgeCount > 0) {
                                Spacer(modifier = Modifier.width(4.dp))
                                Badge(containerColor = Color(0xFFDC2626)) { Text("$alertBadgeCount") }
                            }
                        }
                    },
                    modifier = Modifier.testTag("tab_alerts")
                )
                Tab(
                    selected = selectedTab == 3,
                    onClick = { selectedTab = 3 },
                    text = { Text("Documents", fontSize = 12.sp, fontWeight = FontWeight.Bold) },
                    modifier = Modifier.testTag("tab_documents")
                )
                Tab(
                    selected = selectedTab == 4,
                    onClick = { selectedTab = 4 },
                    text = { Text("Insurer Master (${providers.size})", fontSize = 12.sp, fontWeight = FontWeight.Bold) },
                    modifier = Modifier.testTag("tab_providers")
                )
                Tab(
                    selected = selectedTab == 5,
                    onClick = { selectedTab = 5 },
                    text = { Text("Get Quote", fontSize = 12.sp, fontWeight = FontWeight.Bold) },
                    modifier = Modifier.testTag("tab_quotes")
                )
            }

            if (isLoading) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = FarmGreenDark)
                }
            } else {
                when (selectedTab) {
                    0 -> PoliciesMasterSection(
                        policies = policies,
                        activePolicies = activePolicies,
                        expiringPolicies = expiringPolicies,
                        premiumDuePolicies = premiumDuePolicies,
                        currentSubSection = policyFilterSubSection,
                        onSubSectionChange = { policyFilterSubSection = it },
                        onClaimForPolicy = { policy ->
                            selectedPolicyForClaim = policy
                            showNewClaimDialog = true
                        },
                        onRenewPolicy = { policy ->
                            selectedPolicyForRenew = policy
                            showRenewPolicyDialog = true
                        }
                    )
                    1 -> ClaimsMasterSection(
                        claims = claims,
                        onSettle = { claimToSettle = it },
                        onUpdateStatus = { claimToUpdateStatus = it },
                        onSubmitNewClaim = { showNewClaimDialog = true }
                    )
                    2 -> InsuranceAlertsSection(
                        dueItems = dueItems,
                        alerts = alerts,
                        claims = claims,
                        onDismissAlert = { alertId ->
                            coroutineScope.launch {
                                repository.insurance.dismissAlert(alertId)
                                loadData()
                            }
                        },
                        onRenewPolicy = { policyId ->
                            val pol = policies.find { it.id == policyId }
                            selectedPolicyForRenew = pol
                            showRenewPolicyDialog = true
                        }
                    )
                    3 -> InsuranceDocumentsSection(
                        policies = policies,
                        claims = claims,
                        onUploadNew = { showUploadDocDialog = true }
                    )
                    4 -> ProvidersMasterSection(
                        providers = providers,
                        onSaveProvider = { prov ->
                            coroutineScope.launch {
                                repository.insurance.saveProvider(prov)
                                Toast.makeText(context, "Provider saved", Toast.LENGTH_SHORT).show()
                                loadData()
                            }
                        },
                        onToggleActive = { provId, isAct ->
                            coroutineScope.launch {
                                repository.insurance.setProviderActive(provId, isAct)
                                loadData()
                            }
                        },
                        onEditProvider = { providerToEdit = it }
                    )
                    5 -> QuotesTabContent(
                        goats = goats,
                        providers = providers.filter { it.is_active },
                        onQuoteSelected = { goat, provider, sumIns, prem ->
                            showNewPolicyDialog = true
                        }
                    )
                }
            }
        }
    }

    // ==============================================================================
    // DIALOGS
    // ==============================================================================

    // Dialog: New Insurance Policy (with multiple goat selection & dropdown)
    if (showNewPolicyDialog) {
        NewPolicyDialog(
            goats = goats,
            providers = providers.filter { it.is_active },
            accounts = accounts,
            initialGoatId = initialGoatId,
            onDismiss = { showNewPolicyDialog = false },
            onSave = { policyList, paymentAccountId ->
                showNewPolicyDialog = false
                coroutineScope.launch {
                    val res = repository.insurance.savePoliciesForMultipleGoats(policyList, paymentAccountId)
                    if (res.isSuccess) {
                        Toast.makeText(context, "${policyList.size} goat policy(s) created and registered!", Toast.LENGTH_SHORT).show()
                        loadData()
                    } else {
                        Toast.makeText(context, "Error: ${res.exceptionOrNull()?.message}", Toast.LENGTH_LONG).show()
                    }
                }
            }
        )
    }

    // Dialog: Renew Policy
    if (showRenewPolicyDialog) {
        RenewPolicyDialog(
            policies = policies,
            accounts = accounts,
            preselectedPolicy = selectedPolicyForRenew,
            onDismiss = {
                showRenewPolicyDialog = false
                selectedPolicyForRenew = null
            },
            onRenew = { renewedPolicy, paymentAccountId ->
                showRenewPolicyDialog = false
                selectedPolicyForRenew = null
                coroutineScope.launch {
                    val res = repository.insurance.savePolicy(renewedPolicy, paymentAccountId)
                    if (res.isSuccess) {
                        Toast.makeText(context, "Policy renewed for goat ${renewedPolicy.goat_tag}!", Toast.LENGTH_SHORT).show()
                        loadData()
                    } else {
                        Toast.makeText(context, "Error: ${res.exceptionOrNull()?.message}", Toast.LENGTH_LONG).show()
                    }
                }
            }
        )
    }

    // Dialog: Submit Claim
    if (showNewClaimDialog) {
        SubmitClaimDialog(
            policies = policies.filter { !it.status.equals("Expired", ignoreCase = true) && !it.status.equals("Cancelled", ignoreCase = true) },
            goats = goats,
            preselectedPolicy = selectedPolicyForClaim,
            onDismiss = {
                showNewClaimDialog = false
                selectedPolicyForClaim = null
            },
            onSubmit = { claim ->
                showNewClaimDialog = false
                selectedPolicyForClaim = null
                coroutineScope.launch {
                    val res = repository.insurance.submitClaim(claim)
                    if (res.isSuccess) {
                        Toast.makeText(context, "Claim #${claim.claim_number ?: "New"} submitted successfully with status ${claim.status}", Toast.LENGTH_LONG).show()
                        loadData()
                    } else {
                        Toast.makeText(context, "Error: ${res.exceptionOrNull()?.message}", Toast.LENGTH_LONG).show()
                    }
                }
            }
        )
    }

    // Dialog: Update Claim Status
    claimToUpdateStatus?.let { claim ->
        UpdateClaimStatusDialog(
            claim = claim,
            onDismiss = { claimToUpdateStatus = null },
            onUpdate = { newStatus ->
                claimToUpdateStatus = null
                coroutineScope.launch {
                    val res = repository.insurance.updateClaimStatusOnly(claim.id, newStatus)
                    if (res.isSuccess) {
                        Toast.makeText(context, "Claim status updated to $newStatus", Toast.LENGTH_SHORT).show()
                        loadData()
                    } else {
                        Toast.makeText(context, "Error: ${res.exceptionOrNull()?.message}", Toast.LENGTH_LONG).show()
                    }
                }
            }
        )
    }

    // Dialog: Settle Claim
    claimToSettle?.let { claim ->
        SettleClaimDialog(
            claim = claim,
            accounts = accounts,
            onDismiss = { claimToSettle = null },
            onSettle = { amt, date, accId, rem ->
                claimToSettle = null
                coroutineScope.launch {
                    val res = repository.insurance.settleClaim(
                        claimId = claim.id,
                        settlementAmount = amt,
                        settlementDate = date,
                        settlementAccountId = accId,
                        remarks = rem
                    )
                    if (res.isSuccess) {
                        Toast.makeText(context, "Claim settled! Payout recorded in Cash/Bank ledger", Toast.LENGTH_LONG).show()
                        loadData()
                    } else {
                        Toast.makeText(context, "Error: ${res.exceptionOrNull()?.message}", Toast.LENGTH_LONG).show()
                    }
                }
            }
        )
    }

    // Dialog: Upload Document
    if (showUploadDocDialog) {
        UploadDocumentDialog(
            policies = policies,
            goats = goats,
            onDismiss = { showUploadDocDialog = false },
            onSave = { docName, docType, policyId, url ->
                showUploadDocDialog = false
                Toast.makeText(context, "Document '$docName' registered to policy records.", Toast.LENGTH_SHORT).show()
            }
        )
    }

    // Dialog: Add / Edit Provider (Insurers Master)
    if (showAddProviderDialog || providerToEdit != null) {
        val editing = providerToEdit
        AddEditProviderDialog(
            initial = editing,
            onDismiss = {
                showAddProviderDialog = false
                providerToEdit = null
            },
            onSave = { prov ->
                showAddProviderDialog = false
                providerToEdit = null
                coroutineScope.launch {
                    repository.insurance.saveProvider(prov)
                    Toast.makeText(context, "Insurer '${prov.company_name}' saved to master table", Toast.LENGTH_SHORT).show()
                    loadData()
                }
            }
        )
    }
}

// ==============================================================================
// 1. POLICIES MASTER SECTION (Policies, Active, Expiring, Premium Due)
// ==============================================================================
@Composable
private fun PoliciesMasterSection(
    policies: List<InsurancePolicy>,
    activePolicies: List<InsurancePolicy>,
    expiringPolicies: List<InsurancePolicy>,
    premiumDuePolicies: List<InsurancePolicy>,
    currentSubSection: String,
    onSubSectionChange: (String) -> Unit,
    onClaimForPolicy: (InsurancePolicy) -> Unit,
    onRenewPolicy: (InsurancePolicy) -> Unit
) {
    val displayList = when (currentSubSection) {
        "ACTIVE" -> activePolicies
        "EXPIRING" -> expiringPolicies
        "DUE" -> premiumDuePolicies
        else -> policies
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Section Filter Chips
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                FilterChip(
                    selected = currentSubSection == "ALL",
                    onClick = { onSubSectionChange("ALL") },
                    label = { Text("All (${policies.size})", fontSize = 11.sp) },
                    colors = FilterChipDefaults.filterChipColors(selectedContainerColor = FarmGreenDark, selectedLabelColor = Color.White)
                )
                FilterChip(
                    selected = currentSubSection == "ACTIVE",
                    onClick = { onSubSectionChange("ACTIVE") },
                    label = { Text("Active (${activePolicies.size})", fontSize = 11.sp) },
                    colors = FilterChipDefaults.filterChipColors(selectedContainerColor = Color(0xFF15803D), selectedLabelColor = Color.White)
                )
                FilterChip(
                    selected = currentSubSection == "EXPIRING",
                    onClick = { onSubSectionChange("EXPIRING") },
                    label = { Text("Expiring Soon (${expiringPolicies.size})", fontSize = 11.sp) },
                    colors = FilterChipDefaults.filterChipColors(selectedContainerColor = Color(0xFFC2410C), selectedLabelColor = Color.White)
                )
                FilterChip(
                    selected = currentSubSection == "DUE",
                    onClick = { onSubSectionChange("DUE") },
                    label = { Text("Premium Due (${premiumDuePolicies.size})", fontSize = 11.sp) },
                    colors = FilterChipDefaults.filterChipColors(selectedContainerColor = Color(0xFFB91C1C), selectedLabelColor = Color.White)
                )
            }
        }

        // Summary Metric Row
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                MetricCard(
                    title = "Total Insured",
                    value = "${activePolicies.size}",
                    subtitle = "Covered Goats",
                    color = FarmGreenDark,
                    modifier = Modifier.weight(1f)
                )
                MetricCard(
                    title = "Sum Insured",
                    value = CurrencyUtils.formatInr(activePolicies.sumOf { it.sum_insured }),
                    subtitle = "Total Valuation",
                    color = Color(0xFF1E3A8A),
                    modifier = Modifier.weight(1.3f)
                )
                MetricCard(
                    title = "Expiring",
                    value = "${expiringPolicies.size}",
                    subtitle = "Action Needed",
                    color = Color(0xFFC2410C),
                    modifier = Modifier.weight(1f)
                )
            }
        }

        if (displayList.isEmpty()) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth().padding(vertical = 16.dp)
                ) {
                    Column(
                        modifier = Modifier.fillMaxWidth().padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(Icons.Default.Shield, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(36.dp))
                        Text("No policies in this section.", fontWeight = FontWeight.Bold, color = Color.Gray)
                        Text("Tap '+ Add Policy' to register insurance coverage for your flock.", fontSize = 12.sp, color = Color.LightGray)
                    }
                }
            }
        } else {
            items(displayList) { policy ->
                PolicyItemCard(
                    policy = policy,
                    onClaim = { onClaimForPolicy(policy) },
                    onRenew = { onRenewPolicy(policy) }
                )
            }
        }

        item {
            Spacer(modifier = Modifier.height(72.dp))
        }
    }
}

@Composable
private fun PolicyItemCard(
    policy: InsurancePolicy,
    onClaim: () -> Unit,
    onRenew: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(12.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier.fillMaxWidth().testTag("policy_item_${policy.id}")
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Goat: ${policy.goat_tag} (${policy.goat_name ?: "Insured"})",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = FarmGreenDark
                    )
                    Text(
                        text = "Company: ${policy.insurance_company}",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Color.DarkGray
                    )
                    Text(
                        text = "Policy: ${policy.policy_number ?: "Draft"} • ${policy.coverage_type}",
                        fontSize = 11.sp,
                        color = Color.Gray
                    )
                }

                val statusColor = when (policy.status.lowercase()) {
                    "active" -> Color(0xFF15803D)
                    "expiring soon" -> Color(0xFFC2410C)
                    "expired" -> Color(0xFFDC2626)
                    "claim submitted", "under review" -> Color(0xFF2563EB)
                    "claim settled" -> Color(0xFF047857)
                    else -> Color.Gray
                }
                Surface(
                    color = statusColor.copy(alpha = 0.12f),
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text(
                        text = policy.status.uppercase(),
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = statusColor,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            HorizontalDivider(color = Color(0xFFF1F5F9))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text("Sum Insured: ${CurrencyUtils.formatInr(policy.sum_insured)}", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Text("Premium: ${CurrencyUtils.formatInr(policy.total_premium)}", fontSize = 11.sp, color = FarmGreenDark)
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text("Valid: ${policy.start_date}", fontSize = 10.sp, color = Color.Gray)
                    Text("Expires: ${policy.expiry_date}", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = if (policy.isExpiringSoon) Color(0xFFC2410C) else Color.DarkGray)
                }
            }

            // Actions
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedButton(
                    onClick = onRenew,
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                    modifier = Modifier.height(28.dp)
                ) {
                    Icon(Icons.Default.Autorenew, contentDescription = null, modifier = Modifier.size(12.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Renew", fontSize = 10.sp)
                }
                Spacer(modifier = Modifier.width(6.dp))
                Button(
                    onClick = onClaim,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFC2410C)),
                    shape = RoundedCornerShape(6.dp),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                    modifier = Modifier.height(28.dp)
                ) {
                    Icon(Icons.Default.ReportProblem, contentDescription = null, modifier = Modifier.size(12.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Submit Claim", fontSize = 10.sp)
                }
            }
        }
    }
}

// ==============================================================================
// 2. CLAIMS MASTER SECTION
// ==============================================================================
@Composable
private fun ClaimsMasterSection(
    claims: List<InsuranceClaim>,
    onSettle: (InsuranceClaim) -> Unit,
    onUpdateStatus: (InsuranceClaim) -> Unit,
    onSubmitNewClaim: () -> Unit
) {
    var selectedStatusFilter by remember { mutableStateOf("ALL") }

    val filteredClaims = remember(claims, selectedStatusFilter) {
        if (selectedStatusFilter == "ALL") claims
        else claims.filter { it.status.equals(selectedStatusFilter, ignoreCase = true) }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Status filter chips
        item {
            ScrollableTabRow(
                selectedTabIndex = 0,
                containerColor = Color.Transparent,
                divider = {},
                edgePadding = 0.dp
            ) {
                listOf("ALL", "DRAFT", "SUBMITTED", "UNDER_REVIEW", "APPROVED", "PARTIALLY_APPROVED", "REJECTED", "SETTLED", "CLOSED").forEach { st ->
                    FilterChip(
                        selected = selectedStatusFilter == st,
                        onClick = { selectedStatusFilter = st },
                        label = { Text(st.replace("_", " "), fontSize = 10.sp) },
                        modifier = Modifier.padding(end = 4.dp),
                        colors = FilterChipDefaults.filterChipColors(selectedContainerColor = Color(0xFFC2410C), selectedLabelColor = Color.White)
                    )
                }
            }
        }

        if (filteredClaims.isEmpty()) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth().padding(vertical = 16.dp)
                ) {
                    Column(
                        modifier = Modifier.fillMaxWidth().padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = FarmSuccess, modifier = Modifier.size(36.dp))
                        Text("No insurance claims under this filter.", fontWeight = FontWeight.Bold, color = Color.Gray)
                        Text("Submit claims for goat mortality, theft, or disability.", fontSize = 11.sp, color = Color.LightGray)
                    }
                }
            }
        } else {
            items(filteredClaims) { claim ->
                ClaimItemCard(
                    claim = claim,
                    onSettle = { onSettle(claim) },
                    onUpdateStatus = { onUpdateStatus(claim) }
                )
            }
        }

        item {
            Spacer(modifier = Modifier.height(72.dp))
        }
    }
}

@Composable
private fun ClaimItemCard(
    claim: InsuranceClaim,
    onSettle: () -> Unit,
    onUpdateStatus: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(12.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("Claim #${claim.claim_number ?: claim.id.take(8).uppercase()}", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Text("Goat: ${claim.goat_tag} • Incident: ${claim.incident_type}", fontSize = 11.sp, color = Color.DarkGray)
                }

                val badgeColor = when (claim.status.uppercase()) {
                    "SETTLED" -> Color(0xFF15803D)
                    "APPROVED" -> Color(0xFF047857)
                    "UNDER_REVIEW", "SUBMITTED" -> Color(0xFF1E3A8A)
                    "REJECTED" -> Color(0xFFDC2626)
                    "DRAFT" -> Color.Gray
                    else -> Color(0xFFC2410C)
                }
                Surface(
                    color = badgeColor.copy(alpha = 0.12f),
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text(
                        text = claim.status.replace("_", " "),
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = badgeColor,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            HorizontalDivider(color = Color(0xFFF1F5F9))

            Text("Cause: ${claim.cause}", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            if (!claim.description.isNullOrBlank()) {
                Text(claim.description, fontSize = 11.sp, color = Color.DarkGray)
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("Claim Amount: ${CurrencyUtils.formatInr(claim.claim_amount)}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFFC2410C))
                Text("Date: ${claim.incident_date}", fontSize = 11.sp, color = Color.Gray)
            }

            if (claim.settlement_amount != null && claim.settlement_amount > 0) {
                Surface(
                    color = Color(0xFFDCFCE7),
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Settled Payout:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = FarmGreenDark)
                        Text("${CurrencyUtils.formatInr(claim.settlement_amount)} on ${claim.settlement_date ?: ""}", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = FarmGreenDark)
                    }
                }
            }

            // Action row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedButton(
                    onClick = onUpdateStatus,
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                    modifier = Modifier.height(28.dp)
                ) {
                    Text("Update Status", fontSize = 10.sp)
                }
                if (!claim.status.equals("Settled", ignoreCase = true) && !claim.status.equals("Closed", ignoreCase = true)) {
                    Spacer(modifier = Modifier.width(6.dp))
                    Button(
                        onClick = onSettle,
                        colors = ButtonDefaults.buttonColors(containerColor = FarmGreenDark),
                        shape = RoundedCornerShape(6.dp),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                        modifier = Modifier.height(28.dp)
                    ) {
                        Text("Record Payout", fontSize = 10.sp)
                    }
                }
            }
        }
    }
}

// ==============================================================================
// 3. INSURANCE ALERTS SECTION
// ==============================================================================
@Composable
private fun InsuranceAlertsSection(
    dueItems: List<InsuranceDueItem>,
    alerts: List<InsuranceAlert>,
    claims: List<InsuranceClaim>,
    onDismissAlert: (String) -> Unit,
    onRenewPolicy: (String) -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Text("Active Insurance Alerts & Policy Expiries", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Color(0xFFC2410C))
            Text("Alerts track expiring policies (30, 15, 7, 3, 1, 0 days), pending claims, and premium dues.", fontSize = 11.sp, color = Color.Gray)
        }

        if (dueItems.isNotEmpty()) {
            item {
                Text("Policies Expiring / Premium Due (${dueItems.size})", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color(0xFF9A3412))
            }
            items(dueItems) { due ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF7ED)),
                    shape = RoundedCornerShape(10.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFFED7AA)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Goat: ${due.goatTag} • Policy: ${due.policyNumber ?: "Pending"}", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            Text("Company: ${due.company} • Expires: ${due.expiryDate}", fontSize = 11.sp, color = Color.DarkGray)
                            Text("${due.daysRemaining} days remaining", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFFC2410C))
                        }
                        Button(
                            onClick = { onRenewPolicy(due.policyId) },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFC2410C)),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                            modifier = Modifier.height(28.dp)
                        ) {
                            Text("Renew", fontSize = 10.sp)
                        }
                    }
                }
            }
        }

        if (alerts.isNotEmpty()) {
            item {
                Text("System Alerts (${alerts.size})", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color(0xFF1E3A8A))
            }
            items(alerts) { al ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(al.title, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            Text(al.message, fontSize = 11.sp, color = Color.DarkGray)
                            Text("Due: ${al.due_date}", fontSize = 10.sp, color = Color.Gray)
                        }
                        IconButton(onClick = { onDismissAlert(al.id) }) {
                            Icon(Icons.Default.Check, contentDescription = "Dismiss", tint = Color.Gray)
                        }
                    }
                }
            }
        }

        if (dueItems.isEmpty() && alerts.isEmpty()) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth().padding(vertical = 16.dp)
                ) {
                    Column(
                        modifier = Modifier.fillMaxWidth().padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = FarmSuccess, modifier = Modifier.size(36.dp))
                        Text("No pending insurance alerts.", fontWeight = FontWeight.Bold, color = Color.Gray)
                        Text("All policies are up to date and in active standing.", fontSize = 11.sp, color = Color.LightGray)
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(72.dp))
        }
    }
}

// ==============================================================================
// 4. INSURANCE DOCUMENTS SECTION
// ==============================================================================
@Composable
private fun InsuranceDocumentsSection(
    policies: List<InsurancePolicy>,
    claims: List<InsuranceClaim>,
    onUploadNew: () -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("Insurance Documents & Certificates", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Color(0xFF1E3A8A))
                    Text("Policy certificates, ear-tag photos & veterinary records", fontSize = 11.sp, color = Color.Gray)
                }
                Button(
                    onClick = onUploadNew,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E3A8A)),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                    modifier = Modifier.height(30.dp)
                ) {
                    Icon(Icons.Default.UploadFile, contentDescription = null, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Upload", fontSize = 11.sp)
                }
            }
        }

        items(policies) { p ->
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Description, contentDescription = null, tint = Color(0xFF1E3A8A), modifier = Modifier.size(24.dp))
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text("Policy Document - Goat ${p.goat_tag}", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            Text("Insurer: ${p.insurance_company} • #${p.policy_number ?: "Draft"}", fontSize = 11.sp, color = Color.Gray)
                        }
                    }
                    Surface(
                        color = Color(0xFFEFF6FF),
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Text(
                            text = if (!p.policy_document_url.isNullOrBlank()) "Attached" else "On File",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF1E3A8A),
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(72.dp))
        }
    }
}

// ==============================================================================
// 5. PROVIDERS MASTER SECTION (Admin Master Table with 24 Indian General Insurers)
// ==============================================================================
@Composable
private fun ProvidersMasterSection(
    providers: List<InsuranceProvider>,
    onSaveProvider: (InsuranceProvider) -> Unit,
    onToggleActive: (String, Boolean) -> Unit,
    onEditProvider: (InsuranceProvider) -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Text("Insurance Providers Master Table", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = FarmGreenDark)
            Text(
                "Master directory seeded with 24 Indian general insurers. Actual livestock-policy availability depends on the insurer/product. Admin can add, edit, or toggle active/inactive.",
                fontSize = 11.sp,
                color = Color.Gray
            )
        }

        items(providers) { prov ->
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(10.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(prov.company_name, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Text("Code: ${prov.code ?: "GEN"} • Type: ${prov.type}", fontSize = 11.sp, color = Color.Gray)
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(if (prov.is_active) "Active" else "Inactive", fontSize = 10.sp, color = if (prov.is_active) Color(0xFF15803D) else Color.Gray)
                            Spacer(modifier = Modifier.width(4.dp))
                            Switch(
                                checked = prov.is_active,
                                onCheckedChange = { isAct -> onToggleActive(prov.id, isAct) },
                                modifier = Modifier.height(24.dp)
                            )
                        }
                    }

                    if (!prov.notes.isNullOrBlank()) {
                        Text(prov.notes, fontSize = 11.sp, color = Color.DarkGray)
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        OutlinedButton(
                            onClick = { onEditProvider(prov) },
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                            modifier = Modifier.height(26.dp)
                        ) {
                            Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(12.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Edit", fontSize = 10.sp)
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(72.dp))
        }
    }
}

// ==============================================================================
// 6. GET QUOTE TAB
// ==============================================================================
@Composable
private fun QuotesTabContent(
    goats: List<Goat>,
    providers: List<InsuranceProvider>,
    onQuoteSelected: (Goat, InsuranceProvider, Double, Double) -> Unit
) {
    var selectedGoatId by remember { mutableStateOf(goats.firstOrNull()?.id ?: "") }
    val selectedGoat = goats.find { it.id == selectedGoatId }
    val sumIns = (selectedGoat?.weight_kg_c ?: 35.0) * 350.0

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Text("Instant Indicative Insurance Quotes", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = FarmGreenDark)
            Text("Calculated from current live weight and market valuation rates for small ruminants.", fontSize = 11.sp, color = Color.Gray)
        }

        items(providers.take(6)) { prov ->
            val rate = 0.045
            val prem = sumIns * rate
            val gst = prem * 0.18
            val total = prem + gst

            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(prov.company_name, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Sum Insured: ${CurrencyUtils.formatInr(sumIns)}", fontSize = 11.sp)
                        Text("Est. Premium: ${CurrencyUtils.formatInr(total)}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = FarmGreenDark)
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                        Button(
                            onClick = { selectedGoat?.let { onQuoteSelected(it, prov, sumIns, total) } },
                            colors = ButtonDefaults.buttonColors(containerColor = FarmGreenDark),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                            modifier = Modifier.height(28.dp)
                        ) {
                            Text("Apply for Policy", fontSize = 10.sp)
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(72.dp))
        }
    }
}

// ==============================================================================
// DIALOG IMPLEMENTATIONS
// ==============================================================================

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun NewPolicyDialog(
    goats: List<Goat>,
    providers: List<InsuranceProvider>,
    accounts: List<FinancialAccount>,
    initialGoatId: String?,
    onDismiss: () -> Unit,
    onSave: (List<InsurancePolicy>, paymentAccountId: String?) -> Unit
) {
    val activeGoats = remember(goats) { goats.filter { !it.status_c.equals("Deceased", ignoreCase = true) } }

    // Covered goats mode: "INDIVIDUAL", "MULTIPLE", "ALL_HERD", "DOES", "BUCKS"
    var selectionMode by remember { mutableStateOf(if (initialGoatId != null) "INDIVIDUAL" else "INDIVIDUAL") }
    var singleGoatId by remember { mutableStateOf(initialGoatId ?: activeGoats.firstOrNull()?.id ?: "") }
    var singleGoatExpanded by remember { mutableStateOf(false) }

    val multipleSelectedGoatIds = remember {
        mutableStateListOf<String>().apply {
            if (initialGoatId != null) add(initialGoatId)
            else activeGoats.firstOrNull()?.id?.let { add(it) }
        }
    }

    var selectedProviderName by remember { mutableStateOf(providers.firstOrNull()?.company_name ?: "Select") }
    var providerExpanded by remember { mutableStateOf(false) }

    var policyNumber by remember { mutableStateOf("") }
    var policyType by remember { mutableStateOf("Comprehensive (Death & PTD)") }
    var policyTypeExpanded by remember { mutableStateOf(false) }

    var sumInsuredPerGoatStr by remember { mutableStateOf("15000") }
    var premiumPerGoatStr by remember { mutableStateOf("675") }
    var paymentFrequency by remember { mutableStateOf("Annual") }
    var paymentFrequencyExpanded by remember { mutableStateOf(false) }

    var startDate by remember { mutableStateOf(SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())) }
    var expiryDate by remember {
        val cal = Calendar.getInstance()
        cal.add(Calendar.YEAR, 1)
        mutableStateOf(SimpleDateFormat("yyyy-MM-dd", Locale.US).format(cal.time))
    }

    var agentBroker by remember { mutableStateOf("") }
    var agentContact by remember { mutableStateOf("") }
    var policyDocument by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }
    var paymentAccountId by remember { mutableStateOf(accounts.firstOrNull()?.id ?: "") }
    var accountExpanded by remember { mutableStateOf(false) }

    // Resolve covered goats based on mode
    val coveredGoats = remember(selectionMode, singleGoatId, multipleSelectedGoatIds.toList(), activeGoats) {
        when (selectionMode) {
            "INDIVIDUAL" -> activeGoats.filter { it.id == singleGoatId }
            "MULTIPLE" -> activeGoats.filter { multipleSelectedGoatIds.contains(it.id) }
            "ALL_HERD" -> activeGoats
            "DOES" -> activeGoats.filter { it.sex_c.equals("Doe", ignoreCase = true) || it.sex_c.equals("Female", ignoreCase = true) }
            "BUCKS" -> activeGoats.filter { it.sex_c.equals("Buck", ignoreCase = true) || it.sex_c.equals("Male", ignoreCase = true) }
            else -> activeGoats.filter { it.id == singleGoatId }
        }
    }

    val singleSum = sumInsuredPerGoatStr.toDoubleOrNull() ?: 0.0
    val singlePrem = premiumPerGoatStr.toDoubleOrNull() ?: 0.0
    val totalSumInsured = singleSum * coveredGoats.size
    val totalPremium = singlePrem * coveredGoats.size

    Dialog(onDismissRequest = onDismiss) {
        Surface(shape = RoundedCornerShape(16.dp), color = Color.White, modifier = Modifier.fillMaxWidth().fillMaxHeight(0.92f)) {
            LazyColumn(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                item {
                    Text("Add Insurance Policy", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = FarmGreenDark)
                    Text("Insure individual goats or batches with master insurer links.", fontSize = 11.sp, color = Color.Gray)
                }

                // 1. Insurance Company Dropdown (Requirement 2 & 3)
                item {
                    ExposedDropdownMenuBox(expanded = providerExpanded, onExpandedChange = { providerExpanded = !providerExpanded }) {
                        OutlinedTextField(
                            value = if (selectedProviderName.isBlank() || selectedProviderName == "Select") "[ Select Insurance Company ▼ ]" else selectedProviderName,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Insurance Company *") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = providerExpanded) },
                            modifier = Modifier.fillMaxWidth().menuAnchor().testTag("select_insurance_company")
                        )
                        ExposedDropdownMenu(expanded = providerExpanded, onDismissRequest = { providerExpanded = false }) {
                            providers.forEach { p ->
                                DropdownMenuItem(
                                    text = {
                                        Column {
                                            Text(p.company_name, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                                            if (!p.code.isNullOrBlank()) Text("Code: ${p.code}", fontSize = 10.sp, color = Color.Gray)
                                        }
                                    },
                                    onClick = { selectedProviderName = p.company_name; providerExpanded = false }
                                )
                            }
                        }
                    }
                }

                // Covered Goats Selection Mode
                item {
                    Text("Covered Goats Selection *", fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        listOf("INDIVIDUAL", "MULTIPLE", "ALL_HERD", "DOES").forEach { m ->
                            FilterChip(
                                selected = selectionMode == m,
                                onClick = { selectionMode = m },
                                label = { Text(m.replace("_", " "), fontSize = 10.sp) },
                                colors = FilterChipDefaults.filterChipColors(selectedContainerColor = FarmGreenDark, selectedLabelColor = Color.White)
                            )
                        }
                    }
                }

                if (selectionMode == "INDIVIDUAL") {
                    item {
                        ExposedDropdownMenuBox(expanded = singleGoatExpanded, onExpandedChange = { singleGoatExpanded = !singleGoatExpanded }) {
                            val cur = activeGoats.find { it.id == singleGoatId }
                            OutlinedTextField(
                                value = "${cur?.tag_c ?: "Select"} - ${cur?.name ?: ""}",
                                onValueChange = {},
                                readOnly = true,
                                label = { Text("Select Goat *") },
                                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = singleGoatExpanded) },
                                modifier = Modifier.fillMaxWidth().menuAnchor()
                            )
                            ExposedDropdownMenu(expanded = singleGoatExpanded, onDismissRequest = { singleGoatExpanded = false }) {
                                activeGoats.forEach { g ->
                                    DropdownMenuItem(
                                        text = { Text("${g.tag_c} - ${g.name} (${g.breed_c})") },
                                        onClick = { singleGoatId = g.id; singleGoatExpanded = false }
                                    )
                                }
                            }
                        }
                    }
                } else if (selectionMode == "MULTIPLE") {
                    item {
                        Text("Select Multiple Goats (${multipleSelectedGoatIds.size} selected):", fontSize = 11.sp, color = Color.DarkGray)
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color(0xFFF8FAFC)),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth().heightIn(max = 140.dp)
                        ) {
                            LazyColumn(modifier = Modifier.padding(6.dp)) {
                                items(activeGoats) { g ->
                                    val isChecked = multipleSelectedGoatIds.contains(g.id)
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clickable {
                                                if (isChecked) multipleSelectedGoatIds.remove(g.id)
                                                else multipleSelectedGoatIds.add(g.id)
                                            }
                                            .padding(vertical = 2.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Checkbox(
                                            checked = isChecked,
                                            onCheckedChange = { chk ->
                                                if (chk) multipleSelectedGoatIds.add(g.id)
                                                else multipleSelectedGoatIds.remove(g.id)
                                            }
                                        )
                                        Text("${g.tag_c} - ${g.name} (${g.breed_c})", fontSize = 12.sp)
                                    }
                                }
                            }
                        }
                    }
                }

                // Policy Details
                item {
                    OutlinedTextField(
                        value = policyNumber,
                        onValueChange = { policyNumber = it },
                        label = { Text("Policy Number") },
                        placeholder = { Text("e.g. NICL/LIV/2026/8941") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("input_policy_number")
                    )
                }

                item {
                    ExposedDropdownMenuBox(expanded = policyTypeExpanded, onExpandedChange = { policyTypeExpanded = !policyTypeExpanded }) {
                        OutlinedTextField(
                            value = policyType,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Policy Type") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = policyTypeExpanded) },
                            modifier = Modifier.fillMaxWidth().menuAnchor()
                        )
                        ExposedDropdownMenu(expanded = policyTypeExpanded, onDismissRequest = { policyTypeExpanded = false }) {
                            listOf("Comprehensive (Death & PTD)", "Accident Only", "Disease & Epidemic", "Livestock Transit", "Other").forEach { pt ->
                                DropdownMenuItem(
                                    text = { Text(pt) },
                                    onClick = { policyType = pt; policyTypeExpanded = false }
                                )
                            }
                        }
                    }
                }

                item {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        DatePickerField(dateValue = startDate, onDateSelected = { startDate = it }, label = "Policy Start Date *")
                    }
                }
                item {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        DatePickerField(dateValue = expiryDate, onDateSelected = { expiryDate = it }, label = "Policy End Date *")
                    }
                }

                item {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = sumInsuredPerGoatStr,
                            onValueChange = { sumInsuredPerGoatStr = it },
                            label = { Text("Sum Insured/Goat (₹)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = premiumPerGoatStr,
                            onValueChange = { premiumPerGoatStr = it },
                            label = { Text("Premium/Goat (₹)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                item {
                    ExposedDropdownMenuBox(expanded = paymentFrequencyExpanded, onExpandedChange = { paymentFrequencyExpanded = !paymentFrequencyExpanded }) {
                        OutlinedTextField(
                            value = paymentFrequency,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Payment Frequency") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = paymentFrequencyExpanded) },
                            modifier = Modifier.fillMaxWidth().menuAnchor()
                        )
                        ExposedDropdownMenu(expanded = paymentFrequencyExpanded, onDismissRequest = { paymentFrequencyExpanded = false }) {
                            listOf("Annual", "Semi-Annual", "Quarterly", "Monthly", "One-Time").forEach { fq ->
                                DropdownMenuItem(
                                    text = { Text(fq) },
                                    onClick = { paymentFrequency = fq; paymentFrequencyExpanded = false }
                                )
                            }
                        }
                    }
                }

                item {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = agentBroker,
                            onValueChange = { agentBroker = it },
                            label = { Text("Agent / Broker") },
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = agentContact,
                            onValueChange = { agentContact = it },
                            label = { Text("Agent Contact") },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                item {
                    OutlinedTextField(
                        value = policyDocument,
                        onValueChange = { policyDocument = it },
                        label = { Text("Policy Document / Attachment") },
                        placeholder = { Text("e.g. NICL_policy_certificate.pdf") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                item {
                    OutlinedTextField(
                        value = notes,
                        onValueChange = { notes = it },
                        label = { Text("Notes") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                item {
                    // Payment account
                    ExposedDropdownMenuBox(expanded = accountExpanded, onExpandedChange = { accountExpanded = !accountExpanded }) {
                        val selAcc = accounts.find { it.id == paymentAccountId }
                        OutlinedTextField(
                            value = "${selAcc?.account_name ?: "Select Account"} (${CurrencyUtils.formatInr(selAcc?.current_balance ?: 0.0)})",
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Pay Premium From (Finance Integration)") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = accountExpanded) },
                            modifier = Modifier.fillMaxWidth().menuAnchor()
                        )
                        ExposedDropdownMenu(expanded = accountExpanded, onDismissRequest = { accountExpanded = false }) {
                            accounts.forEach { acc ->
                                DropdownMenuItem(
                                    text = { Text("${acc.account_name} (${CurrencyUtils.formatInr(acc.current_balance)})") },
                                    onClick = { paymentAccountId = acc.id; accountExpanded = false }
                                )
                            }
                        }
                    }
                }

                // Real-time Summary Card (Requirement 4)
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFF0FDF4)),
                        shape = RoundedCornerShape(10.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFBBF7D0)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text("POLICY BATCH SUMMARY", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = FarmGreenDark)
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Insured Goat Count:", fontSize = 12.sp)
                                Text("${coveredGoats.size} goats", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Total Sum Insured:", fontSize = 12.sp)
                                Text(CurrencyUtils.formatInr(totalSumInsured), fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color(0xFF1E3A8A))
                            }
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Total Premium:", fontSize = 12.sp)
                                Text(CurrencyUtils.formatInr(totalPremium), fontWeight = FontWeight.Bold, fontSize = 12.sp, color = FarmGreenDark)
                            }
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Expiry Date:", fontSize = 12.sp)
                                Text(expiryDate, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                        }
                    }
                }

                item {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                        TextButton(onClick = onDismiss) { Text("Cancel") }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = {
                                if (coveredGoats.isEmpty()) return@Button
                                val sharedPolicyNumber = policyNumber.trim().ifBlank {
                                    "POL-${UUID.randomUUID().toString().take(6).uppercase()}"
                                }
                                val policyList = coveredGoats.map { g ->
                                    InsurancePolicy(
                                        goat_id = g.id,
                                        goat_tag = g.tag_c,
                                        goat_name = g.name,
                                        insurance_company = if (selectedProviderName.isBlank() || selectedProviderName == "Select") "National Insurance Company Limited" else selectedProviderName,
                                        policy_name = policyType,
                                        policy_number = sharedPolicyNumber,
                                        sum_insured = singleSum,
                                        premium = singlePrem,
                                        total_premium = singlePrem,
                                        start_date = startDate,
                                        expiry_date = expiryDate,
                                        coverage_type = policyType,
                                        agent_name = agentBroker.trim().ifBlank { null },
                                        agent_contact = agentContact.trim().ifBlank { null },
                                        policy_document_url = policyDocument.trim().ifBlank { null },
                                        status = "Active"
                                    )
                                }
                                onSave(policyList, paymentAccountId.ifBlank { null })
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = FarmGreenDark),
                            modifier = Modifier.testTag("btn_save_policy")
                        ) {
                            Text("Save Policy (${coveredGoats.size} Goats)")
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun RenewPolicyDialog(
    policies: List<InsurancePolicy>,
    accounts: List<FinancialAccount>,
    preselectedPolicy: InsurancePolicy?,
    onDismiss: () -> Unit,
    onRenew: (InsurancePolicy, paymentAccountId: String?) -> Unit
) {
    var selectedPolicyId by remember { mutableStateOf(preselectedPolicy?.id ?: policies.firstOrNull()?.id ?: "") }
    var policyExpanded by remember { mutableStateOf(false) }

    val policy = policies.find { it.id == selectedPolicyId } ?: preselectedPolicy
    var newStartDate by remember { mutableStateOf(SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())) }
    var newExpiryDate by remember {
        val cal = Calendar.getInstance()
        cal.add(Calendar.YEAR, 1)
        mutableStateOf(SimpleDateFormat("yyyy-MM-dd", Locale.US).format(cal.time))
    }
    var renewalPremiumStr by remember { mutableStateOf("${policy?.total_premium?.toInt() ?: 675}") }
    var paymentAccountId by remember { mutableStateOf(accounts.firstOrNull()?.id ?: "") }
    var accountExpanded by remember { mutableStateOf(false) }

    Dialog(onDismissRequest = onDismiss) {
        Surface(shape = RoundedCornerShape(16.dp), color = Color.White, modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Renew Insurance Policy", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = Color(0xFF0284C7))
                Text("Select an existing policy to renew coverage without losing historical claim records.", fontSize = 11.sp, color = Color.Gray)

                ExposedDropdownMenuBox(expanded = policyExpanded, onExpandedChange = { policyExpanded = !policyExpanded }) {
                    OutlinedTextField(
                        value = "Goat ${policy?.goat_tag ?: ""} • ${policy?.insurance_company ?: ""} (#${policy?.policy_number ?: ""})",
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Select Policy to Renew *") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = policyExpanded) },
                        modifier = Modifier.fillMaxWidth().menuAnchor()
                    )
                    ExposedDropdownMenu(expanded = policyExpanded, onDismissRequest = { policyExpanded = false }) {
                        policies.forEach { p ->
                            DropdownMenuItem(
                                text = { Text("${p.goat_tag} - ${p.insurance_company} (Exp: ${p.expiry_date})") },
                                onClick = {
                                    selectedPolicyId = p.id
                                    policyExpanded = false
                                    renewalPremiumStr = "${p.total_premium.toInt()}"
                                }
                            )
                        }
                    }
                }

                DatePickerField(dateValue = newStartDate, onDateSelected = { newStartDate = it }, label = "New Start Date *")
                DatePickerField(dateValue = newExpiryDate, onDateSelected = { newExpiryDate = it }, label = "New Expiry Date *")

                OutlinedTextField(
                    value = renewalPremiumStr,
                    onValueChange = { renewalPremiumStr = it },
                    label = { Text("Renewal Premium (₹) *") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                ExposedDropdownMenuBox(expanded = accountExpanded, onExpandedChange = { accountExpanded = !accountExpanded }) {
                    val selAcc = accounts.find { it.id == paymentAccountId }
                    OutlinedTextField(
                        value = "${selAcc?.account_name ?: "Select"} (${CurrencyUtils.formatInr(selAcc?.current_balance ?: 0.0)})",
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Pay Renewal From (Finance)") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = accountExpanded) },
                        modifier = Modifier.fillMaxWidth().menuAnchor()
                    )
                    ExposedDropdownMenu(expanded = accountExpanded, onDismissRequest = { accountExpanded = false }) {
                        accounts.forEach { acc ->
                            DropdownMenuItem(
                                text = { Text("${acc.account_name} (${CurrencyUtils.formatInr(acc.current_balance)})") },
                                onClick = { paymentAccountId = acc.id; accountExpanded = false }
                            )
                        }
                    }
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    TextButton(onClick = onDismiss) { Text("Cancel") }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            val pol = policy ?: return@Button
                            val prem = renewalPremiumStr.toDoubleOrNull() ?: pol.total_premium
                            val renewed = pol.copy(
                                id = UUID.randomUUID().toString(),
                                start_date = newStartDate,
                                expiry_date = newExpiryDate,
                                renewal_date = newStartDate,
                                premium = prem,
                                total_premium = prem,
                                status = "Active"
                            )
                            onRenew(renewed, paymentAccountId.ifBlank { null })
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7))
                    ) {
                        Text("Confirm Renewal")
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SubmitClaimDialog(
    policies: List<InsurancePolicy>,
    goats: List<Goat>,
    preselectedPolicy: InsurancePolicy?,
    onDismiss: () -> Unit,
    onSubmit: (InsuranceClaim) -> Unit
) {
    var selectedPolicyId by remember { mutableStateOf(preselectedPolicy?.id ?: policies.firstOrNull()?.id ?: "") }
    var policyExpanded by remember { mutableStateOf(false) }

    val policy = policies.find { it.id == selectedPolicyId } ?: preselectedPolicy
    var selectedGoatTag by remember { mutableStateOf(policy?.goat_tag ?: "") }

    var claimType by remember { mutableStateOf("Death") }
    var claimTypeExpanded by remember { mutableStateOf(false) }

    var incidentDate by remember { mutableStateOf(SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())) }
    var incidentDescription by remember { mutableStateOf("") }
    var cause by remember { mutableStateOf("Sudden Illness / Enterotoxemia") }

    var claimAmountStr by remember {
        mutableStateOf("${policy?.sum_insured?.toInt() ?: 15000}")
    }
    var documents by remember { mutableStateOf("") }
    var claimNumber by remember { mutableStateOf("CLM-${UUID.randomUUID().toString().take(6).uppercase()}") }

    // Claim statuses: DRAFT, SUBMITTED, UNDER_REVIEW, APPROVED, PARTIALLY_APPROVED, REJECTED, SETTLED, CLOSED
    var claimStatus by remember { mutableStateOf("SUBMITTED") }
    var statusExpanded by remember { mutableStateOf(false) }

    Dialog(onDismissRequest = onDismiss) {
        Surface(shape = RoundedCornerShape(16.dp), color = Color.White, modifier = Modifier.fillMaxWidth().fillMaxHeight(0.9f)) {
            LazyColumn(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                item {
                    Text("Submit Insurance Claim", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = Color(0xFFC2410C))
                    Text("Register official claim against policy. Do not mark approved automatically.", fontSize = 11.sp, color = Color.Gray)
                }

                // Select Policy
                item {
                    ExposedDropdownMenuBox(expanded = policyExpanded, onExpandedChange = { policyExpanded = !policyExpanded }) {
                        OutlinedTextField(
                            value = "Goat ${policy?.goat_tag ?: ""} • ${policy?.insurance_company ?: ""} (#${policy?.policy_number ?: ""})",
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Select Policy *") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = policyExpanded) },
                            modifier = Modifier.fillMaxWidth().menuAnchor().testTag("select_claim_policy")
                        )
                        ExposedDropdownMenu(expanded = policyExpanded, onDismissRequest = { policyExpanded = false }) {
                            policies.forEach { p ->
                                DropdownMenuItem(
                                    text = { Text("${p.goat_tag} - ${p.insurance_company} (Sum: ${CurrencyUtils.formatInr(p.sum_insured)})") },
                                    onClick = {
                                        selectedPolicyId = p.id
                                        selectedGoatTag = p.goat_tag
                                        claimAmountStr = "${p.sum_insured.toInt()}"
                                        policyExpanded = false
                                    }
                                )
                            }
                        }
                    }
                }

                item {
                    OutlinedTextField(
                        value = selectedGoatTag,
                        onValueChange = { selectedGoatTag = it },
                        label = { Text("Select Goat *") },
                        readOnly = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                item {
                    ExposedDropdownMenuBox(expanded = claimTypeExpanded, onExpandedChange = { claimTypeExpanded = !claimTypeExpanded }) {
                        OutlinedTextField(
                            value = claimType,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Claim Type *") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = claimTypeExpanded) },
                            modifier = Modifier.fillMaxWidth().menuAnchor()
                        )
                        ExposedDropdownMenu(expanded = claimTypeExpanded, onDismissRequest = { claimTypeExpanded = false }) {
                            listOf("Death", "Illness / Treatment", "Accident / Injury", "Permanent Total Disability", "Theft / Loss").forEach { ct ->
                                DropdownMenuItem(
                                    text = { Text(ct) },
                                    onClick = { claimType = ct; claimTypeExpanded = false }
                                )
                            }
                        }
                    }
                }

                item {
                    DatePickerField(dateValue = incidentDate, onDateSelected = { incidentDate = it }, label = "Incident Date *")
                }

                item {
                    OutlinedTextField(
                        value = cause,
                        onValueChange = { cause = it },
                        label = { Text("Cause *") },
                        placeholder = { Text("e.g. Enterotoxemia, Dog Attack, Fracture") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("input_claim_cause")
                    )
                }

                item {
                    OutlinedTextField(
                        value = incidentDescription,
                        onValueChange = { incidentDescription = it },
                        label = { Text("Incident Description") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                item {
                    OutlinedTextField(
                        value = claimAmountStr,
                        onValueChange = { claimAmountStr = it },
                        label = { Text("Claim Amount (₹) *") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("input_claim_amount")
                    )
                }

                item {
                    OutlinedTextField(
                        value = claimNumber,
                        onValueChange = { claimNumber = it },
                        label = { Text("Claim Number") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                item {
                    OutlinedTextField(
                        value = documents,
                        onValueChange = { documents = it },
                        label = { Text("Documents / Attachment Ref") },
                        placeholder = { Text("e.g. Post-mortem cert #772, ear-tag photo") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                // Claim Status dropdown
                item {
                    ExposedDropdownMenuBox(expanded = statusExpanded, onExpandedChange = { statusExpanded = !statusExpanded }) {
                        OutlinedTextField(
                            value = claimStatus,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Claim Status *") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = statusExpanded) },
                            modifier = Modifier.fillMaxWidth().menuAnchor().testTag("select_claim_status")
                        )
                        ExposedDropdownMenu(expanded = statusExpanded, onDismissRequest = { statusExpanded = false }) {
                            listOf("DRAFT", "SUBMITTED", "UNDER_REVIEW", "APPROVED", "PARTIALLY_APPROVED", "REJECTED", "SETTLED", "CLOSED").forEach { st ->
                                DropdownMenuItem(
                                    text = { Text(st) },
                                    onClick = { claimStatus = st; statusExpanded = false }
                                )
                            }
                        }
                    }
                }

                item {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                        TextButton(onClick = onDismiss) { Text("Cancel") }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = {
                                val pol = policy ?: return@Button
                                val amt = claimAmountStr.toDoubleOrNull() ?: pol.sum_insured
                                val claim = InsuranceClaim(
                                    policy_id = pol.id,
                                    goat_id = pol.goat_id,
                                    goat_tag = pol.goat_tag,
                                    incident_date = incidentDate,
                                    incident_type = claimType,
                                    cause = cause.ifBlank { "Unspecified" },
                                    description = incidentDescription.ifBlank { null },
                                    claim_amount = amt,
                                    claim_number = claimNumber.ifBlank { null },
                                    status = claimStatus,
                                    notes = documents.ifBlank { null }
                                )
                                onSubmit(claim)
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFC2410C)),
                            modifier = Modifier.testTag("btn_submit_claim_confirm")
                        ) {
                            Text("Submit Claim")
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun UpdateClaimStatusDialog(
    claim: InsuranceClaim,
    onDismiss: () -> Unit,
    onUpdate: (String) -> Unit
) {
    var selectedStatus by remember { mutableStateOf(claim.status) }
    var expanded by remember { mutableStateOf(false) }

    Dialog(onDismissRequest = onDismiss) {
        Surface(shape = RoundedCornerShape(16.dp), color = Color.White, modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Update Claim Status", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Text("Claim #${claim.claim_number ?: claim.id.take(8)} for Goat ${claim.goat_tag}", fontSize = 12.sp, color = Color.Gray)

                ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = !expanded }) {
                    OutlinedTextField(
                        value = selectedStatus,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("New Claim Status *") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
                        modifier = Modifier.fillMaxWidth().menuAnchor()
                    )
                    ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                        listOf("DRAFT", "SUBMITTED", "UNDER_REVIEW", "APPROVED", "PARTIALLY_APPROVED", "REJECTED", "SETTLED", "CLOSED").forEach { st ->
                            DropdownMenuItem(
                                text = { Text(st) },
                                onClick = { selectedStatus = st; expanded = false }
                            )
                        }
                    }
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    TextButton(onClick = onDismiss) { Text("Cancel") }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(onClick = { onUpdate(selectedStatus) }) {
                        Text("Save Status")
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SettleClaimDialog(
    claim: InsuranceClaim,
    accounts: List<FinancialAccount>,
    onDismiss: () -> Unit,
    onSettle: (settlementAmount: Double, settlementDate: String, accountId: String?, remarks: String?) -> Unit
) {
    var settlementAmountStr by remember { mutableStateOf("${claim.claim_amount.toInt()}") }
    var settlementDate by remember { mutableStateOf(SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())) }
    var accountId by remember { mutableStateOf(accounts.firstOrNull()?.id ?: "") }
    var remarks by remember { mutableStateOf("Full claim approval and payout") }
    var accountExpanded by remember { mutableStateOf(false) }

    Dialog(onDismissRequest = onDismiss) {
        Surface(shape = RoundedCornerShape(16.dp), color = Color.White, modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Record Claim Settlement Payout", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = FarmGreenDark)
                Text(
                    "Recording settlement will update the claim status and post the payout to the selected bank account as Insurance Recovery income (not goat sales).",
                    fontSize = 11.sp,
                    color = Color.Gray
                )

                OutlinedTextField(
                    value = settlementAmountStr,
                    onValueChange = { settlementAmountStr = it },
                    label = { Text("Settlement Amount (₹) *") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("input_settle_amount")
                )

                DatePickerField(dateValue = settlementDate, onDateSelected = { settlementDate = it }, label = "Settlement Date *")

                ExposedDropdownMenuBox(expanded = accountExpanded, onExpandedChange = { accountExpanded = !accountExpanded }) {
                    val selAcc = accounts.find { it.id == accountId }
                    OutlinedTextField(
                        value = "${selAcc?.account_name ?: "Select"} (${CurrencyUtils.formatInr(selAcc?.current_balance ?: 0.0)})",
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Deposit Payout Into (Bank / Cash) *") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = accountExpanded) },
                        modifier = Modifier.fillMaxWidth().menuAnchor()
                    )
                    ExposedDropdownMenu(expanded = accountExpanded, onDismissRequest = { accountExpanded = false }) {
                        accounts.forEach { acc ->
                            DropdownMenuItem(
                                text = { Text("${acc.account_name} (${CurrencyUtils.formatInr(acc.current_balance)})") },
                                onClick = { accountId = acc.id; accountExpanded = false }
                            )
                        }
                    }
                }

                OutlinedTextField(
                    value = remarks,
                    onValueChange = { remarks = it },
                    label = { Text("Settlement Remarks / UTR") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    TextButton(onClick = onDismiss) { Text("Cancel") }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            val amt = settlementAmountStr.toDoubleOrNull() ?: 0.0
                            if (amt <= 0) return@Button
                            onSettle(amt, settlementDate, accountId.ifBlank { null }, remarks.trim().ifBlank { null })
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = FarmGreenDark),
                        modifier = Modifier.testTag("btn_confirm_settle_claim")
                    ) {
                        Text("Confirm Settlement")
                    }
                }
            }
        }
    }
}

@Composable
private fun UploadDocumentDialog(
    policies: List<InsurancePolicy>,
    goats: List<Goat>,
    onDismiss: () -> Unit,
    onSave: (docName: String, docType: String, policyId: String?, docUrl: String) -> Unit
) {
    var docTitle by remember { mutableStateOf("") }
    var docType by remember { mutableStateOf("Policy Document") }
    var docTypeExpanded by remember { mutableStateOf(false) }
    var fileRef by remember { mutableStateOf("") }

    Dialog(onDismissRequest = onDismiss) {
        Surface(shape = RoundedCornerShape(16.dp), color = Color.White, modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Upload Insurance Document", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = Color(0xFF1E3A8A))
                Text("Attach certificates, post-mortem findings, or ear-tag proof.", fontSize = 11.sp, color = Color.Gray)

                OutlinedTextField(
                    value = docTitle,
                    onValueChange = { docTitle = it },
                    label = { Text("Document Title *") },
                    placeholder = { Text("e.g. NICL Health Certificate 2026") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = fileRef,
                    onValueChange = { fileRef = it },
                    label = { Text("Document Reference / File / URL *") },
                    placeholder = { Text("e.g. goat_eartag_photo_019.jpg") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    TextButton(onClick = onDismiss) { Text("Cancel") }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            if (docTitle.isNotBlank()) onSave(docTitle, docType, null, fileRef)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E3A8A))
                    ) {
                        Text("Save Document")
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AddEditProviderDialog(
    initial: InsuranceProvider?,
    onDismiss: () -> Unit,
    onSave: (InsuranceProvider) -> Unit
) {
    var name by remember { mutableStateOf(initial?.name ?: "") }
    var companyName by remember { mutableStateOf(initial?.company_name ?: "") }
    var code by remember { mutableStateOf(initial?.code ?: "") }
    var type by remember { mutableStateOf(initial?.type ?: "GENERAL") }
    var typeExpanded by remember { mutableStateOf(false) }
    var website by remember { mutableStateOf(initial?.website ?: "") }
    var phone by remember { mutableStateOf(initial?.phone ?: "") }
    var email by remember { mutableStateOf(initial?.email ?: "") }
    var isActive by remember { mutableStateOf(initial?.is_active ?: true) }
    var notes by remember { mutableStateOf(initial?.notes ?: "") }

    Dialog(onDismissRequest = onDismiss) {
        Surface(shape = RoundedCornerShape(16.dp), color = Color.White, modifier = Modifier.fillMaxWidth()) {
            LazyColumn(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                item {
                    Text(if (initial == null) "Add Insurance Company" else "Edit Insurer", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = FarmGreenDark)
                    Text("Master table entry for insurance partner companies.", fontSize = 11.sp, color = Color.Gray)
                }

                item {
                    OutlinedTextField(
                        value = companyName,
                        onValueChange = {
                            companyName = it
                            if (name.isBlank()) name = it
                        },
                        label = { Text("Insurance Company Name *") },
                        placeholder = { Text("e.g. The New India Assurance Company Limited") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                item {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = code,
                            onValueChange = { code = it },
                            label = { Text("Code") },
                            placeholder = { Text("e.g. NIA") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        ExposedDropdownMenuBox(expanded = typeExpanded, onExpandedChange = { typeExpanded = !typeExpanded }, modifier = Modifier.weight(1f)) {
                            OutlinedTextField(
                                value = type,
                                onValueChange = {},
                                readOnly = true,
                                label = { Text("Type") },
                                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = typeExpanded) },
                                modifier = Modifier.fillMaxWidth().menuAnchor()
                            )
                            ExposedDropdownMenu(expanded = typeExpanded, onDismissRequest = { typeExpanded = false }) {
                                listOf("GENERAL", "LIVESTOCK", "OTHER").forEach { t ->
                                    DropdownMenuItem(
                                        text = { Text(t) },
                                        onClick = { type = t; typeExpanded = false }
                                    )
                                }
                            }
                        }
                    }
                }

                item {
                    OutlinedTextField(
                        value = website,
                        onValueChange = { website = it },
                        label = { Text("Website") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                item {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = phone,
                            onValueChange = { phone = it },
                            label = { Text("Phone") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = email,
                            onValueChange = { email = it },
                            label = { Text("Email") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Active in Insurer Dropdown", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                        Switch(checked = isActive, onCheckedChange = { isActive = it })
                    }
                }

                item {
                    OutlinedTextField(
                        value = notes,
                        onValueChange = { notes = it },
                        label = { Text("Notes / Policy Availability Info") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                item {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                        TextButton(onClick = onDismiss) { Text("Cancel") }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = {
                                if (companyName.isNotBlank()) {
                                    val prov = initial?.copy(
                                        name = name.ifBlank { companyName },
                                        company_name = companyName,
                                        code = code.ifBlank { null },
                                        type = type,
                                        website = website.ifBlank { null },
                                        phone = phone.ifBlank { null },
                                        email = email.ifBlank { null },
                                        is_active = isActive,
                                        notes = notes.ifBlank { null }
                                    ) ?: InsuranceProvider(
                                        name = name.ifBlank { companyName },
                                        company_name = companyName,
                                        code = code.ifBlank { null },
                                        type = type,
                                        website = website.ifBlank { null },
                                        phone = phone.ifBlank { null },
                                        email = email.ifBlank { null },
                                        is_active = isActive,
                                        notes = notes.ifBlank { null }
                                    )
                                    onSave(prov)
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = FarmGreenDark)
                        ) {
                            Text("Save Insurer")
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun MetricCard(
    title: String,
    value: String,
    subtitle: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(10.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = modifier
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Text(title, fontSize = 10.sp, color = Color.Gray, fontWeight = FontWeight.SemiBold)
            Text(value, fontSize = 16.sp, fontWeight = FontWeight.ExtraBold, color = color)
            Text(subtitle, fontSize = 9.sp, color = Color.LightGray)
        }
    }
}
