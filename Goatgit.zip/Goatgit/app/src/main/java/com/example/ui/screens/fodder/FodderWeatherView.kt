package com.example.ui.screens.fodder

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.weather.DailyForecast
import com.example.data.weather.WeatherReport
import com.example.data.weather.WeatherService
import com.example.ui.theme.*
import kotlinx.coroutines.launch
import java.util.*

@Composable
fun FodderWeatherView(
    weatherService: WeatherService,
    modifier: Modifier = Modifier
) {
    val coroutineScope = rememberCoroutineScope()
    var weatherReport by remember { mutableStateOf<WeatherReport?>(null) }
    var isLoading by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    fun loadWeather() {
        isLoading = true
        errorMessage = null
        coroutineScope.launch {
            val res = weatherService.getAgriculturalWeather()
            isLoading = false
            if (res.isSuccess) {
                weatherReport = res.getOrThrow()
            } else {
                errorMessage = res.exceptionOrNull()?.message ?: "Failed to fetch weather forecast"
            }
        }
    }

    LaunchedEffect(Unit) {
        loadWeather()
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Header with Refresh
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text(
                    text = "Agricultural Weather",
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.titleLarge,
                    color = FarmGreenDark
                )
                Text(
                    text = "Fodder harvesting & irrigation guidance",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color.Gray
                )
            }

            IconButton(
                onClick = { loadWeather() },
                modifier = Modifier.testTag("refresh_weather_btn")
            ) {
                Icon(Icons.Default.Refresh, contentDescription = "Refresh Weather", tint = FarmGreenDark)
            }
        }

        if (isLoading) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    CircularProgressIndicator(color = FarmGreenDark)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Fetching weather data from Open-Meteo...", fontSize = 12.sp, color = Color.Gray)
                }
            }
        } else if (!errorMessage.isNullOrBlank()) {
            Card(
                colors = CardDefaults.cardColors(containerColor = FarmErrorContainer),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.CloudOff, contentDescription = null, tint = FarmError)
                    Spacer(modifier = Modifier.width(10.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Weather Unavailable Offline", fontWeight = FontWeight.Bold, color = FarmError)
                        Text(errorMessage ?: "", fontSize = 12.sp, color = Color.DarkGray)
                    }
                    TextButton(onClick = { loadWeather() }) {
                        Text("Retry", color = FarmError, fontWeight = FontWeight.Bold)
                    }
                }
            }
        } else if (weatherReport != null) {
            val report = weatherReport!!

            // ==========================================
            // CURRENT WEATHER HERO CARD
            // ==========================================
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = FarmGreenDark),
                elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "CURRENT CONDITIONS",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White.copy(alpha = 0.8f)
                            )
                            Text(
                                text = "${report.current.temperature.toInt()}°C",
                                fontSize = 42.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Text(
                                text = report.current.condition,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Medium,
                                color = Color.White.copy(alpha = 0.9f)
                            )
                        }

                        Box(
                            modifier = Modifier
                                .size(64.dp)
                                .clip(CircleShape)
                                .background(Color.White.copy(alpha = 0.15f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = when {
                                    report.current.condition.contains("Rain", ignoreCase = true) -> Icons.Default.WaterDrop
                                    report.current.condition.contains("Cloud", ignoreCase = true) -> Icons.Default.Cloud
                                    else -> Icons.Default.WbSunny
                                },
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(36.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        WeatherMetricItem(label = "Humidity", value = "${report.current.humidity}%", icon = Icons.Default.WaterDrop)
                        WeatherMetricItem(label = "Wind", value = "${report.current.windSpeedKmh.toInt()} km/h", icon = Icons.Default.Air)
                        WeatherMetricItem(label = "Precipitation", value = "${report.current.precipitationMm} mm", icon = Icons.Default.Grain)
                    }
                }
            }

            // ==========================================
            // RAIN & HARVEST ADVISORY BANNER
            // ==========================================
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = FarmAmberContainer),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Agriculture,
                        contentDescription = null,
                        tint = FarmBrown,
                        modifier = Modifier.size(28.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "Rain & Harvest Advisory",
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.titleSmall,
                            color = FarmBrown
                        )
                        Text(
                            text = report.rainForecastSummary,
                            style = MaterialTheme.typography.bodySmall,
                            color = FarmBrown.copy(alpha = 0.9f),
                            modifier = Modifier.padding(top = 2.dp)
                        )
                    }
                }
            }

            // ==========================================
            // 7-DAY AGRICULTURAL FORECAST
            // ==========================================
            Text(
                text = "7-Day Fodder Harvesting Forecast",
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.titleMedium,
                color = FarmGreenDark
            )

            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                report.daily.forEach { forecast ->
                    DailyForecastCard(forecast = forecast)
                }
            }
        }
    }
}

@Composable
fun DailyForecastCard(forecast: DailyForecast) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = when {
                            forecast.condition.contains("Rain", ignoreCase = true) -> Icons.Default.WaterDrop
                            forecast.condition.contains("Cloud", ignoreCase = true) -> Icons.Default.Cloud
                            else -> Icons.Default.WbSunny
                        },
                        contentDescription = null,
                        tint = when {
                            forecast.condition.contains("Rain", ignoreCase = true) -> Color(0xFF0288D1)
                            forecast.condition.contains("Cloud", ignoreCase = true) -> Color.Gray
                            else -> Color(0xFFFFA000)
                        },
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = forecast.dayName,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                        Text(
                            text = forecast.condition,
                            fontSize = 11.sp,
                            color = Color.Gray
                        )
                    }
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Rain probability badge
                    if (forecast.precipitationProbability > 0) {
                        Surface(
                            shape = RoundedCornerShape(4.dp),
                            color = if (forecast.precipitationProbability >= 50) Color(0xFFFFEBEE) else Color(0xFFE1F5FE)
                        ) {
                            Text(
                                text = "${forecast.precipitationProbability}% rain",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (forecast.precipitationProbability >= 50) FarmError else Color(0xFF0277BD),
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }

                    Text(
                        text = "${forecast.maxTemp.toInt()}° / ${forecast.minTemp.toInt()}°",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = Color.DarkGray
                    )
                }
            }

            // Advisory Note
            Text(
                text = forecast.harvestAdvisory,
                fontSize = 11.sp,
                fontWeight = FontWeight.Medium,
                color = if (forecast.harvestAdvisory.startsWith("✓")) FarmGreenDark else FarmBrown,
                modifier = Modifier.padding(top = 6.dp)
            )
        }
    }
}

@Composable
fun WeatherMetricItem(
    label: String,
    value: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector
) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = Color.White.copy(alpha = 0.8f),
            modifier = Modifier.size(16.dp)
        )
        Spacer(modifier = Modifier.width(6.dp))
        Column {
            Text(text = label, fontSize = 10.sp, color = Color.White.copy(alpha = 0.7f))
            Text(text = value, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White)
        }
    }
}
