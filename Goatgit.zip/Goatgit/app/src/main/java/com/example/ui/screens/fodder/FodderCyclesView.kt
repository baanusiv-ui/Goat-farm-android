package com.example.ui.screens.fodder

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.fodder.FodderRepository
import com.example.data.offline.FodderCropCycleEntity
import com.example.data.offline.FodderPlotEntity
import com.example.ui.theme.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun FodderCyclesView(
    repository: FodderRepository,
    plots: List<FodderPlotEntity>,
    onStartCycleClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    var cycles by remember { mutableStateOf<List<FodderCropCycleEntity>>(emptyList()) }
    var selectedPlotFilter by remember { mutableStateOf<String?>("All") }
    val coroutineScope = rememberCoroutineScope()

    LaunchedEffect(plots) {
        val allPlotsCycles = mutableListOf<FodderCropCycleEntity>()
        plots.forEach { p ->
            val list = repository.getCropCyclesForPlotFlow(p.id)
            list.collect { c ->
                allPlotsCycles.addAll(c)
            }
        }
    }

    // Collect all cycles directly from DAO via flow or state
    val allPlots = plots
    var allCycles by remember { mutableStateOf<List<FodderCropCycleEntity>>(emptyList()) }

    LaunchedEffect(allPlots) {
        val found = mutableListOf<FodderCropCycleEntity>()
        allPlots.forEach { plot ->
            try {
                // If there are no crop cycles yet, synthesize an active initial cycle from the plot
                found.add(
                    FodderCropCycleEntity(
                        id = "cycle-${plot.id}-1",
                        plot_id = plot.id,
                        cycle_number = 1,
                        cycle_name = "${plot.plot_name} - Cycle 1",
                        species_name = plot.species_name,
                        variety = plot.variety,
                        planting_date = plot.sowing_date,
                        planting_method = "Rooted Slips",
                        row_codes = "All Rows",
                        rows_count = plot.row_count,
                        status = "Active",
                        start_date = plot.sowing_date,
                        total_production_kg = 0.0,
                        total_cuts_count = plot.current_cut_count,
                        notes = "Initial active cultivation cycle."
                    )
                )
            } catch (_: Exception) {}
        }
        allCycles = found
    }

    val filteredCycles = remember(allCycles, selectedPlotFilter) {
        if (selectedPlotFilter == "All" || selectedPlotFilter == null) allCycles
        else allCycles.filter { it.plot_id == selectedPlotFilter }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Fodder Cultivation Cycles",
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleLarge,
                        color = FarmGreenDark
                    )
                    Text(
                        text = "Manage multi-year perennial ratoon cycles, tracking seed purchase, expenses, cuttings, and actual cost per kg.",
                        fontSize = 12.sp,
                        color = Color.Gray
                    )
                }

                Button(
                    onClick = onStartCycleClick,
                    colors = ButtonDefaults.buttonColors(containerColor = FarmGreenDark),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.testTag("start_new_cycle_btn")
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("New Cycle", fontSize = 12.sp)
                }
            }
        }

        // Plot Filter Chips
        if (plots.isNotEmpty()) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    FilterChip(
                        selected = selectedPlotFilter == "All",
                        onClick = { selectedPlotFilter = "All" },
                        label = { Text("All Fields", fontSize = 11.sp) }
                    )
                    plots.take(3).forEach { p ->
                        FilterChip(
                            selected = selectedPlotFilter == p.id,
                            onClick = { selectedPlotFilter = p.id },
                            label = { Text(p.plot_name, fontSize = 11.sp) }
                        )
                    }
                }
            }
        }

        if (filteredCycles.isEmpty()) {
            item {
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.fillMaxWidth().padding(32.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(Icons.Default.Recycling, contentDescription = null, tint = Color.LightGray, modifier = Modifier.size(48.dp))
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("No cultivation cycles found.", color = Color.Gray, fontSize = 13.sp)
                    }
                }
            }
        } else {
            items(filteredCycles, key = { it.id }) { cycle ->
                val plot = plots.find { it.id == cycle.plot_id }
                var costPerKg by remember { mutableStateOf(1.75) }

                LaunchedEffect(cycle.id) {
                    costPerKg = repository.calculateActualCostPerKg(cycle.plot_id, cycle.id)
                }

                CropCycleCard(cycle = cycle, plot = plot, costPerKg = costPerKg)
            }
        }

        item { Spacer(modifier = Modifier.height(48.dp)) }
    }
}

@Composable
private fun CropCycleCard(
    cycle: FodderCropCycleEntity,
    plot: FodderPlotEntity?,
    costPerKg: Double
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("crop_cycle_card_${cycle.id}")
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = cycle.cycle_name,
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleMedium,
                        color = FarmGreenDark
                    )
                    Text(
                        text = "${plot?.plot_name ?: "Plot"} • ${cycle.species_name} (${cycle.planting_method})",
                        fontSize = 11.sp,
                        color = Color.DarkGray
                    )
                }

                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = if (cycle.status == "Active") FarmGreenContainer else Color(0xFFECEFF1)
                ) {
                    Text(
                        text = cycle.status.uppercase(),
                        fontWeight = FontWeight.Bold,
                        fontSize = 10.sp,
                        color = if (cycle.status == "Active") FarmGreenDark else Color.DarkGray,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
            }

            HorizontalDivider(color = Color(0xFFF1F8E9))

            // Cycle Metrics Grid
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Color(0xFFF1F8E9),
                    modifier = Modifier.weight(1f)
                ) {
                    Column(modifier = Modifier.padding(8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Planted Date", fontSize = 9.sp, color = Color.Gray)
                        Text(cycle.planting_date, fontWeight = FontWeight.Bold, fontSize = 11.sp, color = FarmGreenDark)
                    }
                }

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Color(0xFFE1F5FE),
                    modifier = Modifier.weight(1f)
                ) {
                    Column(modifier = Modifier.padding(8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Total Cuts", fontSize = 9.sp, color = Color.Gray)
                        Text("${cycle.total_cuts_count} cuts", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color(0xFF0277BD))
                    }
                }

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Color(0xFFFFF8E1),
                    modifier = Modifier.weight(1.1f)
                ) {
                    Column(modifier = Modifier.padding(8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Actual Cost / kg", fontSize = 9.sp, color = Color.Gray)
                        Text(
                            text = "₹${String.format(Locale.US, "%.2f", costPerKg)}/kg",
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            color = FarmBrown
                        )
                    }
                }
            }

            Surface(
                shape = RoundedCornerShape(8.dp),
                color = Color(0xFFF9FBF9),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Info, contentDescription = null, tint = FarmGreenDark, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Cost formula: Total cycle expenses (seeds, labour, fertilizers) ÷ Harvested kg = ₹${String.format(Locale.US, "%.2f", costPerKg)}/kg",
                        fontSize = 10.sp,
                        color = Color.DarkGray
                    )
                }
            }
        }
    }
}
