package com.example.ui.components.camera

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Environment
import android.view.MotionEvent
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import coil.compose.AsyncImage
import com.example.data.ai.GoatHealthAiAssessmentService
import com.example.data.ai.GoatHealthAiReport
import com.example.data.ai.HealthSeverityLevel
import com.example.data.supabase.Goat
import com.example.data.supabase.GoatRepository
import com.example.data.supabase.TreatmentRecord
import com.example.ui.theme.FarmGreenDark
import com.example.ui.theme.FarmGreenPrimary
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

/**
 * CameraX Preview Composable for capturing goat health & clinical documentation photos.
 */
@Composable
fun GoatHealthCameraPreview(
    modifier: Modifier = Modifier,
    lensFacing: Int = CameraSelector.LENS_FACING_BACK,
    flashMode: Int = ImageCapture.FLASH_MODE_AUTO,
    enableGrid: Boolean = true,
    isCapturing: Boolean = false,
    onCaptureReady: (ImageCapture) -> Unit = {},
    onFocusPointChanged: (Offset?) -> Unit = {}
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current

    var previewView by remember { mutableStateOf<PreviewView?>(null) }
    var camera by remember { mutableStateOf<Camera?>(null) }

    val imageCapture = remember(flashMode) {
        ImageCapture.Builder()
            .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
            .setFlashMode(flashMode)
            .build()
    }

    LaunchedEffect(imageCapture) {
        onCaptureReady(imageCapture)
    }

    val cameraProviderFuture = remember { ProcessCameraProvider.getInstance(context) }

    LaunchedEffect(lensFacing, previewView) {
        val pView = previewView ?: return@LaunchedEffect
        val cameraProvider = withContext(Dispatchers.IO) {
            cameraProviderFuture.get()
        }

        val preview = Preview.Builder().build().also {
            it.surfaceProvider = pView.surfaceProvider
        }

        val cameraSelector = CameraSelector.Builder()
            .requireLensFacing(lensFacing)
            .build()

        try {
            cameraProvider.unbindAll()
            camera = cameraProvider.bindToLifecycle(
                lifecycleOwner,
                cameraSelector,
                preview,
                imageCapture
            )
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    Box(modifier = modifier) {
        AndroidView(
            factory = { ctx ->
                PreviewView(ctx).apply {
                    scaleType = PreviewView.ScaleType.FILL_CENTER
                    implementationMode = PreviewView.ImplementationMode.COMPATIBLE
                    setOnTouchListener { _, motionEvent ->
                        if (motionEvent.action == MotionEvent.ACTION_DOWN) {
                            val x = motionEvent.x
                            val y = motionEvent.y
                            onFocusPointChanged(Offset(x, y))

                            val factory = meteringPointFactory
                            val point = factory.createPoint(x, y)
                            val action = FocusMeteringAction.Builder(point, FocusMeteringAction.FLAG_AF)
                                .setAutoCancelDuration(3, java.util.concurrent.TimeUnit.SECONDS)
                                .build()
                            camera?.cameraControl?.startFocusAndMetering(action)
                        }
                        true
                    }
                    previewView = this
                }
            },
            modifier = Modifier.fillMaxSize()
        )

        // Veterinary Clinical Framing Grid Overlay
        if (enableGrid) {
            CameraFramingGridOverlay(modifier = Modifier.fillMaxSize())
        }

        // Shutter flash effect when capturing
        if (isCapturing) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.White.copy(alpha = 0.7f))
            )
        }
    }
}

/**
 * Framing grid overlay with clinical crosshairs and rule-of-thirds lines.
 */
@Composable
private fun CameraFramingGridOverlay(modifier: Modifier = Modifier) {
    androidx.compose.foundation.Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        val gridColor = Color.White.copy(alpha = 0.28f)
        val cornerColor = Color(0xFF4CAF50).copy(alpha = 0.75f)
        val strokeWidth = 1.dp.toPx()
        val cornerStroke = 2.5.dp.toPx()
        val cornerLen = 28.dp.toPx()

        // Rule of thirds vertical lines
        drawLine(gridColor, Offset(w / 3f, 0f), Offset(w / 3f, h), strokeWidth)
        drawLine(gridColor, Offset(2f * w / 3f, 0f), Offset(2f * w / 3f, h), strokeWidth)

        // Rule of thirds horizontal lines
        drawLine(gridColor, Offset(0f, h / 3f), Offset(w, h / 3f), strokeWidth)
        drawLine(gridColor, Offset(0f, 2f * h / 3f), Offset(w, 2f * h / 3f), strokeWidth)

        // Target bracket corners (Medical / Clinical Focus Area)
        val pad = 40.dp.toPx()
        val boxL = pad
        val boxR = w - pad
        val boxT = pad * 2
        val boxB = h - pad * 2

        // Top-left
        drawLine(cornerColor, Offset(boxL, boxT), Offset(boxL + cornerLen, boxT), cornerStroke)
        drawLine(cornerColor, Offset(boxL, boxT), Offset(boxL, boxT + cornerLen), cornerStroke)

        // Top-right
        drawLine(cornerColor, Offset(boxR, boxT), Offset(boxR - cornerLen, boxT), cornerStroke)
        drawLine(cornerColor, Offset(boxR, boxT), Offset(boxR, boxT + cornerLen), cornerStroke)

        // Bottom-left
        drawLine(cornerColor, Offset(boxL, boxB), Offset(boxL + cornerLen, boxB), cornerStroke)
        drawLine(cornerColor, Offset(boxL, boxB), Offset(boxL, boxB - cornerLen), cornerStroke)

        // Bottom-right
        drawLine(cornerColor, Offset(boxR, boxB), Offset(boxR - cornerLen, boxB), cornerStroke)
        drawLine(cornerColor, Offset(boxR, boxB), Offset(boxR, boxB - cornerLen), cornerStroke)
    }
}

/**
 * Fullscreen Goat Health Camera Screen with controls, category selection,
 * animal tagger, review dialog, and direct persistence into health records.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GoatHealthCameraScreen(
    repository: GoatRepository,
    preselectedGoatId: String? = null,
    onNavigateBack: () -> Unit,
    onPhotoDocumented: ((File, String) -> Unit)? = null
) {
    BackHandler { onNavigateBack() }

    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }

    // Camera Permissions State
    var hasCameraPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.CAMERA
            ) == PackageManager.PERMISSION_GRANTED
        )
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        hasCameraPermission = isGranted
    }

    // Camera Settings State
    var lensFacing by remember { mutableIntStateOf(CameraSelector.LENS_FACING_BACK) }
    var flashMode by remember { mutableIntStateOf(ImageCapture.FLASH_MODE_AUTO) }
    var enableGrid by remember { mutableStateOf(true) }
    var activeImageCapture by remember { mutableStateOf<ImageCapture?>(null) }
    var isCapturing by remember { mutableStateOf(false) }

    // Focus Point animation
    var focusPoint by remember { mutableStateOf<Offset?>(null) }

    LaunchedEffect(focusPoint) {
        if (focusPoint != null) {
            delay(1200)
            focusPoint = null
        }
    }

    // Herd Data for Animal Tagging
    var goatsList by remember { mutableStateOf<List<Goat>>(emptyList()) }
    var selectedGoat by remember { mutableStateOf<Goat?>(null) }
    var showGoatPicker by remember { mutableStateOf(false) }

    // Health Category Selection
    val categories = listOf(
        "General Inspection",
        "Wound / Skin Lesion",
        "Eye / FAMACHA Anemia",
        "Hoof / Foot Rot",
        "Udder / Mastitis",
        "Digestive / Bloat",
        "Mouth / Sore Mouth"
    )
    var selectedCategory by remember { mutableStateOf(categories[0]) }

    // Captured Photo Review State
    var capturedPhotoFile by remember { mutableStateOf<File?>(null) }
    var clinicalNotes by remember { mutableStateOf("") }
    var isSavingRecord by remember { mutableStateOf(false) }
    val aiService = remember { GoatHealthAiAssessmentService() }
    var isAnalyzingWithAi by remember { mutableStateOf(false) }
    var aiReport by remember { mutableStateOf<GoatHealthAiReport?>(null) }

    // Load goats for tagging
    LaunchedEffect(Unit) {
        val result = repository.getGoats()
        if (result.isSuccess) {
            val list = result.getOrThrow()
            goatsList = list
            selectedGoat = if (!preselectedGoatId.isNullOrBlank()) {
                list.firstOrNull { it.id == preselectedGoatId } ?: list.firstOrNull()
            } else {
                list.firstOrNull()
            }
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        containerColor = Color.Black
    ) { padding ->
        if (!hasCameraPermission) {
            // Permission Rationale Card
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .background(Color(0xFF0F172A)),
                contentAlignment = Alignment.Center
            ) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth(0.9f)
                        .testTag("camera_permission_card"),
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                    elevation = CardDefaults.cardElevation(defaultElevation = 6.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = Color(0xFF065F46),
                            modifier = Modifier.size(60.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    Icons.Default.PhotoCamera,
                                    contentDescription = null,
                                    tint = Color(0xFF34D399),
                                    modifier = Modifier.size(32.dp)
                                )
                            }
                        }

                        Text(
                            text = "Camera Permission Required",
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp,
                            color = Color.White
                        )

                        Text(
                            text = "To capture clear health documentation, track wound healing, inspect mucous membranes for anemia, and maintain clinical goat history, the app requires camera access.",
                            fontSize = 13.sp,
                            color = Color(0xFF94A3B8),
                            lineHeight = 18.sp
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        Button(
                            onClick = { permissionLauncher.launch(Manifest.permission.CAMERA) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("btn_grant_camera_permission"),
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = FarmGreenPrimary)
                        ) {
                            Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Grant Camera Access", fontWeight = FontWeight.Bold)
                        }

                        OutlinedButton(
                            onClick = onNavigateBack,
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text("Cancel", color = Color.White)
                        }
                    }
                }
            }
        } else if (capturedPhotoFile != null) {
            // Photo Review & Health Documentation Sheet
            val photo = capturedPhotoFile!!
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .background(Color(0xFF0F172A))
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .verticalScroll(rememberScrollState())
                ) {
                    // Top Bar
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(onClick = { capturedPhotoFile = null }) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Retake", tint = Color.White)
                        }
                        Text(
                            text = "Health Documentation Review",
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            color = Color.White
                        )
                        Box(modifier = Modifier.size(40.dp))
                    }

                    // Captured Image View
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(280.dp)
                            .padding(horizontal = 16.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .background(Color.Black),
                        contentAlignment = Alignment.Center
                    ) {
                        AsyncImage(
                            model = photo,
                            contentDescription = "Captured Goat Health Photo",
                            contentScale = ContentScale.Fit,
                            modifier = Modifier.fillMaxSize()
                        )

                        // Category Badge Overlay
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = Color.Black.copy(alpha = 0.7f),
                            modifier = Modifier
                                .align(Alignment.TopStart)
                                .padding(12.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.LocalHospital, contentDescription = null, tint = Color(0xFF34D399), modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(selectedCategory, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Gemini AI Diagnostics Assessment Section (Requirement 4)
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp)
                            .testTag("gemini_ai_assessment_card"),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                        border = BorderStroke(
                            1.dp,
                            if (aiReport != null) Color(0xFF38BDF8).copy(alpha = 0.5f) else Color(0xFF334155)
                        )
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Surface(
                                        shape = CircleShape,
                                        color = Color(0xFF0369A1).copy(alpha = 0.35f),
                                        modifier = Modifier.size(36.dp)
                                    ) {
                                        Box(contentAlignment = Alignment.Center) {
                                            Icon(
                                                Icons.Default.AutoAwesome,
                                                contentDescription = null,
                                                tint = Color(0xFF38BDF8),
                                                modifier = Modifier.size(20.dp)
                                            )
                                        }
                                    }
                                    Column {
                                        Text(
                                            "Gemini AI Health Assessment",
                                            fontWeight = FontWeight.Bold,
                                            color = Color.White,
                                            fontSize = 14.sp
                                        )
                                        Text(
                                            "Automated visual diagnostics & clinical guidance",
                                            fontSize = 11.sp,
                                            color = Color(0xFF94A3B8)
                                        )
                                    }
                                }

                                if (!isAnalyzingWithAi && aiReport == null) {
                                    Button(
                                        onClick = {
                                            isAnalyzingWithAi = true
                                            coroutineScope.launch {
                                                val result = aiService.assessGoatHealthImage(
                                                    photoFile = photo,
                                                    goatTag = selectedGoat?.tag_c,
                                                    category = selectedCategory,
                                                    farmerNotes = clinicalNotes.ifBlank { null },
                                                    goatBreed = selectedGoat?.breed_c,
                                                    goatSex = selectedGoat?.sex_c
                                                )
                                                isAnalyzingWithAi = false
                                                if (result.isSuccess) {
                                                    aiReport = result.getOrNull()
                                                    snackbarHostState.showSnackbar("AI Diagnostic Assessment Complete!")
                                                } else {
                                                    snackbarHostState.showSnackbar("AI Analysis notice: ${result.exceptionOrNull()?.localizedMessage}")
                                                }
                                            }
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7)),
                                        shape = RoundedCornerShape(10.dp),
                                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                                        modifier = Modifier.testTag("btn_analyze_with_gemini")
                                    ) {
                                        Icon(Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(14.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("Analyze", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }

                            if (isAnalyzingWithAi) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 12.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.Center
                                ) {
                                    CircularProgressIndicator(
                                        color = Color(0xFF38BDF8),
                                        modifier = Modifier.size(20.dp),
                                        strokeWidth = 2.dp
                                    )
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Text(
                                        "Analyzing goat health image with Gemini Vision...",
                                        fontSize = 12.sp,
                                        color = Color(0xFF38BDF8)
                                    )
                                }
                            } else if (aiReport != null) {
                                val report = aiReport!!
                                val severityColor = when (report.severityLevel) {
                                    HealthSeverityLevel.LOW -> Color(0xFF22C55E)
                                    HealthSeverityLevel.MODERATE -> Color(0xFFF59E0B)
                                    HealthSeverityLevel.HIGH -> Color(0xFFF97316)
                                    HealthSeverityLevel.CRITICAL -> Color(0xFFEF4444)
                                }

                                // Severity & FAMACHA & Quarantine Badges
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .horizontalScroll(rememberScrollState()),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Surface(
                                        shape = RoundedCornerShape(6.dp),
                                        color = severityColor.copy(alpha = 0.2f),
                                        border = BorderStroke(1.dp, severityColor)
                                    ) {
                                        Text(
                                            text = "Severity: ${report.severityLevel.name}",
                                            color = severityColor,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 11.sp,
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                        )
                                    }

                                    if (report.famachaScore != null) {
                                        val famachaColor = when (report.famachaScore) {
                                            1, 2 -> Color(0xFF22C55E)
                                            3 -> Color(0xFFF59E0B)
                                            else -> Color(0xFFEF4444)
                                        }
                                        Surface(
                                            shape = RoundedCornerShape(6.dp),
                                            color = famachaColor.copy(alpha = 0.2f),
                                            border = BorderStroke(1.dp, famachaColor)
                                        ) {
                                            Text(
                                                text = "FAMACHA: ${report.famachaScore}/5",
                                                color = famachaColor,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 11.sp,
                                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                            )
                                        }
                                    }

                                    if (report.quarantineRecommended) {
                                        Surface(
                                            shape = RoundedCornerShape(6.dp),
                                            color = Color(0xFFEF4444).copy(alpha = 0.2f),
                                            border = BorderStroke(1.dp, Color(0xFFEF4444))
                                        ) {
                                            Text(
                                                text = "Quarantine Recommended",
                                                color = Color(0xFFEF4444),
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 11.sp,
                                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                            )
                                        }
                                    }

                                    Surface(
                                        shape = RoundedCornerShape(6.dp),
                                        color = Color(0xFF334155)
                                    ) {
                                        Text(
                                            text = report.affectedAnatomicalArea,
                                            color = Color(0xFF94A3B8),
                                            fontSize = 11.sp,
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                        )
                                    }
                                }

                                // Preliminary & Primary Observation
                                Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                    Text(
                                        "Clinical Finding:",
                                        fontSize = 11.sp,
                                        color = Color(0xFF94A3B8),
                                        fontWeight = FontWeight.SemiBold
                                    )
                                    Text(
                                        report.primaryObservation,
                                        fontSize = 13.sp,
                                        color = Color.White,
                                        fontWeight = FontWeight.Medium
                                    )
                                }

                                // Suspected Conditions
                                if (report.suspectedConditions.isNotEmpty()) {
                                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                        Text(
                                            "Suspected Condition(s):",
                                            fontSize = 11.sp,
                                            color = Color(0xFF94A3B8),
                                            fontWeight = FontWeight.SemiBold
                                        )
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .horizontalScroll(rememberScrollState()),
                                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                                        ) {
                                            report.suspectedConditions.forEach { cond ->
                                                Surface(
                                                    shape = RoundedCornerShape(6.dp),
                                                    color = Color(0xFF334155)
                                                ) {
                                                    Text(
                                                        cond,
                                                        fontSize = 11.sp,
                                                        color = Color(0xFFE2E8F0),
                                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }

                                // Immediate Farm Actions
                                if (report.immediateFarmActions.isNotEmpty()) {
                                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                        Text(
                                            "Immediate Recommended Farm Actions:",
                                            fontSize = 11.sp,
                                            color = Color(0xFF34D399),
                                            fontWeight = FontWeight.SemiBold
                                        )
                                        report.immediateFarmActions.forEach { action ->
                                            Row(
                                                verticalAlignment = Alignment.Top,
                                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                                            ) {
                                                Text("•", color = Color(0xFF34D399), fontSize = 12.sp)
                                                Text(action, fontSize = 12.sp, color = Color(0xFFCBD5E1))
                                            }
                                        }
                                    }
                                }

                                // Questions to Ask Veterinarian
                                if (report.questionsToAskVet.isNotEmpty()) {
                                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                        Text(
                                            "Questions for Visiting Veterinarian:",
                                            fontSize = 11.sp,
                                            color = Color(0xFF38BDF8),
                                            fontWeight = FontWeight.SemiBold
                                        )
                                        report.questionsToAskVet.forEach { q ->
                                            Row(
                                                verticalAlignment = Alignment.Top,
                                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                                            ) {
                                                Text("?", color = Color(0xFF38BDF8), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                                Text(q, fontSize = 12.sp, color = Color(0xFFCBD5E1))
                                            }
                                        }
                                    }
                                }

                                // Copy to Notes Action
                                OutlinedButton(
                                    onClick = {
                                        val aiSummary = buildString {
                                            append("AI Finding: ${report.primaryObservation}")
                                            if (report.famachaScore != null) append(" [FAMACHA: ${report.famachaScore}/5]")
                                            if (report.immediateFarmActions.isNotEmpty()) {
                                                append(". Actions: ${report.immediateFarmActions.joinToString("; ")}")
                                            }
                                        }
                                        clinicalNotes = if (clinicalNotes.isBlank()) aiSummary else "$clinicalNotes\n$aiSummary"
                                    },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("btn_copy_ai_to_notes"),
                                    shape = RoundedCornerShape(8.dp),
                                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFF38BDF8))
                                ) {
                                    Icon(Icons.Default.AddComment, contentDescription = null, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Copy Findings to Clinical Notes", fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                                }

                                Text(
                                    text = report.veterinaryDisclaimer,
                                    fontSize = 10.sp,
                                    color = Color(0xFF64748B),
                                    fontStyle = androidx.compose.ui.text.font.FontStyle.Italic
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Clinical Record Metadata & Notes Card
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp)
                            .padding(bottom = 24.dp),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B))
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text("Animal Tagged:", fontSize = 11.sp, color = Color.Gray)
                                    val tag = selectedGoat?.tag_c ?: "General Herd"
                                    val name = selectedGoat?.name ?: "All Goats"
                                    Text("#$tag • $name", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color.White)
                                }
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = Color(0xFF065F46)
                                ) {
                                    Text(
                                        text = SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault()).format(Date()),
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                        fontSize = 11.sp,
                                        color = Color(0xFF34D399),
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }

                            OutlinedTextField(
                                value = clinicalNotes,
                                onValueChange = { clinicalNotes = it },
                                label = { Text("Clinical Symptoms / Diagnosis / Care Plan") },
                                placeholder = { Text("e.g. Disinfected wound with Betadine; administered antiseptic spray.") },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("health_photo_notes_input"),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = FarmGreenPrimary,
                                    unfocusedBorderColor = Color.Gray,
                                    focusedTextColor = Color.White,
                                    unfocusedTextColor = Color.White,
                                    focusedLabelColor = FarmGreenPrimary,
                                    unfocusedLabelColor = Color.Gray
                                ),
                                maxLines = 4
                            )

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                OutlinedButton(
                                    onClick = { capturedPhotoFile = null },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(10.dp)
                                ) {
                                    Icon(Icons.Default.Refresh, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Retake", color = Color.White)
                                }

                                Button(
                                    onClick = {
                                        isSavingRecord = true
                                        coroutineScope.launch {
                                            val goatId = selectedGoat?.id ?: "general_herd"
                                            val dateStr = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
                                            val finalNotes = "[$selectedCategory] Photo: ${photo.name}. ${clinicalNotes.trim()}"

                                            val treatment = TreatmentRecord(
                                                goat_id_c = goatId,
                                                symptoms_c = selectedCategory,
                                                diagnosis_c = if (clinicalNotes.isNotBlank()) clinicalNotes.take(60) else selectedCategory,
                                                medicine_c = "Clinical Photo Documented",
                                                dose_c = "1 Record",
                                                start_date_c = dateStr,
                                                record_type_c = "Health Observation",
                                                notes_c = finalNotes
                                            )
                                            repository.recordTreatment(treatment)

                                            onPhotoDocumented?.invoke(photo, finalNotes)
                                            isSavingRecord = false
                                            snackbarHostState.showSnackbar("Health photo & clinical observation documented!")
                                            delay(500)
                                            onNavigateBack()
                                        }
                                    },
                                    modifier = Modifier
                                        .weight(1.5f)
                                        .testTag("btn_save_health_photo_doc"),
                                    shape = RoundedCornerShape(10.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = FarmGreenPrimary),
                                    enabled = !isSavingRecord
                                ) {
                                    if (isSavingRecord) {
                                        CircularProgressIndicator(color = Color.White, modifier = Modifier.size(16.dp))
                                    } else {
                                        Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("Save to Health Record", fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            // Live Camera Viewfinder Experience
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
            ) {
                // CameraX Preview
                GoatHealthCameraPreview(
                    modifier = Modifier.fillMaxSize(),
                    lensFacing = lensFacing,
                    flashMode = flashMode,
                    enableGrid = enableGrid,
                    isCapturing = isCapturing,
                    onCaptureReady = { capture -> activeImageCapture = capture },
                    onFocusPointChanged = { pt -> focusPoint = pt }
                )

                // Animated Tap-To-Focus Ring
                focusPoint?.let { pt ->
                    Box(
                        modifier = Modifier
                            .offset(
                                x = (pt.x / context.resources.displayMetrics.density).dp - 30.dp,
                                y = (pt.y / context.resources.displayMetrics.density).dp - 30.dp
                            )
                            .size(60.dp)
                            .border(2.dp, Color(0xFFFFD54F), CircleShape)
                    )
                }

                // Top Controls Overlay (Back, Flash, Grid, Switch Camera)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .statusBarsPadding()
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = onNavigateBack,
                        modifier = Modifier
                            .background(Color.Black.copy(alpha = 0.5f), CircleShape)
                            .testTag("camera_btn_back")
                    ) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Flash Toggle
                        IconButton(
                            onClick = {
                                flashMode = when (flashMode) {
                                    ImageCapture.FLASH_MODE_AUTO -> ImageCapture.FLASH_MODE_ON
                                    ImageCapture.FLASH_MODE_ON -> ImageCapture.FLASH_MODE_OFF
                                    else -> ImageCapture.FLASH_MODE_AUTO
                                }
                            },
                            modifier = Modifier.background(Color.Black.copy(alpha = 0.5f), CircleShape)
                        ) {
                            Icon(
                                imageVector = when (flashMode) {
                                    ImageCapture.FLASH_MODE_ON -> Icons.Default.FlashOn
                                    ImageCapture.FLASH_MODE_OFF -> Icons.Default.FlashOff
                                    else -> Icons.Default.FlashAuto
                                },
                                contentDescription = "Flash Mode",
                                tint = if (flashMode == ImageCapture.FLASH_MODE_OFF) Color.White.copy(alpha = 0.6f) else Color(0xFFFFD54F)
                            )
                        }

                        // Grid Toggle
                        IconButton(
                            onClick = { enableGrid = !enableGrid },
                            modifier = Modifier.background(Color.Black.copy(alpha = 0.5f), CircleShape)
                        ) {
                            Icon(
                                imageVector = Icons.Default.GridOn,
                                contentDescription = "Grid",
                                tint = if (enableGrid) Color(0xFF34D399) else Color.White.copy(alpha = 0.6f)
                            )
                        }

                        // Switch Camera Lens (Front/Back)
                        IconButton(
                            onClick = {
                                lensFacing = if (lensFacing == CameraSelector.LENS_FACING_BACK) {
                                    CameraSelector.LENS_FACING_FRONT
                                } else {
                                    CameraSelector.LENS_FACING_BACK
                                }
                            },
                            modifier = Modifier.background(Color.Black.copy(alpha = 0.5f), CircleShape)
                        ) {
                            Icon(Icons.Default.FlipCameraAndroid, contentDescription = "Switch Camera", tint = Color.White)
                        }
                    }
                }

                // Middle/Top Animal Tagger Chip
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = Color.Black.copy(alpha = 0.65f),
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .padding(top = 70.dp)
                        .clickable { showGoatPicker = true }
                        .testTag("tag_goat_selector_chip")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Pets, contentDescription = null, tint = Color(0xFF34D399), modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        val goatLabel = selectedGoat?.let { "Kid/Goat #${it.tag_c} • ${it.breed_c ?: "Boer"}" } ?: "Select Goat Tag"
                        Text(goatLabel, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.width(4.dp))
                        Icon(Icons.Default.ArrowDropDown, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                    }
                }

                // Bottom Controls Area (Category Pills, Shutter Button)
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .align(Alignment.BottomCenter)
                        .background(Color.Black.copy(alpha = 0.55f))
                        .navigationBarsPadding()
                        .padding(vertical = 14.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Category Selection Pills
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState())
                            .padding(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        categories.forEach { cat ->
                            val isSelected = selectedCategory == cat
                            Surface(
                                shape = RoundedCornerShape(16.dp),
                                color = if (isSelected) FarmGreenPrimary else Color.White.copy(alpha = 0.15f),
                                modifier = Modifier.clickable { selectedCategory = cat }
                            ) {
                                Text(
                                    text = cat,
                                    fontSize = 11.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    color = if (isSelected) Color.White else Color(0xFFE2E8F0),
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                                )
                            }
                        }
                    }

                    // Shutter Button Row
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 32.dp),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Quick Tip info
                        Surface(
                            shape = CircleShape,
                            color = Color.White.copy(alpha = 0.15f),
                            modifier = Modifier.size(44.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(Icons.Default.Info, contentDescription = "Tip", tint = Color.White.copy(alpha = 0.8f), modifier = Modifier.size(20.dp))
                            }
                        }

                        // Large Shutter Button
                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier
                                .size(76.dp)
                                .border(4.dp, Color.White, CircleShape)
                                .padding(6.dp)
                                .clip(CircleShape)
                                .background(if (isCapturing) Color.LightGray else FarmGreenPrimary)
                                .clickable(enabled = !isCapturing && activeImageCapture != null) {
                                    val capture = activeImageCapture ?: return@clickable
                                    isCapturing = true

                                    val photoDir = context.getExternalFilesDir(Environment.DIRECTORY_PICTURES) ?: context.filesDir
                                    val goatTag = selectedGoat?.tag_c ?: "herd"
                                    val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
                                    val photoFile = File(photoDir, "health_${goatTag}_${timeStamp}.jpg")

                                    val outputOptions = ImageCapture.OutputFileOptions.Builder(photoFile).build()

                                    capture.takePicture(
                                        outputOptions,
                                        ContextCompat.getMainExecutor(context),
                                        object : ImageCapture.OnImageSavedCallback {
                                            override fun onImageSaved(outputFileResults: ImageCapture.OutputFileResults) {
                                                isCapturing = false
                                                capturedPhotoFile = photoFile
                                            }

                                            override fun onError(exception: ImageCaptureException) {
                                                isCapturing = false
                                                coroutineScope.launch {
                                                    snackbarHostState.showSnackbar("Capture failed: ${exception.localizedMessage}")
                                                }
                                            }
                                        }
                                    )
                                }
                                .testTag("camera_shutter_button")
                        ) {
                            Icon(Icons.Default.Camera, contentDescription = "Capture Photo", tint = Color.White, modifier = Modifier.size(34.dp))
                        }

                        // Gallery / Album fallback
                        val photoPicker = rememberLauncherForActivityResult(
                            contract = ActivityResultContracts.PickVisualMedia()
                        ) { uri ->
                            if (uri != null) {
                                coroutineScope.launch(Dispatchers.IO) {
                                    try {
                                        val inputStream = context.contentResolver.openInputStream(uri)
                                        val photoDir = context.getExternalFilesDir(Environment.DIRECTORY_PICTURES) ?: context.filesDir
                                        val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
                                        val targetFile = File(photoDir, "health_picked_${timeStamp}.jpg")
                                        inputStream?.use { input ->
                                            targetFile.outputStream().use { output ->
                                                input.copyTo(output)
                                            }
                                        }
                                        withContext(Dispatchers.Main) {
                                            capturedPhotoFile = targetFile
                                        }
                                    } catch (e: Exception) {
                                        e.printStackTrace()
                                    }
                                }
                            }
                        }

                        Surface(
                            shape = CircleShape,
                            color = Color.White.copy(alpha = 0.15f),
                            modifier = Modifier
                                .size(44.dp)
                                .clickable {
                                    photoPicker.launch(
                                        androidx.activity.result.PickVisualMediaRequest(
                                            ActivityResultContracts.PickVisualMedia.ImageOnly
                                        )
                                    )
                                }
                                .testTag("camera_pick_gallery_button")
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(Icons.Default.PhotoLibrary, contentDescription = "Pick Image", tint = Color.White.copy(alpha = 0.8f), modifier = Modifier.size(20.dp))
                            }
                        }
                    }
                }
            }
        }
    }

    // Goat Tag Picker Dialog
    if (showGoatPicker) {
        AlertDialog(
            onDismissRequest = { showGoatPicker = false },
            title = {
                Text("Select Goat for Health Photo", fontWeight = FontWeight.Bold)
            },
            text = {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text("Associate clinical observation with specific animal tag:", fontSize = 12.sp, color = Color.Gray)
                    Spacer(modifier = Modifier.height(10.dp))
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(max = 300.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        items(goatsList) { goat ->
                            val isSelected = selectedGoat?.id == goat.id
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = if (isSelected) Color(0xFFE8F5E9) else Color(0xFFF8FAFC),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        selectedGoat = goat
                                        showGoatPicker = false
                                    }
                            ) {
                                Row(
                                    modifier = Modifier.padding(10.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column {
                                        Text("#${goat.tag_c} • ${goat.name}", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                        Text("Breed: ${goat.breed_c ?: "Boer"} • Sex: ${goat.sex_c ?: "Doe"}", fontSize = 11.sp, color = Color.Gray)
                                    }
                                    if (isSelected) {
                                        Icon(Icons.Default.Check, contentDescription = null, tint = FarmGreenDark, modifier = Modifier.size(18.dp))
                                    }
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showGoatPicker = false }) {
                    Text("Close")
                }
            }
        )
    }
}
