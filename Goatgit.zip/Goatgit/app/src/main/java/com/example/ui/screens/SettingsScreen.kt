package com.example.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.backup.BackupManager
import com.example.data.backup.DriveBackupFile
import com.example.data.backup.DriveBackupStatus
import com.example.data.backup.LocalBackupInfo
import com.example.data.backup.LocalBackupStatus
import com.example.data.offline.BackupLogEntity
import com.example.data.supabase.GoatRepository
import com.example.data.supabase.SupabaseConfig
import com.example.i18n.LanguageToggle
import com.example.i18n.LocalLanguage
import com.example.i18n.LocalLanguageManager
import com.example.i18n.t
import com.example.ui.components.FarmTopBar
import com.example.ui.theme.*
import com.example.data.farm.FarmSetupCard
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.common.api.ApiException
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    repository: GoatRepository,
    config: SupabaseConfig,
    onNavigateBack: () -> Unit,
    onSignOut: () -> Unit
) {
    val coroutineScope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }
    val backupManager = repository.backupManager
    val authManager = backupManager.authManager
    val currentLang = LocalLanguage.current
    val languageManager = LocalLanguageManager.current
    val farmProfileManager = repository.farmProfileManager
    val farmProfile by farmProfileManager.farmProfile.collectAsState()

    val isAutoBackupEnabled by backupManager.isAutoBackupEnabled.collectAsState()
    val lastBackupTime by backupManager.lastBackupTime.collectAsState()
    val nextBackupTime by backupManager.nextBackupTime.collectAsState()
    val backupStatus by backupManager.backupStatus.collectAsState()
    val lastError by backupManager.lastError.collectAsState()
    val isBackingUp by backupManager.isBackingUp.collectAsState()
    val isRestoring by backupManager.isRestoring.collectAsState()
    val connectedEmail by authManager.connectedAccountEmail.collectAsState()
    val backupLogs by backupManager.backupLogs.collectAsState(initial = emptyList())

    val localBackupStatus by backupManager.localBackupStatus.collectAsState()
    val lastLocalBackupTime by backupManager.lastLocalBackupTime.collectAsState()
    val lastLocalBackupInfo by backupManager.lastLocalBackupInfo.collectAsState()
    val localBackupError by backupManager.localBackupError.collectAsState()

    var showLocalRestoreDialog by remember { mutableStateOf(false) }
    var localBackupsList by remember { mutableStateOf<List<LocalBackupInfo>>(emptyList()) }
    var selectedLocalBackupForRestore by remember { mutableStateOf<LocalBackupInfo?>(null) }
    var showConfirmLocalRestoreAlert by remember { mutableStateOf(false) }
    var isPerformingLocalBackup by remember { mutableStateOf(false) }

    val isOnline = repository.syncManager.syncState.collectAsState().value != com.example.data.offline.SyncState.OFFLINE

    var showRestoreDialog by remember { mutableStateOf(false) }
    var availableBackups by remember { mutableStateOf<List<DriveBackupFile>>(emptyList()) }
    var isLoadingBackups by remember { mutableStateOf(false) }
    var selectedBackupForRestore by remember { mutableStateOf<DriveBackupFile?>(null) }
    var showConfirmRestoreAlert by remember { mutableStateOf(false) }

    val dateFormat = remember { SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()) }
    val lastBackupDisplay = remember(lastBackupTime) {
        if (lastBackupTime > 0) dateFormat.format(Date(lastBackupTime)) else "Never"
    }
    val nextBackupDisplay = remember(nextBackupTime, isAutoBackupEnabled, isOnline) {
        if (!isAutoBackupEnabled) {
            "Disabled"
        } else if (!isOnline) {
            "When device is online"
        } else if (nextBackupTime > 0) {
            dateFormat.format(Date(nextBackupTime))
        } else {
            "Approximately every 24 hours"
        }
    }

    val googleSignInLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val task = GoogleSignIn.getSignedInAccountFromIntent(result.data)
        try {
            val account = task.getResult(ApiException::class.java)
            val success = authManager.handleSignInResult(account)
            if (success) {
                coroutineScope.launch {
                    snackbarHostState.showSnackbar("Google Drive connected successfully!")
                }
            } else {
                coroutineScope.launch {
                    snackbarHostState.showSnackbar("Failed to get Google Drive permissions.")
                }
            }
        } catch (e: Exception) {
            coroutineScope.launch {
                snackbarHostState.showSnackbar("Google Sign-In canceled or failed: ${e.message}")
            }
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            FarmTopBar(
                title = t("settings.title"),
                canNavigateBack = true,
                onNavigateBack = onNavigateBack,
                syncManager = repository.syncManager
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item { Spacer(modifier = Modifier.height(4.dp)) }

            // ==========================================
            // 1. FARM SETUP & BRANDING (Custom Farm Name & Logo)
            // ==========================================
            item {
                FarmSetupCard(
                    farmProfile = farmProfile,
                    onSaveProfile = { name, uri ->
                        coroutineScope.launch {
                            val res = farmProfileManager.saveFarmProfile(name, uri)
                            if (res.isSuccess) {
                                snackbarHostState.showSnackbar("Farm branding updated successfully!")
                            } else {
                                snackbarHostState.showSnackbar("Failed to update farm branding: ${res.exceptionOrNull()?.message}")
                            }
                        }
                    },
                    onClearLogo = {
                        coroutineScope.launch {
                            farmProfileManager.clearLogo()
                            snackbarHostState.showSnackbar("Farm logo reset to default emblem")
                        }
                    },
                    onResetDefault = {
                        coroutineScope.launch {
                            farmProfileManager.resetToDefault()
                            snackbarHostState.showSnackbar("Farm profile reset to default ('My Goat Farm')")
                        }
                    }
                )
            }

            // ==========================================
            // LANGUAGE SELECTION (Bilingual English | தமிழ்)
            // ==========================================
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier.fillMaxWidth().testTag("language_settings_card")
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(40.dp)
                                        .clip(CircleShape)
                                        .background(FarmGreenContainer),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Language,
                                        contentDescription = null,
                                        tint = FarmGreenDark,
                                        modifier = Modifier.size(22.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(
                                        text = t("settings.section_language"),
                                        fontWeight = FontWeight.Bold,
                                        style = MaterialTheme.typography.titleMedium
                                    )
                                    Text(
                                        text = t("settings.language_desc"),
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        if (languageManager != null) {
                            LanguageToggle(
                                currentLanguage = currentLang,
                                onLanguageChange = { languageManager.setLanguage(it) },
                                isDarkHeader = false,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                }
            }

            // ==========================================
            // VACCINATION NOTIFICATION REMINDERS
            // ==========================================
            item {
                VaccinationNotificationSettingsCard(
                    repository = repository,
                    snackbarHostState = snackbarHostState
                )
            }

            // ==========================================
            // PAYMENT SETTINGS (INR ₹, UPI / QR, Paytm Gateway)
            // ==========================================
            item {
                val context = androidx.compose.ui.platform.LocalContext.current
                val paymentSettings = remember { com.example.data.payment.PaymentSettingsManager.getInstance(context) }
                var upiQrEnabled by remember { mutableStateOf(paymentSettings.isUpiQrEnabled) }
                var merchantUpiId by remember { mutableStateOf(paymentSettings.merchantUpiId) }
                var merchantName by remember { mutableStateOf(paymentSettings.merchantName) }
                var paytmGatewayEnabled by remember { mutableStateOf(paymentSettings.isPaytmGatewayEnabled) }
                var paytmEnv by remember { mutableStateOf(paymentSettings.paytmEnvironment) }
                var paytmMid by remember { mutableStateOf(paymentSettings.paytmMerchantId) }

                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier.fillMaxWidth().testTag("payment_settings_card")
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(40.dp)
                                        .clip(CircleShape)
                                        .background(com.example.ui.components.PaytmLightBg),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = "₹",
                                        fontWeight = FontWeight.ExtraBold,
                                        fontSize = 20.sp,
                                        color = com.example.ui.components.PaytmNavy
                                    )
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(
                                        text = t("settings.section_payments"),
                                        fontWeight = FontWeight.Bold,
                                        style = MaterialTheme.typography.titleMedium
                                    )
                                    Text(
                                        text = t("settings.payments_desc"),
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // Currency display (Fixed INR ₹ default)
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = Color(0xFFF8FAFC),
                            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text("Application Currency", fontSize = 12.sp, color = Color.Gray)
                                    Text("Indian Rupee (INR ₹)", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = FarmGreenDark)
                                }
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = FarmGreenContainer
                                ) {
                                    Text(
                                        text = "Default",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 11.sp,
                                        color = FarmOnGreenContainer,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))
                        Divider(color = Color(0xFFF1F5F9))
                        Spacer(modifier = Modifier.height(14.dp))

                        // UPI / QR Toggle
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("UPI / QR Payments", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                                Text("Accept payments via Paytm Merchant QR & UPI apps", fontSize = 11.sp, color = Color.Gray)
                            }
                            Switch(
                                checked = upiQrEnabled,
                                onCheckedChange = {
                                    upiQrEnabled = it
                                    paymentSettings.setUpiQrEnabled(it)
                                },
                                modifier = Modifier.testTag("upi_qr_switch")
                            )
                        }

                        if (upiQrEnabled) {
                            Spacer(modifier = Modifier.height(8.dp))
                            OutlinedTextField(
                                value = merchantUpiId,
                                onValueChange = {
                                    merchantUpiId = it
                                    paymentSettings.setMerchantUpiId(it)
                                },
                                label = { Text("Merchant UPI ID / VPA") },
                                placeholder = { Text("e.g. goatfarm.paytm@paytm") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth().testTag("merchant_upi_input")
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            OutlinedTextField(
                                value = merchantName,
                                onValueChange = {
                                    merchantName = it
                                    paymentSettings.setMerchantName(it)
                                },
                                label = { Text("Merchant Display Name") },
                                placeholder = { Text("e.g. Goat Farm Management") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }

                        Spacer(modifier = Modifier.height(14.dp))
                        Divider(color = Color(0xFFF1F5F9))
                        Spacer(modifier = Modifier.height(14.dp))

                        // Paytm Gateway Toggle
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Paytm Payment Gateway", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                                Text("All-in-One server-side verified online checkout", fontSize = 11.sp, color = Color.Gray)
                            }
                            Switch(
                                checked = paytmGatewayEnabled,
                                onCheckedChange = {
                                    paytmGatewayEnabled = it
                                    paymentSettings.setPaytmGatewayEnabled(it)
                                },
                                modifier = Modifier.testTag("paytm_gateway_switch")
                            )
                        }

                        if (paytmGatewayEnabled) {
                            Spacer(modifier = Modifier.height(10.dp))
                            Text("Paytm Environment:", fontWeight = FontWeight.SemiBold, fontSize = 12.sp, color = Color.DarkGray)
                            Spacer(modifier = Modifier.height(4.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                FilterChip(
                                    selected = paytmEnv == com.example.data.payment.PaymentSettingsManager.ENV_STAGING,
                                    onClick = {
                                        paytmEnv = com.example.data.payment.PaymentSettingsManager.ENV_STAGING
                                        paymentSettings.setPaytmEnvironment(com.example.data.payment.PaymentSettingsManager.ENV_STAGING)
                                    },
                                    label = { Text("Staging (Test Mode)", fontWeight = FontWeight.Bold, fontSize = 11.sp) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = FarmWarning,
                                        selectedLabelColor = Color.Black
                                    ),
                                    modifier = Modifier.weight(1f).testTag("paytm_env_staging")
                                )

                                FilterChip(
                                    selected = paytmEnv == com.example.data.payment.PaymentSettingsManager.ENV_PRODUCTION,
                                    onClick = {
                                        paytmEnv = com.example.data.payment.PaymentSettingsManager.ENV_PRODUCTION
                                        paymentSettings.setPaytmEnvironment(com.example.data.payment.PaymentSettingsManager.ENV_PRODUCTION)
                                    },
                                    label = { Text("Production", fontWeight = FontWeight.Bold, fontSize = 11.sp) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = com.example.ui.components.PaytmNavy,
                                        selectedLabelColor = Color.White
                                    ),
                                    modifier = Modifier.weight(1f).testTag("paytm_env_production")
                                )
                            }

                            if (paytmEnv == com.example.data.payment.PaymentSettingsManager.ENV_STAGING) {
                                Spacer(modifier = Modifier.height(6.dp))
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = FarmWarningContainer
                                ) {
                                    Text(
                                        text = "PAYTM TEST MODE: Test orders and simulated server verification active.",
                                        fontSize = 11.sp,
                                        color = FarmWarning,
                                        fontWeight = FontWeight.SemiBold,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))
                            OutlinedTextField(
                                value = paytmMid,
                                onValueChange = {
                                    paytmMid = it
                                    paymentSettings.setPaytmMerchantId(it)
                                },
                                label = { Text("Paytm Merchant ID (MID)") },
                                placeholder = { Text("e.g. TEST_GOAT_FARM_MID_01") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth().testTag("paytm_mid_input")
                            )

                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "Security: Paytm Merchant Key is securely stored server-side in Supabase Edge Functions. It is never exposed in the client UI.",
                                fontSize = 11.sp,
                                color = Color.Gray
                            )
                        }
                    }
                }
            }

            // ==========================================
            // LOCAL DEVICE STORAGE BACKUP (PRIMARY • OFFLINE-FIRST)
            // ==========================================
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Save,
                                    contentDescription = null,
                                    tint = FarmGreenDark,
                                    modifier = Modifier.size(26.dp)
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = "Device Storage Backup",
                                        fontWeight = FontWeight.Bold,
                                        style = MaterialTheme.typography.titleMedium
                                    )
                                    Text(
                                        text = "Primary Backup • Works 100% Offline",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = FarmGreenDark
                                    )
                                }
                            }

                            // Auto Daily Local Backup Switch (Default: ON)
                            var autoLocalEnabled by remember { mutableStateOf(true) }
                            Switch(
                                checked = autoLocalEnabled,
                                onCheckedChange = { checked ->
                                    autoLocalEnabled = checked
                                    if (checked) {
                                        backupManager.scheduleDailyLocalBackup()
                                    } else {
                                        backupManager.cancelDailyLocalBackup()
                                    }
                                },
                                modifier = Modifier.testTag("auto_local_backup_switch")
                            )
                        }

                        Text(
                            text = "Automatic daily backup to device storage (no internet or cloud required). Retains latest 30 backups.",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color.Gray,
                            modifier = Modifier.padding(top = 4.dp, bottom = 8.dp)
                        )

                        Divider(modifier = Modifier.padding(vertical = 8.dp), color = Color(0xFFEEEEEE))

                        // Status Card
                        when (localBackupStatus) {
                            LocalBackupStatus.COMPLETED -> {
                                Surface(
                                    shape = RoundedCornerShape(10.dp),
                                    color = FarmGreenContainer,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(modifier = Modifier.padding(12.dp)) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(
                                                imageVector = Icons.Default.CheckCircle,
                                                contentDescription = null,
                                                tint = FarmSuccess,
                                                modifier = Modifier.size(20.dp)
                                            )
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Text(
                                                text = "BACKUP COMPLETED & VERIFIED",
                                                fontWeight = FontWeight.Bold,
                                                color = FarmGreenDark,
                                                fontSize = 13.sp
                                            )
                                        }

                                        Spacer(modifier = Modifier.height(8.dp))

                                        lastLocalBackupInfo?.let { info ->
                                            Text("• Date/Time: ${info.formattedDate}", fontSize = 12.sp, color = FarmGreenDark)
                                            Text("• Backup Size: ${info.formattedSize}", fontSize = 12.sp, color = FarmGreenDark)
                                            Text("• Records Backed Up: ${info.recordCount} records", fontSize = 12.sp, color = FarmGreenDark)
                                            Text("• File: ${info.fileName}", fontSize = 12.sp, color = FarmGreenDark)
                                            Text("• Location: ${info.location}", fontSize = 11.sp, color = Color.DarkGray)
                                            Text("• Integrity: SHA-256 Checksum Verified", fontSize = 11.sp, color = FarmSuccess, fontWeight = FontWeight.SemiBold)
                                        } ?: run {
                                            Text("Local device backup package is valid and ready.", fontSize = 12.sp, color = FarmGreenDark)
                                        }
                                    }
                                }
                            }
                            LocalBackupStatus.IN_PROGRESS -> {
                                Surface(
                                    shape = RoundedCornerShape(10.dp),
                                    color = Color(0xFFE1F5FE),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier.padding(12.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp, color = Color(0xFF0288D1))
                                        Spacer(modifier = Modifier.width(10.dp))
                                        Text(
                                            text = "Creating and validating local backup package...",
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.SemiBold,
                                            color = Color(0xFF01579B)
                                        )
                                    }
                                }
                            }
                            LocalBackupStatus.FAILED -> {
                                Surface(
                                    shape = RoundedCornerShape(10.dp),
                                    color = FarmErrorContainer,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(modifier = Modifier.padding(12.dp)) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(
                                                imageVector = Icons.Default.Warning,
                                                contentDescription = null,
                                                tint = FarmError,
                                                modifier = Modifier.size(20.dp)
                                            )
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Text(
                                                text = "BACKUP FAILED",
                                                fontWeight = FontWeight.Bold,
                                                color = FarmError,
                                                fontSize = 13.sp
                                            )
                                        }
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            text = localBackupError ?: "An unexpected error occurred during local backup.",
                                            fontSize = 12.sp,
                                            color = FarmError
                                        )
                                    }
                                }
                            }
                            LocalBackupStatus.IDLE -> {
                                Surface(
                                    shape = RoundedCornerShape(10.dp),
                                    color = Color(0xFFF8F9FA),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier.padding(12.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Save,
                                            contentDescription = null,
                                            tint = FarmBrown,
                                            modifier = Modifier.size(20.dp)
                                        )
                                        Spacer(modifier = Modifier.width(10.dp))
                                        Column {
                                            Text(
                                                text = "Device Storage Ready",
                                                fontWeight = FontWeight.SemiBold,
                                                fontSize = 13.sp
                                            )
                                            Text(
                                                text = "Backups saved to Documents/Goat Farm Manager/Backups/",
                                                fontSize = 11.sp,
                                                color = Color.Gray
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // Action Buttons: [ BACKUP NOW ] and [ RESTORE BACKUP ]
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Button(
                                onClick = {
                                    coroutineScope.launch {
                                        isPerformingLocalBackup = true
                                        val res = backupManager.createLocalDeviceBackup(isScheduled = false)
                                        isPerformingLocalBackup = false
                                        if (res.isSuccess) {
                                            val info = res.getOrNull()
                                            snackbarHostState.showSnackbar("BACKUP COMPLETED: ${info?.fileName} (${info?.formattedSize}, ${info?.recordCount} records)")
                                        } else {
                                            snackbarHostState.showSnackbar("BACKUP FAILED: ${res.exceptionOrNull()?.message}")
                                        }
                                    }
                                },
                                enabled = !isBackingUp && !isRestoring && !isPerformingLocalBackup,
                                colors = ButtonDefaults.buttonColors(containerColor = FarmGreenDark),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("backup_now_btn")
                            ) {
                                if (isPerformingLocalBackup || isBackingUp) {
                                    CircularProgressIndicator(color = Color.White, modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Backing up...", fontSize = 12.sp)
                                } else {
                                    Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("BACKUP NOW", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                }
                            }

                            OutlinedButton(
                                onClick = {
                                    coroutineScope.launch {
                                        localBackupsList = backupManager.getLocalBackupHistory()
                                        showLocalRestoreDialog = true
                                    }
                                },
                                enabled = !isBackingUp && !isRestoring && !isPerformingLocalBackup,
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("restore_backup_btn")
                            ) {
                                Icon(Icons.Default.Restore, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("RESTORE BACKUP", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                        }
                    }
                }
            }

            // ==========================================
            // GOOGLE DRIVE BACKUP CONFIGURATION
            // ==========================================
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.CloudSync,
                                    contentDescription = null,
                                    tint = FarmGreenDark,
                                    modifier = Modifier.size(26.dp)
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = "Google Drive Backup (Optional)",
                                        fontWeight = FontWeight.Bold,
                                        style = MaterialTheme.typography.titleMedium
                                    )
                                    Text(
                                        text = "Optional secondary cloud sync",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = Color.Gray
                                    )
                                }
                            }

                            // Switch: Enable automatic Google Drive backup
                            Switch(
                                checked = isAutoBackupEnabled,
                                onCheckedChange = { checked ->
                                    if (checked && !authManager.isConnected()) {
                                        // Request permission first
                                        googleSignInLauncher.launch(authManager.getSignInIntent())
                                    }
                                    backupManager.setAutoBackupEnabled(checked)
                                },
                                modifier = Modifier.testTag("auto_backup_switch")
                            )
                        }

                        Text(
                            text = "Enable automatic backup (once every 24 hours)",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color.Gray,
                            modifier = Modifier.padding(vertical = 4.dp)
                        )

                        Divider(modifier = Modifier.padding(vertical = 12.dp), color = Color(0xFFEEEEEE))

                        // Status Info List
                        BackupInfoRow(
                            label = "Status",
                            value = if (authManager.isConnected()) "Connected" else "Not connected",
                            valueColor = if (authManager.isConnected()) FarmSuccess else Color.Gray,
                            icon = if (authManager.isConnected()) Icons.Default.CheckCircle else Icons.Default.Cancel
                        )

                        if (!connectedEmail.isNullOrBlank()) {
                            BackupInfoRow(
                                label = "Google Account",
                                value = connectedEmail ?: "",
                                icon = Icons.Default.AccountCircle
                            )
                        }

                        BackupInfoRow(
                            label = "Last backup",
                            value = lastBackupDisplay,
                            icon = Icons.Default.History
                        )

                        BackupInfoRow(
                            label = "Next backup",
                            value = nextBackupDisplay,
                            icon = Icons.Default.Update
                        )

                        BackupInfoRow(
                            label = "Backup status",
                            value = when {
                                !authManager.isConnected() -> "Not Connected (Optional)"
                                backupStatus == DriveBackupStatus.SYNCED -> "Synced"
                                backupStatus == DriveBackupStatus.PENDING -> "Scheduled"
                                backupStatus == DriveBackupStatus.FAILED -> "Failed"
                                backupStatus == DriveBackupStatus.IN_PROGRESS -> "In Progress"
                                else -> "Idle"
                            },
                            valueColor = when {
                                !authManager.isConnected() -> Color.Gray
                                backupStatus == DriveBackupStatus.SYNCED -> FarmSuccess
                                backupStatus == DriveBackupStatus.PENDING -> FarmWarning
                                backupStatus == DriveBackupStatus.FAILED -> FarmError
                                else -> Color.DarkGray
                            },
                            icon = Icons.Default.Sync
                        )

                        BackupInfoRow(
                            label = "Drive Folder",
                            value = "Goat Farm Manager / Backups",
                            icon = Icons.Default.Folder
                        )

                        BackupInfoRow(
                            label = "Retention",
                            value = "Keep latest 30 daily backups",
                            icon = Icons.Default.AutoDelete
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        // Action Buttons
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            if (!authManager.isConnected()) {
                                Button(
                                    onClick = {
                                        googleSignInLauncher.launch(authManager.getSignInIntent())
                                    },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("connect_google_drive_btn"),
                                    colors = ButtonDefaults.buttonColors(containerColor = FarmGreenDark)
                                ) {
                                    Icon(Icons.Default.Cloud, contentDescription = null)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(t("settings.connect_drive"), fontWeight = FontWeight.Bold)
                                }
                            } else {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    // Backup Now
                                    Button(
                                        onClick = {
                                            coroutineScope.launch {
                                                val res = backupManager.createBackup(isScheduled = false)
                                                if (res.isSuccess) {
                                                    snackbarHostState.showSnackbar("Backup created successfully in Google Drive!")
                                                } else {
                                                    snackbarHostState.showSnackbar("Backup failed: ${res.exceptionOrNull()?.message}")
                                                }
                                            }
                                        },
                                        enabled = !isBackingUp && !isRestoring,
                                        modifier = Modifier
                                            .weight(1f)
                                            .testTag("backup_now_btn"),
                                        colors = ButtonDefaults.buttonColors(containerColor = FarmGreenDark)
                                    ) {
                                        if (isBackingUp) {
                                            CircularProgressIndicator(color = Color.White, modifier = Modifier.size(16.dp))
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text(t("settings.backing_up"))
                                        } else {
                                            Icon(Icons.Default.CloudUpload, contentDescription = null, modifier = Modifier.size(16.dp))
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text(t("settings.backup_now"), fontWeight = FontWeight.Bold)
                                        }
                                    }

                                    // Restore Backup
                                    OutlinedButton(
                                        onClick = {
                                            isLoadingBackups = true
                                            showRestoreDialog = true
                                            coroutineScope.launch {
                                                val res = backupManager.listAvailableBackups()
                                                isLoadingBackups = false
                                                if (res.isSuccess) {
                                                    availableBackups = res.getOrThrow()
                                                } else {
                                                    snackbarHostState.showSnackbar("Failed to fetch backups: ${res.exceptionOrNull()?.message}")
                                                }
                                            }
                                        },
                                        enabled = !isBackingUp && !isRestoring,
                                        modifier = Modifier
                                            .weight(1f)
                                            .testTag("restore_backup_btn")
                                    ) {
                                        Icon(Icons.Default.CloudDownload, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(t("settings.restore_backup"))
                                    }
                                }

                                OutlinedButton(
                                    onClick = {
                                        coroutineScope.launch {
                                            authManager.disconnect()
                                            snackbarHostState.showSnackbar("Disconnected from Google Drive")
                                        }
                                    },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("disconnect_google_drive_btn"),
                                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.DarkGray)
                                ) {
                                    Icon(Icons.Default.LinkOff, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(t("settings.disconnect_drive"))
                                }
                            }
                        }
                    }
                }
            }

            // ==========================================
            // BACKUP HISTORY LOGS
            // ==========================================
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "Local Backup Log (${backupLogs.size})",
                                fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.titleMedium
                            )
                        }

                        if (backupLogs.isEmpty()) {
                            Text(
                                text = "No backups recorded yet.",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color.Gray,
                                modifier = Modifier.padding(vertical = 12.dp)
                            )
                        } else {
                            Column(
                                modifier = Modifier.padding(top = 10.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                backupLogs.take(5).forEach { log ->
                                    BackupLogItemRow(log = log, dateFormat = dateFormat)
                                }
                            }
                        }
                    }
                }
            }

            // ==========================================
            // FARM ACCOUNT & SUPABASE SESSION
            // ==========================================
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "Farm Cloud Sync (Supabase)",
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.titleMedium
                        )
                        Text(
                            text = "Logged in as ${config.userEmail ?: "Local Field User"}",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color.Gray,
                            modifier = Modifier.padding(vertical = 4.dp)
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        Button(
                            onClick = onSignOut,
                            colors = ButtonDefaults.buttonColors(containerColor = FarmError),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("settings_sign_out_btn")
                        ) {
                            Icon(Icons.Default.Logout, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Sign Out of Farm", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            item { Spacer(modifier = Modifier.height(24.dp)) }
        }
    }

    // ==========================================
    // RESTORE BACKUP DIALOG
    // ==========================================
    if (showRestoreDialog) {
        AlertDialog(
            onDismissRequest = {
                if (!isRestoring) showRestoreDialog = false
            },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.CloudDownload, contentDescription = null, tint = FarmGreenDark)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Select Backup to Restore", fontWeight = FontWeight.Bold)
                }
            },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 420.dp)
                ) {
                    Text(
                        text = "Backups found in Google Drive / Goat Farm Manager / Backups:",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.DarkGray,
                        modifier = Modifier.padding(bottom = 10.dp)
                    )

                    if (isLoadingBackups) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(32.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                CircularProgressIndicator(color = FarmGreenDark)
                                Spacer(modifier = Modifier.height(8.dp))
                                Text("Fetching backups from Google Drive...", fontSize = 12.sp)
                            }
                        }
                    } else if (availableBackups.isEmpty()) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(32.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("No backup files found in Google Drive.", style = MaterialTheme.typography.bodyMedium, color = Color.Gray)
                        }
                    } else {
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(availableBackups, key = { it.id }) { backupFile ->
                                val isSelected = selectedBackupForRestore?.id == backupFile.id
                                Card(
                                    colors = CardDefaults.cardColors(
                                        containerColor = if (isSelected) FarmGreenContainer else Color(0xFFF9F9F9)
                                    ),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { selectedBackupForRestore = backupFile }
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(12.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = backupFile.name,
                                                fontWeight = FontWeight.SemiBold,
                                                style = MaterialTheme.typography.bodyMedium,
                                                maxLines = 1
                                            )
                                            Row(
                                                modifier = Modifier.padding(top = 2.dp),
                                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                                            ) {
                                                Text(
                                                    text = "Size: ${backupFile.sizeBytes / 1024} KB",
                                                    style = MaterialTheme.typography.labelSmall,
                                                    color = Color.Gray
                                                )
                                                Text(
                                                    text = backupFile.createdTime.take(16).replace("T", " "),
                                                    style = MaterialTheme.typography.labelSmall,
                                                    color = Color.Gray
                                                )
                                            }
                                        }

                                        RadioButton(
                                            selected = isSelected,
                                            onClick = { selectedBackupForRestore = backupFile }
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (selectedBackupForRestore != null) {
                            showConfirmRestoreAlert = true
                        }
                    },
                    enabled = selectedBackupForRestore != null && !isRestoring,
                    colors = ButtonDefaults.buttonColors(containerColor = FarmGreenDark),
                    modifier = Modifier.testTag("proceed_restore_dialog_btn")
                ) {
                    Text("Restore Selected")
                }
            },
            dismissButton = {
                TextButton(onClick = { showRestoreDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    // ==========================================
    // CONFIRM RESTORE SAFETY WARNING
    // ==========================================
    if (showConfirmRestoreAlert && selectedBackupForRestore != null) {
        val target = selectedBackupForRestore!!
        AlertDialog(
            onDismissRequest = {
                if (!isRestoring) showConfirmRestoreAlert = false
            },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Warning, contentDescription = null, tint = FarmError)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Confirm Restore", color = FarmError, fontWeight = FontWeight.Bold)
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Restoring will replace the current local farm database with:",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Text(
                        text = target.name,
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.bodyMedium,
                        color = FarmGreenDark
                    )
                    Card(
                        colors = CardDefaults.cardColors(containerColor = FarmAmberContainer),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(
                            text = "SAFETY GUARANTEE: A safety snapshot of your current local farm records will be saved automatically before restoration.",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.SemiBold,
                            color = FarmBrown,
                            modifier = Modifier.padding(8.dp)
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        showConfirmRestoreAlert = false
                        showRestoreDialog = false
                        coroutineScope.launch {
                            val res = backupManager.restoreBackup(target.id)
                            if (res.isSuccess) {
                                snackbarHostState.showSnackbar("Farm data restored successfully from Google Drive!")
                            } else {
                                snackbarHostState.showSnackbar("Restore failed: ${res.exceptionOrNull()?.message}")
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = FarmError),
                    modifier = Modifier.testTag("confirm_restore_final_btn")
                ) {
                    if (isRestoring) {
                        CircularProgressIndicator(color = Color.White, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Restoring...")
                    } else {
                        Text("Confirm & Overwrite", fontWeight = FontWeight.Bold)
                    }
                }
            },
            dismissButton = {
                TextButton(onClick = { showConfirmRestoreAlert = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    // ==========================================
    // LOCAL DEVICE RESTORE DIALOGS
    // ==========================================
    if (showLocalRestoreDialog) {
        AlertDialog(
            onDismissRequest = { showLocalRestoreDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Restore, contentDescription = null, tint = FarmGreenDark)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Select Local Backup", fontWeight = FontWeight.Bold)
                }
            },
            text = {
                if (localBackupsList.isEmpty()) {
                    Text("No local backup files found on device storage.\nCreate a backup first using 'BACKUP NOW'.")
                } else {
                    LazyColumn(
                        modifier = Modifier.heightIn(max = 350.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(localBackupsList) { backup ->
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = if (selectedLocalBackupForRestore == backup) FarmGreenContainer else Color(0xFFF5F5F5),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        selectedLocalBackupForRestore = backup
                                    }
                            ) {
                                Column(modifier = Modifier.padding(10.dp)) {
                                    Text(backup.fileName, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = FarmGreenDark)
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text("Date: ${backup.formattedDate}", fontSize = 11.sp, color = Color.DarkGray)
                                        Text("Size: ${backup.formattedSize}", fontSize = 11.sp, color = Color.DarkGray)
                                    }
                                    Text("${backup.recordCount} records • SHA-256 Verified", fontSize = 10.sp, color = FarmSuccess, fontWeight = FontWeight.SemiBold)
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                if (selectedLocalBackupForRestore != null) {
                    Button(
                        onClick = {
                            showLocalRestoreDialog = false
                            showConfirmLocalRestoreAlert = true
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = FarmGreenDark)
                    ) {
                        Text("Next")
                    }
                }
            },
            dismissButton = {
                TextButton(onClick = { showLocalRestoreDialog = false }) {
                    Text("Close")
                }
            }
        )
    }

    if (showConfirmLocalRestoreAlert && selectedLocalBackupForRestore != null) {
        val b = selectedLocalBackupForRestore!!
        AlertDialog(
            onDismissRequest = { showConfirmLocalRestoreAlert = false },
            title = { Text("Restore this backup?", fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    Text("Selected Backup Details:", fontWeight = FontWeight.SemiBold)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text("• BACKUP DATE: ${b.formattedDate}")
                    Text("• APP VERSION: 1.0.0")
                    Text("• BACKUP SIZE: ${b.formattedSize}")
                    Text("• RECORD COUNT: ${b.recordCount} records")
                    Text("• FILE: ${b.fileName}")
                    Spacer(modifier = Modifier.height(10.dp))
                    Text("A safety backup of your current local data will be created automatically before restoring.", color = FarmBrown, fontSize = 12.sp)
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        showConfirmLocalRestoreAlert = false
                        coroutineScope.launch {
                            val res = backupManager.restoreLocalDeviceBackup(b.file)
                            if (res.isSuccess) {
                                snackbarHostState.showSnackbar("RESTORE COMPLETED. Data successfully restored.")
                            } else {
                                snackbarHostState.showSnackbar("RESTORE FAILED: ${res.exceptionOrNull()?.message}")
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = FarmGreenDark)
                ) {
                    Text("RESTORE", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showConfirmLocalRestoreAlert = false }) {
                    Text("CANCEL")
                }
            }
        )
    }
}

@Composable
fun BackupInfoRow(
    label: String,
    value: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    valueColor: Color = Color.Black
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = Color.Gray,
                modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = label,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Text(
            text = value,
            fontWeight = FontWeight.SemiBold,
            style = MaterialTheme.typography.bodyMedium,
            color = valueColor
        )
    }
}

@Composable
fun BackupLogItemRow(log: BackupLogEntity, dateFormat: SimpleDateFormat) {
    val dateStr = dateFormat.format(Date(log.startedAt))
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFFF7F7F7), RoundedCornerShape(8.dp))
            .padding(10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(
                    shape = RoundedCornerShape(4.dp),
                    color = when (log.status) {
                        "SUCCESS" -> FarmGreenContainer
                        "FAILED" -> FarmErrorContainer
                        else -> Color(0xFFE1F5FE)
                    }
                ) {
                    Text(
                        text = log.status,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = when (log.status) {
                            "SUCCESS" -> FarmGreenDark
                            "FAILED" -> FarmError
                            else -> Color(0xFF0277BD)
                        },
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = dateStr,
                    style = MaterialTheme.typography.bodySmall,
                    fontWeight = FontWeight.Medium
                )
            }

            if (!log.errorMessage.isNullOrBlank()) {
                Text(
                    text = log.errorMessage,
                    style = MaterialTheme.typography.labelSmall,
                    color = FarmError,
                    maxLines = 1,
                    modifier = Modifier.padding(top = 2.dp)
                )
            } else if (log.recordCount > 0) {
                Text(
                    text = "${log.recordCount} records • ${log.fileSize / 1024} KB",
                    style = MaterialTheme.typography.labelSmall,
                    color = Color.Gray,
                    modifier = Modifier.padding(top = 2.dp)
                )
            }
        }
    }
}

@Composable
private fun VaccinationNotificationSettingsCard(
    repository: GoatRepository,
    snackbarHostState: SnackbarHostState
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    var isEnabled by remember { mutableStateOf(true) }
    var lastCheckedStr by remember { mutableStateOf<String?>(null) }
    var lastAlertCount by remember { mutableStateOf<Int?>(null) }

    LaunchedEffect(Unit) {
        val enabledSetting = repository.getFarmSetting("vaccination_notifications_enabled")
        isEnabled = enabledSetting != "false"
        val lastCheckedMillis = repository.getFarmSetting("last_vaccination_check_time")?.toLongOrNull()
        if (lastCheckedMillis != null && lastCheckedMillis > 0) {
            val sdf = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault())
            lastCheckedStr = sdf.format(Date(lastCheckedMillis))
        }
        lastAlertCount = repository.getFarmSetting("last_vaccination_alert_count")?.toIntOrNull()
    }

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth().testTag("vaccination_notification_settings_card")
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(Color(0xFFE0F2FE)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.NotificationsActive,
                            contentDescription = null,
                            tint = Color(0xFF0284C7),
                            modifier = Modifier.size(22.dp)
                        )
                    }
                    Column {
                        Text(
                            text = "Vaccination Reminders",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = FarmGreenDark
                        )
                        Text(
                            text = "Recurring alerts for upcoming & overdue vaccines",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color.Gray
                        )
                    }
                }

                Switch(
                    checked = isEnabled,
                    onCheckedChange = { checked ->
                        isEnabled = checked
                        coroutineScope.launch {
                            repository.saveFarmSetting("vaccination_notifications_enabled", checked.toString())
                            if (checked) {
                                com.example.notification.VaccinationReminderScheduler.scheduleDaily(context)
                                snackbarHostState.showSnackbar("Vaccination reminders enabled (Daily check scheduled)")
                            } else {
                                com.example.notification.VaccinationReminderScheduler.cancel(context)
                                snackbarHostState.showSnackbar("Vaccination reminders disabled")
                            }
                        }
                    },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = Color.White,
                        checkedTrackColor = FarmGreenDark
                    ),
                    modifier = Modifier.testTag("switch_vaccination_notifications")
                )
            }

            HorizontalDivider(color = Color(0xFFF1F5F9))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Schedule: Daily Recurring Scan",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Color(0xFF334155)
                    )
                    Text(
                        text = "Scans individual goat health records and alerts up to 7 days before due date.",
                        fontSize = 11.sp,
                        color = Color.Gray
                    )
                    if (lastCheckedStr != null) {
                        Text(
                            text = "Last scan: $lastCheckedStr ${lastAlertCount?.let { "($it due)" } ?: ""}",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium,
                            color = FarmGreenDark,
                            modifier = Modifier.padding(top = 2.dp)
                        )
                    }
                }

                Button(
                    onClick = {
                        com.example.notification.VaccinationReminderScheduler.triggerImmediateCheck(context)
                        coroutineScope.launch {
                            snackbarHostState.showSnackbar("Checking upcoming vaccination dates now...")
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7)),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                    modifier = Modifier.testTag("btn_test_vaccination_reminder")
                ) {
                    Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Check Now", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

