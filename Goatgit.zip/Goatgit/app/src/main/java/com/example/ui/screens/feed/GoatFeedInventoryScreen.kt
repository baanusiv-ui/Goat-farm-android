package com.example.ui.screens.feed

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.supabase.FeedItem
import com.example.data.supabase.FeedMovement
import com.example.data.supabase.GoatRepository
import com.example.ui.components.DatePickerField
import com.example.ui.theme.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

private val FeedCategories = listOf(
    "All",
    "Green Fodder",
    "Dry Fodder",
    "Concentrate",
    "Grains",
    "Supplements",
    "Silage"
)

private val CategoryColors = mapOf(
    "Green Fodder" to Color(0xFF16A34A),
    "Dry Fodder" to Color(0xFFD97706),
    "Concentrate" to Color(0xFF7C3AED),
    "Grains" to Color(0xFF2563EB),
    "Supplements" to Color(0xFF0D9488),
    "Silage" to Color(0xFF4F46E5)
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GoatFeedInventoryScreen(
    repository: GoatRepository,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val todayDateStr = remember { SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date()) }

    var selectedTab by remember { mutableIntStateOf(0) } // 0: Stock Levels, 1: Daily Usage Logs, 2: Analytics & Restock
    var selectedCategoryFilter by remember { mutableStateOf("All") }
    var searchQuery by remember { mutableStateOf("") }

    var feedList by remember { mutableStateOf<List<FeedItem>>(emptyList()) }
    var movementsList by remember { mutableStateOf<List<FeedMovement>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }

    // Dialog states
    var showAddFeedDialog by remember { mutableStateOf(false) }
    var showRecordUsageDialog by remember { mutableStateOf<FeedItem?>(null) }
    var showQuickUsageDialog by remember { mutableStateOf(false) }
    var showRestockDialog by remember { mutableStateOf<FeedItem?>(null) }
    var feedItemToDelete by remember { mutableStateOf<FeedItem?>(null) }

    fun refreshData() {
        isLoading = true
        coroutineScope.launch {
            val fRes = repository.getFeedInventory()
            if (fRes.isSuccess) feedList = fRes.getOrThrow()

            val mRes = repository.getFeedMovements()
            if (mRes.isSuccess) movementsList = mRes.getOrThrow()
            isLoading = false
        }
    }

    LaunchedEffect(Unit) {
        refreshData()
    }

    BackHandler {
        onNavigateBack()
    }

    // Calculations
    val totalStockKg = remember(feedList) { feedList.sumOf { it.current_stock_kg_c } }
    val lowStockItems = remember(feedList) {
        feedList.filter { it.current_stock_kg_c <= 25.0 }
    }
    val totalValuation = remember(feedList) {
        feedList.sumOf { (it.cost_per_unit_c ?: 0.0) * it.current_stock_kg_c }
    }
    val todayUsageKg = remember(movementsList, todayDateStr) {
        movementsList.filter { it.movement_type_c == "Consumption" && it.date_c == todayDateStr }
            .sumOf { it.quantity_c }
    }

    val filteredFeeds = remember(feedList, selectedCategoryFilter, searchQuery) {
        feedList.filter { feed ->
            val matchesCategory = selectedCategoryFilter == "All" ||
                    feed.category_c.equals(selectedCategoryFilter, ignoreCase = true)
            val matchesSearch = searchQuery.isBlank() ||
                    feed.name_c.contains(searchQuery, ignoreCase = true) ||
                    (feed.category_c?.contains(searchQuery, ignoreCase = true) == true)
            matchesCategory && matchesSearch
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "Feed Inventory & Daily Usage",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF1E293B)
                        )
                        Text(
                            text = "Stock tracking, intake logging & feed type manager",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFF64748B)
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color(0xFF1E293B))
                    }
                },
                actions = {
                    IconButton(onClick = { refreshData() }) {
                        Icon(Icons.Default.Refresh, contentDescription = "Refresh", tint = FarmGreenDark)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.White)
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = {
                    if (selectedTab == 1) {
                        showQuickUsageDialog = true
                    } else {
                        showAddFeedDialog = true
                    }
                },
                icon = {
                    Icon(
                        if (selectedTab == 1) Icons.Default.Restaurant else Icons.Default.Add,
                        contentDescription = null
                    )
                },
                text = {
                    Text(
                        if (selectedTab == 1) "Record Daily Usage" else "Add New Feed Type",
                        fontWeight = FontWeight.Bold
                    )
                },
                containerColor = FarmGreenPrimary,
                contentColor = Color.White,
                modifier = Modifier.testTag(if (selectedTab == 1) "fab_record_daily_usage" else "fab_add_feed_type")
            )
        }
    ) { padding ->
        Column(
            modifier = modifier
                .fillMaxSize()
                .background(Color(0xFFF8FAFC))
                .padding(padding)
        ) {
            // Summary KPI Strip
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                shape = RoundedCornerShape(14.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Total Stock
                    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.weight(1f)) {
                        Text("Total Stock", fontSize = 11.sp, color = Color(0xFF64748B), fontWeight = FontWeight.Medium)
                        Text(
                            "${String.format(Locale.US, "%.0f", totalStockKg)} kg",
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold,
                            color = FarmGreenDark
                        )
                    }
                    VerticalDivider(modifier = Modifier.height(30.dp), color = Color(0xFFE2E8F0))

                    // Daily Usage Today
                    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.weight(1f)) {
                        Text("Today's Usage", fontSize = 11.sp, color = Color(0xFF64748B), fontWeight = FontWeight.Medium)
                        Text(
                            "${String.format(Locale.US, "%.1f", todayUsageKg)} kg",
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFD97706)
                        )
                    }
                    VerticalDivider(modifier = Modifier.height(30.dp), color = Color(0xFFE2E8F0))

                    // Low Stock Alert
                    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.weight(1f)) {
                        Text("Low Stock", fontSize = 11.sp, color = Color(0xFF64748B), fontWeight = FontWeight.Medium)
                        Text(
                            "${lowStockItems.size} items",
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (lowStockItems.isNotEmpty()) Color(0xFFDC2626) else FarmGreenDark
                        )
                    }
                    VerticalDivider(modifier = Modifier.height(30.dp), color = Color(0xFFE2E8F0))

                    // Valuation
                    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.weight(1f)) {
                        Text("Inventory Val.", fontSize = 11.sp, color = Color(0xFF64748B), fontWeight = FontWeight.Medium)
                        Text(
                            "₹${String.format(Locale.US, "%.0f", totalValuation)}",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF2563EB)
                        )
                    }
                }
            }

            // Tabs
            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = Color.White,
                contentColor = FarmGreenDark,
                modifier = Modifier.fillMaxWidth()
            ) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = {
                        Text(
                            "Stock Levels (${feedList.size})",
                            fontWeight = if (selectedTab == 0) FontWeight.Bold else FontWeight.Normal,
                            fontSize = 13.sp
                        )
                    },
                    modifier = Modifier.testTag("feed_inventory_tab_stock")
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = {
                        Text(
                            "Daily Usage Logs (${movementsList.size})",
                            fontWeight = if (selectedTab == 1) FontWeight.Bold else FontWeight.Normal,
                            fontSize = 13.sp
                        )
                    },
                    modifier = Modifier.testTag("feed_inventory_tab_usage")
                )
                Tab(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    text = {
                        Text(
                            "Stock Alerts & Summary",
                            fontWeight = if (selectedTab == 2) FontWeight.Bold else FontWeight.Normal,
                            fontSize = 13.sp
                        )
                    },
                    modifier = Modifier.testTag("feed_inventory_tab_summary")
                )
            }

            if (isLoading) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = FarmGreenPrimary)
                }
            } else when (selectedTab) {
                0 -> {
                    // TAB 0: Stock Levels & Feed Items Management
                    StockLevelsTabContent(
                        feeds = filteredFeeds,
                        selectedCategory = selectedCategoryFilter,
                        onCategorySelect = { selectedCategoryFilter = it },
                        searchQuery = searchQuery,
                        onSearchChange = { searchQuery = it },
                        onAddNewFeed = { showAddFeedDialog = true },
                        onRecordUsage = { showRecordUsageDialog = it },
                        onRestock = { showRestockDialog = it },
                        onDeleteFeed = { feedItemToDelete = it }
                    )
                }
                1 -> {
                    // TAB 1: Daily Usage Logs Per Day
                    DailyUsageLogsTabContent(
                        movements = movementsList,
                        feedList = feedList,
                        todayDateStr = todayDateStr,
                        onRecordUsage = { showQuickUsageDialog = true },
                        onDeleteMovement = { mov ->
                            coroutineScope.launch {
                                val res = repository.deleteFeedMovement(mov.id)
                                if (res.isSuccess) {
                                    Toast.makeText(context, "Daily usage log deleted", Toast.LENGTH_SHORT).show()
                                    refreshData()
                                }
                            }
                        }
                    )
                }
                2 -> {
                    // TAB 2: Alerts, Low Stock Warnings & Category Breakdown
                    StockAlertsAndSummaryTabContent(
                        feedList = feedList,
                        movements = movementsList,
                        onRestock = { showRestockDialog = it },
                        onAddNewFeed = { showAddFeedDialog = true }
                    )
                }
            }
        }
    }

    // Dialog: Add New Feed Type
    if (showAddFeedDialog) {
        AddNewFeedTypeDialog(
            onDismiss = { showAddFeedDialog = false },
            onConfirm = { newFeed ->
                coroutineScope.launch {
                    val res = repository.saveFeedItem(newFeed)
                    if (res.isSuccess) {
                        Toast.makeText(context, "Added new feed type: ${newFeed.name_c}", Toast.LENGTH_SHORT).show()
                        showAddFeedDialog = false
                        refreshData()
                    } else {
                        Toast.makeText(context, "Failed to save feed: ${res.exceptionOrNull()?.message}", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        )
    }

    // Dialog: Record Usage for Specific Feed
    showRecordUsageDialog?.let { targetFeed ->
        RecordDailyFeedUsageDialog(
            feed = targetFeed,
            todayDateStr = todayDateStr,
            onDismiss = { showRecordUsageDialog = null },
            onConfirm = { qty, date, session, pen, notes ->
                coroutineScope.launch {
                    val fullNotes = buildString {
                        if (session.isNotBlank()) append("[$session] ")
                        if (pen.isNotBlank()) append("Target: $pen. ")
                        if (notes.isNotBlank()) append(notes)
                    }
                    val movement = FeedMovement(
                        feed_id_c = targetFeed.id,
                        movement_type_c = "Consumption",
                        quantity_c = qty,
                        date_c = date,
                        notes_c = fullNotes.ifBlank { null }
                    )
                    val res = repository.addFeedMovement(movement)
                    if (res.isSuccess) {
                        Toast.makeText(context, "Recorded $qty ${targetFeed.unit_c} usage on $date", Toast.LENGTH_SHORT).show()
                        showRecordUsageDialog = null
                        refreshData()
                    } else {
                        Toast.makeText(context, "Failed to record usage", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        )
    }

    // Dialog: Quick Usage (Any Feed)
    if (showQuickUsageDialog) {
        QuickDailyFeedUsageDialog(
            allFeeds = feedList,
            todayDateStr = todayDateStr,
            onDismiss = { showQuickUsageDialog = false },
            onConfirm = { feed, qty, date, session, pen, notes ->
                coroutineScope.launch {
                    val fullNotes = buildString {
                        if (session.isNotBlank()) append("[$session] ")
                        if (pen.isNotBlank()) append("Target: $pen. ")
                        if (notes.isNotBlank()) append(notes)
                    }
                    val movement = FeedMovement(
                        feed_id_c = feed.id,
                        movement_type_c = "Consumption",
                        quantity_c = qty,
                        date_c = date,
                        notes_c = fullNotes.ifBlank { null }
                    )
                    val res = repository.addFeedMovement(movement)
                    if (res.isSuccess) {
                        Toast.makeText(context, "Logged $qty ${feed.unit_c} feed usage for $date", Toast.LENGTH_SHORT).show()
                        showQuickUsageDialog = false
                        refreshData()
                    } else {
                        Toast.makeText(context, "Failed to record usage", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        )
    }

    // Dialog: Restock / Purchase
    showRestockDialog?.let { targetFeed ->
        RestockFeedDialog(
            feed = targetFeed,
            todayDateStr = todayDateStr,
            onDismiss = { showRestockDialog = null },
            onConfirm = { qty, date, costPerUnit, notes ->
                coroutineScope.launch {
                    val movement = FeedMovement(
                        feed_id_c = targetFeed.id,
                        movement_type_c = "Purchase",
                        quantity_c = qty,
                        date_c = date,
                        notes_c = "Purchased/Restocked @ ₹$costPerUnit/${targetFeed.unit_c}. $notes"
                    )
                    val res = repository.addFeedMovement(movement)
                    if (costPerUnit != null) {
                        repository.saveFeedItem(targetFeed.copy(cost_per_unit_c = costPerUnit))
                    }
                    if (res.isSuccess) {
                        Toast.makeText(context, "Restocked +$qty ${targetFeed.unit_c}", Toast.LENGTH_SHORT).show()
                        showRestockDialog = null
                        refreshData()
                    }
                }
            }
        )
    }

    // Dialog: Delete confirmation
    feedItemToDelete?.let { feed ->
        AlertDialog(
            onDismissRequest = { feedItemToDelete = null },
            icon = { Icon(Icons.Default.DeleteOutline, contentDescription = null, tint = Color(0xFFDC2626)) },
            title = { Text("Delete Feed Type?", fontWeight = FontWeight.Bold) },
            text = { Text("Are you sure you want to delete '${feed.name_c}'? This removes it from current inventory.") },
            confirmButton = {
                Button(
                    onClick = {
                        coroutineScope.launch {
                            val res = repository.deleteFeedItem(feed.id)
                            if (res.isSuccess) {
                                Toast.makeText(context, "Feed removed", Toast.LENGTH_SHORT).show()
                                feedItemToDelete = null
                                refreshData()
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626))
                ) {
                    Text("Delete", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { feedItemToDelete = null }) {
                    Text("Cancel")
                }
            }
        )
    }
}

// -------------------------------------------------------------
// SUB-TAB 0: Stock Levels & Feed Items Management
// -------------------------------------------------------------
@Composable
private fun StockLevelsTabContent(
    feeds: List<FeedItem>,
    selectedCategory: String,
    onCategorySelect: (String) -> Unit,
    searchQuery: String,
    onSearchChange: (String) -> Unit,
    onAddNewFeed: () -> Unit,
    onRecordUsage: (FeedItem) -> Unit,
    onRestock: (FeedItem) -> Unit,
    onDeleteFeed: (FeedItem) -> Unit
) {
    Column(modifier = Modifier.fillMaxSize()) {
        // Search & Category Filters
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color.White)
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = onSearchChange,
                placeholder = { Text("Search feed types...", fontSize = 13.sp) },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = Color.Gray) },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { onSearchChange("") }) {
                            Icon(Icons.Default.Close, contentDescription = "Clear", tint = Color.Gray)
                        }
                    }
                },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("feed_search_input"),
                shape = RoundedCornerShape(10.dp)
            )

            // Category Chips
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                FeedCategories.forEach { cat ->
                    val isSelected = selectedCategory == cat
                    FilterChip(
                        selected = isSelected,
                        onClick = { onCategorySelect(cat) },
                        label = { Text(cat, fontSize = 12.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = FarmGreenPrimary,
                            selectedLabelColor = Color.White
                        )
                    )
                }
            }
        }

        // Feed List
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (feeds.isEmpty()) {
                item {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 24.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(32.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(Icons.Default.Grass, contentDescription = null, modifier = Modifier.size(48.dp), tint = Color.LightGray)
                            Spacer(modifier = Modifier.height(10.dp))
                            Text("No feed types found", fontWeight = FontWeight.Bold, color = Color.Gray)
                            Text("Click '+ Add New Feed Type' to create a feed inventory item.", fontSize = 12.sp, color = Color.Gray)
                            Spacer(modifier = Modifier.height(16.dp))
                            Button(
                                onClick = onAddNewFeed,
                                colors = ButtonDefaults.buttonColors(containerColor = FarmGreenPrimary),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Icon(Icons.Default.Add, contentDescription = null)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Add Feed Type")
                            }
                        }
                    }
                }
            } else {
                items(feeds, key = { it.id }) { feed ->
                    FeedStockCard(
                        feed = feed,
                        onRecordUsage = { onRecordUsage(feed) },
                        onRestock = { onRestock(feed) },
                        onDelete = { onDeleteFeed(feed) }
                    )
                }
            }

            item {
                Spacer(modifier = Modifier.height(80.dp)) // Space for FAB
            }
        }
    }
}

@Composable
private fun FeedStockCard(
    feed: FeedItem,
    onRecordUsage: () -> Unit,
    onRestock: () -> Unit,
    onDelete: () -> Unit
) {
    val isCritical = feed.current_stock_kg_c <= 10.0
    val isLow = feed.current_stock_kg_c in 10.1..30.0
    val categoryColor = CategoryColors[feed.category_c] ?: FarmGreenDark

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("feed_card_${feed.id}"),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        shape = RoundedCornerShape(14.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            // Header: Category Pill, Name, and Status Badge
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Surface(
                        color = categoryColor.copy(alpha = 0.12f),
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text(
                            text = feed.category_c ?: "Feed",
                            color = categoryColor,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                        )
                    }

                    if (isCritical) {
                        Surface(
                            color = Color(0xFFFEE2E2),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                "CRITICAL LOW",
                                color = Color(0xFFDC2626),
                                fontWeight = FontWeight.Bold,
                                fontSize = 10.sp,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    } else if (isLow) {
                        Surface(
                            color = Color(0xFFFEF3C7),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                "LOW STOCK",
                                color = Color(0xFFD97706),
                                fontWeight = FontWeight.Bold,
                                fontSize = 10.sp,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                }

                IconButton(onClick = onDelete, modifier = Modifier.size(28.dp)) {
                    Icon(Icons.Default.DeleteOutline, contentDescription = "Delete", tint = Color.LightGray, modifier = Modifier.size(18.dp))
                }
            }

            // Feed Name & Metrics
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Bottom
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = feed.name_c,
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleMedium,
                        color = Color(0xFF1E293B)
                    )
                    if (feed.cost_per_unit_c != null) {
                        Text(
                            text = "Unit Cost: ₹${feed.cost_per_unit_c}/${feed.unit_c}",
                            fontSize = 12.sp,
                            color = Color(0xFF64748B)
                        )
                    }
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = "${String.format(Locale.US, "%.1f", feed.current_stock_kg_c)} ${feed.unit_c}",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = when {
                            isCritical -> Color(0xFFDC2626)
                            isLow -> Color(0xFFD97706)
                            else -> FarmGreenDark
                        }
                    )
                    Text("Current Stock", fontSize = 10.sp, color = Color(0xFF64748B))
                }
            }

            // Stock Bar Visual Indicator (relative to 100kg baseline or stock level)
            val maxRef = (feed.current_stock_kg_c * 1.5).coerceAtLeast(100.0)
            val progress = (feed.current_stock_kg_c / maxRef).coerceIn(0.0, 1.0).toFloat()
            LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(6.dp)
                    .clip(RoundedCornerShape(3.dp)),
                color = when {
                    isCritical -> Color(0xFFDC2626)
                    isLow -> Color(0xFFD97706)
                    else -> FarmGreenPrimary
                },
                trackColor = Color(0xFFF1F5F9)
            )

            // Action Buttons: "Record Usage per Day" and "Restock / Add Stock"
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = onRestock,
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(8.dp),
                    border = BorderStroke(1.dp, Color(0xFFCBD5E1))
                ) {
                    Icon(Icons.Default.AddShoppingCart, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Restock", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFF475569))
                }

                Button(
                    onClick = onRecordUsage,
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = FarmGreenContainer, contentColor = FarmOnGreenContainer)
                ) {
                    Icon(Icons.Default.Restaurant, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Record Usage", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

// -------------------------------------------------------------
// SUB-TAB 1: Daily Usage Logs Per Day
// -------------------------------------------------------------
@Composable
private fun DailyUsageLogsTabContent(
    movements: List<FeedMovement>,
    feedList: List<FeedItem>,
    todayDateStr: String,
    onRecordUsage: () -> Unit,
    onDeleteMovement: (FeedMovement) -> Unit
) {
    val feedMap = remember(feedList) { feedList.associateBy { it.id } }
    val consumptionMovements = remember(movements) {
        movements.filter { it.movement_type_c == "Consumption" }
            .sortedByDescending { it.date_c }
    }

    // Group movements by date
    val groupedByDate = remember(consumptionMovements) {
        consumptionMovements.groupBy { it.date_c }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Daily Quick Action Banner
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = FarmGreenContainer),
                shape = RoundedCornerShape(12.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Log Daily Herd Feeding", fontWeight = FontWeight.Bold, color = FarmOnGreenContainer)
                        Text(
                            "Record feed ration consumption per day to track herd intake and decrement stock accurately.",
                            fontSize = 11.sp,
                            color = FarmGreenDark
                        )
                    }
                    Button(
                        onClick = onRecordUsage,
                        colors = ButtonDefaults.buttonColors(containerColor = FarmGreenPrimary),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("Log Today", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        if (groupedByDate.isEmpty()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth().padding(top = 16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(
                        modifier = Modifier.fillMaxWidth().padding(32.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(Icons.Default.EventNote, contentDescription = null, modifier = Modifier.size(48.dp), tint = Color.LightGray)
                        Spacer(modifier = Modifier.height(10.dp))
                        Text("No daily feed usage logged yet.", fontWeight = FontWeight.Bold, color = Color.Gray)
                        Text("Click 'Log Today' to record daily feed consumption per pen or herd.", fontSize = 12.sp, color = Color.Gray)
                    }
                }
            }
        } else {
            groupedByDate.forEach { (date, logs) ->
                val dayTotalKg = logs.sumOf { it.quantity_c }
                val isToday = date == todayDateStr

                item {
                    // Date Header Strip
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Icon(Icons.Default.CalendarToday, contentDescription = null, modifier = Modifier.size(16.dp), tint = FarmGreenDark)
                            Text(
                                text = if (isToday) "Today ($date)" else date,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = if (isToday) FarmGreenDark else Color(0xFF1E293B)
                            )
                        }
                        Surface(
                            color = Color(0xFFEFF6FF),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                "Total: ${String.format(Locale.US, "%.1f", dayTotalKg)} kg",
                                color = Color(0xFF2563EB),
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                            )
                        }
                    }
                }

                items(logs, key = { it.id }) { log ->
                    val feed = feedMap[log.feed_id_c]
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = feed?.name_c ?: "Feed Item",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    color = Color(0xFF1E293B)
                                )
                                Text(
                                    text = feed?.category_c ?: "Feed",
                                    fontSize = 11.sp,
                                    color = Color(0xFF64748B)
                                )
                                if (!log.notes_c.isNullOrBlank()) {
                                    Text(
                                        text = log.notes_c,
                                        fontSize = 12.sp,
                                        color = Color(0xFF475569),
                                        modifier = Modifier.padding(top = 2.dp)
                                    )
                                }
                            }

                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Surface(
                                    color = Color(0xFFFEF3C7),
                                    shape = RoundedCornerShape(6.dp)
                                ) {
                                    Text(
                                        "-${log.quantity_c} ${feed?.unit_c ?: "kg"}",
                                        fontWeight = FontWeight.ExtraBold,
                                        color = Color(0xFFB45309),
                                        fontSize = 13.sp,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    )
                                }

                                IconButton(onClick = { onDeleteMovement(log) }, modifier = Modifier.size(24.dp)) {
                                    Icon(Icons.Default.Close, contentDescription = "Remove", tint = Color.LightGray, modifier = Modifier.size(16.dp))
                                }
                            }
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(80.dp))
        }
    }
}

// -------------------------------------------------------------
// SUB-TAB 2: Stock Alerts & Summary
// -------------------------------------------------------------
@Composable
private fun StockAlertsAndSummaryTabContent(
    feedList: List<FeedItem>,
    movements: List<FeedMovement>,
    onRestock: (FeedItem) -> Unit,
    onAddNewFeed: () -> Unit
) {
    val lowStockFeeds = remember(feedList) { feedList.filter { it.current_stock_kg_c <= 30.0 } }
    val categoryTotals = remember(feedList) {
        feedList.groupBy { it.category_c ?: "Other" }
            .mapValues { entry -> entry.value.sumOf { it.current_stock_kg_c } }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Critical / Low Stock Alert Section
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(14.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Icon(Icons.Default.WarningAmber, contentDescription = null, tint = Color(0xFFDC2626))
                            Text("Reorder & Depletion Alerts", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        }
                        Text("${lowStockFeeds.size} Need Action", fontSize = 11.sp, color = Color(0xFFDC2626), fontWeight = FontWeight.Bold)
                    }

                    if (lowStockFeeds.isEmpty()) {
                        Text(
                            "All feed categories are currently above safe threshold levels (>30 kg).",
                            fontSize = 12.sp,
                            color = FarmGreenDark
                        )
                    } else {
                        lowStockFeeds.forEach { feed ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(Color(0xFFFFF1F2), RoundedCornerShape(8.dp))
                                    .padding(10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(feed.name_c, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color(0xFF991B1B))
                                    Text("Current: ${feed.current_stock_kg_c} ${feed.unit_c}", fontSize = 11.sp, color = Color(0xFFB91C1C))
                                }
                                Button(
                                    onClick = { onRestock(feed) },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626)),
                                    shape = RoundedCornerShape(6.dp),
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                                ) {
                                    Text("Reorder", fontSize = 11.sp, color = Color.White)
                                }
                            }
                        }
                    }
                }
            }
        }

        // Inventory Breakdown by Feed Category
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(14.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Stock Distribution by Feed Category", fontWeight = FontWeight.Bold, fontSize = 15.sp)

                    categoryTotals.forEach { (cat, totalKg) ->
                        val color = CategoryColors[cat] ?: FarmGreenDark
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(cat, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                                Text("${String.format(Locale.US, "%.1f", totalKg)} kg", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = color)
                            }
                            LinearProgressIndicator(
                                progress = { (totalKg / (feedList.sumOf { it.current_stock_kg_c }.takeIf { it > 0.0 } ?: 1.0)).toFloat().coerceIn(0f, 1f) },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(6.dp)
                                    .clip(RoundedCornerShape(3.dp)),
                                color = color,
                                trackColor = Color(0xFFF1F5F9)
                            )
                        }
                    }
                }
            }
        }

        // Quick Action Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFF8FAFC)),
                border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text("Need to introduce a new feeding crop or mineral?", fontSize = 13.sp, color = Color(0xFF475569))
                    Button(
                        onClick = onAddNewFeed,
                        colors = ButtonDefaults.buttonColors(containerColor = FarmGreenPrimary),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Add New Feed Type", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(80.dp))
        }
    }
}

// -------------------------------------------------------------
// DIALOG 1: Add New Feed Type
// -------------------------------------------------------------
@Composable
private fun AddNewFeedTypeDialog(
    onDismiss: () -> Unit,
    onConfirm: (FeedItem) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("Concentrate") }
    var initialStockStr by remember { mutableStateOf("50.0") }
    var unitStr by remember { mutableStateOf("kg") }
    var unitCostStr by remember { mutableStateOf("25.0") }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    val categories = listOf("Green Fodder", "Dry Fodder", "Concentrate", "Grains", "Supplements", "Silage")

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(Icons.Default.Grass, contentDescription = null, tint = FarmGreenDark)
                Text("Add New Feed Type", fontWeight = FontWeight.Bold)
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("dialog_add_feed_type"),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Feed Name *") },
                    placeholder = { Text("e.g. Alfalfa Hay, Grower Pellets") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_feed_name")
                )

                // Category selector
                Text("Category *", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFF475569))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    categories.forEach { cat ->
                        FilterChip(
                            selected = selectedCategory == cat,
                            onClick = { selectedCategory = cat },
                            label = { Text(cat, fontSize = 11.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = FarmGreenPrimary,
                                selectedLabelColor = Color.White
                            )
                        )
                    }
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = initialStockStr,
                        onValueChange = { initialStockStr = it },
                        label = { Text("Initial Stock *") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("input_feed_initial_stock")
                    )

                    OutlinedTextField(
                        value = unitStr,
                        onValueChange = { unitStr = it },
                        label = { Text("Unit") },
                        singleLine = true,
                        modifier = Modifier
                            .width(80.dp)
                            .testTag("input_feed_unit")
                    )
                }

                OutlinedTextField(
                    value = unitCostStr,
                    onValueChange = { unitCostStr = it },
                    label = { Text("Cost per $unitStr (₹)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_feed_unit_cost")
                )

                if (errorMessage != null) {
                    Text(errorMessage ?: "", color = Color(0xFFDC2626), fontSize = 12.sp)
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (name.isBlank()) {
                        errorMessage = "Please enter feed name."
                        return@Button
                    }
                    val stock = initialStockStr.toDoubleOrNull()
                    if (stock == null || stock < 0) {
                        errorMessage = "Please enter valid stock amount."
                        return@Button
                    }
                    val cost = unitCostStr.toDoubleOrNull()
                    val newFeed = FeedItem(
                        name_c = name.trim(),
                        category_c = selectedCategory,
                        current_stock_kg_c = stock,
                        unit_c = unitStr.ifBlank { "kg" },
                        cost_per_unit_c = cost
                    )
                    onConfirm(newFeed)
                },
                colors = ButtonDefaults.buttonColors(containerColor = FarmGreenPrimary),
                modifier = Modifier.testTag("btn_confirm_add_feed")
            ) {
                Text("Add Feed Type", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

// -------------------------------------------------------------
// DIALOG 2: Record Daily Usage (Specific Feed)
// -------------------------------------------------------------
@Composable
private fun RecordDailyFeedUsageDialog(
    feed: FeedItem,
    todayDateStr: String,
    onDismiss: () -> Unit,
    onConfirm: (quantity: Double, date: String, session: String, pen: String, notes: String) -> Unit
) {
    var quantityStr by remember { mutableStateOf("15.0") }
    var dateStr by remember { mutableStateOf(todayDateStr) }
    var selectedSession by remember { mutableStateOf("Morning") }
    var targetGroup by remember { mutableStateOf("Entire Herd") }
    var notes by remember { mutableStateOf("") }
    var errorMsg by remember { mutableStateOf<String?>(null) }

    val sessions = listOf("Morning", "Afternoon", "Evening", "Night")
    val groups = listOf("Entire Herd", "Does in Milk", "Pregnant Does", "Growing Kids", "Bucks", "Pen A", "Pen B")

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Column {
                Text("Record Daily Usage", fontWeight = FontWeight.Bold)
                Text(
                    "${feed.name_c} • Current Stock: ${feed.current_stock_kg_c} ${feed.unit_c}",
                    fontSize = 12.sp,
                    color = FarmGreenDark
                )
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("dialog_record_feed_usage"),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                DatePickerField(
                    dateValue = dateStr,
                    onDateSelected = { dateStr = it },
                    label = "Feeding Date"
                )

                OutlinedTextField(
                    value = quantityStr,
                    onValueChange = { quantityStr = it },
                    label = { Text("Quantity Consumed (${feed.unit_c}) *") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_usage_quantity")
                )

                // Quick Increment Chips
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("5.0", "10.0", "20.0", "30.0").forEach { q ->
                        AssistChip(
                            onClick = { quantityStr = q },
                            label = { Text("+$q", fontSize = 11.sp) }
                        )
                    }
                }

                Text("Feeding Shift / Session", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFF475569))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    sessions.forEach { s ->
                        FilterChip(
                            selected = selectedSession == s,
                            onClick = { selectedSession = s },
                            label = { Text(s, fontSize = 10.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = FarmGreenPrimary,
                                selectedLabelColor = Color.White
                            )
                        )
                    }
                }

                Text("Target Herd / Pen", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFF475569))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    groups.forEach { g ->
                        FilterChip(
                            selected = targetGroup == g,
                            onClick = { targetGroup = g },
                            label = { Text(g, fontSize = 10.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = Color(0xFF2563EB),
                                selectedLabelColor = Color.White
                            )
                        )
                    }
                }

                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Notes / Observations") },
                    placeholder = { Text("e.g. Mixed with 50g mineral premix") },
                    modifier = Modifier.fillMaxWidth()
                )

                if (errorMsg != null) {
                    Text(errorMsg ?: "", color = Color(0xFFDC2626), fontSize = 12.sp)
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val q = quantityStr.toDoubleOrNull()
                    if (q == null || q <= 0.0) {
                        errorMsg = "Please enter valid quantity."
                        return@Button
                    }
                    if (q > feed.current_stock_kg_c) {
                        errorMsg = "Quantity ($q) exceeds available stock (${feed.current_stock_kg_c})."
                        return@Button
                    }
                    onConfirm(q, dateStr, selectedSession, targetGroup, notes)
                },
                colors = ButtonDefaults.buttonColors(containerColor = FarmGreenPrimary),
                modifier = Modifier.testTag("btn_confirm_record_usage")
            ) {
                Text("Save Usage Log", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

// -------------------------------------------------------------
// DIALOG 3: Quick Daily Usage (Select Feed from list)
// -------------------------------------------------------------
@Composable
private fun QuickDailyFeedUsageDialog(
    allFeeds: List<FeedItem>,
    todayDateStr: String,
    onDismiss: () -> Unit,
    onConfirm: (feed: FeedItem, quantity: Double, date: String, session: String, pen: String, notes: String) -> Unit
) {
    if (allFeeds.isEmpty()) {
        AlertDialog(
            onDismissRequest = onDismiss,
            title = { Text("No Feeds Available") },
            text = { Text("Please add at least one feed type to inventory before recording usage.") },
            confirmButton = { Button(onClick = onDismiss) { Text("OK") } }
        )
        return
    }

    var selectedFeed by remember { mutableStateOf(allFeeds.first()) }
    var quantityStr by remember { mutableStateOf("15.0") }
    var dateStr by remember { mutableStateOf(todayDateStr) }
    var selectedSession by remember { mutableStateOf("Morning") }
    var targetGroup by remember { mutableStateOf("Entire Herd") }
    var notes by remember { mutableStateOf("") }
    var errorMsg by remember { mutableStateOf<String?>(null) }

    val sessions = listOf("Morning", "Afternoon", "Evening", "Night")
    val groups = listOf("Entire Herd", "Does in Milk", "Pregnant Does", "Growing Kids", "Bucks", "Pen A")

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Record Daily Feed Usage", fontWeight = FontWeight.Bold) },
        text = {
            Column(modifier = Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                // Feed Selector Dropdown / Row
                Text("Select Feed Type *", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFF475569))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    allFeeds.forEach { f ->
                        FilterChip(
                            selected = selectedFeed.id == f.id,
                            onClick = { selectedFeed = f },
                            label = { Text("${f.name_c} (${f.current_stock_kg_c}${f.unit_c})", fontSize = 11.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = FarmGreenPrimary,
                                selectedLabelColor = Color.White
                            )
                        )
                    }
                }

                DatePickerField(
                    dateValue = dateStr,
                    onDateSelected = { dateStr = it },
                    label = "Usage Date"
                )

                OutlinedTextField(
                    value = quantityStr,
                    onValueChange = { quantityStr = it },
                    label = { Text("Quantity Fed (${selectedFeed.unit_c}) *") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Text("Session", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFF475569))
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    sessions.forEach { s ->
                        FilterChip(
                            selected = selectedSession == s,
                            onClick = { selectedSession = s },
                            label = { Text(s, fontSize = 10.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = FarmGreenPrimary,
                                selectedLabelColor = Color.White
                            )
                        )
                    }
                }

                Text("Target Flock / Pen", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFF475569))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    groups.forEach { g ->
                        FilterChip(
                            selected = targetGroup == g,
                            onClick = { targetGroup = g },
                            label = { Text(g, fontSize = 10.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = Color(0xFF2563EB),
                                selectedLabelColor = Color.White
                            )
                        )
                    }
                }

                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Notes") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                if (errorMsg != null) {
                    Text(errorMsg ?: "", color = Color(0xFFDC2626), fontSize = 12.sp)
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val q = quantityStr.toDoubleOrNull()
                    if (q == null || q <= 0.0) {
                        errorMsg = "Please enter valid quantity."
                        return@Button
                    }
                    if (q > selectedFeed.current_stock_kg_c) {
                        errorMsg = "Quantity ($q) exceeds current stock (${selectedFeed.current_stock_kg_c})."
                        return@Button
                    }
                    onConfirm(selectedFeed, q, dateStr, selectedSession, targetGroup, notes)
                },
                colors = ButtonDefaults.buttonColors(containerColor = FarmGreenPrimary)
            ) {
                Text("Record Usage", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

// -------------------------------------------------------------
// DIALOG 4: Restock / Purchase
// -------------------------------------------------------------
@Composable
private fun RestockFeedDialog(
    feed: FeedItem,
    todayDateStr: String,
    onDismiss: () -> Unit,
    onConfirm: (quantity: Double, date: String, costPerUnit: Double?, notes: String) -> Unit
) {
    var quantityStr by remember { mutableStateOf("50.0") }
    var dateStr by remember { mutableStateOf(todayDateStr) }
    var costStr by remember { mutableStateOf(feed.cost_per_unit_c?.toString() ?: "") }
    var notes by remember { mutableStateOf("") }
    var errorMsg by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Column {
                Text("Restock Feed Inventory", fontWeight = FontWeight.Bold)
                Text(feed.name_c, fontSize = 12.sp, color = FarmGreenDark)
            }
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                DatePickerField(
                    dateValue = dateStr,
                    onDateSelected = { dateStr = it },
                    label = "Purchase / Delivery Date"
                )

                OutlinedTextField(
                    value = quantityStr,
                    onValueChange = { quantityStr = it },
                    label = { Text("Quantity Added (${feed.unit_c}) *") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = costStr,
                    onValueChange = { costStr = it },
                    label = { Text("Cost per ${feed.unit_c} (₹)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Supplier / Invoice Notes") },
                    placeholder = { Text("e.g. Purchased from Kisan Agro Mart") },
                    modifier = Modifier.fillMaxWidth()
                )

                if (errorMsg != null) {
                    Text(errorMsg ?: "", color = Color(0xFFDC2626), fontSize = 12.sp)
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val q = quantityStr.toDoubleOrNull()
                    if (q == null || q <= 0.0) {
                        errorMsg = "Please enter valid quantity."
                        return@Button
                    }
                    val c = costStr.toDoubleOrNull()
                    onConfirm(q, dateStr, c, notes)
                },
                colors = ButtonDefaults.buttonColors(containerColor = FarmGreenPrimary)
            ) {
                Text("Restock Now", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}
