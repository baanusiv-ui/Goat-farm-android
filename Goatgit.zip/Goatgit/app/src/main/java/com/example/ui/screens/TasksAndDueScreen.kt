package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.supabase.*
import com.example.i18n.t
import com.example.ui.components.DatePickerField
import com.example.ui.components.FarmBottomNavigation
import com.example.ui.components.FarmTopBar
import com.example.ui.components.TagBadge
import com.example.ui.theme.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun TasksAndDueScreen(
    repository: GoatRepository,
    initialTab: Int = 0, // 0 = Due Items, 1 = Tasks
    onNavigateBack: () -> Unit,
    onNavigateToVaccinateGoat: (String) -> Unit,
    onNavigateToDewormGoat: (String) -> Unit,
    onNavigateToDashboard: () -> Unit = {},
    onNavigateToGoats: () -> Unit = {},
    onNavigateToSales: () -> Unit = {},
    onNavigateToAiEntry: () -> Unit = {},
    onNavigateToBreeding: () -> Unit = {}
) {
    var selectedTab by remember { mutableIntStateOf(initialTab) }
    var dueItems by remember { mutableStateOf<List<QuickDueItem>>(emptyList()) }
    var tasks by remember { mutableStateOf<List<FarmTask>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }
    var showAddTaskDialog by remember { mutableStateOf(false) }

    val coroutineScope = rememberCoroutineScope()
    val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.US)
    val today = remember { dateFormat.format(Date()) }

    fun loadData() {
        isLoading = true
        coroutineScope.launch {
            val dRes = repository.getDueItems()
            if (dRes.isSuccess) dueItems = dRes.getOrThrow()
            val tRes = repository.getTasks()
            if (tRes.isSuccess) tasks = tRes.getOrThrow()
            isLoading = false
        }
    }

    LaunchedEffect(Unit) {
        loadData()
    }

    Scaffold(
        topBar = {
            FarmTopBar(
                title = if (selectedTab == 0) t("tasks.tab_due_today") else t("tasks.title"),
                canNavigateBack = true,
                onNavigateBack = onNavigateBack,
                syncManager = repository.syncManager,
                actions = {
                    if (selectedTab == 1) {
                        IconButton(onClick = { showAddTaskDialog = true }) {
                            Icon(Icons.Default.Add, contentDescription = t("tasks.add_task"), tint = Color.White)
                        }
                    }
                    IconButton(onClick = { loadData() }) {
                        Icon(Icons.Default.Refresh, contentDescription = t("topbar.refresh"), tint = Color.White)
                    }
                }
            )
        },
        floatingActionButton = {
            if (selectedTab == 1) {
                FloatingActionButton(
                    onClick = { showAddTaskDialog = true },
                    containerColor = FarmGreenDark,
                    contentColor = Color.White
                ) {
                    Icon(Icons.Default.Add, contentDescription = t("tasks.add_task"))
                }
            }
        },
        bottomBar = {
            FarmBottomNavigation(
                currentRoute = "tasks_and_due",
                onNavigateToDashboard = onNavigateToDashboard,
                onNavigateToGoats = onNavigateToGoats,
                onNavigateToBreeding = onNavigateToBreeding,
                onNavigateToSales = onNavigateToSales,
                onNavigateToTasks = {},
                onNavigateToAiEntry = onNavigateToAiEntry
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(FarmBackgroundLight)
                .padding(padding)
        ) {
            TabRow(selectedTabIndex = selectedTab, containerColor = Color.White) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = { Text("${t("tasks.tab_due_today")} (${dueItems.size})", fontWeight = FontWeight.Bold) }
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = { Text("${t("tasks.tab_all")} (${tasks.count { it.status_c == "Pending" }})", fontWeight = FontWeight.Bold) }
                )
            }

            if (isLoading) {
                Box(modifier = Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = FarmGreenPrimary)
                }
            } else if (selectedTab == 0) {
                // Today's Due Tab
                LazyColumn(
                    modifier = Modifier.fillMaxSize().padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    if (dueItems.isEmpty()) {
                        item {
                            Card(
                                modifier = Modifier.fillMaxWidth().padding(16.dp),
                                colors = CardDefaults.cardColors(containerColor = Color.White)
                            ) {
                                Column(
                                    modifier = Modifier.padding(24.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Icon(Icons.Default.CheckCircleOutline, contentDescription = null, tint = FarmSuccess, modifier = Modifier.size(48.dp))
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text(t("dashboard.no_due_today"), fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                                }
                            }
                        }
                    }

                    items(dueItems) { item ->
                        val isOverdue = item.days_diff < 0
                        val isToday = item.days_diff == 0
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        TagBadge(tag = item.goat_tag)
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(item.goat_name, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyLarge)
                                    }

                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = "${item.record_type}: ${item.detail}",
                                        fontWeight = FontWeight.SemiBold,
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = FarmGreenDark
                                    )
                                    Text(
                                        text = "${t("tasks.due_date")}: ${item.due_date}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }

                                Column(horizontalAlignment = Alignment.End) {
                                    Surface(
                                        shape = RoundedCornerShape(8.dp),
                                        color = when {
                                            isOverdue -> FarmErrorContainer
                                            isToday -> FarmWarningContainer
                                            else -> FarmGreenContainer
                                        }
                                    ) {
                                        Text(
                                            text = when {
                                                isOverdue -> "${-item.days_diff}d ${t("tasks.overdue")}"
                                                isToday -> t("tasks.today")
                                                else -> "${t("tasks.upcoming")} (${item.days_diff}d)"
                                            },
                                            color = when {
                                                isOverdue -> FarmError
                                                isToday -> FarmWarning
                                                else -> FarmOnGreenContainer
                                            },
                                            fontWeight = FontWeight.Bold,
                                            style = MaterialTheme.typography.labelSmall,
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                        )
                                    }

                                    Spacer(modifier = Modifier.height(6.dp))

                                    Button(
                                        onClick = {
                                            if (item.record_type.equals("Vaccination", ignoreCase = true)) {
                                                onNavigateToVaccinateGoat(item.goat_id_c)
                                            } else {
                                                onNavigateToDewormGoat(item.goat_id_c)
                                            }
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = FarmGreenPrimary),
                                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                                        shape = RoundedCornerShape(8.dp)
                                    ) {
                                        Text(t("herd.quick_actions"), fontSize = 12.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                // Tasks Tab
                LazyColumn(
                    modifier = Modifier.fillMaxSize().padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    if (tasks.isEmpty()) {
                        item {
                            Card(
                                modifier = Modifier.fillMaxWidth().padding(16.dp),
                                colors = CardDefaults.cardColors(containerColor = Color.White)
                            ) {
                                Column(
                                    modifier = Modifier.padding(24.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Icon(Icons.Default.TaskAlt, contentDescription = null, tint = FarmGreenPrimary, modifier = Modifier.size(48.dp))
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text(t("tasks.no_tasks"), fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }

                    items(tasks) { task ->
                        val isDone = task.status_c == "Completed"
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = if (isDone) Color(0xFFF5F5F5) else Color.White
                            ),
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Checkbox(
                                    checked = isDone,
                                    onCheckedChange = { checked ->
                                        coroutineScope.launch {
                                            repository.updateTaskStatus(task.id, checked)
                                            loadData()
                                        }
                                    }
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = task.title_c,
                                        fontWeight = FontWeight.Bold,
                                        style = MaterialTheme.typography.bodyLarge,
                                        color = if (isDone) MaterialTheme.colorScheme.onSurfaceVariant else Color.Black
                                    )
                                    if (!task.description_c.isNullOrBlank()) {
                                        Text(task.description_c, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                    Text(
                                        text = "${t("tasks.due_prefix")}: ${task.due_date_c}${if (!task.assigned_to_c.isNullOrBlank()) " • ${t("tasks.assigned_to")}: ${task.assigned_to_c}" else ""}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = FarmGreenDark
                                    )
                                }

                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = when (task.priority_c) {
                                        "High" -> FarmErrorContainer
                                        "Low" -> Color(0xFFE0F2F1)
                                        else -> FarmAmberContainer
                                    }
                                ) {
                                    Text(
                                        text = when (task.priority_c) {
                                            "High" -> t("tasks.priority_high")
                                            "Low" -> t("tasks.priority_low")
                                            else -> t("tasks.priority_normal")
                                        },
                                        color = when (task.priority_c) {
                                            "High" -> FarmError
                                            "Low" -> Color(0xFF00695C)
                                            else -> FarmBrown
                                        },
                                        fontWeight = FontWeight.Bold,
                                        style = MaterialTheme.typography.labelSmall,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showAddTaskDialog) {
        var title by remember { mutableStateOf("") }
        var description by remember { mutableStateOf("") }
        var dueDate by remember { mutableStateOf(today) }
        var priority by remember { mutableStateOf("Normal") }
        var assignedTo by remember { mutableStateOf("") }
        var savingTask by remember { mutableStateOf(false) }

        AlertDialog(
            onDismissRequest = { showAddTaskDialog = false },
            title = { Text(t("tasks.add_task"), fontWeight = FontWeight.Bold) },
            text = {
                Column(modifier = Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = title,
                        onValueChange = { title = it },
                        label = { Text(t("tasks.task_title")) },
                        placeholder = { Text("e.g. Disinfect Pen 2, Restock Hay") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = description,
                        onValueChange = { description = it },
                        label = { Text(t("herd.notes")) },
                        modifier = Modifier.fillMaxWidth()
                    )

                    DatePickerField(
                        dateValue = dueDate,
                        onDateSelected = { dueDate = it },
                        label = t("tasks.due_date")
                    )

                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("High" to t("tasks.priority_high"), "Normal" to t("tasks.priority_normal"), "Low" to t("tasks.priority_low")).forEach { (pKey, pLabel) ->
                            FilterChip(
                                selected = priority == pKey,
                                onClick = { priority = pKey },
                                label = { Text(pLabel) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = FarmGreenPrimary,
                                    selectedLabelColor = Color.White
                                )
                            )
                        }
                    }

                    OutlinedTextField(
                        value = assignedTo,
                        onValueChange = { assignedTo = it },
                        label = { Text(t("tasks.assigned_to")) },
                        placeholder = { Text("e.g. John") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (title.isBlank()) return@Button
                        savingTask = true
                        coroutineScope.launch {
                            val task = FarmTask(
                                title_c = title.trim(),
                                description_c = description.ifBlank { null },
                                due_date_c = dueDate,
                                priority_c = priority,
                                assigned_to_c = assignedTo.ifBlank { null }
                            )
                            repository.addTask(task)
                            savingTask = false
                            showAddTaskDialog = false
                            loadData()
                        }
                    },
                    enabled = !savingTask,
                    colors = ButtonDefaults.buttonColors(containerColor = FarmGreenPrimary)
                ) {
                    if (savingTask) CircularProgressIndicator(color = Color.White, modifier = Modifier.size(18.dp))
                    else Text(t("btn.save"))
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddTaskDialog = false }) {
                    Text(t("btn.cancel"))
                }
            }
        )
    }
}
