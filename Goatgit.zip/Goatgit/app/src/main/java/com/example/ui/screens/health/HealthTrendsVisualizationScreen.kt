package com.example.ui.screens.health

import android.graphics.Paint
import android.graphics.Typeface
import androidx.activity.compose.BackHandler
import androidx.compose.animation.*
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.TrendingUp
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.offline.*
import com.example.data.supabase.Goat
import com.example.data.supabase.GoatRepository
import com.example.ui.theme.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.roundToInt

/**
 * High-performance, Recharts/D3 styled Data Visualization Screen for historical
 * goat health trends, Average Daily Gain (ADG), and clinical intervention frequency.
 * Queries data directly from local Room database.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HealthTrendsVisualizationScreen(
    repository: GoatRepository,
    initialGoatId: String? = null,
    onNavigateBack: () -> Unit,
    onNavigateToRecordWeight: ((String?) -> Unit)? = null,
    onNavigateToDailyObservation: ((String?) -> Unit)? = null
) {
    BackHandler { onNavigateBack() }

    val coroutineScope = rememberCoroutineScope()

    // Seed sample data if database is fresh so visualization is immediately vibrant
    LaunchedEffect(Unit) {
        repository.seedHistoricalHealthTrendsIfEmpty()
    }

    // Reactive data from Room Database
    val allWeights by repository.database.healthDao().getAllWeightsFlow().collectAsState(initial = emptyList())
    val allVaccinations by repository.database.healthDao().getAllVaccinationsFlow().collectAsState(initial = emptyList())
    val allDewormings by repository.database.healthDao().getAllDewormingsFlow().collectAsState(initial = emptyList())
    val allTreatments by repository.database.healthDao().getAllTreatmentsFlow().collectAsState(initial = emptyList())
    val allObservations by repository.database.dailyHealthObservationDao().getAllObservationsFlow().collectAsState(initial = emptyList())
    val goatsList by repository.getLocalGoatsFlow().collectAsState(initial = emptyList())

    // UI State
    var selectedTab by remember { mutableIntStateOf(0) } // 0: ADG & Growth, 1: Interventions Frequency, 2: Vitals & FAMACHA
    var selectedTimeframe by remember { mutableStateOf("6M") } // 30D, 90D, 6M, 1Y, ALL
    var selectedGoatId by remember { mutableStateOf(initialGoatId) }
    var showGoatPicker by remember { mutableStateOf(false) }
    var showExportDialog by remember { mutableStateOf(false) }

    val dateFormat = remember { SimpleDateFormat("yyyy-MM-dd", Locale.US) }
    val displayDateFormat = remember { SimpleDateFormat("dd MMM yyyy", Locale.US) }

    // Time cutoff calculation
    val cutoffMillis = remember(selectedTimeframe) {
        val now = System.currentTimeMillis()
        when (selectedTimeframe) {
            "30D" -> now - 30L * 86400000L
            "90D" -> now - 90L * 86400000L
            "6M" -> now - 180L * 86400000L
            "1Y" -> now - 365L * 86400000L
            else -> 0L
        }
    }

    // Filter weights by goat and timeframe
    val filteredWeights = remember(allWeights, selectedGoatId, cutoffMillis) {
        val list = if (selectedGoatId != null) {
            allWeights.filter { it.goat_id_c == selectedGoatId }
        } else {
            allWeights
        }
        list.filter {
            val millis = try { dateFormat.parse(it.date_c)?.time ?: 0L } catch (_: Exception) { 0L }
            millis >= cutoffMillis
        }.sortedBy { it.date_c }
    }

    // Filter interventions by goat and timeframe
    val filteredVaccinations = remember(allVaccinations, selectedGoatId, cutoffMillis) {
        val list = if (selectedGoatId != null) allVaccinations.filter { it.goat_id_c == selectedGoatId } else allVaccinations
        list.filter {
            val millis = try { dateFormat.parse(it.administered_date_c)?.time ?: 0L } catch (_: Exception) { 0L }
            millis >= cutoffMillis
        }
    }

    val filteredDewormings = remember(allDewormings, selectedGoatId, cutoffMillis) {
        val list = if (selectedGoatId != null) allDewormings.filter { it.goat_id_c == selectedGoatId } else allDewormings
        list.filter {
            val millis = try { dateFormat.parse(it.treatment_date_c)?.time ?: 0L } catch (_: Exception) { 0L }
            millis >= cutoffMillis
        }
    }

    val filteredTreatments = remember(allTreatments, selectedGoatId, cutoffMillis) {
        val list = if (selectedGoatId != null) allTreatments.filter { it.goat_id_c == selectedGoatId } else allTreatments
        list.filter {
            val millis = try { dateFormat.parse(it.start_date_c)?.time ?: 0L } catch (_: Exception) { 0L }
            millis >= cutoffMillis
        }
    }

    val filteredObservations = remember(allObservations, selectedGoatId, cutoffMillis) {
        val list = if (selectedGoatId != null) allObservations.filter { it.goat_id == selectedGoatId } else allObservations
        list.filter {
            val millis = try { dateFormat.parse(it.observation_date)?.time ?: 0L } catch (_: Exception) { 0L }
            millis >= cutoffMillis
        }.sortedBy { it.observation_date }
    }

    // Calculate Average Daily Gain (ADG)
    val adgData = remember(filteredWeights) {
        calculateAverageDailyGain(filteredWeights, dateFormat)
    }

    val selectedGoatObj = remember(goatsList, selectedGoatId) {
        goatsList.find { it.id == selectedGoatId }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "Health Trends & Analytics",
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp
                        )
                        Text(
                            text = if (selectedGoatObj != null)
                                "Filtered: ${selectedGoatObj.tag_c} - ${selectedGoatObj.name} (${selectedGoatObj.breed_c})"
                            else
                                "Herd-wide trends from local Room database",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                navigationIcon = {
                    IconButton(
                        onClick = onNavigateBack,
                        modifier = Modifier.testTag("btn_trends_back")
                    ) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(
                        onClick = { showExportDialog = true },
                        modifier = Modifier.testTag("btn_trends_export")
                    ) {
                        Icon(Icons.Default.Share, contentDescription = "Export Trends Summary")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFFF8FAFC))
                .padding(paddingValues)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item { Spacer(modifier = Modifier.height(4.dp)) }

            // 1. Controls Section: Goat Filter & Timeframe Selector
            item {
                TrendsFilterBar(
                    goatsList = goatsList,
                    selectedGoatId = selectedGoatId,
                    selectedTimeframe = selectedTimeframe,
                    onSelectGoat = { selectedGoatId = it },
                    onSelectTimeframe = { selectedTimeframe = it },
                    onOpenGoatPicker = { showGoatPicker = true }
                )
            }

            // 2. Executive KPI Summary Cards
            item {
                TrendsKpiSummaryRow(
                    adgGrams = adgData.overallAdgGrams,
                    totalInterventions = filteredVaccinations.size + filteredDewormings.size + filteredTreatments.size,
                    healthyObsCount = filteredObservations.count { it.overall_health_rating == "Healthy" },
                    totalObsCount = filteredObservations.size,
                    avgFamacha = filteredObservations.mapNotNull {
                        when {
                            it.mucous_membrane_famacha.startsWith("Score 1") -> 1.0
                            it.mucous_membrane_famacha.startsWith("Score 2") -> 2.0
                            it.mucous_membrane_famacha.startsWith("Score 3") -> 3.0
                            it.mucous_membrane_famacha.startsWith("Score 4") -> 4.0
                            it.mucous_membrane_famacha.startsWith("Score 5") -> 5.0
                            else -> null
                        }
                    }.average().let { if (it.isNaN()) 1.8 else it }
                )
            }

            // 3. Tab Selector
            item {
                TabRow(
                    selectedTabIndex = selectedTab,
                    containerColor = Color.White,
                    contentColor = FarmGreenDark,
                    modifier = Modifier.clip(RoundedCornerShape(12.dp))
                ) {
                    Tab(
                        selected = selectedTab == 0,
                        onClick = { selectedTab = 0 },
                        text = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.AutoMirrored.Filled.TrendingUp, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Growth & ADG", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        },
                        modifier = Modifier.testTag("tab_growth_adg")
                    )
                    Tab(
                        selected = selectedTab == 1,
                        onClick = { selectedTab = 1 },
                        text = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.BarChart, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Interventions", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        },
                        modifier = Modifier.testTag("tab_interventions_freq")
                    )
                    Tab(
                        selected = selectedTab == 2,
                        onClick = { selectedTab = 2 },
                        text = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Thermostat, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Vitals & Risk", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        },
                        modifier = Modifier.testTag("tab_vitals_clinical")
                    )
                }
            }

            // 4. Tab Content
            when (selectedTab) {
                0 -> {
                    // TAB 0: Growth Trajectory & Average Daily Gain (ADG)
                    item {
                        RechartsWeightSplineCard(
                            weights = filteredWeights,
                            adgResult = adgData,
                            onRecordWeight = { onNavigateToRecordWeight?.invoke(selectedGoatId) }
                        )
                    }

                    item {
                        AdgBarChartCard(
                            intervals = adgData.intervals
                        )
                    }

                    item {
                        TanuvastargetGrowthInsightCard(
                            adgGrams = adgData.overallAdgGrams
                        )
                    }
                }
                1 -> {
                    // TAB 1: Health Interventions Frequency (Vaccinations, Dewormings, Treatments, Checks)
                    item {
                        InterventionsFrequencyBarCard(
                            vaccinations = filteredVaccinations,
                            dewormings = filteredDewormings,
                            treatments = filteredTreatments,
                            observations = filteredObservations
                        )
                    }

                    item {
                        InterventionDistributionDonutCard(
                            vaccinationCount = filteredVaccinations.size,
                            dewormingCount = filteredDewormings.size,
                            treatmentCount = filteredTreatments.size,
                            observationCount = filteredObservations.size
                        )
                    }

                    item {
                        ClinicalTreatmentsDiagnosisBreakdownCard(
                            treatments = filteredTreatments
                        )
                    }
                }
                2 -> {
                    // TAB 2: Vitals & Clinical Indicators (Temperature, FAMACHA, BCS)
                    item {
                        ClinicalTemperatureTrendCard(
                            observations = filteredObservations,
                            onInputObservation = { onNavigateToDailyObservation?.invoke(selectedGoatId) }
                        )
                    }

                    item {
                        FamachaScoreDistributionCard(
                            observations = filteredObservations
                        )
                    }

                    item {
                        BodyConditionScoreProgressionCard(
                            observations = filteredObservations
                        )
                    }
                }
            }

            item { Spacer(modifier = Modifier.height(32.dp)) }
        }
    }

    // Modal Goat Picker
    if (showGoatPicker) {
        GoatSelectionDialog(
            goats = goatsList,
            selectedGoatId = selectedGoatId,
            onSelectGoat = {
                selectedGoatId = it
                showGoatPicker = false
            },
            onDismiss = { showGoatPicker = false }
        )
    }

    // Export Summary Dialog
    if (showExportDialog) {
        TrendsSummaryExportDialog(
            selectedGoat = selectedGoatObj,
            timeframe = selectedTimeframe,
            weightsCount = filteredWeights.size,
            adgGrams = adgData.overallAdgGrams,
            totalInterventions = filteredVaccinations.size + filteredDewormings.size + filteredTreatments.size,
            onDismiss = { showExportDialog = false }
        )
    }
}

// ==============================================================================
// 1. RECHARTS/D3 STYLE SPLINE AREA CHART (WEIGHT PROGRESSION & ADG)
// ==============================================================================

@Composable
fun RechartsWeightSplineCard(
    weights: List<GoatWeightEntity>,
    adgResult: AdgCalculationResult,
    onRecordWeight: () -> Unit
) {
    var selectedIndex by remember { mutableStateOf<Int?>(null) }

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier.fillMaxWidth().testTag("card_growth_spline_chart")
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(10.dp)
                                .clip(CircleShape)
                                .background(FarmGreenDark)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Weight Growth Trajectory",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = Color(0xFF0F172A)
                        )
                    }
                    Text(
                        text = "Interactive monotone cubic spline curve (D3 / Recharts Area)",
                        fontSize = 11.sp,
                        color = Color(0xFF64748B)
                    )
                }

                FilledTonalButton(
                    onClick = onRecordWeight,
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.testTag("btn_quick_record_weight")
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Weigh-in", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            if (weights.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(180.dp)
                        .background(Color(0xFFF1F5F9), RoundedCornerShape(12.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "No weigh-in records in this timeframe.\nTap '+ Weigh-in' above to record initial weight.",
                        fontSize = 12.sp,
                        color = Color.Gray,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )
                }
            } else {
                // Interactive Canvas Chart
                val sortedWeights = remember(weights) { weights.sortedBy { it.date_c } }
                val minWeight = remember(sortedWeights) { (sortedWeights.minOfOrNull { it.weight_kg_c } ?: 0.0) - 1.5 }.coerceAtLeast(0.0)
                val maxWeight = remember(sortedWeights) { (sortedWeights.maxOfOrNull { it.weight_kg_c } ?: 40.0) + 2.0 }

                // Hovered Tooltip Card
                selectedIndex?.let { idx ->
                    if (idx in sortedWeights.indices) {
                        val activeItem = sortedWeights[idx]
                        val prevItem = if (idx > 0) sortedWeights[idx - 1] else null
                        val gainKg = prevItem?.let { activeItem.weight_kg_c - it.weight_kg_c }

                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = Color(0xFF0F172A),
                            contentColor = Color.White,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 8.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 12.dp, vertical = 8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = "Date: ${activeItem.date_c}",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Medium,
                                        color = Color(0xFF94A3B8)
                                    )
                                    Text(
                                        text = "${activeItem.weight_kg_c} kg (${activeItem.method_c})",
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF4ADE80)
                                    )
                                }
                                if (gainKg != null) {
                                    Column(horizontalAlignment = Alignment.End) {
                                        Text(
                                            text = if (gainKg >= 0) "+${String.format(Locale.US, "%.2f", gainKg)} kg" else "${String.format(Locale.US, "%.2f", gainKg)} kg",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 13.sp,
                                            color = if (gainKg >= 0) Color(0xFF4ADE80) else Color(0xFFF87171)
                                        )
                                        Text(
                                            text = "since prev test",
                                            fontSize = 10.sp,
                                            color = Color(0xFF94A3B8)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                Canvas(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(200.dp)
                        .pointerInput(sortedWeights) {
                            detectTapGestures(
                                onPress = { offset ->
                                    val padLeft = 40.dp.toPx()
                                    val padRight = 16.dp.toPx()
                                    val graphW = size.width - padLeft - padRight
                                    if (sortedWeights.size > 1 && graphW > 0) {
                                        val touchX = offset.x.coerceIn(padLeft, size.width - padRight)
                                        val ratio = (touchX - padLeft) / graphW
                                        val idx = (ratio * (sortedWeights.size - 1)).roundToInt().coerceIn(0, sortedWeights.size - 1)
                                        selectedIndex = idx
                                    } else if (sortedWeights.isNotEmpty()) {
                                        selectedIndex = 0
                                    }
                                }
                            )
                        }
                        .pointerInput(sortedWeights) {
                            detectDragGestures(
                                onDragStart = { offset ->
                                    val padLeft = 40.dp.toPx()
                                    val padRight = 16.dp.toPx()
                                    val graphW = size.width - padLeft - padRight
                                    if (sortedWeights.size > 1 && graphW > 0) {
                                        val touchX = offset.x.coerceIn(padLeft, size.width - padRight)
                                        val ratio = (touchX - padLeft) / graphW
                                        val idx = (ratio * (sortedWeights.size - 1)).roundToInt().coerceIn(0, sortedWeights.size - 1)
                                        selectedIndex = idx
                                    }
                                },
                                onDrag = { change, _ ->
                                    change.consume()
                                    val padLeft = 40.dp.toPx()
                                    val padRight = 16.dp.toPx()
                                    val graphW = size.width - padLeft - padRight
                                    if (sortedWeights.size > 1 && graphW > 0) {
                                        val touchX = change.position.x.coerceIn(padLeft, size.width - padRight)
                                        val ratio = (touchX - padLeft) / graphW
                                        val idx = (ratio * (sortedWeights.size - 1)).roundToInt().coerceIn(0, sortedWeights.size - 1)
                                        selectedIndex = idx
                                    }
                                }
                            )
                        }
                ) {
                    val w = size.width
                    val h = size.height
                    val padLeft = 42.dp.toPx()
                    val padRight = 16.dp.toPx()
                    val padTop = 16.dp.toPx()
                    val padBottom = 26.dp.toPx()

                    val graphW = w - padLeft - padRight
                    val graphH = h - padTop - padBottom

                    if (graphW <= 0 || graphH <= 0) return@Canvas

                    val range = (maxWeight - minWeight).coerceAtLeast(1.0)

                    // 1. Grid Lines & Y-Axis Labels
                    val gridCount = 4
                    val textPaint = Paint().apply {
                        color = android.graphics.Color.parseColor("#94A3B8")
                        textSize = 9.sp.toPx()
                        isAntiAlias = true
                        textAlign = Paint.Align.RIGHT
                    }
                    val datePaint = Paint().apply {
                        color = android.graphics.Color.parseColor("#64748B")
                        textSize = 9.sp.toPx()
                        isAntiAlias = true
                        textAlign = Paint.Align.CENTER
                    }

                    for (i in 0..gridCount) {
                        val fraction = i.toFloat() / gridCount
                        val y = padTop + graphH * (1f - fraction)
                        val kgVal = minWeight + range * fraction

                        drawLine(
                            color = Color(0xFFE2E8F0),
                            start = Offset(padLeft, y),
                            end = Offset(w - padRight, y),
                            strokeWidth = 1.dp.toPx(),
                            pathEffect = if (i == 0 || i == gridCount) null else PathEffect.dashPathEffect(floatArrayOf(6f, 6f), 0f)
                        )

                        drawContext.canvas.nativeCanvas.drawText(
                            "${kgVal.toInt()}kg",
                            padLeft - 6.dp.toPx(),
                            y + 3.dp.toPx(),
                            textPaint
                        )
                    }

                    // 2. Expected Standard Breed Growth Trajectory (TANUVAS guideline dashed line)
                    val startVal = sortedWeights.first().weight_kg_c
                    val targetEndVal = startVal + (adgResult.daysMonitored * 0.075) // 75g/day optimal target
                    val benchStartY = padTop + graphH - (((startVal - minWeight) / range) * graphH).toFloat()
                    val benchEndY = padTop + graphH - (((targetEndVal - minWeight) / range) * graphH).toFloat()

                    drawLine(
                        color = Color(0xFFF59E0B).copy(alpha = 0.6f),
                        start = Offset(padLeft, benchStartY),
                        end = Offset(w - padRight, benchEndY),
                        strokeWidth = 1.5.dp.toPx(),
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(6f, 6f), 0f)
                    )

                    // 3. Compute Coordinates
                    val points = sortedWeights.mapIndexed { index, item ->
                        val x = if (sortedWeights.size == 1) {
                            padLeft + graphW / 2f
                        } else {
                            padLeft + (index.toFloat() / (sortedWeights.size - 1)) * graphW
                        }
                        val y = padTop + graphH - (((item.weight_kg_c - minWeight) / range) * graphH).toFloat()
                        Offset(x, y)
                    }

                    // 4. Draw Monotone Cubic Spline Area & Stroke
                    if (points.size >= 2) {
                        val fillPath = Path().apply {
                            moveTo(points.first().x, padTop + graphH)
                            lineTo(points.first().x, points.first().y)
                            for (i in 0 until points.size - 1) {
                                val p0 = points[i]
                                val p1 = points[i + 1]
                                val cx1 = p0.x + (p1.x - p0.x) / 2f
                                val cy1 = p0.y
                                val cx2 = p0.x + (p1.x - p0.x) / 2f
                                val cy2 = p1.y
                                cubicTo(cx1, cy1, cx2, cy2, p1.x, p1.y)
                            }
                            lineTo(points.last().x, padTop + graphH)
                            close()
                        }

                        drawPath(
                            path = fillPath,
                            brush = Brush.verticalGradient(
                                colors = listOf(
                                    Color(0xFF10B981).copy(alpha = 0.35f),
                                    Color(0xFF10B981).copy(alpha = 0.03f)
                                ),
                                startY = padTop,
                                endY = padTop + graphH
                            )
                        )

                        val strokePath = Path().apply {
                            moveTo(points.first().x, points.first().y)
                            for (i in 0 until points.size - 1) {
                                val p0 = points[i]
                                val p1 = points[i + 1]
                                val cx1 = p0.x + (p1.x - p0.x) / 2f
                                val cy1 = p0.y
                                val cx2 = p0.x + (p1.x - p0.x) / 2f
                                val cy2 = p1.y
                                cubicTo(cx1, cy1, cx2, cy2, p1.x, p1.y)
                            }
                        }

                        drawPath(
                            path = strokePath,
                            color = Color(0xFF059669),
                            style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round)
                        )
                    }

                    // 5. Crosshair Line for Active Hover
                    selectedIndex?.let { idx ->
                        if (idx in points.indices) {
                            val activePt = points[idx]
                            drawLine(
                                color = Color(0xFF0F172A).copy(alpha = 0.5f),
                                start = Offset(activePt.x, padTop),
                                end = Offset(activePt.x, padTop + graphH),
                                strokeWidth = 1.5.dp.toPx(),
                                pathEffect = PathEffect.dashPathEffect(floatArrayOf(4f, 4f), 0f)
                            )
                        }
                    }

                    // 6. Draw Nodes and X-Axis Dates
                    points.forEachIndexed { index, pt ->
                        val isSelected = (index == selectedIndex)
                        if (isSelected) {
                            drawCircle(
                                color = Color(0xFF10B981).copy(alpha = 0.3f),
                                radius = 7.dp.toPx(),
                                center = pt
                            )
                        }
                        drawCircle(
                            color = Color.White,
                            radius = if (isSelected) 4.5.dp.toPx() else 3.5.dp.toPx(),
                            center = pt
                        )
                        drawCircle(
                            color = if (isSelected) Color(0xFF047857) else Color(0xFF10B981),
                            radius = if (isSelected) 3.dp.toPx() else 2.5.dp.toPx(),
                            center = pt
                        )

                        // Date label on X-Axis for first, last, and selected points
                        if (index == 0 || index == points.size - 1 || isSelected) {
                            val dateShort = sortedWeights[index].date_c.takeLast(5) // MM-dd
                            drawContext.canvas.nativeCanvas.drawText(
                                dateShort,
                                pt.x,
                                padTop + graphH + 16.dp.toPx(),
                                datePaint
                            )
                        }
                    }
                }

                // Legend
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(Color(0xFF059669)))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Actual Weight Progression (Room DB)", fontSize = 10.sp, color = Color(0xFF475569))

                    Spacer(modifier = Modifier.width(16.dp))

                    Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(Color(0xFFF59E0B)))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Target Growth Benchmark (75g/day)", fontSize = 10.sp, color = Color(0xFF475569))
                }
            }
        }
    }
}

// ==============================================================================
// 2. AVERAGE DAILY GAIN (ADG) BAR CHART
// ==============================================================================

@Composable
fun AdgBarChartCard(
    intervals: List<AdgInterval>
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier.fillMaxWidth().testTag("card_adg_intervals_chart")
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "Interval Average Daily Gain (ADG)",
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                color = Color(0xFF0F172A)
            )
            Text(
                text = "Daily gain rate between successive weigh-in dates in grams/day",
                fontSize = 11.sp,
                color = Color(0xFF64748B)
            )

            Spacer(modifier = Modifier.height(14.dp))

            if (intervals.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(120.dp)
                        .background(Color(0xFFF8FAFC), RoundedCornerShape(8.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Text("At least 2 weigh-ins required to calculate interval ADG.", fontSize = 12.sp, color = Color.Gray)
                }
            } else {
                val maxAdg = (intervals.maxOfOrNull { it.adgGrams } ?: 100.0).coerceAtLeast(90.0)

                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    intervals.takeLast(6).forEach { interval ->
                        val ratio = (interval.adgGrams / maxAdg).coerceIn(0.05, 1.0).toFloat()
                        val isOptimal = interval.adgGrams >= 70.0
                        val barColor = when {
                            interval.adgGrams >= 70.0 -> Color(0xFF10B981)
                            interval.adgGrams >= 40.0 -> Color(0xFFF59E0B)
                            else -> Color(0xFFEF4444)
                        }

                        Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "${interval.fromDate} → ${interval.toDate} (${interval.days} days)",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = Color(0xFF334155)
                                )
                                Text(
                                    text = "${interval.adgGrams.toInt()} g/day (${String.format(Locale.US, "%+.1f", interval.netGainKg)} kg)",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = barColor
                                )
                            }

                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(12.dp)
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(Color(0xFFF1F5F9))
                            ) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth(ratio)
                                        .fillMaxHeight()
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(barColor)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

// ==============================================================================
// 3. HEALTH INTERVENTIONS FREQUENCY (RECHARTS GROUPED BAR CHART)
// ==============================================================================

@Composable
fun InterventionsFrequencyBarCard(
    vaccinations: List<VaccinationEntity>,
    dewormings: List<DewormingEntity>,
    treatments: List<TreatmentEntity>,
    observations: List<DailyHealthObservationEntity>
) {
    var touchedMonthIndex by remember { mutableStateOf<Int?>(null) }

    // Aggregate interventions by month across past 6 months
    val monthlyData = remember(vaccinations, dewormings, treatments, observations) {
        val cal = Calendar.getInstance()
        val monthFormat = SimpleDateFormat("MMM yyyy", Locale.US)
        val monthKeyFormat = SimpleDateFormat("yyyy-MM", Locale.US)

        val months = mutableListOf<InterventionMonthBucket>()
        for (i in 5 downTo 0) {
            val c = Calendar.getInstance()
            c.add(Calendar.MONTH, -i)
            val key = monthKeyFormat.format(c.time)
            val label = monthFormat.format(c.time)

            val vCount = vaccinations.count { it.administered_date_c.startsWith(key) }
            val dCount = dewormings.count { it.treatment_date_c.startsWith(key) }
            val tCount = treatments.count { it.start_date_c.startsWith(key) }
            val oCount = observations.count { it.observation_date.startsWith(key) }

            months.add(
                InterventionMonthBucket(
                    monthKey = key,
                    monthLabel = label,
                    vaccinations = vCount,
                    dewormings = dCount,
                    treatments = tCount,
                    observations = oCount
                )
            )
        }
        months
    }

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier.fillMaxWidth().testTag("card_interventions_frequency_chart")
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "Interventions Frequency by Month",
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                color = Color(0xFF0F172A)
            )
            Text(
                text = "Grouped bar visualization of medical & preventive actions",
                fontSize = 11.sp,
                color = Color(0xFF64748B)
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Tooltip preview
            touchedMonthIndex?.let { idx ->
                if (idx in monthlyData.indices) {
                    val m = monthlyData[idx]
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = Color(0xFF0F172A),
                        contentColor = Color.White,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 8.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 6.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(text = m.monthLabel, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            Text(
                                text = "💉 ${m.vaccinations} Vax • 💊 ${m.dewormings} Deworm • 🩺 ${m.treatments} Treat • 📋 ${m.observations} Checks",
                                fontSize = 11.sp,
                                color = Color(0xFF38BDF8)
                            )
                        }
                    }
                }
            }

            // Canvas Bar Chart
            val maxCount = remember(monthlyData) {
                monthlyData.maxOfOrNull {
                    maxOf(it.vaccinations, it.dewormings, it.treatments, it.observations)
                }?.coerceAtLeast(4) ?: 4
            }

            Canvas(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(180.dp)
                    .pointerInput(monthlyData) {
                        detectTapGestures { offset ->
                            val padLeft = 28.dp.toPx()
                            val padRight = 10.dp.toPx()
                            val chartW = size.width - padLeft - padRight
                            if (chartW > 0) {
                                val touchX = offset.x.coerceIn(padLeft, size.width - padRight)
                                val colW = chartW / monthlyData.size
                                val idx = ((touchX - padLeft) / colW).toInt().coerceIn(0, monthlyData.size - 1)
                                touchedMonthIndex = idx
                            }
                        }
                    }
            ) {
                val w = size.width
                val h = size.height
                val padLeft = 28.dp.toPx()
                val padRight = 10.dp.toPx()
                val padTop = 14.dp.toPx()
                val padBottom = 26.dp.toPx()

                val chartW = w - padLeft - padRight
                val chartH = h - padTop - padBottom

                if (chartW <= 0 || chartH <= 0) return@Canvas

                // Horizontal grid lines
                val gridLines = 4
                val countPaint = Paint().apply {
                    color = android.graphics.Color.parseColor("#94A3B8")
                    textSize = 8.sp.toPx()
                    isAntiAlias = true
                    textAlign = Paint.Align.RIGHT
                }
                val labelPaint = Paint().apply {
                    color = android.graphics.Color.parseColor("#64748B")
                    textSize = 8.sp.toPx()
                    isAntiAlias = true
                    textAlign = Paint.Align.CENTER
                }

                for (i in 0..gridLines) {
                    val frac = i.toFloat() / gridLines
                    val y = padTop + chartH * (1f - frac)
                    val cnt = (maxCount * frac).roundToInt()

                    drawLine(
                        color = Color(0xFFE2E8F0),
                        start = Offset(padLeft, y),
                        end = Offset(w - padRight, y),
                        strokeWidth = 1.dp.toPx(),
                        pathEffect = if (i == 0) null else PathEffect.dashPathEffect(floatArrayOf(4f, 4f), 0f)
                    )

                    drawContext.canvas.nativeCanvas.drawText(
                        "$cnt",
                        padLeft - 4.dp.toPx(),
                        y + 3.dp.toPx(),
                        countPaint
                    )
                }

                // Draw Grouped Bars per Month
                val groupWidth = chartW / monthlyData.size
                val barW = (groupWidth * 0.18f).coerceAtLeast(3.dp.toPx())
                val barGap = 2.dp.toPx()

                monthlyData.forEachIndexed { colIdx, bucket ->
                    val colCenter = padLeft + colIdx * groupWidth + groupWidth / 2f
                    val totalGroupW = 4 * barW + 3 * barGap
                    val groupStartX = colCenter - totalGroupW / 2f

                    // Highlights if selected
                    if (colIdx == touchedMonthIndex) {
                        drawRoundRect(
                            color = Color(0xFFF1F5F9),
                            topLeft = Offset(padLeft + colIdx * groupWidth + 2.dp.toPx(), padTop),
                            size = Size(groupWidth - 4.dp.toPx(), chartH),
                            cornerRadius = CornerRadius(6.dp.toPx(), 6.dp.toPx())
                        )
                    }

                    // Bar 1: Vaccinations (Blue)
                    val vH = (bucket.vaccinations.toFloat() / maxCount * chartH).coerceAtLeast(2.dp.toPx())
                    drawRoundRect(
                        color = Color(0xFF0284C7),
                        topLeft = Offset(groupStartX, padTop + chartH - vH),
                        size = Size(barW, vH),
                        cornerRadius = CornerRadius(3.dp.toPx(), 3.dp.toPx())
                    )

                    // Bar 2: Dewormings (Green)
                    val dH = (bucket.dewormings.toFloat() / maxCount * chartH).coerceAtLeast(2.dp.toPx())
                    drawRoundRect(
                        color = Color(0xFF059669),
                        topLeft = Offset(groupStartX + barW + barGap, padTop + chartH - dH),
                        size = Size(barW, dH),
                        cornerRadius = CornerRadius(3.dp.toPx(), 3.dp.toPx())
                    )

                    // Bar 3: Treatments (Purple)
                    val tH = (bucket.treatments.toFloat() / maxCount * chartH).coerceAtLeast(2.dp.toPx())
                    drawRoundRect(
                        color = Color(0xFF9333EA),
                        topLeft = Offset(groupStartX + 2 * (barW + barGap), padTop + chartH - tH),
                        size = Size(barW, tH),
                        cornerRadius = CornerRadius(3.dp.toPx(), 3.dp.toPx())
                    )

                    // Bar 4: Observations (Amber)
                    val oH = (bucket.observations.toFloat() / maxCount * chartH).coerceAtLeast(2.dp.toPx())
                    drawRoundRect(
                        color = Color(0xFFD97706),
                        topLeft = Offset(groupStartX + 3 * (barW + barGap), padTop + chartH - oH),
                        size = Size(barW, oH),
                        cornerRadius = CornerRadius(3.dp.toPx(), 3.dp.toPx())
                    )

                    // X-Axis Month Label
                    val shortLabel = bucket.monthLabel.take(3)
                    drawContext.canvas.nativeCanvas.drawText(
                        shortLabel,
                        colCenter,
                        padTop + chartH + 16.dp.toPx(),
                        labelPaint
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Recharts Legend
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                LegendChip(color = Color(0xFF0284C7), label = "Vaccines")
                LegendChip(color = Color(0xFF059669), label = "Deworm")
                LegendChip(color = Color(0xFF9333EA), label = "Treatments")
                LegendChip(color = Color(0xFFD97706), label = "Daily Checks")
            }
        }
    }
}

// ==============================================================================
// 4. CLINICAL TEMPERATURE TRENDS CARD
// ==============================================================================

@Composable
fun ClinicalTemperatureTrendCard(
    observations: List<DailyHealthObservationEntity>,
    onInputObservation: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier.fillMaxWidth().testTag("card_temperature_trends_chart")
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Clinical Body Temperature (°C)",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = Color(0xFF0F172A)
                    )
                    Text(
                        text = "Normal: 38.5°C - 39.7°C • Fever Alert: >39.7°C",
                        fontSize = 11.sp,
                        color = Color(0xFF64748B)
                    )
                }

                FilledTonalButton(
                    onClick = onInputObservation,
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.testTag("btn_quick_obs_temp")
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Check", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            val tempReadings = remember(observations) {
                observations.filter { it.temperature_celsius != null }
                    .map { Pair(it.observation_date, it.temperature_celsius!!) }
            }

            if (tempReadings.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(140.dp)
                        .background(Color(0xFFF1F5F9), RoundedCornerShape(10.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Text("No temperature records logged yet.", fontSize = 12.sp, color = Color.Gray)
                }
            } else {
                val minTemp = 37.5
                val maxTemp = 41.5
                val range = maxTemp - minTemp

                Canvas(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(160.dp)
                ) {
                    val w = size.width
                    val h = size.height
                    val padLeft = 40.dp.toPx()
                    val padRight = 16.dp.toPx()
                    val padTop = 14.dp.toPx()
                    val padBottom = 24.dp.toPx()

                    val chartW = w - padLeft - padRight
                    val chartH = h - padTop - padBottom

                    if (chartW <= 0 || chartH <= 0) return@Canvas

                    // 1. Shaded Normal Temperature Band (38.5°C to 39.7°C)
                    val normalLowY = padTop + chartH - (((38.5 - minTemp) / range) * chartH).toFloat()
                    val normalHighY = padTop + chartH - (((39.7 - minTemp) / range) * chartH).toFloat()

                    drawRect(
                        color = Color(0xFFDCFCE7).copy(alpha = 0.6f),
                        topLeft = Offset(padLeft, normalHighY),
                        size = Size(chartW, normalLowY - normalHighY)
                    )

                    // 2. Fever Threshold Line (>39.7°C)
                    drawLine(
                        color = Color(0xFFEF4444).copy(alpha = 0.7f),
                        start = Offset(padLeft, normalHighY),
                        end = Offset(w - padRight, normalHighY),
                        strokeWidth = 1.5.dp.toPx(),
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(6f, 6f), 0f)
                    )

                    // 3. Grid Lines
                    val textPaint = Paint().apply {
                        color = android.graphics.Color.parseColor("#94A3B8")
                        textSize = 8.sp.toPx()
                        isAntiAlias = true
                        textAlign = Paint.Align.RIGHT
                    }

                    listOf(38.0, 39.0, 40.0, 41.0).forEach { tempVal ->
                        val y = padTop + chartH - (((tempVal - minTemp) / range) * chartH).toFloat()
                        drawContext.canvas.nativeCanvas.drawText(
                            "${tempVal.toInt()}°C",
                            padLeft - 6.dp.toPx(),
                            y + 3.dp.toPx(),
                            textPaint
                        )
                    }

                    // 4. Points & Line
                    val points = tempReadings.mapIndexed { idx, item ->
                        val x = if (tempReadings.size == 1) {
                            padLeft + chartW / 2f
                        } else {
                            padLeft + (idx.toFloat() / (tempReadings.size - 1)) * chartW
                        }
                        val y = padTop + chartH - (((item.second - minTemp) / range) * chartH).toFloat()
                        Offset(x, y)
                    }

                    if (points.size >= 2) {
                        val path = Path().apply {
                            moveTo(points.first().x, points.first().y)
                            for (i in 1 until points.size) {
                                lineTo(points[i].x, points[i].y)
                            }
                        }
                        drawPath(
                            path = path,
                            color = Color(0xFF2563EB),
                            style = Stroke(width = 2.5.dp.toPx(), cap = StrokeCap.Round)
                        )
                    }

                    points.forEachIndexed { idx, pt ->
                        val tempVal = tempReadings[idx].second
                        val isFever = tempVal > 39.7
                        drawCircle(
                            color = if (isFever) Color(0xFFEF4444) else Color(0xFF2563EB),
                            radius = if (isFever) 5.dp.toPx() else 3.5.dp.toPx(),
                            center = pt
                        )
                        drawCircle(
                            color = Color.White,
                            radius = 2.dp.toPx(),
                            center = pt
                        )
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.Center
                ) {
                    Text(
                        text = "🟢 Green Band = Healthy Range (38.5 - 39.7°C) • 🔴 Red Dashed = Fever Alert",
                        fontSize = 10.sp,
                        color = Color(0xFF64748B)
                    )
                }
            }
        }
    }
}

// ==============================================================================
// 5. FAMACHA EYE ANEMIA SCORE DISTRIBUTION
// ==============================================================================

@Composable
fun FamachaScoreDistributionCard(
    observations: List<DailyHealthObservationEntity>
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier.fillMaxWidth().testTag("card_famacha_distribution")
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "FAMACHA© Anemia Grading Distribution",
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                color = Color(0xFF0F172A)
            )
            Text(
                text = "Haemonchus contortus (barber pole worm) clinical eye score distribution",
                fontSize = 11.sp,
                color = Color(0xFF64748B)
            )

            Spacer(modifier = Modifier.height(14.dp))

            val scores = remember(observations) {
                mapOf(
                    "Score 1 (Optimal Pink)" to observations.count { it.mucous_membrane_famacha.startsWith("Score 1") },
                    "Score 2 (Acceptable)" to observations.count { it.mucous_membrane_famacha.startsWith("Score 2") },
                    "Score 3 (Borderline)" to observations.count { it.mucous_membrane_famacha.startsWith("Score 3") },
                    "Score 4 (Anemic)" to observations.count { it.mucous_membrane_famacha.startsWith("Score 4") },
                    "Score 5 (Severe Anemia)" to observations.count { it.mucous_membrane_famacha.startsWith("Score 5") }
                )
            }

            val maxFamacha = scores.values.maxOrNull()?.coerceAtLeast(1) ?: 1

            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                scores.forEach { (label, count) ->
                    val frac = (count.toFloat() / maxFamacha).coerceIn(0.04f, 1f)
                    val barColor = when {
                        label.startsWith("Score 1") -> Color(0xFF10B981)
                        label.startsWith("Score 2") -> Color(0xFF34D399)
                        label.startsWith("Score 3") -> Color(0xFFFBBF24)
                        label.startsWith("Score 4") -> Color(0xFFF87171)
                        else -> Color(0xFFDC2626)
                    }

                    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(text = label, fontSize = 11.sp, fontWeight = FontWeight.Medium, color = Color(0xFF334155))
                            Text(text = "$count observations", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = barColor)
                        }

                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(10.dp)
                                .clip(RoundedCornerShape(5.dp))
                                .background(Color(0xFFF1F5F9))
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth(frac)
                                    .fillMaxHeight()
                                    .clip(RoundedCornerShape(5.dp))
                                    .background(barColor)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Surface(
                color = Color(0xFFFEF3C7),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "💡 Tactical Guidance: Deworm only animals at FAMACHA 4 or 5 to preserve drug efficacy and slow anthelmintic resistance.",
                    fontSize = 11.sp,
                    color = Color(0xFF92400E),
                    modifier = Modifier.padding(10.dp)
                )
            }
        }
    }
}

// ==============================================================================
// 6. BODY CONDITION SCORE (BCS) PROGRESSION
// ==============================================================================

@Composable
fun BodyConditionScoreProgressionCard(
    observations: List<DailyHealthObservationEntity>
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier.fillMaxWidth().testTag("card_bcs_progression")
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "Body Condition Score (BCS) Trajectory",
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                color = Color(0xFF0F172A)
            )
            Text(
                text = "Target score: 2.5 - 3.5 (Ideal energy balance & muscle reserve)",
                fontSize = 11.sp,
                color = Color(0xFF64748B)
            )

            Spacer(modifier = Modifier.height(12.dp))

            val bcsList = observations.filter { it.body_condition_score != null }
            if (bcsList.isEmpty()) {
                Text("No BCS ratings recorded.", fontSize = 11.sp, color = Color.Gray)
            } else {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    bcsList.takeLast(5).forEach { obs ->
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = Color(0xFFF8FAFC),
                            border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
                            modifier = Modifier.weight(1f)
                        ) {
                            Column(
                                modifier = Modifier.padding(8.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    text = String.format(Locale.US, "%.1f", obs.body_condition_score ?: 3.0),
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 16.sp,
                                    color = FarmGreenDark
                                )
                                Text(
                                    text = obs.observation_date.takeLast(5),
                                    fontSize = 9.sp,
                                    color = Color.Gray
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

// ==============================================================================
// 7. INTERVENTIONS DISTRIBUTION DONUT / SUMMARY
// ==============================================================================

@Composable
fun InterventionDistributionDonutCard(
    vaccinationCount: Int,
    dewormingCount: Int,
    treatmentCount: Int,
    observationCount: Int
) {
    val total = vaccinationCount + dewormingCount + treatmentCount + observationCount
    val totalSafe = if (total > 0) total else 1

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier.fillMaxWidth().testTag("card_intervention_distribution")
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "Care Intervention Breakdown",
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                color = Color(0xFF0F172A)
            )
            Text(
                text = "Preventive health protocol vs curative clinical events ($total total)",
                fontSize = 11.sp,
                color = Color(0xFF64748B)
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Multi-segment progress bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(16.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0xFFF1F5F9))
            ) {
                if (vaccinationCount > 0) {
                    Box(modifier = Modifier.weight(vaccinationCount.toFloat() / totalSafe).fillMaxHeight().background(Color(0xFF0284C7)))
                }
                if (dewormingCount > 0) {
                    Box(modifier = Modifier.weight(dewormingCount.toFloat() / totalSafe).fillMaxHeight().background(Color(0xFF059669)))
                }
                if (treatmentCount > 0) {
                    Box(modifier = Modifier.weight(treatmentCount.toFloat() / totalSafe).fillMaxHeight().background(Color(0xFF9333EA)))
                }
                if (observationCount > 0) {
                    Box(modifier = Modifier.weight(observationCount.toFloat() / totalSafe).fillMaxHeight().background(Color(0xFFD97706)))
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                DistributionStatItem(color = Color(0xFF0284C7), label = "Vaccines", count = vaccinationCount, total = totalSafe)
                DistributionStatItem(color = Color(0xFF059669), label = "Dewormings", count = dewormingCount, total = totalSafe)
                DistributionStatItem(color = Color(0xFF9333EA), label = "Treatments", count = treatmentCount, total = totalSafe)
                DistributionStatItem(color = Color(0xFFD97706), label = "Daily Checks", count = observationCount, total = totalSafe)
            }
        }
    }
}

@Composable
fun ClinicalTreatmentsDiagnosisBreakdownCard(
    treatments: List<TreatmentEntity>
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "Recent Clinical Treatments & Diagnoses",
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                color = Color(0xFF0F172A)
            )

            Spacer(modifier = Modifier.height(10.dp))

            if (treatments.isEmpty()) {
                Text("No clinical illness treatments recorded in this period. Herd is healthy!", fontSize = 11.sp, color = Color.Gray)
            } else {
                treatments.takeLast(4).forEach { tr ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(text = tr.diagnosis_c.ifBlank { "Clinical Case" }, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            Text(text = "${tr.medicine_c} • ${tr.start_date_c}", fontSize = 10.sp, color = Color.Gray)
                        }
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = if (tr.outcome_c.contains("Recovered", ignoreCase = true)) Color(0xFFDCFCE7) else Color(0xFFFEF3C7)
                        ) {
                            Text(
                                text = tr.outcome_c,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (tr.outcome_c.contains("Recovered", ignoreCase = true)) Color(0xFF166534) else Color(0xFF92400E),
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

// ==============================================================================
// 8. TANUVAS STANDARD ADG BENCHMARK INSIGHT CARD
// ==============================================================================

@Composable
fun TanuvastargetGrowthInsightCard(
    adgGrams: Double
) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = Color(0xFFEFF6FF),
        border = BorderStroke(1.dp, Color(0xFFBFDBFE)),
        modifier = Modifier.fillMaxWidth().testTag("card_tanuvas_adg_insight")
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(Color(0xFFDBEAFE)),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.Verified, contentDescription = null, tint = Color(0xFF1D4ED8))
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column {
                Text(
                    text = "TANUVAS Benchmark Growth Guidance",
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = Color(0xFF1E40AF)
                )
                Text(
                    text = when {
                        adgGrams >= 75.0 -> "Current Average Daily Gain (+${adgGrams.toInt()}g/day) is in the optimal performance band for intensive goat feeding."
                        adgGrams >= 50.0 -> "Current growth (+${adgGrams.toInt()}g/day) is within standard maintenance. Review concentrates and mineral lick for acceleration."
                        else -> "Growth rate (+${adgGrams.toInt()}g/day) is below 50g benchmark. Check deworming schedule, rumen motility, and green fodder protein."
                    },
                    fontSize = 11.sp,
                    color = Color(0xFF1E3A8A),
                    lineHeight = 15.sp
                )
            }
        }
    }
}

// ==============================================================================
// 9. FILTER BAR & KPI ROW COMPONENTS
// ==============================================================================

@Composable
fun TrendsFilterBar(
    goatsList: List<Goat>,
    selectedGoatId: String?,
    selectedTimeframe: String,
    onSelectGoat: (String?) -> Unit,
    onSelectTimeframe: (String) -> Unit,
    onOpenGoatPicker: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            // Goat Selector Dropdown Pill
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onOpenGoatPicker() }
                    .background(Color(0xFFF1F5F9), RoundedCornerShape(8.dp))
                    .padding(horizontal = 10.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Pets, contentDescription = null, tint = FarmGreenDark, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (selectedGoatId == null) "Cohort: All Herd Average" else "Goat: ${goatsList.find { it.id == selectedGoatId }?.let { "${it.tag_c} - ${it.name}" } ?: "Selected Goat"}",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF0F172A)
                    )
                }
                Icon(Icons.Default.ArrowDropDown, contentDescription = null, tint = Color.Gray)
            }

            // Timeframe Chips
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                listOf("30D", "90D", "6M", "1Y", "ALL").forEach { tf ->
                    val isSelected = selectedTimeframe == tf
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = if (isSelected) FarmGreenDark else Color(0xFFF1F5F9),
                        modifier = Modifier
                            .weight(1f)
                            .clickable { onSelectTimeframe(tf) }
                    ) {
                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier.padding(vertical = 6.dp)
                        ) {
                            Text(
                                text = tf,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isSelected) Color.White else Color(0xFF475569)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun TrendsKpiSummaryRow(
    adgGrams: Double,
    totalInterventions: Int,
    healthyObsCount: Int,
    totalObsCount: Int,
    avgFamacha: Double
) {
    val healthPercent = if (totalObsCount > 0) (healthyObsCount.toFloat() / totalObsCount * 100).toInt() else 100

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        KpiTile(
            title = "Average Gain",
            value = "+${adgGrams.toInt()} g/d",
            subtext = if (adgGrams >= 70) "Optimal" else "Standard",
            color = Color(0xFF10B981),
            bgColor = Color(0xFFE8F5E9),
            modifier = Modifier.weight(1f)
        )
        KpiTile(
            title = "Interventions",
            value = "$totalInterventions Events",
            subtext = "Care actions",
            color = Color(0xFF0284C7),
            bgColor = Color(0xFFE0F2FE),
            modifier = Modifier.weight(1f)
        )
        KpiTile(
            title = "Health Rate",
            value = "$healthPercent%",
            subtext = "$healthyObsCount/$totalObsCount obs",
            color = Color(0xFF9333EA),
            bgColor = Color(0xFFF3E8FF),
            modifier = Modifier.weight(1f)
        )
        KpiTile(
            title = "Avg FAMACHA",
            value = String.format(Locale.US, "%.1f", avgFamacha),
            subtext = if (avgFamacha <= 2.2) "Healthy" else "Caution",
            color = if (avgFamacha <= 2.2) Color(0xFF16A34A) else Color(0xFFDC2626),
            bgColor = if (avgFamacha <= 2.2) Color(0xFFDCFCE7) else Color(0xFFFEE2E2),
            modifier = Modifier.weight(1f)
        )
    }
}

@Composable
fun KpiTile(
    title: String,
    value: String,
    subtext: String,
    color: Color,
    bgColor: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = bgColor,
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(10.dp),
            verticalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            Text(text = title, fontSize = 10.sp, color = Color.Gray, maxLines = 1)
            Text(text = value, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = color, maxLines = 1)
            Text(text = subtext, fontSize = 9.sp, color = color.copy(alpha = 0.8f), maxLines = 1)
        }
    }
}

@Composable
fun LegendChip(color: Color, label: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(color))
        Spacer(modifier = Modifier.width(4.dp))
        Text(label, fontSize = 10.sp, color = Color(0xFF475569))
    }
}

@Composable
fun DistributionStatItem(color: Color, label: String, count: Int, total: Int) {
    val pct = (count.toFloat() / total * 100).toInt()
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(modifier = Modifier.size(6.dp).clip(CircleShape).background(color))
            Spacer(modifier = Modifier.width(3.dp))
            Text(label, fontSize = 10.sp, color = Color.Gray)
        }
        Text("$count ($pct%)", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF0F172A))
    }
}

// ==============================================================================
// 10. DIALOGS
// ==============================================================================

@Composable
fun GoatSelectionDialog(
    goats: List<Goat>,
    selectedGoatId: String?,
    onSelectGoat: (String?) -> Unit,
    onDismiss: () -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    val filtered = goats.filter {
        it.tag_c.contains(searchQuery, ignoreCase = true) ||
        it.name.contains(searchQuery, ignoreCase = true) ||
        it.breed_c.contains(searchQuery, ignoreCase = true)
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Filter by Goat Profile", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("Search by tag or name...") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                LazyColumn(modifier = Modifier.heightIn(max = 280.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    item {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = if (selectedGoatId == null) Color(0xFFDCFCE7) else Color.Transparent,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onSelectGoat(null) }
                                .padding(vertical = 4.dp)
                        ) {
                            Text(
                                "👥 All Herd Average (Full Flock)",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                modifier = Modifier.padding(10.dp),
                                color = if (selectedGoatId == null) FarmGreenDark else Color(0xFF0F172A)
                            )
                        }
                    }

                    items(filtered) { goat ->
                        val isSelected = (goat.id == selectedGoatId)
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = if (isSelected) Color(0xFFDCFCE7) else Color.Transparent,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onSelectGoat(goat.id) }
                                .padding(vertical = 2.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        "${goat.tag_c} - ${goat.name}",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp,
                                        color = if (isSelected) FarmGreenDark else Color(0xFF0F172A)
                                    )
                                    Text(
                                        "${goat.breed_c} • ${goat.sex_c} • ${goat.weight_kg_c ?: "N/A"}kg",
                                        fontSize = 11.sp,
                                        color = Color.Gray
                                    )
                                }
                                if (isSelected) {
                                    Icon(Icons.Default.Check, contentDescription = null, tint = FarmGreenDark, modifier = Modifier.size(18.dp))
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("Close") }
        }
    )
}

@Composable
fun TrendsSummaryExportDialog(
    selectedGoat: Goat?,
    timeframe: String,
    weightsCount: Int,
    adgGrams: Double,
    totalInterventions: Int,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Health Trends Summary", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "Cohort: ${selectedGoat?.let { "${it.tag_c} (${it.breed_c})" } ?: "All Herd"}",
                    fontWeight = FontWeight.Bold
                )
                Text(text = "Timeframe: $timeframe")
                Text(text = "Total Weigh-ins: $weightsCount records")
                Text(text = "Average Daily Gain: +${adgGrams.toInt()} g/day")
                Text(text = "Medical Interventions: $totalInterventions events logged in Room DB")
                Text(
                    text = "Data persisted locally in SQLite via Android Jetpack Room with offline-first indexing.",
                    fontSize = 11.sp,
                    color = Color.Gray
                )
            }
        },
        confirmButton = {
            Button(onClick = onDismiss) { Text("Done") }
        }
    )
}

// ==============================================================================
// 11. CALCULATION HELPER CLASSES & LOGIC
// ==============================================================================

data class AdgCalculationResult(
    val overallAdgGrams: Double = 0.0,
    val initialWeightKg: Double = 0.0,
    val currentWeightKg: Double = 0.0,
    val totalGainKg: Double = 0.0,
    val daysMonitored: Long = 0,
    val intervals: List<AdgInterval> = emptyList()
)

data class AdgInterval(
    val fromDate: String,
    val toDate: String,
    val days: Long,
    val netGainKg: Double,
    val adgGrams: Double
)

data class InterventionMonthBucket(
    val monthKey: String,
    val monthLabel: String,
    val vaccinations: Int,
    val dewormings: Int,
    val treatments: Int,
    val observations: Int
)

fun calculateAverageDailyGain(
    weights: List<GoatWeightEntity>,
    dateFormat: SimpleDateFormat
): AdgCalculationResult {
    if (weights.size < 2) {
        val single = weights.firstOrNull()?.weight_kg_c ?: 0.0
        return AdgCalculationResult(
            overallAdgGrams = 0.0,
            initialWeightKg = single,
            currentWeightKg = single,
            totalGainKg = 0.0,
            daysMonitored = 0
        )
    }

    val sorted = weights.sortedBy { it.date_c }
    val initial = sorted.first()
    val latest = sorted.last()

    val intervals = mutableListOf<AdgInterval>()
    for (i in 0 until sorted.size - 1) {
        val w1 = sorted[i]
        val w2 = sorted[i + 1]
        try {
            val d1 = dateFormat.parse(w1.date_c)?.time ?: 0L
            val d2 = dateFormat.parse(w2.date_c)?.time ?: 0L
            val days = ((d2 - d1) / (1000 * 60 * 60 * 24)).coerceAtLeast(1)
            val gain = w2.weight_kg_c - w1.weight_kg_c
            val adg = (gain * 1000.0) / days
            intervals.add(
                AdgInterval(
                    fromDate = w1.date_c.takeLast(5),
                    toDate = w2.date_c.takeLast(5),
                    days = days,
                    netGainKg = gain,
                    adgGrams = adg
                )
            )
        } catch (_: Exception) {}
    }

    val totalDays = try {
        val d1 = dateFormat.parse(initial.date_c)?.time ?: 0L
        val d2 = dateFormat.parse(latest.date_c)?.time ?: 0L
        ((d2 - d1) / (1000 * 60 * 60 * 24)).coerceAtLeast(1)
    } catch (_: Exception) { 1L }

    val totalGain = latest.weight_kg_c - initial.weight_kg_c
    val overallAdg = (totalGain * 1000.0) / totalDays

    return AdgCalculationResult(
        overallAdgGrams = overallAdg,
        initialWeightKg = initial.weight_kg_c,
        currentWeightKg = latest.weight_kg_c,
        totalGainKg = totalGain,
        daysMonitored = totalDays,
        intervals = intervals
    )
}
