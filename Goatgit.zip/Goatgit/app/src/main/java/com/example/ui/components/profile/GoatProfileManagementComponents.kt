package com.example.ui.components.profile

import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.TrendingUp
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.abs
import kotlin.math.roundToInt
import kotlin.math.sqrt
import com.example.data.offline.GoatEntity
import com.example.data.offline.GoatWeightEntity
import com.example.data.supabase.Goat
import com.example.data.supabase.GoatRepository
import com.example.data.supabase.GoatWeight
import com.example.ui.components.DatePickerField
import com.example.ui.components.OriginBadge
import com.example.ui.screens.weight.DefaultBreedBenchmarks
import com.example.ui.screens.weight.RechartsChartPoint
import com.example.ui.screens.weight.RechartsWebInteractiveChart
import com.example.ui.theme.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.TimeUnit

val STANDARD_GOAT_BREEDS = listOf(
    "Salem Karupu",
    "Kodi Adu",
    "Boer",
    "Jamnapari",
    "Sirohi",
    "Saanen",
    "Barbari",
    "Beetal",
    "Nubian",
    "Alpine",
    "Toggenburg",
    "Kiko",
    "Kalahari Red",
    "Malabari (Tellicherry)",
    "Osmanabadi",
    "Black Bengal",
    "Nigerian Dwarf",
    "Pygmy",
    "Crossbred / Local"
)

/**
 * Calculates human-readable age from birth date string (yyyy-MM-dd).
 */
fun calculateGoatAge(birthDateStr: String?): String {
    if (birthDateStr.isNullOrBlank()) return "Age unknown"
    return try {
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        val birthDate = sdf.parse(birthDateStr) ?: return "Age unknown"
        val today = Calendar.getInstance()
        val birthCal = Calendar.getInstance().apply { time = birthDate }

        var years = today.get(Calendar.YEAR) - birthCal.get(Calendar.YEAR)
        var months = today.get(Calendar.MONTH) - birthCal.get(Calendar.MONTH)
        var days = today.get(Calendar.DAY_OF_MONTH) - birthCal.get(Calendar.DAY_OF_MONTH)

        if (days < 0) {
            months--
        }
        if (months < 0) {
            years--
            months += 12
        }

        when {
            years > 0 && months > 0 -> "$years yr $months mo"
            years > 0 -> "$years yr"
            months > 0 -> "$months mo"
            else -> {
                val diffDays = TimeUnit.MILLISECONDS.toDays(today.timeInMillis - birthCal.timeInMillis).toInt()
                "$diffDays days"
            }
        }
    } catch (_: Exception) {
        "Age unknown"
    }
}

/**
 * Header card for an individual goat profile displaying breed, birth date, live age, sex, and status.
 */
@Composable
fun GoatProfileHeaderCard(
    goat: Goat,
    latestWeight: Double?,
    onEditProfile: () -> Unit,
    modifier: Modifier = Modifier
) {
    val ageStr = remember(goat.birth_date_c) { calculateGoatAge(goat.birth_date_c) }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("goat_profile_header_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Top Row: Avatar/Tag, Name, Edit Button
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Surface(
                        shape = CircleShape,
                        color = when (goat.sex_c?.lowercase()) {
                            "buck", "male" -> Color(0xFF1E3A8A).copy(alpha = 0.15f)
                            "doe", "female" -> Color(0xFF831843).copy(alpha = 0.15f)
                            else -> FarmGreenPrimary.copy(alpha = 0.15f)
                        },
                        modifier = Modifier.size(48.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Text(
                                text = "#${goat.tag_c}".take(5),
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                color = when (goat.sex_c?.lowercase()) {
                                    "buck", "male" -> Color(0xFF1E3A8A)
                                    "doe", "female" -> Color(0xFF9D174D)
                                    else -> FarmGreenDark
                                }
                            )
                        }
                    }

                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(
                                text = goat.name.ifBlank { "Tag #${goat.tag_c}" },
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF0F172A)
                            )
                            OriginBadge(origin = goat.effectiveOrigin)
                        }
                        Text(
                            text = "Ear Tag: #${goat.tag_c}",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color(0xFF64748B)
                        )
                    }
                }

                IconButton(
                    onClick = onEditProfile,
                    modifier = Modifier
                        .background(Color(0xFFF1F5F9), CircleShape)
                        .size(36.dp)
                        .testTag("btn_edit_goat_profile")
                ) {
                    Icon(Icons.Default.Edit, contentDescription = "Edit Profile", tint = FarmGreenDark, modifier = Modifier.size(18.dp))
                }
            }

            HorizontalDivider(color = Color(0xFFF1F5F9))

            // Details Grid: Breed, Birth Date, Sex, Status, Weight
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Breed Box
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = Color(0xFFF8FAFC),
                    border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
                    modifier = Modifier.weight(1f)
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text("BREED", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color(0xFF64748B))
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = goat.breed_c?.ifBlank { "Boer" } ?: "Boer",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = FarmGreenDark,
                            maxLines = 1
                        )
                    }
                }

                // Birth Date & Age Box
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = Color(0xFFF8FAFC),
                    border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
                    modifier = Modifier.weight(1.2f)
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text("BIRTH DATE & AGE", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color(0xFF64748B))
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = goat.birth_date_c?.ifBlank { "Not set" } ?: "Not set",
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 12.sp,
                            color = Color(0xFF1E293B)
                        )
                        Text(
                            text = ageStr,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF2563EB)
                        )
                    }
                }

                // Current Weight Box
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = Color(0xFFF0FDF4),
                    border = BorderStroke(1.dp, Color(0xFFBBF7D0)),
                    modifier = Modifier.weight(1f)
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text("WEIGHT", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color(0xFF15803D))
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = if (latestWeight != null && latestWeight > 0.0) "${String.format(Locale.US, "%.1f", latestWeight)} kg" else "-- kg",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = FarmGreenDark
                        )
                    }
                }
            }

            // Chips Row: Sex, Status, Color
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = Color(0xFFEDE9FE)
                ) {
                    Text(
                        text = "Sex: ${goat.sex_c ?: "Doe"}",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF6D28D9),
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }

                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = when (goat.status_c?.lowercase()) {
                        "active", "healthy" -> Color(0xFFDCFCE7)
                        "pregnant" -> Color(0xFFFCE7F3)
                        "quarantine" -> Color(0xFFFEF3C7)
                        "sold" -> Color(0xFFE2E8F0)
                        "deceased" -> Color(0xFFFEE2E2)
                        else -> Color(0xFFF1F5F9)
                    }
                ) {
                    Text(
                        text = "Status: ${goat.status_c ?: "Active"}",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = when (goat.status_c?.lowercase()) {
                            "active", "healthy" -> Color(0xFF15803D)
                            "pregnant" -> Color(0xFFBE185D)
                            "quarantine" -> Color(0xFFB45309)
                            "sold" -> Color(0xFF475569)
                            "deceased" -> Color(0xFFB91C1C)
                            else -> Color(0xFF334155)
                        },
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }

                if (!goat.color_c.isNullOrBlank()) {
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = Color(0xFFF1F5F9)
                    ) {
                        Text(
                            text = goat.color_c,
                            fontSize = 11.sp,
                            color = Color(0xFF475569),
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                        )
                    }
                }
            }
        }
    }
}

/**
 * Dialog to edit or update an individual goat's profile details in Room (breed, birth date, tag, name, sex, status, notes).
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GoatProfileEditDialog(
    goat: Goat,
    allGoats: List<Goat>,
    onDismiss: () -> Unit,
    onSaveProfile: (
        name: String,
        tag: String,
        breed: String,
        sex: String,
        status: String,
        birthDate: String?,
        color: String?,
        dam: String?,
        sire: String?,
        notes: String?
    ) -> Unit
) {
    var editName by remember { mutableStateOf(goat.name) }
    var editTag by remember { mutableStateOf(goat.tag_c) }
    var editBreed by remember { mutableStateOf(goat.breed_c?.ifBlank { "Boer" } ?: "Boer") }
    var editSex by remember { mutableStateOf(goat.sex_c ?: "Doe") }
    var editStatus by remember { mutableStateOf(goat.status_c ?: "Active") }
    var editBirthDate by remember { mutableStateOf(goat.birth_date_c ?: "") }
    var editColor by remember { mutableStateOf(goat.color_c ?: "") }
    var editDam by remember { mutableStateOf(goat.dam_c ?: "") }
    var editSire by remember { mutableStateOf(goat.sire_c ?: "") }
    var editNotes by remember { mutableStateOf(goat.notes_c ?: "") }

    var breedMenuExpanded by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(Icons.Default.Edit, contentDescription = null, tint = FarmGreenDark)
                Text("Edit Goat Profile", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Ear Tag & Name
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = editTag,
                        onValueChange = { editTag = it },
                        label = { Text("Ear Tag # *") },
                        modifier = Modifier.weight(1f).testTag("input_edit_goat_tag")
                    )
                    OutlinedTextField(
                        value = editName,
                        onValueChange = { editName = it },
                        label = { Text("Name") },
                        modifier = Modifier.weight(1.2f).testTag("input_edit_goat_name")
                    )
                }

                // Breed Dropdown (Requirement: Manage Breed)
                ExposedDropdownMenuBox(
                    expanded = breedMenuExpanded,
                    onExpandedChange = { breedMenuExpanded = it },
                    modifier = Modifier.fillMaxWidth().testTag("dropdown_goat_breed")
                ) {
                    OutlinedTextField(
                        value = editBreed,
                        onValueChange = { editBreed = it },
                        label = { Text("Goat Breed *") },
                        readOnly = false,
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = breedMenuExpanded) },
                        modifier = Modifier.menuAnchor().fillMaxWidth()
                    )
                    ExposedDropdownMenu(
                        expanded = breedMenuExpanded,
                        onDismissRequest = { breedMenuExpanded = false }
                    ) {
                        STANDARD_GOAT_BREEDS.forEach { br ->
                            DropdownMenuItem(
                                text = { Text(br) },
                                onClick = {
                                    editBreed = br
                                    breedMenuExpanded = false
                                }
                            )
                        }
                    }
                }

                // Birth Date Picker (Requirement: Manage Birth Date)
                DatePickerField(
                    dateValue = editBirthDate,
                    onDateSelected = { editBirthDate = it },
                    label = "Birth Date (YYYY-MM-DD)"
                )

                // Sex Selection
                Text("Sex:", fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Doe", "Buck", "Wether").forEach { sx ->
                        FilterChip(
                            selected = editSex.equals(sx, ignoreCase = true),
                            onClick = { editSex = sx },
                            label = { Text(sx) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = FarmGreenDark,
                                selectedLabelColor = Color.White
                            )
                        )
                    }
                }

                // Status Selection
                Text("Herd Status:", fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                Row(
                    modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    listOf("Active", "Pregnant", "Lactating", "Quarantine", "Sold", "Deceased").forEach { st ->
                        FilterChip(
                            selected = editStatus.equals(st, ignoreCase = true),
                            onClick = { editStatus = st },
                            label = { Text(st, fontSize = 11.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = FarmGreenPrimary,
                                selectedLabelColor = Color.White
                            )
                        )
                    }
                }

                OutlinedTextField(
                    value = editColor,
                    onValueChange = { editColor = it },
                    label = { Text("Color / Markings") },
                    placeholder = { Text("e.g. Traditional white body with red/brown head") },
                    modifier = Modifier.fillMaxWidth()
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = editDam,
                        onValueChange = { editDam = it },
                        label = { Text("Dam (Mother) Tag") },
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = editSire,
                        onValueChange = { editSire = it },
                        label = { Text("Sire (Father) Tag") },
                        modifier = Modifier.weight(1f)
                    )
                }

                OutlinedTextField(
                    value = editNotes,
                    onValueChange = { editNotes = it },
                    label = { Text("Notes / History") },
                    modifier = Modifier.fillMaxWidth(),
                    maxLines = 3
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (editTag.isNotBlank()) {
                        onSaveProfile(
                            editName.trim(),
                            editTag.trim(),
                            editBreed.trim(),
                            editSex.trim(),
                            editStatus.trim(),
                            editBirthDate.ifBlank { null },
                            editColor.ifBlank { null },
                            editDam.ifBlank { null },
                            editSire.ifBlank { null },
                            editNotes.ifBlank { null }
                        )
                    }
                },
                enabled = editTag.isNotBlank(),
                colors = ButtonDefaults.buttonColors(containerColor = FarmGreenPrimary),
                modifier = Modifier.testTag("btn_save_goat_profile_changes")
            ) {
                Text("Save Changes")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

/**
 * Complete Weight History Management Component displaying:
 * 1. KPIs (Current, Birth Weight, Total Gain, Average Daily Gain - ADG)
 * 2. Visual Growth Trajectory Chart Curve
 * 3. Log Weight Action Button & Dialog
 * 4. Chronological Weight History Timeline with delete affordance.
 */
@Composable
fun GoatWeightHistoryComponent(
    goatId: String,
    weights: List<GoatWeight>,
    birthDateStr: String?,
    onRecordNewWeight: (weightKg: Double, dateStr: String, method: String, notes: String?) -> Unit,
    onDeleteWeight: (weightId: String) -> Unit,
    modifier: Modifier = Modifier,
    onNavigateToTrends: (() -> Unit)? = null,
    goatBreed: String? = null
) {
    var showRecordWeightDialog by remember { mutableStateOf(false) }
    var weightToDelete by remember { mutableStateOf<GoatWeight?>(null) }
    var historyChartEngine by remember { mutableStateOf("Recharts") }

    // Sorted chronological ascending for analytics and chart
    val sortedAsc = remember(weights) { weights.sortedBy { it.date_c } }
    val sortedDesc = remember(weights) { weights.sortedByDescending { it.date_c } }

    val historyActiveBenchmark = remember(goatBreed) {
        val bName = goatBreed.orEmpty()
        DefaultBreedBenchmarks.find { it.breedName.equals(bName, ignoreCase = true) }
            ?: DefaultBreedBenchmarks.firstOrNull { bName.contains(it.breedName, ignoreCase = true) }
            ?: DefaultBreedBenchmarks.last()
    }

    val historyRechartsPoints = remember(sortedAsc, historyActiveBenchmark, birthDateStr) {
        if (sortedAsc.isEmpty()) emptyList()
        else {
            val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
            val firstWeight = sortedAsc.first()
            val firstDate = try { sdf.parse(firstWeight.date_c) ?: Date() } catch (_: Exception) { Date() }
            val bDate = birthDateStr?.let {
                try { sdf.parse(it) } catch (_: Exception) { null }
            }

            sortedAsc.mapIndexed { idx, item ->
                val itemDate = try { sdf.parse(item.date_c) ?: Date() } catch (_: Exception) { Date() }
                val expected = if (bDate != null) {
                    val ageDays = TimeUnit.MILLISECONDS.toDays(itemDate.time - bDate.time).toInt()
                    historyActiveBenchmark.calculateExpectedWeight(ageDays)
                } else {
                    val elapsedDays = TimeUnit.MILLISECONDS.toDays(itemDate.time - firstDate.time).toInt()
                    historyActiveBenchmark.calculateExpectedWeightFromStart(firstWeight.weight_kg_c, elapsedDays)
                }
                val varianceKg = item.weight_kg_c - expected
                val variancePct = if (expected > 0) (varianceKg / expected) * 100.0 else 0.0

                val prevItem = if (idx > 0) sortedAsc[idx - 1] else null
                val gainSinceLast = prevItem?.let { item.weight_kg_c - it.weight_kg_c }
                val daysSinceLast = prevItem?.let {
                    val prevDate = try { sdf.parse(it.date_c) ?: Date() } catch (_: Exception) { Date() }
                    TimeUnit.MILLISECONDS.toDays(itemDate.time - prevDate.time).coerceAtLeast(1L)
                }
                val intervalAdg = if (gainSinceLast != null && daysSinceLast != null && daysSinceLast > 0) {
                    ((gainSinceLast * 1000.0) / daysSinceLast).toInt()
                } else null

                RechartsChartPoint(
                    id = item.id,
                    dateStr = item.date_c,
                    timestamp = itemDate.time,
                    actualWeightKg = item.weight_kg_c,
                    expectedWeightKg = ((expected * 10.0).roundToInt()) / 10.0,
                    varianceKg = ((varianceKg * 10.0).roundToInt()) / 10.0,
                    variancePct = ((variancePct * 10.0).roundToInt()) / 10.0,
                    gainSinceLastKg = gainSinceLast?.let { ((it * 10.0).roundToInt()) / 10.0 },
                    intervalDays = daysSinceLast,
                    intervalAdgGrams = intervalAdg,
                    method = item.method_c,
                    notes = item.notes_c
                )
            }
        }
    }

    val currentWeight = sortedDesc.firstOrNull()?.weight_kg_c
    val initialWeight = sortedAsc.firstOrNull()?.weight_kg_c
    val totalGain = if (currentWeight != null && initialWeight != null && sortedAsc.size > 1) {
        currentWeight - initialWeight
    } else null

    // Overall Average Daily Gain (ADG)
    val overallAdgGramsPerDay = remember(sortedAsc) {
        if (sortedAsc.size >= 2) {
            val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
            try {
                val first = sortedAsc.first()
                val last = sortedAsc.last()
                val d1 = sdf.parse(first.date_c) ?: Date()
                val d2 = sdf.parse(last.date_c) ?: Date()
                val days = TimeUnit.MILLISECONDS.toDays(d2.time - d1.time).toInt()
                if (days > 0) {
                    val gainKg = last.weight_kg_c - first.weight_kg_c
                    ((gainKg * 1000.0) / days).toInt()
                } else null
            } catch (_: Exception) { null }
        } else null
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .testTag("goat_weight_history_component"),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Section Header with "Log Weight" CTA
        Card(
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = FarmGreenPrimary.copy(alpha = 0.15f),
                            modifier = Modifier.size(36.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(Icons.Default.Scale, contentDescription = null, tint = FarmGreenDark, modifier = Modifier.size(20.dp))
                            }
                        }
                        Column {
                            Text(
                                text = "Weight History & Growth Trajectory",
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp,
                                color = Color(0xFF0F172A)
                            )
                            Text(
                                text = "${weights.size} weigh-in record${if (weights.size == 1) "" else "s"} logged in Room",
                                fontSize = 11.sp,
                                color = Color(0xFF64748B)
                            )
                        }
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        if (onNavigateToTrends != null) {
                            FilledTonalButton(
                                onClick = { onNavigateToTrends() },
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp),
                                modifier = Modifier.testTag("btn_recharts_trends")
                            ) {
                                Icon(Icons.AutoMirrored.Filled.TrendingUp, contentDescription = null, modifier = Modifier.size(14.dp), tint = Color(0xFF0284C7))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Recharts", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF0284C7))
                            }
                        }

                        Button(
                            onClick = { showRecordWeightDialog = true },
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = FarmGreenPrimary),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                            modifier = Modifier.testTag("btn_log_new_weight")
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Log Weight", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                HorizontalDivider(color = Color(0xFFF1F5F9))

                // KPI Metrics Grid
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Current Weight
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = Color(0xFFF8FAFC),
                        border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
                        modifier = Modifier.weight(1f)
                    ) {
                        Column(
                            modifier = Modifier.padding(10.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text("Current Weight", fontSize = 10.sp, color = Color.Gray, fontWeight = FontWeight.SemiBold)
                            Text(
                                text = if (currentWeight != null) "${String.format(Locale.US, "%.1f", currentWeight)} kg" else "--",
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp,
                                color = Color(0xFF0F172A)
                            )
                        }
                    }

                    // Total Net Gain
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = if (totalGain != null && totalGain >= 0) Color(0xFFF0FDF4) else Color(0xFFF8FAFC),
                        border = BorderStroke(1.dp, if (totalGain != null && totalGain >= 0) Color(0xFFBBF7D0) else Color(0xFFE2E8F0)),
                        modifier = Modifier.weight(1f)
                    ) {
                        Column(
                            modifier = Modifier.padding(10.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text("Total Gain", fontSize = 10.sp, color = Color.Gray, fontWeight = FontWeight.SemiBold)
                            val gainStr = if (totalGain != null) {
                                "${if (totalGain >= 0) "+" else ""}${String.format(Locale.US, "%.1f", totalGain)} kg"
                            } else "--"
                            Text(
                                text = gainStr,
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp,
                                color = if (totalGain != null && totalGain >= 0) FarmGreenDark else Color.DarkGray
                            )
                        }
                    }

                    // ADG (Average Daily Gain)
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = Color(0xFFF8FAFC),
                        border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
                        modifier = Modifier.weight(1f)
                    ) {
                        Column(
                            modifier = Modifier.padding(10.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text("Average Daily Gain", fontSize = 10.sp, color = Color.Gray, fontWeight = FontWeight.SemiBold)
                            Text(
                                text = if (overallAdgGramsPerDay != null) "${overallAdgGramsPerDay} g/d" else "--",
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp,
                                color = Color(0xFF2563EB)
                            )
                        }
                    }
                }
            }
        }

        // Weight Growth Trajectory Chart Curve
        if (sortedAsc.isNotEmpty()) {
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "Growth Trajectory Curve",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = FarmGreenDark
                            )
                            if (sortedAsc.size > 1) {
                                Text(
                                    text = "${sortedAsc.first().date_c} → ${sortedAsc.last().date_c}",
                                    fontSize = 10.sp,
                                    color = Color.Gray
                                )
                            }
                        }

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            FilterChip(
                                selected = historyChartEngine == "Recharts",
                                onClick = { historyChartEngine = "Recharts" },
                                leadingIcon = {
                                    Icon(Icons.AutoMirrored.Filled.TrendingUp, contentDescription = null, modifier = Modifier.size(11.dp))
                                },
                                label = { Text("Recharts", fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                                modifier = Modifier.height(26.dp).testTag("btn_history_recharts_toggle")
                            )
                            FilterChip(
                                selected = historyChartEngine == "Canvas",
                                onClick = { historyChartEngine = "Canvas" },
                                label = { Text("Canvas", fontSize = 10.sp) },
                                modifier = Modifier.height(26.dp).testTag("btn_history_canvas_toggle")
                            )
                        }
                    }

                    if (historyChartEngine == "Recharts" && historyRechartsPoints.isNotEmpty()) {
                        RechartsWebInteractiveChart(
                            points = historyRechartsPoints,
                            breedName = goatBreed ?: "General Meat",
                            marketTargetKg = historyActiveBenchmark.marketTargetWeightKg,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(200.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .testTag("history_goat_recharts_chart")
                        )
                    } else {
                        GoatWeightGrowthChart(
                            weights = sortedAsc,
                            benchmarkBreed = goatBreed,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(180.dp)
                                .padding(vertical = 8.dp)
                        )
                    }
                }
            }
        }

        // Chronological Weight Timeline Table
        Card(
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = "Weight History Log",
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = Color(0xFF1E293B)
                )
                HorizontalDivider(color = Color(0xFFF1F5F9))

                if (sortedDesc.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 24.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("No weight records logged yet. Tap 'Log Weight' to add the first entry.", fontSize = 12.sp, color = Color.Gray)
                    }
                } else {
                    sortedDesc.forEachIndexed { index, item ->
                        val nextWeight = sortedDesc.getOrNull(index + 1)
                        val diffKg = if (nextWeight != null) item.weight_kg_c - nextWeight.weight_kg_c else null

                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = if (index % 2 == 0) Color(0xFFFAFAFA) else Color.White,
                            border = BorderStroke(1.dp, Color(0xFFF1F5F9)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 12.dp, vertical = 10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Surface(
                                        shape = CircleShape,
                                        color = Color(0xFFE2E8F0),
                                        modifier = Modifier.size(28.dp)
                                    ) {
                                        Box(contentAlignment = Alignment.Center) {
                                            Text(
                                                text = "${sortedDesc.size - index}",
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = Color.DarkGray
                                            )
                                        }
                                    }

                                    Column {
                                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                            Text(
                                                text = "${String.format(Locale.US, "%.1f", item.weight_kg_c)} kg",
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 14.sp,
                                                color = Color(0xFF0F172A)
                                            )
                                            if (diffKg != null) {
                                                val isGain = diffKg >= 0
                                                Surface(
                                                    shape = RoundedCornerShape(4.dp),
                                                    color = if (isGain) Color(0xFFDCFCE7) else Color(0xFFFEE2E2)
                                                ) {
                                                    Text(
                                                        text = "${if (isGain) "+" else ""}${String.format(Locale.US, "%.1f", diffKg)} kg",
                                                        fontSize = 10.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        color = if (isGain) Color(0xFF15803D) else Color(0xFFB91C1C),
                                                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                                    )
                                                }
                                            }
                                        }

                                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                            Text(
                                                text = "Date: ${item.date_c} • ${item.method_c}",
                                                fontSize = 11.sp,
                                                color = Color(0xFF64748B)
                                            )
                                        }
                                        if (!item.notes_c.isNullOrBlank()) {
                                            Text(
                                                text = item.notes_c,
                                                fontSize = 10.sp,
                                                color = Color(0xFF94A3B8),
                                                maxLines = 1
                                            )
                                        }
                                    }
                                }

                                IconButton(
                                    onClick = { weightToDelete = item },
                                    modifier = Modifier.size(32.dp)
                                ) {
                                    Icon(Icons.Default.Delete, contentDescription = "Delete Weight", tint = Color(0xFF94A3B8), modifier = Modifier.size(16.dp))
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Record Weight Dialog
    if (showRecordWeightDialog) {
        RecordWeightModalDialog(
            defaultDate = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date()),
            lastWeightKg = currentWeight ?: 25.0,
            onDismiss = { showRecordWeightDialog = false },
            onSave = { kg, dateStr, method, notes ->
                onRecordNewWeight(kg, dateStr, method, notes)
                showRecordWeightDialog = false
            }
        )
    }

    // Delete Confirmation Dialog
    weightToDelete?.let { wt ->
        AlertDialog(
            onDismissRequest = { weightToDelete = null },
            title = { Text("Delete Weight Entry", fontWeight = FontWeight.Bold) },
            text = { Text("Are you sure you want to remove the weight measurement of ${wt.weight_kg_c} kg recorded on ${wt.date_c}?") },
            confirmButton = {
                Button(
                    onClick = {
                        onDeleteWeight(wt.id)
                        weightToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626))
                ) {
                    Text("Delete")
                }
            },
            dismissButton = {
                TextButton(onClick = { weightToDelete = null }) {
                    Text("Cancel")
                }
            }
        )
    }
}

/**
 * D3-quality interactive line chart component displaying weight trends over time.
 * Features:
 * - Smooth monotone cubic bezier spline curve (d3.curveMonotoneX)
 * - Gradient area fill beneath trajectory
 * - Y-Axis weight ticks with labels (e.g. 40 kg, 30 kg, 20 kg) & horizontal gridlines
 * - X-Axis date markers
 * - Interactive scrubbing / touch inspection with floating tooltip badge
 * - Benchmark target growth dashed trajectory corridor
 * - Responds smoothly to single-point or multiple points
 */
@Composable
fun GoatWeightGrowthChart(
    weights: List<GoatWeight>,
    modifier: Modifier = Modifier,
    benchmarkBreed: String? = null,
    onPointSelected: ((GoatWeight?) -> Unit)? = null
) {
    if (weights.isEmpty()) {
        Box(
            modifier = modifier
                .fillMaxWidth()
                .background(Color(0xFFF8FAFC), RoundedCornerShape(10.dp))
                .padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Icon(Icons.Default.Scale, contentDescription = null, tint = Color(0xFF94A3B8), modifier = Modifier.size(32.dp))
                Text("No historical weight points recorded yet", fontSize = 12.sp, fontWeight = FontWeight.Medium, color = Color(0xFF64748B))
                Text("Log periodic weights to generate the growth curve", fontSize = 11.sp, color = Color(0xFF94A3B8))
            }
        }
        return
    }

    // Sort ascending by date
    val sortedWeights = remember(weights) { weights.sortedBy { it.date_c } }
    var selectedIndex by remember { mutableStateOf<Int?>(null) }

    val minWeight = remember(sortedWeights) {
        val min = sortedWeights.minOfOrNull { it.weight_kg_c } ?: 0.0
        (min - 2.0).coerceAtLeast(0.0)
    }
    val maxWeight = remember(sortedWeights) {
        val max = sortedWeights.maxOfOrNull { it.weight_kg_c } ?: 50.0
        (max + 3.0).coerceAtLeast(minWeight + 5.0)
    }

    val selectedWeight = selectedIndex?.let { sortedWeights.getOrNull(it) }

    Column(modifier = modifier.fillMaxWidth()) {
        // Floating / Interactive inspection tooltip bar
        if (selectedWeight != null) {
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = FarmGreenDark,
                contentColor = Color.White,
                modifier = Modifier
                    .align(Alignment.CenterHorizontally)
                    .padding(bottom = 6.dp)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(Icons.Default.Scale, contentDescription = null, modifier = Modifier.size(14.dp), tint = Color.White)
                    Text(
                        text = "${String.format(Locale.US, "%.1f", selectedWeight.weight_kg_c)} kg",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Text("•", fontSize = 11.sp, color = Color.White.copy(alpha = 0.6f))
                    Text(
                        text = selectedWeight.date_c,
                        fontSize = 11.sp,
                        color = Color.White.copy(alpha = 0.9f)
                    )
                    if (!selectedWeight.method_c.isNullOrBlank()) {
                        Text("•", fontSize = 11.sp, color = Color.White.copy(alpha = 0.6f))
                        Text(
                            text = selectedWeight.method_c,
                            fontSize = 11.sp,
                            color = FarmGreenLight
                        )
                    }
                }
            }
        }

        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(180.dp)
                .pointerInput(sortedWeights) {
                    detectTapGestures(
                        onPress = { offset ->
                            val paddingLeft = 40.dp.toPx()
                            val paddingRight = 16.dp.toPx()
                            val graphWidth = size.width - paddingLeft - paddingRight
                            if (sortedWeights.size > 1 && graphWidth > 0) {
                                val touchX = offset.x.coerceIn(paddingLeft, size.width - paddingRight)
                                val ratio = (touchX - paddingLeft) / graphWidth
                                val idx = (ratio * (sortedWeights.size - 1)).roundToInt().coerceIn(0, sortedWeights.size - 1)
                                selectedIndex = idx
                                onPointSelected?.invoke(sortedWeights[idx])
                            } else if (sortedWeights.isNotEmpty()) {
                                selectedIndex = 0
                                onPointSelected?.invoke(sortedWeights[0])
                            }
                        }
                    )
                }
                .pointerInput(sortedWeights) {
                    detectDragGestures(
                        onDragStart = { offset ->
                            val paddingLeft = 40.dp.toPx()
                            val paddingRight = 16.dp.toPx()
                            val graphWidth = size.width - paddingLeft - paddingRight
                            if (sortedWeights.size > 1 && graphWidth > 0) {
                                val touchX = offset.x.coerceIn(paddingLeft, size.width - paddingRight)
                                val ratio = (touchX - paddingLeft) / graphWidth
                                val idx = (ratio * (sortedWeights.size - 1)).roundToInt().coerceIn(0, sortedWeights.size - 1)
                                selectedIndex = idx
                                onPointSelected?.invoke(sortedWeights[idx])
                            }
                        },
                        onDrag = { change, _ ->
                            change.consume()
                            val paddingLeft = 40.dp.toPx()
                            val paddingRight = 16.dp.toPx()
                            val graphWidth = size.width - paddingLeft - paddingRight
                            if (sortedWeights.size > 1 && graphWidth > 0) {
                                val touchX = change.position.x.coerceIn(paddingLeft, size.width - paddingRight)
                                val ratio = (touchX - paddingLeft) / graphWidth
                                val idx = (ratio * (sortedWeights.size - 1)).roundToInt().coerceIn(0, sortedWeights.size - 1)
                                selectedIndex = idx
                                onPointSelected?.invoke(sortedWeights[idx])
                            }
                        }
                    )
                }
        ) {
            val width = size.width
            val height = size.height
            val paddingLeft = 40.dp.toPx()
            val paddingRight = 16.dp.toPx()
            val paddingTop = 16.dp.toPx()
            val paddingBottom = 26.dp.toPx()

            val graphWidth = width - paddingLeft - paddingRight
            val graphHeight = height - paddingTop - paddingBottom

            if (graphWidth <= 0 || graphHeight <= 0) return@Canvas

            val weightRange = (maxWeight - minWeight).coerceAtLeast(1.0)

            // 1. Draw horizontal grid lines & Y-Axis labels
            val gridCount = 4
            val textPaint = android.graphics.Paint().apply {
                color = android.graphics.Color.parseColor("#94A3B8")
                textSize = 9.sp.toPx()
                isAntiAlias = true
                textAlign = android.graphics.Paint.Align.RIGHT
            }
            val datePaint = android.graphics.Paint().apply {
                color = android.graphics.Color.parseColor("#64748B")
                textSize = 9.sp.toPx()
                isAntiAlias = true
                textAlign = android.graphics.Paint.Align.CENTER
            }

            for (i in 0..gridCount) {
                val fraction = i.toFloat() / gridCount
                val y = paddingTop + graphHeight * (1f - fraction)
                val kgValue = minWeight + weightRange * fraction

                // Grid line
                drawLine(
                    color = Color(0xFFE2E8F0),
                    start = Offset(paddingLeft, y),
                    end = Offset(width - paddingRight, y),
                    strokeWidth = 1.dp.toPx(),
                    pathEffect = if (i == 0 || i == gridCount) null else PathEffect.dashPathEffect(floatArrayOf(6f, 6f), 0f)
                )

                // Y-Axis tick label
                drawContext.canvas.nativeCanvas.drawText(
                    "${kgValue.toInt()}kg",
                    paddingLeft - 4.dp.toPx(),
                    y + 3.dp.toPx(),
                    textPaint
                )
            }

            // 2. Draw Target Breed Benchmark Trajectory (dashed guideline)
            val benchmarkStartWeight = minWeight.coerceAtLeast(3.0)
            val benchmarkEndWeight = (maxWeight * 0.95).coerceAtLeast(benchmarkStartWeight + 5.0)
            val benchStartY = paddingTop + graphHeight - (((benchmarkStartWeight - minWeight) / weightRange) * graphHeight).toFloat()
            val benchEndY = paddingTop + graphHeight - (((benchmarkEndWeight - minWeight) / weightRange) * graphHeight).toFloat()

            drawLine(
                color = FarmAmber.copy(alpha = 0.5f),
                start = Offset(paddingLeft, benchStartY),
                end = Offset(width - paddingRight, benchEndY),
                strokeWidth = 1.5.dp.toPx(),
                pathEffect = PathEffect.dashPathEffect(floatArrayOf(8f, 8f), 0f)
            )

            // 3. Calculate Point Coordinates
            val points = sortedWeights.mapIndexed { index, item ->
                val x = if (sortedWeights.size == 1) {
                    paddingLeft + graphWidth / 2f
                } else {
                    paddingLeft + (index.toFloat() / (sortedWeights.size - 1)) * graphWidth
                }
                val y = paddingTop + graphHeight - (((item.weight_kg_c - minWeight) / weightRange) * graphHeight).toFloat()
                Offset(x, y)
            }

            // 4. Draw D3-style Monotone Cubic Bezier Spline and Area Gradient
            if (points.size >= 2) {
                // Gradient Area Fill
                val fillPath = Path().apply {
                    moveTo(points.first().x, paddingTop + graphHeight)
                    lineTo(points.first().x, points.first().y)
                    for (i in 0 until points.size - 1) {
                        val p0 = points[i]
                        val p1 = points[i + 1]
                        val cx1 = p0.x + (p1.x - p0.x) / 2f
                        val cy1 = p0.y
                        val cx2 = p0.x + (p1.x - p0.x) / 2f
                        val cy2 = p1.y
                        cubicTo(cx1, cy1, cx2, cy2, p1.x, p1.y)
                    }
                    lineTo(points.last().x, paddingTop + graphHeight)
                    close()
                }

                drawPath(
                    path = fillPath,
                    brush = Brush.verticalGradient(
                        colors = listOf(
                            FarmGreenPrimary.copy(alpha = 0.35f),
                            FarmGreenLight.copy(alpha = 0.04f)
                        ),
                        startY = paddingTop,
                        endY = paddingTop + graphHeight
                    )
                )

                // Smooth Spline Line
                val strokePath = Path().apply {
                    moveTo(points.first().x, points.first().y)
                    for (i in 0 until points.size - 1) {
                        val p0 = points[i]
                        val p1 = points[i + 1]
                        val cx1 = p0.x + (p1.x - p0.x) / 2f
                        val cy1 = p0.y
                        val cx2 = p0.x + (p1.x - p0.x) / 2f
                        val cy2 = p1.y
                        cubicTo(cx1, cy1, cx2, cy2, p1.x, p1.y)
                    }
                }

                drawPath(
                    path = strokePath,
                    color = FarmGreenDark,
                    style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round)
                )
            } else if (points.size == 1) {
                // Single point baseline projection line
                val singlePt = points.first()
                drawLine(
                    color = FarmGreenDark.copy(alpha = 0.3f),
                    start = Offset(paddingLeft, singlePt.y),
                    end = Offset(width - paddingRight, singlePt.y),
                    strokeWidth = 1.dp.toPx(),
                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(4f, 4f), 0f)
                )
            }

            // 5. Draw Interactive Crosshair if point selected
            selectedIndex?.let { idx ->
                if (idx in points.indices) {
                    val activePt = points[idx]
                    drawLine(
                        color = FarmGreenDark.copy(alpha = 0.6f),
                        start = Offset(activePt.x, paddingTop),
                        end = Offset(activePt.x, paddingTop + graphHeight),
                        strokeWidth = 1.5.dp.toPx(),
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(4f, 4f), 0f)
                    )
                }
            }

            // 6. Draw Data Nodes
            points.forEachIndexed { index, pt ->
                val isSelected = (index == selectedIndex)
                if (isSelected) {
                    // Outer glow ring
                    drawCircle(
                        color = FarmGreenLight.copy(alpha = 0.4f),
                        radius = 8.dp.toPx(),
                        center = pt
                    )
                    // Mid ring
                    drawCircle(
                        color = Color.White,
                        radius = 5.5.dp.toPx(),
                        center = pt
                    )
                    // Center core
                    drawCircle(
                        color = FarmGreenDark,
                        radius = 4.dp.toPx(),
                        center = pt
                    )
                } else {
                    // Standard node
                    drawCircle(
                        color = Color.White,
                        radius = 4.5.dp.toPx(),
                        center = pt
                    )
                    drawCircle(
                        color = FarmGreenDark,
                        radius = 3.dp.toPx(),
                        center = pt
                    )
                }

                // X-Axis date label
                val shouldShowDate = points.size <= 4 || index == 0 || index == points.size - 1 || index == points.size / 2
                if (shouldShowDate) {
                    val rawDate = sortedWeights[index].date_c
                    val shortDate = try {
                        val sdfIn = SimpleDateFormat("yyyy-MM-dd", Locale.US)
                        val d = sdfIn.parse(rawDate) ?: Date()
                        val sdfOut = SimpleDateFormat("dd MMM", Locale.US)
                        sdfOut.format(d)
                    } catch (_: Exception) { rawDate }

                    drawContext.canvas.nativeCanvas.drawText(
                        shortDate,
                        pt.x,
                        height - 4.dp.toPx(),
                        datePaint
                    )
                }
            }
        }
    }
}

/**
 * Prominent Weight Trends Line Chart Card for Goat Profile Overview.
 * Provides D3-style smooth cubic bezier curve, interactive tooltips, timeframe filters,
 * and quick-add weigh-in modal.
 */
@Composable
fun GoatWeightTrendsCard(
    goat: Goat,
    weights: List<GoatWeight>,
    onRecordNewWeight: (weightKg: Double, dateStr: String, method: String, notes: String?) -> Unit,
    onNavigateToFullHistory: (() -> Unit)? = null,
    onNavigateToTrends: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    var showRecordWeightDialog by remember { mutableStateOf(false) }
    var selectedFilter by remember { mutableStateOf("All") } // "All", "90D", "30D"
    var chartEngine by remember { mutableStateOf("Recharts") } // "Recharts" default, or "Canvas"

    val sortedAsc = remember(weights) { weights.sortedBy { it.date_c } }
    val sortedDesc = remember(weights) { weights.sortedByDescending { it.date_c } }

    val activeBenchmark = remember(goat) {
        val goatBreed = goat.breed_c.orEmpty()
        DefaultBreedBenchmarks.find { it.breedName.equals(goatBreed, ignoreCase = true) }
            ?: DefaultBreedBenchmarks.firstOrNull { goatBreed.contains(it.breedName, ignoreCase = true) }
            ?: DefaultBreedBenchmarks.last()
    }

    val filteredWeights = remember(sortedAsc, selectedFilter) {
        if (selectedFilter == "All" || sortedAsc.isEmpty()) {
            sortedAsc
        } else {
            val daysLimit = if (selectedFilter == "30D") 30 else 90
            val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
            val now = Date()
            sortedAsc.filter {
                try {
                    val d = sdf.parse(it.date_c) ?: return@filter true
                    val diffDays = TimeUnit.MILLISECONDS.toDays(now.time - d.time)
                    diffDays <= daysLimit
                } catch (_: Exception) { true }
            }
        }
    }

    val currentWeight = sortedDesc.firstOrNull()?.weight_kg_c ?: goat.weight_kg_c
    val initialWeight = sortedAsc.firstOrNull()?.weight_kg_c ?: goat.weight_kg_c
    val totalGain = if (currentWeight != null && initialWeight != null && sortedAsc.size > 1) {
        currentWeight - initialWeight
    } else null

    // Overall Average Daily Gain (ADG)
    val overallAdgGramsPerDay = remember(sortedAsc) {
        if (sortedAsc.size >= 2) {
            val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
            try {
                val first = sortedAsc.first()
                val last = sortedAsc.last()
                val d1 = sdf.parse(first.date_c) ?: Date()
                val d2 = sdf.parse(last.date_c) ?: Date()
                val days = TimeUnit.MILLISECONDS.toDays(d2.time - d1.time).toInt()
                if (days > 0) {
                    val gainKg = last.weight_kg_c - first.weight_kg_c
                    ((gainKg * 1000.0) / days).toInt()
                } else null
            } catch (_: Exception) { null }
        } else null
    }

    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = modifier
            .fillMaxWidth()
            .testTag("goat_profile_weight_trends_card")
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Header Row: Title + "Log Weight" CTA Button
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Surface(
                        shape = CircleShape,
                        color = FarmGreenPrimary.copy(alpha = 0.12f),
                        modifier = Modifier.size(36.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(Icons.Default.Scale, contentDescription = null, tint = FarmGreenDark, modifier = Modifier.size(20.dp))
                        }
                    }
                    Column {
                        Text(
                            text = "Weight History & Trends",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = FarmGreenDark
                        )
                        Text(
                            text = if (weights.isNotEmpty()) "${weights.size} weigh-in logs • Last: ${sortedDesc.first().date_c}"
                                   else "Baseline registered weight: ${goat.weight_kg_c ?: "--"} kg",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Button(
                    onClick = { showRecordWeightDialog = true },
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = FarmGreenDark),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                    modifier = Modifier.height(34.dp).testTag("btn_log_weight_overview")
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(15.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Log Weight", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }

            HorizontalDivider(color = Color(0xFFF1F5F9))

            // KPI Metrics Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Current Weight
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = Color(0xFFF8FAFC),
                    border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
                    modifier = Modifier.weight(1f)
                ) {
                    Column(
                        modifier = Modifier.padding(8.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("Current", fontSize = 10.sp, color = Color.Gray, fontWeight = FontWeight.SemiBold)
                        Text(
                            text = if (currentWeight != null) "${String.format(Locale.US, "%.1f", currentWeight)} kg" else "--",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = FarmGreenDark
                        )
                    }
                }

                // Total Gain
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = if (totalGain != null && totalGain >= 0) Color(0xFFF0FDF4) else Color(0xFFF8FAFC),
                    border = BorderStroke(1.dp, if (totalGain != null && totalGain >= 0) Color(0xFFBBF7D0) else Color(0xFFE2E8F0)),
                    modifier = Modifier.weight(1f)
                ) {
                    Column(
                        modifier = Modifier.padding(8.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("Total Gain", fontSize = 10.sp, color = Color.Gray, fontWeight = FontWeight.SemiBold)
                        val gainStr = if (totalGain != null) {
                            "${if (totalGain >= 0) "+" else ""}${String.format(Locale.US, "%.1f", totalGain)} kg"
                        } else "--"
                        Text(
                            text = gainStr,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = if (totalGain != null && totalGain >= 0) Color(0xFF15803D) else Color.DarkGray
                        )
                    }
                }

                // ADG
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = Color(0xFFF8FAFC),
                    border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
                    modifier = Modifier.weight(1f)
                ) {
                    Column(
                        modifier = Modifier.padding(8.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("Daily Gain (ADG)", fontSize = 10.sp, color = Color.Gray, fontWeight = FontWeight.SemiBold)
                        Text(
                            text = if (overallAdgGramsPerDay != null) "${overallAdgGramsPerDay} g/d" else "--",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = Color(0xFF2563EB)
                        )
                    }
                }
            }

            // Timeframe filters & Chart Engine Switcher
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    listOf("All", "90D", "30D").forEach { f ->
                        FilterChip(
                            selected = selectedFilter == f,
                            onClick = { selectedFilter = f },
                            label = { Text(f, fontSize = 10.sp, fontWeight = FontWeight.SemiBold) },
                            modifier = Modifier.height(28.dp).testTag("weight_filter_$f")
                        )
                    }
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    FilterChip(
                        selected = chartEngine == "Recharts",
                        onClick = { chartEngine = "Recharts" },
                        leadingIcon = {
                            Icon(
                                Icons.AutoMirrored.Filled.TrendingUp,
                                contentDescription = null,
                                modifier = Modifier.size(12.dp)
                            )
                        },
                        label = { Text("Recharts", fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                        modifier = Modifier.height(28.dp).testTag("toggle_recharts_engine")
                    )
                    FilterChip(
                        selected = chartEngine == "Canvas",
                        onClick = { chartEngine = "Canvas" },
                        label = { Text("Canvas", fontSize = 10.sp) },
                        modifier = Modifier.height(28.dp).testTag("toggle_canvas_engine")
                    )
                }
            }

            // D3/Recharts-style Line Chart
            val chartWeights = if (filteredWeights.isNotEmpty()) filteredWeights
            else if (goat.weight_kg_c != null && goat.weight_kg_c > 0) {
                listOf(
                    GoatWeight(
                        id = "baseline",
                        goat_id_c = goat.id,
                        weight_kg_c = goat.weight_kg_c,
                        date_c = goat.birth_date_c ?: SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date()),
                        method_c = "Initial Registration"
                    )
                )
            } else emptyList()

            val rechartsPoints = remember(chartWeights, activeBenchmark, goat) {
                if (chartWeights.isEmpty()) emptyList()
                else {
                    val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
                    val firstWeight = chartWeights.first()
                    val firstDate = try { sdf.parse(firstWeight.date_c) ?: Date() } catch (_: Exception) { Date() }
                    val birthDate = goat.birth_date_c?.let {
                        try { sdf.parse(it) } catch (_: Exception) { null }
                    }

                    chartWeights.mapIndexed { idx, item ->
                        val itemDate = try { sdf.parse(item.date_c) ?: Date() } catch (_: Exception) { Date() }
                        val expected = if (birthDate != null) {
                            val ageDays = TimeUnit.MILLISECONDS.toDays(itemDate.time - birthDate.time).toInt()
                            activeBenchmark.calculateExpectedWeight(ageDays)
                        } else {
                            val elapsedDays = TimeUnit.MILLISECONDS.toDays(itemDate.time - firstDate.time).toInt()
                            activeBenchmark.calculateExpectedWeightFromStart(firstWeight.weight_kg_c, elapsedDays)
                        }
                        val varianceKg = item.weight_kg_c - expected
                        val variancePct = if (expected > 0) (varianceKg / expected) * 100.0 else 0.0

                        val prevItem = if (idx > 0) chartWeights[idx - 1] else null
                        val gainSinceLast = prevItem?.let { item.weight_kg_c - it.weight_kg_c }
                        val daysSinceLast = prevItem?.let {
                            val prevDate = try { sdf.parse(it.date_c) ?: Date() } catch (_: Exception) { Date() }
                            TimeUnit.MILLISECONDS.toDays(itemDate.time - prevDate.time).coerceAtLeast(1L)
                        }
                        val intervalAdg = if (gainSinceLast != null && daysSinceLast != null && daysSinceLast > 0) {
                            ((gainSinceLast * 1000.0) / daysSinceLast).toInt()
                        } else null

                        RechartsChartPoint(
                            id = item.id,
                            dateStr = item.date_c,
                            timestamp = itemDate.time,
                            actualWeightKg = item.weight_kg_c,
                            expectedWeightKg = ((expected * 10.0).roundToInt()) / 10.0,
                            varianceKg = ((varianceKg * 10.0).roundToInt()) / 10.0,
                            variancePct = ((variancePct * 10.0).roundToInt()) / 10.0,
                            gainSinceLastKg = gainSinceLast?.let { ((it * 10.0).roundToInt()) / 10.0 },
                            intervalDays = daysSinceLast,
                            intervalAdgGrams = intervalAdg,
                            method = item.method_c,
                            notes = item.notes_c
                        )
                    }
                }
            }

            // Chart Rendering
            if (chartEngine == "Recharts" && rechartsPoints.isNotEmpty()) {
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = Color(0xFFF8FAFC),
                    border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(8.dp)) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 4.dp, vertical = 2.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Surface(shape = CircleShape, color = Color(0xFF10B981), modifier = Modifier.size(8.dp)) {}
                                Text("Weight (kg)", fontSize = 10.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFF1E293B))
                                Surface(shape = CircleShape, color = FarmAmber, modifier = Modifier.size(8.dp)) {}
                                Text("${activeBenchmark.breedName} Target", fontSize = 10.sp, color = FarmAmber, fontWeight = FontWeight.SemiBold)
                            }

                            if (onNavigateToTrends != null) {
                                TextButton(
                                    onClick = onNavigateToTrends,
                                    contentPadding = PaddingValues(horizontal = 4.dp, vertical = 0.dp),
                                    modifier = Modifier.height(24.dp).testTag("btn_open_recharts_trends")
                                ) {
                                    Text("Full Analytics ↗", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color(0xFF0284C7))
                                }
                            }
                        }

                        RechartsWebInteractiveChart(
                            points = rechartsPoints,
                            breedName = goat.breed_c ?: "General Meat",
                            marketTargetKg = activeBenchmark.marketTargetWeightKg,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(210.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .testTag("overview_goat_recharts_chart")
                        )
                    }
                }
            } else {
                GoatWeightGrowthChart(
                    weights = chartWeights,
                    benchmarkBreed = goat.breed_c,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(180.dp)
                        .testTag("overview_goat_weight_chart")
                )
            }

            // Hint for interactive scrubbing
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (chartEngine == "Recharts") "💡 Tap points on the Recharts graph to inspect exact weights & variance"
                           else "💡 Tap or drag across chart to inspect point details",
                    fontSize = 10.sp,
                    color = Color(0xFF94A3B8)
                )

                if (onNavigateToFullHistory != null && weights.isNotEmpty()) {
                    TextButton(
                        onClick = onNavigateToFullHistory,
                        contentPadding = PaddingValues(0.dp)
                    ) {
                        Text("Full History →", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = FarmGreenDark)
                    }
                }
            }
        }
    }

    if (showRecordWeightDialog) {
        RecordWeightModalDialog(
            defaultDate = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date()),
            lastWeightKg = currentWeight ?: 25.0,
            onDismiss = { showRecordWeightDialog = false },
            onSave = { kg, dateStr, method, notes ->
                onRecordNewWeight(kg, dateStr, method, notes)
                showRecordWeightDialog = false
            }
        )
    }
}

/**
 * Modal dialog for logging a new weight measurement into Room.
 */
@Composable
fun RecordWeightModalDialog(
    defaultDate: String,
    lastWeightKg: Double,
    onDismiss: () -> Unit,
    onSave: (weightKg: Double, dateStr: String, method: String, notes: String?) -> Unit
) {
    var weightInput by remember { mutableStateOf(if (lastWeightKg > 0) String.format(Locale.US, "%.1f", lastWeightKg) else "25.0") }
    var dateInput by remember { mutableStateOf(defaultDate) }
    var selectedMethod by remember { mutableStateOf("Digital Scale") }
    var notesInput by remember { mutableStateOf("") }

    val methods = listOf("Digital Scale", "Weigh Tape", "Visual Estimate")

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(Icons.Default.Scale, contentDescription = null, tint = FarmGreenDark)
                Text("Log Goat Weight", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "Record body weight to track growth velocity, ADG, and medication dosages.",
                    fontSize = 12.sp,
                    color = Color.Gray
                )

                // Weight Input with Quick Adjusters
                OutlinedTextField(
                    value = weightInput,
                    onValueChange = { weightInput = it },
                    label = { Text("Weight (kg) *") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    modifier = Modifier.fillMaxWidth().testTag("input_weight_kg")
                )

                // Quick Increment/Decrement Buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    val currentVal = weightInput.toDoubleOrNull() ?: 0.0
                    OutlinedButton(
                        onClick = {
                            val newVal = (currentVal - 0.5).coerceAtLeast(0.5)
                            weightInput = String.format(Locale.US, "%.1f", newVal)
                        },
                        modifier = Modifier.weight(1f),
                        contentPadding = PaddingValues(vertical = 4.dp)
                    ) {
                        Text("-0.5 kg", fontSize = 11.sp)
                    }
                    OutlinedButton(
                        onClick = {
                            val newVal = currentVal + 0.5
                            weightInput = String.format(Locale.US, "%.1f", newVal)
                        },
                        modifier = Modifier.weight(1f),
                        contentPadding = PaddingValues(vertical = 4.dp)
                    ) {
                        Text("+0.5 kg", fontSize = 11.sp)
                    }
                    OutlinedButton(
                        onClick = {
                            val newVal = currentVal + 1.0
                            weightInput = String.format(Locale.US, "%.1f", newVal)
                        },
                        modifier = Modifier.weight(1f),
                        contentPadding = PaddingValues(vertical = 4.dp)
                    ) {
                        Text("+1.0 kg", fontSize = 11.sp)
                    }
                }

                // Date Picker
                DatePickerField(
                    dateValue = dateInput,
                    onDateSelected = { dateInput = it },
                    label = "Weighing Date"
                )

                // Method Selection
                Text("Weighing Method:", fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    methods.forEach { m ->
                        FilterChip(
                            selected = selectedMethod == m,
                            onClick = { selectedMethod = m },
                            label = { Text(m, fontSize = 11.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = FarmGreenPrimary,
                                selectedLabelColor = Color.White
                            )
                        )
                    }
                }

                OutlinedTextField(
                    value = notesInput,
                    onValueChange = { notesInput = it },
                    label = { Text("Clinical Notes / BCS") },
                    placeholder = { Text("e.g. Body Condition Score 3.5; thriving pasture growth.") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val kg = weightInput.toDoubleOrNull()
                    if (kg != null && kg > 0.0) {
                        onSave(kg, dateInput, selectedMethod, notesInput.ifBlank { null })
                    }
                },
                enabled = (weightInput.toDoubleOrNull() ?: 0.0) > 0.0,
                colors = ButtonDefaults.buttonColors(containerColor = FarmGreenPrimary),
                modifier = Modifier.testTag("btn_save_weight_entry")
            ) {
                Text("Save Weight Record")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
