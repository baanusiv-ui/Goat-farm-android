package com.example.ui.screens

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.TrendingDown
import androidx.compose.material.icons.automirrored.filled.TrendingUp
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.supabase.*
import com.example.i18n.t
import com.example.ui.components.DatePickerField
import com.example.ui.components.FarmTopBar
import com.example.ui.theme.*
import com.example.util.CurrencyUtils
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FinanceScreen(
    repository: GoatRepository,
    onNavigateBack: () -> Unit,
    onNavigateToSales: () -> Unit = {},
    onNavigateToAssets: () -> Unit = {},
    onNavigateToCashBank: () -> Unit = {},
    onNavigateToRecurring: () -> Unit = {},
    onNavigateToEb: () -> Unit = {},
    onNavigateToLoans: () -> Unit = {},
    onNavigateToSuppliers: () -> Unit = {},
    onNavigateToGst: () -> Unit = {},
    onNavigateToEWay: () -> Unit = {},
    onNavigateToReports: () -> Unit = {},
    onNavigateToPaymentsDue: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    BackHandler { onNavigateBack() }

    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val dateFormat = remember { SimpleDateFormat("yyyy-MM-dd", Locale.US) }
    val today = remember { dateFormat.format(Date()) }

    var financeSummary by remember { mutableStateOf(FarmFinanceSummary()) }
    var transactions by remember { mutableStateOf<List<FinanceTransaction>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    // Filter states
    var selectedFilter by remember { mutableStateOf("ALL") } // ALL, INCOME, EXPENSE, FEED, HEALTH, MANURE, SALES
    var showAddDialog by remember { mutableStateOf(false) }
    var addDialogIsIncome by remember { mutableStateOf(false) }
    var showManureSaleDialog by remember { mutableStateOf(false) }
    var transactionToDelete by remember { mutableStateOf<FinanceTransaction?>(null) }

    fun loadData() {
        isLoading = true
        errorMessage = null
        coroutineScope.launch {
            val sumRes = repository.getFarmFinanceSummary()
            if (sumRes.isSuccess) {
                financeSummary = sumRes.getOrThrow()
            } else {
                errorMessage = sumRes.exceptionOrNull()?.message
            }

            val txRes = repository.getFinanceTransactions()
            if (txRes.isSuccess) {
                transactions = txRes.getOrThrow().sortedByDescending { it.date_c }
            }
            isLoading = false
        }
    }

    LaunchedEffect(Unit) {
        loadData()
    }

    val filteredTransactions = remember(transactions, selectedFilter) {
        when (selectedFilter) {
            "INCOME" -> transactions.filter { it.type_c.equals("INCOME", ignoreCase = true) || it.type_c.equals("Sale", ignoreCase = true) }
            "EXPENSE" -> transactions.filter { it.type_c.equals("EXPENSE", ignoreCase = true) || it.type_c.equals("Purchase", ignoreCase = true) }
            "FEED" -> transactions.filter { it.category_c.contains("Feed", ignoreCase = true) || it.category_c.contains("Fodder", ignoreCase = true) }
            "HEALTH" -> transactions.filter { it.category_c.contains("Med", ignoreCase = true) || it.category_c.contains("Vet", ignoreCase = true) }
            "MANURE" -> transactions.filter { it.category_c.contains("Manure", ignoreCase = true) || it.category_c.contains("Dung", ignoreCase = true) || it.category_c.contains("Compost", ignoreCase = true) }
            "SALES" -> transactions.filter { it.category_c.contains("Goat", ignoreCase = true) || it.category_c.contains("Sale", ignoreCase = true) }
            else -> transactions
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = t("finance.title"),
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp
                        )
                        Text(
                            text = t("finance.subtitle"),
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                navigationIcon = {
                    IconButton(
                        onClick = onNavigateBack,
                        modifier = Modifier.testTag("finance_btn_back")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = t("btn.back")
                        )
                    }
                },
                actions = {
                    IconButton(
                        onClick = { loadData() },
                        modifier = Modifier.testTag("finance_btn_refresh")
                    ) {
                        Icon(Icons.Default.Refresh, contentDescription = t("btn.refresh"))
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = FarmSurfaceLight,
                    titleContentColor = FarmGreenDark
                )
            )
        },
        containerColor = Color(0xFFF8F9FA),
        modifier = modifier
    ) { innerPadding ->
        if (isLoading) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator(color = FarmGreenPrimary)
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .testTag("finance_screen_list"),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // 1. Master Profit & Loss Hero Card
                item {
                    ProfitLossHeroCard(
                        summary = financeSummary,
                        onAddIncome = {
                            addDialogIsIncome = true
                            showAddDialog = true
                        },
                        onAddExpense = {
                            addDialogIsIncome = false
                            showAddDialog = true
                        },
                        onLogManureSale = { showManureSaleDialog = true },
                        onNavigateToSales = onNavigateToSales
                    )
                }

                // 2. Cash Flow & Inflow/Outflow Breakdown Card
                item {
                    CashFlowOverviewCard(summary = financeSummary)
                }

                // 2.5 Farm Assets & Infrastructure (CAPEX) Card
                item {
                    Card(
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFEDE7F6)),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFD1C4E9)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onNavigateToAssets() }
                            .testTag("finance_farm_assets_card")
                    ) {
                        Row(
                            modifier = Modifier
                                .padding(16.dp)
                                .fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Surface(
                                    shape = CircleShape,
                                    color = Color(0xFF5E35B1),
                                    modifier = Modifier.size(36.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(
                                            imageVector = Icons.Default.Apartment,
                                            contentDescription = null,
                                            tint = Color.White,
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(
                                        text = "Farm Assets & Infrastructure",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp,
                                        color = Color(0xFF311B92)
                                    )
                                    Text(
                                        text = "CAPEX • Sheds, Equipment, Vehicles & Depreciation",
                                        fontSize = 11.sp,
                                        color = Color(0xFF512DA8)
                                    )
                                }
                            }
                            Icon(
                                imageVector = Icons.Default.ChevronRight,
                                contentDescription = null,
                                tint = Color(0xFF5E35B1)
                            )
                        }
                    }
                }

                // 2.7 Financial Management & Accounting Modules Grid
                item {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            text = "Financial Modules & Ledgers",
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            color = FarmGreenDark
                        )
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            FinanceModuleActionCard(
                                title = "Cash & Bank",
                                subtitle = "Multi-Account & Transfers",
                                icon = Icons.Default.AccountBalance,
                                color = Color(0xFF1E3A8A),
                                bgColor = Color(0xFFEFF6FF),
                                modifier = Modifier.weight(1f).testTag("card_module_cash_bank"),
                                onClick = onNavigateToCashBank
                            )
                            FinanceModuleActionCard(
                                title = "Recurring",
                                subtitle = "EB, Salaries & EMIs",
                                icon = Icons.Default.Update,
                                color = Color(0xFF047857),
                                bgColor = Color(0xFFECFDF5),
                                modifier = Modifier.weight(1f).testTag("card_module_recurring"),
                                onClick = onNavigateToRecurring
                            )
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            FinanceModuleActionCard(
                                title = "Electricity / EB",
                                subtitle = "Meters & Unit Billing",
                                icon = Icons.Default.Bolt,
                                color = Color(0xFFB45309),
                                bgColor = Color(0xFFFFFBEB),
                                modifier = Modifier.weight(1f).testTag("card_module_eb"),
                                onClick = onNavigateToEb
                            )
                            FinanceModuleActionCard(
                                title = "Loans & Debt",
                                subtitle = "Schedules & Amortization",
                                icon = Icons.Default.MonetizationOn,
                                color = Color(0xFF6B21A8),
                                bgColor = Color(0xFFF3E8FF),
                                modifier = Modifier.weight(1f).testTag("card_module_loans"),
                                onClick = onNavigateToLoans
                            )
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            FinanceModuleActionCard(
                                title = "Creditors",
                                subtitle = "Suppliers & Ageing",
                                icon = Icons.Default.Storefront,
                                color = Color(0xFF991B1B),
                                bgColor = Color(0xFFFEF2F2),
                                modifier = Modifier.weight(1f).testTag("card_module_suppliers"),
                                onClick = onNavigateToSuppliers
                            )
                            FinanceModuleActionCard(
                                title = "GST Invoicing",
                                subtitle = "Tax Invoices & Rates",
                                icon = Icons.Default.ReceiptLong,
                                color = Color(0xFF0F766E),
                                bgColor = Color(0xFFF0FDFA),
                                modifier = Modifier.weight(1f).testTag("card_module_gst"),
                                onClick = onNavigateToGst
                            )
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            FinanceModuleActionCard(
                                title = "E-Way Bill",
                                subtitle = "Consignments Register",
                                icon = Icons.Default.LocalShipping,
                                color = Color(0xFF374151),
                                bgColor = Color(0xFFF3F4F6),
                                modifier = Modifier.weight(1f).testTag("card_module_eway"),
                                onClick = onNavigateToEWay
                            )
                            FinanceModuleActionCard(
                                title = "Reports & CF",
                                subtitle = "3-Pillar & Statements",
                                icon = Icons.Default.BarChart,
                                color = FarmGreenDark,
                                bgColor = Color(0xFFF1F8E9),
                                modifier = Modifier.weight(1f).testTag("card_module_reports"),
                                onClick = onNavigateToReports
                            )
                        }
                        // Payments Due banner button
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF7ED)),
                            shape = RoundedCornerShape(12.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFFED7AA)),
                            modifier = Modifier.fillMaxWidth().clickable { onNavigateToPaymentsDue() }.testTag("card_module_payments_due")
                        ) {
                            Row(modifier = Modifier.padding(14.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.PendingActions, contentDescription = null, tint = Color(0xFFC2410C))
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column {
                                        Text("Unified Payments Due Center", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color(0xFF9A3412))
                                        Text("One-stop settlement for EB, Suppliers, EMIs & Recurring", fontSize = 11.sp, color = Color(0xFFC2410C))
                                    }
                                }
                                Icon(Icons.Default.ChevronRight, contentDescription = null, tint = Color(0xFF9A3412))
                            }
                        }
                    }
                }

                // 3. Category Breakdown Grid
                item {
                    CategoryBreakdownSection(summary = financeSummary)
                }

                // 4. Filter Chips
                item {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = t("finance.recent_transactions"),
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = FarmGreenDark
                            )
                            Text(
                                text = "${filteredTransactions.size} records",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        LazyRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            val filterOptions = listOf(
                                "ALL" to "All",
                                "INCOME" to "Income (Inflow)",
                                "EXPENSE" to "Expenses (Outflow)",
                                "SALES" to "Goat Sales",
                                "MANURE" to "Manure Sales",
                                "FEED" to "Feed / Fodder",
                                "HEALTH" to "Medicine / Vet"
                            )
                            items(filterOptions) { (key, label) ->
                                FilterChip(
                                    selected = selectedFilter == key,
                                    onClick = { selectedFilter = key },
                                    label = { Text(label, fontSize = 12.sp) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = FarmGreenDark,
                                        selectedLabelColor = Color.White
                                    ),
                                    modifier = Modifier.testTag("filter_chip_$key")
                                )
                            }
                        }
                    }
                }

                // 5. Transaction List
                if (filteredTransactions.isEmpty()) {
                    item {
                        Card(
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier
                                    .padding(32.dp)
                                    .fillMaxWidth(),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.ReceiptLong,
                                    contentDescription = null,
                                    tint = Color.Gray,
                                    modifier = Modifier.size(48.dp)
                                )
                                Text(
                                    text = t("finance.no_transactions"),
                                    fontSize = 14.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                OutlinedButton(
                                    onClick = {
                                        addDialogIsIncome = false
                                        showAddDialog = true
                                    }
                                ) {
                                    Text("+ ${t("finance.add_expense")}")
                                }
                            }
                        }
                    }
                } else {
                    items(filteredTransactions, key = { it.id }) { tx ->
                        TransactionRowCard(
                            transaction = tx,
                            onDelete = { transactionToDelete = tx }
                        )
                    }
                }
            }
        }
    }

    // Add Income / Expense Dialog
    if (showAddDialog) {
        AddTransactionDialog(
            isIncome = addDialogIsIncome,
            today = today,
            onDismiss = { showAddDialog = false },
            onSave = { newTx ->
                coroutineScope.launch {
                    val res = repository.recordFinanceTransaction(newTx)
                    if (res.isSuccess) {
                        Toast.makeText(context, "Recorded successfully", Toast.LENGTH_SHORT).show()
                        showAddDialog = false
                        loadData()
                    } else {
                        Toast.makeText(context, "Error: ${res.exceptionOrNull()?.message}", Toast.LENGTH_LONG).show()
                    }
                }
            }
        )
    }

    // Quick Manure Sale Dialog
    if (showManureSaleDialog) {
        QuickManureSaleDialog(
            today = today,
            onDismiss = { showManureSaleDialog = false },
            onSave = { manureTx ->
                coroutineScope.launch {
                    val res = repository.recordFinanceTransaction(manureTx)
                    if (res.isSuccess) {
                        Toast.makeText(context, "Manure sale recorded successfully", Toast.LENGTH_SHORT).show()
                        showManureSaleDialog = false
                        loadData()
                    } else {
                        Toast.makeText(context, "Error: ${res.exceptionOrNull()?.message}", Toast.LENGTH_LONG).show()
                    }
                }
            }
        )
    }

    // Delete Confirmation Dialog
    transactionToDelete?.let { tx ->
        AlertDialog(
            onDismissRequest = { transactionToDelete = null },
            title = { Text("Delete Transaction", fontWeight = FontWeight.Bold) },
            text = {
                Text("Are you sure you want to delete this ${tx.type_c} of ${CurrencyUtils.formatInr(tx.amount_c)} for ${tx.category_c}?")
            },
            confirmButton = {
                Button(
                    onClick = {
                        val id = tx.id
                        transactionToDelete = null
                        coroutineScope.launch {
                            val delRes = repository.deleteFinanceTransaction(id)
                            if (delRes.isSuccess) {
                                Toast.makeText(context, "Transaction deleted", Toast.LENGTH_SHORT).show()
                                loadData()
                            } else {
                                Toast.makeText(context, "Delete failed: ${delRes.exceptionOrNull()?.message}", Toast.LENGTH_LONG).show()
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = FarmError)
                ) {
                    Text(t("btn.delete"))
                }
            },
            dismissButton = {
                TextButton(onClick = { transactionToDelete = null }) {
                    Text(t("btn.cancel"))
                }
            }
        )
    }
}

/**
 * Hero Card highlighting Profit / Loss, Inflow, Outflow, and Quick Field Action buttons.
 */
@Composable
private fun ProfitLossHeroCard(
    summary: FarmFinanceSummary,
    onAddIncome: () -> Unit,
    onAddExpense: () -> Unit,
    onLogManureSale: () -> Unit,
    onNavigateToSales: () -> Unit
) {
    val isProfit = summary.netProfit >= 0.0

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isProfit) Color(0xFFF1F8E9) else Color(0xFFFFEBEE)
        ),
        border = androidx.compose.foundation.BorderStroke(
            1.5.dp,
            if (isProfit) FarmGreenPrimary else FarmError
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth().testTag("profit_loss_hero_card")
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Net Profit / Loss Header Banner
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        shape = CircleShape,
                        color = if (isProfit) FarmGreenDark else FarmError,
                        modifier = Modifier.size(40.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = if (isProfit) Icons.AutoMirrored.Filled.TrendingUp else Icons.AutoMirrored.Filled.TrendingDown,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = if (isProfit) t("finance.profit") else t("finance.loss"),
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = if (isProfit) FarmGreenDark else FarmError
                        )
                        Text(
                            text = CurrencyUtils.formatInr(summary.netProfit, includeDecimals = false),
                            fontSize = 24.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = if (isProfit) FarmGreenDark else FarmError
                        )
                    }
                }

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = if (isProfit) FarmGreenContainer else FarmErrorContainer
                ) {
                    Text(
                        text = if (isProfit) "NET PROFITABLE" else "NET LOSS",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isProfit) FarmGreenDark else FarmError,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            HorizontalDivider(
                color = if (isProfit) FarmGreenContainer else Color(0xFFFFCDD2),
                thickness = 1.dp
            )

            // Two-column Income vs Expenses summary
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Income Column
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = Color.White,
                    modifier = Modifier.weight(1f)
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.ArrowUpward, contentDescription = null, tint = FarmGreenPrimary, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = t("finance.total_income"),
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Text(
                            text = CurrencyUtils.formatInr(summary.totalIncome, includeDecimals = false),
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            color = FarmGreenDark
                        )
                        Text(
                            text = "Goat Sales: ${CurrencyUtils.formatInr(summary.goatSalesIncome, includeDecimals = false)} • Manure: ${CurrencyUtils.formatInr(summary.manureSalesIncome, includeDecimals = false)}",
                            fontSize = 10.sp,
                            color = Color.DarkGray
                        )
                    }
                }

                // Expenses Column
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = Color.White,
                    modifier = Modifier.weight(1f)
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.ArrowDownward, contentDescription = null, tint = FarmError, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = t("finance.total_expenses"),
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Text(
                            text = CurrencyUtils.formatInr(summary.totalExpenses, includeDecimals = false),
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            color = FarmError
                        )
                        Text(
                            text = "Feed: ${CurrencyUtils.formatInr(summary.feedExpenses, includeDecimals = false)} • Med/Vet: ${CurrencyUtils.formatInr(summary.medicineExpenses + summary.veterinaryExpenses, includeDecimals = false)}",
                            fontSize = 10.sp,
                            color = Color.DarkGray
                        )
                    }
                }
            }

            // Quick Action Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = onAddIncome,
                    colors = ButtonDefaults.buttonColors(containerColor = FarmGreenDark),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.weight(1f).testTag("btn_add_income")
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(t("finance.add_income"), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }

                Button(
                    onClick = onAddExpense,
                    colors = ButtonDefaults.buttonColors(containerColor = FarmBrown),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.weight(1f).testTag("btn_add_expense")
                ) {
                    Icon(Icons.Default.Remove, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(t("finance.add_expense"), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }

            // Secondary Quick Actions (Manure & Goat Sales)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = onLogManureSale,
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.weight(1f).testTag("btn_log_manure_sale")
                ) {
                    Icon(Icons.Default.Eco, contentDescription = null, tint = FarmGreenDark, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(t("finance.log_manure_sale"), fontSize = 11.sp)
                }

                OutlinedButton(
                    onClick = onNavigateToSales,
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.weight(1f).testTag("btn_manage_goat_sales")
                ) {
                    Icon(Icons.Default.Sell, contentDescription = null, tint = FarmGreenPrimary, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Goat Sales Hub", fontSize = 11.sp)
                }
            }
        }
    }
}

/**
 * Cash Flow Overview showing Inflow vs Outflow progress and liquidity position.
 */
@Composable
private fun CashFlowOverviewCard(summary: FarmFinanceSummary) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier.fillMaxWidth().testTag("cash_flow_card")
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = t("finance.cash_flow"),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = FarmGreenDark
                )
                Text(
                    text = "${summary.totalTransactions} recorded entries",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            HorizontalDivider(color = Color(0xFFEEEEEE))

            // Inflow vs Outflow Ratio Bar
            val totalFlow = (summary.totalIncome + summary.totalExpenses).coerceAtLeast(1.0)
            val inflowFraction = (summary.totalIncome / totalFlow).toFloat().coerceIn(0f, 1f)

            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "Inflow (${(inflowFraction * 100).toInt()}%)",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = FarmGreenDark
                    )
                    Text(
                        text = "Outflow (${((1f - inflowFraction) * 100).toInt()}%)",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = FarmError
                    )
                }

                LinearProgressIndicator(
                    progress = { inflowFraction },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(8.dp)
                        .clip(RoundedCornerShape(4.dp)),
                    color = FarmGreenPrimary,
                    trackColor = Color(0xFFFFCDD2)
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = t("finance.cash_position"),
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = CurrencyUtils.formatInr(summary.netCashFlow, includeDecimals = false),
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (summary.netCashFlow >= 0.0) FarmGreenDark else FarmError
                )
            }
        }
    }
}

/**
 * Breakdown of Income Categories & Expense Categories.
 */
@Composable
private fun CategoryBreakdownSection(summary: FarmFinanceSummary) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(
            text = "Financial Category Breakdown",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = FarmGreenDark
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Income Categories Card
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                modifier = Modifier.weight(1f)
            ) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "Income Sources",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = FarmGreenDark
                    )
                    HorizontalDivider(color = Color(0xFFEEEEEE))

                    CategoryAmountRow(label = t("finance.goat_sales"), amount = summary.goatSalesIncome, isIncome = true)
                    CategoryAmountRow(label = t("finance.manure_sales"), amount = summary.manureSalesIncome, isIncome = true)
                    CategoryAmountRow(label = t("finance.other_income"), amount = summary.otherIncome, isIncome = true)
                }
            }

            // Expense Categories Card
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                modifier = Modifier.weight(1f)
            ) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "Expense Heads",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = FarmBrown
                    )
                    HorizontalDivider(color = Color(0xFFEEEEEE))

                    CategoryAmountRow(label = t("finance.feed_expenses"), amount = summary.feedExpenses, isIncome = false)
                    CategoryAmountRow(label = t("finance.medicine_expenses"), amount = summary.medicineExpenses, isIncome = false)
                    CategoryAmountRow(label = t("finance.veterinary_expenses"), amount = summary.veterinaryExpenses, isIncome = false)
                    CategoryAmountRow(label = t("finance.labour_expenses"), amount = summary.labourExpenses, isIncome = false)
                    CategoryAmountRow(label = t("finance.other_expenses"), amount = summary.otherExpenses, isIncome = false)
                }
            }
        }
    }
}

@Composable
private fun CategoryAmountRow(label: String, amount: Double, isIncome: Boolean) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = label, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(
            text = CurrencyUtils.formatInr(amount, includeDecimals = false),
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold,
            color = if (isIncome) FarmGreenDark else Color(0xFF424242)
        )
    }
}

/**
 * Individual Transaction Row Card.
 */
@Composable
private fun TransactionRowCard(
    transaction: FinanceTransaction,
    onDelete: () -> Unit
) {
    val isIncome = transaction.type_c.equals("INCOME", ignoreCase = true) || transaction.type_c.equals("Sale", ignoreCase = true)

    Card(
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier.fillMaxWidth().testTag("transaction_row_${transaction.id}")
    ) {
        Row(
            modifier = Modifier
                .padding(12.dp)
                .fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                Surface(
                    shape = CircleShape,
                    color = if (isIncome) FarmGreenContainer else FarmErrorContainer,
                    modifier = Modifier.size(36.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = if (isIncome) Icons.Default.ArrowUpward else Icons.Default.ArrowDownward,
                            contentDescription = null,
                            tint = if (isIncome) FarmGreenDark else FarmError,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.width(10.dp))

                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = transaction.category_c,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Surface(
                            shape = RoundedCornerShape(4.dp),
                            color = Color(0xFFF5F5F5)
                        ) {
                            Text(
                                text = transaction.payment_mode_c,
                                fontSize = 10.sp,
                                color = Color(0xFF616161),
                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                            )
                        }
                    }

                    if (!transaction.description_c.isNullOrBlank()) {
                        Text(
                            text = transaction.description_c,
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    Text(
                        text = transaction.date_c,
                        fontSize = 11.sp,
                        color = Color.Gray
                    )
                }
            }

            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = "${if (isIncome) "+" else "-"} ${CurrencyUtils.formatInr(transaction.amount_c)}",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = if (isIncome) FarmGreenDark else FarmError
                )

                IconButton(
                    onClick = onDelete,
                    modifier = Modifier.size(24.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.DeleteOutline,
                        contentDescription = t("btn.delete"),
                        tint = Color.Gray,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }
    }
}

/**
 * Dialog to add a new Income or Expense record.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AddTransactionDialog(
    isIncome: Boolean,
    today: String,
    onDismiss: () -> Unit,
    onSave: (FinanceTransaction) -> Unit
) {
    val incomeCategories = listOf("Goat Sale", "Manure / Dung Sale", "Breeding Service", "Farm Tour / Training", "Other Income")
    val expenseCategories = listOf("Feed", "Medicine", "Veterinary", "Labour", "Fodder Plot", "Equipment / Barn", "Other Expense")

    var selectedType by remember { mutableStateOf(if (isIncome) "INCOME" else "EXPENSE") }
    var selectedCategory by remember { mutableStateOf(if (isIncome) incomeCategories.first() else expenseCategories.first()) }
    var amountInput by remember { mutableStateOf("") }
    var dateInput by remember { mutableStateOf(today) }
    var paymentMode by remember { mutableStateOf("CASH") }
    var descriptionInput by remember { mutableStateOf("") }
    var validationError by remember { mutableStateOf<String?>(null) }

    val currentCategories = if (selectedType == "INCOME") incomeCategories else expenseCategories

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = if (selectedType == "INCOME") t("finance.add_income") else t("finance.add_expense"),
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Type Selector Switch
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilterChip(
                        selected = selectedType == "INCOME",
                        onClick = {
                            selectedType = "INCOME"
                            selectedCategory = incomeCategories.first()
                        },
                        label = { Text("Income", fontSize = 12.sp) },
                        colors = FilterChipDefaults.filterChipColors(selectedContainerColor = FarmGreenDark, selectedLabelColor = Color.White),
                        modifier = Modifier.weight(1f)
                    )
                    FilterChip(
                        selected = selectedType == "EXPENSE",
                        onClick = {
                            selectedType = "EXPENSE"
                            selectedCategory = expenseCategories.first()
                        },
                        label = { Text("Expense", fontSize = 12.sp) },
                        colors = FilterChipDefaults.filterChipColors(selectedContainerColor = FarmBrown, selectedLabelColor = Color.White),
                        modifier = Modifier.weight(1f)
                    )
                }

                // Category Chips
                Text(text = t("finance.category"), fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(currentCategories) { cat ->
                        FilterChip(
                            selected = selectedCategory == cat,
                            onClick = { selectedCategory = cat },
                            label = { Text(cat, fontSize = 11.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = if (selectedType == "INCOME") FarmGreenPrimary else FarmBrown,
                                selectedLabelColor = Color.White
                            )
                        )
                    }
                }

                // Amount
                OutlinedTextField(
                    value = amountInput,
                    onValueChange = {
                        amountInput = it
                        validationError = null
                    },
                    label = { Text(t("finance.amount") + " *") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    isError = validationError != null,
                    modifier = Modifier.fillMaxWidth().testTag("finance_amount_input")
                )

                // Date Picker
                DatePickerField(
                    dateValue = dateInput,
                    onDateSelected = { dateInput = it },
                    label = t("finance.date")
                )

                // Payment Mode Selector
                Text(text = t("finance.payment_mode"), fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    val modes = listOf("CASH", "UPI", "BANK")
                    modes.forEach { mode ->
                        FilterChip(
                            selected = paymentMode == mode,
                            onClick = { paymentMode = mode },
                            label = { Text(mode, fontSize = 11.sp) },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                // Description
                OutlinedTextField(
                    value = descriptionInput,
                    onValueChange = { descriptionInput = it },
                    label = { Text(t("finance.description")) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("finance_description_input")
                )

                if (validationError != null) {
                    Text(text = validationError!!, color = FarmError, fontSize = 12.sp)
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val amt = amountInput.toDoubleOrNull()
                    if (amt == null || amt <= 0.0) {
                        validationError = "Please enter a valid amount greater than 0"
                        return@Button
                    }
                    onSave(
                        FinanceTransaction(
                            type_c = selectedType,
                            category_c = selectedCategory,
                            amount_c = amt,
                            date_c = dateInput,
                            payment_mode_c = paymentMode,
                            description_c = descriptionInput.ifBlank { null }
                        )
                    )
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (selectedType == "INCOME") FarmGreenDark else FarmBrown
                ),
                modifier = Modifier.testTag("finance_dialog_save_btn")
            ) {
                Text(t("btn.save"))
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(t("btn.cancel"))
            }
        }
    )
}

/**
 * Quick dialog to record Manure / Compost Sale (units/bags x rate per unit).
 */
@Composable
private fun QuickManureSaleDialog(
    today: String,
    onDismiss: () -> Unit,
    onSave: (FinanceTransaction) -> Unit
) {
    var quantityInput by remember { mutableStateOf("25") }
    var unitType by remember { mutableStateOf("Bags") } // Bags, Trolley, Tons, Kg
    var rateInput by remember { mutableStateOf("120.0") }
    var buyerName by remember { mutableStateOf("") }
    var dateInput by remember { mutableStateOf(today) }
    var paymentMode by remember { mutableStateOf("CASH") }

    val qty = quantityInput.toDoubleOrNull() ?: 0.0
    val rate = rateInput.toDoubleOrNull() ?: 0.0
    val totalAmount = qty * rate

    val unitOptions = listOf("Bags", "Trolley", "Tons", "Kg")

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(t("finance.log_manure_sale"), fontWeight = FontWeight.Bold) },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = quantityInput,
                        onValueChange = { quantityInput = it },
                        label = { Text("Quantity ($unitType) *") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.weight(1.1f)
                    )
                    OutlinedTextField(
                        value = rateInput,
                        onValueChange = { rateInput = it },
                        label = { Text("Rate (₹/$unitType) *") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.weight(1.1f)
                    )
                }

                // Unit selection row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    unitOptions.forEach { unit ->
                        FilterChip(
                            selected = unitType == unit,
                            onClick = { unitType = unit },
                            label = { Text(unit, fontSize = 11.sp) },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = FarmGreenContainer,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Calculated Total:", fontSize = 12.sp, color = FarmGreenDark)
                        Text(
                            text = CurrencyUtils.formatInr(totalAmount),
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = FarmGreenDark
                        )
                    }
                }

                OutlinedTextField(
                    value = buyerName,
                    onValueChange = { buyerName = it },
                    label = { Text("Buyer / Nursery / Farmer Name") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                DatePickerField(
                    dateValue = dateInput,
                    onDateSelected = { dateInput = it },
                    label = t("finance.date")
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    listOf("CASH", "UPI", "BANK").forEach { mode ->
                        FilterChip(
                            selected = paymentMode == mode,
                            onClick = { paymentMode = mode },
                            label = { Text(mode, fontSize = 11.sp) },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (totalAmount <= 0.0) return@Button
                    val desc = "Manure Sale: $quantityInput $unitType @ ₹$rateInput/$unitType${if (buyerName.isNotBlank()) " to $buyerName" else ""}"
                    onSave(
                        FinanceTransaction(
                            type_c = "INCOME",
                            category_c = "Manure / Dung Sale",
                            amount_c = totalAmount,
                            date_c = dateInput,
                            payment_mode_c = paymentMode,
                            description_c = desc
                        )
                    )
                },
                colors = ButtonDefaults.buttonColors(containerColor = FarmGreenDark)
            ) {
                Text(t("btn.save"))
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(t("btn.cancel"))
            }
        }
    )
}

@Composable
private fun FinanceModuleActionCard(
    title: String,
    subtitle: String,
    icon: ImageVector,
    color: Color,
    bgColor: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(12.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = modifier.clickable { onClick() }
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                shape = CircleShape,
                color = bgColor,
                modifier = Modifier.size(36.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(imageVector = icon, contentDescription = null, tint = color, modifier = Modifier.size(20.dp))
                }
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column {
                Text(title, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = color)
                Text(subtitle, fontSize = 10.sp, color = Color.Gray, maxLines = 1)
            }
        }
    }
}

