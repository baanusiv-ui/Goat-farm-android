package com.example.ui.components

import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.supabase.Goat
import com.example.data.supabase.GoatRepository
import com.example.data.supabase.TreatmentRecord
import com.example.ui.theme.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun BatchTreatmentDialog(
    selectedGoats: List<Goat>,
    repository: GoatRepository,
    onDismiss: () -> Unit,
    onSuccess: (count: Int) -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    var isSubmitting by remember { mutableStateOf(false) }

    val todayDate = remember {
        SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
    }

    var symptomsText by remember { mutableStateOf("External Parasites / Ticks") }
    var diagnosisText by remember { mutableStateOf("Parasite Infestation") }
    var medicineText by remember { mutableStateOf("Ivermectin 1%") }
    var doseText by remember { mutableStateOf("1 ml / 10 kg Subcutaneous") }
    var startDateText by remember { mutableStateOf(todayDate) }
    var endDateText by remember { mutableStateOf("") }
    var veterinarianText by remember { mutableStateOf("Dr. Vet / Farm Staff") }
    var outcomeStatus by remember { mutableStateOf("Under Treatment") }
    var meatWithdrawalDays by remember { mutableStateOf("28") }
    var milkWithdrawalDays by remember { mutableStateOf("7") }
    var costPerGoatText by remember { mutableStateOf("") }
    var notesText by remember { mutableStateOf("") }
    var updateGoatStatusToTreatment by remember { mutableStateOf(true) }

    val commonConditions = listOf(
        "External Parasites / Ticks" to ("Parasite Infestation" to "Ivermectin 1%"),
        "Internal Worms / Deworming" to ("Helminthiasis" to "Albendazole 2.5%"),
        "Respiratory / Cough" to ("Caprine Pneumonia" to "Oxytetracycline LA 200"),
        "Diarrhea / Scours" to ("Bacterial Enteritis" to "Sulfamethoxazole-Trimethoprim"),
        "Foot Rot / Lameness" to ("Infectious Pododermatitis" to "Topical Copper Sulphate & Penicillin"),
        "Wound / Abscess" to ("Skin Trauma" to "Povidone Iodine & Antiseptic Spray"),
        "Vitamin Deficiency" to ("Nutritional Deficit" to "Vitamin AD3E + B-Complex Injectable")
    )

    val commonMedicines = listOf(
        "Ivermectin 1%",
        "Albendazole 2.5%",
        "Oxytetracycline LA",
        "Penicillin Procaine",
        "Meloxicam",
        "Topical Antiseptic",
        "Vitamin AD3E",
        "Dewormer Suspension"
    )

    val commonDoses = listOf(
        "1 ml / 10 kg SC",
        "5 ml Oral Drench",
        "2 ml Deep IM",
        "1 ml / 20 kg IM",
        "Topical application"
    )

    Dialog(
        onDismissRequest = { if (!isSubmitting) onDismiss() },
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .fillMaxHeight(0.94f)
                .testTag("batch_treatment_dialog"),
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 6.dp
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(20.dp)
            ) {
                // Header Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(Color(0xFFE3F2FD)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Medication,
                                contentDescription = null,
                                tint = Color(0xFF1565C0),
                                modifier = Modifier.size(24.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "Batch Treatment Note",
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Recording medication for ${selectedGoats.size} goats",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    IconButton(
                        onClick = onDismiss,
                        enabled = !isSubmitting,
                        modifier = Modifier.testTag("btn_close_batch_treatment_dialog")
                    ) {
                        Icon(Icons.Default.Close, contentDescription = "Close")
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Scrollable Form Content
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    // Selected Goats Badge Summary
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFE8EAF6)),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(
                                text = "Treated Goats (${selectedGoats.size}):",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF283593)
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            FlowRow(
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                selectedGoats.forEach { goat ->
                                    Surface(
                                        shape = RoundedCornerShape(8.dp),
                                        color = Color.White,
                                        border = BorderStroke(1.dp, Color(0xFF3949AB).copy(alpha = 0.3f))
                                    ) {
                                        Text(
                                            text = "${goat.tag_c} (${goat.name.ifBlank { goat.breed_c }})",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.SemiBold,
                                            color = Color(0xFF283593),
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // Preset Templates
                    Column {
                        Text(
                            text = "Condition Quick Presets",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            commonConditions.forEach { (conditionName, pair) ->
                                val (diag, med) = pair
                                val isSelected = symptomsText == conditionName
                                FilterChip(
                                    selected = isSelected,
                                    onClick = {
                                        symptomsText = conditionName
                                        diagnosisText = diag
                                        medicineText = med
                                    },
                                    label = { Text(conditionName, fontSize = 11.sp) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = Color(0xFFBBDEFB),
                                        selectedLabelColor = Color(0xFF0D47A1)
                                    ),
                                    modifier = Modifier.testTag("preset_${conditionName.take(10).lowercase().replace(" ", "_")}")
                                )
                            }
                        }
                    }

                    // Symptoms and Diagnosis Fields
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedTextField(
                            value = symptomsText,
                            onValueChange = { symptomsText = it },
                            label = { Text("Symptoms / Reason") },
                            placeholder = { Text("e.g. Parasite ticks") },
                            singleLine = true,
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("input_batch_treatment_symptoms")
                        )

                        OutlinedTextField(
                            value = diagnosisText,
                            onValueChange = { diagnosisText = it },
                            label = { Text("Diagnosis") },
                            placeholder = { Text("e.g. Parasite Infestation") },
                            singleLine = true,
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("input_batch_treatment_diagnosis")
                        )
                    }

                    // Medicine Selector and Chips
                    Column {
                        OutlinedTextField(
                            value = medicineText,
                            onValueChange = { medicineText = it },
                            label = { Text("Medicine / Product Name *") },
                            placeholder = { Text("e.g. Ivermectin 1%") },
                            singleLine = true,
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("input_batch_treatment_medicine")
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            commonMedicines.forEach { med ->
                                SuggestionChip(
                                    onClick = { medicineText = med },
                                    label = { Text(med, fontSize = 11.sp) }
                                )
                            }
                        }
                    }

                    // Dosage and Route
                    Column {
                        OutlinedTextField(
                            value = doseText,
                            onValueChange = { doseText = it },
                            label = { Text("Dose & Route *") },
                            placeholder = { Text("e.g. 1 ml / 10 kg Subcutaneous") },
                            singleLine = true,
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("input_batch_treatment_dose")
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            commonDoses.forEach { d ->
                                SuggestionChip(
                                    onClick = { doseText = d },
                                    label = { Text(d, fontSize = 11.sp) }
                                )
                            }
                        }
                    }

                    // Dates: Start Date and End Date
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedTextField(
                            value = startDateText,
                            onValueChange = { startDateText = it },
                            label = { Text("Treatment Date *") },
                            singleLine = true,
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("input_batch_treatment_start_date")
                        )

                        OutlinedTextField(
                            value = endDateText,
                            onValueChange = { endDateText = it },
                            label = { Text("Follow-up / End Date") },
                            placeholder = { Text("yyyy-MM-dd (Optional)") },
                            singleLine = true,
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("input_batch_treatment_end_date")
                        )
                    }

                    // Veterinarian & Outcome Status
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedTextField(
                            value = veterinarianText,
                            onValueChange = { veterinarianText = it },
                            label = { Text("Veterinarian / Administered By") },
                            singleLine = true,
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .weight(1.2f)
                                .testTag("input_batch_treatment_vet")
                        )

                        // Outcome Status
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Outcome Status", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(4.dp))
                            val outcomes = listOf("Under Treatment", "Recovered", "Under Observation")
                            var expanded by remember { mutableStateOf(false) }
                            Box {
                                OutlinedButton(
                                    onClick = { expanded = true },
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text(outcomeStatus, fontSize = 11.sp, maxLines = 1)
                                }
                                DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                                    outcomes.forEach {
                                        DropdownMenuItem(
                                            text = { Text(it) },
                                            onClick = {
                                                outcomeStatus = it
                                                expanded = false
                                            }
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // Withdrawal Periods (Meat & Milk)
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF8E1)),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Warning, contentDescription = null, tint = Color(0xFFF57F17), modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Withdrawal Safety Periods (Days)", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color(0xFFF57F17))
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                OutlinedTextField(
                                    value = meatWithdrawalDays,
                                    onValueChange = { meatWithdrawalDays = it },
                                    label = { Text("Meat (Days)") },
                                    singleLine = true,
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.weight(1f)
                                )
                                OutlinedTextField(
                                    value = milkWithdrawalDays,
                                    onValueChange = { milkWithdrawalDays = it },
                                    label = { Text("Milk (Days)") },
                                    singleLine = true,
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }
                    }

                    // Notes
                    OutlinedTextField(
                        value = notesText,
                        onValueChange = { notesText = it },
                        label = { Text("Treatment & Dosage Notes") },
                        placeholder = { Text("e.g. Mass herd anti-parasitic treatment administered per protocol") },
                        minLines = 2,
                        maxLines = 4,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_batch_treatment_notes")
                    )

                    // Checkbox: Update profile status
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { updateGoatStatusToTreatment = !updateGoatStatusToTreatment }
                    ) {
                        Checkbox(
                            checked = updateGoatStatusToTreatment,
                            onCheckedChange = { updateGoatStatusToTreatment = it }
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Update profile status to '$outcomeStatus' for selected goats",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Bottom Action Buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        enabled = !isSubmitting,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("btn_cancel_batch_treatment")
                    ) {
                        Text("Cancel")
                    }

                    Button(
                        onClick = {
                            if (isSubmitting) return@Button
                            if (medicineText.isBlank()) {
                                Toast.makeText(context, "Please enter medicine or product name", Toast.LENGTH_SHORT).show()
                                return@Button
                            }
                            if (doseText.isBlank()) {
                                Toast.makeText(context, "Please enter dosage and route", Toast.LENGTH_SHORT).show()
                                return@Button
                            }

                            isSubmitting = true
                            coroutineScope.launch {
                                val costVal = costPerGoatText.toDoubleOrNull()
                                val withdrawalNote = "Withdrawal: Meat $meatWithdrawalDays d, Milk $milkWithdrawalDays d."
                                val fullNotes = listOfNotNull(
                                    notesText.ifBlank { null },
                                    withdrawalNote
                                ).joinToString(" | ")

                                val treatments = selectedGoats.map { goat ->
                                    TreatmentRecord(
                                        goat_id_c = goat.id,
                                        symptoms_c = symptomsText.ifBlank { "Clinical Check" },
                                        diagnosis_c = diagnosisText.ifBlank { "Treatment" },
                                        medicine_c = medicineText.trim(),
                                        dose_c = doseText.trim(),
                                        start_date_c = startDateText,
                                        end_date_c = endDateText.ifBlank { null },
                                        veterinarian_c = veterinarianText.ifBlank { null },
                                        outcome_c = outcomeStatus,
                                        cost_c = costVal,
                                        notes_c = fullNotes
                                    )
                                }

                                val result = repository.recordBatchTreatments(
                                    treatments = treatments,
                                    updateGoatHealthStatus = updateGoatStatusToTreatment
                                )

                                isSubmitting = false
                                if (result.isSuccess) {
                                    Toast.makeText(
                                        context,
                                        "Batch treatment recorded for ${selectedGoats.size} goats",
                                        Toast.LENGTH_SHORT
                                    ).show()
                                    onSuccess(selectedGoats.size)
                                } else {
                                    Toast.makeText(
                                        context,
                                        "Failed to record treatments: ${result.exceptionOrNull()?.message}",
                                        Toast.LENGTH_LONG
                                    ).show()
                                }
                            }
                        },
                        enabled = !isSubmitting,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1565C0)),
                        modifier = Modifier
                            .weight(1.5f)
                            .testTag("btn_apply_batch_treatment")
                    ) {
                        if (isSubmitting) {
                            CircularProgressIndicator(
                                color = Color.White,
                                modifier = Modifier.size(18.dp),
                                strokeWidth = 2.dp
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                        }
                        Icon(Icons.Default.Medication, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Apply to ${selectedGoats.size} Goats")
                    }
                }
            }
        }
    }
}
