package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.data.offline.AppDatabase
import com.example.data.offline.NetworkMonitor
import com.example.data.offline.OfflineSyncManager
import com.example.data.supabase.GoatRepository
import com.example.data.supabase.SupabaseClient
import com.example.data.supabase.SupabaseConfig
import com.example.ui.screens.*
import com.example.ui.screens.finance.*
import com.example.ui.screens.health.*
import com.example.ui.screens.feed.GoatFeedInventoryScreen
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val config = SupabaseConfig(applicationContext)
        val client = SupabaseClient(config)
        val database = AppDatabase.getDatabase(applicationContext)
        val networkMonitor = NetworkMonitor(applicationContext)
        val syncManager = OfflineSyncManager(applicationContext, database, client, networkMonitor)
        val authManager = com.example.data.backup.GoogleAuthManager(applicationContext)
        val backupManager = com.example.data.backup.BackupManager(applicationContext, database, syncManager, authManager)
        val repository = GoatRepository(client, database, syncManager, backupManager)
        val fodderRepository = com.example.data.fodder.FodderRepository(database, syncManager)
        val languageManager = com.example.i18n.LanguageManager.getInstance(applicationContext)
        val farmProfileManager = repository.farmProfileManager

        // Schedule recurring notification system for upcoming goat vaccinations
        com.example.notification.VaccinationReminderScheduler.scheduleDaily(applicationContext)

        // Schedule recurring notification system for expected kidding dates in breeding management
        com.example.notification.KiddingReminderScheduler.scheduleDaily(applicationContext)

        val targetRoute = intent?.getStringExtra("navigate_to")

        setContent {
            val currentLanguage by languageManager.currentLanguage
            val farmProfile by farmProfileManager.farmProfile.collectAsState()
            androidx.compose.runtime.CompositionLocalProvider(
                com.example.i18n.LocalLanguage provides currentLanguage,
                com.example.i18n.LocalLanguageManager provides languageManager,
                com.example.data.farm.LocalFarmProfile provides farmProfile,
                com.example.data.farm.LocalFarmProfileManager provides farmProfileManager
            ) {
                MyApplicationTheme {
                    Surface(modifier = Modifier.fillMaxSize()) {
                        GoatFarmApp(
                            config = config,
                            client = client,
                            repository = repository,
                            fodderRepository = fodderRepository,
                            languageManager = languageManager,
                            initialRoute = targetRoute
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun GoatFarmApp(
    config: SupabaseConfig,
    client: SupabaseClient,
    repository: GoatRepository,
    fodderRepository: com.example.data.fodder.FodderRepository,
    languageManager: com.example.i18n.LanguageManager,
    initialRoute: String? = null
) {
    val navController = rememberNavController()
    val context = androidx.compose.ui.platform.LocalContext.current
    val navPrefs = remember { context.getSharedPreferences("nav_state_prefs", android.content.Context.MODE_PRIVATE) }
    val defaultStart = "auth"
    val startDestination = "auth"
    val weaningRepository = remember {
        com.example.data.weaning.WeaningRepository(
            repository.database,
            repository,
            repository.syncManager
        )
    }

    // Persist active navigation route to prevent preview from losing screen on APK re-installation
    androidx.compose.runtime.DisposableEffect(navController) {
        val listener = androidx.navigation.NavController.OnDestinationChangedListener { _, destination, args ->
            val route = destination.route
            if (!route.isNullOrBlank() && route != "auth") {
                var effectiveRoute: String = route
                args?.keySet()?.forEach { key ->
                    val value = args.get(key)
                    if (value != null) {
                        effectiveRoute = effectiveRoute.replace("{$key}", value.toString())
                    }
                }
                navPrefs.edit().putString("last_active_route", effectiveRoute).apply()
            }
        }
        navController.addOnDestinationChangedListener(listener)
        onDispose {
            navController.removeOnDestinationChangedListener(listener)
        }
    }


    NavHost(
        navController = navController,
        startDestination = startDestination
    ) {
        composable("auth") {
            AuthScreen(
                config = config,
                client = client,
                onAuthSuccess = {
                    navController.navigate("dashboard") {
                        popUpTo("auth") { inclusive = true }
                    }
                }
            )
        }

        composable("dashboard") {
            DashboardScreen(
                repository = repository,
                onNavigateToGoats = { navController.navigate("goats") },
                onNavigateToAddGoat = { navController.navigate("add_goat") },
                onNavigateToRecordWeight = { navController.navigate("record_weight") },
                onNavigateToVaccination = { navController.navigate("vaccination") },
                onNavigateToDeworming = { navController.navigate("deworming") },
                onNavigateToTreatment = { navController.navigate("treatment") },
                onNavigateToHealth = { navController.navigate("health") },
                onNavigateToDailyObservation = { navController.navigate("daily_health_observation") },
                onNavigateToTrends = { navController.navigate("health/trends") },
                onNavigateToWeightTrends = { navController.navigate("weight_trends") },
                onNavigateToQuarantine = { navController.navigate("biosecurity_hub?tab=0") },
                onNavigateToInsurance = { navController.navigate("biosecurity_hub?tab=2") },
                onNavigateToMortality = { navController.navigate("biosecurity_hub?tab=1") },
                onNavigateToBiosecurityHub = { tab -> navController.navigate("biosecurity_hub?tab=$tab") },
                onNavigateToBreeding = { navController.navigate("breeding_hub") },
                onNavigateToBreedingHub = { tab ->
                    if (tab == 0) {
                        navController.navigate("breeding_hub")
                    } else {
                        navController.navigate("breeding_reproduction?tab=$tab")
                    }
                },
                onNavigateToBreedingDashboard = { navController.navigate("breeding_dashboard") },
                onNavigateToFeed = { navController.navigate("feed") },
                onNavigateToFeedInventory = { navController.navigate("feed_inventory") },
                onNavigateToMedicine = { navController.navigate("medicine") },
                onNavigateToTasks = { navController.navigate("tasks_and_due?tab=1") },
                onNavigateToTodaysDue = { navController.navigate("tasks_and_due?tab=0") },
                onNavigateToSales = { navController.navigate("sales") },
                onNavigateToFinance = { navController.navigate("finance") },
                onNavigateToAssets = { navController.navigate("farm_assets") },
                onNavigateToAiEntry = { navController.navigate("ai_entry") },
                onNavigateToSettings = { navController.navigate("settings") },
                onNavigateToFodder = { tab -> navController.navigate("green_fodder?tab=$tab") },
                onNavigateToWeaning = { navController.navigate("breeding_reproduction?tab=3") },
                onNavigateToRecurring = { navController.navigate("recurring_expenses") },
                onNavigateToLoans = { navController.navigate("loans") },
                onNavigateToSuppliers = { navController.navigate("suppliers") },
                onNavigateToPaymentsDue = { navController.navigate("payments_due") },
                onNavigateToGst = { navController.navigate("gst_invoice") },
                onNavigateToEWay = { navController.navigate("eway_bill") },
                onNavigateToReports = { navController.navigate("financial_reports") },
                onNavigateToCashBank = { navController.navigate("cash_and_bank") },
                onNavigateToElectricity = { navController.navigate("electricity") },
                onNavigateToPopulationDashboard = { navController.navigate("population_dashboard") },
                onSignOut = {
                    config.clearSession()
                    navController.navigate("auth") {
                        popUpTo("dashboard") { inclusive = true }
                    }
                }
            )
        }

        composable("goats") {
            GoatListScreen(
                repository = repository,
                onNavigateBack = { navController.popBackStack() },
                onNavigateToAddGoat = { navController.navigate("add_goat") },
                onNavigateToRecordWeight = { goatId -> navController.navigate("record_weight?goatId=$goatId") },
                onNavigateToVaccination = { goatId -> navController.navigate("vaccination?goatId=$goatId") },
                onNavigateToDeworming = { goatId -> navController.navigate("deworming?goatId=$goatId") },
                onNavigateToProfile = { goatId -> navController.navigate("goat_profile?goatId=$goatId") },
                onNavigateToDashboard = {
                    navController.navigate("dashboard") {
                        popUpTo("dashboard") { inclusive = false }
                        launchSingleTop = true
                    }
                },
                onNavigateToSales = {
                    navController.navigate("sales") { launchSingleTop = true }
                },
                onNavigateToTasks = {
                    navController.navigate("tasks_and_due?tab=0") { launchSingleTop = true }
                },
                onNavigateToAiEntry = {
                    navController.navigate("ai_entry") { launchSingleTop = true }
                },
                onNavigateToBreeding = {
                    navController.navigate("breeding_reproduction?tab=0") { launchSingleTop = true }
                },
                onNavigateToPopulationDashboard = {
                    navController.navigate("population_dashboard")
                }
            )
        }

        composable(
            route = "goat_profile?goatId={goatId}",
            arguments = listOf(navArgument("goatId") {
                type = NavType.StringType
                nullable = false
            })
        ) { backStackEntry ->
            val goatId = backStackEntry.arguments?.getString("goatId") ?: ""
            GoatProfileScreen(
                goatId = goatId,
                repository = repository,
                onNavigateBack = { navController.popBackStack() },
                onNavigateToProfile = { targetGoatId ->
                    navController.navigate("goat_profile?goatId=$targetGoatId")
                },
                onNavigateToRecordWeight = { gid -> navController.navigate("record_weight?goatId=$gid") },
                onNavigateToVaccination = { gid -> navController.navigate("vaccination?goatId=$gid") },
                onNavigateToDeworming = { gid -> navController.navigate("deworming?goatId=$gid") },
                onNavigateToTreatment = { gid -> navController.navigate("treatment?goatId=$gid") },
                onNavigateToBreeding = { navController.navigate("breeding_reproduction?tab=0") },
                onNavigateToHealthCamera = { gid -> navController.navigate("health_camera?goatId=$gid") },
                onNavigateToDailyObservation = { gid -> navController.navigate("daily_health_observation?goatId=$gid") },
                onNavigateToTrends = { gid -> navController.navigate("health/trends?goatId=$gid") },
                onNavigateToRecurringHealthTracking = { gid -> navController.navigate("recurring_health_tracking?goatId=$gid") }
            )
        }

        composable("add_goat") {
            AddGoatScreen(
                repository = repository,
                onNavigateBack = { navController.popBackStack() },
                onGoatSaved = {
                    navController.popBackStack()
                }
            )
        }

        composable(
            route = "add_goat_breed?breed={breed}",
            arguments = listOf(navArgument("breed") {
                type = NavType.StringType
                nullable = true
                defaultValue = null
            })
        ) { backStackEntry ->
            val initialBreed = backStackEntry.arguments?.getString("breed")
            AddGoatScreen(
                repository = repository,
                onNavigateBack = { navController.popBackStack() },
                onGoatSaved = {
                    navController.popBackStack()
                },
                initialBreed = initialBreed
            )
        }

        composable("population_dashboard") {
            GoatPopulationDashboardScreen(
                repository = repository,
                onNavigateBack = { navController.popBackStack() },
                onNavigateToAddGoat = { breed ->
                    if (breed != null) {
                        navController.navigate("add_goat_breed?breed=$breed")
                    } else {
                        navController.navigate("add_goat")
                    }
                },
                onNavigateToGoatProfile = { goatId ->
                    navController.navigate("goat_profile?goatId=$goatId")
                }
            )
        }

        composable(
            route = "record_weight?goatId={goatId}",
            arguments = listOf(navArgument("goatId") {
                type = NavType.StringType
                nullable = true
                defaultValue = null
            })
        ) { backStackEntry ->
            val goatId = backStackEntry.arguments?.getString("goatId")
            RecordWeightScreen(
                repository = repository,
                initialGoatId = goatId,
                onNavigateBack = { navController.popBackStack() },
                onWeightSaved = { navController.popBackStack() },
                onNavigateToTrends = {
                    navController.navigate(if (goatId != null) "weight_trends?goatId=$goatId" else "weight_trends")
                }
            )
        }

        composable("weight_trends") {
            com.example.ui.screens.weight.GoatWeightTrendsVisualizationScreen(
                repository = repository,
                onNavigateBack = { navController.popBackStack() },
                onNavigateToRecordWeight = { gid ->
                    navController.navigate(if (gid != null) "record_weight?goatId=$gid" else "record_weight")
                }
            )
        }

        composable(
            route = "weight_trends?goatId={goatId}",
            arguments = listOf(navArgument("goatId") {
                type = NavType.StringType
                nullable = true
                defaultValue = null
            })
        ) { backStackEntry ->
            val goatId = backStackEntry.arguments?.getString("goatId")
            com.example.ui.screens.weight.GoatWeightTrendsVisualizationScreen(
                repository = repository,
                initialGoatId = goatId,
                onNavigateBack = { navController.popBackStack() },
                onNavigateToRecordWeight = { gid ->
                    navController.navigate(if (gid != null) "record_weight?goatId=$gid" else "record_weight")
                }
            )
        }

        composable(
            route = "vaccination?goatId={goatId}",
            arguments = listOf(navArgument("goatId") {
                type = NavType.StringType
                nullable = true
                defaultValue = null
            })
        ) { backStackEntry ->
            val goatId = backStackEntry.arguments?.getString("goatId")
            VaccinationScreen(
                repository = repository,
                initialGoatId = goatId,
                onNavigateBack = { navController.popBackStack() },
                onVaccinationSaved = { navController.popBackStack() }
            )
        }

        composable(
            route = "deworming?goatId={goatId}&tab={tab}",
            arguments = listOf(
                navArgument("goatId") {
                    type = NavType.StringType
                    nullable = true
                    defaultValue = null
                },
                navArgument("tab") {
                    type = NavType.IntType
                    defaultValue = 0
                }
            )
        ) { backStackEntry ->
            val goatId = backStackEntry.arguments?.getString("goatId")
            val tab = backStackEntry.arguments?.getInt("tab") ?: 0
            DewormingScreen(
                repository = repository,
                initialGoatId = goatId,
                initialTab = tab,
                onNavigateBack = { navController.popBackStack() },
                onDewormingSaved = { navController.popBackStack() }
            )
        }

        composable("deworming_schedule") {
            DewormingScreen(
                repository = repository,
                initialTab = 0,
                onNavigateBack = { navController.popBackStack() },
                onDewormingSaved = { navController.popBackStack() }
            )
        }

        composable("treatment") {
            TreatmentScreen(
                repository = repository,
                initialGoatId = null,
                onNavigateBack = { navController.popBackStack() },
                onTreatmentSaved = { navController.popBackStack() }
            )
        }

        composable(
            route = "treatment?goatId={goatId}",
            arguments = listOf(navArgument("goatId") {
                type = NavType.StringType
                nullable = true
                defaultValue = null
            })
        ) { backStackEntry ->
            val goatId = backStackEntry.arguments?.getString("goatId")
            TreatmentScreen(
                repository = repository,
                initialGoatId = goatId,
                onNavigateBack = { navController.popBackStack() },
                onTreatmentSaved = { navController.popBackStack() }
            )
        }

        // ==============================================================================
        // HEALTH & QUARANTINE SYSTEM ROUTES (Requirements 1, 2, 5, 7, 8, 9, 10, 16, 19)
        // ==============================================================================

        composable("health") {
            HealthDashboardScreen(
                repository = repository,
                onNavigateBack = { navController.popBackStack() },
                onNavigateToVaccination = { navController.navigate("vaccination") },
                onNavigateToDeworming = { navController.navigate("deworming") },
                onNavigateToTreatment = { navController.navigate("treatment") },
                onNavigateToHealthHistory = { navController.navigate("health/history") },
                onNavigateToAlerts = { navController.navigate("health/alerts") },
                onNavigateToQuarantine = { navController.navigate("biosecurity_hub?tab=0") },
                onNavigateToReports = { navController.navigate("health/reports") },
                onNavigateToCamera = { navController.navigate("health_camera") },
                onNavigateToDailyObservation = { navController.navigate("daily_health_observation") },
                onNavigateToTrends = { navController.navigate("health/trends") },
                onNavigateToRecurringHealthTracking = { navController.navigate("recurring_health_tracking") }
            )
        }

        composable("health/trends") {
            HealthTrendsVisualizationScreen(
                repository = repository,
                onNavigateBack = { navController.popBackStack() },
                onNavigateToRecordWeight = { gid ->
                    navController.navigate(if (gid != null) "record_weight?goatId=$gid" else "record_weight")
                },
                onNavigateToDailyObservation = { gid ->
                    navController.navigate(if (gid != null) "daily_health_observation?goatId=$gid" else "daily_health_observation")
                }
            )
        }

        composable(
            route = "health/trends?goatId={goatId}",
            arguments = listOf(navArgument("goatId") {
                type = NavType.StringType
                nullable = true
                defaultValue = null
            })
        ) { backStackEntry ->
            val goatId = backStackEntry.arguments?.getString("goatId")
            HealthTrendsVisualizationScreen(
                repository = repository,
                initialGoatId = goatId,
                onNavigateBack = { navController.popBackStack() },
                onNavigateToRecordWeight = { gid ->
                    navController.navigate(if (gid != null) "record_weight?goatId=$gid" else "record_weight")
                },
                onNavigateToDailyObservation = { gid ->
                    navController.navigate(if (gid != null) "daily_health_observation?goatId=$gid" else "daily_health_observation")
                }
            )
        }

        composable(
            route = "recurring_health_tracking?goatId={goatId}",
            arguments = listOf(navArgument("goatId") {
                type = NavType.StringType
                nullable = true
                defaultValue = null
            })
        ) { backStackEntry ->
            val goatId = backStackEntry.arguments?.getString("goatId")
            RecurringHealthTrackingScreen(
                repository = repository,
                initialGoatId = goatId,
                onNavigateBack = { navController.popBackStack() },
                onNavigateToGoatProfile = { gid -> navController.navigate("goat_profile?goatId=$gid") }
            )
        }

        composable("recurring_health_tracking") {
            RecurringHealthTrackingScreen(
                repository = repository,
                initialGoatId = null,
                onNavigateBack = { navController.popBackStack() },
                onNavigateToGoatProfile = { gid -> navController.navigate("goat_profile?goatId=$gid") }
            )
        }

        composable("daily_health_observation") {
            DailyHealthObservationScreen(
                repository = repository,
                onNavigateBack = { navController.popBackStack() },
                onNavigateToTrends = { navController.navigate("health/trends") }
            )
        }

        composable(
            route = "daily_health_observation?goatId={goatId}",
            arguments = listOf(navArgument("goatId") {
                type = NavType.StringType
                nullable = true
                defaultValue = null
            })
        ) { backStackEntry ->
            val goatId = backStackEntry.arguments?.getString("goatId")
            DailyHealthObservationScreen(
                repository = repository,
                preselectedGoatId = goatId,
                onNavigateBack = { navController.popBackStack() },
                onNavigateToTrends = { navController.navigate(if (goatId != null) "health/trends?goatId=$goatId" else "health/trends") }
            )
        }

        composable("health/daily_observation") {
            DailyHealthObservationScreen(
                repository = repository,
                onNavigateBack = { navController.popBackStack() },
                onNavigateToTrends = { navController.navigate("health/trends") }
            )
        }

        composable("health/vaccination") {
            VaccinationScreen(
                repository = repository,
                onNavigateBack = { navController.popBackStack() },
                onVaccinationSaved = { navController.popBackStack() }
            )
        }

        composable("health/deworming") {
            DewormingScreen(
                repository = repository,
                onNavigateBack = { navController.popBackStack() },
                onDewormingSaved = { navController.popBackStack() }
            )
        }

        composable("health/treatment") {
            TreatmentScreen(
                repository = repository,
                onNavigateBack = { navController.popBackStack() },
                onTreatmentSaved = { navController.popBackStack() }
            )
        }

        composable("health/history") {
            HealthHistoryScreen(
                repository = repository,
                onNavigateBack = { navController.popBackStack() }
            )
        }

        composable(
            route = "health/history?goatId={goatId}",
            arguments = listOf(navArgument("goatId") {
                type = NavType.StringType
                nullable = true
                defaultValue = null
            })
        ) { backStackEntry ->
            val goatId = backStackEntry.arguments?.getString("goatId")
            HealthHistoryScreen(
                repository = repository,
                initialGoatId = goatId,
                onNavigateBack = { navController.popBackStack() }
            )
        }

        composable("health/alerts") {
            HealthAlertsScreen(
                repository = repository,
                onNavigateBack = { navController.popBackStack() },
                onNavigateToVaccination = { gid -> navController.navigate("vaccination?goatId=$gid") },
                onNavigateToDeworming = { gid -> navController.navigate("deworming?goatId=$gid") },
                onNavigateToTreatment = { gid -> navController.navigate("treatment?goatId=$gid") },
                onNavigateToQuarantine = { gid -> navController.navigate("biosecurity_hub?tab=0&goatId=$gid") }
            )
        }

        composable("quarantine") {
            com.example.ui.screens.health.BiosecurityHubScreen(
                repository = repository,
                initialTab = 0,
                onNavigateBack = { navController.popBackStack() },
                onNavigateToVaccination = { gid -> navController.navigate("vaccination?goatId=$gid") },
                onNavigateToDeworming = { gid -> navController.navigate("deworming?goatId=$gid") },
                onNavigateToTreatment = { gid -> navController.navigate("treatment?goatId=$gid") },
                onNavigateToDashboard = {
                    navController.navigate("dashboard") {
                        popUpTo("dashboard") { inclusive = true }
                        launchSingleTop = true
                    }
                },
                onNavigateToGoats = {
                    navController.navigate("goats") {
                        popUpTo("dashboard")
                        launchSingleTop = true
                    }
                },
                onNavigateToBreeding = {
                    navController.navigate("breeding_reproduction?tab=0") {
                        popUpTo("dashboard")
                        launchSingleTop = true
                    }
                },
                onNavigateToSales = {
                    navController.navigate("sales") {
                        popUpTo("dashboard")
                        launchSingleTop = true
                    }
                },
                onNavigateToTasks = {
                    navController.navigate("tasks_and_due?tab=0") {
                        popUpTo("dashboard")
                        launchSingleTop = true
                    }
                },
                onNavigateToAiEntry = {
                    navController.navigate("ai_entry") { launchSingleTop = true }
                }
            )
        }

        composable(
            route = "quarantine?goatId={goatId}",
            arguments = listOf(navArgument("goatId") {
                type = NavType.StringType
                nullable = true
                defaultValue = null
            })
        ) { backStackEntry ->
            val goatId = backStackEntry.arguments?.getString("goatId")
            com.example.ui.screens.health.BiosecurityHubScreen(
                repository = repository,
                initialTab = 0,
                initialGoatId = goatId,
                onNavigateBack = { navController.popBackStack() },
                onNavigateToVaccination = { gid -> navController.navigate("vaccination?goatId=$gid") },
                onNavigateToDeworming = { gid -> navController.navigate("deworming?goatId=$gid") },
                onNavigateToTreatment = { gid -> navController.navigate("treatment?goatId=$gid") },
                onNavigateToDashboard = {
                    navController.navigate("dashboard") {
                        popUpTo("dashboard") { inclusive = true }
                        launchSingleTop = true
                    }
                },
                onNavigateToGoats = {
                    navController.navigate("goats") {
                        popUpTo("dashboard")
                        launchSingleTop = true
                    }
                },
                onNavigateToBreeding = {
                    navController.navigate("breeding_reproduction?tab=0") {
                        popUpTo("dashboard")
                        launchSingleTop = true
                    }
                },
                onNavigateToSales = {
                    navController.navigate("sales") {
                        popUpTo("dashboard")
                        launchSingleTop = true
                    }
                },
                onNavigateToTasks = {
                    navController.navigate("tasks_and_due?tab=0") {
                        popUpTo("dashboard")
                        launchSingleTop = true
                    }
                },
                onNavigateToAiEntry = {
                    navController.navigate("ai_entry") { launchSingleTop = true }
                }
            )
        }

        composable("health/reports") {
            HealthReportsScreen(
                repository = repository,
                onNavigateBack = { navController.popBackStack() }
            )
        }

        composable(
            route = "health_camera?goatId={goatId}",
            arguments = listOf(navArgument("goatId") {
                type = NavType.StringType
                nullable = true
                defaultValue = null
            })
        ) { backStackEntry ->
            val goatId = backStackEntry.arguments?.getString("goatId")
            com.example.ui.components.camera.GoatHealthCameraScreen(
                repository = repository,
                preselectedGoatId = goatId,
                onNavigateBack = { navController.popBackStack() }
            )
        }

        composable("health_camera") {
            com.example.ui.components.camera.GoatHealthCameraScreen(
                repository = repository,
                onNavigateBack = { navController.popBackStack() }
            )
        }

        composable(
            route = "breeding_reproduction?tab={tab}&doeId={doeId}",
            arguments = listOf(
                navArgument("tab") {
                    type = NavType.IntType
                    defaultValue = 0
                },
                navArgument("doeId") {
                    type = NavType.StringType
                    nullable = true
                    defaultValue = null
                }
            )
        ) { backStackEntry ->
            val tab = backStackEntry.arguments?.getInt("tab") ?: 0
            val doeId = backStackEntry.arguments?.getString("doeId")
            BreedingReproductionHubScreen(
                repository = repository,
                weaningRepository = weaningRepository,
                initialTab = tab,
                preselectedDoeId = doeId,
                onNavigateBack = { navController.popBackStack() },
                onNavigateToKidProfile = { kidId -> navController.navigate("goat_profile?goatId=$kidId") },
                onNavigateToBreedingRecords = { navController.navigate("breeding_records") },
                onNavigateToBreedingDashboard = { navController.navigate("breeding_dashboard") },
                onNavigateToDashboard = {
                    navController.navigate("dashboard") {
                        popUpTo("dashboard") { inclusive = false }
                        launchSingleTop = true
                    }
                },
                onNavigateToGoats = {
                    navController.navigate("goats") { launchSingleTop = true }
                },
                onNavigateToSales = {
                    navController.navigate("sales") { launchSingleTop = true }
                },
                onNavigateToTasks = {
                    navController.navigate("tasks_and_due?tab=0") { launchSingleTop = true }
                },
                onNavigateToAiEntry = {
                    navController.navigate("ai_entry") { launchSingleTop = true }
                }
            )
        }

        composable("breeding_hub") {
            com.example.ui.screens.breeding.BreedingAndKidsHubScreen(
                repository = repository,
                onNavigateBack = { navController.popBackStack() },
                onNavigateHome = {
                    navController.navigate("dashboard") {
                        popUpTo("dashboard") { inclusive = false }
                        launchSingleTop = true
                    }
                }
            )
        }

        composable("breeding") {
            BreedingReproductionHubScreen(
                repository = repository,
                weaningRepository = weaningRepository,
                initialTab = 0,
                onNavigateBack = { navController.popBackStack() },
                onNavigateToKidProfile = { kidId -> navController.navigate("goat_profile?goatId=$kidId") },
                onNavigateToBreedingRecords = { navController.navigate("breeding_records") },
                onNavigateToBreedingDashboard = { navController.navigate("breeding_dashboard") },
                onNavigateToDashboard = {
                    navController.navigate("dashboard") {
                        popUpTo("dashboard") { inclusive = false }
                        launchSingleTop = true
                    }
                },
                onNavigateToGoats = {
                    navController.navigate("goats") { launchSingleTop = true }
                },
                onNavigateToSales = {
                    navController.navigate("sales") { launchSingleTop = true }
                },
                onNavigateToTasks = {
                    navController.navigate("tasks_and_due?tab=0") { launchSingleTop = true }
                },
                onNavigateToAiEntry = {
                    navController.navigate("ai_entry") { launchSingleTop = true }
                }
            )
        }

        composable("delivery") {
            BreedingReproductionHubScreen(
                repository = repository,
                weaningRepository = weaningRepository,
                initialTab = 2,
                onNavigateBack = { navController.popBackStack() },
                onNavigateToKidProfile = { kidId -> navController.navigate("goat_profile?goatId=$kidId") },
                onNavigateToBreedingRecords = { navController.navigate("breeding_records") },
                onNavigateToBreedingDashboard = { navController.navigate("breeding_dashboard") },
                onNavigateToDashboard = {
                    navController.navigate("dashboard") {
                        popUpTo("dashboard") { inclusive = false }
                        launchSingleTop = true
                    }
                },
                onNavigateToGoats = {
                    navController.navigate("goats") { launchSingleTop = true }
                },
                onNavigateToSales = {
                    navController.navigate("sales") { launchSingleTop = true }
                },
                onNavigateToTasks = {
                    navController.navigate("tasks_and_due?tab=0") { launchSingleTop = true }
                },
                onNavigateToAiEntry = {
                    navController.navigate("ai_entry") { launchSingleTop = true }
                }
            )
        }

        composable("breeding_dashboard") {
            com.example.ui.screens.breeding.BreedingDashboardScreen(
                repository = repository,
                onNavigateBack = { navController.popBackStack() },
                onNavigateToRecordMating = { navController.navigate("breeding_reproduction?tab=0") },
                onNavigateToRecordPregnancy = { navController.navigate("breeding_reproduction?tab=1") },
                onNavigateToLogKidding = { doeId ->
                    navController.navigate("breeding_reproduction?tab=2&doeId=$doeId")
                },
                onNavigateToBreedingRecords = { navController.navigate("breeding_records") },
                onNavigateToLineageAudit = { navController.navigate("breeding_reproduction?tab=0") }
            )
        }

        composable("breeding_records") {
            BreedingRecordsScreen(
                repository = repository,
                onNavigateBack = { navController.popBackStack() }
            )
        }

        composable("feed") {
            FeedMedicineScreen(
                repository = repository,
                initialTab = 0,
                onNavigateToFeedInventory = { navController.navigate("feed_inventory") },
                onNavigateBack = { navController.popBackStack() }
            )
        }

        composable("feed_inventory") {
            GoatFeedInventoryScreen(
                repository = repository,
                onNavigateBack = { navController.popBackStack() }
            )
        }

        composable("medicine") {
            FeedMedicineScreen(
                repository = repository,
                initialTab = 1,
                onNavigateBack = { navController.popBackStack() }
            )
        }

        composable("sales") {
            SalesScreen(
                repository = repository,
                onNavigateBack = { navController.popBackStack() },
                onNavigateToDashboard = {
                    navController.navigate("dashboard") {
                        popUpTo("dashboard") { inclusive = false }
                        launchSingleTop = true
                    }
                },
                onNavigateToGoats = {
                    navController.navigate("goats") { launchSingleTop = true }
                },
                onNavigateToTasks = {
                    navController.navigate("tasks_and_due?tab=0") { launchSingleTop = true }
                },
                onNavigateToAiEntry = {
                    navController.navigate("ai_entry") { launchSingleTop = true }
                },
                onNavigateToBreeding = {
                    navController.navigate("breeding_reproduction?tab=0") { launchSingleTop = true }
                }
            )
        }

        composable("finance") {
            FinanceScreen(
                repository = repository,
                onNavigateBack = { navController.popBackStack() },
                onNavigateToSales = { navController.navigate("sales") },
                onNavigateToAssets = { navController.navigate("farm_assets") },
                onNavigateToCashBank = { navController.navigate("cash_and_bank") },
                onNavigateToRecurring = { navController.navigate("recurring_expenses") },
                onNavigateToEb = { navController.navigate("electricity") },
                onNavigateToLoans = { navController.navigate("loans") },
                onNavigateToSuppliers = { navController.navigate("suppliers") },
                onNavigateToGst = { navController.navigate("gst_invoice") },
                onNavigateToEWay = { navController.navigate("eway_bill") },
                onNavigateToReports = { navController.navigate("financial_reports") },
                onNavigateToPaymentsDue = { navController.navigate("payments_due") }
            )
        }

        composable("cash_and_bank") {
            CashAndBankScreen(
                repository = repository,
                onNavigateBack = { navController.popBackStack() }
            )
        }

        composable("recurring_expenses") {
            RecurringExpensesScreen(
                repository = repository,
                onNavigateBack = { navController.popBackStack() }
            )
        }

        composable("electricity") {
            ElectricityScreen(
                repository = repository,
                onNavigateBack = { navController.popBackStack() }
            )
        }

        composable("loans") {
            LoansScreen(
                repository = repository,
                onNavigateBack = { navController.popBackStack() }
            )
        }

        composable("suppliers") {
            SuppliersScreen(
                repository = repository,
                onNavigateBack = { navController.popBackStack() }
            )
        }

        composable("gst_invoice") {
            GstInvoiceScreen(
                repository = repository,
                onNavigateBack = { navController.popBackStack() }
            )
        }

        composable("eway_bill") {
            EWayBillScreen(
                repository = repository,
                onNavigateBack = { navController.popBackStack() }
            )
        }

        composable("financial_reports") {
            FinancialReportsScreen(
                repository = repository,
                onNavigateBack = { navController.popBackStack() }
            )
        }

        composable("payments_due") {
            PaymentsDueScreen(
                repository = repository,
                onNavigateBack = { navController.popBackStack() },
                onNavigateToEb = { navController.navigate("electricity") },
                onNavigateToSuppliers = { navController.navigate("suppliers") },
                onNavigateToLoans = { navController.navigate("loans") },
                onNavigateToRecurring = { navController.navigate("recurring_expenses") }
            )
        }

        composable("farm_assets") {
            FarmAssetsScreen(
                repository = repository,
                onNavigateBack = { navController.popBackStack() }
            )
        }

        composable(
            route = "tasks_and_due?tab={tab}",
            arguments = listOf(navArgument("tab") {
                type = NavType.IntType
                defaultValue = 0
            })
        ) { backStackEntry ->
            val tab = backStackEntry.arguments?.getInt("tab") ?: 0
            TasksAndDueScreen(
                repository = repository,
                initialTab = tab,
                onNavigateBack = { navController.popBackStack() },
                onNavigateToVaccinateGoat = { goatId -> navController.navigate("vaccination?goatId=$goatId") },
                onNavigateToDewormGoat = { goatId -> navController.navigate("deworming?goatId=$goatId") },
                onNavigateToDashboard = {
                    navController.navigate("dashboard") {
                        popUpTo("dashboard") { inclusive = false }
                        launchSingleTop = true
                    }
                },
                onNavigateToGoats = {
                    navController.navigate("goats") { launchSingleTop = true }
                },
                onNavigateToSales = {
                    navController.navigate("sales") { launchSingleTop = true }
                },
                onNavigateToAiEntry = {
                    navController.navigate("ai_entry") { launchSingleTop = true }
                },
                onNavigateToBreeding = {
                    navController.navigate("breeding_reproduction?tab=0") { launchSingleTop = true }
                }
            )
        }

        composable("ai_entry") {
            AiEntryScreen(
                repository = repository,
                onNavigateBack = { navController.popBackStack() },
                onEntrySaved = {
                    navController.navigate("dashboard") {
                        popUpTo("dashboard") { inclusive = true }
                    }
                },
                onNavigateToDashboard = {
                    navController.navigate("dashboard") {
                        popUpTo("dashboard") { inclusive = false }
                        launchSingleTop = true
                    }
                },
                onNavigateToGoats = {
                    navController.navigate("goats") { launchSingleTop = true }
                },
                onNavigateToSales = {
                    navController.navigate("sales") { launchSingleTop = true }
                },
                onNavigateToTasks = {
                    navController.navigate("tasks_and_due?tab=0") { launchSingleTop = true }
                },
                onNavigateToBreeding = {
                    navController.navigate("breeding_reproduction?tab=0") { launchSingleTop = true }
                }
            )
        }

        composable("settings") {
            com.example.ui.screens.SettingsScreen(
                repository = repository,
                config = config,
                onNavigateBack = { navController.popBackStack() },
                onSignOut = {
                    config.clearSession()
                    navController.navigate("auth") {
                        popUpTo("dashboard") { inclusive = true }
                    }
                }
            )
        }

        composable(
            route = "green_fodder?tab={tab}",
            arguments = listOf(navArgument("tab") {
                type = NavType.IntType
                defaultValue = 0
            })
        ) { backStackEntry ->
            val tab = backStackEntry.arguments?.getInt("tab") ?: 0
            com.example.ui.screens.fodder.GreenFodderScreen(
                repository = repository,
                fodderRepository = fodderRepository,
                initialTab = tab,
                onNavigateBack = { navController.popBackStack() }
            )
        }

        composable("weaning") {
            BreedingReproductionHubScreen(
                repository = repository,
                weaningRepository = weaningRepository,
                initialTab = 3,
                onNavigateBack = { navController.popBackStack() },
                onNavigateToKidProfile = { kidId -> navController.navigate("goat_profile?goatId=$kidId") },
                onNavigateToBreedingRecords = { navController.navigate("breeding_records") },
                onNavigateToBreedingDashboard = { navController.navigate("breeding_dashboard") },
                onNavigateToDashboard = {
                    navController.navigate("dashboard") {
                        popUpTo("dashboard") { inclusive = false }
                        launchSingleTop = true
                    }
                },
                onNavigateToGoats = {
                    navController.navigate("goats") { launchSingleTop = true }
                },
                onNavigateToSales = {
                    navController.navigate("sales") { launchSingleTop = true }
                },
                onNavigateToTasks = {
                    navController.navigate("tasks_and_due?tab=0") { launchSingleTop = true }
                },
                onNavigateToAiEntry = {
                    navController.navigate("ai_entry") { launchSingleTop = true }
                }
            )
        }

        composable(
            route = "biosecurity_hub?tab={tab}&goatId={goatId}",
            arguments = listOf(
                navArgument("tab") {
                    type = NavType.IntType
                    defaultValue = 0
                },
                navArgument("goatId") {
                    type = NavType.StringType
                    nullable = true
                    defaultValue = null
                }
            )
        ) { backStackEntry ->
            val initialTab = backStackEntry.arguments?.getInt("tab") ?: 0
            val initialGoatId = backStackEntry.arguments?.getString("goatId")
            com.example.ui.screens.health.BiosecurityHubScreen(
                repository = repository,
                initialTab = initialTab,
                initialGoatId = initialGoatId,
                onNavigateBack = { navController.popBackStack() },
                onNavigateToVaccination = { gid -> navController.navigate("vaccination?goatId=$gid") },
                onNavigateToDeworming = { gid -> navController.navigate("deworming?goatId=$gid") },
                onNavigateToTreatment = { gid -> navController.navigate("treatment?goatId=$gid") },
                onNavigateToDashboard = {
                    navController.navigate("dashboard") {
                        popUpTo("dashboard") { inclusive = true }
                        launchSingleTop = true
                    }
                },
                onNavigateToGoats = {
                    navController.navigate("goats") {
                        popUpTo("dashboard")
                        launchSingleTop = true
                    }
                },
                onNavigateToBreeding = {
                    navController.navigate("breeding_reproduction?tab=0") {
                        popUpTo("dashboard")
                        launchSingleTop = true
                    }
                },
                onNavigateToSales = {
                    navController.navigate("sales") {
                        popUpTo("dashboard")
                        launchSingleTop = true
                    }
                },
                onNavigateToTasks = {
                    navController.navigate("tasks_and_due?tab=0") {
                        popUpTo("dashboard")
                        launchSingleTop = true
                    }
                },
                onNavigateToAiEntry = {
                    navController.navigate("ai_entry") { launchSingleTop = true }
                }
            )
        }

        composable("insurance") {
            com.example.ui.screens.health.BiosecurityHubScreen(
                repository = repository,
                initialTab = 2,
                onNavigateBack = { navController.popBackStack() },
                onNavigateToVaccination = { gid -> navController.navigate("vaccination?goatId=$gid") },
                onNavigateToDeworming = { gid -> navController.navigate("deworming?goatId=$gid") },
                onNavigateToTreatment = { gid -> navController.navigate("treatment?goatId=$gid") },
                onNavigateToDashboard = {
                    navController.navigate("dashboard") {
                        popUpTo("dashboard") { inclusive = true }
                        launchSingleTop = true
                    }
                },
                onNavigateToGoats = {
                    navController.navigate("goats") {
                        popUpTo("dashboard")
                        launchSingleTop = true
                    }
                },
                onNavigateToBreeding = {
                    navController.navigate("breeding_reproduction?tab=0") {
                        popUpTo("dashboard")
                        launchSingleTop = true
                    }
                },
                onNavigateToSales = {
                    navController.navigate("sales") {
                        popUpTo("dashboard")
                        launchSingleTop = true
                    }
                },
                onNavigateToTasks = {
                    navController.navigate("tasks_and_due?tab=0") {
                        popUpTo("dashboard")
                        launchSingleTop = true
                    }
                },
                onNavigateToAiEntry = {
                    navController.navigate("ai_entry") { launchSingleTop = true }
                }
            )
        }

        composable(
            route = "livestock_insurance?goatId={goatId}",
            arguments = listOf(
                navArgument("goatId") {
                    type = NavType.StringType
                    nullable = true
                    defaultValue = null
                }
            )
        ) { backStackEntry ->
            val goatId = backStackEntry.arguments?.getString("goatId")
            com.example.ui.screens.health.BiosecurityHubScreen(
                repository = repository,
                initialTab = 2,
                initialGoatId = goatId,
                onNavigateBack = { navController.popBackStack() },
                onNavigateToVaccination = { gid -> navController.navigate("vaccination?goatId=$gid") },
                onNavigateToDeworming = { gid -> navController.navigate("deworming?goatId=$gid") },
                onNavigateToTreatment = { gid -> navController.navigate("treatment?goatId=$gid") },
                onNavigateToDashboard = {
                    navController.navigate("dashboard") {
                        popUpTo("dashboard") { inclusive = true }
                        launchSingleTop = true
                    }
                },
                onNavigateToGoats = {
                    navController.navigate("goats") {
                        popUpTo("dashboard")
                        launchSingleTop = true
                    }
                },
                onNavigateToBreeding = {
                    navController.navigate("breeding_reproduction?tab=0") {
                        popUpTo("dashboard")
                        launchSingleTop = true
                    }
                },
                onNavigateToSales = {
                    navController.navigate("sales") {
                        popUpTo("dashboard")
                        launchSingleTop = true
                    }
                },
                onNavigateToTasks = {
                    navController.navigate("tasks_and_due?tab=0") {
                        popUpTo("dashboard")
                        launchSingleTop = true
                    }
                },
                onNavigateToAiEntry = {
                    navController.navigate("ai_entry") { launchSingleTop = true }
                }
            )
        }

        composable("mortality") {
            com.example.ui.screens.health.BiosecurityHubScreen(
                repository = repository,
                initialTab = 1,
                onNavigateBack = { navController.popBackStack() },
                onNavigateToVaccination = { gid -> navController.navigate("vaccination?goatId=$gid") },
                onNavigateToDeworming = { gid -> navController.navigate("deworming?goatId=$gid") },
                onNavigateToTreatment = { gid -> navController.navigate("treatment?goatId=$gid") },
                onNavigateToDashboard = {
                    navController.navigate("dashboard") {
                        popUpTo("dashboard") { inclusive = true }
                        launchSingleTop = true
                    }
                },
                onNavigateToGoats = {
                    navController.navigate("goats") {
                        popUpTo("dashboard")
                        launchSingleTop = true
                    }
                },
                onNavigateToBreeding = {
                    navController.navigate("breeding_reproduction?tab=0") {
                        popUpTo("dashboard")
                        launchSingleTop = true
                    }
                },
                onNavigateToSales = {
                    navController.navigate("sales") {
                        popUpTo("dashboard")
                        launchSingleTop = true
                    }
                },
                onNavigateToTasks = {
                    navController.navigate("tasks_and_due?tab=0") {
                        popUpTo("dashboard")
                        launchSingleTop = true
                    }
                },
                onNavigateToAiEntry = {
                    navController.navigate("ai_entry") { launchSingleTop = true }
                }
            )
        }
    }
}
