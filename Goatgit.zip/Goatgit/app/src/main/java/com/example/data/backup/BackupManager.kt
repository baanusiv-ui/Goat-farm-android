package com.example.data.backup

import android.content.Context
import android.os.Environment
import android.util.Log
import androidx.work.*
import com.example.data.offline.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.*
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.TimeUnit
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream

enum class DriveBackupStatus {
    SYNCED,
    PENDING,
    FAILED,
    IN_PROGRESS,
    IDLE
}

enum class LocalBackupStatus {
    COMPLETED,
    FAILED,
    IN_PROGRESS,
    IDLE
}

data class LocalBackupInfo(
    val file: File,
    val fileName: String,
    val fileSize: Long,
    val recordCount: Int,
    val timestamp: Long,
    val formattedDate: String,
    val formattedSize: String,
    val checksum: String,
    val location: String,
    val isVerified: Boolean = true
)

class BackupManager(
    private val context: Context,
    private val database: AppDatabase,
    private val syncManager: OfflineSyncManager,
    val authManager: GoogleAuthManager,
    private val driveService: GoogleDriveService = GoogleDriveService()
) {
    companion object {
        private const val TAG = "BackupManager"
        private const val PREFS_NAME = "google_drive_backup_manager_prefs"
        private const val KEY_AUTO_BACKUP_ENABLED = "auto_backup_enabled"
        private const val KEY_LAST_BACKUP_MS = "last_backup_timestamp_ms"
        private const val KEY_NEXT_BACKUP_MS = "next_backup_timestamp_ms"
        private const val KEY_BACKUP_STATUS = "backup_status"
        private const val KEY_LAST_BACKUP_FILE_ID = "last_backup_file_id"
        private const val KEY_LAST_ERROR = "last_backup_error"
        private const val WORK_TAG = "daily_google_drive_backup_work"
        private const val LOCAL_WORK_TAG = "daily_local_device_backup_work"
        private const val KEY_LOCAL_BACKUP_STATUS = "local_backup_status"
        private const val KEY_LOCAL_LAST_BACKUP_MS = "local_last_backup_ms"
        private const val KEY_LOCAL_LAST_ERROR = "local_last_backup_error"
        private const val KEY_LOCAL_LAST_FILE_NAME = "local_last_file_name"
        private const val KEY_LOCAL_LAST_FILE_PATH = "local_last_file_path"
        private const val KEY_LOCAL_LAST_RECORDS = "local_last_records"
        private const val KEY_LOCAL_LAST_SIZE = "local_last_size"
        const val APP_VERSION = "1.0.0"
        const val SCHEMA_VERSION = 7
        const val BACKUP_FORMAT_VERSION = "1.0"
    }

    private val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    private val _isAutoBackupEnabled = MutableStateFlow(prefs.getBoolean(KEY_AUTO_BACKUP_ENABLED, false))
    val isAutoBackupEnabled: StateFlow<Boolean> = _isAutoBackupEnabled.asStateFlow()

    private val _lastBackupTime = MutableStateFlow(prefs.getLong(KEY_LAST_BACKUP_MS, 0L))
    val lastBackupTime: StateFlow<Long> = _lastBackupTime.asStateFlow()

    private val _nextBackupTime = MutableStateFlow(prefs.getLong(KEY_NEXT_BACKUP_MS, 0L))
    val nextBackupTime: StateFlow<Long> = _nextBackupTime.asStateFlow()

    private val _backupStatus = MutableStateFlow(
        try {
            DriveBackupStatus.valueOf(prefs.getString(KEY_BACKUP_STATUS, DriveBackupStatus.IDLE.name) ?: DriveBackupStatus.IDLE.name)
        } catch (_: Exception) {
            DriveBackupStatus.IDLE
        }
    )
    val backupStatus: StateFlow<DriveBackupStatus> = _backupStatus.asStateFlow()

    private val _lastError = MutableStateFlow(prefs.getString(KEY_LAST_ERROR, null))
    val lastError: StateFlow<String?> = _lastError.asStateFlow()

    private val _isBackingUp = MutableStateFlow(false)
    val isBackingUp: StateFlow<Boolean> = _isBackingUp.asStateFlow()

    private val _isRestoring = MutableStateFlow(false)
    val isRestoring: StateFlow<Boolean> = _isRestoring.asStateFlow()

    private val fileNameFormat = SimpleDateFormat("yyyy-MM-dd-HH-mm", Locale.US)
    private val displayDateFormat = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault())
    private val localBackupDateFormat = SimpleDateFormat("yyyy-MM-dd_HH-mm-ss", Locale.US)

    val backupLogs = database.backupLogDao().getAllBackupLogsFlow()

    private val _localBackupStatus = MutableStateFlow(
        try {
            LocalBackupStatus.valueOf(prefs.getString(KEY_LOCAL_BACKUP_STATUS, LocalBackupStatus.IDLE.name) ?: LocalBackupStatus.IDLE.name)
        } catch (_: Exception) {
            LocalBackupStatus.IDLE
        }
    )
    val localBackupStatus: StateFlow<LocalBackupStatus> = _localBackupStatus.asStateFlow()

    private val _lastLocalBackupTime = MutableStateFlow(prefs.getLong(KEY_LOCAL_LAST_BACKUP_MS, 0L))
    val lastLocalBackupTime: StateFlow<Long> = _lastLocalBackupTime.asStateFlow()

    private val _lastLocalBackupInfo = MutableStateFlow<LocalBackupInfo?>(null)
    val lastLocalBackupInfo: StateFlow<LocalBackupInfo?> = _lastLocalBackupInfo.asStateFlow()

    private val _localBackupError = MutableStateFlow(prefs.getString(KEY_LOCAL_LAST_ERROR, null))
    val localBackupError: StateFlow<String?> = _localBackupError.asStateFlow()

    init {
        // Daily automatic local backup scheduled via WorkManager without network constraint
        try {
            scheduleDailyLocalBackup()
        } catch (e: Exception) {
            Log.w(TAG, "WorkManager init ignored: ${e.message}")
        }
        try {
            loadLatestLocalBackupInfo()
        } catch (e: Exception) {
            Log.w(TAG, "loadLatestLocalBackupInfo error: ${e.message}")
        }
        if (_isAutoBackupEnabled.value) {
            try {
                scheduleDailyBackup()
            } catch (e: Exception) {
                Log.w(TAG, "WorkManager cloud backup init ignored: ${e.message}")
            }
        }
    }

    fun scheduleDailyLocalBackup() {
        try {
            val periodicWork = PeriodicWorkRequestBuilder<DailyLocalBackupWorker>(
                24, TimeUnit.HOURS,
                1, TimeUnit.HOURS
            )
                .addTag("daily_local_device_backup")
                .build()

            WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                LOCAL_WORK_TAG,
                ExistingPeriodicWorkPolicy.KEEP,
                periodicWork
            )
            Log.d(TAG, "Daily local device backup scheduled (24h recurring, offline-capable)")
        } catch (e: Exception) {
            Log.w(TAG, "Could not schedule local backup via WorkManager: ${e.message}")
        }
    }

    fun cancelDailyLocalBackup() {
        try {
            WorkManager.getInstance(context).cancelUniqueWork(LOCAL_WORK_TAG)
            Log.d(TAG, "Daily local device backup cancelled")
        } catch (e: Exception) {
            Log.w(TAG, "Could not cancel local backup via WorkManager: ${e.message}")
        }
    }

    fun getLocalBackupDirectory(): File {
        val publicDocs = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS)
        val preferredDir = File(publicDocs, "Goat Farm Manager/Backups")
        if (preferredDir.exists() || preferredDir.mkdirs()) {
            return preferredDir
        }
        val appDocs = context.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS)
        val fallbackDir = File(appDocs, "Goat Farm Manager/Backups")
        if (fallbackDir.exists() || fallbackDir.mkdirs()) {
            return fallbackDir
        }
        val internalDir = File(context.filesDir, "Backups")
        internalDir.mkdirs()
        return internalDir
    }

    fun loadLatestLocalBackupInfo() {
        val lastMs = prefs.getLong(KEY_LOCAL_LAST_BACKUP_MS, 0L)
        val fileName = prefs.getString(KEY_LOCAL_LAST_FILE_NAME, null)
        val filePath = prefs.getString(KEY_LOCAL_LAST_FILE_PATH, null)
        val records = prefs.getInt(KEY_LOCAL_LAST_RECORDS, 0)
        val size = prefs.getLong(KEY_LOCAL_LAST_SIZE, 0L)

        if (lastMs > 0 && !fileName.isNullOrBlank() && !filePath.isNullOrBlank()) {
            val file = File(filePath)
            if (file.exists()) {
                _lastLocalBackupInfo.value = LocalBackupInfo(
                    file = file,
                    fileName = fileName,
                    fileSize = if (size > 0) size else file.length(),
                    recordCount = records,
                    timestamp = lastMs,
                    formattedDate = displayDateFormat.format(Date(lastMs)),
                    formattedSize = formatFileSize(if (size > 0) size else file.length()),
                    checksum = "Verified",
                    location = file.parent ?: "Device Storage",
                    isVerified = true
                )
            }
        }
    }

    fun formatFileSize(bytes: Long): String {
        return when {
            bytes >= 1024 * 1024 -> String.format(Locale.US, "%.2f MB", bytes.toDouble() / (1024 * 1024))
            bytes >= 1024 -> String.format(Locale.US, "%.1f KB", bytes.toDouble() / 1024)
            else -> "$bytes bytes"
        }
    }

    suspend fun createLocalDeviceBackup(
        isScheduled: Boolean = false,
        isSafety: Boolean = false
    ): Result<LocalBackupInfo> = withContext(Dispatchers.IO) {
        if (_isBackingUp.value) {
            return@withContext Result.failure(Exception("Another backup operation is already running"))
        }

        val startTime = System.currentTimeMillis()
        val backupId = when {
            isSafety -> "safety-backup-$startTime"
            isScheduled -> "scheduled-local-${SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date(startTime))}"
            else -> "manual-local-${UUID.randomUUID()}"
        }

        _isBackingUp.value = true
        _localBackupStatus.value = LocalBackupStatus.IN_PROGRESS

        try {
            // 1. Collect all local data
            val payload = buildBackupPayload(backupId, startTime)
            val jsonContent = payload.toString(2)
            val totalRecords = payload.getJSONObject("backup_metadata").getJSONObject("record_counts").optInt("total_records", 0)

            // 2. Compute SHA-256 hash
            val digest = MessageDigest.getInstance("SHA-256")
            val hashBytes = digest.digest(jsonContent.toByteArray(Charsets.UTF_8))
            val checksumHex = hashBytes.joinToString("") { "%02x".format(it) }

            // 3. Prepare target folder and filename
            val targetDir = getLocalBackupDirectory()
            val timePart = localBackupDateFormat.format(Date(startTime))
            val fileName = if (isSafety) "GoatFarm_Safety_Backup_$timePart.zip" else "GoatFarm_Backup_$timePart.zip"
            val targetFile = File(targetDir, fileName)
            val tempFile = File(targetDir, "$fileName.tmp")

            // 4. Create ZIP package containing manifest & payload
            val manifestJson = JSONObject().apply {
                put("backup_version", BACKUP_FORMAT_VERSION)
                put("app_version", APP_VERSION)
                put("database_version", SCHEMA_VERSION)
                put("created_timestamp", startTime)
                put("created_date", displayDateFormat.format(Date(startTime)))
                put("file_name", fileName)
                put("record_counts", payload.getJSONObject("backup_metadata").getJSONObject("record_counts"))
                put("checksum_sha256", checksumHex)
            }

            ZipOutputStream(BufferedOutputStream(FileOutputStream(tempFile))).use { zos ->
                // Entry 1: manifest.json
                val manifestBytes = manifestJson.toString(2).toByteArray(Charsets.UTF_8)
                val manifestEntry = ZipEntry("backup_manifest.json")
                manifestEntry.size = manifestBytes.size.toLong()
                zos.putNextEntry(manifestEntry)
                zos.write(manifestBytes)
                zos.closeEntry()

                // Entry 2: backup_data.json
                val dataBytes = jsonContent.toByteArray(Charsets.UTF_8)
                val dataEntry = ZipEntry("backup_data.json")
                dataEntry.size = dataBytes.size.toLong()
                zos.putNextEntry(dataEntry)
                zos.write(dataBytes)
                zos.closeEntry()
            }

            // 5. Atomic rename to final zip
            if (targetFile.exists()) targetFile.delete()
            if (!tempFile.renameTo(targetFile)) {
                tempFile.copyTo(targetFile, overwrite = true)
                tempFile.delete()
            }

            // 6. VALIDATE THE BACKUP IMMEDIATELY (Read-back verification)
            val validationRes = validateBackupZip(targetFile, expectedChecksum = checksumHex)
            if (validationRes.isFailure) {
                targetFile.delete()
                val err = validationRes.exceptionOrNull()?.message ?: "Backup verification failed"
                _localBackupStatus.value = LocalBackupStatus.FAILED
                _localBackupError.value = err
                return@withContext Result.failure(Exception(err))
            }

            val completedTime = System.currentTimeMillis()
            val backupInfo = LocalBackupInfo(
                file = targetFile,
                fileName = fileName,
                fileSize = targetFile.length(),
                recordCount = totalRecords,
                timestamp = completedTime,
                formattedDate = displayDateFormat.format(Date(completedTime)),
                formattedSize = formatFileSize(targetFile.length()),
                checksum = checksumHex,
                location = targetFile.parent ?: targetDir.absolutePath,
                isVerified = true
            )

            // 7. Enforce 30-backup retention rule (only delete oldest AFTER successful verified backup)
            enforceLocalBackupRetention(targetDir, maxKeep = 30)

            // 8. Update state and persistent prefs
            _localBackupStatus.value = LocalBackupStatus.COMPLETED
            _lastLocalBackupTime.value = completedTime
            _lastLocalBackupInfo.value = backupInfo
            _localBackupError.value = null

            prefs.edit()
                .putString(KEY_LOCAL_BACKUP_STATUS, LocalBackupStatus.COMPLETED.name)
                .putLong(KEY_LOCAL_LAST_BACKUP_MS, completedTime)
                .putString(KEY_LOCAL_LAST_FILE_NAME, fileName)
                .putString(KEY_LOCAL_LAST_FILE_PATH, targetFile.absolutePath)
                .putInt(KEY_LOCAL_LAST_RECORDS, totalRecords)
                .putLong(KEY_LOCAL_LAST_SIZE, targetFile.length())
                .remove(KEY_LOCAL_LAST_ERROR)
                .apply()

            // Record in local Room log
            val log = BackupLogEntity(
                backupId = backupId,
                startedAt = startTime,
                completedAt = completedTime,
                status = "SUCCESS",
                fileName = fileName,
                fileSize = targetFile.length(),
                recordCount = totalRecords,
                appVersion = APP_VERSION
            )
            database.backupLogDao().insertOrUpdate(log)

            Log.d(TAG, "Local device backup created and verified: $fileName, size: ${backupInfo.formattedSize}")
            Result.success(backupInfo)
        } catch (e: Exception) {
            val err = e.message ?: "Failed to create local device backup"
            Log.e(TAG, "Local backup error: $err", e)
            _localBackupStatus.value = LocalBackupStatus.FAILED
            _localBackupError.value = err
            prefs.edit()
                .putString(KEY_LOCAL_BACKUP_STATUS, LocalBackupStatus.FAILED.name)
                .putString(KEY_LOCAL_LAST_ERROR, err)
                .apply()
            Result.failure(e)
        } finally {
            _isBackingUp.value = false
        }
    }

    fun validateBackupZip(file: File, expectedChecksum: String? = null): Result<LocalBackupInfo> {
        if (!file.exists() || file.length() == 0L) {
            return Result.failure(Exception("Backup file does not exist or is empty"))
        }

        try {
            var dataContent: String? = null
            var manifestContent: String? = null

            ZipFile(file).use { zip ->
                val manifestEntry = zip.getEntry("backup_manifest.json")
                if (manifestEntry != null) {
                    manifestContent = zip.getInputStream(manifestEntry).bufferedReader(Charsets.UTF_8).use { it.readText() }
                }

                val dataEntry = zip.getEntry("backup_data.json")
                    ?: return Result.failure(Exception("Invalid backup format: backup_data.json not found in archive"))

                dataContent = zip.getInputStream(dataEntry).bufferedReader(Charsets.UTF_8).use { it.readText() }
            }

            if (dataContent.isNullOrBlank()) {
                return Result.failure(Exception("Backup data is empty or corrupt"))
            }

            // Verify checksum
            val digest = MessageDigest.getInstance("SHA-256")
            val actualChecksum = digest.digest(dataContent!!.toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it) }

            val manifestChecksum = manifestContent?.let {
                try { JSONObject(it).optString("checksum_sha256") } catch (_: Exception) { null }
            }

            val checkToMatch = expectedChecksum ?: manifestChecksum
            if (!checkToMatch.isNullOrBlank() && !checkToMatch.equals(actualChecksum, ignoreCase = true)) {
                return Result.failure(Exception("Checksum verification failed: file integrity is compromised"))
            }

            val parsedJson = JSONObject(dataContent!!)
            if (!parsedJson.has("data")) {
                return Result.failure(Exception("Backup is missing primary 'data' node"))
            }

            val totalRecords = manifestContent?.let {
                try { JSONObject(it).getJSONObject("record_counts").optInt("total_records", 0) } catch (_: Exception) { 0 }
            } ?: parsedJson.optJSONObject("backup_metadata")?.optJSONObject("record_counts")?.optInt("total_records", 0) ?: 0

            val timestamp = file.lastModified()
            val info = LocalBackupInfo(
                file = file,
                fileName = file.name,
                fileSize = file.length(),
                recordCount = totalRecords,
                timestamp = timestamp,
                formattedDate = displayDateFormat.format(Date(timestamp)),
                formattedSize = formatFileSize(file.length()),
                checksum = actualChecksum,
                location = file.parent ?: "Device Storage",
                isVerified = true
            )
            return Result.success(info)
        } catch (e: Exception) {
            return Result.failure(Exception("Backup validation failed: ${e.message}"))
        }
    }

    private fun enforceLocalBackupRetention(directory: File, maxKeep: Int = 30) {
        try {
            val backupFiles = directory.listFiles { f ->
                f.isFile && f.name.startsWith("GoatFarm_Backup_") && f.name.endsWith(".zip")
            } ?: return

            if (backupFiles.size > maxKeep) {
                // Sort by last modified descending (newest first)
                val sorted = backupFiles.sortedByDescending { it.lastModified() }
                // Remove files starting from index maxKeep
                for (i in maxKeep until sorted.size) {
                    val toDelete = sorted[i]
                    Log.d(TAG, "Deleting old backup past 30-backup retention: ${toDelete.name}")
                    toDelete.delete()
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "Retention cleanup note: ${e.message}")
        }
    }

    suspend fun getLocalBackupHistory(): List<LocalBackupInfo> = withContext(Dispatchers.IO) {
        val dir = getLocalBackupDirectory()
        val files = dir.listFiles { f ->
            f.isFile && f.name.endsWith(".zip") && (f.name.startsWith("GoatFarm_Backup_") || f.name.startsWith("GoatFarm_Safety_Backup_"))
        } ?: return@withContext emptyList()

        files.sortedByDescending { it.lastModified() }.mapNotNull { f ->
            validateBackupZip(f).getOrNull()
        }
    }

    suspend fun restoreLocalDeviceBackup(backupFile: File): Result<Boolean> = withContext(Dispatchers.IO) {
        if (_isRestoring.value) return@withContext Result.failure(Exception("Restore operation is already in progress"))
        _isRestoring.value = true

        try {
            // 1. Validate the backup archive
            val validation = validateBackupZip(backupFile)
            if (validation.isFailure) {
                return@withContext Result.failure(validation.exceptionOrNull() ?: Exception("Corrupt backup file"))
            }

            // 2. Extract backup_data.json
            var jsonString: String? = null
            ZipFile(backupFile).use { zip ->
                val entry = zip.getEntry("backup_data.json")
                    ?: return@withContext Result.failure(Exception("backup_data.json not found in archive"))
                jsonString = zip.getInputStream(entry).bufferedReader(Charsets.UTF_8).use { it.readText() }
            }

            if (jsonString.isNullOrBlank()) {
                return@withContext Result.failure(Exception("Extracted backup data is empty"))
            }

            val rootJson = JSONObject(jsonString!!)
            if (!rootJson.has("data")) {
                return@withContext Result.failure(Exception("Missing 'data' section in backup"))
            }

            // 3. Create a SAFETY BACKUP of current data before touching the database
            try {
                createLocalDeviceBackup(isSafety = true)
            } catch (e: Exception) {
                Log.w(TAG, "Pre-restore safety backup note: ${e.message}")
            }

            // 4. Restore data into SQLite Room
            val dataObj = rootJson.getJSONObject("data")
            restoreDataIntoDatabase(dataObj)

            Log.d(TAG, "Local device backup restored successfully from ${backupFile.name}")
            Result.success(true)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to restore backup: ${e.message}", e)
            Result.failure(e)
        } finally {
            _isRestoring.value = false
        }
    }

    fun setAutoBackupEnabled(enabled: Boolean) {
        _isAutoBackupEnabled.value = enabled
        prefs.edit().putBoolean(KEY_AUTO_BACKUP_ENABLED, enabled).apply()
        if (enabled) {
            scheduleDailyBackup()
            if (_backupStatus.value == DriveBackupStatus.IDLE) {
                _backupStatus.value = DriveBackupStatus.PENDING
                prefs.edit().putString(KEY_BACKUP_STATUS, DriveBackupStatus.PENDING.name).apply()
            }
        } else {
            cancelDailyBackup()
        }
    }

    fun scheduleDailyBackup() {
        try {
            val constraints = Constraints.Builder()
                .setRequiredNetworkType(NetworkType.CONNECTED)
                .build()

            val periodicWork = PeriodicWorkRequestBuilder<DailyGoogleDriveBackupWorker>(
                24, TimeUnit.HOURS,
                30, TimeUnit.MINUTES
            )
                .setConstraints(constraints)
                .addTag("daily_google_drive_backup")
                .build()

            WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                WORK_TAG,
                ExistingPeriodicWorkPolicy.KEEP,
                periodicWork
            )
            Log.d(TAG, "Daily Google Drive backup scheduled (approx. once every 24 hours)")
        } catch (e: Exception) {
            Log.w(TAG, "Could not schedule cloud backup via WorkManager: ${e.message}")
        }
    }

    fun cancelDailyBackup() {
        try {
            WorkManager.getInstance(context).cancelUniqueWork(WORK_TAG)
            Log.d(TAG, "Daily Google Drive backup cancelled")
        } catch (e: Exception) {
            Log.w(TAG, "Could not cancel cloud backup via WorkManager: ${e.message}")
        }
    }

    fun getStatusDisplayMessage(isOnline: Boolean): String {
        val lastMs = _lastBackupTime.value
        val formattedLast = if (lastMs > 0) displayDateFormat.format(Date(lastMs)) else "Never"

        return when (_backupStatus.value) {
            DriveBackupStatus.SYNCED -> "✓ Google Drive backup completed\nLast backup: $formattedLast"
            DriveBackupStatus.PENDING -> if (!isOnline) "○ Backup pending\nWaiting for internet" else "○ Backup pending\nWaiting for schedule"
            DriveBackupStatus.FAILED -> "⚠ Backup failed\n${_lastError.value ?: "Tap to retry"}"
            DriveBackupStatus.IN_PROGRESS -> "○ Google Drive backup in progress..."
            DriveBackupStatus.IDLE -> "○ Google Drive backup idle\nLast backup: $formattedLast"
        }
    }

    suspend fun createBackup(isScheduled: Boolean = false): Result<String> = withContext(Dispatchers.IO) {
        if (_isBackingUp.value) {
            return@withContext Result.failure(Exception("Backup already in progress"))
        }

        val startTime = System.currentTimeMillis()
        val deterministicDay = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date(startTime))
        val backupId = if (isScheduled) "daily-backup-$deterministicDay" else "manual-backup-${UUID.randomUUID()}"

        // Deduplication check for daily scheduled jobs
        if (isScheduled) {
            val existing = database.backupLogDao().getBackupById(backupId)
            if (existing != null && existing.status == "SUCCESS") {
                Log.d(TAG, "Scheduled backup for today ($deterministicDay) already completed successfully.")
                return@withContext Result.success(existing.googleDriveFileId ?: "")
            }
        }

        _isBackingUp.value = true
        _backupStatus.value = DriveBackupStatus.IN_PROGRESS
        prefs.edit().putString(KEY_BACKUP_STATUS, DriveBackupStatus.IN_PROGRESS.name).apply()

        // Insert initial log
        val initialLog = BackupLogEntity(
            backupId = backupId,
            startedAt = startTime,
            status = "IN_PROGRESS",
            appVersion = APP_VERSION
        )
        database.backupLogDao().insertOrUpdate(initialLog)

        try {
            // 1. Synchronize pending local changes with Supabase first if online
            try {
                syncManager.syncNow()
            } catch (e: Exception) {
                Log.w(TAG, "Pre-backup Supabase sync note: ${e.message}")
            }

            // 2. Obtain Google OAuth token
            val tokenRes = authManager.getAccessToken()
            if (tokenRes.isFailure) {
                val err = "Google account not connected or authorization expired"
                recordFailure(backupId, startTime, err)
                return@withContext Result.failure(Exception(err))
            }
            val accessToken = tokenRes.getOrThrow()

            // 3. Resolve destination folder: "Goat Farm Manager / Backups"
            val folderRes = driveService.getOrCreateBackupsFolder(accessToken)
            if (folderRes.isFailure) {
                val err = folderRes.exceptionOrNull()?.message ?: "Failed to access Google Drive folders"
                recordFailure(backupId, startTime, err)
                return@withContext Result.failure(Exception(err))
            }
            val backupsFolderId = folderRes.getOrThrow()

            // 4. Extract entire farm dataset from local Room database
            val backupPayload = buildBackupPayload(backupId, startTime)
            val jsonContent = backupPayload.toString(2)
            val totalRecords = backupPayload.getJSONObject("backup_metadata").getJSONObject("record_counts").optInt("total_records", 0)

            // 5. Upload backup file to Google Drive
            val fileName = "goat-farm-backup-${fileNameFormat.format(Date(startTime))}.json"
            val uploadRes = driveService.uploadBackupFile(
                folderId = backupsFolderId,
                fileName = fileName,
                jsonContent = jsonContent,
                accessToken = accessToken
            )

            if (uploadRes.isFailure) {
                val err = uploadRes.exceptionOrNull()?.message ?: "Upload to Google Drive failed"
                recordFailure(backupId, startTime, err)
                return@withContext Result.failure(Exception(err))
            }

            val driveFileId = uploadRes.getOrThrow()
            val completedTime = System.currentTimeMillis()

            // 6. Enforce retention policy: keep 30 latest backups, never delete only backup
            driveService.enforceRetention(backupsFolderId, keepCount = 30, accessToken = accessToken)

            // 7. Update logs and status
            val successLog = BackupLogEntity(
                backupId = backupId,
                startedAt = startTime,
                completedAt = completedTime,
                status = "SUCCESS",
                googleDriveFileId = driveFileId,
                fileName = fileName,
                fileSize = jsonContent.toByteArray().size.toLong(),
                recordCount = totalRecords,
                appVersion = APP_VERSION
            )
            database.backupLogDao().insertOrUpdate(successLog)

            _lastBackupTime.value = completedTime
            _nextBackupTime.value = completedTime + (24 * 60 * 60 * 1000L)
            _backupStatus.value = DriveBackupStatus.SYNCED
            _lastError.value = null

            prefs.edit()
                .putLong(KEY_LAST_BACKUP_MS, completedTime)
                .putLong(KEY_NEXT_BACKUP_MS, _nextBackupTime.value)
                .putString(KEY_BACKUP_STATUS, DriveBackupStatus.SYNCED.name)
                .putString(KEY_LAST_BACKUP_FILE_ID, driveFileId)
                .remove(KEY_LAST_ERROR)
                .apply()

            Log.d(TAG, "Google Drive backup completed successfully: $fileName ($driveFileId)")
            Result.success(driveFileId)
        } catch (e: Exception) {
            val err = e.message ?: "Backup failed"
            recordFailure(backupId, startTime, err)
            Result.failure(e)
        } finally {
            _isBackingUp.value = false
        }
    }

    private suspend fun recordFailure(backupId: String, startTime: Long, error: String) {
        val completedTime = System.currentTimeMillis()
        val failLog = BackupLogEntity(
            backupId = backupId,
            startedAt = startTime,
            completedAt = completedTime,
            status = "FAILED",
            errorMessage = error,
            appVersion = APP_VERSION
        )
        database.backupLogDao().insertOrUpdate(failLog)

        _backupStatus.value = DriveBackupStatus.FAILED
        _lastError.value = error
        prefs.edit()
            .putString(KEY_BACKUP_STATUS, DriveBackupStatus.FAILED.name)
            .putString(KEY_LAST_ERROR, error)
            .apply()
    }

    suspend fun listAvailableBackups(): Result<List<DriveBackupFile>> = withContext(Dispatchers.IO) {
        try {
            val tokenRes = authManager.getAccessToken()
            if (tokenRes.isFailure) return@withContext Result.failure(tokenRes.exceptionOrNull() ?: Exception("Google auth required"))
            val token = tokenRes.getOrThrow()

            val folderRes = driveService.getOrCreateBackupsFolder(token)
            if (folderRes.isFailure) return@withContext Result.failure(folderRes.exceptionOrNull() ?: Exception("Folder error"))
            val folderId = folderRes.getOrThrow()

            driveService.listBackups(folderId, token)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun restoreBackup(fileId: String): Result<Boolean> = withContext(Dispatchers.IO) {
        if (_isRestoring.value) return@withContext Result.failure(Exception("Restore already in progress"))
        _isRestoring.value = true

        try {
            // 1. Download file content from Google Drive
            val tokenRes = authManager.getAccessToken()
            if (tokenRes.isFailure) return@withContext Result.failure(Exception("Google authorization failed"))
            val token = tokenRes.getOrThrow()

            val downloadRes = driveService.downloadBackupContent(fileId, token)
            if (downloadRes.isFailure) return@withContext Result.failure(Exception("Failed to download backup file"))
            val backupJsonString = downloadRes.getOrThrow()

            val rootJson = JSONObject(backupJsonString)
            if (!rootJson.has("data")) {
                return@withContext Result.failure(Exception("Invalid backup format: missing data payload"))
            }

            // 2. CREATE A SAFETY SNAPSHOT of current local data before touching anything!
            val safetySnapshot = buildBackupPayload("pre-restore-safety-${System.currentTimeMillis()}", System.currentTimeMillis())
            try {
                val safetyFile = File(context.filesDir, "safety_backup_${System.currentTimeMillis()}.json")
                safetyFile.writeText(safetySnapshot.toString())
                Log.d(TAG, "Safety backup saved to ${safetyFile.absolutePath}")
            } catch (e: Exception) {
                Log.w(TAG, "Safety backup file save warning: ${e.message}")
            }

            // 3. Restore all datasets into Room database
            val dataObj = rootJson.getJSONObject("data")
            restoreDataIntoDatabase(dataObj)

            // 4. Trigger Supabase synchronization carefully to update cloud with restored records
            try {
                syncManager.syncNow()
            } catch (e: Exception) {
                Log.w(TAG, "Post-restore Supabase sync note: ${e.message}")
            }

            Log.d(TAG, "Successfully restored farm data from backup $fileId")
            Result.success(true)
        } catch (e: Exception) {
            Log.e(TAG, "Restore failed: ${e.message}", e)
            Result.failure(e)
        } finally {
            _isRestoring.value = false
        }
    }

    private suspend fun buildBackupPayload(backupId: String, timestamp: Long): JSONObject {
        val goats = database.goatDao().getAllGoats()
        val weights = database.healthDao().getAllWeights()
        val vaccinations = database.healthDao().getAllVaccinations()
        val dewormings = database.healthDao().getAllDewormings()
        val treatments = database.healthDao().getAllTreatments()
        val matings = database.breedingDao().getAllMatings()
        val pregnancies = database.breedingDao().getAllPregnancies()
        val kiddings = database.breedingDao().getAllKiddings()
        val kids = database.breedingDao().getAllKids()
        val feedItems = database.inventoryDao().getAllFeedItems()
        val feedMovements = database.inventoryDao().getAllFeedMovements()
        val medicines = database.inventoryDao().getAllMedicines()
        val tasks = database.tasksDao().getAllTasks()
        val sales = database.salesDao().getAllSales()
        val transactions = database.transactionDao().getAllTransactions()
        val settings = database.farmSettingsDao().getAllSettings()
        val payments = database.paymentLedgerDao().getAllPayments()
        val customers = database.customerDao().getAllCustomers()
        val deliveries = database.deliveryDao().getAllDeliveries()
        val smsCandidates = database.smsReconciliationDao().getAllCandidates()
        val fodderSpecies = database.fodderDao().getAllSpecies()
        val fodderPlots = database.fodderDao().getAllPlots()
        val fodderRows = database.fodderDao().getAllRows()
        val fodderCycles = database.fodderDao().getAllCropCycles()
        val fodderMaterials = database.fodderDao().getAllMaterials()
        val fodderActivities = database.fodderDao().getAllActivities()
        val fodderCuttings = database.fodderDao().getAllCuttings()
        val fodderFeedings = database.fodderDao().getAllFeedings()
        val fodderAdjustments = database.fodderDao().getAllStockAdjustments()
        val weaningRecords = database.weaningDao().getAllWeaningRecordsSync()
        val weaningBatches = database.weaningDao().getAllWeaningBatchesSync()

        val totalRecords = goats.size + weights.size + vaccinations.size + dewormings.size +
                treatments.size + matings.size + pregnancies.size + kiddings.size + kids.size +
                feedItems.size + feedMovements.size + medicines.size + tasks.size + sales.size +
                transactions.size + settings.size + payments.size + customers.size + deliveries.size +
                smsCandidates.size + fodderSpecies.size + fodderPlots.size +
                fodderRows.size + fodderCycles.size + fodderMaterials.size + fodderActivities.size +
                fodderCuttings.size + fodderFeedings.size + fodderAdjustments.size +
                weaningRecords.size + weaningBatches.size

        val isoTimestamp = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US).apply {
            timeZone = TimeZone.getTimeZone("UTC")
        }.format(Date(timestamp))

        val metadata = JSONObject().apply {
            put("backup_id", backupId)
            put("backup_timestamp", isoTimestamp)
            put("backup_timestamp_ms", timestamp)
            put("app_version", APP_VERSION)
            put("database_schema_version", SCHEMA_VERSION)
            put("backup_format_version", BACKUP_FORMAT_VERSION)
            put("farm_identifier", "Goat Farm Field")
            put("record_counts", JSONObject().apply {
                put("total_records", totalRecords)
                put("goats", goats.size)
                put("weights", weights.size)
                put("vaccinations", vaccinations.size)
                put("dewormings", dewormings.size)
                put("treatments", treatments.size)
                put("matings", matings.size)
                put("pregnancies", pregnancies.size)
                put("kiddings", kiddings.size)
                put("kids", kids.size)
                put("feed_inventory", feedItems.size)
                put("feed_movements", feedMovements.size)
                put("medicines", medicines.size)
                put("tasks", tasks.size)
                put("sales", sales.size)
                put("payments", payments.size)
                put("customers", customers.size)
                put("deliveries", deliveries.size)
                put("sms_candidates", smsCandidates.size)
                put("transactions", transactions.size)
                put("settings", settings.size)
                put("fodder_species", fodderSpecies.size)
                put("fodder_plots", fodderPlots.size)
                put("fodder_rows", fodderRows.size)
                put("fodder_crop_cycles", fodderCycles.size)
                put("fodder_materials", fodderMaterials.size)
                put("fodder_activities", fodderActivities.size)
                put("fodder_cuttings", fodderCuttings.size)
                put("fodder_feedings", fodderFeedings.size)
                put("fodder_stock_adjustments", fodderAdjustments.size)
            })
        }

        val data = JSONObject().apply {
            put("goats", JSONArray().apply {
                for (g in goats) put(JSONObject().apply {
                    put("id", g.id)
                    put("name", g.name)
                    put("tag_c", g.tag_c)
                    put("breed_c", g.breed_c)
                    put("sex_c", g.sex_c)
                    put("status_c", g.status_c)
                    put("birth_date_c", g.birth_date_c)
                    if (g.weight_kg_c != null) put("weight_kg_c", g.weight_kg_c)
                    put("dam_c", g.dam_c)
                    put("sire_c", g.sire_c)
                    put("source_c", g.source_c)
                    put("purchase_date_c", g.purchase_date_c)
                    if (g.purchase_cost_c != null) put("purchase_cost_c", g.purchase_cost_c)
                    put("farm_location_c", g.farm_location_c)
                    put("color_c", g.color_c)
                    put("notes_c", g.notes_c)
                    put("created_at", g.created_at)
                    put("origin_c", g.effectiveOrigin)
                })
            })

            put("weights", JSONArray().apply {
                for (w in weights) put(JSONObject().apply {
                    put("id", w.id)
                    put("goat_id_c", w.goat_id_c)
                    put("weight_kg_c", w.weight_kg_c)
                    put("date_c", w.date_c)
                    put("method_c", w.method_c)
                    put("notes_c", w.notes_c)
                })
            })

            put("vaccinations", JSONArray().apply {
                for (v in vaccinations) put(JSONObject().apply {
                    put("id", v.id)
                    put("goat_id_c", v.goat_id_c)
                    put("vaccine_c", v.vaccine_c)
                    put("dose_c", v.dose_c)
                    put("administered_date_c", v.administered_date_c)
                    put("next_due_date_c", v.next_due_date_c)
                    put("batch_number_c", v.batch_number_c)
                    put("administered_by_c", v.administered_by_c)
                    put("notes_c", v.notes_c)
                })
            })

            put("dewormings", JSONArray().apply {
                for (d in dewormings) put(JSONObject().apply {
                    put("id", d.id)
                    put("goat_id_c", d.goat_id_c)
                    put("medicine_c", d.medicine_c)
                    put("dose_c", d.dose_c)
                    put("treatment_date_c", d.treatment_date_c)
                    put("next_due_date_c", d.next_due_date_c)
                    if (d.weight_at_treatment_c != null) put("weight_at_treatment_c", d.weight_at_treatment_c)
                    put("administered_by_c", d.administered_by_c)
                    put("notes_c", d.notes_c)
                })
            })

            put("treatments", JSONArray().apply {
                for (t in treatments) put(JSONObject().apply {
                    put("id", t.id)
                    put("goat_id_c", t.goat_id_c)
                    put("symptoms_c", t.symptoms_c)
                    put("diagnosis_c", t.diagnosis_c)
                    put("medicine_c", t.medicine_c)
                    put("dose_c", t.dose_c)
                    put("start_date_c", t.start_date_c)
                    put("end_date_c", t.end_date_c)
                    put("veterinarian_c", t.veterinarian_c)
                    put("outcome_c", t.outcome_c)
                    put("notes_c", t.notes_c)
                })
            })

            put("matings", JSONArray().apply {
                for (m in matings) put(JSONObject().apply {
                    put("id", m.id)
                    put("doe_id_c", m.doe_id_c)
                    put("buck_id_c", m.buck_id_c)
                    put("mating_date_c", m.mating_date_c)
                    put("heat_observed_c", m.heat_observed_c)
                    put("method_c", m.method_c)
                    put("notes_c", m.notes_c)
                })
            })

            put("pregnancies", JSONArray().apply {
                for (p in pregnancies) put(JSONObject().apply {
                    put("id", p.id)
                    put("doe_id_c", p.doe_id_c)
                    put("mating_record_id_c", p.mating_record_id_c)
                    put("confirmation_date_c", p.confirmation_date_c)
                    put("expected_kidding_date_c", p.expected_kidding_date_c)
                    put("status_c", p.status_c)
                    put("actual_kidding_date_c", p.actual_kidding_date_c)
                    put("notes_c", p.notes_c)
                })
            })

            put("kiddings", JSONArray().apply {
                for (k in kiddings) put(JSONObject().apply {
                    put("id", k.id)
                    put("doe_id_c", k.doe_id_c)
                    put("pregnancy_id_c", k.pregnancy_id_c)
                    put("kidding_date_c", k.kidding_date_c)
                    put("birth_type_c", k.birth_type_c)
                    put("assistance_c", k.assistance_c)
                    put("complications_c", k.complications_c)
                    put("notes_c", k.notes_c)
                })
            })

            put("kids", JSONArray().apply {
                for (kid in kids) put(JSONObject().apply {
                    put("id", kid.id)
                    put("kid_tag_c", kid.kid_tag_c)
                    put("kidding_record_id_c", kid.kidding_record_id_c)
                    if (kid.birth_weight_c != null) put("birth_weight_c", kid.birth_weight_c)
                    put("birth_order_c", kid.birth_order_c)
                    put("notes_c", kid.notes_c)
                })
            })

            put("feed_inventory", JSONArray().apply {
                for (f in feedItems) put(JSONObject().apply {
                    put("id", f.id)
                    put("name_c", f.name_c)
                    put("category_c", f.category_c)
                    put("current_stock_kg_c", f.current_stock_kg_c)
                    put("unit_c", f.unit_c)
                    if (f.cost_per_unit_c != null) put("cost_per_unit_c", f.cost_per_unit_c)
                })
            })

            put("feed_movements", JSONArray().apply {
                for (m in feedMovements) put(JSONObject().apply {
                    put("id", m.id)
                    put("feed_id_c", m.feed_id_c)
                    put("movement_type_c", m.movement_type_c)
                    put("quantity_c", m.quantity_c)
                    put("date_c", m.date_c)
                    put("notes_c", m.notes_c)
                })
            })

            put("medicines", JSONArray().apply {
                for (med in medicines) put(JSONObject().apply {
                    put("id", med.id)
                    put("medicine_name_c", med.medicine_name_c)
                    put("category_c", med.category_c)
                    put("quantity_c", med.quantity_c)
                    put("unit_c", med.unit_c)
                    put("reorder_level_c", med.reorder_level_c)
                    if (med.unit_cost_c != null) put("unit_cost_c", med.unit_cost_c)
                    put("expiry_date_c", med.expiry_date_c)
                    put("supplier_c", med.supplier_c)
                })
            })

            put("tasks", JSONArray().apply {
                for (t in tasks) put(JSONObject().apply {
                    put("id", t.id)
                    put("title_c", t.title_c)
                    put("description_c", t.description_c)
                    put("due_date_c", t.due_date_c)
                    put("priority_c", t.priority_c)
                    put("status_c", t.status_c)
                    put("assigned_to_c", t.assigned_to_c)
                    put("related_goat_id_c", t.related_goat_id_c)
                })
            })

            put("sales", JSONArray().apply {
                for (s in sales) put(JSONObject().apply {
                    put("id", s.id)
                    put("goat_id_c", s.goat_id_c)
                    put("amount_c", s.amount_c)
                    put("sale_date_c", s.sale_date_c)
                    put("buyer_name_c", s.buyer_name_c)
                    put("buyer_phone_c", s.buyer_phone_c)
                    put("payment_mode_c", s.payment_mode_c)
                    put("payment_status_c", s.payment_status_c)
                    put("notes_c", s.notes_c)
                    put("created_at", s.created_at)
                    put("order_id_c", s.order_id_c)
                    put("transaction_id_c", s.transaction_id_c)
                    put("bank_transaction_id_c", s.bank_transaction_id_c)
                    put("reference_c", s.reference_c)
                    put("currency_c", s.currency_c)
                    put("payment_timestamp_c", s.payment_timestamp_c)
                    put("failure_reason_c", s.failure_reason_c)
                    put("sale_type_c", s.sale_type_c)
                    put("quantity_c", s.quantity_c)
                    put("total_weight_kg_c", s.total_weight_kg_c)
                    put("rate_per_unit_c", s.rate_per_unit_c)
                    put("buyer_address_c", s.buyer_address_c)
                    put("buyer_village_c", s.buyer_village_c)
                    put("amount_paid_c", s.amount_paid_c)
                    put("balance_due_c", s.balance_due_c)
                    put("delivery_status_c", s.delivery_status_c)
                    put("expected_delivery_date_c", s.expected_delivery_date_c)
                    put("actual_delivery_date_c", s.actual_delivery_date_c)
                    put("delivery_photo_uri_c", s.delivery_photo_uri_c)
                    put("delivery_notes_c", s.delivery_notes_c)
                    put("customer_id_c", s.customer_id_c)
                })
            })

            put("payments", JSONArray().apply {
                for (p in payments) put(JSONObject().apply {
                    put("id", p.id)
                    put("sale_id_c", p.sale_id_c)
                    put("customer_id_c", p.customer_id_c)
                    put("amount_c", p.amount_c)
                    put("payment_method_c", p.payment_method_c)
                    put("payment_date_c", p.payment_date_c)
                    put("reference_number_c", p.reference_number_c)
                    put("notes_c", p.notes_c)
                    put("source_c", p.source_c)
                    put("created_at", p.created_at)
                })
            })

            put("customers", JSONArray().apply {
                for (c in customers) put(JSONObject().apply {
                    put("id", c.id)
                    put("name_c", c.name_c)
                    put("phone_c", c.phone_c)
                    put("address_c", c.address_c)
                    put("village_c", c.village_c)
                    put("outstanding_balance_c", c.outstanding_balance_c)
                    put("total_purchases_c", c.total_purchases_c)
                    put("total_paid_c", c.total_paid_c)
                    put("notes_c", c.notes_c)
                    put("created_at", c.created_at)
                })
            })

            put("deliveries", JSONArray().apply {
                for (d in deliveries) put(JSONObject().apply {
                    put("id", d.id)
                    put("sale_id_c", d.sale_id_c)
                    put("goat_id_c", d.goat_id_c)
                    put("customer_id_c", d.customer_id_c)
                    put("recipient_name_c", d.recipient_name_c)
                    put("recipient_phone_c", d.recipient_phone_c)
                    put("delivery_address_c", d.delivery_address_c)
                    put("expected_delivery_date_c", d.expected_delivery_date_c)
                    put("actual_delivery_date_c", d.actual_delivery_date_c)
                    put("delivery_status_c", d.delivery_status_c)
                    put("delivery_photo_uri_c", d.delivery_photo_uri_c)
                    put("delivery_notes_c", d.delivery_notes_c)
                    put("outstanding_balance_c", d.outstanding_balance_c)
                    put("is_delivered", d.is_delivered)
                    put("marked_by_c", d.marked_by_c)
                    put("created_at", d.created_at)
                })
            })

            put("sms_candidates", JSONArray().apply {
                for (sc in smsCandidates) put(JSONObject().apply {
                    put("id", sc.id)
                    put("amount", sc.amount)
                    put("referenceNumber", sc.referenceNumber)
                    put("upiId", sc.upiId)
                    put("sender", sc.sender)
                    put("rawSnippet", sc.rawSnippet)
                    put("timestamp", sc.timestamp)
                    put("matchedSaleId", sc.matchedSaleId)
                    put("status", sc.status)
                })
            })

            put("transactions", JSONArray().apply {
                for (tx in transactions) put(JSONObject().apply {
                    put("id", tx.id)
                    put("transaction_type_c", tx.transaction_type_c)
                    put("amount_c", tx.amount_c)
                    put("date_c", tx.date_c)
                    put("category_c", tx.category_c)
                    put("description_c", tx.description_c)
                    put("payment_mode_c", tx.payment_mode_c)
                    put("payment_status_c", tx.payment_status_c)
                    put("related_id_c", tx.related_id_c)
                })
            })

            put("settings", JSONArray().apply {
                for (st in settings) put(JSONObject().apply {
                    put("key", st.key)
                    put("value_c", st.value_c)
                })
            })

            put("fodder_species", JSONArray().apply {
                for (sp in fodderSpecies) put(JSONObject().apply {
                    put("id", sp.id)
                    put("name", sp.name)
                    put("scientific_name", sp.scientific_name)
                    put("category", sp.category)
                    put("crude_protein_pct", sp.crude_protein_pct)
                    put("dry_matter_pct", sp.dry_matter_pct)
                    put("days_to_first_cut", sp.days_to_first_cut)
                    put("regrowth_interval_days", sp.regrowth_interval_days)
                    put("cutting_height_cm", sp.cutting_height_cm)
                    put("expected_yield_per_acre_cut_kg", sp.expected_yield_per_acre_cut_kg)
                    put("water_requirement", sp.water_requirement)
                    put("notes", sp.notes)
                })
            })

            put("fodder_plots", JSONArray().apply {
                for (p in fodderPlots) put(JSONObject().apply {
                    put("id", p.id)
                    put("plot_name", p.plot_name)
                    put("area_value", p.area_value)
                    put("area_unit", p.area_unit)
                    put("variety", p.variety)
                    put("row_count", p.row_count)
                    put("row_length", p.row_length)
                    put("row_length_unit", p.row_length_unit)
                    put("row_spacing", p.row_spacing)
                    put("row_spacing_unit", p.row_spacing_unit)
                    put("calculated_cultivated_area", p.calculated_cultivated_area)
                    put("calculated_area_unit", p.calculated_area_unit)
                    if (p.latitude != null) put("latitude", p.latitude)
                    if (p.longitude != null) put("longitude", p.longitude)
                    if (p.gps_accuracy != null) put("gps_accuracy", p.gps_accuracy)
                    put("location_tag", p.location_tag)
                    put("species_id", p.species_id)
                    put("species_name", p.species_name)
                    put("sowing_date", p.sowing_date)
                    put("crop_cycle_status", p.crop_cycle_status)
                    put("current_cut_count", p.current_cut_count)
                    put("last_cut_date", p.last_cut_date)
                    put("next_expected_cut_date", p.next_expected_cut_date)
                    put("irrigation_type", p.irrigation_type)
                    put("soil_type", p.soil_type)
                    put("notes", p.notes)
                })
            })

            put("fodder_rows", JSONArray().apply {
                for (r in fodderRows) put(JSONObject().apply {
                    put("id", r.id)
                    put("plot_id", r.plot_id)
                    put("row_index", r.row_index)
                    put("row_code", r.row_code)
                    put("crop_cycle_id", r.crop_cycle_id)
                    put("species_name", r.species_name)
                    put("variety", r.variety)
                    put("status", r.status)
                    put("length_m", r.length_m)
                    put("spacing_m", r.spacing_m)
                    put("planting_date", r.planting_date)
                    put("planting_method", r.planting_method)
                    put("last_cut_date", r.last_cut_date)
                    put("next_expected_cut_date", r.next_expected_cut_date)
                    put("total_cuts", r.total_cuts)
                    put("total_yield_kg", r.total_yield_kg)
                    put("notes", r.notes)
                })
            })

            put("fodder_crop_cycles", JSONArray().apply {
                for (cy in fodderCycles) put(JSONObject().apply {
                    put("id", cy.id)
                    put("plot_id", cy.plot_id)
                    put("cycle_number", cy.cycle_number)
                    put("cycle_name", cy.cycle_name)
                    put("species_name", cy.species_name)
                    put("variety", cy.variety)
                    put("planting_date", cy.planting_date)
                    put("planting_method", cy.planting_method)
                    put("row_codes", cy.row_codes)
                    put("rows_count", cy.rows_count)
                    put("status", cy.status)
                    put("start_date", cy.start_date)
                    put("end_date", cy.end_date)
                    put("total_production_kg", cy.total_production_kg)
                    put("total_cuts_count", cy.total_cuts_count)
                    put("notes", cy.notes)
                })
            })

            put("fodder_materials", JSONArray().apply {
                for (m in fodderMaterials) put(JSONObject().apply {
                    put("id", m.id)
                    put("material_type", m.material_type)
                    put("species_name", m.species_name)
                    put("variety", m.variety)
                    put("quantity_purchased", m.quantity_purchased)
                    put("quantity_used", m.quantity_used)
                    put("quantity_remaining", m.quantity_remaining)
                    put("unit", m.unit)
                    put("unit_cost", m.unit_cost)
                    put("total_cost", m.total_cost)
                    put("supplier", m.supplier)
                    put("purchase_date", m.purchase_date)
                    put("batch_lot_number", m.batch_lot_number)
                    put("notes", m.notes)
                })
            })

            put("fodder_activities", JSONArray().apply {
                for (act in fodderActivities) put(JSONObject().apply {
                    put("id", act.id)
                    put("plot_id", act.plot_id)
                    put("plot_name", act.plot_name)
                    put("crop_cycle_id", act.crop_cycle_id)
                    put("row_codes", act.row_codes)
                    put("species_name", act.species_name)
                    put("variety", act.variety)
                    put("activity_type", act.activity_type)
                    put("activity_date", act.activity_date)
                    if (act.quantity != null) put("quantity", act.quantity)
                    put("unit", act.unit)
                    if (act.labour_hours != null) put("labour_hours", act.labour_hours)
                    if (act.labour_cost != null) put("labour_cost", act.labour_cost)
                    if (act.material_cost != null) put("material_cost", act.material_cost)
                    put("total_cost", act.total_cost)
                    if (act.weather_temp_c != null) put("weather_temp_c", act.weather_temp_c)
                    put("weather_condition", act.weather_condition)
                    if (act.weather_rainfall_mm != null) put("weather_rainfall_mm", act.weather_rainfall_mm)
                    if (act.weather_humidity_pct != null) put("weather_humidity_pct", act.weather_humidity_pct)
                    if (act.weather_wind_kmh != null) put("weather_wind_kmh", act.weather_wind_kmh)
                    put("operator_user", act.operator_user)
                    put("notes", act.notes)
                })
            })

            put("fodder_cuttings", JSONArray().apply {
                for (c in fodderCuttings) put(JSONObject().apply {
                    put("id", c.id)
                    put("plot_id", c.plot_id)
                    put("plot_name", c.plot_name)
                    put("species_id", c.species_id)
                    put("species_name", c.species_name)
                    put("cutting_date", c.cutting_date)
                    put("cut_number", c.cut_number)
                    put("harvested_weight_kg", c.harvested_weight_kg)
                    put("area_harvested_pct", c.area_harvested_pct)
                    if (c.labor_cost != null) put("labor_cost", c.labor_cost)
                    put("harvester_name", c.harvester_name)
                    put("quality_rating", c.quality_rating)
                    put("notes", c.notes)
                    put("row_codes", c.row_codes)
                    put("rows_harvested_count", c.rows_harvested_count)
                    put("row_length_m", c.row_length_m)
                    put("total_harvested_row_length_m", c.total_harvested_row_length_m)
                    put("yield_per_metre", c.yield_per_metre)
                    put("yield_per_row", c.yield_per_row)
                    put("yield_per_acre", c.yield_per_acre)
                    put("weather_summary", c.weather_summary)
                    if (c.weather_temp_c != null) put("weather_temp_c", c.weather_temp_c)
                    if (c.weather_rainfall_mm != null) put("weather_rainfall_mm", c.weather_rainfall_mm)
                })
            })

            put("fodder_feedings", JSONArray().apply {
                for (f in fodderFeedings) put(JSONObject().apply {
                    put("id", f.id)
                    put("feeding_date", f.feeding_date)
                    put("species_id", f.species_id)
                    put("species_name", f.species_name)
                    put("target_group", f.target_group)
                    put("goats_count", f.goats_count)
                    put("quantity_fed_kg", f.quantity_fed_kg)
                    put("feeding_time", f.feeding_time)
                    put("chaffed_method", f.chaffed_method)
                    put("wastage_kg", f.wastage_kg)
                    put("notes", f.notes)
                })
            })

            put("fodder_stock_adjustments", JSONArray().apply {
                for (a in fodderAdjustments) put(JSONObject().apply {
                    put("id", a.id)
                    put("date_c", a.date_c)
                    put("species_name", a.species_name)
                    put("adjustment_type", a.adjustment_type)
                    put("quantity_kg", a.quantity_kg)
                    put("notes", a.notes)
                })
            })

            put("weaning_records", JSONArray().apply {
                for (w in weaningRecords) put(JSONObject().apply {
                    put("id", w.id)
                    put("farm_id", w.farm_id)
                    put("goat_id", w.goat_id)
                    if (w.mother_goat_id != null) put("mother_goat_id", w.mother_goat_id)
                    if (w.kidding_id != null) put("kidding_id", w.kidding_id)
                    put("birth_date", w.birth_date)
                    put("weaning_due_date", w.weaning_due_date)
                    if (w.actual_weaning_date != null) put("actual_weaning_date", w.actual_weaning_date)
                    if (w.age_at_weaning_days != null) put("age_at_weaning_days", w.age_at_weaning_days)
                    if (w.weight_at_weaning != null) put("weight_at_weaning", w.weight_at_weaning)
                    put("weight_unit", w.weight_unit)
                    if (w.weaning_method != null) put("weaning_method", w.weaning_method)
                    put("status", w.status)
                    if (w.reason_if_delayed != null) put("reason_if_delayed", w.reason_if_delayed)
                    if (w.notes != null) put("notes", w.notes)
                    put("setting_source", w.setting_source)
                    put("post_weaning_feed_group", w.post_weaning_feed_group)
                    if (w.birth_weight != null) put("birth_weight", w.birth_weight)
                    if (w.prev_weight != null) put("prev_weight", w.prev_weight)
                    if (w.adg_g_per_day != null) put("adg_g_per_day", w.adg_g_per_day)
                    if (w.batch_id != null) put("batch_id", w.batch_id)
                    put("created_at", w.created_at)
                    put("updated_at", w.updated_at)
                })
            })

            put("weaning_batches", JSONArray().apply {
                for (b in weaningBatches) put(JSONObject().apply {
                    put("id", b.id)
                    put("farm_id", b.farm_id)
                    put("weaning_date", b.weaning_date)
                    put("number_of_kids", b.number_of_kids)
                    if (b.average_weight != null) put("average_weight", b.average_weight)
                    if (b.notes != null) put("notes", b.notes)
                    put("created_at", b.created_at)
                    put("updated_at", b.updated_at)
                })
            })
        }

        return JSONObject().apply {
            put("backup_metadata", metadata)
            put("data", data)
        }
    }

    private suspend fun restoreDataIntoDatabase(dataObj: JSONObject) {
        val now = System.currentTimeMillis()

        // 1. Goats
        dataObj.optJSONArray("goats")?.let { arr ->
            val list = mutableListOf<GoatEntity>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                list.add(
                    GoatEntity(
                        id = o.getString("id"),
                        name = o.optString("name", "Goat"),
                        tag_c = o.optString("tag_c", ""),
                        breed_c = o.optString("breed_c", "Boer"),
                        sex_c = o.optString("sex_c", "Doe"),
                        status_c = o.optString("status_c", "Active"),
                        birth_date_c = o.optNullable("birth_date_c"),
                        weight_kg_c = if (o.has("weight_kg_c") && !o.isNull("weight_kg_c")) o.optDouble("weight_kg_c") else null,
                        dam_c = o.optNullable("dam_c"),
                        sire_c = o.optNullable("sire_c"),
                        source_c = o.optString("source_c", "Born on farm"),
                        purchase_date_c = o.optNullable("purchase_date_c"),
                        purchase_cost_c = if (o.has("purchase_cost_c") && !o.isNull("purchase_cost_c")) o.optDouble("purchase_cost_c") else null,
                        farm_location_c = o.optString("farm_location_c", "Barn A"),
                        color_c = o.optNullable("color_c"),
                        notes_c = o.optNullable("notes_c"),
                        created_at = o.optNullable("created_at"),
                        updated_at = now,
                        is_synced = true,
                        origin_c = o.optNullable("origin_c")
                    )
                )
            }
            if (list.isNotEmpty()) database.goatDao().insertAll(list)
        }

        // 2. Weights
        dataObj.optJSONArray("weights")?.let { arr ->
            val list = mutableListOf<GoatWeightEntity>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                list.add(
                    GoatWeightEntity(
                        id = o.getString("id"),
                        goat_id_c = o.getString("goat_id_c"),
                        weight_kg_c = o.getDouble("weight_kg_c"),
                        date_c = o.getString("date_c"),
                        method_c = o.optString("method_c", "Scale"),
                        notes_c = o.optNullable("notes_c"),
                        updated_at = now,
                        is_synced = true
                    )
                )
            }
            if (list.isNotEmpty()) database.healthDao().insertAllWeights(list)
        }

        // 3. Vaccinations
        dataObj.optJSONArray("vaccinations")?.let { arr ->
            val list = mutableListOf<VaccinationEntity>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                list.add(
                    VaccinationEntity(
                        id = o.getString("id"),
                        goat_id_c = o.getString("goat_id_c"),
                        vaccine_c = o.getString("vaccine_c"),
                        dose_c = o.optString("dose_c", "1 ml"),
                        administered_date_c = o.getString("administered_date_c"),
                        next_due_date_c = o.optNullable("next_due_date_c"),
                        batch_number_c = o.optNullable("batch_number_c"),
                        administered_by_c = o.optNullable("administered_by_c"),
                        notes_c = o.optNullable("notes_c"),
                        updated_at = now,
                        is_synced = true
                    )
                )
            }
            if (list.isNotEmpty()) database.healthDao().insertAllVaccinations(list)
        }

        // 4. Dewormings
        dataObj.optJSONArray("dewormings")?.let { arr ->
            val list = mutableListOf<DewormingEntity>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                list.add(
                    DewormingEntity(
                        id = o.getString("id"),
                        goat_id_c = o.getString("goat_id_c"),
                        medicine_c = o.getString("medicine_c"),
                        dose_c = o.optString("dose_c", "5 ml"),
                        treatment_date_c = o.getString("treatment_date_c"),
                        next_due_date_c = o.optNullable("next_due_date_c"),
                        weight_at_treatment_c = if (o.has("weight_at_treatment_c") && !o.isNull("weight_at_treatment_c")) o.optDouble("weight_at_treatment_c") else null,
                        administered_by_c = o.optNullable("administered_by_c"),
                        notes_c = o.optNullable("notes_c"),
                        updated_at = now,
                        is_synced = true
                    )
                )
            }
            if (list.isNotEmpty()) database.healthDao().insertAllDewormings(list)
        }

        // 5. Treatments
        dataObj.optJSONArray("treatments")?.let { arr ->
            val list = mutableListOf<TreatmentEntity>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                list.add(
                    TreatmentEntity(
                        id = o.getString("id"),
                        goat_id_c = o.getString("goat_id_c"),
                        symptoms_c = o.optString("symptoms_c", ""),
                        diagnosis_c = o.optString("diagnosis_c", ""),
                        medicine_c = o.getString("medicine_c"),
                        dose_c = o.optString("dose_c", "2 ml"),
                        start_date_c = o.getString("start_date_c"),
                        end_date_c = o.optNullable("end_date_c"),
                        veterinarian_c = o.optNullable("veterinarian_c"),
                        outcome_c = o.optString("outcome_c", "Completed"),
                        notes_c = o.optNullable("notes_c"),
                        updated_at = now,
                        is_synced = true
                    )
                )
            }
            if (list.isNotEmpty()) database.healthDao().insertAllTreatments(list)
        }

        // 6. Matings
        dataObj.optJSONArray("matings")?.let { arr ->
            val list = mutableListOf<MatingEntity>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                list.add(
                    MatingEntity(
                        id = o.getString("id"),
                        doe_id_c = o.getString("doe_id_c"),
                        buck_id_c = o.getString("buck_id_c"),
                        mating_date_c = o.getString("mating_date_c"),
                        heat_observed_c = o.optBoolean("heat_observed_c", true),
                        method_c = o.optString("method_c", "Natural"),
                        notes_c = o.optNullable("notes_c"),
                        updated_at = now,
                        is_synced = true
                    )
                )
            }
            if (list.isNotEmpty()) database.breedingDao().insertAllMatings(list)
        }

        // 7. Pregnancies
        dataObj.optJSONArray("pregnancies")?.let { arr ->
            val list = mutableListOf<PregnancyEntity>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                list.add(
                    PregnancyEntity(
                        id = o.getString("id"),
                        doe_id_c = o.getString("doe_id_c"),
                        mating_record_id_c = o.optNullable("mating_record_id_c"),
                        confirmation_date_c = o.getString("confirmation_date_c"),
                        expected_kidding_date_c = o.getString("expected_kidding_date_c"),
                        status_c = o.optString("status_c", "Confirmed"),
                        actual_kidding_date_c = o.optNullable("actual_kidding_date_c"),
                        notes_c = o.optNullable("notes_c"),
                        updated_at = now,
                        is_synced = true
                    )
                )
            }
            if (list.isNotEmpty()) database.breedingDao().insertAllPregnancies(list)
        }

        // 8. Kiddings
        dataObj.optJSONArray("kiddings")?.let { arr ->
            val list = mutableListOf<KiddingEntity>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                list.add(
                    KiddingEntity(
                        id = o.getString("id"),
                        doe_id_c = o.getString("doe_id_c"),
                        pregnancy_id_c = o.optNullable("pregnancy_id_c"),
                        kidding_date_c = o.getString("kidding_date_c"),
                        birth_type_c = o.optString("birth_type_c", "Single"),
                        assistance_c = o.optString("assistance_c", "None"),
                        complications_c = o.optString("complications_c", "None"),
                        notes_c = o.optNullable("notes_c"),
                        updated_at = now,
                        is_synced = true
                    )
                )
            }
            if (list.isNotEmpty()) database.breedingDao().insertAllKiddings(list)
        }

        // 9. Kids
        dataObj.optJSONArray("kids")?.let { arr ->
            val list = mutableListOf<KidEntity>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                list.add(
                    KidEntity(
                        id = o.getString("id"),
                        kid_tag_c = o.getString("kid_tag_c"),
                        kidding_record_id_c = o.getString("kidding_record_id_c"),
                        birth_weight_c = if (o.has("birth_weight_c") && !o.isNull("birth_weight_c")) o.optDouble("birth_weight_c") else null,
                        birth_order_c = o.optInt("birth_order_c", 1),
                        notes_c = o.optNullable("notes_c"),
                        updated_at = now,
                        is_synced = true
                    )
                )
            }
            if (list.isNotEmpty()) database.breedingDao().insertAllKids(list)
        }

        // 10. Feed Inventory
        dataObj.optJSONArray("feed_inventory")?.let { arr ->
            val list = mutableListOf<FeedItemEntity>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                list.add(
                    FeedItemEntity(
                        id = o.getString("id"),
                        name_c = o.getString("name_c"),
                        category_c = o.optNullable("category_c") ?: "Green Fodder",
                        current_stock_kg_c = o.optDouble("current_stock_kg_c", 0.0),
                        unit_c = o.optString("unit_c", "kg"),
                        cost_per_unit_c = if (o.has("cost_per_unit_c") && !o.isNull("cost_per_unit_c")) o.optDouble("cost_per_unit_c") else null,
                        updated_at = now,
                        is_synced = true
                    )
                )
            }
            if (list.isNotEmpty()) database.inventoryDao().insertAllFeedItems(list)
        }

        // 11. Feed Movements
        dataObj.optJSONArray("feed_movements")?.let { arr ->
            val list = mutableListOf<FeedMovementEntity>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                list.add(
                    FeedMovementEntity(
                        id = o.getString("id"),
                        feed_id_c = o.getString("feed_id_c"),
                        movement_type_c = o.getString("movement_type_c"),
                        quantity_c = o.getDouble("quantity_c"),
                        date_c = o.getString("date_c"),
                        notes_c = o.optNullable("notes_c"),
                        updated_at = now,
                        is_synced = true
                    )
                )
            }
            if (list.isNotEmpty()) database.inventoryDao().insertAllFeedMovements(list)
        }

        // 12. Medicines
        dataObj.optJSONArray("medicines")?.let { arr ->
            val list = mutableListOf<MedicineEntity>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                list.add(
                    MedicineEntity(
                        id = o.getString("id"),
                        medicine_name_c = o.getString("medicine_name_c"),
                        category_c = o.optString("category_c", "Antibiotic"),
                        quantity_c = o.optDouble("quantity_c", 0.0),
                        unit_c = o.optString("unit_c", "ml"),
                        reorder_level_c = o.optDouble("reorder_level_c", 10.0),
                        unit_cost_c = if (o.has("unit_cost_c") && !o.isNull("unit_cost_c")) o.optDouble("unit_cost_c") else null,
                        expiry_date_c = o.optNullable("expiry_date_c"),
                        supplier_c = o.optNullable("supplier_c"),
                        updated_at = now,
                        is_synced = true
                    )
                )
            }
            if (list.isNotEmpty()) database.inventoryDao().insertAllMedicines(list)
        }

        // 13. Tasks
        dataObj.optJSONArray("tasks")?.let { arr ->
            val list = mutableListOf<TaskEntity>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                list.add(
                    TaskEntity(
                        id = o.getString("id"),
                        title_c = o.getString("title_c"),
                        description_c = o.optNullable("description_c"),
                        due_date_c = o.getString("due_date_c"),
                        priority_c = o.optString("priority_c", "Normal"),
                        status_c = o.optString("status_c", "Pending"),
                        assigned_to_c = o.optNullable("assigned_to_c"),
                        related_goat_id_c = o.optNullable("related_goat_id_c"),
                        updated_at = now,
                        is_synced = true
                    )
                )
            }
            if (list.isNotEmpty()) database.tasksDao().insertAll(list)
        }

        // 14. Sales
        dataObj.optJSONArray("sales")?.let { arr ->
            val list = mutableListOf<SaleEntity>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                list.add(
                    SaleEntity(
                        id = o.getString("id"),
                        goat_id_c = o.getString("goat_id_c"),
                        amount_c = o.getDouble("amount_c"),
                        sale_date_c = o.getString("sale_date_c"),
                        buyer_name_c = o.optString("buyer_name_c", ""),
                        buyer_phone_c = o.optString("buyer_phone_c", ""),
                        payment_mode_c = o.optString("payment_mode_c", "CASH"),
                        payment_status_c = o.optString("payment_status_c", "PAID"),
                        notes_c = o.optNullable("notes_c"),
                        created_at = o.optNullable("created_at"),
                        order_id_c = o.optNullable("order_id_c"),
                        transaction_id_c = o.optNullable("transaction_id_c"),
                        bank_transaction_id_c = o.optNullable("bank_transaction_id_c"),
                        reference_c = o.optNullable("reference_c"),
                        currency_c = o.optString("currency_c", "INR"),
                        payment_timestamp_c = o.optNullable("payment_timestamp_c"),
                        failure_reason_c = o.optNullable("failure_reason_c"),
                        sale_type_c = o.optString("sale_type_c", "PIECE"),
                        quantity_c = o.optInt("quantity_c", 1),
                        total_weight_kg_c = o.optDouble("total_weight_kg_c", 0.0),
                        rate_per_unit_c = o.optDouble("rate_per_unit_c", 0.0),
                        buyer_address_c = o.optString("buyer_address_c", ""),
                        buyer_village_c = o.optString("buyer_village_c", ""),
                        amount_paid_c = o.optDouble("amount_paid_c", 0.0),
                        balance_due_c = o.optDouble("balance_due_c", 0.0),
                        delivery_status_c = o.optString("delivery_status_c", "DELIVERED"),
                        expected_delivery_date_c = o.optNullable("expected_delivery_date_c"),
                        actual_delivery_date_c = o.optNullable("actual_delivery_date_c"),
                        delivery_photo_uri_c = o.optNullable("delivery_photo_uri_c"),
                        delivery_notes_c = o.optNullable("delivery_notes_c"),
                        customer_id_c = o.optNullable("customer_id_c"),
                        updated_at = now,
                        is_synced = true
                    )
                )
            }
            if (list.isNotEmpty()) database.salesDao().insertAll(list)
        }

        // 14b. Payments
        dataObj.optJSONArray("payments")?.let { arr ->
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val entity = PaymentLedgerEntity(
                    id = o.getString("id"),
                    sale_id_c = o.getString("sale_id_c"),
                    customer_id_c = o.optNullable("customer_id_c"),
                    amount_c = o.getDouble("amount_c"),
                    payment_method_c = o.optString("payment_method_c", "CASH"),
                    payment_date_c = o.optString("payment_date_c", ""),
                    reference_number_c = o.optNullable("reference_number_c"),
                    notes_c = o.optNullable("notes_c"),
                    source_c = o.optString("source_c", "MANUAL"),
                    created_at = o.optLong("created_at", now),
                    updated_at = now,
                    is_synced = true
                )
                database.paymentLedgerDao().insertPayment(entity)
            }
        }

        // 14c. Customers
        dataObj.optJSONArray("customers")?.let { arr ->
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val entity = CustomerEntity(
                    id = o.getString("id"),
                    name_c = o.getString("name_c"),
                    phone_c = o.optString("phone_c", ""),
                    address_c = o.optString("address_c", ""),
                    village_c = o.optString("village_c", ""),
                    outstanding_balance_c = o.optDouble("outstanding_balance_c", 0.0),
                    total_purchases_c = o.optDouble("total_purchases_c", 0.0),
                    total_paid_c = o.optDouble("total_paid_c", 0.0),
                    notes_c = o.optNullable("notes_c"),
                    created_at = o.optString("created_at", ""),
                    updated_at = now,
                    is_synced = true
                )
                database.customerDao().insertOrUpdate(entity)
            }
        }

        // 14d. Deliveries
        dataObj.optJSONArray("deliveries")?.let { arr ->
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val entity = DeliveryRecordEntity(
                    id = o.getString("id"),
                    sale_id_c = o.getString("sale_id_c"),
                    goat_id_c = o.optNullable("goat_id_c"),
                    customer_id_c = o.optNullable("customer_id_c"),
                    recipient_name_c = o.optString("recipient_name_c", ""),
                    recipient_phone_c = o.optString("recipient_phone_c", ""),
                    delivery_address_c = o.optString("delivery_address_c", ""),
                    expected_delivery_date_c = o.optNullable("expected_delivery_date_c"),
                    actual_delivery_date_c = o.optNullable("actual_delivery_date_c"),
                    delivery_status_c = o.optString("delivery_status_c", "EXPECTED"),
                    delivery_photo_uri_c = o.optNullable("delivery_photo_uri_c"),
                    delivery_notes_c = o.optNullable("delivery_notes_c"),
                    outstanding_balance_c = o.optDouble("outstanding_balance_c", 0.0),
                    is_delivered = o.optBoolean("is_delivered", false),
                    marked_by_c = o.optNullable("marked_by_c"),
                    created_at = o.optLong("created_at", now),
                    updated_at = now,
                    is_synced = true
                )
                database.deliveryDao().insertOrUpdate(entity)
            }
        }

        // 14e. SMS Candidates
        dataObj.optJSONArray("sms_candidates")?.let { arr ->
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val entity = SmsPaymentCandidateEntity(
                    id = o.getString("id"),
                    amount = o.getDouble("amount"),
                    referenceNumber = o.optNullable("referenceNumber"),
                    upiId = o.optNullable("upiId"),
                    sender = o.optString("sender", ""),
                    rawSnippet = o.optString("rawSnippet", ""),
                    timestamp = o.optLong("timestamp", now),
                    matchedSaleId = o.optNullable("matchedSaleId"),
                    status = o.optString("status", "PENDING")
                )
                database.smsReconciliationDao().insertCandidate(entity)
            }
        }

        // 15. Transactions
        dataObj.optJSONArray("transactions")?.let { arr ->
            val list = mutableListOf<TransactionEntity>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                list.add(
                    TransactionEntity(
                        id = o.getString("id"),
                        transaction_type_c = o.optString("transaction_type_c", "Sale"),
                        amount_c = o.getDouble("amount_c"),
                        date_c = o.getString("date_c"),
                        category_c = o.optNullable("category_c"),
                        description_c = o.optNullable("description_c"),
                        payment_mode_c = o.optString("payment_mode_c", "Cash"),
                        payment_status_c = o.optString("payment_status_c", "Received"),
                        related_id_c = o.optNullable("related_id_c"),
                        updated_at = now,
                        is_synced = true
                    )
                )
            }
            if (list.isNotEmpty()) database.transactionDao().insertAll(list)
        }

        // 16. Farm Settings
        dataObj.optJSONArray("settings")?.let { arr ->
            val list = mutableListOf<FarmSettingEntity>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                list.add(
                    FarmSettingEntity(
                        key = o.getString("key"),
                        value_c = o.getString("value_c"),
                        updated_at = now
                    )
                )
            }
            if (list.isNotEmpty()) database.farmSettingsDao().insertAll(list)
        }

        // 17. Fodder Species
        dataObj.optJSONArray("fodder_species")?.let { arr ->
            val list = mutableListOf<FodderSpeciesEntity>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                list.add(
                    FodderSpeciesEntity(
                        id = o.getString("id"),
                        name = o.getString("name"),
                        scientific_name = o.optNullable("scientific_name"),
                        category = o.optString("category", "Perennial Grass"),
                        crude_protein_pct = o.optDouble("crude_protein_pct", 15.0),
                        dry_matter_pct = o.optDouble("dry_matter_pct", 22.0),
                        days_to_first_cut = o.optInt("days_to_first_cut", 60),
                        regrowth_interval_days = o.optInt("regrowth_interval_days", 40),
                        cutting_height_cm = o.optDouble("cutting_height_cm", 15.0),
                        expected_yield_per_acre_cut_kg = o.optDouble("expected_yield_per_acre_cut_kg", 15000.0),
                        water_requirement = o.optString("water_requirement", "Medium"),
                        notes = o.optNullable("notes"),
                        updated_at = now,
                        is_synced = true
                    )
                )
            }
            if (list.isNotEmpty()) database.fodderDao().insertAllSpecies(list)
        }

        // 18. Fodder Plots
        dataObj.optJSONArray("fodder_plots")?.let { arr ->
            val list = mutableListOf<FodderPlotEntity>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                list.add(
                    FodderPlotEntity(
                        id = o.getString("id"),
                        plot_name = o.getString("plot_name"),
                        area_value = o.optDouble("area_value", 1.0),
                        area_unit = o.optString("area_unit", "Acres"),
                        variety = o.optNullable("variety"),
                        row_count = o.optInt("row_count", 40),
                        row_length = o.optDouble("row_length", 25.0),
                        row_length_unit = o.optString("row_length_unit", "metre"),
                        row_spacing = o.optDouble("row_spacing", 1.0),
                        row_spacing_unit = o.optString("row_spacing_unit", "metre"),
                        calculated_cultivated_area = o.optDouble("calculated_cultivated_area", 1000.0),
                        calculated_area_unit = o.optString("calculated_area_unit", "sq.m"),
                        latitude = if (o.has("latitude") && !o.isNull("latitude")) o.optDouble("latitude") else null,
                        longitude = if (o.has("longitude") && !o.isNull("longitude")) o.optDouble("longitude") else null,
                        gps_accuracy = if (o.has("gps_accuracy") && !o.isNull("gps_accuracy")) o.getDouble("gps_accuracy").toFloat() else null,
                        location_tag = o.optNullable("location_tag"),
                        species_id = o.getString("species_id"),
                        species_name = o.getString("species_name"),
                        sowing_date = o.getString("sowing_date"),
                        crop_cycle_status = o.optString("crop_cycle_status", "Sown / Growing"),
                        current_cut_count = o.optInt("current_cut_count", 0),
                        last_cut_date = o.optNullable("last_cut_date"),
                        next_expected_cut_date = o.optNullable("next_expected_cut_date"),
                        irrigation_type = o.optString("irrigation_type", "Drip"),
                        soil_type = o.optString("soil_type", "Red Loam"),
                        notes = o.optNullable("notes"),
                        updated_at = now,
                        is_synced = true
                    )
                )
            }
            if (list.isNotEmpty()) database.fodderDao().insertAllPlots(list)
        }

        // 19. Fodder Rows
        dataObj.optJSONArray("fodder_rows")?.let { arr ->
            val list = mutableListOf<FodderRowEntity>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                list.add(
                    FodderRowEntity(
                        id = o.getString("id"),
                        plot_id = o.getString("plot_id"),
                        row_index = o.optInt("row_index", 1),
                        row_code = o.optString("row_code", "R01"),
                        crop_cycle_id = o.optNullable("crop_cycle_id"),
                        species_name = o.getString("species_name"),
                        variety = o.optNullable("variety"),
                        status = o.optString("status", "Growing"),
                        length_m = o.optDouble("length_m", 25.0),
                        spacing_m = o.optDouble("spacing_m", 1.0),
                        planting_date = o.optNullable("planting_date"),
                        planting_method = o.optNullable("planting_method"),
                        last_cut_date = o.optNullable("last_cut_date"),
                        next_expected_cut_date = o.optNullable("next_expected_cut_date"),
                        total_cuts = o.optInt("total_cuts", 0),
                        total_yield_kg = o.optDouble("total_yield_kg", 0.0),
                        notes = o.optNullable("notes"),
                        updated_at = now,
                        is_synced = true
                    )
                )
            }
            if (list.isNotEmpty()) database.fodderDao().insertAllRows(list)
        }

        // 20. Fodder Crop Cycles
        dataObj.optJSONArray("fodder_crop_cycles")?.let { arr ->
            val list = mutableListOf<FodderCropCycleEntity>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                list.add(
                    FodderCropCycleEntity(
                        id = o.getString("id"),
                        plot_id = o.getString("plot_id"),
                        cycle_number = o.optInt("cycle_number", 1),
                        cycle_name = o.optString("cycle_name", "Crop Cycle 1"),
                        species_name = o.getString("species_name"),
                        variety = o.optNullable("variety"),
                        planting_date = o.getString("planting_date"),
                        planting_method = o.optString("planting_method", "Slips"),
                        row_codes = o.optString("row_codes", "All Rows"),
                        rows_count = o.optInt("rows_count", 40),
                        status = o.optString("status", "Active"),
                        start_date = o.getString("start_date"),
                        end_date = o.optNullable("end_date"),
                        total_production_kg = o.optDouble("total_production_kg", 0.0),
                        total_cuts_count = o.optInt("total_cuts_count", 0),
                        notes = o.optNullable("notes"),
                        updated_at = now,
                        is_synced = true
                    )
                )
            }
            if (list.isNotEmpty()) database.fodderDao().insertAllCropCycles(list)
        }

        // 21. Fodder Materials
        dataObj.optJSONArray("fodder_materials")?.let { arr ->
            val list = mutableListOf<FodderPlantingMaterialEntity>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                list.add(
                    FodderPlantingMaterialEntity(
                        id = o.getString("id"),
                        material_type = o.optString("material_type", "Slips"),
                        species_name = o.getString("species_name"),
                        variety = o.optNullable("variety"),
                        quantity_purchased = o.optDouble("quantity_purchased", 0.0),
                        quantity_used = o.optDouble("quantity_used", 0.0),
                        quantity_remaining = o.optDouble("quantity_remaining", 0.0),
                        unit = o.optString("unit", "slips"),
                        unit_cost = o.optDouble("unit_cost", 0.0),
                        total_cost = o.optDouble("total_cost", 0.0),
                        supplier = o.optNullable("supplier"),
                        purchase_date = o.getString("purchase_date"),
                        batch_lot_number = o.optNullable("batch_lot_number"),
                        notes = o.optNullable("notes"),
                        updated_at = now,
                        is_synced = true
                    )
                )
            }
            if (list.isNotEmpty()) database.fodderDao().insertAllMaterials(list)
        }

        // 22. Fodder Activities
        dataObj.optJSONArray("fodder_activities")?.let { arr ->
            val list = mutableListOf<FodderActivityEntity>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                list.add(
                    FodderActivityEntity(
                        id = o.getString("id"),
                        plot_id = o.getString("plot_id"),
                        plot_name = o.getString("plot_name"),
                        crop_cycle_id = o.optNullable("crop_cycle_id"),
                        row_codes = o.optString("row_codes", "All Rows"),
                        species_name = o.getString("species_name"),
                        variety = o.optNullable("variety"),
                        activity_type = o.getString("activity_type"),
                        activity_date = o.getString("activity_date"),
                        quantity = if (o.has("quantity") && !o.isNull("quantity")) o.optDouble("quantity") else null,
                        unit = o.optNullable("unit"),
                        labour_hours = if (o.has("labour_hours") && !o.isNull("labour_hours")) o.optDouble("labour_hours") else null,
                        labour_cost = if (o.has("labour_cost") && !o.isNull("labour_cost")) o.optDouble("labour_cost") else null,
                        material_cost = if (o.has("material_cost") && !o.isNull("material_cost")) o.optDouble("material_cost") else null,
                        total_cost = o.optDouble("total_cost", 0.0),
                        weather_temp_c = if (o.has("weather_temp_c") && !o.isNull("weather_temp_c")) o.optDouble("weather_temp_c") else null,
                        weather_condition = o.optNullable("weather_condition"),
                        weather_rainfall_mm = if (o.has("weather_rainfall_mm") && !o.isNull("weather_rainfall_mm")) o.optDouble("weather_rainfall_mm") else null,
                        weather_humidity_pct = if (o.has("weather_humidity_pct") && !o.isNull("weather_humidity_pct")) o.optInt("weather_humidity_pct") else null,
                        weather_wind_kmh = if (o.has("weather_wind_kmh") && !o.isNull("weather_wind_kmh")) o.optDouble("weather_wind_kmh") else null,
                        operator_user = o.optNullable("operator_user"),
                        notes = o.optNullable("notes"),
                        updated_at = now,
                        is_synced = true
                    )
                )
            }
            if (list.isNotEmpty()) database.fodderDao().insertAllActivities(list)
        }

        // 23. Fodder Cuttings
        dataObj.optJSONArray("fodder_cuttings")?.let { arr ->
            val list = mutableListOf<FodderCuttingEntity>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                list.add(
                    FodderCuttingEntity(
                        id = o.getString("id"),
                        plot_id = o.getString("plot_id"),
                        plot_name = o.getString("plot_name"),
                        species_id = o.getString("species_id"),
                        species_name = o.getString("species_name"),
                        cutting_date = o.getString("cutting_date"),
                        cut_number = o.optInt("cut_number", 1),
                        harvested_weight_kg = o.getDouble("harvested_weight_kg"),
                        area_harvested_pct = o.optDouble("area_harvested_pct", 100.0),
                        labor_cost = if (o.has("labor_cost") && !o.isNull("labor_cost")) o.optDouble("labor_cost") else null,
                        harvester_name = o.optNullable("harvester_name"),
                        quality_rating = o.optString("quality_rating", "Tender & Leafy"),
                        notes = o.optNullable("notes"),
                        row_codes = o.optString("row_codes", "All Rows"),
                        rows_harvested_count = o.optInt("rows_harvested_count", 1),
                        row_length_m = o.optDouble("row_length_m", 25.0),
                        total_harvested_row_length_m = o.optDouble("total_harvested_row_length_m", 25.0),
                        yield_per_metre = o.optDouble("yield_per_metre", 0.0),
                        yield_per_row = o.optDouble("yield_per_row", 0.0),
                        yield_per_acre = o.optDouble("yield_per_acre", 0.0),
                        weather_summary = o.optNullable("weather_summary"),
                        weather_temp_c = if (o.has("weather_temp_c") && !o.isNull("weather_temp_c")) o.optDouble("weather_temp_c") else null,
                        weather_rainfall_mm = if (o.has("weather_rainfall_mm") && !o.isNull("weather_rainfall_mm")) o.optDouble("weather_rainfall_mm") else null,
                        updated_at = now,
                        is_synced = true
                    )
                )
            }
            if (list.isNotEmpty()) database.fodderDao().insertAllCuttings(list)
        }

        // 20. Fodder Feedings
        dataObj.optJSONArray("fodder_feedings")?.let { arr ->
            val list = mutableListOf<FodderFeedingEntity>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                list.add(
                    FodderFeedingEntity(
                        id = o.getString("id"),
                        feeding_date = o.getString("feeding_date"),
                        species_id = o.optNullable("species_id"),
                        species_name = o.getString("species_name"),
                        target_group = o.optString("target_group", "All Does"),
                        goats_count = o.optInt("goats_count", 1),
                        quantity_fed_kg = o.getDouble("quantity_fed_kg"),
                        feeding_time = o.optString("feeding_time", "Morning"),
                        chaffed_method = o.optString("chaffed_method", "Chaff Cut Machine"),
                        wastage_kg = o.optDouble("wastage_kg", 0.0),
                        notes = o.optNullable("notes"),
                        updated_at = now,
                        is_synced = true
                    )
                )
            }
            if (list.isNotEmpty()) database.fodderDao().insertAllFeedings(list)
        }

        // 21. Fodder Stock Adjustments
        dataObj.optJSONArray("fodder_stock_adjustments")?.let { arr ->
            val list = mutableListOf<FodderStockAdjustmentEntity>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                list.add(
                    FodderStockAdjustmentEntity(
                        id = o.getString("id"),
                        date_c = o.getString("date_c"),
                        species_name = o.optNullable("species_name"),
                        adjustment_type = o.optString("adjustment_type", "WASTAGE"),
                        quantity_kg = o.getDouble("quantity_kg"),
                        notes = o.optNullable("notes"),
                        updated_at = now,
                        is_synced = true
                    )
                )
            }
            if (list.isNotEmpty()) database.fodderDao().insertAllStockAdjustments(list)
        }

        // 24. Weaning Records
        dataObj.optJSONArray("weaning_records")?.let { arr ->
            val list = mutableListOf<com.example.data.offline.WeaningRecordEntity>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                list.add(
                    com.example.data.offline.WeaningRecordEntity(
                        id = o.optString("id", UUID.randomUUID().toString()),
                        farm_id = o.optString("farm_id", "default_farm"),
                        goat_id = o.getString("goat_id"),
                        mother_goat_id = o.optNullable("mother_goat_id"),
                        kidding_id = o.optNullable("kidding_id"),
                        birth_date = o.optString("birth_date", ""),
                        weaning_due_date = o.optString("weaning_due_date", ""),
                        actual_weaning_date = o.optNullable("actual_weaning_date"),
                        age_at_weaning_days = if (o.has("age_at_weaning_days") && !o.isNull("age_at_weaning_days")) o.optInt("age_at_weaning_days") else null,
                        weight_at_weaning = if (o.has("weight_at_weaning") && !o.isNull("weight_at_weaning")) o.optDouble("weight_at_weaning") else null,
                        weight_unit = o.optString("weight_unit", "kg"),
                        weaning_method = o.optNullable("weaning_method"),
                        status = o.optString("status", "PLANNED"),
                        reason_if_delayed = o.optNullable("reason_if_delayed"),
                        notes = o.optNullable("notes"),
                        setting_source = o.optString("setting_source", "FARM_DEFAULT"),
                        post_weaning_feed_group = o.optString("post_weaning_feed_group", "WEANED KID / GROWING KID"),
                        birth_weight = if (o.has("birth_weight") && !o.isNull("birth_weight")) o.optDouble("birth_weight") else null,
                        prev_weight = if (o.has("prev_weight") && !o.isNull("prev_weight")) o.optDouble("prev_weight") else null,
                        adg_g_per_day = if (o.has("adg_g_per_day") && !o.isNull("adg_g_per_day")) o.optDouble("adg_g_per_day") else null,
                        batch_id = o.optNullable("batch_id"),
                        created_at = o.optString("created_at", ""),
                        updated_at = now,
                        is_synced = true
                    )
                )
            }
            if (list.isNotEmpty()) database.weaningDao().insertAllWeaningRecords(list)
        }

        // 25. Weaning Batches
        dataObj.optJSONArray("weaning_batches")?.let { arr ->
            val list = mutableListOf<com.example.data.offline.WeaningBatchEntity>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                list.add(
                    com.example.data.offline.WeaningBatchEntity(
                        id = o.optString("id", UUID.randomUUID().toString()),
                        farm_id = o.optString("farm_id", "default_farm"),
                        weaning_date = o.optString("weaning_date", ""),
                        number_of_kids = o.optInt("number_of_kids", 1),
                        average_weight = if (o.has("average_weight") && !o.isNull("average_weight")) o.optDouble("average_weight") else null,
                        notes = o.optNullable("notes"),
                        created_at = o.optString("created_at", ""),
                        updated_at = now,
                        is_synced = true
                    )
                )
            }
            if (list.isNotEmpty()) database.weaningDao().insertAllWeaningBatches(list)
        }
    }

    private fun JSONObject.optNullable(key: String): String? {
        if (!has(key) || isNull(key)) return null
        val str = optString(key)
        return if (str.isBlank() || str.equals("null", ignoreCase = true)) null else str
    }
}
