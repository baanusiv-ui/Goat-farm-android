package com.example.data.farm

import android.content.Context
import android.net.Uri
import android.util.Log
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.offline.AppDatabase
import com.example.data.offline.FarmSettingEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

data class FarmProfile(
    val farmName: String = "My Goat Farm",
    val logoUri: String? = null
)

val LocalFarmProfile = compositionLocalOf { FarmProfile() }
val LocalFarmProfileManager = compositionLocalOf<FarmProfileManager?> { null }

class FarmProfileManager(
    private val context: Context,
    private val database: AppDatabase
) {
    companion object {
        private const val TAG = "FarmProfileManager"
        private const val KEY_FARM_NAME = "farm_name"
        private const val KEY_FARM_LOGO_URI = "farm_logo_uri"
        const val DEFAULT_FARM_NAME = "My Goat Farm"

        @Volatile
        private var INSTANCE: FarmProfileManager? = null

        fun getInstance(context: Context, database: AppDatabase): FarmProfileManager {
            return INSTANCE ?: synchronized(this) {
                val inst = FarmProfileManager(context.applicationContext, database)
                INSTANCE = inst
                inst
            }
        }
    }

    private val scope = CoroutineScope(Dispatchers.IO)
    private val _farmProfile = MutableStateFlow(FarmProfile())
    val farmProfile: StateFlow<FarmProfile> = _farmProfile.asStateFlow()

    init {
        loadProfile()
    }

    fun loadProfile() {
        scope.launch {
            try {
                val name = database.farmSettingsDao().getSetting(KEY_FARM_NAME)?.value_c
                    ?: database.farmSettingsDao().getSetting("current_farm_name")?.value_c
                    ?: DEFAULT_FARM_NAME

                val logo = database.farmSettingsDao().getSetting(KEY_FARM_LOGO_URI)?.value_c

                _farmProfile.value = FarmProfile(
                    farmName = if (name.isNotBlank()) name else DEFAULT_FARM_NAME,
                    logoUri = logo?.takeIf { it.isNotBlank() }
                )
            } catch (e: Exception) {
                Log.e(TAG, "Error loading farm profile: ${e.message}", e)
            }
        }
    }

    suspend fun saveFarmProfile(
        name: String,
        selectedImageUri: Uri? = null,
        removeLogo: Boolean = false
    ): Result<FarmProfile> = withContext(Dispatchers.IO) {
        try {
            val cleanName = name.trim().ifBlank { DEFAULT_FARM_NAME }
            var finalLogoUri: String? = _farmProfile.value.logoUri

            if (removeLogo) {
                finalLogoUri = null
                try {
                    val localLogoFile = File(context.filesDir, "farm_logo.png")
                    if (localLogoFile.exists()) localLogoFile.delete()
                } catch (_: Exception) {}
            } else if (selectedImageUri != null) {
                // Copy selected image from device to app's private filesDir for permanent, reliable access
                val logoFile = File(context.filesDir, "farm_logo.png")
                context.contentResolver.openInputStream(selectedImageUri)?.use { input ->
                    FileOutputStream(logoFile).use { output ->
                        input.copyTo(output)
                    }
                }
                finalLogoUri = logoFile.toURI().toString()
            }

            // Save to Room Database
            database.farmSettingsDao().saveSetting(
                FarmSettingEntity(key = KEY_FARM_NAME, value_c = cleanName)
            )
            // Also keep current_farm_name in sync for any legacy components
            database.farmSettingsDao().saveSetting(
                FarmSettingEntity(key = "current_farm_name", value_c = cleanName)
            )

            if (finalLogoUri != null) {
                database.farmSettingsDao().saveSetting(
                    FarmSettingEntity(key = KEY_FARM_LOGO_URI, value_c = finalLogoUri)
                )
            } else {
                database.farmSettingsDao().saveSetting(
                    FarmSettingEntity(key = KEY_FARM_LOGO_URI, value_c = "")
                )
            }

            val updatedProfile = FarmProfile(farmName = cleanName, logoUri = finalLogoUri)
            _farmProfile.value = updatedProfile
            Log.d(TAG, "Farm profile updated successfully: name='$cleanName', logo='$finalLogoUri'")
            Result.success(updatedProfile)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to save farm profile: ${e.message}", e)
            Result.failure(e)
        }
    }

    suspend fun clearLogo(): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val localLogoFile = File(context.filesDir, "farm_logo.png")
            if (localLogoFile.exists()) localLogoFile.delete()
            database.farmSettingsDao().saveSetting(
                FarmSettingEntity(key = KEY_FARM_LOGO_URI, value_c = "")
            )
            _farmProfile.value = _farmProfile.value.copy(logoUri = null)
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun resetToDefault(): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val localLogoFile = File(context.filesDir, "farm_logo.png")
            if (localLogoFile.exists()) localLogoFile.delete()
            database.farmSettingsDao().saveSetting(
                FarmSettingEntity(key = KEY_FARM_NAME, value_c = DEFAULT_FARM_NAME)
            )
            database.farmSettingsDao().saveSetting(
                FarmSettingEntity(key = "current_farm_name", value_c = DEFAULT_FARM_NAME)
            )
            database.farmSettingsDao().saveSetting(
                FarmSettingEntity(key = KEY_FARM_LOGO_URI, value_c = "")
            )
            _farmProfile.value = FarmProfile(farmName = DEFAULT_FARM_NAME, logoUri = null)
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}

@Composable
fun FarmLogoImage(
    logoUri: String?,
    modifier: Modifier = Modifier,
    fallbackIconSize: Dp = 22.dp,
    fallbackTintColor: Color = Color.White,
    contentDescription: String? = "Farm Logo"
) {
    if (!logoUri.isNullOrBlank()) {
        AsyncImage(
            model = logoUri,
            contentDescription = contentDescription,
            contentScale = ContentScale.Crop,
            modifier = modifier.clip(CircleShape)
        )
    } else {
        androidx.compose.foundation.Image(
            painter = androidx.compose.ui.res.painterResource(id = com.example.R.drawable.cartoon_goat_logo),
            contentDescription = contentDescription,
            contentScale = ContentScale.Crop,
            modifier = modifier.clip(CircleShape)
        )
    }
}

@Composable
fun FarmSetupCard(
    farmProfile: FarmProfile,
    onSaveProfile: (name: String, imageUri: Uri?) -> Unit,
    onClearLogo: () -> Unit,
    onResetDefault: () -> Unit,
    modifier: Modifier = Modifier
) {
    var farmNameInput by remember(farmProfile.farmName) { mutableStateOf(farmProfile.farmName) }
    var selectedImageUri by remember { mutableStateOf<Uri?>(null) }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            selectedImageUri = uri
        }
    }

    val displayLogo = selectedImageUri?.toString() ?: farmProfile.logoUri
    val hasLogo = !displayLogo.isNullOrBlank()

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Header
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(Color(0xFFE8F5E9)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Business,
                        contentDescription = null,
                        tint = Color(0xFF1B5E20),
                        modifier = Modifier.size(22.dp)
                    )
                }
                Column {
                    Text(
                        text = "Farm Setup & Profile Branding",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF1B5E20)
                    )
                    Text(
                        text = "Customize your dynamic farm name and custom logo emblem",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.Gray
                    )
                }
            }

            HorizontalDivider(color = Color(0xFFF1F5F9))

            // Logo Preview & Actions
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Logo Circle with Border
                Box(
                    modifier = Modifier
                        .size(72.dp)
                        .clip(CircleShape)
                        .background(Color(0xFFF1F5F9))
                        .border(2.dp, Color(0xFF86EFAC), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    FarmLogoImage(
                        logoUri = displayLogo,
                        modifier = Modifier.fillMaxSize(),
                        fallbackIconSize = 36.dp,
                        fallbackTintColor = Color(0xFF1B5E20)
                    )
                }

                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = {
                                photoPickerLauncher.launch(
                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                )
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1B5E20)),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Icon(Icons.Default.CameraAlt, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(if (hasLogo) "Change Logo" else "Upload Logo", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }

                        if (hasLogo) {
                            OutlinedButton(
                                onClick = {
                                    selectedImageUri = null
                                    onClearLogo()
                                },
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp)
                            ) {
                                Icon(Icons.Default.Delete, contentDescription = null, tint = Color(0xFFD32F2F), modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(2.dp))
                                Text("Remove", fontSize = 12.sp, color = Color(0xFFD32F2F))
                            }
                        }
                    }
                    Text(
                        text = if (selectedImageUri != null) "New image chosen (tap Save to apply)" else "JPG, PNG, WebP supported via Photo Picker",
                        fontSize = 11.sp,
                        color = if (selectedImageUri != null) Color(0xFF1B5E20) else Color.Gray
                    )
                }
            }

            // Farm Name Input
            OutlinedTextField(
                value = farmNameInput,
                onValueChange = { farmNameInput = it },
                label = { Text("Farm Name *") },
                placeholder = { Text("e.g. Sunrise Goat Farm") },
                leadingIcon = { Icon(Icons.Default.Business, contentDescription = null, tint = Color(0xFF1B5E20)) },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            // Save & Reset Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                TextButton(onClick = {
                    farmNameInput = FarmProfileManager.DEFAULT_FARM_NAME
                    selectedImageUri = null
                    onResetDefault()
                }) {
                    Text("Reset to Default", fontSize = 12.sp, color = Color.Gray)
                }

                Button(
                    onClick = {
                        onSaveProfile(farmNameInput.ifBlank { FarmProfileManager.DEFAULT_FARM_NAME }, selectedImageUri)
                        selectedImageUri = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1B5E20)),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Save Farm Setup", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun FarmSetupDialog(
    farmProfile: FarmProfile,
    farmProfileManager: FarmProfileManager,
    onDismiss: () -> Unit
) {
    val coroutineScope = rememberCoroutineScope()

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(Icons.Default.Business, contentDescription = null, tint = Color(0xFF1B5E20))
                Text("Farm Setup & Branding", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            }
        },
        text = {
            FarmSetupCard(
                farmProfile = farmProfile,
                onSaveProfile = { name, uri ->
                    coroutineScope.launch {
                        farmProfileManager.saveFarmProfile(name, uri)
                        onDismiss()
                    }
                },
                onClearLogo = {
                    coroutineScope.launch {
                        farmProfileManager.clearLogo()
                    }
                },
                onResetDefault = {
                    coroutineScope.launch {
                        farmProfileManager.resetToDefault()
                    }
                }
            )
        },
        confirmButton = {},
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Close")
            }
        }
    )
}


