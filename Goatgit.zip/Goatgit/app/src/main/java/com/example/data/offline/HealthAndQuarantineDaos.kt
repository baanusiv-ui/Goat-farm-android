package com.example.data.offline

import androidx.room.*

@Dao
interface HealthScheduleDao {
    // Vaccination Schedules
    @Query("SELECT * FROM local_vaccination_schedules ORDER BY active DESC, name ASC")
    suspend fun getAllVaccinationSchedules(): List<VaccinationScheduleEntity>

    @Query("SELECT * FROM local_vaccination_schedules WHERE active = 1 ORDER BY name ASC")
    suspend fun getActiveVaccinationSchedules(): List<VaccinationScheduleEntity>

    @Query("SELECT * FROM local_vaccination_schedules WHERE disease = :disease AND active = 1 LIMIT 1")
    suspend fun getVaccinationScheduleByDisease(disease: String): VaccinationScheduleEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertVaccinationSchedule(schedule: VaccinationScheduleEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllVaccinationSchedules(list: List<VaccinationScheduleEntity>)

    @Update
    suspend fun updateVaccinationSchedule(schedule: VaccinationScheduleEntity)

    // Deworming Schedules
    @Query("SELECT * FROM local_deworming_schedules ORDER BY active DESC, name ASC")
    suspend fun getAllDewormingSchedules(): List<DewormingScheduleEntity>

    @Query("SELECT * FROM local_deworming_schedules WHERE active = 1 ORDER BY name ASC")
    suspend fun getActiveDewormingSchedules(): List<DewormingScheduleEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDewormingSchedule(schedule: DewormingScheduleEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllDewormingSchedules(list: List<DewormingScheduleEntity>)

    @Update
    suspend fun updateDewormingSchedule(schedule: DewormingScheduleEntity)
}

@Dao
interface QuarantineDao {
    @Query("SELECT * FROM local_quarantine_records ORDER BY start_date DESC")
    suspend fun getAllQuarantineRecords(): List<QuarantineRecordEntity>

    @Query("SELECT * FROM local_quarantine_records WHERE goat_id = :goatId ORDER BY start_date DESC")
    suspend fun getQuarantineRecordsForGoat(goatId: String): List<QuarantineRecordEntity>

    @Query("SELECT * FROM local_quarantine_records WHERE goat_id = :goatId AND status IN ('QUARANTINE', 'EXTENDED') LIMIT 1")
    suspend fun getActiveQuarantineForGoat(goatId: String): QuarantineRecordEntity?

    @Query("SELECT * FROM local_quarantine_records WHERE status IN ('QUARANTINE', 'EXTENDED') ORDER BY planned_end_date ASC")
    suspend fun getActiveQuarantinedGoats(): List<QuarantineRecordEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertQuarantineRecord(record: QuarantineRecordEntity)

    @Update
    suspend fun updateQuarantineRecord(record: QuarantineRecordEntity)

    @Query("UPDATE local_quarantine_records SET status = :status, actual_release_date = :releaseDate, release_reason = :releaseReason, updated_at = :updatedAt WHERE id = :id")
    suspend fun releaseQuarantine(id: String, status: String, releaseDate: String, releaseReason: String?, updatedAt: Long = System.currentTimeMillis())

    @Query("UPDATE local_quarantine_records SET planned_end_date = :newEndDate, status = 'EXTENDED', extensions_json = :extensionsJson, notes = :notes, updated_at = :updatedAt WHERE id = :id")
    suspend fun extendQuarantine(id: String, newEndDate: String, extensionsJson: String?, notes: String?, updatedAt: Long = System.currentTimeMillis())
}
