package com.example.ui.screens.sales

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.payment.PaytmInitiateResult
import com.example.data.payment.PaytmService
import com.example.data.payment.PaytmVerifyResult
import com.example.ui.components.PaytmCyan
import com.example.ui.components.PaytmNavy
import com.example.ui.theme.FarmError
import com.example.ui.theme.FarmSuccess
import com.example.ui.theme.FarmWarning
import com.example.util.CurrencyUtils
import kotlinx.coroutines.launch

@Composable
fun PaytmGatewayCheckoutDialog(
    orderId: String,
    amount: Double,
    goatTag: String,
    goatName: String,
    buyerName: String,
    buyerPhone: String,
    paytmService: PaytmService,
    isOnline: Boolean,
    onDismiss: () -> Unit,
    onPaymentSuccess: (PaytmVerifyResult) -> Unit,
    onPaymentFailed: (PaytmVerifyResult) -> Unit
) {
    val coroutineScope = rememberCoroutineScope()
    var checkoutStep by remember { mutableStateOf("INITIATING") } // INITIATING, READY, PROCESSING, VERIFYING, ERROR
    var initiateResult by remember { mutableStateOf<PaytmInitiateResult?>(null) }
    var verifyResult by remember { mutableStateOf<PaytmVerifyResult?>(null) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    // Check offline constraint immediately
    LaunchedEffect(isOnline) {
        if (!isOnline) {
            checkoutStep = "OFFLINE_ERROR"
            return@LaunchedEffect
        }

        // Start Order Initiation with Backend
        checkoutStep = "INITIATING"
        val initRes = paytmService.initiateOrder(
            orderId = orderId,
            amount = amount,
            customerId = buyerPhone.ifBlank { "CUST_${System.currentTimeMillis()}" },
            customerPhone = buyerPhone
        )
        initiateResult = initRes
        if (initRes.isSuccess) {
            checkoutStep = "READY"
        } else {
            checkoutStep = "ERROR"
            errorMessage = initRes.errorMessage ?: "Failed to initialize Paytm Gateway transaction"
        }
    }

    Dialog(
        onDismissRequest = {
            if (checkoutStep != "PROCESSING" && checkoutStep != "VERIFYING") {
                onDismiss()
            }
        },
        properties = DialogProperties(dismissOnBackPress = checkoutStep != "PROCESSING", dismissOnClickOutside = false)
    ) {
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp)
                .testTag("paytm_checkout_dialog")
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                // Header with Paytm branding
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(PaytmNavy)
                        .padding(16.dp)
                ) {
                    Column {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Surface(
                                    shape = RoundedCornerShape(4.dp),
                                    color = Color.White,
                                    modifier = Modifier.size(width = 46.dp, height = 22.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Text(
                                            text = "Paytm",
                                            color = PaytmNavy,
                                            fontWeight = FontWeight.Black,
                                            fontSize = 11.sp
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Payment Gateway",
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp
                                )
                            }

                            if (checkoutStep != "PROCESSING" && checkoutStep != "VERIFYING") {
                                IconButton(
                                    onClick = onDismiss,
                                    modifier = Modifier.size(24.dp)
                                ) {
                                    Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.White)
                                }
                            }
                        }

                        // Prominent Test Mode Banner
                        Spacer(modifier = Modifier.height(6.dp))
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = FarmWarning,
                            modifier = Modifier.testTag("paytm_test_mode_banner")
                        ) {
                            Text(
                                text = "PAYTM TEST MODE",
                                color = Color.Black,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.ExtraBold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                            )
                        }
                    }
                }

                // Body content based on step
                Column(modifier = Modifier.padding(20.dp)) {
                    // Order and Amount Info Card
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = Color(0xFFF8FAFC),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Order ID:", fontSize = 12.sp, color = Color.Gray)
                                Text(orderId, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Goat:", fontSize = 12.sp, color = Color.Gray)
                                Text("$goatName ($goatTag)", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Amount:", fontSize = 13.sp, color = Color.Gray)
                                Text(
                                    CurrencyUtils.formatInr(amount),
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = PaytmNavy
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    when (checkoutStep) {
                        "OFFLINE_ERROR" -> {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Icon(
                                    Icons.Default.CloudOff,
                                    contentDescription = null,
                                    tint = FarmError,
                                    modifier = Modifier.size(48.dp)
                                )
                                Spacer(modifier = Modifier.height(12.dp))
                                Text(
                                    text = "Paytm Gateway requires an internet connection.\nUse Cash or UPI / QR for offline payment.",
                                    textAlign = TextAlign.Center,
                                    color = FarmError,
                                    fontWeight = FontWeight.Medium,
                                    fontSize = 14.sp
                                )
                                Spacer(modifier = Modifier.height(16.dp))
                                Button(
                                    onClick = onDismiss,
                                    colors = ButtonDefaults.buttonColors(containerColor = PaytmNavy),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text("Go Back to Payment Options")
                                }
                            }
                        }

                        "INITIATING" -> {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier.fillMaxWidth().padding(vertical = 20.dp)
                            ) {
                                CircularProgressIndicator(color = PaytmCyan)
                                Spacer(modifier = Modifier.height(14.dp))
                                Text(
                                    "Creating secure Paytm order...",
                                    fontWeight = FontWeight.Medium,
                                    fontSize = 13.sp,
                                    color = Color.Gray
                                )
                            }
                        }

                        "PROCESSING", "VERIFYING" -> {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier.fillMaxWidth().padding(vertical = 20.dp)
                            ) {
                                CircularProgressIndicator(color = PaytmNavy)
                                Spacer(modifier = Modifier.height(14.dp))
                                Text(
                                    if (checkoutStep == "PROCESSING") "Connecting to Paytm Checkout..." else "Verifying payment with Paytm server...",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    color = PaytmNavy
                                )
                                Text(
                                    "Please do not close this window",
                                    fontSize = 11.sp,
                                    color = Color.Gray
                                )
                            }
                        }

                        "READY" -> {
                            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                Text(
                                    "Paytm Checkout Interface (All-in-One):",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    color = Color(0xFF1E293B)
                                )

                                Surface(
                                    shape = RoundedCornerShape(10.dp),
                                    color = Color(0xFFF1F5F9),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(modifier = Modifier.padding(10.dp)) {
                                        Text("• Paytm UPI / Netbanking / Cards", fontSize = 12.sp, color = Color.DarkGray)
                                        Text("• Secure Tokenized Payment Flow", fontSize = 12.sp, color = Color.DarkGray)
                                        Text("• Server-side Verification Enforcement", fontSize = 12.sp, color = Color.DarkGray)
                                    }
                                }

                                Text(
                                    "Test Gateway Simulator Controls:",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp,
                                    color = FarmWarning
                                )

                                // Action 1: Complete Successful Payment
                                Button(
                                    onClick = {
                                        coroutineScope.launch {
                                            checkoutStep = "VERIFYING"
                                            val verifyRes = paytmService.verifyTransaction(orderId, simulatedTestResult = "SUCCESS")
                                            verifyResult = verifyRes
                                            if (verifyRes.isSuccess) {
                                                onPaymentSuccess(verifyRes)
                                            } else {
                                                checkoutStep = "ERROR"
                                                errorMessage = verifyRes.failureReason
                                                onPaymentFailed(verifyRes)
                                            }
                                        }
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = FarmSuccess),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.fillMaxWidth().height(46.dp).testTag("paytm_simulate_success_btn")
                                ) {
                                    Icon(Icons.Default.Check, contentDescription = null)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Simulate Successful Payment", fontWeight = FontWeight.Bold)
                                }

                                // Action 2: Simulate Bank Failure
                                OutlinedButton(
                                    onClick = {
                                        coroutineScope.launch {
                                            checkoutStep = "VERIFYING"
                                            val verifyRes = paytmService.verifyTransaction(orderId, simulatedTestResult = "FAILED")
                                            verifyResult = verifyRes
                                            checkoutStep = "FAILED"
                                            onPaymentFailed(verifyRes)
                                        }
                                    },
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.fillMaxWidth().height(46.dp).testTag("paytm_simulate_failure_btn")
                                ) {
                                    Icon(Icons.Default.ErrorOutline, contentDescription = null, tint = FarmError)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Simulate Bank Failure", color = FarmError, fontWeight = FontWeight.Bold)
                                }

                                // Action 3: Customer Cancelled
                                OutlinedButton(
                                    onClick = {
                                        coroutineScope.launch {
                                            val verifyRes = paytmService.verifyTransaction(orderId, simulatedTestResult = "CANCELLED")
                                            onPaymentFailed(verifyRes)
                                            onDismiss()
                                        }
                                    },
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.fillMaxWidth().height(42.dp).testTag("paytm_cancel_btn")
                                ) {
                                    Text("Cancel Transaction", color = Color.Gray)
                                }
                            }
                        }

                        "FAILED" -> {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Icon(Icons.Default.Cancel, contentDescription = null, tint = FarmError, modifier = Modifier.size(48.dp))
                                Spacer(modifier = Modifier.height(10.dp))
                                Text("Payment Failed", fontWeight = FontWeight.Bold, color = FarmError, fontSize = 16.sp)
                                Text(
                                    verifyResult?.failureReason ?: "Payment was declined by Paytm.",
                                    fontSize = 12.sp,
                                    color = Color.Gray,
                                    textAlign = TextAlign.Center
                                )
                                Spacer(modifier = Modifier.height(14.dp))
                                Text(
                                    "Note: Goat status remains unsold.",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = Color.DarkGray
                                )
                                Spacer(modifier = Modifier.height(16.dp))
                                Button(
                                    onClick = onDismiss,
                                    colors = ButtonDefaults.buttonColors(containerColor = Color.DarkGray),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text("Close")
                                }
                            }
                        }

                        "ERROR" -> {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Icon(Icons.Default.Warning, contentDescription = null, tint = FarmError, modifier = Modifier.size(44.dp))
                                Spacer(modifier = Modifier.height(10.dp))
                                Text("Gateway Error", fontWeight = FontWeight.Bold, color = FarmError, fontSize = 16.sp)
                                Text(
                                    errorMessage ?: "An unexpected error occurred with Paytm Gateway.",
                                    fontSize = 12.sp,
                                    color = Color.Gray,
                                    textAlign = TextAlign.Center
                                )
                                Spacer(modifier = Modifier.height(16.dp))
                                Button(
                                    onClick = onDismiss,
                                    colors = ButtonDefaults.buttonColors(containerColor = PaytmNavy),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text("Dismiss")
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
