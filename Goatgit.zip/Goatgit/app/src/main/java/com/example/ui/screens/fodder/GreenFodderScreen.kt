package com.example.ui.screens.fodder

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.fodder.*
import com.example.data.offline.*
import com.example.data.supabase.GoatRepository
import com.example.i18n.t
import com.example.ui.components.FarmTopBar
import com.example.ui.theme.*
import kotlinx.coroutines.launch
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GreenFodderScreen(
    repository: GoatRepository,
    fodderRepository: FodderRepository,
    initialTab: Int = 0,
    onNavigateBack: () -> Unit
) {
    val coroutineScope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }

    var selectedTabIndex by remember { mutableStateOf(initialTab) }
    val tabs = listOf(
        t("fodder.tab_dashboard"),
        t("fodder.tab_cutting_plan"),
        t("fodder.tab_fields_rows"),
        t("fodder.tab_cycles"),
        t("fodder.tab_calendar"),
        t("fodder.tab_planner"),
        t("fodder.tab_activities"),
        t("fodder.tab_materials"),
        t("fodder.tab_species_master"),
        t("fodder.tab_techniques"),
        t("fodder.tab_feeding_stock"),
        t("fodder.tab_weather"),
        t("fodder.tab_reports_view"),
        t("fodder.tab_master_settings")
    )

    // Data collection from flows
    val speciesList by fodderRepository.speciesFlow.collectAsState(initial = emptyList())
    val plotsList by fodderRepository.plotsFlow.collectAsState(initial = emptyList())
    val cuttingsList by fodderRepository.cuttingsFlow.collectAsState(initial = emptyList())
    val feedingsList by fodderRepository.feedingsFlow.collectAsState(initial = emptyList())
    val adjustmentsList by fodderRepository.adjustmentsFlow.collectAsState(initial = emptyList())
    val materialsList by fodderRepository.materialsFlow.collectAsState(initial = emptyList())
    val activitiesList by fodderRepository.activitiesFlow.collectAsState(initial = emptyList())

    var stockSummary by remember { mutableStateOf(FodderStockSummary()) }
    var dashboardMetrics by remember { mutableStateOf(FodderDashboardMetrics()) }
    var dailyHarvestPlans by remember { mutableStateOf<List<PlotCuttingPlan>>(emptyList()) }

    // Selected plot for inline layout view
    var activeLayoutPlotId by remember { mutableStateOf<String?>(null) }
    var activePlotRows by remember { mutableStateOf<List<FodderRowEntity>>(emptyList()) }
    var selectedRowCodes by remember { mutableStateOf<Set<String>>(emptySet()) }

    // Dialog states
    var showAddSpeciesDialog by remember { mutableStateOf(false) }
    var editingSpecies by remember { mutableStateOf<FodderSpeciesEntity?>(null) }

    var showAddPlotDialog by remember { mutableStateOf(false) }
    var editingPlot by remember { mutableStateOf<FodderPlotEntity?>(null) }

    var showRecordCuttingDialog by remember { mutableStateOf(false) }
    var preselectedPlotIdForCutting by remember { mutableStateOf<String?>(null) }
    var preselectedRowsForCutting by remember { mutableStateOf<List<String>>(emptyList()) }

    var showRecordActivityDialog by remember { mutableStateOf(false) }
    var showRecordMaterialDialog by remember { mutableStateOf(false) }
    var showRecordFeedingDialog by remember { mutableStateOf(false) }
    var showStartCycleDialog by remember { mutableStateOf(false) }

    // Row details & Replanting
    var viewingRowDetails by remember { mutableStateOf<FodderRowEntity?>(null) }
    var viewingRowPlot by remember { mutableStateOf<FodderPlotEntity?>(null) }
    var rowHarvestHistory by remember { mutableStateOf<RowHarvestHistoryItem?>(null) }
    var replantingRow by remember { mutableStateOf<FodderRowEntity?>(null) }

    // Master settings options
    var plantingMethodsList by remember { mutableStateOf(listOf("Seed", "Direct sowing", "Transplanting", "Cuttings", "Slips", "Rooted slips", "Vegetative propagation", "Other")) }
    var activityTypesList by remember { mutableStateOf(listOf("Land preparation", "Bed preparation", "Seed purchase", "Seed treatment", "Sowing", "Transplanting", "Planting slips", "Planting cuttings", "Fertilization", "Irrigation", "Weeding", "Pest control", "Disease treatment", "First cutting", "Regrowth", "Subsequent cutting", "Wastage", "Other")) }

    // Initialize sample defaults if empty
    LaunchedEffect(Unit) {
        fodderRepository.initializeDefaultDataIfEmpty()
        plantingMethodsList = fodderRepository.getMasterSettingOptions("planting_methods").ifEmpty { plantingMethodsList }
        activityTypesList = fodderRepository.getMasterSettingOptions("activity_types").ifEmpty { activityTypesList }
    }

    // Refresh calculations when data updates
    LaunchedEffect(cuttingsList, feedingsList, plotsList, activitiesList) {
        stockSummary = fodderRepository.getStockSummary()
        dashboardMetrics = fodderRepository.getDashboardMetrics()
        dailyHarvestPlans = fodderRepository.getDailyHarvestPlan()
    }

    // Update active plot rows when activeLayoutPlotId changes
    LaunchedEffect(activeLayoutPlotId, plotsList) {
        val targetId = activeLayoutPlotId ?: plotsList.firstOrNull()?.id
        if (targetId != null) {
            fodderRepository.getRowsForPlotFlow(targetId).collect { r ->
                activePlotRows = r
            }
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            FarmTopBar(
                title = t("fodder.title"),
                canNavigateBack = true,
                onNavigateBack = onNavigateBack,
                syncManager = repository.syncManager,
                backupManager = repository.backupManager
            )
        },
        floatingActionButton = {
            when (selectedTabIndex) {
                1 -> {
                    // Cutting Plan
                    ExtendedFloatingActionButton(
                        onClick = {
                            preselectedPlotIdForCutting = null
                            preselectedRowsForCutting = emptyList()
                            showRecordCuttingDialog = true
                        },
                        containerColor = FarmGreenDark,
                        contentColor = Color.White,
                        modifier = Modifier.testTag("fab_record_cut_plan")
                    ) {
                        Icon(Icons.Default.ContentCut, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Record Cut", fontWeight = FontWeight.Bold)
                    }
                }
                2 -> {
                    // Fields & Rows
                    ExtendedFloatingActionButton(
                        onClick = {
                            editingPlot = null
                            showAddPlotDialog = true
                        },
                        containerColor = FarmGreenDark,
                        contentColor = Color.White,
                        modifier = Modifier.testTag("fab_add_plot")
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Add Field / Plot", fontWeight = FontWeight.Bold)
                    }
                }
                3 -> {
                    // Cultivation Cycles
                    ExtendedFloatingActionButton(
                        onClick = { showStartCycleDialog = true },
                        containerColor = FarmGreenDark,
                        contentColor = Color.White,
                        modifier = Modifier.testTag("fab_start_crop_cycle")
                    ) {
                        Icon(Icons.Default.Recycling, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Start Cycle", fontWeight = FontWeight.Bold)
                    }
                }
                6 -> {
                    // Activities
                    ExtendedFloatingActionButton(
                        onClick = { showRecordActivityDialog = true },
                        containerColor = FarmGreenDark,
                        contentColor = Color.White,
                        modifier = Modifier.testTag("fab_record_activity")
                    ) {
                        Icon(Icons.Default.EventNote, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Log Activity", fontWeight = FontWeight.Bold)
                    }
                }
                7 -> {
                    // Materials
                    ExtendedFloatingActionButton(
                        onClick = { showRecordMaterialDialog = true },
                        containerColor = Color(0xFF0277BD),
                        contentColor = Color.White,
                        modifier = Modifier.testTag("fab_add_material")
                    ) {
                        Icon(Icons.Default.Inventory2, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Add Material", fontWeight = FontWeight.Bold)
                    }
                }
                8 -> {
                    // Species Master
                    ExtendedFloatingActionButton(
                        onClick = {
                            editingSpecies = null
                            showAddSpeciesDialog = true
                        },
                        containerColor = FarmGreenDark,
                        contentColor = Color.White,
                        modifier = Modifier.testTag("fab_add_species")
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Add Species", fontWeight = FontWeight.Bold)
                    }
                }
                10 -> {
                    // Feeding & Stock
                    ExtendedFloatingActionButton(
                        onClick = { showRecordFeedingDialog = true },
                        containerColor = FarmAmber,
                        contentColor = FarmBrown,
                        modifier = Modifier.testTag("fab_record_feeding")
                    ) {
                        Icon(Icons.Default.Restaurant, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Record Feeding", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            // ==========================================
            // TOP STOCK PILLARS HERO BANNER
            // ==========================================
            Surface(
                color = Color(0xFFF1F8E9),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Grass, contentDescription = null, tint = FarmGreenDark, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "GREEN FODDER STOCK",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = FarmGreenDark
                            )
                        }
                        Surface(
                            shape = RoundedCornerShape(4.dp),
                            color = FarmGreenContainer
                        ) {
                            Text(
                                text = "${stockSummary.daysOfStockRemaining} days herd buffer (${stockSummary.dailyHerdConsumptionRateKg.toInt()} kg/d)",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = FarmGreenDark,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    // 4 Stock Pillars: Harvested, Consumed, Wastage, Balance
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        StockMiniCard(title = "Harvested", value = "${stockSummary.totalHarvestedKg.toInt()}", unit = "kg", color = FarmGreenDark, modifier = Modifier.weight(1f))
                        StockMiniCard(title = "Consumed", value = "${stockSummary.totalConsumedKg.toInt()}", unit = "kg", color = Color(0xFF0277BD), modifier = Modifier.weight(1f))
                        StockMiniCard(title = "Wastage", value = "${stockSummary.totalWastageKg.toInt()}", unit = "kg", color = FarmWarning, modifier = Modifier.weight(1f))
                        StockMiniCard(title = "Balance", value = "${stockSummary.currentBalanceKg.toInt()}", unit = "kg", color = FarmSuccess, modifier = Modifier.weight(1f))
                    }
                }
            }

            // ==========================================
            // TABS ROW
            // ==========================================
            ScrollableTabRow(
                selectedTabIndex = selectedTabIndex,
                containerColor = Color.White,
                contentColor = FarmGreenDark,
                edgePadding = 8.dp
            ) {
                tabs.forEachIndexed { index, title ->
                    Tab(
                        selected = selectedTabIndex == index,
                        onClick = { selectedTabIndex = index },
                        text = {
                            Text(
                                text = title,
                                fontWeight = if (selectedTabIndex == index) FontWeight.Bold else FontWeight.Medium,
                                fontSize = 12.sp
                            )
                        },
                        modifier = Modifier.testTag("fodder_tab_$index")
                    )
                }
            }

            // ==========================================
            // TAB CONTENT
            // ==========================================
            Box(modifier = Modifier.weight(1f)) {
                when (selectedTabIndex) {
                    // TAB 0: GREEN FODDER DASHBOARD (Requirement 22)
                    0 -> {
                        LazyColumn(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            item {
                                Text("Green Fodder Operations Dashboard", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge, color = FarmGreenDark)
                            }

                            // 10 Key Dashboard Metrics Grid (Requirement 22)
                            item {
                                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        MetricHighlightCard(title = "Total Fields", value = "${dashboardMetrics.totalFields}", subtitle = "${String.format(Locale.US, "%.2f", dashboardMetrics.totalCultivatedAreaAcres)} acres cultivated", color = FarmGreenDark, modifier = Modifier.weight(1f))
                                        MetricHighlightCard(title = "Total Rows", value = "${dashboardMetrics.totalRows} rows", subtitle = "${dashboardMetrics.totalRowLengthMetres.toInt()} m row length", color = Color(0xFF0277BD), modifier = Modifier.weight(1f))
                                    }
                                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        MetricHighlightCard(title = "Rows Due for Cut", value = "${dashboardMetrics.rowsDueForCutting} rows", subtitle = "Ready for harvest", color = FarmWarning, modifier = Modifier.weight(1f))
                                        MetricHighlightCard(title = "Harvested Today", value = "${dashboardMetrics.rowsHarvestedToday} rows", subtitle = "${dashboardMetrics.productionTodayKg.toInt()} kg cut today", color = FarmSuccess, modifier = Modifier.weight(1f))
                                    }
                                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        MetricHighlightCard(title = "Month Production", value = "${dashboardMetrics.productionThisMonthKg.toInt()} kg", subtitle = "Cumulative this month", color = FarmBrown, modifier = Modifier.weight(1f))
                                        MetricHighlightCard(title = "Species Count", value = "${dashboardMetrics.speciesCount} varieties", subtitle = "Next cut: ${dashboardMetrics.nextCuttingDate ?: "N/A"}", color = Color(0xFF5C6BC0), modifier = Modifier.weight(1f))
                                    }
                                }
                            }

                            // Section: Today's Cutting Plan
                            item {
                                Card(
                                    shape = RoundedCornerShape(14.dp),
                                    colors = CardDefaults.cardColors(containerColor = Color.White),
                                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Icon(Icons.Default.DateRange, contentDescription = null, tint = FarmGreenDark, modifier = Modifier.size(18.dp))
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Text("Today's Cutting Plan", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium, color = FarmGreenDark)
                                            }
                                            TextButton(onClick = { selectedTabIndex = 1 }) {
                                                Text("View Full Plan", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                            }
                                        }

                                        if (dailyHarvestPlans.isEmpty()) {
                                            Text("No cutting plans generated yet.", color = Color.Gray, fontSize = 12.sp)
                                        } else {
                                            dailyHarvestPlans.take(2).forEach { plan ->
                                                Surface(
                                                    shape = RoundedCornerShape(8.dp),
                                                    color = Color(0xFFF9FBF9),
                                                    modifier = Modifier.fillMaxWidth()
                                                ) {
                                                    Row(
                                                        modifier = Modifier.padding(10.dp),
                                                        horizontalArrangement = Arrangement.SpaceBetween,
                                                        verticalAlignment = Alignment.CenterVertically
                                                    ) {
                                                        Column {
                                                            Text(plan.plot.plot_name, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                                            Text("${plan.rowsAvailable.size} of ${plan.totalRows} rows available • ${plan.rowsHarvestedToday.size} cut today", fontSize = 11.sp, color = Color.Gray)
                                                        }
                                                        Button(
                                                            onClick = {
                                                                preselectedPlotIdForCutting = plan.plot.id
                                                                preselectedRowsForCutting = plan.rowsAvailable.take(5).map { it.row_code }
                                                                showRecordCuttingDialog = true
                                                            },
                                                            colors = ButtonDefaults.buttonColors(containerColor = FarmGreenDark),
                                                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                                                        ) {
                                                            Text("Cut Rows", fontSize = 11.sp)
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }

                            // Section: Recent Field Activities
                            item {
                                Card(
                                    shape = RoundedCornerShape(14.dp),
                                    colors = CardDefaults.cardColors(containerColor = Color.White),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text("Recent Field Activities", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium, color = FarmGreenDark)
                                            TextButton(onClick = { selectedTabIndex = 6 }) { Text("All Activities", fontSize = 12.sp) }
                                        }

                                        if (activitiesList.isEmpty()) {
                                            Text("No activities logged yet.", color = Color.Gray, fontSize = 12.sp)
                                        } else {
                                            activitiesList.take(3).forEach { act ->
                                                CropActivityItemRow(
                                                    activity = act,
                                                    onDelete = {
                                                        coroutineScope.launch { fodderRepository.deleteActivity(act.id) }
                                                    }
                                                )
                                            }
                                        }
                                    }
                                }
                            }

                            // Quick Navigation to Cultivation Cycles, Calendar, Planner, Techniques, Reports
                            item {
                                Card(
                                    shape = RoundedCornerShape(14.dp),
                                    colors = CardDefaults.cardColors(containerColor = Color.White),
                                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                        Text("Fodder Agronomy & Planning Modules", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium, color = FarmGreenDark)
                                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                            OutlinedButton(
                                                onClick = { selectedTabIndex = 3 },
                                                modifier = Modifier.weight(1f),
                                                shape = RoundedCornerShape(8.dp)
                                            ) {
                                                Icon(Icons.Default.Recycling, contentDescription = null, modifier = Modifier.size(16.dp))
                                                Spacer(modifier = Modifier.width(4.dp))
                                                Text("Cycles", fontSize = 11.sp)
                                            }
                                            OutlinedButton(
                                                onClick = { selectedTabIndex = 4 },
                                                modifier = Modifier.weight(1f),
                                                shape = RoundedCornerShape(8.dp)
                                            ) {
                                                Icon(Icons.Default.CalendarToday, contentDescription = null, modifier = Modifier.size(16.dp))
                                                Spacer(modifier = Modifier.width(4.dp))
                                                Text("Calendar", fontSize = 11.sp)
                                            }
                                            OutlinedButton(
                                                onClick = { selectedTabIndex = 5 },
                                                modifier = Modifier.weight(1f),
                                                shape = RoundedCornerShape(8.dp)
                                            ) {
                                                Icon(Icons.Default.Calculate, contentDescription = null, modifier = Modifier.size(16.dp))
                                                Spacer(modifier = Modifier.width(4.dp))
                                                Text("Planner", fontSize = 11.sp)
                                            }
                                        }
                                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                            OutlinedButton(
                                                onClick = { selectedTabIndex = 9 },
                                                modifier = Modifier.weight(1f),
                                                shape = RoundedCornerShape(8.dp)
                                            ) {
                                                Icon(Icons.Default.MenuBook, contentDescription = null, modifier = Modifier.size(16.dp))
                                                Spacer(modifier = Modifier.width(4.dp))
                                                Text("Techniques DB", fontSize = 11.sp)
                                            }
                                            OutlinedButton(
                                                onClick = { selectedTabIndex = 12 },
                                                modifier = Modifier.weight(1f),
                                                shape = RoundedCornerShape(8.dp)
                                            ) {
                                                Icon(Icons.Default.Analytics, contentDescription = null, modifier = Modifier.size(16.dp))
                                                Spacer(modifier = Modifier.width(4.dp))
                                                Text("P&L & Reports", fontSize = 11.sp)
                                            }
                                        }
                                    }
                                }
                            }

                            item { Spacer(modifier = Modifier.height(32.dp)) }
                        }
                    }

                    // TAB 1: TODAY'S CUTTING PLAN (Requirement 7)
                    1 -> {
                        LazyColumn(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            item {
                                Text("Today's Fodder Cutting Plan", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge, color = FarmGreenDark)
                                Text("Select rows to cut. As you record cuttings, rows update seamlessly from available to harvested.", fontSize = 12.sp, color = Color.Gray)
                            }

                            if (dailyHarvestPlans.isEmpty()) {
                                item {
                                    Text("No plots available. Please add a field in 'Fields & Rows'.", color = Color.Gray)
                                }
                            } else {
                                items(dailyHarvestPlans) { plan ->
                                    val plot = plan.plot
                                    val harvestedRows = plan.rowsHarvestedToday
                                    val previouslyHarvested = plan.rowsPreviouslyHarvested
                                    val remainingRows = plan.remainingRows

                                    Card(
                                        shape = RoundedCornerShape(14.dp),
                                        colors = CardDefaults.cardColors(containerColor = Color.White),
                                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                                        modifier = Modifier.fillMaxWidth().testTag("cutting_plan_${plot.id}")
                                    ) {
                                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Column {
                                                    Text(plot.plot_name, fontWeight = FontWeight.Bold, fontSize = 15.sp, color = FarmGreenDark)
                                                    Text("${plot.species_name} • ${plot.row_count} rows (${plot.row_length}m each)", fontSize = 11.sp, color = Color.Gray)
                                                }

                                                Surface(shape = RoundedCornerShape(4.dp), color = FarmGreenContainer) {
                                                    Text(
                                                        text = "${remainingRows.size} rows remaining",
                                                        fontSize = 11.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        color = FarmGreenDark,
                                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                                                    )
                                                }
                                            }

                                            // Progress Bar: Harvested vs Remaining
                                            val pct = if (plan.totalRows > 0) ((plan.totalRows - remainingRows.size).toFloat() / plan.totalRows.toFloat()) else 0f
                                            LinearProgressIndicator(
                                                progress = { pct.coerceIn(0f, 1f) },
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .height(8.dp)
                                                    .clip(RoundedCornerShape(4.dp)),
                                                color = FarmSuccess,
                                                trackColor = Color(0xFFE0E0E0)
                                            )

                                            // Breakdown Strip
                                            Surface(
                                                shape = RoundedCornerShape(8.dp),
                                                color = Color(0xFFF9FBF9),
                                                modifier = Modifier.fillMaxWidth()
                                            ) {
                                                Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                                        Text("• Harvested Today:", fontSize = 11.sp, color = Color.DarkGray)
                                                        Text(if (harvestedRows.isNotEmpty()) "${harvestedRows.size} rows (${harvestedRows.first().row_code}–${harvestedRows.last().row_code})" else "0 rows", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = FarmSuccess)
                                                    }
                                                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                                        Text("• Available for Cut:", fontSize = 11.sp, color = Color.DarkGray)
                                                        Text("${plan.rowsAvailable.size} rows", fontWeight = FontWeight.SemiBold, fontSize = 11.sp)
                                                    }
                                                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                                        Text("• Remaining Unharvested:", fontSize = 11.sp, color = Color.DarkGray)
                                                        Text("${remainingRows.size} rows", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = FarmBrown)
                                                    }
                                                }
                                            }

                                            // Quick Row Cutting Actions (e.g. Next 5 rows)
                                            val next5Available = remainingRows.take(5)
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                if (next5Available.isNotEmpty()) {
                                                    Text(
                                                        text = "Next: ${next5Available.first().row_code}–${next5Available.last().row_code} (${next5Available.size * plot.row_length.toInt()}m)",
                                                        fontSize = 11.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        color = FarmGreenDark
                                                    )
                                                } else {
                                                    Text("All rows cut in current cycle", fontSize = 11.sp, color = Color.Gray)
                                                }

                                                Button(
                                                    onClick = {
                                                        preselectedPlotIdForCutting = plot.id
                                                        preselectedRowsForCutting = next5Available.map { it.row_code }
                                                        showRecordCuttingDialog = true
                                                    },
                                                    enabled = remainingRows.isNotEmpty(),
                                                    colors = ButtonDefaults.buttonColors(containerColor = FarmGreenDark),
                                                    shape = RoundedCornerShape(8.dp)
                                                ) {
                                                    Icon(Icons.Default.ContentCut, contentDescription = null, modifier = Modifier.size(14.dp))
                                                    Spacer(modifier = Modifier.width(4.dp))
                                                    Text("Record Cut", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            item { Spacer(modifier = Modifier.height(72.dp)) }
                        }
                    }

                    // TAB 2: FIELDS & ROWS (Requirement 1, 2, 10, 13)
                    2 -> {
                        LazyColumn(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            item {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("Fields & Row Master (${plotsList.size})", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge, color = FarmGreenDark)
                                }
                            }

                            if (plotsList.isEmpty()) {
                                item {
                                    Box(modifier = Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                                        Text("No fields registered yet. Tap '+ Add Field / Plot' below.", color = Color.Gray)
                                    }
                                }
                            } else {
                                items(plotsList, key = { it.id }) { plot ->
                                    val isLayoutActive = activeLayoutPlotId == plot.id
                                    FodderPlotCard(
                                        plot = plot,
                                        rows = if (isLayoutActive) activePlotRows else emptyList(),
                                        onRecordCutting = {
                                            preselectedPlotIdForCutting = plot.id
                                            preselectedRowsForCutting = emptyList()
                                            showRecordCuttingDialog = true
                                        },
                                        onViewLayout = {
                                            activeLayoutPlotId = if (isLayoutActive) null else plot.id
                                            selectedRowCodes = emptySet()
                                        },
                                        onEdit = {
                                            editingPlot = plot
                                            showAddPlotDialog = true
                                        },
                                        onDelete = {
                                            coroutineScope.launch {
                                                fodderRepository.deletePlot(plot.id)
                                                snackbarHostState.showSnackbar("Field removed")
                                            }
                                        }
                                    )

                                    // Inline Visual Layout when toggled
                                    if (isLayoutActive) {
                                        FieldVisualLayoutView(
                                            plot = plot,
                                            rows = activePlotRows,
                                            selectedRowCodes = selectedRowCodes,
                                            onToggleRowSelection = { code ->
                                                selectedRowCodes = if (selectedRowCodes.contains(code)) {
                                                    selectedRowCodes - code
                                                } else {
                                                    selectedRowCodes + code
                                                }
                                            },
                                            onSelectRange = { start, end ->
                                                val rangeCodes = (start..end).map { "R%02d".format(it) }
                                                selectedRowCodes = rangeCodes.toSet()
                                            },
                                            onSelectAllAvailable = {
                                                selectedRowCodes = activePlotRows.filter { it.status == "Due for cutting" || it.status == "Growing" }.map { it.row_code }.toSet()
                                            },
                                            onClearSelection = { selectedRowCodes = emptySet() },
                                            onRowDetailsClick = { row ->
                                                viewingRowDetails = row
                                                viewingRowPlot = plot
                                                coroutineScope.launch {
                                                    rowHarvestHistory = fodderRepository.getRowHarvestHistory(plot.id, row.row_code)
                                                }
                                            },
                                            onHarvestSelectedClick = {
                                                preselectedPlotIdForCutting = plot.id
                                                preselectedRowsForCutting = selectedRowCodes.sorted().toList()
                                                showRecordCuttingDialog = true
                                            }
                                        )
                                    }
                                }
                            }
                            item { Spacer(modifier = Modifier.height(72.dp)) }
                        }
                    }

                    // TAB 3: CULTIVATION CYCLES (Requirement 5)
                    3 -> {
                        FodderCyclesView(
                            repository = fodderRepository,
                            plots = plotsList,
                            onStartCycleClick = { showStartCycleDialog = true }
                        )
                    }

                    // TAB 4: CULTIVATION CALENDAR (Requirement 15)
                    4 -> {
                        FodderCalendarView(
                            repository = fodderRepository,
                            onNavigateToCut = { plotId ->
                                preselectedPlotIdForCutting = plotId
                                preselectedRowsForCutting = emptyList()
                                showRecordCuttingDialog = true
                            }
                        )
                    }

                    // TAB 5: FODDER REQUIREMENT PLANNER (Requirement 16)
                    5 -> {
                        FodderRequirementPlannerView(repository = fodderRepository)
                    }

                    // TAB 6: CROP ACTIVITIES (Requirement 9)
                    6 -> {
                        LazyColumn(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            item {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("Crop Activity History (${activitiesList.size})", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge, color = FarmGreenDark)
                                }
                                Text("Chronological field activity log including land prep, sowing, slips, fertilizer, irrigation, weeding, cutting.", fontSize = 11.sp, color = Color.Gray)
                            }

                            if (activitiesList.isEmpty()) {
                                item {
                                    Box(modifier = Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                                        Text("No activities logged yet. Tap '+ Log Activity' below.", color = Color.Gray)
                                    }
                                }
                            } else {
                                items(activitiesList, key = { it.id }) { act ->
                                    CropActivityItemRow(
                                        activity = act,
                                        onDelete = {
                                            coroutineScope.launch {
                                                fodderRepository.deleteActivity(act.id)
                                                snackbarHostState.showSnackbar("Activity deleted")
                                            }
                                        }
                                    )
                                }
                            }
                            item { Spacer(modifier = Modifier.height(72.dp)) }
                        }
                    }

                    // TAB 7: SEED & PLANTING MATERIALS (Requirement 4, 6, 7, 8)
                    7 -> {
                        LazyColumn(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            item {
                                Text("Planting Material & Seed Inventory (${materialsList.size})", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge, color = FarmGreenDark)
                                Text("Track seeds, vegetative slips, stem cuttings, and transplants with usage & remaining buffer.", fontSize = 11.sp, color = Color.Gray)
                            }

                            if (materialsList.isEmpty()) {
                                item {
                                    Box(modifier = Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                                        Text("No planting materials in inventory. Tap '+ Add Material' below.", color = Color.Gray)
                                    }
                                }
                            } else {
                                items(materialsList, key = { it.id }) { mat ->
                                    PlantingMaterialItemRow(
                                        material = mat,
                                        onDelete = {
                                            coroutineScope.launch {
                                                fodderRepository.deleteMaterial(mat.id)
                                                snackbarHostState.showSnackbar("Material removed")
                                            }
                                        }
                                    )
                                }
                            }
                            item { Spacer(modifier = Modifier.height(72.dp)) }
                        }
                    }

                    // TAB 8: SPECIES MASTER
                    8 -> {
                        LazyColumn(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            item {
                                Text("Fodder Species Master (${speciesList.size})", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge, color = FarmGreenDark)
                            }

                            if (speciesList.isEmpty()) {
                                item {
                                    Box(modifier = Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                                        Text("No species registered. Tap '+ Add Species' below.", color = Color.Gray)
                                    }
                                }
                            } else {
                                items(speciesList, key = { it.id }) { sp ->
                                    FodderSpeciesCard(
                                        species = sp,
                                        onEdit = {
                                            editingSpecies = sp
                                            showAddSpeciesDialog = true
                                        },
                                        onDelete = {
                                            coroutineScope.launch {
                                                fodderRepository.deleteSpecies(sp.id)
                                                snackbarHostState.showSnackbar("Species deleted")
                                            }
                                        }
                                    )
                                }
                            }
                            item { Spacer(modifier = Modifier.height(72.dp)) }
                        }
                    }

                    // TAB 9: CULTIVATION TECHNIQUES (Requirement 3)
                    9 -> {
                        FodderCultivationTechniquesView(repository = fodderRepository)
                    }

                    // TAB 10: FEEDING & STOCK (Requirement 11, 12, 13, 14)
                    10 -> {
                        LazyColumn(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            item {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("Daily Goat Feeding Log (${feedingsList.size})", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge, color = FarmGreenDark)
                                    Text("Total Fed: ${feedingsList.sumOf { it.quantity_fed_kg }.toInt()} kg", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = FarmBrown)
                                }
                            }

                            if (feedingsList.isEmpty()) {
                                item {
                                    Box(modifier = Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                                        Text("No feeding records logged yet. Tap '+ Record Feeding' below.", color = Color.Gray)
                                    }
                                }
                            } else {
                                items(feedingsList, key = { it.id }) { f ->
                                    FeedingHistoryItemRow(
                                        feeding = f,
                                        onDelete = {
                                            coroutineScope.launch {
                                                fodderRepository.deleteFeeding(f.id)
                                                snackbarHostState.showSnackbar("Feeding record removed")
                                            }
                                        }
                                    )
                                }
                            }
                            item { Spacer(modifier = Modifier.height(72.dp)) }
                        }
                    }

                    // TAB 11: WEATHER & RAIN
                    11 -> {
                        LazyColumn(modifier = Modifier.fillMaxSize()) {
                            item {
                                FodderWeatherView(weatherService = fodderRepository.weatherService)
                            }
                            item { Spacer(modifier = Modifier.height(32.dp)) }
                        }
                    }

                    // TAB 12: REPORTS & ANALYTICS (Requirement 14, 17, 18)
                    12 -> {
                        LazyColumn(modifier = Modifier.fillMaxSize()) {
                            item {
                                FodderReportsView(repository = fodderRepository)
                            }
                            item { Spacer(modifier = Modifier.height(32.dp)) }
                        }
                    }

                    // TAB 13: MASTER SETTINGS (Requirement 19)
                    13 -> {
                        MasterSettingsView(
                            plantingMethods = plantingMethodsList,
                            activityTypes = activityTypesList,
                            onSavePlantingMethods = { updated ->
                                plantingMethodsList = updated
                                coroutineScope.launch {
                                    fodderRepository.saveMasterSettingOptions("planting_methods", updated)
                                    snackbarHostState.showSnackbar("Planting methods updated")
                                }
                            },
                            onSaveActivityTypes = { updated ->
                                activityTypesList = updated
                                coroutineScope.launch {
                                    fodderRepository.saveMasterSettingOptions("activity_types", updated)
                                    snackbarHostState.showSnackbar("Activity types updated")
                                }
                            }
                        )
                    }
                }
            }
        }
    }

    // ==========================================
    // DIALOGS
    // ==========================================
    // 1. Add / Edit Species
    if (showAddSpeciesDialog) {
        AddEditSpeciesDialog(
            initialSpecies = editingSpecies,
            onDismiss = { showAddSpeciesDialog = false },
            onSave = { sp ->
                coroutineScope.launch {
                    fodderRepository.saveSpecies(sp)
                    showAddSpeciesDialog = false
                    snackbarHostState.showSnackbar("Species '${sp.name}' saved")
                }
            }
        )
    }

    // 2. Add / Edit Plot with Field Row Master
    if (showAddPlotDialog) {
        AddEditPlotDialog(
            initialPlot = editingPlot,
            speciesList = speciesList,
            onDismiss = { showAddPlotDialog = false },
            onSave = { plot ->
                coroutineScope.launch {
                    fodderRepository.savePlot(plot, autoGenerateRows = true)
                    showAddPlotDialog = false
                    snackbarHostState.showSnackbar("Field '${plot.plot_name}' saved with ${plot.row_count} rows")
                }
            }
        )
    }

    // 3. Record Row Harvest Cutting
    if (showRecordCuttingDialog) {
        RecordCuttingDialog(
            plots = plotsList,
            preselectedPlotId = preselectedPlotIdForCutting,
            preselectedRows = preselectedRowsForCutting,
            onDismiss = { showRecordCuttingDialog = false },
            onSave = { plotId, selectedRows, weight, date, labor, harvester, quality, notes ->
                coroutineScope.launch {
                    val res = fodderRepository.recordRowHarvest(
                        plotId = plotId,
                        selectedRowCodes = selectedRows,
                        harvestedWeightKg = weight,
                        cuttingDate = date,
                        laborCost = labor,
                        harvesterName = harvester,
                        qualityRating = quality,
                        notes = notes
                    )
                    showRecordCuttingDialog = false
                    selectedRowCodes = emptySet()
                    if (res.isSuccess) {
                        val cut = res.getOrThrow()
                        snackbarHostState.showSnackbar("Harvested ${cut.harvested_weight_kg.toInt()} kg from ${cut.row_codes}")
                    } else {
                        snackbarHostState.showSnackbar("Error saving cutting: ${res.exceptionOrNull()?.message}")
                    }
                }
            }
        )
    }

    // 4. Record Crop Activity
    if (showRecordActivityDialog) {
        RecordCropActivityDialog(
            plots = plotsList,
            activityTypes = activityTypesList,
            onDismiss = { showRecordActivityDialog = false },
            onSave = { plotId, rows, type, date, qty, unit, hours, labourCost, matCost, notes ->
                coroutineScope.launch {
                    val plot = plotsList.find { it.id == plotId }
                    val act = FodderActivityEntity(
                        plot_id = plotId,
                        plot_name = plot?.plot_name ?: "Field",
                        row_codes = rows,
                        species_name = plot?.species_name ?: "Fodder",
                        variety = plot?.variety,
                        activity_type = type,
                        activity_date = date,
                        quantity = qty,
                        unit = unit,
                        labour_hours = hours,
                        labour_cost = labourCost,
                        material_cost = matCost,
                        total_cost = (labourCost ?: 0.0) + (matCost ?: 0.0),
                        notes = notes
                    )
                    fodderRepository.recordActivity(act)
                    showRecordActivityDialog = false
                    snackbarHostState.showSnackbar("Activity '$type' logged")
                }
            }
        )
    }

    // 5. Record Planting Material (Requirement 6, 7, 8)
    if (showRecordMaterialDialog) {
        RecordMaterialPurchaseDialog(
            speciesList = speciesList,
            plots = plotsList,
            onDismiss = { showRecordMaterialDialog = false },
            onSave = { mat, plotId, plotName, cropCycleId, paymentMode ->
                coroutineScope.launch {
                    fodderRepository.recordMaterialPurchase(
                        material = mat,
                        plotId = plotId,
                        plotName = plotName,
                        cropCycleId = cropCycleId,
                        paymentMode = paymentMode
                    )
                    showRecordMaterialDialog = false
                    snackbarHostState.showSnackbar("Planting material '${mat.material_type}' added & expense linked to ${plotName ?: "Field"}")
                }
            }
        )
    }

    // 6. Record Daily Feeding (Requirement 11, 12, 13)
    if (showRecordFeedingDialog) {
        RecordFeedingDialog(
            speciesList = speciesList,
            onDismiss = { showRecordFeedingDialog = false },
            onSave = { spId, spName, group, count, qty, date, time, chaff, waste, isPurchased, notes ->
                coroutineScope.launch {
                    val res = fodderRepository.recordFeeding(
                        speciesId = spId,
                        speciesName = spName,
                        targetGroup = group,
                        goatsCount = count,
                        quantityFedKg = qty,
                        feedingDate = date,
                        feedingTime = time,
                        chaffedMethod = chaff,
                        wastageKg = waste,
                        isPurchasedFodder = isPurchased,
                        notes = notes
                    )
                    showRecordFeedingDialog = false
                    if (res.isSuccess) {
                        val src = if (isPurchased) "purchased" else "home-grown"
                        snackbarHostState.showSnackbar("Feeding of ${qty.toInt()} kg ($src) recorded for $group")
                    }
                }
            }
        )
    }

    // 6.5 Start Cultivation Cycle (Requirement 5)
    if (showStartCycleDialog) {
        StartCropCycleDialog(
            plots = plotsList,
            onDismiss = { showStartCycleDialog = false },
            onSave = { plotId, cycleName, spName, variety, pDate, pMethod, notes ->
                coroutineScope.launch {
                    fodderRepository.startCropCycle(
                        plotId = plotId,
                        cycleName = cycleName,
                        speciesName = spName,
                        variety = variety,
                        plantingDate = pDate,
                        plantingMethod = pMethod,
                        notes = notes
                    )
                    showStartCycleDialog = false
                    snackbarHostState.showSnackbar("Cultivation cycle '$cycleName' started")
                }
            }
        )
    }

    // 7. Row Harvest History Sheet
    if (viewingRowDetails != null && viewingRowPlot != null) {
        val row = viewingRowDetails!!
        val plot = viewingRowPlot!!
        RowHistoryDialog(
            row = row,
            plot = plot,
            cuttings = rowHarvestHistory?.cuttings ?: emptyList(),
            activities = rowHarvestHistory?.activities ?: emptyList(),
            onDismiss = {
                viewingRowDetails = null
                viewingRowPlot = null
                rowHarvestHistory = null
            },
            onReplantClick = {
                replantingRow = row
                viewingRowDetails = null
            }
        )
    }

    // 8. Replant Row Dialog (Requirement 11)
    if (replantingRow != null) {
        val row = replantingRow!!
        val plot = plotsList.find { it.id == row.plot_id } ?: plotsList.first()
        ReplantRowDialog(
            row = row,
            plot = plot,
            speciesList = speciesList,
            plantingMethods = plantingMethodsList,
            onDismiss = { replantingRow = null },
            onSave = { sp, varName, date, method, qty, unit, source, cost, notes ->
                coroutineScope.launch {
                    val res = fodderRepository.replantRow(
                        plotId = row.plot_id,
                        rowCode = row.row_code,
                        speciesName = sp,
                        variety = varName,
                        plantingDate = date,
                        plantingMethod = method,
                        materialQuantity = qty,
                        materialUnit = unit,
                        source = source,
                        cost = cost,
                        notes = notes
                    )
                    replantingRow = null
                    if (res.isSuccess) {
                        snackbarHostState.showSnackbar("Row ${row.row_code} replanted successfully!")
                    }
                }
            }
        )
    }
}

// ==========================================
// MASTER SETTINGS COMPONENT (Requirement 19)
// ==========================================
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun MasterSettingsView(
    plantingMethods: List<String>,
    activityTypes: List<String>,
    onSavePlantingMethods: (List<String>) -> Unit,
    onSaveActivityTypes: (List<String>) -> Unit
) {
    var newMethodText by remember { mutableStateOf("") }
    var newActivityText by remember { mutableStateOf("") }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text("Editable Master Settings", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge, color = FarmGreenDark)
            Text("Customize dropdown options and master values according to your farm practices.", fontSize = 11.sp, color = Color.Gray)
        }

        // 1. Planting Methods
        item {
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Planting Methods Master", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = FarmGreenDark)
                    Text("Current active planting methods:", fontSize = 11.sp, color = Color.Gray)

                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        plantingMethods.forEach { method ->
                            InputChip(
                                selected = false,
                                onClick = {},
                                label = { Text(method, fontSize = 11.sp) },
                                trailingIcon = {
                                    Icon(
                                        Icons.Default.Close,
                                        contentDescription = "Remove",
                                        modifier = Modifier
                                            .size(14.dp)
                                            .clickable {
                                                onSavePlantingMethods(plantingMethods - method)
                                            }
                                    )
                                }
                            )
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = newMethodText,
                            onValueChange = { newMethodText = it },
                            placeholder = { Text("Add custom planting method") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                        Button(
                            onClick = {
                                if (newMethodText.isNotBlank()) {
                                    onSavePlantingMethods(plantingMethods + newMethodText.trim())
                                    newMethodText = ""
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = FarmGreenDark)
                        ) {
                            Text("Add")
                        }
                    }
                }
            }
        }

        // 2. Crop Activity Types
        item {
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Crop Activity Types Master", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = FarmGreenDark)
                    Text("Activities logged in field history:", fontSize = 11.sp, color = Color.Gray)

                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        activityTypes.forEach { actType ->
                            InputChip(
                                selected = false,
                                onClick = {},
                                label = { Text(actType, fontSize = 11.sp) },
                                trailingIcon = {
                                    Icon(
                                        Icons.Default.Close,
                                        contentDescription = "Remove",
                                        modifier = Modifier
                                            .size(14.dp)
                                            .clickable {
                                                onSaveActivityTypes(activityTypes - actType)
                                            }
                                    )
                                }
                            )
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = newActivityText,
                            onValueChange = { newActivityText = it },
                            placeholder = { Text("Add custom activity type") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                        Button(
                            onClick = {
                                if (newActivityText.isNotBlank()) {
                                    onSaveActivityTypes(activityTypes + newActivityText.trim())
                                    newActivityText = ""
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = FarmGreenDark)
                        ) {
                            Text("Add")
                        }
                    }
                }
            }
        }

        item { Spacer(modifier = Modifier.height(32.dp)) }
    }
}

@Composable
fun StockMiniCard(
    title: String,
    value: String,
    unit: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(8.dp),
        color = Color.White,
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(vertical = 8.dp, horizontal = 6.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(text = title, fontSize = 10.sp, color = Color.Gray)
            Row(verticalAlignment = Alignment.Bottom) {
                Text(text = value, fontWeight = FontWeight.Bold, fontSize = 15.sp, color = color)
                Spacer(modifier = Modifier.width(2.dp))
                Text(text = unit, fontSize = 9.sp, color = Color.Gray)
            }
        }
    }
}
