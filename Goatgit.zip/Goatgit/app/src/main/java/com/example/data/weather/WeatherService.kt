package com.example.data.weather

import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.TimeUnit

data class CurrentWeather(
    val temperature: Double,
    val humidity: Int,
    val precipitationMm: Double,
    val weatherCode: Int,
    val condition: String,
    val windSpeedKmh: Double
)

data class DailyForecast(
    val date: String,
    val dayName: String,
    val maxTemp: Double,
    val minTemp: Double,
    val precipitationSumMm: Double,
    val precipitationProbability: Int,
    val weatherCode: Int,
    val condition: String,
    val harvestAdvisory: String
)

data class WeatherReport(
    val latitude: Double,
    val longitude: Double,
    val locationName: String,
    val current: CurrentWeather,
    val daily: List<DailyForecast>,
    val rainForecastSummary: String
)

class WeatherService(
    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .build()
) {
    companion object {
        private const val TAG = "WeatherService"
        // Default farm location if none set (tropical agricultural zone)
        const val DEFAULT_LAT = 11.0168
        const val DEFAULT_LON = 76.9558
        const val DEFAULT_LOCATION_NAME = "Farm Field Coordinates"
    }

    suspend fun getAgriculturalWeather(
        lat: Double = DEFAULT_LAT,
        lon: Double = DEFAULT_LON,
        locationName: String = DEFAULT_LOCATION_NAME
    ): Result<WeatherReport> = withContext(Dispatchers.IO) {
        try {
            val url = "https://api.open-meteo.com/v1/forecast?" +
                    "latitude=$lat&longitude=$lon" +
                    "&current=temperature_2m,relative_humidity_2m,precipitation,weather_code,wind_speed_10m" +
                    "&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_sum,precipitation_probability_max" +
                    "&timezone=auto"

            val request = Request.Builder().url(url).get().build()
            val response = client.newCall(request).execute()

            if (!response.isSuccessful) {
                return@withContext Result.failure(Exception("Weather API returned code ${response.code}"))
            }

            val body = response.body?.string().orEmpty()
            val json = JSONObject(body)

            val currentObj = json.getJSONObject("current")
            val temp = currentObj.optDouble("temperature_2m", 28.0)
            val hum = currentObj.optInt("relative_humidity_2m", 65)
            val precip = currentObj.optDouble("precipitation", 0.0)
            val code = currentObj.optInt("weather_code", 1)
            val wind = currentObj.optDouble("wind_speed_10m", 12.0)

            val currentWeather = CurrentWeather(
                temperature = temp,
                humidity = hum,
                precipitationMm = precip,
                weatherCode = code,
                condition = decodeWeatherCode(code),
                windSpeedKmh = wind
            )

            val dailyObj = json.getJSONObject("daily")
            val timeArr = dailyObj.getJSONArray("time")
            val codeArr = dailyObj.getJSONArray("weather_code")
            val maxArr = dailyObj.getJSONArray("temperature_2m_max")
            val minArr = dailyObj.getJSONArray("temperature_2m_min")
            val precipSumArr = dailyObj.getJSONArray("precipitation_sum")
            val rainProbArr = dailyObj.getJSONArray("precipitation_probability_max")

            val dailyList = mutableListOf<DailyForecast>()
            val inputFormat = SimpleDateFormat("yyyy-MM-dd", Locale.US)
            val dayFormat = SimpleDateFormat("EEE, MMM d", Locale.getDefault())

            var rainExpectedCount = 0

            for (i in 0 until minOf(7, timeArr.length())) {
                val dateStr = timeArr.getString(i)
                val dayCode = codeArr.optInt(i, 0)
                val maxT = maxArr.optDouble(i, 30.0)
                val minT = minArr.optDouble(i, 20.0)
                val pSum = precipSumArr.optDouble(i, 0.0)
                val prob = rainProbArr.optInt(i, 0)

                val dateObj = try { inputFormat.parse(dateStr) } catch (_: Exception) { null }
                val dayDisplayName = if (i == 0) "Today" else if (dateObj != null) dayFormat.format(dateObj) else dateStr

                if (prob > 40 || pSum > 3.0) {
                    rainExpectedCount++
                }

                val advisory = when {
                    prob >= 60 || pSum >= 5.0 -> "⚠ High Rain: Postpone cutting, soil may be soggy."
                    prob in 30..59 -> "⛅ Moderate Chance: Cut in morning, dry or feed quickly."
                    else -> "✓ Ideal: Clear harvest conditions with optimal regrowth recovery."
                }

                dailyList.add(
                    DailyForecast(
                        date = dateStr,
                        dayName = dayDisplayName,
                        maxTemp = maxT,
                        minTemp = minT,
                        precipitationSumMm = pSum,
                        precipitationProbability = prob,
                        weatherCode = dayCode,
                        condition = decodeWeatherCode(dayCode),
                        harvestAdvisory = advisory
                    )
                )
            }

            val rainSummary = if (rainExpectedCount > 0) {
                "Rain predicted on $rainExpectedCount of next 7 days. Plan your fodder cutting schedule around dry days."
            } else {
                "Minimal rain forecast for next 7 days. Favorable for daily cutting and field irrigation."
            }

            val report = WeatherReport(
                latitude = lat,
                longitude = lon,
                locationName = locationName,
                current = currentWeather,
                daily = dailyList,
                rainForecastSummary = rainSummary
            )

            Result.success(report)
        } catch (e: Exception) {
            Log.e(TAG, "Error fetching agricultural weather: ${e.message}", e)
            Result.failure(e)
        }
    }

    private fun decodeWeatherCode(code: Int): String {
        return when (code) {
            0 -> "Clear Sky"
            1 -> "Mainly Sunny"
            2 -> "Partly Cloudy"
            3 -> "Overcast"
            45, 48 -> "Foggy"
            51, 53, 55 -> "Light Drizzle"
            61, 63 -> "Moderate Rain"
            65 -> "Heavy Rain"
            80, 81, 82 -> "Rain Showers"
            95, 96, 99 -> "Thunderstorm"
            else -> "Fair"
        }
    }
}
