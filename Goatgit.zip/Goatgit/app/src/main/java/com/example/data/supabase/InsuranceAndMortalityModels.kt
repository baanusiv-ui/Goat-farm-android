package com.example.data.supabase

import java.util.UUID

// ==============================================================================
// 1. LIVESTOCK INSURANCE MODELS
// ==============================================================================

data class InsuranceProvider(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val company_name: String,
    val code: String? = null,
    val type: String = "GENERAL", // GENERAL, LIVESTOCK, OTHER
    val website: String? = null,
    val phone: String? = null,
    val email: String? = null,
    val api_base_url: String? = null,
    val sandbox_url: String? = null,
    val production_url: String? = null,
    val api_version: String = "v1",
    val auth_type: String = "API_KEY", // API_KEY, OAUTH2, BASIC, NONE
    val webhook_url: String? = null,
    val is_active: Boolean = true,
    val is_sandbox: Boolean = true,
    val notes: String? = null,
    val created_at: String? = null,
    val updated_at: Long = System.currentTimeMillis()
)

data class InsurancePolicy(
    val id: String = UUID.randomUUID().toString(),
    val goat_id: String,
    val goat_tag: String,
    val rfid: String? = null,
    val goat_name: String? = null,
    val provider_id: String? = null,
    val insurance_company: String,
    val policy_name: String,
    val policy_number: String? = null,
    val proposal_number: String? = null,
    val sum_insured: Double = 0.0,
    val market_value: Double = 0.0,
    val premium: Double = 0.0,
    val tax_amount: Double = 0.0,
    val total_premium: Double = 0.0,
    val start_date: String,
    val expiry_date: String,
    val renewal_date: String? = null,
    val status: String = "Active", // Draft, Proposal, Active, Expiring Soon, Expired, Cancelled, Claim Submitted, Claim Under Review, Claim Approved, Claim Rejected, Claim Settled
    val coverage_type: String = "Comprehensive (Death & PTD)",
    val deductible: Double = 0.0,
    val claim_eligibility: String? = null,
    val agent_name: String? = null,
    val agent_contact: String? = null,
    val policy_document_url: String? = null,
    val vet_certificate_url: String? = null,
    val animal_photo_url: String? = null,
    val eartag_photo_url: String? = null,
    val payment_account_id: String? = null,
    val created_at: String? = null,
    val updated_at: String? = null
) {
    val isExpiringSoon: Boolean
        get() = status.equals("Expiring Soon", ignoreCase = true)

    val isActive: Boolean
        get() = status.equals("Active", ignoreCase = true) || status.equals("Expiring Soon", ignoreCase = true)
}

data class InsuranceQuote(
    val id: String = UUID.randomUUID().toString(),
    val goat_id: String,
    val goat_tag: String,
    val provider_id: String? = null,
    val provider_name: String,
    val product_name: String,
    val sum_insured: Double,
    val premium: Double,
    val tax_amount: Double,
    val total_premium: Double,
    val validity_date: String,
    val coverage_details: String? = null,
    val terms_and_conditions: String? = null,
    val exclusions: String? = null,
    val status: String = "AVAILABLE", // AVAILABLE, ACCEPTED, REJECTED, EXPIRED
    val created_at: String? = null
)

data class InsuranceClaim(
    val id: String = UUID.randomUUID().toString(),
    val policy_id: String,
    val goat_id: String,
    val goat_tag: String,
    val mortality_event_id: String? = null,
    val incident_date: String,
    val incident_type: String = "Death", // Death, Accident, PTD, Theft, Sickness
    val cause: String,
    val description: String? = null,
    val location: String? = null,
    val vet_doctor: String? = null,
    val vet_certificate_url: String? = null,
    val photos_urls: String? = null,
    val eartag_photo_url: String? = null,
    val post_mortem_report_url: String? = null,
    val police_report_url: String? = null,
    val claim_amount: Double,
    val claim_number: String? = null,
    val submitted_date: String? = null,
    val insurer_response: String? = null,
    val approved_amount: Double? = null,
    val settlement_date: String? = null,
    val settlement_amount: Double? = null,
    val settlement_account_id: String? = null,
    val rejection_reason: String? = null,
    val status: String = "Draft", // Draft, Submitted, Documents Pending, Under Review, Approved, Rejected, Partially Settled, Settled
    val notes: String? = null,
    val created_at: String? = null,
    val updated_at: String? = null
)

data class InsuranceAlert(
    val id: String = UUID.randomUUID().toString(),
    val policy_id: String? = null,
    val claim_id: String? = null,
    val goat_id: String? = null,
    val alert_type: String, // EXPIRY, RENEWAL_DUE, PREMIUM_DUE, PROPOSAL_PENDING, MISSING_DOCUMENTS, CLAIM_STATUS
    val title: String,
    val message: String,
    val due_date: String,
    val days_before_expiry: Int = 0,
    val is_dismissed: Boolean = false,
    val created_at: String? = null
)

data class InsuranceDueItem(
    val policyId: String,
    val goatId: String,
    val goatTag: String,
    val goatName: String?,
    val policyNumber: String?,
    val company: String,
    val expiryDate: String,
    val daysRemaining: Int,
    val premium: Double,
    val sumInsured: Double,
    val status: String
)

// ==============================================================================
// 2. REPRODUCTIVE OUTCOMES & MORTALITY
// ==============================================================================

data class ReproductiveEvent(
    val id: String = UUID.randomUUID().toString(),
    val doe_id: String,
    val pregnancy_id: String? = null,
    val sire_id: String? = null,
    val event_type: String, // NORMAL_DELIVERY, ABORTION, STILLBIRTH, KID_DEATH, DOE_DEATH, POST_DELIVERY_DEATH, OTHER_MORTALITY
    val event_date: String,
    val mating_date: String? = null,
    val expected_delivery_date: String? = null,
    val pregnancy_age_days: Int? = null,
    val number_of_fetuses: Int? = null,
    val suspected_cause: String? = null,
    val confirmed_cause: String? = null,
    val cause_category: String? = null,
    val vet_diagnosis: String? = null,
    val symptoms: String? = null,
    val treatment: String? = null,
    val vet_doctor: String? = null,
    val certificate_url: String? = null,
    val photo_url: String? = null,
    val notes: String? = null,
    val created_at: String? = null
)

data class PostDeliveryCheck(
    val id: String = UUID.randomUUID().toString(),
    val doe_id: String,
    val delivery_date: String,
    val check_date: String,
    val days_post_delivery: Int,
    val appetite: String = "Normal", // Normal, Poor, Anorexic
    val temperature: Double? = null,
    val milk_production_ltr: Double? = null,
    val complications: String? = null, // Retained placenta, Metritis, Mastitis, Milk fever, Hypocalcemia, Ketosis, Prolapse, Excessive bleeding, Fever, Infection, Weakness, Poor appetite, Milk production problem, Injury, Difficult recovery, Sudden death, None, Other
    val treatment: String? = null,
    val medication: String? = null,
    val vet_visit: Boolean = false,
    val vet_doctor: String? = null,
    val recovery_status: String = "Recovering", // Recovered, Recovering, Critical, Deceased
    val notes: String? = null,
    val created_at: String? = null
)

data class MortalityEvent(
    val id: String = UUID.randomUUID().toString(),
    val goat_id: String,
    val goat_tag: String,
    val event_type: String, // ADULT_DEATH, KID_DEATH, DOE_POST_DELIVERY_DEATH, STILLBIRTH, OTHER
    val death_date: String,
    val death_time: String? = null,
    val age_at_death_days: Int? = null,
    val weight_at_death: Double? = null,
    val delivery_date: String? = null,
    val days_post_delivery: Int? = null,
    val immediate_cause: String,
    val underlying_cause: String? = null,
    val cause_certainty: String = "Suspected", // Confirmed, Suspected, Unknown
    val cause_category: String, // Disease, Accident, Injury, Predator attack, Poisoning/toxicity, Parasites, Digestive problem, Respiratory problem, Reproductive complication, Post-delivery complication, Starvation/malnutrition, Heat stress, Cold stress, Unknown, Other
    val disease_name: String? = null,
    val injury_details: String? = null,
    val treatment_history: String? = null,
    val vet_doctor: String? = null,
    val post_mortem_performed: Boolean = false,
    val post_mortem_report_url: String? = null,
    val photos_urls: String? = null,
    val insurance_policy_id: String? = null,
    val insurance_claim_id: String? = null,
    val notes: String? = null,
    val created_at: String? = null
)

data class FarmMortalitySummary(
    val totalDeaths: Int = 0,
    val adultDeaths: Int = 0,
    val kidDeaths: Int = 0,
    val doeDeaths: Int = 0,
    val buckDeaths: Int = 0,
    val abortionCount: Int = 0,
    val stillbirthCount: Int = 0,
    val postDeliveryDeaths: Int = 0,
    val insuredDeaths: Int = 0,
    val claimsPending: Int = 0,
    val claimsSettled: Int = 0,
    val totalHerdCount: Int = 0,
    val overallMortalityRate: Double = 0.0,
    val kidMortalityRate: Double = 0.0,
    val reproductiveLossRate: Double = 0.0,
    val deathsByMonth: Map<String, Int> = emptyMap(),
    val deathsByCause: Map<String, Int> = emptyMap(),
    val deathsByAgeGroup: Map<String, Int> = emptyMap()
)

data class BreedingPerformanceSummary(
    val totalDoesBred: Int = 0,
    val totalPregnancies: Int = 0,
    val confirmedPregnancies: Int = 0,
    val normalDeliveries: Int = 0,
    val abortions: Int = 0,
    val stillbirths: Int = 0,
    val totalLiveKidsBorn: Int = 0,
    val kidSurvivalCount: Int = 0,
    val postDeliveryComplicationsCount: Int = 0,
    val doeMortalityAfterDeliveryCount: Int = 0,
    val conceptionRate: Double = 0.0,
    val kiddingRate: Double = 0.0,
    val kidSurvivalRate: Double = 0.0
)

// ==============================================================================
// 3. INSURANCE PROVIDER ADAPTER ABSTRACTION
// ==============================================================================

data class InsuranceQuoteRequest(
    val goatId: String,
    val goatTag: String,
    val breed: String,
    val ageMonths: Int,
    val sex: String,
    val marketValue: Double,
    val location: String,
    val ownerName: String
)

data class InsuranceProposalResponse(
    val proposalNumber: String,
    val status: String,
    val message: String
)

data class InsuranceClaimResponse(
    val claimNumber: String,
    val status: String,
    val message: String
)

data class InsuranceClaimStatusResponse(
    val claimNumber: String,
    val status: String,
    val approvedAmount: Double?,
    val settlementDate: String?,
    val remarks: String?
)

interface InsuranceProviderAdapter {
    val providerName: String
    suspend fun isConfigured(): Boolean
    suspend fun getQuote(request: InsuranceQuoteRequest): Result<List<InsuranceQuote>>
    suspend fun createProposal(policy: InsurancePolicy): Result<InsuranceProposalResponse>
    suspend fun uploadDocuments(policyId: String, docType: String, fileBytes: ByteArray, fileName: String): Result<String>
    suspend fun issuePolicy(proposalId: String): Result<InsurancePolicy>
    suspend fun getPolicy(policyNumber: String): Result<InsurancePolicy>
    suspend fun renewPolicy(policyNumber: String, paymentRef: String): Result<InsurancePolicy>
    suspend fun submitClaim(claim: InsuranceClaim): Result<InsuranceClaimResponse>
    suspend fun getClaimStatus(claimNumber: String): Result<InsuranceClaimStatusResponse>
    suspend fun cancelPolicy(policyNumber: String, reason: String): Result<Boolean>
    suspend fun downloadPolicy(policyNumber: String): Result<ByteArray>
}

/**
 * Standard implementation that respects real integration:
 * If an insurer API endpoint is configured, connects via HTTP/REST;
 * otherwise gracefully returns: "Insurance API not configured for this provider."
 * Never fabricates fake policy or claim numbers.
 */
class ConfigurableInsuranceAdapter(
    private val provider: InsuranceProvider
) : InsuranceProviderAdapter {
    override val providerName: String = provider.company_name

    override suspend fun isConfigured(): Boolean {
        return !provider.api_base_url.isNullOrBlank() ||
               (provider.is_sandbox && !provider.sandbox_url.isNullOrBlank()) ||
               (!provider.is_sandbox && !provider.production_url.isNullOrBlank())
    }

    override suspend fun getQuote(request: InsuranceQuoteRequest): Result<List<InsuranceQuote>> {
        if (!isConfigured()) {
            return Result.failure(IllegalStateException("Insurance API not configured for this provider."))
        }
        // In live mode with real API credentials, calls remote insurer quote endpoint.
        return Result.failure(IllegalStateException("Live insurance quote API integration requires active insurer credentials."))
    }

    override suspend fun createProposal(policy: InsurancePolicy): Result<InsuranceProposalResponse> {
        if (!isConfigured()) {
            return Result.failure(IllegalStateException("Insurance API not configured for this provider."))
        }
        return Result.failure(IllegalStateException("Live insurance proposal API requires active insurer credentials."))
    }

    override suspend fun uploadDocuments(policyId: String, docType: String, fileBytes: ByteArray, fileName: String): Result<String> {
        if (!isConfigured()) {
            return Result.failure(IllegalStateException("Insurance API not configured for this provider."))
        }
        return Result.failure(IllegalStateException("Live document upload API requires active insurer credentials."))
    }

    override suspend fun issuePolicy(proposalId: String): Result<InsurancePolicy> {
        if (!isConfigured()) {
            return Result.failure(IllegalStateException("Insurance API not configured for this provider."))
        }
        return Result.failure(IllegalStateException("Live policy issuance API requires active insurer credentials."))
    }

    override suspend fun getPolicy(policyNumber: String): Result<InsurancePolicy> {
        if (!isConfigured()) {
            return Result.failure(IllegalStateException("Insurance API not configured for this provider."))
        }
        return Result.failure(IllegalStateException("Live get policy API requires active insurer credentials."))
    }

    override suspend fun renewPolicy(policyNumber: String, paymentRef: String): Result<InsurancePolicy> {
        if (!isConfigured()) {
            return Result.failure(IllegalStateException("Insurance API not configured for this provider."))
        }
        return Result.failure(IllegalStateException("Live policy renewal API requires active insurer credentials."))
    }

    override suspend fun submitClaim(claim: InsuranceClaim): Result<InsuranceClaimResponse> {
        if (!isConfigured()) {
            return Result.failure(IllegalStateException("Insurance API not configured for this provider."))
        }
        return Result.failure(IllegalStateException("Live claim submission API requires active insurer credentials."))
    }

    override suspend fun getClaimStatus(claimNumber: String): Result<InsuranceClaimStatusResponse> {
        if (!isConfigured()) {
            return Result.failure(IllegalStateException("Insurance API not configured for this provider."))
        }
        return Result.failure(IllegalStateException("Live claim status API requires active insurer credentials."))
    }

    override suspend fun cancelPolicy(policyNumber: String, reason: String): Result<Boolean> {
        if (!isConfigured()) {
            return Result.failure(IllegalStateException("Insurance API not configured for this provider."))
        }
        return Result.failure(IllegalStateException("Live policy cancellation API requires active insurer credentials."))
    }

    override suspend fun downloadPolicy(policyNumber: String): Result<ByteArray> {
        if (!isConfigured()) {
            return Result.failure(IllegalStateException("Insurance API not configured for this provider."))
        }
        return Result.failure(IllegalStateException("Live policy download API requires active insurer credentials."))
    }
}
