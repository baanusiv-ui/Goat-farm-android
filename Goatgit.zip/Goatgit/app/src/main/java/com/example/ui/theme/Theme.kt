package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme =
  darkColorScheme(
    primary = FarmGreenLight,
    onPrimary = FarmOnGreenContainer,
    primaryContainer = FarmGreenDark,
    onPrimaryContainer = FarmGreenContainer,
    secondary = FarmAmber,
    onSecondary = Color.Black,
    secondaryContainer = FarmBrown,
    onSecondaryContainer = FarmAmberContainer,
    background = FarmBackgroundDark,
    onBackground = TextPrimaryDark,
    surface = FarmSurfaceDark,
    onSurface = TextPrimaryDark,
    surfaceVariant = FarmCardDark,
    onSurfaceVariant = TextSecondaryDark,
    error = FarmError,
    errorContainer = FarmErrorContainer
  )

private val LightColorScheme =
  lightColorScheme(
    primary = FarmGreenPrimary,
    onPrimary = Color.White,
    primaryContainer = FarmGreenContainer,
    onPrimaryContainer = FarmOnGreenContainer,
    secondary = FarmAmber,
    onSecondary = Color.Black,
    secondaryContainer = FarmAmberContainer,
    onSecondaryContainer = FarmBrown,
    background = FarmBackgroundLight,
    onBackground = TextPrimaryLight,
    surface = FarmSurfaceLight,
    onSurface = TextPrimaryLight,
    surfaceVariant = FarmCardLight,
    onSurfaceVariant = TextSecondaryLight,
    error = FarmError,
    errorContainer = FarmErrorContainer
  )

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  dynamicColor: Boolean = false, // Use our brand farm colors for distinct agricultural identity
  content: @Composable () -> Unit,
) {
  val colorScheme =
    when {
      dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
        val context = LocalContext.current
        if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
      }
      darkTheme -> DarkColorScheme
      else -> LightColorScheme
    }

  MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}

