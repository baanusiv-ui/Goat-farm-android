package com.example.notification

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.example.MainActivity
import com.example.R
import com.example.data.offline.AppDatabase
import com.example.data.offline.FarmSettingEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.TimeUnit

class KiddingNotificationWorker(
    appContext: Context,
    workerParams: WorkerParameters
) : CoroutineWorker(appContext, workerParams) {

    companion object {
        const val TAG = "KiddingWorker"
        const val CHANNEL_ID = "goat_kidding_reminders"
        const val CHANNEL_NAME = "Goat Kidding & Delivery Alerts"
        const val NOTIFICATION_BASE_ID = 8100
        const val SUMMARY_NOTIFICATION_ID = 8099
    }

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        Log.d(TAG, "Starting recurring check for expected kidding dates and delivery alerts...")
        val context = applicationContext
        val database = AppDatabase.getDatabase(context)

        try {
            createNotificationChannel(context)

            // Check if user disabled kidding notifications
            val enabledSetting = database.farmSettingsDao().getSetting("kidding_notifications_enabled")?.value_c
            if (enabledSetting == "false") {
                Log.d(TAG, "Kidding notifications are disabled by user in settings. Skipping.")
                return@withContext Result.success()
            }

            val goats = database.goatDao().getAllGoats().associateBy { it.id }
            val pregnancies = database.breedingDao().getAllPregnancies()
            val breedingRecords = database.breedingRecordDao().getAllBreedingRecords()

            val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
            val today = Date()
            val cal = Calendar.getInstance().apply {
                time = today
                set(Calendar.HOUR_OF_DAY, 0)
                set(Calendar.MINUTE, 0)
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
            }
            val todayStart = cal.time

            val alerts = mutableListOf<KiddingAlertItem>()
            val processedDoeIds = mutableSetOf<String>()

            // 1. Check local_breeding_records (active records with 150-day calculated expected kidding date)
            for (breed in breedingRecords) {
                if (breed.status.equals("Kidded", ignoreCase = true) ||
                    breed.status.equals("Failed", ignoreCase = true) ||
                    breed.status.equals("Aborted", ignoreCase = true)
                ) {
                    continue
                }

                val expDateStr = breed.expected_kidding_date.trim()
                if (expDateStr.isBlank()) continue

                val expDate = try {
                    sdf.parse(expDateStr)
                } catch (_: Exception) {
                    null
                } ?: continue

                val diffMillis = expDate.time - todayStart.time
                val diffDays = TimeUnit.MILLISECONDS.toDays(diffMillis)

                val doe = goats[breed.doe_id]
                val buck = goats[breed.buck_id]
                val doeTag = doe?.tag_c ?: "Doe #${breed.doe_id.take(4)}"
                val doeName = doe?.name?.ifBlank { "Doe" } ?: "Doe"
                val buckTag = buck?.tag_c

                val stageAndDetails = evaluateKiddingStage(diffDays, doeTag, expDateStr, buckTag)
                if (stageAndDetails != null) {
                    alerts.add(
                        KiddingAlertItem(
                            id = "breed_${breed.id}",
                            recordId = breed.id,
                            recordType = "BreedingRecord",
                            doeId = breed.doe_id,
                            doeTag = doeTag,
                            doeName = doeName,
                            sireTag = buckTag,
                            expectedKiddingDate = expDateStr,
                            diffDays = diffDays,
                            stage = stageAndDetails.first,
                            title = stageAndDetails.second,
                            message = stageAndDetails.third,
                            actionRecommendation = stageAndDetails.fourth
                        )
                    )
                    processedDoeIds.add(breed.doe_id)
                }
            }

            // 2. Check local_pregnancies (confirmed pregnancies)
            for (preg in pregnancies) {
                // If this doe was already alerted from breeding records, skip duplicate
                if (processedDoeIds.contains(preg.doe_id_c)) continue

                if (!preg.status_c.equals("Confirmed", ignoreCase = true) &&
                    !preg.status_c.equals("Suspected", ignoreCase = true)
                ) {
                    continue
                }

                // If actual kidding already occurred, skip
                if (!preg.actual_kidding_date_c.isNullOrBlank()) continue

                val expDateStr = preg.expected_kidding_date_c.trim()
                if (expDateStr.isBlank()) continue

                val expDate = try {
                    sdf.parse(expDateStr)
                } catch (_: Exception) {
                    null
                } ?: continue

                val diffMillis = expDate.time - todayStart.time
                val diffDays = TimeUnit.MILLISECONDS.toDays(diffMillis)

                val doe = goats[preg.doe_id_c]
                val doeTag = doe?.tag_c ?: "Doe #${preg.doe_id_c.take(4)}"
                val doeName = doe?.name?.ifBlank { "Doe" } ?: "Doe"

                val stageAndDetails = evaluateKiddingStage(diffDays, doeTag, expDateStr, null)
                if (stageAndDetails != null) {
                    alerts.add(
                        KiddingAlertItem(
                            id = "preg_${preg.id}",
                            recordId = preg.id,
                            recordType = "Pregnancy",
                            doeId = preg.doe_id_c,
                            doeTag = doeTag,
                            doeName = doeName,
                            sireTag = null,
                            expectedKiddingDate = expDateStr,
                            diffDays = diffDays,
                            stage = stageAndDetails.first,
                            title = stageAndDetails.second,
                            message = stageAndDetails.third,
                            actionRecommendation = stageAndDetails.fourth
                        )
                    )
                }
            }

            Log.d(TAG, "Found ${alerts.size} active kidding delivery alerts.")

            // Send local device notifications if alerts found
            if (alerts.isNotEmpty()) {
                sendKiddingNotifications(context, alerts)
            }

            // Record check time & alert count in farm settings
            val nowTime = System.currentTimeMillis().toString()
            database.farmSettingsDao().saveSetting(FarmSettingEntity("last_kidding_check_time", nowTime))
            database.farmSettingsDao().saveSetting(FarmSettingEntity("last_kidding_alert_count", alerts.size.toString()))

            // Save JSON summary of recent alerts for in-app history
            val alertJsonArr = JSONArray()
            for (a in alerts.take(10)) {
                val obj = JSONObject().apply {
                    put("doeTag", a.doeTag)
                    put("doeName", a.doeName)
                    put("expectedDate", a.expectedKiddingDate)
                    put("diffDays", a.diffDays)
                    put("stage", a.stage.name)
                    put("title", a.title)
                    put("message", a.message)
                    put("action", a.actionRecommendation)
                }
                alertJsonArr.put(obj)
            }
            database.farmSettingsDao().saveSetting(FarmSettingEntity("recent_kidding_alerts_json", alertJsonArr.toString()))

            Result.success()
        } catch (e: Exception) {
            Log.e(TAG, "Error checking upcoming kidding reminders: ${e.message}", e)
            Result.retry()
        }
    }

    private fun evaluateKiddingStage(
        diffDays: Long,
        doeTag: String,
        expectedDateStr: String,
        sireTag: String?
    ): Quadruple<KiddingAlertStage, String, String, String>? {
        val sireInfo = if (!sireTag.isNullOrBlank()) " (Sire: #$sireTag)" else ""

        return when {
            // Overdue by 1 to 7 days
            diffDays in -7..-1 -> {
                val overdueDays = -diffDays
                Quadruple(
                    KiddingAlertStage.OVERDUE,
                    "🚨 OVERDUE: Doe #$doeTag is $overdueDays day(s) overdue!",
                    "Expected delivery was on $expectedDateStr$sireInfo. Check doe immediately for labor distress, uterine inertia, or abnormal discharge.",
                    "Check tailhead ligaments & prepare for vet consultation if labor does not advance."
                )
            }
            // Due Today
            diffDays == 0L -> {
                Quadruple(
                    KiddingAlertStage.DUE_TODAY,
                    "🐐 KIDDING DUE TODAY: Doe #$doeTag",
                    "Expected delivery is TODAY ($expectedDateStr)$sireInfo. Monitor doe for pawing, nesting, and loss of pelvic ligaments.",
                    "Ensure clean kidding stall, iodine navel dip, and warm dry towels are ready."
                )
            }
            // Due Tomorrow (1 day remaining)
            diffDays == 1L -> {
                Quadruple(
                    KiddingAlertStage.DUE_TOMORROW,
                    "⚠️ Kidding Tomorrow: Doe #$doeTag due in 24h",
                    "Calculated kidding date is tomorrow ($expectedDateStr)$sireInfo. Udder may be strutted and shiny.",
                    "Move doe to individual sanitized kidding pen and provide fresh warm water."
                )
            }
            // Due within 2 to 3 days
            diffDays in 2..3 -> {
                Quadruple(
                    KiddingAlertStage.DUE_IN_3_DAYS,
                    "🔔 Kidding in $diffDays Days: Doe #$doeTag",
                    "Delivery expected on $expectedDateStr (in $diffDays days)$sireInfo. Tailhead ligaments softening.",
                    "Inspect kidding kit: bulb syringe, lubricant, 7% iodine dip, dental floss/clamps."
                )
            }
            // Due within 4 to 7 days
            diffDays in 4..7 -> {
                Quadruple(
                    KiddingAlertStage.DUE_IN_7_DAYS,
                    "📅 Kidding in 1 Week: Doe #$doeTag ($expectedDateStr)",
                    "Expected kidding in $diffDays days based on standard 150-day gestation$sireInfo.",
                    "Separate from active herd into maternity pen with dry straw bedding."
                )
            }
            // CD&T Booster window (21 to 28 days prior to delivery)
            diffDays in 21..28 -> {
                Quadruple(
                    KiddingAlertStage.CDT_BOOSTER,
                    "💉 Pre-Kidding CD&T Booster Due: Doe #$doeTag",
                    "Kidding expected in $diffDays days ($expectedDateStr). Administer CD&T toxoid booster 3-4 weeks prior to kidding.",
                    "Ensures high levels of protective clostridial antibodies passed through colostrum to newborns."
                )
            }
            else -> null
        }
    }

    private fun sendKiddingNotifications(context: Context, alerts: List<KiddingAlertItem>) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val permission = ContextCompat.checkSelfPermission(context, android.Manifest.permission.POST_NOTIFICATIONS)
            if (permission != PackageManager.PERMISSION_GRANTED) {
                Log.w(TAG, "POST_NOTIFICATIONS permission not granted. Cannot display local device alerts.")
                return
            }
        }

        val notificationManager = NotificationManagerCompat.from(context)

        // Intent to open Breeding management screen directly
        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            putExtra("navigate_to", "breeding")
        }
        val pendingIntent = PendingIntent.getActivity(
            context,
            2001,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // For individual urgent alerts (Due Today, Tomorrow, or Overdue), dispatch individual high-priority notifications
        val urgentAlerts = alerts.filter { it.stage == KiddingAlertStage.OVERDUE || it.stage == KiddingAlertStage.DUE_TODAY || it.stage == KiddingAlertStage.DUE_TOMORROW }

        for ((idx, alert) in urgentAlerts.take(3).withIndex()) {
            val bigTextStyle = NotificationCompat.BigTextStyle()
                .setBigContentTitle(alert.title)
                .bigText("${alert.message}\n\n👉 Recommendation: ${alert.actionRecommendation}")
                .setSummaryText("Expected Kidding: ${alert.expectedKiddingDate}")

            val notification = NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(R.mipmap.ic_launcher)
                .setContentTitle(alert.title)
                .setContentText(alert.message)
                .setStyle(bigTextStyle)
                .setPriority(NotificationCompat.PRIORITY_MAX)
                .setCategory(NotificationCompat.CATEGORY_ALARM)
                .setAutoCancel(true)
                .setContentIntent(pendingIntent)
                .addAction(
                    android.R.drawable.ic_menu_today,
                    "Open Breeding",
                    pendingIntent
                )
                .build()

            try {
                notificationManager.notify(NOTIFICATION_BASE_ID + idx, notification)
            } catch (e: SecurityException) {
                Log.e(TAG, "SecurityException sending kidding notification: ${e.message}")
            }
        }

        // Summary notification if multiple does have alerts
        if (alerts.size > 1) {
            val dueTodayCount = alerts.count { it.stage == KiddingAlertStage.DUE_TODAY }
            val overdueCount = alerts.count { it.stage == KiddingAlertStage.OVERDUE }
            val upcomingWeekCount = alerts.count { it.stage == KiddingAlertStage.DUE_TOMORROW || it.stage == KiddingAlertStage.DUE_IN_3_DAYS || it.stage == KiddingAlertStage.DUE_IN_7_DAYS }

            val summaryTitle = "${alerts.size} Does with Kidding Alerts"
            val summaryText = buildString {
                if (dueTodayCount > 0) append("$dueTodayCount DUE TODAY, ")
                if (overdueCount > 0) append("$overdueCount OVERDUE, ")
                append("$upcomingWeekCount upcoming this week.")
            }

            val inboxStyle = NotificationCompat.InboxStyle()
                .setBigContentTitle(summaryTitle)
                .setSummaryText("Breeding & Gestation Alert System")

            for (a in alerts.take(6)) {
                val label = when (a.stage) {
                    KiddingAlertStage.OVERDUE -> "🚨 OVERDUE (${-a.diffDays}d)"
                    KiddingAlertStage.DUE_TODAY -> "🐐 DUE TODAY"
                    KiddingAlertStage.DUE_TOMORROW -> "⚠️ TOMORROW"
                    KiddingAlertStage.DUE_IN_3_DAYS -> "🔔 in ${a.diffDays}d"
                    KiddingAlertStage.DUE_IN_7_DAYS -> "📅 in ${a.diffDays}d"
                    KiddingAlertStage.CDT_BOOSTER -> "💉 CD&T in ${a.diffDays}d"
                    else -> "in ${a.diffDays}d"
                }
                inboxStyle.addLine("${a.doeTag}: $label (${a.expectedKiddingDate})")
            }

            val summaryNotification = NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(R.mipmap.ic_launcher)
                .setContentTitle(summaryTitle)
                .setContentText(summaryText)
                .setStyle(inboxStyle)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true)
                .setContentIntent(pendingIntent)
                .build()

            try {
                notificationManager.notify(SUMMARY_NOTIFICATION_ID, summaryNotification)
            } catch (e: SecurityException) {
                Log.e(TAG, "SecurityException sending summary kidding notification: ${e.message}")
            }
        } else if (urgentAlerts.isEmpty() && alerts.isNotEmpty()) {
            // Only 1 non-urgent alert (e.g. 7 days or CD&T booster)
            val alert = alerts.first()
            val bigTextStyle = NotificationCompat.BigTextStyle()
                .setBigContentTitle(alert.title)
                .bigText("${alert.message}\n\n👉 Recommendation: ${alert.actionRecommendation}")
                .setSummaryText("Expected: ${alert.expectedKiddingDate}")

            val notification = NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(R.mipmap.ic_launcher)
                .setContentTitle(alert.title)
                .setContentText(alert.message)
                .setStyle(bigTextStyle)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true)
                .setContentIntent(pendingIntent)
                .build()

            try {
                notificationManager.notify(NOTIFICATION_BASE_ID, notification)
            } catch (e: SecurityException) {
                Log.e(TAG, "SecurityException sending single kidding notification: ${e.message}")
            }
        }
    }

    private fun createNotificationChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                CHANNEL_NAME,
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Timely alerts for expected goat delivery dates, 150-day gestation milestones, and kidding pen preparations."
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 400, 200, 400)
                setShowBadge(true)
            }
            val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
            manager?.createNotificationChannel(channel)
        }
    }
}

private data class Quadruple<A, B, C, D>(
    val first: A,
    val second: B,
    val third: C,
    val fourth: D
)
