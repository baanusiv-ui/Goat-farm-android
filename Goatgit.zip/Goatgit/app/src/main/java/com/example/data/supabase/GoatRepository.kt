package com.example.data.supabase

import com.example.data.offline.*
import com.example.data.pedigree.PedigreeManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID
import java.util.concurrent.TimeUnit

class GoatRepository(
    private val client: SupabaseClient,
    val database: AppDatabase,
    val syncManager: OfflineSyncManager,
    val backupManager: com.example.data.backup.BackupManager
) {
    val finance: FinanceRepository = FinanceRepository(client, database, syncManager)
    val insurance: InsuranceAndMortalityRepository = InsuranceAndMortalityRepository(client, database, syncManager, finance)
    val supabaseGoatRepository: SupabaseGoatRepository by lazy {
        SupabaseGoatRepository(client, database, syncManager)
    }
    val realtimeStatus: kotlinx.coroutines.flow.StateFlow<RealtimeStatus>
        get() = supabaseGoatRepository.realtimeStatus

    fun startRealtimeSync() = supabaseGoatRepository.startRealtimeSync()
    fun stopRealtimeSync() = supabaseGoatRepository.stopRealtimeSync()
    suspend fun syncRealtimeGoats() = supabaseGoatRepository.syncGoats()

    val farmProfileManager: com.example.data.farm.FarmProfileManager by lazy {
        com.example.data.farm.FarmProfileManager.getInstance(syncManager.context, database)
    }
    private val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.US)

    private fun JSONObject.optNullableString(key: String): String? =
        if (has(key) && !isNull(key) && optString(key).isNotBlank()) optString(key) else null

    // ==========================================
    // GOATS / HERD
    // ==========================================

    fun getLocalGoatsFlow(): Flow<List<Goat>> =
        database.goatDao().getAllGoatsFlow().map { list -> list.map { it.toDomain() } }

    suspend fun getLocalGoats(): List<Goat> = withContext(Dispatchers.IO) {
        database.goatDao().getAllGoats().map { it.toDomain() }
    }

    suspend fun getGoats(): Result<List<Goat>> = withContext(Dispatchers.IO) {
        try {
            val localList = database.goatDao().getAllGoats()
            if (localList.isNotEmpty()) {
                val goats = localList.map { it.toDomain() }
                return@withContext Result.success(goats)
            }

            // If local cache is empty, download from Supabase
            val res = client.get("goats_c", "select=*&order=created_at.desc")
            if (res.isSuccess) {
                val arr = res.getOrThrow()
                val list = mutableListOf<GoatEntity>()
                for (i in 0 until arr.length()) {
                    val obj = arr.getJSONObject(i)
                    list.add(parseGoatEntity(obj))
                }
                database.goatDao().insertAll(list)
                Result.success(list.map { it.toDomain() })
            } else {
                Result.success(emptyList())
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun addGoat(goat: Goat): Result<Goat> = withContext(Dispatchers.IO) {
        try {
            // 1. Save immediately to local database
            val entity = goat.toEntity(isSynced = false)
            database.goatDao().insertOrUpdate(entity)

            // 2. Enqueue sync operation
            val json = JSONObject().apply {
                put("id", goat.id)
                put("name", goat.name)
                put("tag_c", goat.tag_c)
                put("breed_c", goat.breed_c)
                put("sex_c", goat.sex_c)
                put("status_c", goat.status_c)
                if (!goat.birth_date_c.isNullOrBlank()) put("birth_date_c", goat.birth_date_c)
                if (goat.weight_kg_c != null) put("weight_kg_c", goat.weight_kg_c)
                if (!goat.dam_c.isNullOrBlank()) put("dam_c", goat.dam_c)
                if (!goat.sire_c.isNullOrBlank()) put("sire_c", goat.sire_c)
                if (!goat.source_c.isNullOrBlank()) put("source_c", goat.source_c)
                if (!goat.purchase_date_c.isNullOrBlank()) put("purchase_date_c", goat.purchase_date_c)
                if (goat.purchase_cost_c != null) put("purchase_cost_c", goat.purchase_cost_c)
                if (!goat.farm_location_c.isNullOrBlank()) put("farm_location_c", goat.farm_location_c)
                if (!goat.color_c.isNullOrBlank()) put("color_c", goat.color_c)
                if (!goat.notes_c.isNullOrBlank()) put("notes_c", goat.notes_c)
                put("origin_c", goat.effectiveOrigin)
            }
            syncManager.enqueueOperation("goats_c", goat.id, "CREATE", json)

            Result.success(goat)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun updateGoat(goat: Goat): Result<Goat> = withContext(Dispatchers.IO) {
        try {
            val entity = goat.toEntity(isSynced = false)
            database.goatDao().insertOrUpdate(entity)

            val json = JSONObject().apply {
                put("name", goat.name)
                put("tag_c", goat.tag_c)
                put("breed_c", goat.breed_c)
                put("sex_c", goat.sex_c)
                put("status_c", goat.status_c)
                if (!goat.birth_date_c.isNullOrBlank()) put("birth_date_c", goat.birth_date_c)
                if (goat.weight_kg_c != null) put("weight_kg_c", goat.weight_kg_c)
                if (!goat.dam_c.isNullOrBlank()) put("dam_c", goat.dam_c)
                if (!goat.sire_c.isNullOrBlank()) put("sire_c", goat.sire_c)
                if (!goat.source_c.isNullOrBlank()) put("source_c", goat.source_c)
                if (!goat.purchase_date_c.isNullOrBlank()) put("purchase_date_c", goat.purchase_date_c)
                if (goat.purchase_cost_c != null) put("purchase_cost_c", goat.purchase_cost_c)
                if (!goat.farm_location_c.isNullOrBlank()) put("farm_location_c", goat.farm_location_c)
                if (!goat.color_c.isNullOrBlank()) put("color_c", goat.color_c)
                if (!goat.notes_c.isNullOrBlank()) put("notes_c", goat.notes_c)
                put("origin_c", goat.effectiveOrigin)
            }
            syncManager.enqueueOperation("goats_c", goat.id, "UPDATE", json)

            Result.success(goat)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // ==========================================
    // HEALTH & WEIGHTS
    // ==========================================

    suspend fun recordWeight(weight: GoatWeight): Result<GoatWeight> = withContext(Dispatchers.IO) {
        try {
            // 1. Save weight locally
            val entity = GoatWeightEntity(
                id = weight.id,
                goat_id_c = weight.goat_id_c,
                weight_kg_c = weight.weight_kg_c,
                date_c = weight.date_c,
                method_c = weight.method_c,
                notes_c = weight.notes_c,
                updated_at = weight.timestamp,
                is_synced = false
            )
            database.healthDao().insertWeight(entity)

            // 2. Update goat's weight_kg_c in local database immediately
            database.goatDao().updateWeight(weight.goat_id_c, weight.weight_kg_c)

            // 3. Queue weight insertion
            val jsonWeight = JSONObject().apply {
                put("id", weight.id)
                put("goat_id_c", weight.goat_id_c)
                put("weight_kg_c", weight.weight_kg_c)
                put("date_c", weight.date_c)
                put("method_c", weight.method_c)
                if (!weight.notes_c.isNullOrBlank()) put("notes_c", weight.notes_c)
                put("updated_at", weight.timestamp)
            }
            syncManager.enqueueOperation("goat_weights_c", weight.id, "CREATE", jsonWeight)

            // 4. Queue goat's weight update
            val updateGoatJson = JSONObject().apply {
                put("weight_kg_c", weight.weight_kg_c)
            }
            syncManager.enqueueOperation("goats_c", weight.goat_id_c, "UPDATE", updateGoatJson)

            Result.success(weight)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getWeights(goatId: String): Result<List<GoatWeight>> = withContext(Dispatchers.IO) {
        try {
            val list = database.healthDao().getWeightsByGoat(goatId).map {
                GoatWeight(
                    id = it.id,
                    goat_id_c = it.goat_id_c,
                    weight_kg_c = it.weight_kg_c,
                    date_c = it.date_c,
                    method_c = it.method_c,
                    notes_c = it.notes_c,
                    timestamp = it.updated_at
                )
            }
            Result.success(list)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun getAllWeightsFlow(): Flow<List<GoatWeight>> {
        return database.healthDao().getAllWeightsFlow().map { list ->
            list.map {
                GoatWeight(
                    id = it.id,
                    goat_id_c = it.goat_id_c,
                    weight_kg_c = it.weight_kg_c,
                    date_c = it.date_c,
                    method_c = it.method_c,
                    notes_c = it.notes_c,
                    timestamp = it.updated_at
                )
            }
        }
    }

    fun getWeightsByGoatFlow(goatId: String): Flow<List<GoatWeight>> {
        return database.healthDao().getWeightsByGoatFlow(goatId).map { list ->
            list.map {
                GoatWeight(
                    id = it.id,
                    goat_id_c = it.goat_id_c,
                    weight_kg_c = it.weight_kg_c,
                    date_c = it.date_c,
                    method_c = it.method_c,
                    notes_c = it.notes_c,
                    timestamp = it.updated_at
                )
            }
        }
    }

    suspend fun getAllWeights(): Result<List<GoatWeight>> = withContext(Dispatchers.IO) {
        try {
            val list = database.healthDao().getAllWeights().map {
                GoatWeight(
                    id = it.id,
                    goat_id_c = it.goat_id_c,
                    weight_kg_c = it.weight_kg_c,
                    date_c = it.date_c,
                    method_c = it.method_c,
                    notes_c = it.notes_c,
                    timestamp = it.updated_at
                )
            }
            Result.success(list)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun getGoatWithWeightHistoryFlow(goatId: String): Flow<GoatWithWeightHistory?> {
        return database.goatDao().getGoatWithWeightHistoryFlow(goatId)
    }

    suspend fun getGoatWithWeightHistory(goatId: String): Result<GoatWithWeightHistory?> = withContext(Dispatchers.IO) {
        try {
            val data = database.goatDao().getGoatWithWeightHistory(goatId)
            Result.success(data)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun updateGoatProfileDetails(
        goatId: String,
        name: String,
        tag: String,
        breed: String,
        sex: String,
        status: String,
        birthDate: String?,
        color: String?,
        dam: String?,
        sire: String?,
        notes: String?
    ): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            database.goatDao().updateGoatProfile(
                id = goatId,
                name = name,
                tag = tag,
                breed = breed,
                sex = sex,
                status = status,
                birthDate = birthDate,
                color = color,
                dam = dam,
                sire = sire,
                notes = notes
            )
            val json = JSONObject().apply {
                put("name", name)
                put("tag_c", tag)
                put("breed_c", breed)
                put("sex_c", sex)
                put("status_c", status)
                if (!birthDate.isNullOrBlank()) put("birth_date_c", birthDate)
                if (!color.isNullOrBlank()) put("color_c", color)
                if (!dam.isNullOrBlank()) put("dam_c", dam)
                if (!sire.isNullOrBlank()) put("sire_c", sire)
                if (!notes.isNullOrBlank()) put("notes_c", notes)
            }
            syncManager.enqueueOperation("goats_c", goatId, "UPDATE", json)
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun updateGoatProfilePhoto(goatId: String, photoUri: String?): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            database.goatDao().updateGoatPhoto(goatId, photoUri)
            val json = JSONObject().apply {
                if (photoUri != null) put("photo_url_c", photoUri) else put("photo_url_c", JSONObject.NULL)
            }
            syncManager.enqueueOperation("goats_c", goatId, "UPDATE", json)
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun saveGoatPhotoRecord(
        goatId: String,
        photoUri: String,
        title: String? = null,
        category: String = "Identification",
        notes: String? = null,
        isPrimary: Boolean = false
    ): Result<com.example.data.offline.GoatPhotoEntity> = withContext(Dispatchers.IO) {
        try {
            val dateStr = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(java.util.Date())
            val entity = com.example.data.offline.GoatPhotoEntity(
                goat_id_c = goatId,
                photo_uri_c = photoUri,
                title_c = title,
                category_c = category,
                notes_c = notes,
                date_taken_c = dateStr,
                is_primary_c = isPrimary
            )
            if (isPrimary) {
                database.goatPhotoDao().clearPrimaryPhotos(goatId)
                database.goatDao().updateGoatPhoto(goatId, photoUri)
                syncManager.enqueueOperation("goats_c", goatId, "UPDATE", JSONObject().put("photo_url_c", photoUri))
            }
            database.goatPhotoDao().insertPhoto(entity)
            Result.success(entity)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun getGoatPhotosFlow(goatId: String): kotlinx.coroutines.flow.Flow<List<com.example.data.offline.GoatPhotoEntity>> {
        return database.goatPhotoDao().getPhotosForGoatFlow(goatId)
    }

    suspend fun getGoatPhotos(goatId: String): List<com.example.data.offline.GoatPhotoEntity> = withContext(Dispatchers.IO) {
        database.goatPhotoDao().getPhotosForGoat(goatId)
    }

    suspend fun deleteGoatPhoto(photoId: String, goatId: String): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            database.goatPhotoDao().deletePhotoById(photoId)
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun setPrimaryGoatPhoto(goatId: String, photoId: String, photoUri: String): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            database.goatPhotoDao().clearPrimaryPhotos(goatId)
            database.goatPhotoDao().setPrimaryPhoto(photoId)
            database.goatDao().updateGoatPhoto(goatId, photoUri)
            syncManager.enqueueOperation("goats_c", goatId, "UPDATE", JSONObject().put("photo_url_c", photoUri))
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun deleteWeightRecord(weightId: String, goatId: String): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            database.healthDao().deleteWeightById(weightId)
            syncManager.enqueueOperation("goat_weights_c", weightId, "DELETE", JSONObject().put("id", weightId))

            // Update goat's latest weight from remaining weights
            val latest = database.healthDao().getLatestWeightForGoat(goatId)
            val newWeight = latest?.weight_kg_c ?: 0.0
            database.goatDao().updateWeight(goatId, newWeight)
            syncManager.enqueueOperation("goats_c", goatId, "UPDATE", JSONObject().put("weight_kg_c", newWeight))
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun recordVaccination(vac: VaccinationRecord): Result<VaccinationRecord> = withContext(Dispatchers.IO) {
        try {
            val entity = VaccinationEntity(
                id = vac.id,
                goat_id_c = vac.goat_id_c,
                vaccine_c = vac.vaccine_c,
                dose_c = vac.dose_c,
                administered_date_c = vac.administered_date_c,
                next_due_date_c = vac.next_due_date_c,
                batch_number_c = vac.batch_number_c,
                administered_by_c = vac.administered_by_c,
                notes_c = vac.notes_c,
                is_synced = false
            )
            database.healthDao().insertVaccination(entity)

            val json = JSONObject().apply {
                put("id", vac.id)
                put("goat_id_c", vac.goat_id_c)
                put("vaccine_c", vac.vaccine_c)
                put("dose_c", vac.dose_c)
                put("administered_date_c", vac.administered_date_c)
                if (!vac.next_due_date_c.isNullOrBlank()) put("next_due_date_c", vac.next_due_date_c)
                if (!vac.batch_number_c.isNullOrBlank()) put("batch_number_c", vac.batch_number_c)
                if (!vac.administered_by_c.isNullOrBlank()) put("administered_by_c", vac.administered_by_c)
                if (!vac.notes_c.isNullOrBlank()) put("notes_c", vac.notes_c)
            }
            syncManager.enqueueOperation("vaccinations_c", vac.id, "CREATE", json)

            Result.success(vac)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getVaccinations(goatId: String? = null): Result<List<VaccinationRecord>> = withContext(Dispatchers.IO) {
        try {
            val entities = if (goatId != null) database.healthDao().getVaccinationsByGoat(goatId) else database.healthDao().getAllVaccinations()
            val list = entities.map {
                VaccinationRecord(
                    id = it.id,
                    goat_id_c = it.goat_id_c,
                    vaccine_c = it.vaccine_c,
                    dose_c = it.dose_c,
                    administered_date_c = it.administered_date_c,
                    next_due_date_c = it.next_due_date_c,
                    batch_number_c = it.batch_number_c,
                    administered_by_c = it.administered_by_c,
                    notes_c = it.notes_c
                )
            }
            Result.success(list)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun recordDeworming(deworm: DewormingRecord): Result<DewormingRecord> = withContext(Dispatchers.IO) {
        try {
            val entity = DewormingEntity(
                id = deworm.id,
                goat_id_c = deworm.goat_id_c,
                medicine_c = deworm.medicine_c,
                dose_c = deworm.dose_c,
                treatment_date_c = deworm.treatment_date_c,
                next_due_date_c = deworm.next_due_date_c,
                weight_at_treatment_c = deworm.weight_at_treatment_c,
                administered_by_c = deworm.administered_by_c,
                notes_c = deworm.notes_c,
                is_synced = false
            )
            database.healthDao().insertDeworming(entity)

            val json = JSONObject().apply {
                put("id", deworm.id)
                put("goat_id_c", deworm.goat_id_c)
                put("medicine_c", deworm.medicine_c)
                put("dose_c", deworm.dose_c)
                put("treatment_date_c", deworm.treatment_date_c)
                if (!deworm.next_due_date_c.isNullOrBlank()) put("next_due_date_c", deworm.next_due_date_c)
                if (deworm.weight_at_treatment_c != null) put("weight_at_treatment_c", deworm.weight_at_treatment_c)
                if (!deworm.administered_by_c.isNullOrBlank()) put("administered_by_c", deworm.administered_by_c)
                if (!deworm.notes_c.isNullOrBlank()) put("notes_c", deworm.notes_c)
            }
            syncManager.enqueueOperation("deworming_records_c", deworm.id, "CREATE", json)

            Result.success(deworm)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getDewormings(goatId: String? = null): Result<List<DewormingRecord>> = withContext(Dispatchers.IO) {
        try {
            val entities = if (goatId != null) database.healthDao().getDewormingsByGoat(goatId) else database.healthDao().getAllDewormings()
            val list = entities.map {
                DewormingRecord(
                    id = it.id,
                    goat_id_c = it.goat_id_c,
                    medicine_c = it.medicine_c,
                    dose_c = it.dose_c,
                    treatment_date_c = it.treatment_date_c,
                    next_due_date_c = it.next_due_date_c,
                    weight_at_treatment_c = it.weight_at_treatment_c,
                    administered_by_c = it.administered_by_c,
                    notes_c = it.notes_c
                )
            }
            Result.success(list)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun recordTreatment(treatment: TreatmentRecord): Result<TreatmentRecord> = withContext(Dispatchers.IO) {
        try {
            val entity = TreatmentEntity(
                id = treatment.id,
                goat_id_c = treatment.goat_id_c,
                symptoms_c = treatment.symptoms_c,
                diagnosis_c = treatment.diagnosis_c,
                medicine_c = treatment.medicine_c,
                dose_c = treatment.dose_c,
                start_date_c = treatment.start_date_c,
                end_date_c = treatment.end_date_c,
                veterinarian_c = treatment.veterinarian_c,
                outcome_c = treatment.outcome_c,
                notes_c = treatment.notes_c,
                is_synced = false
            )
            database.healthDao().insertTreatment(entity)

            val json = JSONObject().apply {
                put("id", treatment.id)
                put("goat_id_c", treatment.goat_id_c)
                put("symptoms_c", treatment.symptoms_c)
                put("diagnosis_c", treatment.diagnosis_c)
                put("medicine_c", treatment.medicine_c)
                put("dose_c", treatment.dose_c)
                put("start_date_c", treatment.start_date_c)
                if (!treatment.end_date_c.isNullOrBlank()) put("end_date_c", treatment.end_date_c)
                if (!treatment.veterinarian_c.isNullOrBlank()) put("veterinarian_c", treatment.veterinarian_c)
                put("outcome_c", treatment.outcome_c)
                if (!treatment.notes_c.isNullOrBlank()) put("notes_c", treatment.notes_c)
            }
            syncManager.enqueueOperation("treatments_c", treatment.id, "CREATE", json)

            Result.success(treatment)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getTreatments(goatId: String? = null): Result<List<TreatmentRecord>> = withContext(Dispatchers.IO) {
        try {
            val entities = if (goatId != null) database.healthDao().getTreatmentsByGoat(goatId) else database.healthDao().getAllTreatments()
            val list = entities.map {
                TreatmentRecord(
                    id = it.id,
                    goat_id_c = it.goat_id_c,
                    symptoms_c = it.symptoms_c,
                    diagnosis_c = it.diagnosis_c,
                    medicine_c = it.medicine_c,
                    dose_c = it.dose_c,
                    start_date_c = it.start_date_c,
                    end_date_c = it.end_date_c,
                    veterinarian_c = it.veterinarian_c,
                    outcome_c = it.outcome_c,
                    notes_c = it.notes_c
                )
            }
            Result.success(list)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // ==============================================================================
    // HEALTH SCHEDULES & TANUVAS REFERENCE
    // ==============================================================================

    suspend fun seedTanuvasSchedulesIfEmpty() = withContext(Dispatchers.IO) {
        try {
            val existingVac = database.healthScheduleDao().getAllVaccinationSchedules()
            if (existingVac.isEmpty()) {
                val defaultVaccinations = listOf(
                    VaccinationScheduleEntity(
                        name = "PPR (Peste des Petits Ruminants) - TANUVAS",
                        disease = "PPR",
                        vaccine_name = "Live Attenuated PPR Vaccine",
                        recommended_age = "3 months and above",
                        recommended_interval = "Once every 3 years",
                        dose_reference = "1 ml Subcutaneously (S/C)",
                        notes = "Essential protective vaccination. Do not vaccinate pregnant does in advanced gestation. Confirm timing with your veterinarian/local animal-health authority.",
                        source = "TANUVAS Reference Schedule",
                        active = true
                    ),
                    VaccinationScheduleEntity(
                        name = "Enterotoxaemia (ET / Pulpy Kidney) - TANUVAS",
                        disease = "Enterotoxaemia",
                        vaccine_name = "Clostridium perfringens Type D Toxoid",
                        recommended_age = "3-4 months (Pre-monsoon booster)",
                        recommended_interval = "Annual (May-June)",
                        dose_reference = "2.5 ml - 3 ml Subcutaneously (S/C)",
                        notes = "Critical before seasonal lush pasture grazing. Booster in 14-21 days for primary kids. Confirm timing with veterinarian.",
                        source = "TANUVAS Reference Schedule",
                        active = true
                    ),
                    VaccinationScheduleEntity(
                        name = "Foot and Mouth Disease (FMD) - TANUVAS",
                        disease = "FMD",
                        vaccine_name = "Inactivated Polyvalent FMD Vaccine",
                        recommended_age = "4 months and above",
                        recommended_interval = "Bi-annual (Every 6 months: Sept & March)",
                        dose_reference = "1 ml - 2 ml Deep Intramuscular (I/M)",
                        notes = "Protects against systemic aphthous vesicular outbreaks. Confirm timing with your veterinarian/local animal-health authority.",
                        source = "TANUVAS Reference Schedule",
                        active = true
                    ),
                    VaccinationScheduleEntity(
                        name = "Bluetongue (BT) - TANUVAS",
                        disease = "Bluetongue",
                        vaccine_name = "Inactivated Polyvalent Bluetongue Vaccine",
                        recommended_age = "4 months and above",
                        recommended_interval = "Annual (Pre-monsoon/August)",
                        dose_reference = "1 ml Subcutaneously (S/C)",
                        notes = "Administer prior to peak Culicoides vector breeding season. Confirm timing with veterinarian.",
                        source = "TANUVAS Reference Schedule",
                        active = true
                    ),
                    VaccinationScheduleEntity(
                        name = "Goat Pox - TANUVAS",
                        disease = "Goat Pox",
                        vaccine_name = "Attenuated Goat Pox Vaccine",
                        recommended_age = "3-4 months",
                        recommended_interval = "Annual (December-January)",
                        dose_reference = "0.5 ml - 1 ml S/C",
                        notes = "Prevents cutaneous pox eruptions and systemic morbidity. Confirm timing with veterinarian.",
                        source = "TANUVAS Reference Schedule",
                        active = true
                    ),
                    VaccinationScheduleEntity(
                        name = "CCPP (Contagious Caprine Pleuropneumonia) - TANUVAS",
                        disease = "CCPP",
                        vaccine_name = "Inactivated Mycoplasma capricolum subsp. capripneumoniae",
                        recommended_age = "3 months and above",
                        recommended_interval = "Annual",
                        dose_reference = "0.2 ml - 1 ml S/C",
                        notes = "Indicated in endemic respiratory zones. Confirm timing with veterinarian.",
                        source = "TANUVAS Reference Schedule",
                        active = true
                    )
                )
                database.healthScheduleDao().insertAllVaccinationSchedules(defaultVaccinations)
            }

            val existingDeworm = database.healthScheduleDao().getAllDewormingSchedules()
            if (existingDeworm.size < 8) {
                val defaultDewormings = listOf(
                    DewormingScheduleEntity(
                        name = "Kid 1st Deworming (30 Days / 1 Month) - முதல் முறை (30 நாட்கள்)",
                        species = "Goat",
                        trigger_type = "KID (30d)",
                        interval_days = 30,
                        fec_reference = "Early neonatal parasitic clearance (Roundworms, Tapeworms)",
                        notes = "Age: 30 days. Medicine: Albendazole suspension (1 ml / 3-5 kg) or Fenbendazole oral suspension. Dose morning on empty stomach. Weigh kid accurately to avoid underdosing. (குட்டிகளுக்கான முதல் குடற்புழு நீக்கம் - 30 நாட்கள்).",
                        source = "Age-Based Protocol",
                        active = true
                    ),
                    DewormingScheduleEntity(
                        name = "Kid 2nd Deworming (60 Days / 2 Months) - இரண்டாம் முறை (60 நாட்கள்)",
                        species = "Goat",
                        trigger_type = "KID (60d)",
                        interval_days = 30,
                        fec_reference = "Hookworms, Roundworms, Lungworms - Rotational Group",
                        notes = "Age: 60 days (2 months). Medicine: Levamisole hydrochloride or Fenbendazole suspension. Rotate chemical family from 1st dose to prevent parasite resistance. (குட்டிகளுக்கான இரண்டாம் குடற்புழு நீக்கம் - 60 நாட்கள் - மருந்து சுழற்சி).",
                        source = "Age-Based Protocol",
                        active = true
                    ),
                    DewormingScheduleEntity(
                        name = "Kid 3rd Deworming - Weaning (90 Days / 3 Months) - பால் குடி மறக்கும் பருவம்",
                        species = "Goat",
                        trigger_type = "WEANING (90d)",
                        interval_days = 30,
                        fec_reference = "Mixed helminths, Amphistomes, Pre-weaning stress protection",
                        notes = "Age: 90 days (3 months - Weaning stage). Medicine: Oxyclozanide + Levamisole combination or Fenbendazole suspension. Administer 3-5 days before separating from mother. Weaning stress causes immunity drops; deworming protects gut integrity. (பால் குடி மறக்கும் பருவம் - 90 நாட்கள்).",
                        source = "Age-Based Protocol",
                        active = true
                    ),
                    DewormingScheduleEntity(
                        name = "Growing Weaners Routine Deworming (3 to 6 Months) - வளரும் ஆடுகள்",
                        species = "Goat",
                        trigger_type = "GROWING (3-6m)",
                        interval_days = 60,
                        fec_reference = "Haemonchus contortus (Barber pole worm), FEC > 300 EPG",
                        notes = "Every 60-90 days during fast growth stage. Medicine: Closantel oral, Levamisole, or Fenbendazole. Check eye membrane color with FAMACHA card and monitor daily weight gain. (வளரும் குட்டிகள் - 3 முதல் 6 மாதங்கள்).",
                        source = "Age-Based Protocol",
                        active = true
                    ),
                    DewormingScheduleEntity(
                        name = "Adults Pre-Monsoon Strategic Deworming (May - June) - மழைக்காலத்திற்கு முன்",
                        species = "Goat",
                        trigger_type = "PRE-MONSOON",
                        interval_days = 90,
                        fec_reference = "Pasture contamination suppression before rain-induced spore blooms",
                        notes = "Administer in May/June before monsoon rains. Medicine: Ivermectin injection, Closantel, or Albendazole. Suppresses egg shedding before rain turns pastures into infective larval incubators. (மழைக்காலத்திற்கு முன் - மே/ஜூன்).",
                        source = "Seasonal Protocol",
                        active = true
                    ),
                    DewormingScheduleEntity(
                        name = "Adults Post-Monsoon Flukicide & Deworming (Oct - Nov) - மழைக்காலத்திற்கு பின்",
                        species = "Goat",
                        trigger_type = "POST-MONSOON",
                        interval_days = 90,
                        fec_reference = "Liver fluke (Fasciola) & Amphistome eradication after wetland grazing",
                        notes = "Administer in Oct/Nov after monsoon rains. Medicine: Levamisole + Oxyclozanide combination, Rafoxanide, or Triclabendazole. Targets liver flukes and stomach flukes contracted from snail habitats. (மழைக்காலத்திற்கு பின் - அக்டோபர்/நவம்பர்).",
                        source = "Seasonal Protocol",
                        active = true
                    ),
                    DewormingScheduleEntity(
                        name = "Adult Herd Routine Deworming (3 to 4 Times/Year) - பெரிய ஆடுகள்",
                        species = "Goat",
                        trigger_type = "PERIODIC",
                        interval_days = 90,
                        fec_reference = "Adult herd maintenance (Quarterly / 3-4 times a year)",
                        notes = "Deworm adult does and bucks 3 to 4 times a year. Always rotate chemical classes (Benzimidazoles, Imidazothiazoles, Macrocyclic Lactones) to avoid drug resistance. (பெரிய ஆடுகள் - ஆண்டுக்கு 3 முதல் 4 முறை).",
                        source = "TANUVAS Reference",
                        active = true
                    ),
                    DewormingScheduleEntity(
                        name = "Pregnant Does Protocol & Gestation Safety Rules - சினை ஆடுகள் வழிகாட்டுதல்",
                        species = "Goat",
                        trigger_type = "GESTATION CAUTION",
                        interval_days = 150,
                        fec_reference = "Strictly conditional: FEC > 1000 EPG with clinical anemia only",
                        notes = "⚠️ CRITICAL WARNING: DO NOT DEWORM during the first 45-60 days of pregnancy! (Risk of embryonic death and teratogenesis). In late pregnancy (after 90 days), deworm ONLY if clinically essential using pregnancy-safe Fenbendazole under veterinary supervision. Deworm again 2-3 weeks post-kidding to prevent milk transmission. (சினை ஆடுகள் - முதல் 45-60 நாட்கள் கண்டிப்பாகத் தவிர்க்கவும்).",
                        source = "Veterinary Protocol",
                        active = true
                    ),
                    DewormingScheduleEntity(
                        name = "FEC-Based Targeted Deworming (FAMACHA / McMaster)",
                        species = "Goat",
                        trigger_type = "FEC-BASED",
                        interval_days = 60,
                        fec_reference = "Treat individuals with FEC > 500-1000 EPG or FAMACHA score 4-5",
                        notes = "Selective anthelmintic therapy leaves refugia population to delay resistance. Do not hardcode medication or dosage. (மலப் பரிசோதனை மற்றும் FAMACHA அடிப்படையிலான சிகிச்சை).",
                        source = "TANUVAS Reference",
                        active = true
                    ),
                    DewormingScheduleEntity(
                        name = "Veterinarian Advised Strategic Protocol",
                        species = "Goat",
                        trigger_type = "VETERINARIAN ADVISED",
                        interval_days = 120,
                        fec_reference = "Prescribed following clinical post-mortem or fecal floatation",
                        notes = "Periodic deworming / broad-spectrum anthelmintic based on faecal egg count. Administer under licensed veterinarian prescription. (கால்நடை மருத்துவர் பரிந்துரைத்த நெறிமுறை).",
                        source = "TANUVAS Reference",
                        active = true
                    )
                )
                database.healthScheduleDao().insertAllDewormingSchedules(defaultDewormings)
            }
        } catch (_: Exception) {}
    }

    suspend fun seedHistoricalHealthTrendsIfEmpty() = withContext(Dispatchers.IO) {
        try {
            seedTanuvasSchedulesIfEmpty()
            val existingWeights = database.healthDao().getAllWeights()
            if (existingWeights.size >= 5) return@withContext

            var goats = database.goatDao().getAllGoats()
            if (goats.isEmpty()) {
                val seedGoats = listOf(
                    GoatEntity(
                        id = "goat_boer_tara",
                        tag_c = "GT-01",
                        name = "Tara",
                        breed_c = "Boer",
                        sex_c = "Doe",
                        birth_date_c = "2024-02-15",
                        weight_kg_c = 34.5,
                        status_c = "Active"
                    ),
                    GoatEntity(
                        id = "goat_buck_raja",
                        tag_c = "GT-02",
                        name = "Raja",
                        breed_c = "Tellicherry",
                        sex_c = "Buck",
                        birth_date_c = "2023-11-10",
                        weight_kg_c = 48.0,
                        status_c = "Active"
                    ),
                    GoatEntity(
                        id = "goat_sirohi_ganga",
                        tag_c = "GT-03",
                        name = "Ganga",
                        breed_c = "Sirohi",
                        sex_c = "Doe",
                        birth_date_c = "2024-04-01",
                        weight_kg_c = 28.2,
                        status_c = "Active"
                    )
                )
                database.goatDao().insertAll(seedGoats)
                goats = seedGoats
            }

            val primaryGoat = goats.first()
            val now = System.currentTimeMillis()
            val dayMillis = 86400000L
            val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)

            // Seed historical weights across past 5 months showing healthy growth (ADG ~75g/day)
            val weightProgress = listOf(
                Pair(150, 22.0),
                Pair(120, 24.3),
                Pair(90, 26.8),
                Pair(60, 29.2),
                Pair(30, 31.8),
                Pair(7, 34.0),
                Pair(0, 34.5)
            )

            val weightsToInsert = weightProgress.map { (daysAgo, weight) ->
                val dateStr = sdf.format(Date(now - daysAgo * dayMillis))
                GoatWeightEntity(
                    id = UUID.randomUUID().toString(),
                    goat_id_c = primaryGoat.id,
                    weight_kg_c = weight,
                    date_c = dateStr,
                    method_c = "Electronic Scale",
                    notes_c = "Periodic herd weigh-in",
                    updated_at = now - daysAgo * dayMillis,
                    is_synced = true
                )
            }
            database.healthDao().insertAllWeights(weightsToInsert)

            // Seed vaccinations across past months
            val seedVaccinations = listOf(
                VaccinationEntity(
                    id = UUID.randomUUID().toString(),
                    goat_id_c = primaryGoat.id,
                    vaccine_c = "PPR Live Attenuated",
                    dose_c = "1 ml",
                    administered_date_c = sdf.format(Date(now - 140 * dayMillis)),
                    administered_by_c = "Dr. Suresh (Vet)",
                    notes_c = "Annual protective booster"
                ),
                VaccinationEntity(
                    id = UUID.randomUUID().toString(),
                    goat_id_c = primaryGoat.id,
                    vaccine_c = "Enterotoxaemia (ET)",
                    dose_c = "2.5 ml",
                    administered_date_c = sdf.format(Date(now - 80 * dayMillis)),
                    administered_by_c = "Farm Vet",
                    notes_c = "Pre-monsoon booster"
                ),
                VaccinationEntity(
                    id = UUID.randomUUID().toString(),
                    goat_id_c = primaryGoat.id,
                    vaccine_c = "FMD Polyvalent",
                    dose_c = "2 ml",
                    administered_date_c = sdf.format(Date(now - 20 * dayMillis)),
                    administered_by_c = "Dr. Suresh",
                    notes_c = "Bi-annual schedule"
                )
            )
            database.healthDao().insertAllVaccinations(seedVaccinations)

            // Seed rotational dewormings
            val seedDewormings = listOf(
                DewormingEntity(
                    id = UUID.randomUUID().toString(),
                    goat_id_c = primaryGoat.id,
                    medicine_c = "Albendazole (Valbazen)",
                    dose_c = "5 ml",
                    treatment_date_c = sdf.format(Date(now - 110 * dayMillis)),
                    weight_at_treatment_c = 25.0,
                    administered_by_c = "Farm Staff",
                    notes_c = "Quarterly strategic deworming"
                ),
                DewormingEntity(
                    id = UUID.randomUUID().toString(),
                    goat_id_c = primaryGoat.id,
                    medicine_c = "Ivermectin Oral",
                    dose_c = "4 ml",
                    treatment_date_c = sdf.format(Date(now - 45 * dayMillis)),
                    weight_at_treatment_c = 30.5,
                    administered_by_c = "Farm Staff",
                    notes_c = "Drug class rotation (Avermectins)"
                )
            )
            database.healthDao().insertAllDewormings(seedDewormings)

            // Seed clinical treatments
            val seedTreatments = listOf(
                TreatmentEntity(
                    id = UUID.randomUUID().toString(),
                    goat_id_c = primaryGoat.id,
                    symptoms_c = "Mild Foot Scald (Interdigital tenderness)",
                    diagnosis_c = "Interdigital dermatitis",
                    medicine_c = "Oxytetracycline topical spray + Zinc Sulphate footbath",
                    dose_c = "Twice daily for 3 days",
                    start_date_c = sdf.format(Date(now - 70 * dayMillis)),
                    end_date_c = sdf.format(Date(now - 67 * dayMillis)),
                    outcome_c = "Recovered",
                    veterinarian_c = "Dr. Suresh"
                ),
                TreatmentEntity(
                    id = UUID.randomUUID().toString(),
                    goat_id_c = primaryGoat.id,
                    symptoms_c = "Mild Indigestion / Off Feed",
                    diagnosis_c = "Rumen hypomotility",
                    medicine_c = "Probiotic live yeast drench + B-Complex",
                    dose_c = "15 ml oral",
                    start_date_c = sdf.format(Date(now - 15 * dayMillis)),
                    end_date_c = sdf.format(Date(now - 13 * dayMillis)),
                    outcome_c = "Recovered",
                    veterinarian_c = "Farm Staff"
                )
            )
            database.healthDao().insertAllTreatments(seedTreatments)

            // Seed daily health observations
            val obsDays = listOf(60, 45, 30, 20, 14, 7, 3, 1, 0)
            val seedObservations = obsDays.mapIndexed { idx, daysAgo ->
                val temp = 38.8 + ((idx % 3) * 0.2)
                val famacha = if (idx == 1) "Score 3 - Borderline" else if (idx % 2 == 0) "Score 1 - Optimal Pink" else "Score 2 - Acceptable"
                val bcs = 2.8 + ((idx.toFloat() / obsDays.size) * 0.7)
                DailyHealthObservationEntity(
                    id = UUID.randomUUID().toString(),
                    goat_id = primaryGoat.id,
                    goat_tag = primaryGoat.tag_c,
                    goat_name = primaryGoat.name,
                    observation_date = sdf.format(Date(now - daysAgo * dayMillis)),
                    temperature_celsius = temp,
                    pulse_bpm = 76 + (idx % 4) * 2,
                    respiration_rate = 20 + (idx % 3),
                    appetite_status = if (idx == 3) "Reduced" else "Normal",
                    activity_level = "Active & Alert",
                    body_condition_score = bcs,
                    feces_consistency = "Normal Pellets",
                    rumen_motility = "Normal",
                    mucous_membrane_famacha = famacha,
                    abnormal_symptoms = if (idx == 3) "Mild Indigestion" else "None",
                    overall_health_rating = if (idx == 3) "Mild Concern" else "Healthy",
                    observer_name = "Farm Staff",
                    notes = "Daily herd morning rounds",
                    created_at = now - daysAgo * dayMillis
                )
            }
            database.dailyHealthObservationDao().insertAll(seedObservations)

        } catch (_: Exception) {}
    }

    suspend fun getVaccinationSchedules(): Result<List<VaccinationSchedule>> = withContext(Dispatchers.IO) {
        try {
            seedTanuvasSchedulesIfEmpty()
            val list = database.healthScheduleDao().getAllVaccinationSchedules().map { it.toDomain() }
            Result.success(list)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun saveVaccinationSchedule(schedule: VaccinationSchedule): Result<VaccinationSchedule> = withContext(Dispatchers.IO) {
        try {
            database.healthScheduleDao().insertVaccinationSchedule(schedule.toEntity())
            Result.success(schedule)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getDewormingSchedules(): Result<List<DewormingSchedule>> = withContext(Dispatchers.IO) {
        try {
            seedTanuvasSchedulesIfEmpty()
            val list = database.healthScheduleDao().getAllDewormingSchedules().map { it.toDomain() }
            Result.success(list)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun saveDewormingSchedule(schedule: DewormingSchedule): Result<DewormingSchedule> = withContext(Dispatchers.IO) {
        try {
            database.healthScheduleDao().insertDewormingSchedule(schedule.toEntity())
            Result.success(schedule)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // ==============================================================================
    // BATCH / MULTI-GOAT HEALTH RECORDING + FINANCE EXPENSE INTEGRATION
    // ==============================================================================

    suspend fun recordVaccinationsForGoats(
        records: List<VaccinationRecord>,
        totalCost: Double? = null,
        diseaseOrVaccine: String = "Vaccination"
    ): Result<List<VaccinationRecord>> = withContext(Dispatchers.IO) {
        try {
            val entities = records.map {
                VaccinationEntity(
                    id = it.id,
                    goat_id_c = it.goat_id_c,
                    vaccine_c = it.vaccine_c,
                    dose_c = it.dose_c,
                    administered_date_c = it.administered_date_c,
                    next_due_date_c = it.next_due_date_c,
                    batch_number_c = it.batch_number_c,
                    administered_by_c = it.administered_by_c,
                    notes_c = it.notes_c,
                    is_synced = false
                )
            }
            database.healthDao().insertAllVaccinations(entities)

            entities.forEach { entity ->
                val json = JSONObject().apply {
                    put("id", entity.id)
                    put("goat_id_c", entity.goat_id_c)
                    put("vaccine_c", entity.vaccine_c)
                    put("dose_c", entity.dose_c)
                    put("administered_date_c", entity.administered_date_c)
                    if (!entity.next_due_date_c.isNullOrBlank()) put("next_due_date_c", entity.next_due_date_c)
                    if (!entity.batch_number_c.isNullOrBlank()) put("batch_number_c", entity.batch_number_c)
                    if (!entity.administered_by_c.isNullOrBlank()) put("administered_by_c", entity.administered_by_c)
                    if (!entity.notes_c.isNullOrBlank()) put("notes_c", entity.notes_c)
                }
                syncManager.enqueueOperation("vaccinations_c", entity.id, "CREATE", json)
            }

            // Financial integration: Create expense if actual cost incurred
            if (totalCost != null && totalCost > 0) {
                val firstDate = records.firstOrNull()?.administered_date_c ?: dateFormat.format(Date())
                val expenseTxn = FinanceTransaction(
                    type_c = "Expense",
                    amount_c = totalCost,
                    date_c = firstDate,
                    category_c = "Veterinary / Health",
                    description_c = "Vaccination ($diseaseOrVaccine) for ${records.size} goats",
                    payment_mode_c = "Cash",
                    reference_id_c = records.firstOrNull()?.id
                )
                recordFinanceTransaction(expenseTxn)
            }

            Result.success(records)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun recordDewormingsForGoats(
        records: List<DewormingRecord>,
        totalCost: Double? = null,
        productName: String = "Deworming"
    ): Result<List<DewormingRecord>> = withContext(Dispatchers.IO) {
        try {
            val entities = records.map {
                DewormingEntity(
                    id = it.id,
                    goat_id_c = it.goat_id_c,
                    medicine_c = it.medicine_c,
                    dose_c = it.dose_c,
                    treatment_date_c = it.treatment_date_c,
                    next_due_date_c = it.next_due_date_c,
                    weight_at_treatment_c = it.weight_at_treatment_c,
                    administered_by_c = it.administered_by_c,
                    notes_c = it.notes_c,
                    is_synced = false
                )
            }
            database.healthDao().insertAllDewormings(entities)

            entities.forEach { entity ->
                val json = JSONObject().apply {
                    put("id", entity.id)
                    put("goat_id_c", entity.goat_id_c)
                    put("medicine_c", entity.medicine_c)
                    put("dose_c", entity.dose_c)
                    put("treatment_date_c", entity.treatment_date_c)
                    if (!entity.next_due_date_c.isNullOrBlank()) put("next_due_date_c", entity.next_due_date_c)
                    if (entity.weight_at_treatment_c != null) put("weight_at_treatment_c", entity.weight_at_treatment_c)
                    if (!entity.administered_by_c.isNullOrBlank()) put("administered_by_c", entity.administered_by_c)
                    if (!entity.notes_c.isNullOrBlank()) put("notes_c", entity.notes_c)
                }
                syncManager.enqueueOperation("deworming_records_c", entity.id, "CREATE", json)
            }

            // Financial integration
            if (totalCost != null && totalCost > 0) {
                val firstDate = records.firstOrNull()?.treatment_date_c ?: dateFormat.format(Date())
                val expenseTxn = FinanceTransaction(
                    type_c = "Expense",
                    amount_c = totalCost,
                    date_c = firstDate,
                    category_c = "Veterinary / Health",
                    description_c = "Deworming ($productName) for ${records.size} goats",
                    payment_mode_c = "Cash",
                    reference_id_c = records.firstOrNull()?.id
                )
                recordFinanceTransaction(expenseTxn)
            }

            Result.success(records)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun recordTreatmentWithExpense(
        treatment: TreatmentRecord,
        cost: Double? = null
    ): Result<TreatmentRecord> = withContext(Dispatchers.IO) {
        try {
            val res = recordTreatment(treatment.copy(cost_c = cost))
            if (res.isSuccess && cost != null && cost > 0) {
                val expenseTxn = FinanceTransaction(
                    type_c = "Expense",
                    amount_c = cost,
                    date_c = treatment.start_date_c,
                    category_c = "Veterinary / Health",
                    description_c = "Clinical Treatment for Goat #${treatment.goat_id_c.take(6)}: ${treatment.medicine_c}",
                    payment_mode_c = "Cash",
                    reference_id_c = treatment.id
                )
                recordFinanceTransaction(expenseTxn)
            }
            res
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // ==============================================================================
    // QUARANTINE PROTOCOL & WORKFLOW
    // ==============================================================================

    suspend fun getQuarantineRecords(): Result<List<QuarantineRecord>> = withContext(Dispatchers.IO) {
        try {
            val goats = database.goatDao().getAllGoats().associateBy { it.id }
            val records = database.quarantineDao().getAllQuarantineRecords().map { entity ->
                val g = goats[entity.goat_id]
                entity.toDomain(goatTag = g?.tag_c ?: "", goatName = g?.name ?: "")
            }
            Result.success(records)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getQuarantineRecordForGoat(goatId: String): Result<QuarantineRecord?> = withContext(Dispatchers.IO) {
        try {
            val entity = database.quarantineDao().getActiveQuarantineForGoat(goatId)
            val goat = database.goatDao().getGoatById(goatId)
            val domain = entity?.toDomain(goatTag = goat?.tag_c ?: "", goatName = goat?.name ?: "")
            Result.success(domain)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun saveQuarantineRecord(record: QuarantineRecord): Result<QuarantineRecord> = withContext(Dispatchers.IO) {
        try {
            val entity = record.toEntity()
            database.quarantineDao().insertQuarantineRecord(entity)

            // If status is QUARANTINE or EXTENDED, ensure goat status is "Quarantine"
            if (record.status == "QUARANTINE" || record.status == "EXTENDED") {
                database.goatDao().updateStatus(record.goat_id, "Quarantine")
            }

            val json = JSONObject().apply {
                put("id", entity.id)
                put("goat_id", entity.goat_id)
                put("start_date", entity.start_date)
                put("planned_end_date", entity.planned_end_date)
                put("status", entity.status)
                if (!entity.isolation_location.isNullOrBlank()) put("isolation_location", entity.isolation_location)
                if (!entity.seller_name.isNullOrBlank()) put("seller_name", entity.seller_name)
            }
            syncManager.enqueueOperation("quarantine_records", entity.id, "CREATE", json)

            Result.success(record)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun extendQuarantine(
        id: String,
        newEndDate: String,
        reason: String,
        veterinarian: String?,
        notes: String?
    ): Result<Boolean> = withContext(Dispatchers.IO) {
        try {
            val all = database.quarantineDao().getAllQuarantineRecords()
            val existing = all.find { it.id == id } ?: return@withContext Result.failure(Exception("Record not found"))

            val currentExtList = existing.toDomain().extensions.toMutableList()
            currentExtList.add(
                QuarantineExtension(
                    extended_date = dateFormat.format(Date()),
                    new_end_date = newEndDate,
                    reason = reason,
                    veterinarian = veterinarian,
                    notes = notes
                )
            )

            val extJson = JSONArray().apply {
                currentExtList.forEach { ext ->
                    put(JSONObject().apply {
                        put("extended_date", ext.extended_date)
                        put("new_end_date", ext.new_end_date)
                        put("reason", ext.reason)
                        if (ext.veterinarian != null) put("veterinarian", ext.veterinarian)
                        if (ext.notes != null) put("notes", ext.notes)
                    })
                }
            }.toString()

            val combinedNotes = buildString {
                if (!existing.notes.isNullOrBlank()) append(existing.notes).append(" | ")
                append("Extended to $newEndDate: $reason")
                if (!notes.isNullOrBlank()) append(" ($notes)")
            }

            database.quarantineDao().extendQuarantine(
                id = id,
                newEndDate = newEndDate,
                extensionsJson = extJson,
                notes = combinedNotes
            )

            Result.success(true)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun releaseQuarantine(
        id: String,
        releaseDate: String,
        veterinarian: String?,
        comments: String?
    ): Result<Boolean> = withContext(Dispatchers.IO) {
        try {
            val all = database.quarantineDao().getAllQuarantineRecords()
            val existing = all.find { it.id == id } ?: return@withContext Result.failure(Exception("Record not found"))

            val releaseReason = buildString {
                append("Cleared by Vet: ${veterinarian ?: "Staff"}")
                if (!comments.isNullOrBlank()) append(" - Comments: $comments")
            }

            database.quarantineDao().releaseQuarantine(
                id = id,
                status = "CLEARED",
                releaseDate = releaseDate,
                releaseReason = releaseReason
            )

            // Update goat status to "Active"
            database.goatDao().updateStatus(existing.goat_id, "Active")
            syncManager.enqueueOperation("goats_c", existing.goat_id, "UPDATE", JSONObject().put("status_c", "Active"))

            Result.success(true)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // ==============================================================================
    // HEALTH ALERTS, AUDIT & UNIFIED HISTORY
    // ==============================================================================

    suspend fun getHealthAlerts(): Result<List<HealthAlert>> = withContext(Dispatchers.IO) {
        try {
            val todayStr = dateFormat.format(Date())
            val todayDate = dateFormat.parse(todayStr) ?: Date()
            val goats = database.goatDao().getAllGoats().associateBy { it.id }
            val alerts = mutableListOf<HealthAlert>()

            // 1. Vaccination Alerts (Due & Overdue)
            val vaccinations = database.healthDao().getAllVaccinations()
            vaccinations.filter { !it.next_due_date_c.isNullOrBlank() }.forEach { vac ->
                try {
                    val dueDate = dateFormat.parse(vac.next_due_date_c!!)
                    if (dueDate != null) {
                        val diffDays = ((dueDate.time - todayDate.time) / (1000 * 60 * 60 * 24)).toInt()
                        val goat = goats[vac.goat_id_c]
                        val gTag = goat?.tag_c ?: "Goat"
                        if (diffDays < 0) {
                            alerts.add(
                                HealthAlert(
                                    type = "VACCINATION_OVERDUE",
                                    title = "Vaccination Overdue: ${vac.vaccine_c}",
                                    message = "Goat $gTag is overdue by ${-diffDays} days (Due: ${vac.next_due_date_c})",
                                    goat_id = vac.goat_id_c,
                                    goat_tag = gTag,
                                    due_date = vac.next_due_date_c!!,
                                    days_diff = diffDays,
                                    severity = "URGENT"
                                )
                            )
                        } else if (diffDays <= 14) {
                            alerts.add(
                                HealthAlert(
                                    type = "VACCINATION_DUE",
                                    title = "Vaccination Due: ${vac.vaccine_c}",
                                    message = "Goat $gTag is due in $diffDays days (Due: ${vac.next_due_date_c})",
                                    goat_id = vac.goat_id_c,
                                    goat_tag = gTag,
                                    due_date = vac.next_due_date_c!!,
                                    days_diff = diffDays,
                                    severity = "WARNING"
                                )
                            )
                        }
                    }
                } catch (_: Exception) {}
            }

            // 2. Deworming Alerts (Due & Overdue)
            val dewormings = database.healthDao().getAllDewormings()
            dewormings.filter { !it.next_due_date_c.isNullOrBlank() }.forEach { dew ->
                try {
                    val dueDate = dateFormat.parse(dew.next_due_date_c!!)
                    if (dueDate != null) {
                        val diffDays = ((dueDate.time - todayDate.time) / (1000 * 60 * 60 * 24)).toInt()
                        val goat = goats[dew.goat_id_c]
                        val gTag = goat?.tag_c ?: "Goat"
                        if (diffDays < 0) {
                            alerts.add(
                                HealthAlert(
                                    type = "DEWORMING_OVERDUE",
                                    title = "Deworming Overdue: ${dew.medicine_c}",
                                    message = "Goat $gTag is overdue by ${-diffDays} days for deworming (Due: ${dew.next_due_date_c})",
                                    goat_id = dew.goat_id_c,
                                    goat_tag = gTag,
                                    due_date = dew.next_due_date_c!!,
                                    days_diff = diffDays,
                                    severity = "URGENT"
                                )
                            )
                        } else if (diffDays <= 7) {
                            alerts.add(
                                HealthAlert(
                                    type = "DEWORMING_DUE",
                                    title = "Deworming Due: ${dew.medicine_c}",
                                    message = "Goat $gTag is due for deworming in $diffDays days",
                                    goat_id = dew.goat_id_c,
                                    goat_tag = gTag,
                                    due_date = dew.next_due_date_c!!,
                                    days_diff = diffDays,
                                    severity = "WARNING"
                                )
                            )
                        }
                    }
                } catch (_: Exception) {}
            }

            // 3. Treatment Follow-ups
            val treatments = database.healthDao().getAllTreatments()
            treatments.filter { it.outcome_c.equals("Under Treatment", ignoreCase = true) }.forEach { tr ->
                val goat = goats[tr.goat_id_c]
                val gTag = goat?.tag_c ?: "Goat"
                alerts.add(
                    HealthAlert(
                        type = "TREATMENT_FOLLOW_UP",
                        title = "Active Treatment Follow-up: ${tr.medicine_c}",
                        message = "Goat $gTag is currently under treatment for ${tr.symptoms_c}",
                        goat_id = tr.goat_id_c,
                        goat_tag = gTag,
                        due_date = tr.end_date_c ?: tr.start_date_c,
                        days_diff = 0,
                        severity = "INFO"
                    )
                )
            }

            // 4. Quarantine Alerts
            val quarantines = database.quarantineDao().getActiveQuarantinedGoats()
            quarantines.forEach { q ->
                try {
                    val endDate = dateFormat.parse(q.planned_end_date)
                    if (endDate != null) {
                        val diffDays = ((endDate.time - todayDate.time) / (1000 * 60 * 60 * 24)).toInt()
                        val goat = goats[q.goat_id]
                        val gTag = goat?.tag_c ?: "Goat"
                        if (diffDays < 0) {
                            alerts.add(
                                HealthAlert(
                                    type = "QUARANTINE_OVERDUE",
                                    title = "Quarantine Period Overdue",
                                    message = "Quarantine for Goat $gTag passed planned end date (${q.planned_end_date}) by ${-diffDays} days without clearance.",
                                    goat_id = q.goat_id,
                                    goat_tag = gTag,
                                    due_date = q.planned_end_date,
                                    days_diff = diffDays,
                                    severity = "URGENT"
                                )
                            )
                        } else if (diffDays <= 3) {
                            alerts.add(
                                HealthAlert(
                                    type = "QUARANTINE_ENDING",
                                    title = "Quarantine Ending Soon",
                                    message = "Quarantine for Goat $gTag ends in $diffDays days. Schedule veterinary clinical clearance.",
                                    goat_id = q.goat_id,
                                    goat_tag = gTag,
                                    due_date = q.planned_end_date,
                                    days_diff = diffDays,
                                    severity = "WARNING"
                                )
                            )
                        }
                    }
                } catch (_: Exception) {}
            }

            Result.success(alerts)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getHealthDashboardSummary(): Result<HealthDashboardSummary> = withContext(Dispatchers.IO) {
        try {
            val goats = database.goatDao().getAllGoats()
            val quarantines = database.quarantineDao().getActiveQuarantinedGoats()
            val treatments = database.healthDao().getAllTreatments().filter { it.outcome_c.equals("Under Treatment", ignoreCase = true) }
            val alertsRes = getHealthAlerts()
            val alerts = alertsRes.getOrDefault(emptyList())

            val summary = HealthDashboardSummary(
                totalGoats = goats.size,
                activeQuarantineCount = quarantines.size,
                vaccinationDueCount = alerts.count { it.type == "VACCINATION_DUE" },
                vaccinationOverdueCount = alerts.count { it.type == "VACCINATION_OVERDUE" },
                dewormingDueCount = alerts.count { it.type == "DEWORMING_DUE" },
                dewormingOverdueCount = alerts.count { it.type == "DEWORMING_OVERDUE" },
                activeTreatmentsCount = treatments.size,
                totalHealthAlertsCount = alerts.size
            )
            Result.success(summary)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getUnifiedHealthHistory(goatId: String? = null): Result<List<HealthHistoryItem>> = withContext(Dispatchers.IO) {
        try {
            val goats = database.goatDao().getAllGoats().associateBy { it.id }
            val items = mutableListOf<HealthHistoryItem>()

            // 1. Vaccinations
            val vacs = if (goatId != null) database.healthDao().getVaccinationsByGoat(goatId) else database.healthDao().getAllVaccinations()
            vacs.forEach { v ->
                val g = goats[v.goat_id_c]
                items.add(
                    HealthHistoryItem(
                        id = v.id,
                        goat_id = v.goat_id_c,
                        goat_tag = g?.tag_c ?: "Goat",
                        date = v.administered_date_c,
                        type = "Vaccination",
                        title = "Vaccinated: ${v.vaccine_c}",
                        description = "Dose: ${v.dose_c}. Next Due: ${v.next_due_date_c ?: "Not specified"}",
                        medicine_or_product = v.vaccine_c,
                        dose = v.dose_c,
                        veterinarian = v.administered_by_c,
                        attachment_note = v.notes_c
                    )
                )
            }

            // 2. Dewormings
            val dews = if (goatId != null) database.healthDao().getDewormingsByGoat(goatId) else database.healthDao().getAllDewormings()
            dews.forEach { d ->
                val g = goats[d.goat_id_c]
                items.add(
                    HealthHistoryItem(
                        id = d.id,
                        goat_id = d.goat_id_c,
                        goat_tag = g?.tag_c ?: "Goat",
                        date = d.treatment_date_c,
                        type = "Deworming",
                        title = "Dewormed: ${d.medicine_c}",
                        description = "Dose: ${d.dose_c}. Weight: ${d.weight_at_treatment_c ?: "N/A"} kg. Next Due: ${d.next_due_date_c ?: "Not specified"}",
                        medicine_or_product = d.medicine_c,
                        dose = d.dose_c,
                        veterinarian = d.administered_by_c,
                        attachment_note = d.notes_c
                    )
                )
            }

            // 3. Treatments
            val treats = if (goatId != null) database.healthDao().getTreatmentsByGoat(goatId) else database.healthDao().getAllTreatments()
            treats.forEach { t ->
                val g = goats[t.goat_id_c]
                items.add(
                    HealthHistoryItem(
                        id = t.id,
                        goat_id = t.goat_id_c,
                        goat_tag = g?.tag_c ?: "Goat",
                        date = t.start_date_c,
                        type = "Treatment",
                        title = "Treatment: ${t.diagnosis_c.ifBlank { t.symptoms_c }}",
                        description = "Medicine: ${t.medicine_c} (${t.dose_c}). Status: ${t.outcome_c}",
                        medicine_or_product = t.medicine_c,
                        dose = t.dose_c,
                        veterinarian = t.veterinarian_c,
                        outcome = t.outcome_c,
                        attachment_note = t.notes_c
                    )
                )
            }

            // 4. Reproductive Complications / Abortions
            val repEvents = if (goatId != null) database.mortalityAndReproductionDao().getEventsForDoe(goatId) else database.mortalityAndReproductionDao().getAllReproductiveEvents()
            repEvents.forEach { r ->
                val g = goats[r.doe_id]
                items.add(
                    HealthHistoryItem(
                        id = r.id,
                        goat_id = r.doe_id,
                        goat_tag = g?.tag_c ?: "Doe",
                        date = r.event_date,
                        type = "Reproductive Complication",
                        title = "Reproductive Event: ${r.event_type.replace("_", " ")}",
                        description = "Category: ${r.cause_category ?: "General"}. Symptoms: ${r.symptoms ?: "None recorded"}. Treatment: ${r.treatment ?: "None"}",
                        veterinarian = r.vet_doctor,
                        attachment_note = r.notes
                    )
                )
            }

            // 5. Mortalities
            val mortalities = database.mortalityAndReproductionDao().getAllMortalityEvents()
            val filteredMort = if (goatId != null) mortalities.filter { it.goat_id == goatId } else mortalities
            filteredMort.forEach { m ->
                items.add(
                    HealthHistoryItem(
                        id = m.id,
                        goat_id = m.goat_id,
                        goat_tag = m.goat_tag,
                        date = m.death_date,
                        type = "Mortality",
                        title = "Deceased: ${m.immediate_cause}",
                        description = "Category: ${m.cause_category}. Underlying: ${m.underlying_cause ?: "N/A"}. Post-mortem: ${if (m.post_mortem_performed) "Yes" else "No"}",
                        veterinarian = m.vet_doctor,
                        attachment_note = m.notes
                    )
                )
            }

            items.sortByDescending { it.date }
            Result.success(items)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // ==========================================
    // BREEDING, PREGNANCY & KIDDING
    // ==========================================

    suspend fun recordMating(mating: MatingRecord): Result<MatingRecord> = withContext(Dispatchers.IO) {
        try {
            // Immediate server/repo-side validation before inserting the mating record
            val allGoats = database.goatDao().getAllGoats().map { it.toDomain() }
            val doe = PedigreeManager.findGoat(mating.doe_id_c, allGoats)
            val buck = PedigreeManager.findGoat(mating.buck_id_c, allGoats)

            if (doe != null && buck != null) {
                val eligibility = PedigreeManager.evaluateMating(doe, buck, allGoats)
                if (!eligibility.canRecordMating) {
                    val errorMsg = eligibility.rejectionReasonEn ?: "Mating validation failed"
                    return@withContext Result.failure(IllegalArgumentException(errorMsg))
                }
            } else {
                return@withContext Result.failure(IllegalArgumentException("Invalid Doe or Buck specified for mating."))
            }

            val entity = MatingEntity(
                id = mating.id,
                doe_id_c = mating.doe_id_c,
                buck_id_c = mating.buck_id_c,
                mating_date_c = mating.mating_date_c,
                heat_observed_c = mating.heat_observed_c,
                method_c = mating.method_c,
                notes_c = mating.notes_c,
                is_synced = false
            )
            database.breedingDao().insertMating(entity)

            val json = JSONObject().apply {
                put("id", mating.id)
                put("doe_id_c", mating.doe_id_c)
                put("buck_id_c", mating.buck_id_c)
                put("mating_date_c", mating.mating_date_c)
                put("heat_observed_c", mating.heat_observed_c)
                put("method_c", mating.method_c)
                if (!mating.notes_c.isNullOrBlank()) put("notes_c", mating.notes_c)
            }
            syncManager.enqueueOperation("mating_records_c", mating.id, "CREATE", json)

            Result.success(mating)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getMatingRecords(): Result<List<MatingRecord>> = withContext(Dispatchers.IO) {
        try {
            val list = database.breedingDao().getAllMatings().map {
                MatingRecord(
                    id = it.id,
                    doe_id_c = it.doe_id_c,
                    buck_id_c = it.buck_id_c,
                    mating_date_c = it.mating_date_c,
                    heat_observed_c = it.heat_observed_c,
                    method_c = it.method_c,
                    notes_c = it.notes_c
                )
            }
            Result.success(list)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun recordPregnancy(preg: PregnancyRecord): Result<PregnancyRecord> = withContext(Dispatchers.IO) {
        try {
            val entity = PregnancyEntity(
                id = preg.id,
                doe_id_c = preg.doe_id_c,
                mating_record_id_c = preg.mating_record_id_c,
                confirmation_date_c = preg.confirmation_date_c,
                expected_kidding_date_c = preg.expected_kidding_date_c,
                status_c = preg.status_c,
                actual_kidding_date_c = preg.actual_kidding_date_c,
                notes_c = preg.notes_c,
                is_synced = false
            )
            database.breedingDao().insertPregnancy(entity)

            // Update doe status to Pregnant locally
            if (preg.status_c.equals("Confirmed", ignoreCase = true)) {
                database.goatDao().updateStatus(preg.doe_id_c, "Pregnant")
            }

            val json = JSONObject().apply {
                put("id", preg.id)
                put("doe_id_c", preg.doe_id_c)
                if (!preg.mating_record_id_c.isNullOrBlank()) put("mating_record_id_c", preg.mating_record_id_c)
                put("confirmation_date_c", preg.confirmation_date_c)
                put("expected_kidding_date_c", preg.expected_kidding_date_c)
                put("status_c", preg.status_c)
                if (!preg.actual_kidding_date_c.isNullOrBlank()) put("actual_kidding_date_c", preg.actual_kidding_date_c)
                if (!preg.notes_c.isNullOrBlank()) put("notes_c", preg.notes_c)
            }
            syncManager.enqueueOperation("pregnancies_c", preg.id, "CREATE", json)

            if (preg.status_c.equals("Confirmed", ignoreCase = true)) {
                syncManager.enqueueOperation("goats_c", preg.doe_id_c, "UPDATE", JSONObject().put("status_c", "Pregnant"))
            }

            Result.success(preg)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getPregnancies(): Result<List<PregnancyRecord>> = withContext(Dispatchers.IO) {
        try {
            val list = database.breedingDao().getAllPregnancies().map {
                PregnancyRecord(
                    id = it.id,
                    doe_id_c = it.doe_id_c,
                    mating_record_id_c = it.mating_record_id_c,
                    confirmation_date_c = it.confirmation_date_c,
                    expected_kidding_date_c = it.expected_kidding_date_c,
                    status_c = it.status_c,
                    actual_kidding_date_c = it.actual_kidding_date_c,
                    notes_c = it.notes_c
                )
            }
            Result.success(list)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun recordKidding(kidding: KiddingRecord, kids: List<KidRecord> = emptyList()): Result<KiddingRecord> = withContext(Dispatchers.IO) {
        try {
            val entity = KiddingEntity(
                id = kidding.id,
                doe_id_c = kidding.doe_id_c,
                pregnancy_id_c = kidding.pregnancy_id_c,
                kidding_date_c = kidding.kidding_date_c,
                birth_type_c = kidding.birth_type_c,
                assistance_c = kidding.assistance_c,
                complications_c = kidding.complications_c,
                notes_c = kidding.notes_c,
                is_synced = false
            )
            database.breedingDao().insertKidding(entity)

            // Update doe status to Lactating locally
            database.goatDao().updateStatus(kidding.doe_id_c, "Lactating")

            val json = JSONObject().apply {
                put("id", kidding.id)
                put("doe_id_c", kidding.doe_id_c)
                if (!kidding.pregnancy_id_c.isNullOrBlank()) put("pregnancy_id_c", kidding.pregnancy_id_c)
                put("kidding_date_c", kidding.kidding_date_c)
                put("birth_type_c", kidding.birth_type_c)
                put("assistance_c", kidding.assistance_c)
                put("complications_c", kidding.complications_c)
                if (!kidding.notes_c.isNullOrBlank()) put("notes_c", kidding.notes_c)
            }
            syncManager.enqueueOperation("kidding_records_c", kidding.id, "CREATE", json)
            syncManager.enqueueOperation("goats_c", kidding.doe_id_c, "UPDATE", JSONObject().put("status_c", "Lactating"))

            // Also record kids and create initial weaning records
            val dam = database.goatDao().getGoatById(kidding.doe_id_c)
            val defaultDays = database.farmSettingsDao().getSetting("weaning_default_days")?.value_c?.toIntOrNull() ?: 90
            for (kid in kids) {
                recordKid(kid)

                // Ensure registered in local_goats
                val existing = database.goatDao().getGoatByTag(kid.kid_tag_c)
                val kidId = existing?.id ?: UUID.randomUUID().toString()
                if (existing == null) {
                    val newborn = Goat(
                        id = kidId,
                        name = "Kid ${kid.kid_tag_c}",
                        tag_c = kid.kid_tag_c,
                        breed_c = dam?.breed_c ?: "Boer",
                        sex_c = kid.sex_c.ifBlank { "Doe" },
                        status_c = if (kid.birth_status_c.equals("Stillborn", ignoreCase = true)) "Dead" else "Active",
                        birth_date_c = kidding.kidding_date_c,
                        weight_kg_c = kid.birth_weight_c,
                        dam_c = dam?.tag_c ?: kidding.doe_id_c,
                        sire_c = kidding.sire_id_c,
                        dam_id = dam?.id ?: kidding.doe_id_c,
                        sire_id = kidding.sire_id_c,
                        source_c = "Born on farm",
                        origin_c = "FARM_BORN"
                    )
                    addGoat(newborn)
                }

                // If alive, create weaning record
                if (!kid.birth_status_c.equals("Stillborn", ignoreCase = true)) {
                    val cal = java.util.Calendar.getInstance().apply {
                        time = try { dateFormat.parse(kidding.kidding_date_c) ?: Date() } catch (_: Exception) { Date() }
                        add(java.util.Calendar.DAY_OF_YEAR, defaultDays)
                    }
                    val dueDateStr = dateFormat.format(cal.time)
                    val nowStr = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())

                    val weaningRec = com.example.data.offline.WeaningRecordEntity(
                        id = UUID.randomUUID().toString(),
                        farm_id = "default_farm",
                        goat_id = kidId,
                        mother_goat_id = dam?.id ?: kidding.doe_id_c,
                        kidding_id = kidding.id,
                        birth_date = kidding.kidding_date_c,
                        weaning_due_date = dueDateStr,
                        status = "PLANNED",
                        setting_source = "FARM_DEFAULT",
                        post_weaning_feed_group = "WEANED KID / GROWING KID",
                        birth_weight = kid.birth_weight_c,
                        prev_weight = kid.birth_weight_c,
                        created_at = nowStr,
                        updated_at = System.currentTimeMillis()
                    )
                    database.weaningDao().insertWeaningRecord(weaningRec)
                }
            }

            Result.success(kidding)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getKiddings(): Result<List<KiddingRecord>> = withContext(Dispatchers.IO) {
        try {
            val list = database.breedingDao().getAllKiddings().map {
                KiddingRecord(
                    id = it.id,
                    doe_id_c = it.doe_id_c,
                    pregnancy_id_c = it.pregnancy_id_c,
                    kidding_date_c = it.kidding_date_c,
                    birth_type_c = it.birth_type_c,
                    assistance_c = it.assistance_c,
                    complications_c = it.complications_c,
                    notes_c = it.notes_c
                )
            }
            Result.success(list)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun recordKid(kid: KidRecord): Result<KidRecord> = withContext(Dispatchers.IO) {
        try {
            val entity = KidEntity(
                id = kid.id,
                kid_tag_c = kid.kid_tag_c,
                kidding_record_id_c = kid.kidding_record_id_c,
                birth_weight_c = kid.birth_weight_c,
                birth_order_c = kid.birth_order_c,
                notes_c = kid.notes_c,
                is_synced = false
            )
            database.breedingDao().insertKid(entity)

            val json = JSONObject().apply {
                put("id", kid.id)
                put("kid_tag_c", kid.kid_tag_c)
                put("kidding_record_id_c", kid.kidding_record_id_c)
                if (kid.birth_weight_c != null) put("birth_weight_c", kid.birth_weight_c)
                put("birth_order_c", kid.birth_order_c)
                if (!kid.notes_c.isNullOrBlank()) put("notes_c", kid.notes_c)
            }
            syncManager.enqueueOperation("kids_c", kid.id, "CREATE", json)

            Result.success(kid)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getKids(): Result<List<KidRecord>> = withContext(Dispatchers.IO) {
        try {
            val list = database.breedingDao().getAllKids().map {
                KidRecord(
                    id = it.id,
                    kid_tag_c = it.kid_tag_c,
                    kidding_record_id_c = it.kidding_record_id_c,
                    birth_weight_c = it.birth_weight_c,
                    birth_order_c = it.birth_order_c,
                    notes_c = it.notes_c
                )
            }
            Result.success(list)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun recordKiddingAndRegisterNewborns(
        kidding: KiddingRecord,
        kids: List<KidRecord>,
        autoRegisterInHerd: Boolean = true
    ): Result<KiddingRecord> = withContext(Dispatchers.IO) {
        try {
            val res = recordKidding(kidding, kids)
            if (res.isFailure) return@withContext res

            if (autoRegisterInHerd) {
                val dam = database.goatDao().getGoatById(kidding.doe_id_c)
                val sire = if (!kidding.sire_id_c.isNullOrBlank()) database.goatDao().getGoatById(kidding.sire_id_c) else null
                for (kid in kids) {
                    val existing = database.goatDao().getGoatByTag(kid.kid_tag_c)
                    if (existing == null) {
                        val newborn = Goat(
                            name = "Kid ${kid.kid_tag_c}",
                            tag_c = kid.kid_tag_c,
                            breed_c = dam?.breed_c ?: "Boer",
                            sex_c = kid.sex_c,
                            status_c = if (kid.birth_status_c.equals("Stillborn", ignoreCase = true)) "Dead" else "Active",
                            birth_date_c = kidding.kidding_date_c,
                            weight_kg_c = kid.birth_weight_c,
                            dam_c = dam?.tag_c ?: kidding.doe_id_c,
                            sire_c = sire?.tag_c ?: kidding.sire_id_c,
                            dam_id = dam?.id ?: kidding.doe_id_c,
                            sire_id = sire?.id ?: kidding.sire_id_c,
                            source_c = "Born on farm",
                            origin_c = "FARM_BORN",
                            photo_url_c = kid.photo_url_c
                        )
                        addGoat(newborn)
                    }
                }
            }
            res
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // ==========================================
    // MILK PRODUCTION
    // ==========================================

    suspend fun recordMilk(record: MilkRecord): Result<MilkRecord> = withContext(Dispatchers.IO) {
        try {
            val entity = MilkRecordEntity(
                id = record.id,
                goat_id_c = record.goat_id_c,
                date_c = record.date_c,
                morning_milk_ltr_c = record.morning_milk_ltr_c,
                evening_milk_ltr_c = record.evening_milk_ltr_c,
                total_milk_ltr_c = record.total_milk_ltr_c,
                fat_percentage_c = record.fat_percentage_c,
                notes_c = record.notes_c,
                is_synced = false
            )
            database.milkDao().insertMilkRecord(entity)

            val json = JSONObject().apply {
                put("id", record.id)
                put("goat_id_c", record.goat_id_c)
                put("date_c", record.date_c)
                put("morning_milk_ltr_c", record.morning_milk_ltr_c)
                put("evening_milk_ltr_c", record.evening_milk_ltr_c)
                put("total_milk_ltr_c", record.total_milk_ltr_c)
                if (record.fat_percentage_c != null) put("fat_percentage_c", record.fat_percentage_c)
                if (!record.notes_c.isNullOrBlank()) put("notes_c", record.notes_c)
            }
            syncManager.enqueueOperation("milk_records_c", record.id, "CREATE", json)
            recordAuditLog(AuditLogEntry(
                action_c = "CREATE",
                entity_c = "MILK",
                record_id_c = record.id,
                details_c = "Logged ${record.total_milk_ltr_c}L milk for goat ${record.goat_id_c}"
            ))
            Result.success(record)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getMilkRecords(goatId: String? = null): Result<List<MilkRecord>> = withContext(Dispatchers.IO) {
        try {
            val entities = if (goatId.isNullOrBlank()) {
                database.milkDao().getAllMilkRecords()
            } else {
                database.milkDao().getMilkRecordsForGoat(goatId)
            }
            val list = entities.map {
                MilkRecord(
                    id = it.id,
                    goat_id_c = it.goat_id_c,
                    date_c = it.date_c,
                    morning_milk_ltr_c = it.morning_milk_ltr_c,
                    evening_milk_ltr_c = it.evening_milk_ltr_c,
                    total_milk_ltr_c = it.total_milk_ltr_c,
                    fat_percentage_c = it.fat_percentage_c,
                    notes_c = it.notes_c
                )
            }
            Result.success(list)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // ==========================================
    // FARM FINANCE & TRANSACTIONS
    // ==========================================

    suspend fun recordFinanceTransaction(transaction: FinanceTransaction): Result<FinanceTransaction> = withContext(Dispatchers.IO) {
        try {
            val entity = TransactionEntity(
                id = transaction.id,
                transaction_type_c = transaction.type_c,
                amount_c = transaction.amount_c,
                date_c = transaction.date_c,
                category_c = transaction.category_c,
                description_c = transaction.description_c,
                payment_mode_c = transaction.payment_mode_c,
                payment_status_c = "Received",
                related_id_c = transaction.reference_id_c,
                is_synced = false
            )
            database.transactionDao().insertTransaction(entity)

            val json = JSONObject().apply {
                put("id", transaction.id)
                put("transaction_type_c", transaction.type_c)
                put("amount_c", transaction.amount_c)
                put("date_c", transaction.date_c)
                put("category_c", transaction.category_c)
                if (!transaction.description_c.isNullOrBlank()) put("description_c", transaction.description_c)
                put("payment_mode_c", transaction.payment_mode_c)
                if (!transaction.reference_id_c.isNullOrBlank()) put("related_id_c", transaction.reference_id_c)
            }
            syncManager.enqueueOperation("transactions_c", transaction.id, "CREATE", json)
            recordAuditLog(AuditLogEntry(
                action_c = "CREATE",
                entity_c = "FINANCE",
                record_id_c = transaction.id,
                details_c = "${transaction.type_c} of ₹${transaction.amount_c} for ${transaction.category_c}"
            ))
            Result.success(transaction)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getFinanceTransactions(): Result<List<FinanceTransaction>> = withContext(Dispatchers.IO) {
        try {
            val entities = database.transactionDao().getAllTransactions()
            val list = entities.map {
                FinanceTransaction(
                    id = it.id,
                    type_c = it.transaction_type_c,
                    category_c = it.category_c ?: "Other",
                    amount_c = it.amount_c,
                    date_c = it.date_c,
                    reference_id_c = it.related_id_c,
                    payment_mode_c = it.payment_mode_c,
                    description_c = it.description_c
                )
            }
            Result.success(list)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun deleteFinanceTransaction(id: String): Result<Boolean> = withContext(Dispatchers.IO) {
        try {
            database.transactionDao().deleteById(id)
            syncManager.enqueueOperation("transactions_c", id, "DELETE", JSONObject().put("id", id))
            recordAuditLog(AuditLogEntry(
                action_c = "DELETE",
                entity_c = "FINANCE",
                record_id_c = id,
                details_c = "Deleted transaction $id"
            ))
            Result.success(true)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getFarmFinanceSummary(): Result<FarmFinanceSummary> = withContext(Dispatchers.IO) {
        try {
            val transactions = database.transactionDao().getAllTransactions()
            val sales = database.salesDao().getAllSales()
            val milkRecords = database.milkDao().getAllMilkRecords()
            val treatments = database.healthDao().getAllTreatments()

            // 1. Goat sales income: Paid sales
            val paidSalesAmount = sales
                .filter { com.example.data.payment.PaymentStatus.isPaid(it.payment_status_c) }
                .sumOf { if (it.amount_paid_c > 0.0) it.amount_paid_c else it.amount_c }

            val recordedSaleIds = sales.map { it.id }.toSet()

            var additionalGoatSalesIncome = 0.0
            var manureSalesIncome = 0.0
            var milkSalesIncome = 0.0
            var otherIncome = 0.0

            var feedExpenses = 0.0
            var medicineExpenses = 0.0
            var veterinaryExpenses = 0.0
            var labourExpenses = 0.0
            var otherExpenses = 0.0

            for (tx in transactions) {
                // CRITICAL ACCOUNTING RULE: Internal transfers NEVER affect Profit & Loss
                if (tx.transaction_type_c.equals("TRANSFER", ignoreCase = true) ||
                    tx.transaction_type_c.equals("CONTRA", ignoreCase = true) ||
                    tx.transaction_type_c.equals("INTERNAL_TRANSFER", ignoreCase = true) ||
                    (tx.category_c ?: "").contains("Transfer", ignoreCase = true)) {
                    continue
                }

                val isIncome = tx.transaction_type_c.equals("INCOME", ignoreCase = true) ||
                        tx.transaction_type_c.equals("Sale", ignoreCase = true)
                val cat = (tx.category_c ?: "").lowercase()

                if (isIncome) {
                    when {
                        cat.contains("manure") || cat.contains("dung") || cat.contains("compost") -> manureSalesIncome += tx.amount_c
                        cat.contains("milk") -> milkSalesIncome += tx.amount_c
                        cat.contains("goat") -> {
                            if (tx.related_id_c == null || !recordedSaleIds.contains(tx.related_id_c)) {
                                additionalGoatSalesIncome += tx.amount_c
                            }
                        }
                        else -> otherIncome += tx.amount_c
                    }
                } else {
                    when {
                        cat.contains("feed") || cat.contains("fodder") -> feedExpenses += tx.amount_c
                        cat.contains("med") -> medicineExpenses += tx.amount_c
                        cat.contains("vet") -> veterinaryExpenses += tx.amount_c
                        cat.contains("labour") || cat.contains("labor") || cat.contains("wage") -> labourExpenses += tx.amount_c
                        else -> otherExpenses += tx.amount_c
                    }
                }
            }

            // Also aggregate account transactions that affect P&L (strictly skipping transfers)
            val accountTxns = database.accountTransactionDao().getAllTransactions()
            for (atx in accountTxns) {
                if (!atx.affects_pnl || atx.transaction_type.equals("TRANSFER", ignoreCase = true)) {
                    continue
                }
                val isIncome = atx.transaction_type.equals("INCOME", ignoreCase = true) ||
                        atx.transaction_type.equals("CUSTOMER_RECEIPT", ignoreCase = true)
                val cat = atx.category.lowercase()
                if (isIncome) {
                    when {
                        cat.contains("manure") || cat.contains("dung") || cat.contains("compost") -> manureSalesIncome += atx.amount
                        cat.contains("milk") -> milkSalesIncome += atx.amount
                        cat.contains("goat") -> additionalGoatSalesIncome += atx.amount
                        else -> otherIncome += atx.amount
                    }
                } else {
                    when {
                        cat.contains("feed") || cat.contains("fodder") -> feedExpenses += atx.amount
                        cat.contains("med") -> medicineExpenses += atx.amount
                        cat.contains("vet") -> veterinaryExpenses += atx.amount
                        cat.contains("labour") || cat.contains("labor") || cat.contains("wage") -> labourExpenses += atx.amount
                        else -> otherExpenses += atx.amount
                    }
                }
            }

            val totalGoatSales = paidSalesAmount + additionalGoatSalesIncome
            val totalIncome = totalGoatSales + manureSalesIncome + milkSalesIncome + otherIncome
            val totalExpenses = feedExpenses + medicineExpenses + veterinaryExpenses + labourExpenses + otherExpenses
            val netProfit = totalIncome - totalExpenses
            val netCashFlow = totalIncome - totalExpenses
            val totalMilkLiters = milkRecords.sumOf { it.total_milk_ltr_c }

            Result.success(
                FarmFinanceSummary(
                    totalIncome = totalIncome,
                    goatSalesIncome = totalGoatSales,
                    manureSalesIncome = manureSalesIncome,
                    milkSalesIncome = milkSalesIncome,
                    otherIncome = otherIncome,
                    totalExpenses = totalExpenses,
                    feedExpenses = feedExpenses,
                    medicineExpenses = medicineExpenses,
                    veterinaryExpenses = veterinaryExpenses,
                    labourExpenses = labourExpenses,
                    otherExpenses = otherExpenses,
                    netProfit = netProfit,
                    netCashFlow = netCashFlow,
                    isProfitable = netProfit >= 0.0,
                    totalTransactions = transactions.size + sales.size,
                    totalMilkLiters = totalMilkLiters
                )
            )
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // ==========================================
    // AUDIT LOG
    // ==========================================

    suspend fun recordAuditLog(entry: AuditLogEntry): Result<AuditLogEntry> = withContext(Dispatchers.IO) {
        try {
            val entity = AuditLogEntity(
                id = entry.id,
                user_email_c = entry.user_email_c,
                action_c = entry.action_c,
                entity_c = entry.entity_c,
                record_id_c = entry.record_id_c,
                details_c = entry.details_c,
                timestamp_c = entry.timestamp_c
            )
            database.auditLogDao().insertLog(entity)
            Result.success(entry)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getAuditLogs(limit: Int = 100): Result<List<AuditLogEntry>> = withContext(Dispatchers.IO) {
        try {
            val list = database.auditLogDao().getRecentLogs(limit).map {
                AuditLogEntry(
                    id = it.id,
                    user_email_c = it.user_email_c,
                    action_c = it.action_c,
                    entity_c = it.entity_c,
                    record_id_c = it.record_id_c,
                    details_c = it.details_c,
                    timestamp_c = it.timestamp_c
                )
            }
            Result.success(list)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // ==========================================
    // CHRONOLOGICAL GOAT TIMELINE
    // ==========================================

    suspend fun getGoatTimelineEvents(goatId: String): Result<List<FarmTimelineEvent>> = withContext(Dispatchers.IO) {
        try {
            val events = mutableListOf<FarmTimelineEvent>()

            // 1. Birth event
            val goat = database.goatDao().getGoatById(goatId)
            if (goat != null && !goat.birth_date_c.isNullOrBlank()) {
                events.add(FarmTimelineEvent(
                    id = "birth_${goat.id}",
                    date = goat.birth_date_c,
                    type = "BIRTH",
                    title = "Born",
                    subtitle = "Origin: ${goat.effectiveOrigin} • Breed: ${goat.breed_c}",
                    details = "Dam: ${goat.dam_c ?: "Unknown"} • Sire: ${goat.sire_c ?: "Unknown"}",
                    referenceId = goat.id
                ))
            }

            // 2. Weights
            val weights = database.healthDao().getWeightsByGoat(goatId)
            weights.forEach { w ->
                events.add(FarmTimelineEvent(
                    id = "w_${w.id}",
                    date = w.date_c,
                    type = "WEIGHT",
                    title = "Weight Recorded",
                    subtitle = "${w.weight_kg_c} kg",
                    details = if (!w.notes_c.isNullOrBlank()) "Note: ${w.notes_c}" else null,
                    referenceId = w.id
                ))
            }

            // 3. Vaccinations
            val vacs = database.healthDao().getVaccinationsByGoat(goatId)
            vacs.forEach { v ->
                events.add(FarmTimelineEvent(
                    id = "v_${v.id}",
                    date = v.administered_date_c,
                    type = "VACCINATION",
                    title = "Vaccinated",
                    subtitle = v.vaccine_c,
                    details = "Dose: ${v.dose_c}${if (!v.next_due_date_c.isNullOrBlank()) " • Next Due: ${v.next_due_date_c}" else ""}",
                    referenceId = v.id
                ))
            }

            // 4. Dewormings
            val deworms = database.healthDao().getDewormingsByGoat(goatId)
            deworms.forEach { d ->
                events.add(FarmTimelineEvent(
                    id = "d_${d.id}",
                    date = d.treatment_date_c,
                    type = "DEWORMING",
                    title = "Dewormed",
                    subtitle = d.medicine_c,
                    details = "Dose: ${d.dose_c}${if (!d.next_due_date_c.isNullOrBlank()) " • Next Due: ${d.next_due_date_c}" else ""}",
                    referenceId = d.id
                ))
            }

            // 5. Treatments
            val treatments = database.healthDao().getTreatmentsByGoat(goatId)
            treatments.forEach { t ->
                events.add(FarmTimelineEvent(
                    id = "t_${t.id}",
                    date = t.start_date_c,
                    type = "TREATMENT",
                    title = "Medical Treatment",
                    subtitle = t.diagnosis_c.ifBlank { t.symptoms_c },
                    details = "Medicine: ${t.medicine_c} • Outcome: ${t.outcome_c}",
                    referenceId = t.id
                ))
            }

            // 6. Matings
            val matings = database.breedingDao().getAllMatings().filter { it.doe_id_c == goatId || it.buck_id_c == goatId }
            matings.forEach { m ->
                val isDoe = m.doe_id_c == goatId
                events.add(FarmTimelineEvent(
                    id = "m_${m.id}",
                    date = m.mating_date_c,
                    type = "MATING",
                    title = "Mating Service",
                    subtitle = if (isDoe) "Mated with Buck ID: ${m.buck_id_c}" else "Serviced Doe ID: ${m.doe_id_c}",
                    details = "Method: ${m.method_c}",
                    referenceId = m.id
                ))
            }

            // 7. Pregnancies
            val pregnancies = database.breedingDao().getAllPregnancies().filter { it.doe_id_c == goatId }
            pregnancies.forEach { p ->
                events.add(FarmTimelineEvent(
                    id = "p_${p.id}",
                    date = p.confirmation_date_c,
                    type = "PREGNANCY",
                    title = "Pregnancy Confirmed",
                    subtitle = "Status: ${p.status_c}",
                    details = "Expected Kidding: ${p.expected_kidding_date_c}",
                    referenceId = p.id
                ))
            }

            // 8. Kiddings
            val kiddings = database.breedingDao().getAllKiddings().filter { it.doe_id_c == goatId }
            kiddings.forEach { k ->
                events.add(FarmTimelineEvent(
                    id = "k_${k.id}",
                    date = k.kidding_date_c,
                    type = "KIDDING",
                    title = "Delivered Kids",
                    subtitle = "Type: ${k.birth_type_c}",
                    details = if (!k.notes_c.isNullOrBlank()) k.notes_c else null,
                    referenceId = k.id
                ))
            }

            // 9. Milk
            val milks = database.milkDao().getMilkRecordsForGoat(goatId)
            milks.forEach { ml ->
                events.add(FarmTimelineEvent(
                    id = "milk_${ml.id}",
                    date = ml.date_c,
                    type = "MILK",
                    title = "Milk Yield",
                    subtitle = "${ml.total_milk_ltr_c} L",
                    details = "AM: ${ml.morning_milk_ltr_c}L • PM: ${ml.evening_milk_ltr_c}L",
                    referenceId = ml.id
                ))
            }

            // 10. Sales
            val sales = database.salesDao().getAllSales().filter { it.goat_id_c == goatId }
            sales.forEach { s ->
                events.add(FarmTimelineEvent(
                    id = "sale_${s.id}",
                    date = s.sale_date_c,
                    type = "SALE",
                    title = "Sold to Buyer",
                    subtitle = "₹${s.amount_c} (${s.payment_status_c})",
                    details = "Buyer: ${s.buyer_name_c}",
                    referenceId = s.id
                ))
            }

            events.sortByDescending { it.date }
            Result.success(events)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // ==========================================
    // FEED & MEDICINE
    // ==========================================

    suspend fun getFeedInventory(): Result<List<FeedItem>> = withContext(Dispatchers.IO) {
        try {
            var entities = database.inventoryDao().getAllFeedItems()
            if (entities.isEmpty()) {
                val defaults = listOf(
                    FeedItemEntity(
                        name_c = "Super Napier (Green Fodder)",
                        category_c = "Green Fodder",
                        current_stock_kg_c = 450.0,
                        unit_c = "kg",
                        cost_per_unit_c = 2.5
                    ),
                    FeedItemEntity(
                        name_c = "Lucerne / Alfalfa Hay (Dry Fodder)",
                        category_c = "Dry Fodder",
                        current_stock_kg_c = 180.0,
                        unit_c = "kg",
                        cost_per_unit_c = 18.0
                    ),
                    FeedItemEntity(
                        name_c = "Goat Grower Pellets (16% CP)",
                        category_c = "Concentrate",
                        current_stock_kg_c = 120.0,
                        unit_c = "kg",
                        cost_per_unit_c = 28.5
                    ),
                    FeedItemEntity(
                        name_c = "Cracked Maize / Corn Grain",
                        category_c = "Grains",
                        current_stock_kg_c = 95.0,
                        unit_c = "kg",
                        cost_per_unit_c = 22.0
                    ),
                    FeedItemEntity(
                        name_c = "Mineral Mixture & Salt Lick",
                        category_c = "Supplements",
                        current_stock_kg_c = 25.0,
                        unit_c = "kg",
                        cost_per_unit_c = 65.0
                    )
                )
                database.inventoryDao().insertAllFeedItems(defaults)
                entities = database.inventoryDao().getAllFeedItems()

                // Add sample daily usage log for today
                val todayStr = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
                val sampleMovements = listOf(
                    FeedMovementEntity(
                        feed_id_c = entities[0].id,
                        movement_type_c = "Consumption",
                        quantity_c = 35.0,
                        date_c = todayStr,
                        notes_c = "Morning green feeding for milking does"
                    ),
                    FeedMovementEntity(
                        feed_id_c = entities[2].id,
                        movement_type_c = "Consumption",
                        quantity_c = 12.0,
                        date_c = todayStr,
                        notes_c = "Grower pellet ration for kids pen"
                    )
                )
                database.inventoryDao().insertAllFeedMovements(sampleMovements)
            }

            val list = entities.map {
                FeedItem(
                    id = it.id,
                    name_c = it.name_c,
                    category_c = it.category_c,
                    current_stock_kg_c = it.current_stock_kg_c,
                    unit_c = it.unit_c,
                    cost_per_unit_c = it.cost_per_unit_c
                )
            }
            Result.success(list)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun getFeedInventoryFlow(): Flow<List<FeedItem>> =
        database.inventoryDao().getAllFeedItemsFlow().map { list ->
            list.map {
                FeedItem(
                    id = it.id,
                    name_c = it.name_c,
                    category_c = it.category_c,
                    current_stock_kg_c = it.current_stock_kg_c,
                    unit_c = it.unit_c,
                    cost_per_unit_c = it.cost_per_unit_c
                )
            }
        }

    fun getFeedMovementsFlow(): Flow<List<FeedMovement>> =
        database.inventoryDao().getAllFeedMovementsFlow().map { list ->
            list.map {
                FeedMovement(
                    id = it.id,
                    feed_id_c = it.feed_id_c,
                    movement_type_c = it.movement_type_c,
                    quantity_c = it.quantity_c,
                    date_c = it.date_c,
                    notes_c = it.notes_c
                )
            }
        }

    suspend fun saveFeedItem(feed: FeedItem): Result<FeedItem> = withContext(Dispatchers.IO) {
        try {
            val entity = FeedItemEntity(
                id = feed.id,
                name_c = feed.name_c,
                category_c = feed.category_c ?: "Concentrate",
                current_stock_kg_c = feed.current_stock_kg_c,
                unit_c = feed.unit_c,
                cost_per_unit_c = feed.cost_per_unit_c,
                updated_at = System.currentTimeMillis(),
                is_synced = false
            )
            database.inventoryDao().insertFeedItem(entity)

            val json = JSONObject().apply {
                put("id", feed.id)
                put("name_c", feed.name_c)
                put("category_c", feed.category_c)
                put("current_stock_kg_c", feed.current_stock_kg_c)
                put("unit_c", feed.unit_c)
                if (feed.cost_per_unit_c != null) put("cost_per_unit_c", feed.cost_per_unit_c)
            }
            syncManager.enqueueOperation("feed_inventory_c", feed.id, "UPSERT", json)
            Result.success(feed)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun deleteFeedItem(id: String): Result<Boolean> = withContext(Dispatchers.IO) {
        try {
            database.inventoryDao().deleteFeedItemById(id)
            val json = JSONObject().apply { put("id", id) }
            syncManager.enqueueOperation("feed_inventory_c", id, "DELETE", json)
            Result.success(true)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getFeedMovements(feedId: String? = null): Result<List<FeedMovement>> = withContext(Dispatchers.IO) {
        try {
            val list = (if (feedId != null) {
                database.inventoryDao().getAllFeedMovements().filter { it.feed_id_c == feedId }
            } else {
                database.inventoryDao().getAllFeedMovements()
            }).map {
                FeedMovement(
                    id = it.id,
                    feed_id_c = it.feed_id_c,
                    movement_type_c = it.movement_type_c,
                    quantity_c = it.quantity_c,
                    date_c = it.date_c,
                    notes_c = it.notes_c
                )
            }
            Result.success(list)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun deleteFeedMovement(id: String): Result<Boolean> = withContext(Dispatchers.IO) {
        try {
            database.inventoryDao().deleteFeedMovementById(id)
            Result.success(true)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun addFeedMovement(movement: FeedMovement): Result<FeedMovement> = withContext(Dispatchers.IO) {
        try {
            val entity = FeedMovementEntity(
                id = movement.id,
                feed_id_c = movement.feed_id_c,
                movement_type_c = movement.movement_type_c,
                quantity_c = movement.quantity_c,
                date_c = movement.date_c,
                notes_c = movement.notes_c,
                is_synced = false
            )
            database.inventoryDao().insertFeedMovement(entity)

            // Update feed inventory stock locally
            val feedItem = database.inventoryDao().getFeedItemById(movement.feed_id_c)
            if (feedItem != null) {
                val stockDelta = when (movement.movement_type_c) {
                    "Purchase" -> movement.quantity_c
                    "Adjustment" -> movement.quantity_c
                    else -> -movement.quantity_c
                }
                val newStock = (feedItem.current_stock_kg_c + stockDelta).coerceAtLeast(0.0)
                database.inventoryDao().updateFeedStock(feedItem.id, newStock)

                val updateStockJson = JSONObject().apply {
                    put("current_stock_kg_c", newStock)
                }
                syncManager.enqueueOperation("feed_inventory_c", feedItem.id, "UPDATE", updateStockJson)
            }

            val json = JSONObject().apply {
                put("id", movement.id)
                put("feed_id_c", movement.feed_id_c)
                put("movement_type_c", movement.movement_type_c)
                put("quantity_c", movement.quantity_c)
                put("date_c", movement.date_c)
                if (!movement.notes_c.isNullOrBlank()) put("notes_c", movement.notes_c)
            }
            syncManager.enqueueOperation("feed_movements_c", movement.id, "CREATE", json)

            Result.success(movement)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun recordFeedMovement(movement: FeedMovement): Result<FeedMovement> = addFeedMovement(movement)

    suspend fun getMedicines(): Result<List<MedicineItem>> = withContext(Dispatchers.IO) {
        try {
            val list = database.inventoryDao().getAllMedicines().map {
                MedicineItem(
                    id = it.id,
                    medicine_name_c = it.medicine_name_c,
                    category_c = it.category_c,
                    quantity_c = it.quantity_c,
                    unit_c = it.unit_c,
                    reorder_level_c = it.reorder_level_c,
                    unit_cost_c = it.unit_cost_c,
                    expiry_date_c = it.expiry_date_c,
                    supplier_c = it.supplier_c
                )
            }
            Result.success(list)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getMedicineInventory(): Result<List<MedicineItem>> = getMedicines()

    // ==========================================
    // TASKS
    // ==========================================

    suspend fun getTasks(): Result<List<FarmTask>> = withContext(Dispatchers.IO) {
        try {
            val list = database.tasksDao().getAllTasks().map {
                FarmTask(
                    id = it.id,
                    title_c = it.title_c,
                    description_c = it.description_c,
                    due_date_c = it.due_date_c,
                    priority_c = it.priority_c,
                    status_c = it.status_c,
                    assigned_to_c = it.assigned_to_c,
                    related_goat_id_c = it.related_goat_id_c
                )
            }
            Result.success(list)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun updateTaskStatus(taskId: String, completed: Boolean): Result<Boolean> = withContext(Dispatchers.IO) {
        try {
            val status = if (completed) "Completed" else "Pending"
            database.tasksDao().updateTaskStatus(taskId, status)

            val json = JSONObject().apply {
                put("status_c", status)
            }
            syncManager.enqueueOperation("tasks_c", taskId, "UPDATE", json)

            Result.success(true)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun addTask(task: FarmTask): Result<FarmTask> = withContext(Dispatchers.IO) {
        try {
            val entity = TaskEntity(
                id = task.id,
                title_c = task.title_c,
                description_c = task.description_c,
                due_date_c = task.due_date_c,
                priority_c = task.priority_c,
                status_c = task.status_c,
                assigned_to_c = task.assigned_to_c,
                related_goat_id_c = task.related_goat_id_c,
                is_synced = false
            )
            database.tasksDao().insertOrUpdate(entity)

            val json = JSONObject().apply {
                put("id", task.id)
                put("title_c", task.title_c)
                if (!task.description_c.isNullOrBlank()) put("description_c", task.description_c)
                put("due_date_c", task.due_date_c)
                put("priority_c", task.priority_c)
                put("status_c", task.status_c)
                if (!task.assigned_to_c.isNullOrBlank()) put("assigned_to_c", task.assigned_to_c)
                if (!task.related_goat_id_c.isNullOrBlank()) put("related_goat_id_c", task.related_goat_id_c)
            }
            syncManager.enqueueOperation("tasks_c", task.id, "CREATE", json)

            Result.success(task)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // ==========================================
    // TODAY'S DUE & DASHBOARD SUMMARY
    // ==========================================

    suspend fun getDueItems(): Result<List<QuickDueItem>> = withContext(Dispatchers.IO) {
        try {
            val dueList = mutableListOf<QuickDueItem>()
            val today = Date()

            val goats = database.goatDao().getAllGoats().associateBy { it.id }

            // Vaccinations due
            val vacs = database.healthDao().getAllVaccinations()
            for (v in vacs) {
                if (!v.next_due_date_c.isNullOrBlank()) {
                    val days = calculateDaysDiff(v.next_due_date_c, today)
                    val goat = goats[v.goat_id_c]
                    dueList.add(
                        QuickDueItem(
                            id = v.id,
                            goat_id_c = v.goat_id_c,
                            goat_tag = goat?.tag_c ?: "Goat",
                            goat_name = goat?.name ?: "",
                            record_type = "Vaccination",
                            detail = "${v.vaccine_c} booster due",
                            due_date = v.next_due_date_c,
                            days_diff = days
                        )
                    )
                }
            }

            // Dewormings due
            val deworms = database.healthDao().getAllDewormings()
            for (d in deworms) {
                if (!d.next_due_date_c.isNullOrBlank()) {
                    val days = calculateDaysDiff(d.next_due_date_c, today)
                    val goat = goats[d.goat_id_c]
                    dueList.add(
                        QuickDueItem(
                            id = d.id,
                            goat_id_c = d.goat_id_c,
                            goat_tag = goat?.tag_c ?: "Goat",
                            goat_name = goat?.name ?: "",
                            record_type = "Deworming",
                            detail = "${d.medicine_c} treatment due",
                            due_date = d.next_due_date_c,
                            days_diff = days
                        )
                    )
                }
            }

            // Pregnancies
            val pregs = database.breedingDao().getAllPregnancies()
            for (p in pregs) {
                if (p.status_c.equals("Confirmed", ignoreCase = true) && !p.expected_kidding_date_c.isNullOrBlank()) {
                    val days = calculateDaysDiff(p.expected_kidding_date_c, today)
                    val goat = goats[p.doe_id_c]
                    dueList.add(
                        QuickDueItem(
                            id = p.id,
                            goat_id_c = p.doe_id_c,
                            goat_tag = goat?.tag_c ?: "Doe",
                            goat_name = goat?.name ?: "",
                            record_type = "Expected Kidding",
                            detail = "Kidding expected (${p.expected_kidding_date_c})",
                            due_date = p.expected_kidding_date_c,
                            days_diff = days
                        )
                    )
                }
            }

            dueList.sortBy { it.days_diff }
            Result.success(dueList)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getDashboardSummary(): Result<DashboardSummary> = withContext(Dispatchers.IO) {
        try {
            val goats = database.goatDao().getAllGoats()
            val totalGoats = goats.size
            val bucks = goats.count { it.sex_c.equals("Buck", ignoreCase = true) }
            val does = goats.count { it.sex_c.equals("Doe", ignoreCase = true) }
            val kids = goats.count { it.sex_c.equals("Kid", ignoreCase = true) || it.status_c.equals("Kid", ignoreCase = true) }
            val pregnantDoes = goats.count { it.status_c.equals("Pregnant", ignoreCase = true) }

            val dueItems = getDueItems().getOrDefault(emptyList())
            val vacDue = dueItems.count { it.record_type == "Vaccination" && it.days_diff <= 7 }
            val dewDue = dueItems.count { it.record_type == "Deworming" && it.days_diff <= 7 }

            val tasks = database.tasksDao().getAllTasks()
            val todayStr = dateFormat.format(Date())
            val todayTasks = tasks.count {
                it.status_c == "Pending" && (it.due_date_c <= todayStr || it.due_date_c.isEmpty())
            }

            val sales = database.salesDao().getAllSales()
            val totalSales = sales
                .filter { com.example.data.payment.PaymentStatus.isPaid(it.payment_status_c) }
                .sumOf { it.amount_c }

            val financeSummary = getFarmFinanceSummary().getOrDefault(FarmFinanceSummary())

            Result.success(
                DashboardSummary(
                    totalGoats = totalGoats,
                    bucks = bucks,
                    does = does,
                    kids = kids,
                    pregnantDoes = pregnantDoes,
                    vaccinationsDue = vacDue,
                    dewormingDue = dewDue,
                    todayTasks = todayTasks,
                    totalSales = totalSales,
                    financeSummary = financeSummary
                )
            )
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // ==========================================
    // SALES (OFFLINE-FIRST)
    // ==========================================

    suspend fun getSales(): Result<List<SaleRecord>> = withContext(Dispatchers.IO) {
        try {
            val list = database.salesDao().getAllSales().map { it.toDomain() }
            Result.success(list)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun recordSale(sale: SaleRecord): Result<SaleRecord> = withContext(Dispatchers.IO) {
        try {
            val normalizedMode = com.example.data.payment.PaymentMethod.normalize(sale.payment_mode_c)
            val isCash = normalizedMode == com.example.data.payment.PaymentMethod.CASH
            val isCredit = normalizedMode == com.example.data.payment.PaymentMethod.CREDIT

            // Compute paid & balance amounts
            val paidAmount = when {
                isCash -> sale.amount_c
                isCredit -> sale.amount_paid_c.coerceAtLeast(0.0).coerceAtMost(sale.amount_c)
                else -> 0.0
            }
            val balanceDue = when {
                isCash -> 0.0
                isCredit -> (sale.amount_c - paidAmount).coerceAtLeast(0.0)
                else -> sale.amount_c
            }

            // Determine canonical status
            val initialStatus = when {
                isCash -> com.example.data.payment.PaymentStatus.PAID
                isCredit -> {
                    if (balanceDue <= 0.0) com.example.data.payment.PaymentStatus.PAID
                    else if (paidAmount > 0.0) com.example.data.payment.PaymentStatus.PARTIALLY_PAID
                    else com.example.data.payment.PaymentStatus.UNPAID
                }
                else -> com.example.data.payment.PaymentStatus.PENDING
            }

            val nowTimestamp = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US).format(Date())
            val paymentTimestamp = if (isCash || (isCredit && paidAmount > 0)) (sale.payment_timestamp_c ?: nowTimestamp) else null

            // 1. Manage Customer record for Credit or linked customer sale
            var customerId = sale.customer_id_c
            val existingCustomer = if (!customerId.isNullOrBlank()) {
                database.customerDao().getCustomerById(customerId) ?: (if (sale.buyer_name_c.isNotBlank()) database.customerDao().getCustomerByName(sale.buyer_name_c) else null)
            } else if (sale.buyer_name_c.isNotBlank()) {
                database.customerDao().getCustomerByName(sale.buyer_name_c)
            } else null

            if (existingCustomer != null) {
                customerId = existingCustomer.id
                val newBalance = if (isCredit) (existingCustomer.outstanding_balance_c + balanceDue) else existingCustomer.outstanding_balance_c
                val newPurchases = existingCustomer.total_purchases_c + sale.amount_c
                val newPaid = existingCustomer.total_paid_c + (if (isCredit) paidAmount else sale.amount_c)
                database.customerDao().updateBalances(existingCustomer.id, newBalance, newPurchases, newPaid)
            } else if (isCredit && sale.buyer_name_c.isNotBlank()) {
                val newCustId = customerId ?: UUID.randomUUID().toString()
                customerId = newCustId
                val custEntity = CustomerEntity(
                    id = newCustId,
                    name_c = sale.buyer_name_c,
                    phone_c = sale.buyer_phone_c,
                    address_c = sale.buyer_address_c,
                    village_c = sale.buyer_village_c,
                    outstanding_balance_c = balanceDue,
                    total_purchases_c = sale.amount_c,
                    total_paid_c = paidAmount,
                    created_at = sale.sale_date_c,
                    is_synced = false
                )
                database.customerDao().insertOrUpdate(custEntity)
            } else if (!customerId.isNullOrBlank() || (sale.buyer_name_c.isNotBlank() && sale.buyer_name_c != "Direct Buyer" && sale.buyer_name_c != "Walk-in Buyer")) {
                val newCustId = customerId ?: UUID.randomUUID().toString()
                customerId = newCustId
                val custEntity = CustomerEntity(
                    id = newCustId,
                    name_c = sale.buyer_name_c.ifBlank { "Customer" },
                    phone_c = sale.buyer_phone_c,
                    address_c = sale.buyer_address_c,
                    village_c = sale.buyer_village_c,
                    outstanding_balance_c = 0.0,
                    total_purchases_c = sale.amount_c,
                    total_paid_c = sale.amount_c,
                    created_at = sale.sale_date_c,
                    is_synced = false
                )
                database.customerDao().insertOrUpdate(custEntity)
            }

            // 2. Save the sale locally in SQLite Room
            val saleEntity = SaleEntity(
                id = sale.id,
                goat_id_c = sale.goat_id_c,
                amount_c = sale.amount_c,
                sale_date_c = sale.sale_date_c,
                buyer_name_c = sale.buyer_name_c,
                buyer_phone_c = sale.buyer_phone_c,
                payment_mode_c = normalizedMode,
                payment_status_c = initialStatus,
                notes_c = sale.notes_c,
                created_at = sale.created_at ?: nowTimestamp,
                order_id_c = sale.order_id_c,
                transaction_id_c = sale.transaction_id_c,
                bank_transaction_id_c = sale.bank_transaction_id_c,
                reference_c = sale.reference_c,
                currency_c = "INR",
                payment_timestamp_c = paymentTimestamp,
                failure_reason_c = sale.failure_reason_c,
                sale_type_c = sale.sale_type_c,
                quantity_c = sale.quantity_c,
                total_weight_kg_c = sale.total_weight_kg_c,
                rate_per_unit_c = sale.rate_per_unit_c,
                buyer_address_c = sale.buyer_address_c,
                buyer_village_c = sale.buyer_village_c,
                amount_paid_c = paidAmount,
                balance_due_c = balanceDue,
                delivery_status_c = sale.delivery_status_c,
                expected_delivery_date_c = sale.expected_delivery_date_c,
                actual_delivery_date_c = sale.actual_delivery_date_c,
                delivery_photo_uri_c = sale.delivery_photo_uri_c,
                customer_id_c = customerId,
                is_synced = false
            )
            database.salesDao().insertOrUpdate(saleEntity)

            // Save dedicated delivery record locally
            val isDeliveredNow = sale.delivery_status_c.uppercase() == "DELIVERED"
            val deliveryEntity = DeliveryRecordEntity(
                id = UUID.randomUUID().toString(),
                sale_id_c = sale.id,
                goat_id_c = sale.goat_id_c,
                customer_id_c = customerId,
                recipient_name_c = sale.buyer_name_c,
                recipient_phone_c = sale.buyer_phone_c,
                delivery_address_c = sale.buyer_address_c,
                expected_delivery_date_c = sale.expected_delivery_date_c,
                actual_delivery_date_c = if (isDeliveredNow) (sale.actual_delivery_date_c ?: sale.sale_date_c) else null,
                delivery_status_c = sale.delivery_status_c,
                delivery_photo_uri_c = sale.delivery_photo_uri_c,
                outstanding_balance_c = balanceDue,
                is_delivered = isDeliveredNow,
                is_synced = false
            )
            database.deliveryDao().insertOrUpdate(deliveryEntity)

            val meta = JSONObject().apply {
                put("buyer_name", sale.buyer_name_c)
                put("buyer_phone", sale.buyer_phone_c)
                put("buyer_address", sale.buyer_address_c)
                put("buyer_village", sale.buyer_village_c)
                put("payment_mode", normalizedMode)
                put("payment_status", initialStatus)
                put("sale_type", sale.sale_type_c)
                put("quantity", sale.quantity_c)
                put("total_weight_kg", sale.total_weight_kg_c)
                put("rate_per_unit", sale.rate_per_unit_c)
                put("amount_paid", paidAmount)
                put("balance_due", balanceDue)
                put("currency", "INR")
                if (!sale.order_id_c.isNullOrBlank()) put("order_id", sale.order_id_c)
                if (!sale.reference_c.isNullOrBlank()) put("reference", sale.reference_c)
                if (!sale.notes_c.isNullOrBlank()) put("notes", sale.notes_c)
            }

            val saleJson = JSONObject().apply {
                put("id", sale.id)
                put("goat_id_c", sale.goat_id_c)
                put("amount_c", sale.amount_c)
                put("sale_date_c", sale.sale_date_c)
                put("buyer_name_c", sale.buyer_name_c)
                put("buyer_phone_c", sale.buyer_phone_c)
                put("payment_mode_c", normalizedMode)
                put("payment_status_c", initialStatus)
                put("notes_c", sale.notes_c ?: meta.toString())
            }

            // 3. Add sale creation to sync queue
            syncManager.enqueueOperation("sales_c", sale.id, "CREATE", saleJson)

            // 4. Mark goat as Sold for Cash or Credit
            if (isCash || isCredit) {
                database.goatDao().updateStatus(sale.goat_id_c, "Sold")
                val updateGoatJson = JSONObject().apply {
                    put("status_c", "Sold")
                }
                syncManager.enqueueOperation("goats_c", sale.goat_id_c, "UPDATE", updateGoatJson)
            }

            // 5. If any amount was paid upfront (Cash or Partial Credit), record ledger & transaction
            if (paidAmount > 0) {
                val paymentId = UUID.randomUUID().toString()
                val paymentEntity = PaymentLedgerEntity(
                    id = paymentId,
                    sale_id_c = sale.id,
                    customer_id_c = customerId,
                    amount_c = paidAmount,
                    payment_method_c = if (isCash) "CASH" else "INITIAL_DOWNPAYMENT",
                    payment_date_c = sale.sale_date_c,
                    reference_number_c = sale.reference_c,
                    notes_c = if (isCredit) "Initial payment on credit sale" else "Cash sale",
                    source_c = "MANUAL",
                    is_synced = false
                )
                database.paymentLedgerDao().insertPayment(paymentEntity)

                val txnId = UUID.randomUUID().toString()
                val txnEntity = TransactionEntity(
                    id = txnId,
                    transaction_type_c = "Sale",
                    amount_c = paidAmount,
                    date_c = sale.sale_date_c,
                    category_c = "Goat Sale",
                    description_c = "Payment for sale to ${sale.buyer_name_c.ifBlank { "Buyer" }}",
                    payment_mode_c = if (isCash) "CASH" else "PARTIAL",
                    payment_status_c = "PAID",
                    related_id_c = sale.id,
                    is_synced = false
                )
                database.transactionDao().insertTransaction(txnEntity)

                val transactionJson = JSONObject().apply {
                    put("id", txnId)
                    put("transaction_type_c", "Sale")
                    put("amount_c", paidAmount)
                    put("date_c", sale.sale_date_c)
                    put("description_c", "Payment for sale to ${sale.buyer_name_c.ifBlank { "Buyer" }}")
                    put("payment_mode_c", if (isCash) "CASH" else "PARTIAL")
                    put("payment_status_c", "PAID")
                    put("related_id_c", sale.id)
                }
                syncManager.enqueueOperation("transactions_c", txnId, "CREATE", transactionJson)
            }

            val resultDomain = saleEntity.toDomain()
            Result.success(resultDomain)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun recordCreditPayment(
        saleId: String,
        amount: Double,
        method: String,
        reference: String? = null,
        notes: String? = null
    ): Result<PaymentLedgerRecord> = withContext(Dispatchers.IO) {
        try {
            val sale = database.salesDao().getSaleById(saleId)
                ?: return@withContext Result.failure(Exception("Sale record not found"))

            val newPaid = sale.amount_paid_c + amount
            val newBalance = (sale.balance_due_c - amount).coerceAtLeast(0.0)
            val newStatus = if (newBalance <= 0.0) {
                com.example.data.payment.PaymentStatus.PAID
            } else {
                com.example.data.payment.PaymentStatus.PARTIALLY_PAID
            }

            // 1. Update sale
            database.salesDao().updateCreditPayment(
                id = saleId,
                amountPaid = newPaid,
                balanceDue = newBalance,
                status = newStatus,
                updatedAt = System.currentTimeMillis(),
                isSynced = false
            )

            // 2. Insert into Payment Ledger
            val todayStr = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
            val paymentId = UUID.randomUUID().toString()
            val ledgerEntity = PaymentLedgerEntity(
                id = paymentId,
                sale_id_c = saleId,
                customer_id_c = sale.customer_id_c,
                amount_c = amount,
                payment_method_c = com.example.data.payment.PaymentMethod.normalize(method),
                payment_date_c = todayStr,
                reference_number_c = reference,
                notes_c = notes,
                source_c = "MANUAL",
                is_synced = false
            )
            database.paymentLedgerDao().insertPayment(ledgerEntity)

            // 3. Update customer balance if linked
            if (!sale.customer_id_c.isNullOrBlank()) {
                val customer = database.customerDao().getCustomerById(sale.customer_id_c)
                if (customer != null) {
                    val updatedBal = (customer.outstanding_balance_c - amount).coerceAtLeast(0.0)
                    val updatedPaid = customer.total_paid_c + amount
                    database.customerDao().updateBalances(
                        customer.id,
                        updatedBal,
                        customer.total_purchases_c,
                        updatedPaid
                    )
                }
            }

            // 4. Record Transaction
            val txnId = UUID.randomUUID().toString()
            val txnEntity = TransactionEntity(
                id = txnId,
                transaction_type_c = "Sale",
                amount_c = amount,
                date_c = todayStr,
                category_c = "Credit Collection",
                description_c = "Credit payment received for ${sale.buyer_name_c}",
                payment_mode_c = method,
                payment_status_c = "PAID",
                related_id_c = saleId,
                is_synced = false
            )
            database.transactionDao().insertTransaction(txnEntity)

            // 5. Enqueue sync
            val updateSaleJson = JSONObject().apply {
                put("payment_status_c", newStatus)
                put("amount_paid", newPaid)
                put("balance_due", newBalance)
            }
            syncManager.enqueueOperation("sales_c", saleId, "UPDATE", updateSaleJson)

            val txnJson = JSONObject().apply {
                put("id", txnId)
                put("transaction_type_c", "Sale")
                put("amount_c", amount)
                put("date_c", todayStr)
                put("description_c", "Credit payment received for ${sale.buyer_name_c}")
                put("payment_mode_c", method)
                put("payment_status_c", "PAID")
                put("related_id_c", saleId)
            }
            syncManager.enqueueOperation("transactions_c", txnId, "CREATE", txnJson)

            val domainRecord = PaymentLedgerRecord(
                id = paymentId,
                sale_id_c = saleId,
                customer_id_c = sale.customer_id_c,
                amount_c = amount,
                payment_method_c = method,
                payment_date_c = todayStr,
                reference_number_c = reference,
                notes_c = notes,
                source_c = "MANUAL",
                created_at = todayStr
            )
            Result.success(domainRecord)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun getDeliveriesFlow(): Flow<List<DeliveryRecord>> =
        database.deliveryDao().getAllDeliveriesFlow().map { list ->
            list.map { it.toDomain() }
        }

    suspend fun getAllDeliveries(): List<DeliveryRecord> = withContext(Dispatchers.IO) {
        database.deliveryDao().getAllDeliveries().map { it.toDomain() }
    }

    suspend fun getDeliveryBySaleId(saleId: String): DeliveryRecord? = withContext(Dispatchers.IO) {
        database.deliveryDao().getDeliveryBySaleId(saleId)?.toDomain()
    }

    suspend fun updateDeliveryStatus(
        saleId: String,
        status: String,
        actualDate: String? = null,
        photoUri: String? = null,
        notes: String? = null,
        isDelivered: Boolean = status.equals("DELIVERED", ignoreCase = true)
    ): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val nowTime = System.currentTimeMillis()
            val todayStr = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date(nowTime))
            val finalDate = if (isDelivered) (actualDate ?: todayStr) else actualDate

            database.salesDao().updateFullDelivery(
                id = saleId,
                deliveryStatus = status,
                actualDate = finalDate,
                photoUri = photoUri,
                updatedAt = nowTime,
                isSynced = false
            )
            val existing = database.deliveryDao().getDeliveryBySaleId(saleId)
            if (existing != null) {
                database.deliveryDao().updateDeliveryStatus(
                    id = existing.id,
                    status = status,
                    actualDate = finalDate,
                    photoUri = photoUri,
                    isDelivered = isDelivered,
                    updatedAt = nowTime,
                    isSynced = false
                )
            }
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun updateDeliveryStatus(saleId: String, newStatus: String): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val normalized = com.example.data.payment.DeliveryStatus.normalize(newStatus)
            database.salesDao().updateDeliveryStatus(saleId, normalized)
            val json = JSONObject().apply {
                put("delivery_status_c", normalized)
            }
            syncManager.enqueueOperation("sales_c", saleId, "UPDATE", json)
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getCustomers(): Result<List<CustomerRecord>> = withContext(Dispatchers.IO) {
        try {
            val list = database.customerDao().getAllCustomers().map {
                CustomerRecord(
                    id = it.id,
                    name_c = it.name_c,
                    phone_c = it.phone_c,
                    address_c = it.address_c,
                    village_c = it.village_c,
                    outstanding_balance_c = it.outstanding_balance_c,
                    total_purchases_c = it.total_purchases_c,
                    total_paid_c = it.total_paid_c,
                    notes_c = it.notes_c,
                    created_at = it.created_at
                )
            }
            Result.success(list)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun saveCustomer(customer: CustomerRecord): Result<CustomerRecord> = withContext(Dispatchers.IO) {
        try {
            val entity = CustomerEntity(
                id = customer.id,
                name_c = customer.name_c,
                phone_c = customer.phone_c,
                address_c = customer.address_c,
                village_c = customer.village_c,
                outstanding_balance_c = customer.outstanding_balance_c,
                total_purchases_c = customer.total_purchases_c,
                total_paid_c = customer.total_paid_c,
                notes_c = customer.notes_c,
                created_at = customer.created_at ?: SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date()),
                is_synced = false
            )
            database.customerDao().insertOrUpdate(entity)
            Result.success(customer)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getPaymentLedger(saleId: String? = null): Result<List<PaymentLedgerRecord>> = withContext(Dispatchers.IO) {
        try {
            val list = if (saleId != null) {
                database.paymentLedgerDao().getPaymentsForSale(saleId)
            } else {
                database.paymentLedgerDao().getAllPayments()
            }.map {
                PaymentLedgerRecord(
                    id = it.id,
                    sale_id_c = it.sale_id_c,
                    customer_id_c = it.customer_id_c,
                    amount_c = it.amount_c,
                    payment_method_c = it.payment_method_c,
                    payment_date_c = it.payment_date_c,
                    reference_number_c = it.reference_number_c,
                    notes_c = it.notes_c,
                    source_c = it.source_c,
                    created_at = it.payment_date_c
                )
            }
            Result.success(list)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun confirmUpiPayment(
        sale: SaleRecord,
        referenceNumber: String? = null
    ): Result<SaleRecord> = withContext(Dispatchers.IO) {
        try {
            val nowTimestamp = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US).format(Date())

            // 1. Update sale payment status to PAID locally with reference and timestamp
            database.salesDao().updatePaymentDetails(
                id = sale.id,
                status = com.example.data.payment.PaymentStatus.PAID,
                paymentMode = com.example.data.payment.PaymentMethod.UPI_QR,
                reference = referenceNumber,
                txnId = referenceNumber,
                bankTxnId = null,
                failureReason = null,
                timestamp = nowTimestamp,
                updatedAt = System.currentTimeMillis(),
                isSynced = false
            )

            // 2. Mark goat as Sold locally only after payment is confirmed
            database.goatDao().updateStatus(sale.goat_id_c, "Sold")

            // 3. Save payment transaction locally
            val transactionId = UUID.randomUUID().toString()
            val paymentEntity = TransactionEntity(
                id = transactionId,
                transaction_type_c = "Sale",
                amount_c = sale.amount_c,
                date_c = sale.sale_date_c,
                category_c = "Goat Sale",
                description_c = "UPI / QR payment confirmed for ${sale.buyer_name_c.ifBlank { "Buyer" }}",
                payment_mode_c = "UPI_QR",
                payment_status_c = "PAID",
                related_id_c = sale.id,
                is_synced = false
            )
            database.transactionDao().insertTransaction(paymentEntity)

            // 4. Queue sale update
            val meta = JSONObject().apply {
                put("buyer_name", sale.buyer_name_c)
                put("buyer_phone", sale.buyer_phone_c)
                put("payment_mode", "UPI_QR")
                put("payment_status", "PAID")
                put("currency", "INR")
                if (!referenceNumber.isNullOrBlank()) put("reference", referenceNumber)
                if (!sale.notes_c.isNullOrBlank()) put("notes", sale.notes_c)
            }
            val updateSaleJson = JSONObject().apply {
                put("payment_status_c", "PAID")
                put("payment_mode_c", "UPI_QR")
                put("notes_c", meta.toString())
            }
            syncManager.enqueueOperation("sales_c", sale.id, "UPDATE", updateSaleJson)

            // 5. Queue goat status update
            val updateGoatJson = JSONObject().apply {
                put("status_c", "Sold")
            }
            syncManager.enqueueOperation("goats_c", sale.goat_id_c, "UPDATE", updateGoatJson)

            // 6. Queue payment transaction
            val transactionJson = JSONObject().apply {
                put("id", transactionId)
                put("transaction_type_c", "Sale")
                put("amount_c", sale.amount_c)
                put("date_c", sale.sale_date_c)
                put("description_c", "UPI / QR payment confirmed for ${sale.buyer_name_c.ifBlank { "Buyer" }}")
                put("payment_mode_c", "UPI_QR")
                put("payment_status_c", "PAID")
                put("related_id_c", sale.id)
            }
            syncManager.enqueueOperation("transactions_c", transactionId, "CREATE", transactionJson)

            val updatedSale = sale.copy(
                payment_status_c = com.example.data.payment.PaymentStatus.PAID,
                payment_mode_c = com.example.data.payment.PaymentMethod.UPI_QR,
                reference_c = referenceNumber,
                payment_timestamp_c = nowTimestamp
            )
            Result.success(updatedSale)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun confirmPaytmPayment(
        sale: SaleRecord,
        verifyResult: com.example.data.payment.PaytmVerifyResult
    ): Result<SaleRecord> = withContext(Dispatchers.IO) {
        try {
            val nowTimestamp = verifyResult.paymentTimestamp

            // 1. Update sale payment status to PAID locally with transaction IDs
            database.salesDao().updatePaymentDetails(
                id = sale.id,
                status = com.example.data.payment.PaymentStatus.PAID,
                paymentMode = com.example.data.payment.PaymentMethod.PAYTM_GATEWAY,
                reference = verifyResult.txnId,
                txnId = verifyResult.txnId,
                bankTxnId = verifyResult.bankTxnId,
                failureReason = null,
                timestamp = nowTimestamp,
                updatedAt = System.currentTimeMillis(),
                isSynced = false
            )

            // 2. Mark goat as Sold locally only after Paytm transaction is verified
            database.goatDao().updateStatus(sale.goat_id_c, "Sold")

            // 3. Save payment transaction locally
            val transactionId = UUID.randomUUID().toString()
            val paymentEntity = TransactionEntity(
                id = transactionId,
                transaction_type_c = "Sale",
                amount_c = sale.amount_c,
                date_c = sale.sale_date_c,
                category_c = "Goat Sale",
                description_c = "Paytm Gateway payment verified (Txn: ${verifyResult.txnId ?: ""})",
                payment_mode_c = "PAYTM_GATEWAY",
                payment_status_c = "PAID",
                related_id_c = sale.id,
                is_synced = false
            )
            database.transactionDao().insertTransaction(paymentEntity)

            // 4. Queue sale update
            val meta = JSONObject().apply {
                put("buyer_name", sale.buyer_name_c)
                put("buyer_phone", sale.buyer_phone_c)
                put("payment_mode", "PAYTM_GATEWAY")
                put("payment_status", "PAID")
                put("currency", "INR")
                put("order_id", verifyResult.orderId)
                if (!verifyResult.txnId.isNullOrBlank()) put("paytm_txn_id", verifyResult.txnId)
                if (!verifyResult.bankTxnId.isNullOrBlank()) put("bank_txn_id", verifyResult.bankTxnId)
                if (!sale.notes_c.isNullOrBlank()) put("notes", sale.notes_c)
            }
            val updateSaleJson = JSONObject().apply {
                put("payment_status_c", "PAID")
                put("payment_mode_c", "PAYTM_GATEWAY")
                put("notes_c", meta.toString())
            }
            syncManager.enqueueOperation("sales_c", sale.id, "UPDATE", updateSaleJson)

            // 5. Queue goat status update
            val updateGoatJson = JSONObject().apply {
                put("status_c", "Sold")
            }
            syncManager.enqueueOperation("goats_c", sale.goat_id_c, "UPDATE", updateGoatJson)

            // 6. Queue payment transaction
            val transactionJson = JSONObject().apply {
                put("id", transactionId)
                put("transaction_type_c", "Sale")
                put("amount_c", sale.amount_c)
                put("date_c", sale.sale_date_c)
                put("description_c", "Paytm Gateway payment verified for ${sale.buyer_name_c.ifBlank { "Buyer" }}")
                put("payment_mode_c", "PAYTM_GATEWAY")
                put("payment_status_c", "PAID")
                put("related_id_c", sale.id)
            }
            syncManager.enqueueOperation("transactions_c", transactionId, "CREATE", transactionJson)

            val updatedSale = sale.copy(
                payment_status_c = com.example.data.payment.PaymentStatus.PAID,
                payment_mode_c = com.example.data.payment.PaymentMethod.PAYTM_GATEWAY,
                order_id_c = verifyResult.orderId,
                transaction_id_c = verifyResult.txnId,
                bank_transaction_id_c = verifyResult.bankTxnId,
                reference_c = verifyResult.txnId,
                payment_timestamp_c = nowTimestamp
            )
            Result.success(updatedSale)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun markPaymentFailed(
        sale: SaleRecord,
        status: String, // FAILED or CANCELLED
        failureReason: String?
    ): Result<SaleRecord> = withContext(Dispatchers.IO) {
        try {
            val normalizedStatus = if (status == com.example.data.payment.PaymentStatus.CANCELLED) com.example.data.payment.PaymentStatus.CANCELLED else com.example.data.payment.PaymentStatus.FAILED
            database.salesDao().updatePaymentDetails(
                id = sale.id,
                status = normalizedStatus,
                paymentMode = sale.payment_mode_c,
                reference = sale.reference_c,
                txnId = sale.transaction_id_c,
                bankTxnId = sale.bank_transaction_id_c,
                failureReason = failureReason,
                timestamp = null,
                updatedAt = System.currentTimeMillis(),
                isSynced = false
            )

            // Goat is intentionally NOT marked as Sold!

            val updateSaleJson = JSONObject().apply {
                put("payment_status_c", normalizedStatus)
                put("failure_reason", failureReason ?: "")
            }
            syncManager.enqueueOperation("sales_c", sale.id, "UPDATE", updateSaleJson)

            val updatedSale = sale.copy(
                payment_status_c = normalizedStatus,
                failure_reason_c = failureReason
            )
            Result.success(updatedSale)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getUnsoldGoats(): Result<List<Goat>> = withContext(Dispatchers.IO) {
        try {
            val allLocalGoats = database.goatDao().getAllGoats()
            val allSales = database.salesDao().getAllSales()
            val goatsWithPaidSales = allSales
                .filter { com.example.data.payment.PaymentStatus.isPaid(it.payment_status_c) }
                .map { it.goat_id_c }
                .toSet()

            val unsold = allLocalGoats.filter { goat ->
                !goat.status_c.equals("Sold", ignoreCase = true) &&
                !goat.status_c.equals("Deceased", ignoreCase = true) &&
                goat.id !in goatsWithPaidSales
            }.map { it.toDomain() }

            Result.success(unsold)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // ==========================================
    // CONVERTERS & HELPERS
    // ==========================================

    private fun calculateDaysDiff(dateStr: String, today: Date): Int {
        return try {
            val d = dateFormat.parse(dateStr) ?: return 0
            val diffMs = d.time - today.time
            TimeUnit.DAYS.convert(diffMs, TimeUnit.MILLISECONDS).toInt()
        } catch (_: Exception) {
            0
        }
    }

    fun GoatEntity.toDomain() = Goat(
        id = id,
        name = name,
        tag_c = tag_c,
        breed_c = breed_c,
        sex_c = sex_c,
        status_c = status_c,
        birth_date_c = birth_date_c,
        weight_kg_c = weight_kg_c,
        dam_c = dam_c,
        sire_c = sire_c,
        source_c = source_c,
        purchase_date_c = purchase_date_c,
        purchase_cost_c = purchase_cost_c,
        farm_location_c = farm_location_c,
        color_c = color_c,
        notes_c = notes_c,
        created_at = created_at,
        origin_c = origin_c ?: effectiveOrigin,
        sire_id = sire_c,
        dam_id = dam_c,
        photo_url_c = photo_url_c,
        health_status_c = health_status_c ?: "Healthy"
    )

    private fun Goat.toEntity(isSynced: Boolean = true) = GoatEntity(
        id = id,
        name = name,
        tag_c = tag_c,
        breed_c = breed_c,
        sex_c = sex_c,
        status_c = status_c,
        birth_date_c = birth_date_c,
        weight_kg_c = weight_kg_c,
        dam_c = dam_c,
        sire_c = sire_c,
        source_c = source_c,
        purchase_date_c = purchase_date_c,
        purchase_cost_c = purchase_cost_c,
        farm_location_c = farm_location_c,
        color_c = color_c,
        notes_c = notes_c,
        created_at = created_at,
        is_synced = isSynced,
        origin_c = origin_c ?: effectiveOrigin,
        photo_url_c = photo_url_c,
        health_status_c = health_status_c ?: "Healthy"
    )

    private fun SaleEntity.toDomain() = SaleRecord(
        id = id,
        goat_id_c = goat_id_c,
        amount_c = amount_c,
        sale_date_c = sale_date_c,
        buyer_name_c = buyer_name_c,
        buyer_phone_c = buyer_phone_c,
        payment_mode_c = payment_mode_c,
        payment_status_c = payment_status_c,
        notes_c = notes_c,
        created_at = created_at,
        order_id_c = order_id_c,
        transaction_id_c = transaction_id_c,
        bank_transaction_id_c = bank_transaction_id_c,
        reference_c = reference_c,
        currency_c = currency_c,
        payment_timestamp_c = payment_timestamp_c,
        failure_reason_c = failure_reason_c,
        sale_type_c = sale_type_c,
        quantity_c = quantity_c,
        total_weight_kg_c = total_weight_kg_c,
        rate_per_unit_c = rate_per_unit_c,
        buyer_address_c = buyer_address_c,
        buyer_village_c = buyer_village_c,
        amount_paid_c = amount_paid_c,
        balance_due_c = balance_due_c,
        delivery_status_c = delivery_status_c,
        expected_delivery_date_c = expected_delivery_date_c,
        actual_delivery_date_c = actual_delivery_date_c,
        delivery_photo_uri_c = delivery_photo_uri_c,
        customer_id_c = customer_id_c
    )

    private fun DeliveryRecordEntity.toDomain() = DeliveryRecord(
        id = id,
        sale_id_c = sale_id_c,
        goat_id_c = goat_id_c,
        customer_id_c = customer_id_c,
        recipient_name_c = recipient_name_c,
        recipient_phone_c = recipient_phone_c,
        delivery_address_c = delivery_address_c,
        expected_delivery_date_c = expected_delivery_date_c,
        actual_delivery_date_c = actual_delivery_date_c,
        delivery_status_c = delivery_status_c,
        delivery_photo_uri_c = delivery_photo_uri_c,
        delivery_notes_c = delivery_notes_c,
        outstanding_balance_c = outstanding_balance_c,
        is_delivered = is_delivered,
        marked_by_c = marked_by_c,
        created_at = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date(created_at))
    )

    private fun parseGoatEntity(obj: JSONObject): GoatEntity {
        return GoatEntity(
            id = obj.optString("id"),
            name = obj.optString("name", "Goat"),
            tag_c = obj.optString("tag_c", obj.optString("tag", "")),
            breed_c = obj.optString("breed_c", obj.optString("breed", "Boer")),
            sex_c = obj.optString("sex_c", obj.optString("sex", "Doe")),
            status_c = obj.optString("status_c", obj.optString("status", "Active")),
            birth_date_c = obj.optNullableString("birth_date_c"),
            weight_kg_c = if (obj.has("weight_kg_c") && !obj.isNull("weight_kg_c")) obj.optDouble("weight_kg_c") else null,
            dam_c = obj.optNullableString("dam_id") ?: obj.optNullableString("dam_c"),
            sire_c = obj.optNullableString("sire_id") ?: obj.optNullableString("sire_c"),
            source_c = obj.optString("source_c", "Born on farm"),
            purchase_date_c = obj.optNullableString("purchase_date_c"),
            purchase_cost_c = if (obj.has("purchase_cost_c") && !obj.isNull("purchase_cost_c")) obj.optDouble("purchase_cost_c") else null,
            farm_location_c = obj.optString("farm_location_c", "Barn A"),
            color_c = obj.optNullableString("color_c"),
            notes_c = obj.optNullableString("notes_c"),
            created_at = obj.optNullableString("created_at"),
            is_synced = true,
            origin_c = obj.optNullableString("origin_c") ?: when (obj.optString("source_c").lowercase()) {
                "born on farm", "farm born", "farm_born" -> "FARM_BORN"
                "purchased", "market bought", "market_bought", "market" -> "MARKET_BOUGHT"
                else -> "UNKNOWN"
            }
        )
    }

    // ==========================================
    // FARM ASSETS & INFRASTRUCTURE
    // ==========================================

    suspend fun getFarmAssets(): Result<List<FarmAsset>> = withContext(Dispatchers.IO) {
        try {
            val localList = database.farmAssetDao().getAllAssets()
            if (localList.isNotEmpty()) {
                return@withContext Result.success(localList.map { it.toDomain() })
            }

            // Fetch from Supabase table 'farm_assets'
            val res = client.get("farm_assets", "select=*&order=created_at.desc")
            if (res.isSuccess) {
                val arr = res.getOrThrow()
                val list = mutableListOf<FarmAssetEntity>()
                for (i in 0 until arr.length()) {
                    val obj = arr.getJSONObject(i)
                    list.add(parseFarmAssetEntity(obj))
                }
                database.farmAssetDao().insertAll(list)
                Result.success(list.map { it.toDomain() })
            } else {
                Result.success(emptyList())
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun getFarmAssetsFlow(): Flow<List<FarmAsset>> {
        return database.farmAssetDao().getAllAssetsFlow().map { list ->
            list.map { it.toDomain() }
        }
    }

    suspend fun getFarmAssetById(id: String): Result<FarmAsset?> = withContext(Dispatchers.IO) {
        try {
            val local = database.farmAssetDao().getAssetById(id)
            Result.success(local?.toDomain())
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun addFarmAsset(asset: FarmAsset): Result<FarmAsset> = withContext(Dispatchers.IO) {
        try {
            val entity = asset.toEntity(isSynced = false)
            database.farmAssetDao().insertOrUpdate(entity)

            // Construct payload JSON for Supabase table 'farm_assets'
            val json = JSONObject().apply {
                put("id", asset.id)
                put("name", asset.name)
                put("category", asset.category)
                if (!asset.purchase_date.isNullOrBlank()) put("purchase_date", asset.purchase_date)
                put("cost", asset.cost)
                put("useful_life", asset.useful_life)
                put("current_condition", asset.current_condition)
                put("location", asset.location)
                if (!asset.warranty_expiry.isNullOrBlank()) put("warranty_expiry", asset.warranty_expiry)
                if (!asset.maintenance_schedule.isNullOrBlank()) put("maintenance_schedule", asset.maintenance_schedule)
                if (!asset.asset_id.isNullOrBlank()) put("asset_id", asset.asset_id)
                if (!asset.supplier.isNullOrBlank()) put("supplier", asset.supplier)
                put("quantity", asset.quantity)
                put("status", asset.status)
                if (!asset.amc_expiry.isNullOrBlank()) put("amc_expiry", asset.amc_expiry)
                if (!asset.last_maintenance.isNullOrBlank()) put("last_maintenance", asset.last_maintenance)
                if (!asset.next_maintenance.isNullOrBlank()) put("next_maintenance", asset.next_maintenance)
                put("residual_value", asset.residual_value)
                put("depreciation_method", asset.depreciation_method)
                put("accumulated_depreciation", asset.accumulated_depreciation)
                put("current_book_value", asset.current_book_value)
                put("is_capex", asset.is_capex)
                if (!asset.notes.isNullOrBlank()) put("notes", asset.notes)
                if (!asset.photo_url.isNullOrBlank()) put("photo_url", asset.photo_url)
            }
            syncManager.enqueueOperation("farm_assets", asset.id, "CREATE", json)

            Result.success(asset)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun updateFarmAsset(asset: FarmAsset): Result<FarmAsset> = withContext(Dispatchers.IO) {
        try {
            val entity = asset.toEntity(isSynced = false)
            database.farmAssetDao().insertOrUpdate(entity)

            val json = JSONObject().apply {
                put("name", asset.name)
                put("category", asset.category)
                if (!asset.purchase_date.isNullOrBlank()) put("purchase_date", asset.purchase_date)
                put("cost", asset.cost)
                put("useful_life", asset.useful_life)
                put("current_condition", asset.current_condition)
                put("location", asset.location)
                if (!asset.warranty_expiry.isNullOrBlank()) put("warranty_expiry", asset.warranty_expiry)
                if (!asset.maintenance_schedule.isNullOrBlank()) put("maintenance_schedule", asset.maintenance_schedule)
                if (!asset.asset_id.isNullOrBlank()) put("asset_id", asset.asset_id)
                if (!asset.supplier.isNullOrBlank()) put("supplier", asset.supplier)
                put("quantity", asset.quantity)
                put("status", asset.status)
                if (!asset.amc_expiry.isNullOrBlank()) put("amc_expiry", asset.amc_expiry)
                if (!asset.last_maintenance.isNullOrBlank()) put("last_maintenance", asset.last_maintenance)
                if (!asset.next_maintenance.isNullOrBlank()) put("next_maintenance", asset.next_maintenance)
                put("residual_value", asset.residual_value)
                put("depreciation_method", asset.depreciation_method)
                put("accumulated_depreciation", asset.accumulated_depreciation)
                put("current_book_value", asset.current_book_value)
                put("is_capex", asset.is_capex)
                if (!asset.notes.isNullOrBlank()) put("notes", asset.notes)
                if (!asset.photo_url.isNullOrBlank()) put("photo_url", asset.photo_url)
            }
            syncManager.enqueueOperation("farm_assets", asset.id, "UPDATE", json)

            Result.success(asset)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun deleteFarmAsset(id: String): Result<Boolean> = withContext(Dispatchers.IO) {
        try {
            database.farmAssetDao().deleteById(id)
            syncManager.enqueueOperation("farm_assets", id, "DELETE", JSONObject().put("id", id))
            Result.success(true)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getFarmAssetsSummary(): Result<FarmAssetsSummary> = withContext(Dispatchers.IO) {
        try {
            val assets = database.farmAssetDao().getAllAssets().map { it.toDomain() }
            val totalCost = assets.sumOf { it.cost }
            val currentBookValue = assets.sumOf { it.current_book_value }
            val accumDep = (totalCost - currentBookValue).coerceAtLeast(0.0)
            val active = assets.count { it.status.equals("Active", ignoreCase = true) }
            val underMaint = assets.count { it.status.contains("Maintenance", ignoreCase = true) }
            val damaged = assets.count { it.status.contains("Damaged", ignoreCase = true) }

            val breakdown = assets.groupBy { it.category }.mapValues { entry ->
                entry.value.sumOf { it.cost }
            }

            Result.success(
                FarmAssetsSummary(
                    totalAssetsCount = assets.size,
                    totalCostCapex = totalCost,
                    currentBookValue = currentBookValue,
                    accumulatedDepreciation = accumDep,
                    activeCount = active,
                    underMaintenanceCount = underMaint,
                    damagedCount = damaged,
                    upcomingMaintenanceCount = assets.count { !it.next_maintenance.isNullOrBlank() },
                    categoryBreakdown = breakdown
                )
            )
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun FarmAssetEntity.toDomain() = FarmAsset(
        id = id,
        name = name,
        category = category,
        purchase_date = purchase_date,
        cost = cost,
        useful_life = useful_life,
        current_condition = current_condition,
        location = location,
        warranty_expiry = warranty_expiry,
        maintenance_schedule = maintenance_schedule,
        asset_id = asset_id,
        supplier = supplier,
        quantity = quantity,
        status = status,
        amc_expiry = amc_expiry,
        last_maintenance = last_maintenance,
        next_maintenance = next_maintenance,
        residual_value = residual_value,
        depreciation_method = depreciation_method,
        accumulated_depreciation = accumulated_depreciation,
        current_book_value = if (current_book_value > 0.0) current_book_value else cost,
        is_capex = is_capex,
        notes = notes,
        photo_url = photo_url,
        created_at = created_at
    )

    private fun FarmAsset.toEntity(isSynced: Boolean) = FarmAssetEntity(
        id = id,
        name = name,
        category = category,
        purchase_date = purchase_date,
        cost = cost,
        useful_life = useful_life,
        current_condition = current_condition,
        location = location,
        warranty_expiry = warranty_expiry,
        maintenance_schedule = maintenance_schedule,
        asset_id = asset_id,
        supplier = supplier,
        quantity = quantity,
        status = status,
        amc_expiry = amc_expiry,
        last_maintenance = last_maintenance,
        next_maintenance = next_maintenance,
        residual_value = residual_value,
        depreciation_method = depreciation_method,
        accumulated_depreciation = accumulated_depreciation,
        current_book_value = current_book_value,
        is_capex = is_capex,
        notes = notes,
        photo_url = photo_url,
        created_at = created_at ?: SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US).format(Date()),
        updated_at = System.currentTimeMillis(),
        is_synced = isSynced
    )

    private fun parseFarmAssetEntity(obj: JSONObject): FarmAssetEntity {
        val costVal = if (obj.has("cost") && !obj.isNull("cost")) obj.optDouble("cost", 0.0) else 0.0
        val bookVal = if (obj.has("current_book_value") && !obj.isNull("current_book_value")) {
            obj.optDouble("current_book_value", costVal)
        } else costVal

        return FarmAssetEntity(
            id = obj.optString("id", UUID.randomUUID().toString()),
            name = obj.optString("name", "Farm Asset"),
            category = obj.optString("category", "Equipment"),
            purchase_date = obj.optNullableString("purchase_date"),
            cost = costVal,
            useful_life = if (obj.has("useful_life") && !obj.isNull("useful_life")) obj.optInt("useful_life", 5) else 5,
            current_condition = obj.optString("current_condition", "Good"),
            location = obj.optString("location", "Main Shed"),
            warranty_expiry = obj.optNullableString("warranty_expiry"),
            maintenance_schedule = obj.optNullableString("maintenance_schedule") ?: "Monthly",
            asset_id = obj.optNullableString("asset_id"),
            supplier = obj.optNullableString("supplier"),
            quantity = if (obj.has("quantity") && !obj.isNull("quantity")) obj.optInt("quantity", 1) else 1,
            status = obj.optString("status", "Active"),
            amc_expiry = obj.optNullableString("amc_expiry"),
            last_maintenance = obj.optNullableString("last_maintenance"),
            next_maintenance = obj.optNullableString("next_maintenance"),
            residual_value = if (obj.has("residual_value") && !obj.isNull("residual_value")) obj.optDouble("residual_value", 0.0) else 0.0,
            depreciation_method = obj.optString("depreciation_method", "Straight-line"),
            accumulated_depreciation = if (obj.has("accumulated_depreciation") && !obj.isNull("accumulated_depreciation")) obj.optDouble("accumulated_depreciation", 0.0) else 0.0,
            current_book_value = bookVal,
            is_capex = if (obj.has("is_capex")) obj.optBoolean("is_capex", true) else true,
            notes = obj.optNullableString("notes"),
            photo_url = obj.optNullableString("photo_url"),
            created_at = obj.optNullableString("created_at"),
            updated_at = System.currentTimeMillis(),
            is_synced = true
        )
    }

    val appDatabase: AppDatabase get() = database

    suspend fun getFarmSetting(key: String): String? = withContext(Dispatchers.IO) {
        database.farmSettingsDao().getSetting(key)?.value_c
    }

    suspend fun saveFarmSetting(key: String, value: String) = withContext(Dispatchers.IO) {
        database.farmSettingsDao().saveSetting(FarmSettingEntity(key = key, value_c = value))
    }

    suspend fun getAllFarmSettings(): Map<String, String> = withContext(Dispatchers.IO) {
        database.farmSettingsDao().getAllSettings().associate { it.key to it.value_c }
    }

    suspend fun getBreedingRecords(): Result<List<BreedingRecordEntity>> = withContext(Dispatchers.IO) {
        try {
            val list = database.breedingRecordDao().getAllBreedingRecords()
            Result.success(list)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun saveBreedingRecord(record: BreedingRecordEntity): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            database.breedingRecordDao().insertBreedingRecord(record)
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun deleteBreedingRecord(id: String): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            database.breedingRecordDao().deleteBreedingRecord(id)
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun getBreedingRecordsForGoatFlow(goatId: String): kotlinx.coroutines.flow.Flow<List<BreedingRecordEntity>> =
        database.breedingRecordDao().getBreedingRecordsForGoatFlow(goatId)

    suspend fun getBreedingRecordsForGoat(goatId: String): Result<List<BreedingRecordEntity>> = withContext(Dispatchers.IO) {
        try {
            val list = database.breedingRecordDao().getBreedingRecordsForGoat(goatId)
            Result.success(list)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun updateBreedingRecordStatus(id: String, status: String, notes: String? = null): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            database.breedingRecordDao().updateBreedingRecordStatus(id, status, notes)
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // ==========================================
    // DAILY HEALTH OBSERVATIONS
    // ==========================================

    fun getDailyHealthObservationsFlow(): Flow<List<DailyHealthObservationEntity>> =
        database.dailyHealthObservationDao().getAllObservationsFlow()

    fun getDailyHealthObservationsForGoatFlow(goatId: String): Flow<List<DailyHealthObservationEntity>> =
        database.dailyHealthObservationDao().getObservationsForGoatFlow(goatId)

    suspend fun getDailyHealthObservations(): Result<List<DailyHealthObservationEntity>> = withContext(Dispatchers.IO) {
        try {
            val list = database.dailyHealthObservationDao().getAllObservations()
            Result.success(list)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun saveDailyHealthObservation(obs: DailyHealthObservationEntity): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            database.dailyHealthObservationDao().insertObservation(obs)
            // If observation notes an issue, update goat's quick health status badge
            val targetStatus = when (obs.overall_health_rating) {
                "Critical" -> "Sick / Critical"
                "Needs Vet Attention" -> "Sick"
                "Mild Concern" -> "Under Observation"
                else -> "Healthy"
            }
            database.goatDao().getGoatById(obs.goat_id)?.let { goat ->
                database.goatDao().insertOrUpdate(goat.copy(health_status_c = targetStatus, updated_at = System.currentTimeMillis()))
            }
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun deleteDailyHealthObservation(id: String): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            database.dailyHealthObservationDao().deleteObservationById(id)
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun saveBatchDailyHealthObservations(
        observations: List<DailyHealthObservationEntity>,
        updateGoatHealthStatus: Boolean = true
    ): Result<Int> = withContext(Dispatchers.IO) {
        try {
            if (observations.isEmpty()) return@withContext Result.success(0)
            database.dailyHealthObservationDao().insertAll(observations)
            if (updateGoatHealthStatus) {
                observations.forEach { obs ->
                    val targetStatus = when (obs.overall_health_rating) {
                        "Critical" -> "Sick / Critical"
                        "Needs Vet Attention" -> "Sick"
                        "Mild Concern" -> "Under Observation"
                        "Quarantine" -> "Quarantine"
                        else -> "Healthy"
                    }
                    database.goatDao().updateHealthStatus(obs.goat_id, targetStatus)
                }
            }
            Result.success(observations.size)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun recordBatchTreatments(
        treatments: List<TreatmentRecord>,
        updateGoatHealthStatus: Boolean = true
    ): Result<Int> = withContext(Dispatchers.IO) {
        try {
            if (treatments.isEmpty()) return@withContext Result.success(0)
            val entities = treatments.map { treatment ->
                TreatmentEntity(
                    id = treatment.id,
                    goat_id_c = treatment.goat_id_c,
                    symptoms_c = treatment.symptoms_c,
                    diagnosis_c = treatment.diagnosis_c,
                    medicine_c = treatment.medicine_c,
                    dose_c = treatment.dose_c,
                    start_date_c = treatment.start_date_c,
                    end_date_c = treatment.end_date_c,
                    veterinarian_c = treatment.veterinarian_c,
                    outcome_c = treatment.outcome_c,
                    notes_c = treatment.notes_c,
                    is_synced = false
                )
            }
            database.healthDao().insertAllTreatments(entities)

            treatments.forEach { treatment ->
                val json = JSONObject().apply {
                    put("id", treatment.id)
                    put("goat_id_c", treatment.goat_id_c)
                    put("symptoms_c", treatment.symptoms_c)
                    put("diagnosis_c", treatment.diagnosis_c)
                    put("medicine_c", treatment.medicine_c)
                    put("dose_c", treatment.dose_c)
                    put("start_date_c", treatment.start_date_c)
                    if (!treatment.end_date_c.isNullOrBlank()) put("end_date_c", treatment.end_date_c)
                    if (!treatment.veterinarian_c.isNullOrBlank()) put("veterinarian_c", treatment.veterinarian_c)
                    put("outcome_c", treatment.outcome_c)
                    if (!treatment.notes_c.isNullOrBlank()) put("notes_c", treatment.notes_c)
                }
                syncManager.enqueueOperation("treatments_c", treatment.id, "CREATE", json)

                if (updateGoatHealthStatus) {
                    val newHealthStatus = if (treatment.outcome_c.equals("Under Treatment", ignoreCase = true)) {
                        "Under Treatment"
                    } else if (treatment.outcome_c.equals("Recovered", ignoreCase = true)) {
                        "Healthy"
                    } else {
                        "Under Treatment"
                    }
                    database.goatDao().updateHealthStatus(treatment.goat_id_c, newHealthStatus)
                }
            }

            Result.success(treatments.size)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getLiveDashboardMetrics(): Result<LiveDashboardMetrics> = withContext(Dispatchers.IO) {
        try {
            val goats = database.goatDao().getAllGoats()
            val totalGoats = goats.count { !it.status_c.equals("Deceased", ignoreCase = true) && !it.status_c.equals("Sold", ignoreCase = true) }
            val pregnancies = database.breedingDao().getAllPregnancies()
            val pregnantCount = pregnancies.count { it.status_c.equals("Confirmed", ignoreCase = true) }
            val todayStr = dateFormat.format(Date())

            val dueForDeliveryCount = pregnancies.count { p ->
                if (!p.status_c.equals("Confirmed", ignoreCase = true) || p.expected_kidding_date_c.isNullOrBlank()) false
                else {
                    try {
                        val dueMillis = dateFormat.parse(p.expected_kidding_date_c)?.time ?: 0L
                        val diffDays = (dueMillis - System.currentTimeMillis()) / (1000 * 60 * 60 * 24)
                        diffDays in -7..14
                    } catch (e: Exception) {
                        false
                    }
                }
            }

            val kidsCount = goats.count {
                it.sex_c.equals("Kid", ignoreCase = true) ||
                it.status_c.equals("Kid", ignoreCase = true) ||
                it.tag_c.contains("K", ignoreCase = true) ||
                (it.birth_date_c?.let { d ->
                    try {
                        val bMillis = dateFormat.parse(d)?.time ?: 0L
                        val diff = (System.currentTimeMillis() - bMillis) / (1000 * 60 * 60 * 24)
                        diff in 0..180
                    } catch (e: Exception) { false }
                } ?: false)
            }

            val mortalities = database.mortalityAndReproductionDao().getAllMortalityEvents()
            val currentMonthPrefix = todayStr.take(7)
            val thisMonthMortalities = mortalities.count { it.death_date.startsWith(currentMonthPrefix) }
            val mortalityCount = if (thisMonthMortalities > 0) thisMonthMortalities else mortalities.size

            val insurancePolicies = database.insuranceDao().getAllPolicies()
            val insuranceBadge = insurancePolicies.count { p ->
                p.status.equals("Expiring Soon", ignoreCase = true) ||
                p.status.equals("Expired", ignoreCase = true) ||
                p.status.equals("Proposal Pending", ignoreCase = true) ||
                (p.status.equals("Active", ignoreCase = true) && try {
                    val exp = dateFormat.parse(p.expiry_date)
                    val now = dateFormat.parse(todayStr)
                    if (exp != null && now != null) {
                        val diffDays = ((exp.time - now.time) / (1000 * 60 * 60 * 24)).toInt()
                        diffDays in 0..30
                    } else false
                } catch (e: Exception) { false })
            }

            val ebUnpaid = database.electricityDao().getAllBills().filter { it.balance_amount > 0 }
            val supUnpaid = database.supplierDao().getAllInvoices().filter { it.balance_due > 0 }
            val loans = database.loanDao().getAllLoans().filter { it.status.equals("ACTIVE", ignoreCase = true) && it.outstanding_principal > 0 }
            val recurring = database.recurringExpenseDao().getAllRecurring().filter { it.is_active }
            val paymentsDueBadge = ebUnpaid.size + supUnpaid.size + loans.size + recurring.size
            val paymentsDueAmount = ebUnpaid.sumOf { it.balance_amount } + supUnpaid.sumOf { it.balance_due }

            val dueItems = getDueItems().getOrDefault(emptyList())
            val vacDue = dueItems.count { it.record_type == "Vaccination" && it.days_diff <= 7 }

            val weaningDueCount = try {
                val weanings = database.weaningDao().getAllWeaningRecordsSync()
                weanings.count { rec ->
                    if (rec.status.equals("WEANED", ignoreCase = true) || rec.status.equals("NOT_APPLICABLE", ignoreCase = true)) false
                    else {
                        val due = try { dateFormat.parse(rec.weaning_due_date) ?: Date() } catch (_: Exception) { Date() }
                        val today = try { dateFormat.parse(todayStr) ?: Date() } catch (_: Exception) { Date() }
                        val diffDays = java.util.concurrent.TimeUnit.MILLISECONDS.toDays(due.time - today.time)
                        diffDays <= 7
                    }
                }
            } catch (_: Exception) { 0 }

            val alertsBadge = dueItems.count { it.days_diff <= 7 } + weaningDueCount

            Result.success(
                LiveDashboardMetrics(
                    totalGoats = totalGoats,
                    pregnantCount = pregnantCount,
                    dueForDeliveryCount = dueForDeliveryCount,
                    kidsCount = kidsCount,
                    mortalityCount = mortalityCount,
                    insuranceBadge = insuranceBadge,
                    paymentsDueBadge = paymentsDueBadge,
                    paymentsDueAmount = paymentsDueAmount,
                    deliveryBadge = dueForDeliveryCount,
                    vaccinationBadge = vacDue,
                    alertsBadge = alertsBadge,
                    weaningDueCount = weaningDueCount
                )
            )
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun searchGlobal(query: String): List<GlobalSearchResult> = withContext(Dispatchers.IO) {
        if (query.isBlank()) return@withContext emptyList()
        val q = query.trim().lowercase()
        val results = mutableListOf<GlobalSearchResult>()

        try {
            // 1. Goats
            val goats = database.goatDao().getAllGoats()
            for (g in goats) {
                if (g.tag_c.lowercase().contains(q) || g.name.lowercase().contains(q) || g.breed_c.lowercase().contains(q)) {
                    results.add(
                        GlobalSearchResult(
                            id = g.id,
                            title = "${g.tag_c} • ${g.name}",
                            subtitle = "Goat • ${g.breed_c} (${g.sex_c}) • Status: ${g.status_c}",
                            moduleType = "Goat",
                            targetRoute = "goat_profile?goatId=${g.id}"
                        )
                    )
                }
            }

            // 2. Customers
            val customers = database.customerDao().getAllCustomers()
            for (c in customers) {
                if (c.name_c.lowercase().contains(q) || (c.phone_c ?: "").contains(q)) {
                    results.add(
                        GlobalSearchResult(
                            id = c.id,
                            title = c.name_c,
                            subtitle = "Customer • Phone: ${c.phone_c ?: "N/A"} • Balance: ₹${String.format(Locale.US, "%.0f", c.outstanding_balance_c)}",
                            moduleType = "Customer",
                            targetRoute = "sales"
                        )
                    )
                }
            }

            // 3. Suppliers
            val suppliers = database.supplierDao().getAllSuppliers()
            for (s in suppliers) {
                if (s.name.lowercase().contains(q) || (s.address ?: "").lowercase().contains(q) || (s.phone ?: "").contains(q)) {
                    results.add(
                        GlobalSearchResult(
                            id = s.id,
                            title = s.name,
                            subtitle = "Supplier • Phone: ${s.phone ?: "N/A"} • Outstanding: ₹${String.format(Locale.US, "%.0f", s.current_outstanding)}",
                            moduleType = "Supplier",
                            targetRoute = "suppliers"
                        )
                    )
                }
            }

            // 4. Invoices
            val supInvoices = database.supplierDao().getAllInvoices()
            for (inv in supInvoices) {
                if (inv.invoice_number.lowercase().contains(q) || inv.items_description.lowercase().contains(q)) {
                    results.add(
                        GlobalSearchResult(
                            id = inv.id,
                            title = "Invoice #${inv.invoice_number}",
                            subtitle = "Supplier Bill • ${inv.items_description} • ₹${String.format(Locale.US, "%.0f", inv.total_amount)}",
                            moduleType = "Invoice",
                            targetRoute = "suppliers"
                        )
                    )
                }
            }

            // 5. Insurance Policies
            val policies = database.insuranceDao().getAllPolicies()
            for (pol in policies) {
                val polNumMatch = pol.policy_number?.lowercase()?.contains(q) == true
                if (polNumMatch || pol.goat_tag.lowercase().contains(q) || pol.insurance_company.lowercase().contains(q)) {
                    results.add(
                        GlobalSearchResult(
                            id = pol.id,
                            title = "Policy #${pol.policy_number ?: "Draft"}",
                            subtitle = "Insurance • Goat: ${pol.goat_tag} • ${pol.insurance_company} • Status: ${pol.status}",
                            moduleType = "Insurance",
                            targetRoute = "livestock_insurance"
                        )
                    )
                }
            }

            // 6. Loans
            val loans = database.loanDao().getAllLoans()
            for (l in loans) {
                if (l.loan_name.lowercase().contains(q) || l.lender.lowercase().contains(q) || l.loan_account_number.lowercase().contains(q)) {
                    results.add(
                        GlobalSearchResult(
                            id = l.id,
                            title = l.loan_name,
                            subtitle = "Loan • ${l.lender} • Bal: ₹${String.format(Locale.US, "%.0f", l.outstanding_principal)}",
                            moduleType = "Loan",
                            targetRoute = "loans"
                        )
                    )
                }
            }

            // 7. Assets
            val assets = database.farmAssetDao().getAllAssets()
            for (a in assets) {
                if (a.name.lowercase().contains(q) || a.category.lowercase().contains(q) || (a.asset_id ?: "").lowercase().contains(q)) {
                    results.add(
                        GlobalSearchResult(
                            id = a.id,
                            title = a.name,
                            subtitle = "Asset • ${a.category} • Value: ₹${String.format(Locale.US, "%.0f", a.current_book_value)}",
                            moduleType = "Asset",
                            targetRoute = "farm_assets"
                        )
                    )
                }
            }
        } catch (e: Exception) {
            // return partial results
        }

        results.take(30)
    }
}

data class LiveDashboardMetrics(
    val totalGoats: Int = 0,
    val pregnantCount: Int = 0,
    val dueForDeliveryCount: Int = 0,
    val kidsCount: Int = 0,
    val mortalityCount: Int = 0,
    val insuranceBadge: Int = 0,
    val paymentsDueBadge: Int = 0,
    val paymentsDueAmount: Double = 0.0,
    val deliveryBadge: Int = 0,
    val vaccinationBadge: Int = 0,
    val alertsBadge: Int = 0,
    val weaningDueCount: Int = 0
)

data class GlobalSearchResult(
    val id: String,
    val title: String,
    val subtitle: String,
    val moduleType: String,
    val targetRoute: String
)
