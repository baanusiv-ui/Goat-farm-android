package com.example.ui.screens.sales

import android.Manifest
import android.content.pm.PackageManager
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.data.payment.SmsPaymentCandidate
import com.example.data.payment.SmsReconciliationManager
import com.example.data.supabase.CustomerRecord
import com.example.data.supabase.SaleRecord
import com.example.ui.theme.FarmGreenDark
import com.example.util.CurrencyUtils
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun SmsReconciliationView(
    smsManager: SmsReconciliationManager,
    sales: List<SaleRecord>,
    customers: List<CustomerRecord>,
    onMatchConfirmed: (candidate: SmsPaymentCandidate, targetSale: SaleRecord) -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    var candidates by remember { mutableStateOf<List<SmsPaymentCandidate>>(emptyList()) }
    var isScanning by remember { mutableStateOf(false) }
    var selectedCandidateForDifferentSale by remember { mutableStateOf<SmsPaymentCandidate?>(null) }
    val timeFormat = remember { SimpleDateFormat("dd MMM, hh:mm a", Locale.US) }

    var hasSmsPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.READ_SMS) == PackageManager.PERMISSION_GRANTED
        )
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { perms ->
        val granted = perms[Manifest.permission.READ_SMS] == true || perms[Manifest.permission.RECEIVE_SMS] == true
        hasSmsPermission = granted
        if (granted) {
            coroutineScope.launch {
                isScanning = true
                candidates = smsManager.scanInboxForPayments(sales, customers)
                isScanning = false
            }
        } else {
            Toast.makeText(context, "SMS permission needed to detect bank/UPI payment alerts", Toast.LENGTH_SHORT).show()
        }
    }

    fun triggerScan() {
        if (!hasSmsPermission) {
            permissionLauncher.launch(arrayOf(Manifest.permission.READ_SMS, Manifest.permission.RECEIVE_SMS))
        } else {
            coroutineScope.launch {
                isScanning = true
                candidates = smsManager.scanInboxForPayments(sales, customers)
                isScanning = false
            }
        }
    }

    LaunchedEffect(hasSmsPermission) {
        if (hasSmsPermission) {
            triggerScan()
        }
    }

    Column(modifier = Modifier.fillMaxWidth().padding(16.dp)) {
        // Top Banner / Header
        Surface(
            shape = RoundedCornerShape(12.dp),
            color = Color(0xFFF0FDF4),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFBBF7D0)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier.padding(14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                    Box(
                        modifier = Modifier.size(40.dp).clip(CircleShape).background(Color(0xFFDCFCE7)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.Sms, contentDescription = null, tint = FarmGreenDark, modifier = Modifier.size(22.dp))
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text("SMS Payment Reconciliation", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = FarmGreenDark)
                        Text(
                            text = if (hasSmsPermission) "Auto-matches bank & UPI payment SMS to sales" else "Permission required to reconcile incoming SMS",
                            fontSize = 11.sp,
                            color = Color.Gray
                        )
                    }
                }

                Button(
                    onClick = { triggerScan() },
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = FarmGreenDark),
                    enabled = !isScanning,
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    if (isScanning) {
                        CircularProgressIndicator(modifier = Modifier.size(16.dp), color = Color.White, strokeWidth = 2.dp)
                    } else {
                        Icon(Icons.Default.Sync, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(if (hasSmsPermission) "Scan SMS" else "Enable", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        if (candidates.isEmpty()) {
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = Color.White,
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
                modifier = Modifier.fillMaxWidth().padding(vertical = 20.dp)
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(Icons.Default.CheckCircleOutline, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(44.dp))
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("No Unmatched Payment SMS", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "When customer pays by UPI or bank transfer and your device receives a credit SMS, candidates will appear here for 1-tap confirmation.",
                        fontSize = 12.sp,
                        color = Color.Gray,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(14.dp))
                    OutlinedButton(onClick = { triggerScan() }) {
                        Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Check for Recent Messages", fontSize = 12.sp)
                    }
                }
            }
        } else {
            Text(
                text = "Detected Payments (${candidates.size})",
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp,
                color = Color(0xFF334155),
                modifier = Modifier.padding(bottom = 8.dp)
            )

            LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                items(candidates, key = { it.id }) { candidate ->
                    CandidateCard(
                        candidate = candidate,
                        timeFormat = timeFormat,
                        onMatchAndConfirm = { targetSale ->
                            onMatchConfirmed(candidate, targetSale)
                            candidates = candidates.filter { it.id != candidate.id }
                        },
                        onIgnore = {
                            coroutineScope.launch {
                                smsManager.markCandidateIgnored(candidate.id)
                                candidates = candidates.filter { it.id != candidate.id }
                            }
                        },
                        onChooseDifferentSale = {
                            selectedCandidateForDifferentSale = candidate
                        }
                    )
                }
            }
        }
    }

    // Modal to choose a different sale
    selectedCandidateForDifferentSale?.let { cand ->
        AlertDialog(
            onDismissRequest = { selectedCandidateForDifferentSale = null },
            title = { Text("Select Sale to Reconcile", fontWeight = FontWeight.Bold, fontSize = 16.sp) },
            text = {
                LazyColumn(modifier = Modifier.fillMaxWidth().heightIn(max = 350.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    val eligibleSales = sales.filter { it.payment_status_c != com.example.data.payment.PaymentStatus.PAID }
                    if (eligibleSales.isEmpty()) {
                        item {
                            Text("No pending or credit sales found to match.", color = Color.Gray, fontSize = 13.sp)
                        }
                    } else {
                        items(eligibleSales) { sale ->
                            Card(
                                onClick = {
                                    onMatchConfirmed(cand, sale)
                                    candidates = candidates.filter { it.id != cand.id }
                                    selectedCandidateForDifferentSale = null
                                },
                                shape = RoundedCornerShape(8.dp),
                                colors = CardDefaults.cardColors(containerColor = Color(0xFFF8FAFC)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(10.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(sale.buyer_name_c.ifBlank { "Sale #${sale.id.take(6)}" }, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                        Text("Balance: ${CurrencyUtils.formatInr(sale.balance_due_c)} • ${sale.sale_date_c}", fontSize = 11.sp, color = Color.Gray)
                                    }
                                    Text(CurrencyUtils.formatInr(sale.amount_c), fontWeight = FontWeight.Bold, color = FarmGreenDark, fontSize = 13.sp)
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { selectedCandidateForDifferentSale = null }) {
                    Text("Close")
                }
            }
        )
    }
}

@Composable
private fun CandidateCard(
    candidate: SmsPaymentCandidate,
    timeFormat: SimpleDateFormat,
    onMatchAndConfirm: (SaleRecord) -> Unit,
    onIgnore: () -> Unit,
    onChooseDifferentSale: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
        modifier = Modifier.fillMaxWidth().testTag("sms_candidate_${candidate.id}")
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            // Header: Amount & Provider
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier.size(32.dp).clip(CircleShape).background(Color(0xFFDCFCE7)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.ArrowDownward, contentDescription = null, tint = Color(0xFF15803D), modifier = Modifier.size(18.dp))
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(CurrencyUtils.formatInr(candidate.amount), fontWeight = FontWeight.ExtraBold, fontSize = 16.sp, color = Color(0xFF15803D))
                        Text("From: ${candidate.sender}", fontSize = 11.sp, color = Color.Gray)
                    }
                }
                Text(timeFormat.format(Date(candidate.timestamp)), fontSize = 11.sp, color = Color.Gray)
            }

            if (!candidate.referenceNumber.isNullOrBlank()) {
                Surface(shape = RoundedCornerShape(6.dp), color = Color(0xFFF1F5F9)) {
                    Text("Ref: ${candidate.referenceNumber}", fontSize = 11.sp, color = Color(0xFF475569), modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp))
                }
            }

            // Suggested Match Section
            if (candidate.suggestedSale != null) {
                val sale = candidate.suggestedSale
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Color(0xFFEFF6FF),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFBFDBFE)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = Color(0xFF1D4ED8), modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Possible Match Detected", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = Color(0xFF1D4ED8))
                        }
                        Text("Customer: ${sale.buyer_name_c}", fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                        Text("Sale Amount: ${CurrencyUtils.formatInr(sale.amount_c)} • Balance: ${CurrencyUtils.formatInr(sale.balance_due_c)}", fontSize = 11.sp, color = Color(0xFF1E3A8A))
                        if (candidate.matchReason != null) {
                            Text("Reason: ${candidate.matchReason}", fontSize = 10.sp, color = Color.Gray)
                        }
                    }
                }
            }

            // Action Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (candidate.suggestedSale != null) {
                    Button(
                        onClick = { onMatchAndConfirm(candidate.suggestedSale) },
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = FarmGreenDark),
                        modifier = Modifier.weight(1.3f).height(38.dp),
                        contentPadding = PaddingValues(0.dp)
                    ) {
                        Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Match & Confirm", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }

                OutlinedButton(
                    onClick = onChooseDifferentSale,
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.weight(1f).height(38.dp),
                    contentPadding = PaddingValues(0.dp)
                ) {
                    Text("Choose Sale", fontSize = 11.sp)
                }

                TextButton(
                    onClick = onIgnore,
                    modifier = Modifier.height(38.dp),
                    contentPadding = PaddingValues(horizontal = 8.dp)
                ) {
                    Text("Ignore", fontSize = 11.sp, color = Color.Gray)
                }
            }
        }
    }
}
