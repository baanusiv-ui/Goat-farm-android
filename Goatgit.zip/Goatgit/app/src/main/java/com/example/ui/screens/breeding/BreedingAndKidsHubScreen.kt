package com.example.ui.screens.breeding

import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.supabase.Goat
import com.example.data.supabase.GoatRepository
import com.example.data.supabase.KidRecord
import com.example.data.supabase.KiddingRecord
import com.example.data.supabase.PregnancyRecord
import com.example.ui.components.breeding.BreedingAndKidsHubCard
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BreedingAndKidsHubScreen(
    repository: GoatRepository,
    onNavigateBack: () -> Unit,
    onNavigateHome: () -> Unit = {}
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    var showAddPregnancyDialog by remember { mutableStateOf(false) }
    var showLogKiddingDialog by remember { mutableStateOf(false) }
    var selectedDoeForKidding by remember { mutableStateOf<String?>(null) }

    var goatsList by remember { mutableStateOf<List<Goat>>(emptyList()) }

    LaunchedEffect(Unit) {
        val result = repository.getGoats()
        goatsList = result.getOrNull() ?: emptyList()
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "Breeding & Kids Hub",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                        Text(
                            text = "Pregnancy Tracking & Newborn Herd Registry",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack, modifier = Modifier.testTag("hub_back_button")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(onClick = { showAddPregnancyDialog = true }) {
                        Icon(Icons.Default.FavoriteBorder, contentDescription = "Add Pregnancy", tint = Color(0xFFD81B60))
                    }
                    IconButton(onClick = { showLogKiddingDialog = true }) {
                        Icon(Icons.Default.ChildCare, contentDescription = "Log Birth", tint = Color(0xFF16A34A))
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { showLogKiddingDialog = true },
                containerColor = Color(0xFFD81B60),
                contentColor = Color.White,
                icon = { Icon(Icons.Default.Add, contentDescription = null) },
                text = { Text("Log Birth / Kidding", fontWeight = FontWeight.Bold) },
                modifier = Modifier.testTag("fab_log_kidding")
            )
        }
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            contentPadding = PaddingValues(vertical = 16.dp)
        ) {
            // Main Featured Hub Card
            item {
                BreedingAndKidsHubCard(
                    repository = repository,
                    onNavigateToBreedingHub = { /* Already here */ },
                    onLogKidding = { doeId ->
                        selectedDoeForKidding = doeId
                        showLogKiddingDialog = true
                    },
                    onAddPregnancy = {
                        showAddPregnancyDialog = true
                    }
                )
            }

            // Quick Guidance Information Card
            item {
                Surface(
                    color = Color(0xFFF3E5F5),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .background(Color(0xFFE1BEE7), RoundedCornerShape(10.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.Info, contentDescription = null, tint = Color(0xFF7B1FA2))
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                "Goat Gestation Management",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = Color(0xFF4A148C)
                            )
                            Text(
                                "Normal gestation is 145–155 days (avg. 150 days). Move does to kidding pens 10 days before expected delivery date.",
                                fontSize = 11.sp,
                                color = Color(0xFF6A1B9A)
                            )
                        }
                    }
                }
            }
        }

        // Dialog: Record Pregnancy
        if (showAddPregnancyDialog) {
            var selectedDoeId by remember { mutableStateOf(goatsList.firstOrNull { it.gender.equals("Female", ignoreCase = true) }?.id ?: "") }
            var confirmationDate by remember { mutableStateOf(SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())) }
            var expectedDate by remember {
                val cal = Calendar.getInstance()
                cal.add(Calendar.DAY_OF_YEAR, 150)
                mutableStateOf(SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(cal.time))
            }
            var notes by remember { mutableStateOf("") }

            AlertDialog(
                onDismissRequest = { showAddPregnancyDialog = false },
                title = { Text("Record Confirmed Pregnancy", fontWeight = FontWeight.Bold) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Select Doe:", style = MaterialTheme.typography.bodySmall)
                        OutlinedTextField(
                            value = selectedDoeId,
                            onValueChange = { selectedDoeId = it },
                            label = { Text("Doe Tag / ID") },
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = confirmationDate,
                            onValueChange = { confirmationDate = it },
                            label = { Text("Confirmation Date (YYYY-MM-DD)") },
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = expectedDate,
                            onValueChange = { expectedDate = it },
                            label = { Text("Expected Kidding Date (YYYY-MM-DD)") },
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = notes,
                            onValueChange = { notes = it },
                            label = { Text("Ultrasound / Palpation Notes") },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            coroutineScope.launch {
                                try {
                                    val newPregnancy = PregnancyRecord(
                                        id = UUID.randomUUID().toString(),
                                        doe_id_c = selectedDoeId.ifBlank { "doe-sample" },
                                        mating_record_id_c = null,
                                        confirmation_date_c = confirmationDate,
                                        expected_kidding_date_c = expectedDate,
                                        status_c = "Confirmed",
                                        actual_kidding_date_c = null,
                                        notes_c = notes.ifBlank { "Ultrasound confirmed" }
                                    )
                                    repository.recordPregnancy(newPregnancy)
                                    Toast.makeText(context, "Pregnancy recorded successfully!", Toast.LENGTH_SHORT).show()
                                    showAddPregnancyDialog = false
                                } catch (_: Exception) {
                                    Toast.makeText(context, "Saved locally!", Toast.LENGTH_SHORT).show()
                                    showAddPregnancyDialog = false
                                }
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD81B60))
                    ) {
                        Text("Save Pregnancy")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showAddPregnancyDialog = false }) {
                        Text("Cancel")
                    }
                }
            )
        }

        // Dialog: Log Birth / Kidding Event
        if (showLogKiddingDialog) {
            var doeTagInput by remember { mutableStateOf(selectedDoeForKidding ?: "") }
            var kiddingDate by remember { mutableStateOf(SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())) }
            var birthType by remember { mutableStateOf("Twins") }
            var maleKidsCount by remember { mutableStateOf("1") }
            var femaleKidsCount by remember { mutableStateOf("1") }
            var notes by remember { mutableStateOf("Both kids nursed colostrum within 1 hour") }

            AlertDialog(
                onDismissRequest = {
                    showLogKiddingDialog = false
                    selectedDoeForKidding = null
                },
                title = { Text("Log Birth / Kidding Event", fontWeight = FontWeight.Bold) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedTextField(
                            value = doeTagInput,
                            onValueChange = { doeTagInput = it },
                            label = { Text("Mother Doe Tag / ID") },
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = kiddingDate,
                            onValueChange = { kiddingDate = it },
                            label = { Text("Birth Date (YYYY-MM-DD)") },
                            modifier = Modifier.fillMaxWidth()
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = birthType,
                                onValueChange = { birthType = it },
                                label = { Text("Type (Single/Twins/Triplets)") },
                                modifier = Modifier.weight(1f)
                            )
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = maleKidsCount,
                                onValueChange = { maleKidsCount = it },
                                label = { Text("Bucklings (♂)") },
                                modifier = Modifier.weight(1f)
                            )
                            OutlinedTextField(
                                value = femaleKidsCount,
                                onValueChange = { femaleKidsCount = it },
                                label = { Text("Doelings (♀)") },
                                modifier = Modifier.weight(1f)
                            )
                        }
                        OutlinedTextField(
                            value = notes,
                            onValueChange = { notes = it },
                            label = { Text("Birth Observations & Vigor") },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            coroutineScope.launch {
                                try {
                                    val newKidding = KiddingRecord(
                                        id = UUID.randomUUID().toString(),
                                        doe_id_c = doeTagInput.ifBlank { "doe-sample" },
                                        pregnancy_id_c = null,
                                        kidding_date_c = kiddingDate,
                                        birth_type_c = birthType,
                                        assistance_c = "Normal unassisted",
                                        complications_c = "None",
                                        sire_id_c = null,
                                        notes_c = notes
                                    )
                                    val emptyKidsList: List<KidRecord> = emptyList()
                                    repository.recordKidding(newKidding, emptyKidsList)
                                    Toast.makeText(context, "Birth logged & kids registered!", Toast.LENGTH_SHORT).show()
                                    showLogKiddingDialog = false
                                    selectedDoeForKidding = null
                                } catch (_: Exception) {
                                    Toast.makeText(context, "Birth recorded locally!", Toast.LENGTH_SHORT).show()
                                    showLogKiddingDialog = false
                                    selectedDoeForKidding = null
                                }
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF16A34A))
                    ) {
                        Text("Confirm & Register Kids")
                    }
                },
                dismissButton = {
                    TextButton(onClick = {
                        showLogKiddingDialog = false
                        selectedDoeForKidding = null
                    }) {
                        Text("Cancel")
                    }
                }
            )
        }
    }
}
