package com.example.data.supabase

import android.content.Context
import android.content.SharedPreferences
import com.example.BuildConfig

class SupabaseConfig(context: Context? = null) {
    private val prefs: SharedPreferences? = context?.getSharedPreferences("supabase_prefs", Context.MODE_PRIVATE)
    private val memoryStore = mutableMapOf<String, String>()

    constructor(url: String, publishableKey: String) : this(null) {
        saveConfig(url, publishableKey)
    }

    companion object {
        const val DEFAULT_URL = "https://xrjoajpvrcfjpunoruom.supabase.co"
        const val KEY_URL = "supabase_url"
        const val KEY_PUBLISHABLE_KEY = "supabase_publishable_key"
        const val KEY_ACCESS_TOKEN = "access_token"
        const val KEY_REFRESH_TOKEN = "refresh_token"
        const val KEY_USER_EMAIL = "user_email"
        const val KEY_USER_ID = "user_id"
    }

    val url: String
        get() {
            val saved = prefs?.getString(KEY_URL, null) ?: memoryStore[KEY_URL]
            if (!saved.isNullOrBlank()) return saved.trimEnd('/')
            val buildConfigUrl = try {
                BuildConfig::class.java.getField("VITE_SUPABASE_URL").get(null) as? String
            } catch (e: Exception) {
                null
            }
            return if (!buildConfigUrl.isNullOrBlank()) buildConfigUrl.trimEnd('/') else DEFAULT_URL
        }

    val publishableKey: String
        get() {
            val saved = prefs?.getString(KEY_PUBLISHABLE_KEY, null) ?: memoryStore[KEY_PUBLISHABLE_KEY]
            if (!saved.isNullOrBlank()) return saved.trim()
            val buildConfigKey = try {
                BuildConfig::class.java.getField("VITE_SUPABASE_PUBLISHABLE_KEY").get(null) as? String
            } catch (e: Exception) {
                null
            }
            return buildConfigKey?.trim() ?: ""
        }

    val apiKey: String get() = publishableKey
    val anonKey: String get() = publishableKey

    val websocketUrl: String
        get() {
            val baseUrl = url
            val wsScheme = if (baseUrl.startsWith("https://")) "wss://" else "ws://"
            val hostAndPath = baseUrl.removePrefix("https://").removePrefix("http://").trimEnd('/')
            return "$wsScheme$hostAndPath/realtime/v1/websocket?apikey=$publishableKey&vsn=1.0.0"
        }

    val restUrl: String get() = "${url.trimEnd('/')}/rest/v1"
    val authUrl: String get() = "${url.trimEnd('/')}/auth/v1"

    val accessToken: String?
        get() = prefs?.getString(KEY_ACCESS_TOKEN, null) ?: memoryStore[KEY_ACCESS_TOKEN]

    val refreshToken: String?
        get() = prefs?.getString(KEY_REFRESH_TOKEN, null) ?: memoryStore[KEY_REFRESH_TOKEN]

    val userEmail: String?
        get() = prefs?.getString(KEY_USER_EMAIL, null) ?: memoryStore[KEY_USER_EMAIL]

    val userId: String?
        get() = prefs?.getString(KEY_USER_ID, null) ?: memoryStore[KEY_USER_ID]

    fun hasValidKey(): Boolean = publishableKey.isNotBlank() && !publishableKey.startsWith("YOUR_")

    fun isAuthenticated(): Boolean = !accessToken.isNullOrBlank()

    fun saveConfig(newUrl: String, newKey: String) {
        memoryStore[KEY_URL] = newUrl.trimEnd('/')
        memoryStore[KEY_PUBLISHABLE_KEY] = newKey.trim()
        prefs?.edit()
            ?.putString(KEY_URL, newUrl.trimEnd('/'))
            ?.putString(KEY_PUBLISHABLE_KEY, newKey.trim())
            ?.apply()
    }

    fun saveSession(accessToken: String, refreshToken: String?, email: String?, userId: String?) {
        memoryStore[KEY_ACCESS_TOKEN] = accessToken
        if (refreshToken != null) memoryStore[KEY_REFRESH_TOKEN] = refreshToken
        if (email != null) memoryStore[KEY_USER_EMAIL] = email
        if (userId != null) memoryStore[KEY_USER_ID] = userId
        prefs?.edit()?.apply {
            putString(KEY_ACCESS_TOKEN, accessToken)
            putString(KEY_REFRESH_TOKEN, refreshToken)
            putString(KEY_USER_EMAIL, email)
            putString(KEY_USER_ID, userId)
            apply()
        }
    }

    fun clearSession() {
        memoryStore.remove(KEY_ACCESS_TOKEN)
        memoryStore.remove(KEY_REFRESH_TOKEN)
        memoryStore.remove(KEY_USER_EMAIL)
        memoryStore.remove(KEY_USER_ID)
        prefs?.edit()?.apply {
            remove(KEY_ACCESS_TOKEN)
            remove(KEY_REFRESH_TOKEN)
            remove(KEY_USER_EMAIL)
            remove(KEY_USER_ID)
            apply()
        }
    }
}
