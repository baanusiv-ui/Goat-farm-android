package com.example.ui.screens.health

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.supabase.*
import com.example.ui.components.DatePickerField
import com.example.ui.theme.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun QuarantineScreen(
    repository: GoatRepository,
    initialGoatId: String? = null,
    onNavigateBack: () -> Unit,
    onNavigateToVaccination: (String) -> Unit = {},
    onNavigateToDeworming: (String) -> Unit = {},
    onNavigateToTreatment: (String) -> Unit = {},
    showTopBar: Boolean = true
) {
    if (showTopBar) {
        BackHandler { onNavigateBack() }
    }

    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val dateFormat = remember { SimpleDateFormat("yyyy-MM-dd", Locale.US) }
    val today = remember { dateFormat.format(Date()) }
    val todayDate = remember(today) { dateFormat.parse(today) ?: Date() }

    var quarantineRecords by remember { mutableStateOf<List<QuarantineRecord>>(emptyList()) }
    var goats by remember { mutableStateOf<List<Goat>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }

    // Filter tab: 0: All Active, 1: Ending Today, 2: Ending Soon, 3: Overdue, 4: Cleared This Month, 5: All Records
    var selectedFilterTab by remember { mutableIntStateOf(0) }

    var selectedRecordForDetail by remember { mutableStateOf<QuarantineRecord?>(null) }
    var recordToRelease by remember { mutableStateOf<QuarantineRecord?>(null) }
    var recordToExtend by remember { mutableStateOf<QuarantineRecord?>(null) }
    var showIntakeDialog by remember { mutableStateOf(false) }

    fun loadData() {
        isLoading = true
        coroutineScope.launch {
            val qRes = repository.getQuarantineRecords()
            if (qRes.isSuccess) quarantineRecords = qRes.getOrThrow()

            val gRes = repository.getGoats()
            if (gRes.isSuccess) goats = gRes.getOrThrow()

            isLoading = false
        }
    }

    LaunchedEffect(Unit) {
        loadData()
        if (initialGoatId != null) {
            coroutineScope.launch {
                val single = repository.getQuarantineRecordForGoat(initialGoatId)
                if (single.isSuccess && single.getOrNull() != null) {
                    selectedRecordForDetail = single.getOrNull()
                }
            }
        }
    }

    // Calculations for KPI dashboard
    val activeRecords = remember(quarantineRecords) {
        quarantineRecords.filter { it.status == "QUARANTINE" || it.status == "EXTENDED" }
    }

    val endingTodayRecords = remember(activeRecords, today) {
        activeRecords.filter { it.planned_end_date == today }
    }

    val endingSoonRecords = remember(activeRecords, todayDate) {
        activeRecords.filter { r ->
            try {
                val d = dateFormat.parse(r.planned_end_date)
                if (d != null) {
                    val diff = (d.time - todayDate.time) / (1000 * 60 * 60 * 24)
                    diff in 1..4
                } else false
            } catch (_: Exception) { false }
        }
    }

    val overdueRecords = remember(activeRecords, todayDate) {
        activeRecords.filter { r ->
            try {
                val d = dateFormat.parse(r.planned_end_date)
                d != null && d.before(todayDate) && r.planned_end_date != today
            } catch (_: Exception) { false }
        }
    }

    val clearedThisMonthRecords = remember(quarantineRecords, today) {
        val currentYearMonth = today.take(7) // e.g. "2026-10"
        quarantineRecords.filter {
            it.status == "CLEARED" && (it.actual_release_date?.startsWith(currentYearMonth) == true)
        }
    }

    val filteredRecords = remember(selectedFilterTab, quarantineRecords, activeRecords, endingTodayRecords, endingSoonRecords, overdueRecords, clearedThisMonthRecords) {
        when (selectedFilterTab) {
            0 -> activeRecords
            1 -> endingTodayRecords
            2 -> endingSoonRecords
            3 -> overdueRecords
            4 -> clearedThisMonthRecords
            else -> quarantineRecords
        }
    }

    Scaffold(
        topBar = {
            if (showTopBar) {
                TopAppBar(
                    title = {
                        Column {
                            Text(
                                text = "Quarantine Management",
                                fontWeight = FontWeight.Bold,
                                fontSize = 18.sp
                            )
                            Text(
                                text = "Market Purchase Isolation & Health Clearance",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    },
                    navigationIcon = {
                        IconButton(onClick = onNavigateBack, modifier = Modifier.testTag("quarantine_btn_back")) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                        }
                    },
                    actions = {
                        IconButton(onClick = { showIntakeDialog = true }, modifier = Modifier.testTag("btn_new_quarantine_intake")) {
                            Icon(Icons.Default.AddModerator, contentDescription = "Add Quarantine Intake", tint = FarmGreenDark)
                        }
                    }
                )
            }
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { showIntakeDialog = true },
                containerColor = FarmGreenPrimary,
                contentColor = Color.White,
                icon = { Icon(Icons.Default.Add, contentDescription = null) },
                text = { Text("Quarantine Intake") },
                modifier = Modifier.testTag("fab_quarantine_intake")
            )
        }
    ) { padding ->
        if (isLoading) {
            Box(modifier = Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = FarmGreenPrimary)
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xFFF8FAFC))
                    .padding(padding)
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                item {
                    Spacer(modifier = Modifier.height(2.dp))
                    // Protocol Banner
                    Surface(
                        color = Color(0xFFFEF3C7),
                        shape = RoundedCornerShape(12.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFFCD34D)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Security, contentDescription = null, tint = Color(0xFFB45309), modifier = Modifier.size(24.dp))
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text("Market Purchase Biosecurity Protocol", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color(0xFF92400E))
                                Text(
                                    "Newly purchased goats must undergo a minimum 14-21 day quarantine and 11-point clinical examination before joining the active herd.",
                                    fontSize = 11.sp,
                                    color = Color(0xFF78350F)
                                )
                            }
                        }
                    }
                }

                // 16. QUARANTINE KPI DASHBOARD: Currently Quarantined, Ending Today, Ending Soon, Overdue, Cleared This Month
                item {
                    Text(
                        text = "QUARANTINE DASHBOARD STATUS",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.Gray,
                        letterSpacing = 0.5.sp
                    )
                }

                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        QuarantineKpiTile(
                            title = "Active",
                            count = activeRecords.size,
                            color = Color(0xFFD97706),
                            isSelected = selectedFilterTab == 0,
                            modifier = Modifier.weight(1f),
                            onClick = { selectedFilterTab = 0 }
                        )
                        QuarantineKpiTile(
                            title = "Today",
                            count = endingTodayRecords.size,
                            color = Color(0xFF2563EB),
                            isSelected = selectedFilterTab == 1,
                            modifier = Modifier.weight(1f),
                            onClick = { selectedFilterTab = 1 }
                        )
                        QuarantineKpiTile(
                            title = "Soon (<4d)",
                            count = endingSoonRecords.size,
                            color = Color(0xFF7C3AED),
                            isSelected = selectedFilterTab == 2,
                            modifier = Modifier.weight(1f),
                            onClick = { selectedFilterTab = 2 }
                        )
                        QuarantineKpiTile(
                            title = "Overdue",
                            count = overdueRecords.size,
                            color = Color(0xFFDC2626),
                            isSelected = selectedFilterTab == 3,
                            modifier = Modifier.weight(1f),
                            onClick = { selectedFilterTab = 3 }
                        )
                        QuarantineKpiTile(
                            title = "Cleared",
                            count = clearedThisMonthRecords.size,
                            color = Color(0xFF059669),
                            isSelected = selectedFilterTab == 4,
                            modifier = Modifier.weight(1f),
                            onClick = { selectedFilterTab = 4 }
                        )
                    }
                }

                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        val filterLabel = when (selectedFilterTab) {
                            0 -> "Currently Quarantined (${filteredRecords.size})"
                            1 -> "Quarantine Ending Today (${filteredRecords.size})"
                            2 -> "Ending Soon (<4 Days) (${filteredRecords.size})"
                            3 -> "Overdue for Clearance (${filteredRecords.size})"
                            4 -> "Cleared This Month (${filteredRecords.size})"
                            else -> "All Quarantine Records (${filteredRecords.size})"
                        }
                        Text(
                            text = filterLabel.uppercase(),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.Gray,
                            letterSpacing = 0.5.sp
                        )

                        TextButton(onClick = { selectedFilterTab = if (selectedFilterTab == 5) 0 else 5 }) {
                            Text(if (selectedFilterTab == 5) "Show Active" else "View All History", fontSize = 11.sp, color = FarmGreenDark)
                        }
                    }
                }

                if (filteredRecords.isEmpty()) {
                    item {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Box(modifier = Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = FarmGreenDark, modifier = Modifier.size(36.dp))
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text("No quarantine records in this category", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                    Text("All newly purchased goats have been cleared or none match the active filter.", fontSize = 12.sp, color = Color.Gray)
                                }
                            }
                        }
                    }
                } else {
                    items(filteredRecords) { record ->
                        QuarantineRecordCard(
                            record = record,
                            todayDate = todayDate,
                            dateFormat = dateFormat,
                            onOpenDetails = { selectedRecordForDetail = record },
                            onRequestClearance = { recordToRelease = record },
                            onExtendQuarantine = { recordToExtend = record }
                        )
                    }
                }

                item {
                    Spacer(modifier = Modifier.height(72.dp))
                }
            }
        }
    }

    // Detail & Checklist Dialog
    selectedRecordForDetail?.let { record ->
        QuarantineDetailDialog(
            record = record,
            onDismiss = { selectedRecordForDetail = null },
            onUpdateChecklist = { updatedChecklist ->
                coroutineScope.launch {
                    val updated = record.copy(checklist = updatedChecklist)
                    repository.saveQuarantineRecord(updated)
                    selectedRecordForDetail = updated
                    loadData()
                    Toast.makeText(context, "Checklist updated", Toast.LENGTH_SHORT).show()
                }
            },
            onRequestClearance = {
                selectedRecordForDetail = null
                recordToRelease = record
            },
            onExtendQuarantine = {
                selectedRecordForDetail = null
                recordToExtend = record
            },
            onVaccinate = {
                selectedRecordForDetail = null
                onNavigateToVaccination(record.goat_id)
            },
            onDeworm = {
                selectedRecordForDetail = null
                onNavigateToDeworming(record.goat_id)
            },
            onTreatment = {
                selectedRecordForDetail = null
                onNavigateToTreatment(record.goat_id)
            }
        )
    }

    // Clearance Release Dialog
    recordToRelease?.let { record ->
        QuarantineReleaseDialog(
            record = record,
            today = today,
            onDismiss = { recordToRelease = null },
            onConfirmRelease = { releaseDate, vetName, comments ->
                coroutineScope.launch {
                    val res = repository.releaseQuarantine(record.id, releaseDate, vetName, comments)
                    if (res.isSuccess) {
                        Toast.makeText(context, "Goat cleared! Status updated to ACTIVE herd.", Toast.LENGTH_LONG).show()
                        recordToRelease = null
                        loadData()
                    } else {
                        Toast.makeText(context, "Clearance error: ${res.exceptionOrNull()?.message}", Toast.LENGTH_LONG).show()
                    }
                }
            }
        )
    }

    // Extension Dialog
    recordToExtend?.let { record ->
        QuarantineExtensionDialog(
            record = record,
            today = today,
            onDismiss = { recordToExtend = null },
            onConfirmExtension = { newDate, reason, vetName, notes ->
                coroutineScope.launch {
                    val res = repository.extendQuarantine(record.id, newDate, reason, vetName, notes)
                    if (res.isSuccess) {
                        Toast.makeText(context, "Quarantine period extended successfully.", Toast.LENGTH_SHORT).show()
                        recordToExtend = null
                        loadData()
                    } else {
                        Toast.makeText(context, "Extension error: ${res.exceptionOrNull()?.message}", Toast.LENGTH_LONG).show()
                    }
                }
            }
        )
    }

    // New Quarantine Intake Dialog
    if (showIntakeDialog) {
        QuarantineIntakeDialog(
            goats = goats,
            today = today,
            onDismiss = { showIntakeDialog = false },
            onSave = { newRecord ->
                coroutineScope.launch {
                    val res = repository.saveQuarantineRecord(newRecord)
                    if (res.isSuccess) {
                        Toast.makeText(context, "Quarantine intake recorded.", Toast.LENGTH_SHORT).show()
                        showIntakeDialog = false
                        loadData()
                    } else {
                        Toast.makeText(context, "Error: ${res.exceptionOrNull()?.message}", Toast.LENGTH_LONG).show()
                    }
                }
            }
        )
    }
}

@Composable
private fun QuarantineKpiTile(
    title: String,
    count: Int,
    color: Color,
    isSelected: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Surface(
        color = if (isSelected) color.copy(alpha = 0.15f) else Color.White,
        shape = RoundedCornerShape(10.dp),
        border = if (isSelected) androidx.compose.foundation.BorderStroke(1.5.dp, color) else androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
        modifier = modifier.clickable { onClick() }
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(text = "$count", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = color)
            Spacer(modifier = Modifier.height(2.dp))
            Text(text = title, fontSize = 10.sp, color = Color.DarkGray, maxLines = 1)
        }
    }
}

@Composable
private fun QuarantineRecordCard(
    record: QuarantineRecord,
    todayDate: Date,
    dateFormat: SimpleDateFormat,
    onOpenDetails: () -> Unit,
    onRequestClearance: () -> Unit,
    onExtendQuarantine: () -> Unit
) {
    val isCleared = record.status == "CLEARED"
    val isExtended = record.status == "EXTENDED"

    val diffDays = remember(record.planned_end_date, todayDate) {
        try {
            val d = dateFormat.parse(record.planned_end_date)
            if (d != null) ((d.time - todayDate.time) / (1000 * 60 * 60 * 24)).toInt() else 0
        } catch (_: Exception) { 0 }
    }

    val statusBadgeColor = when {
        isCleared -> Color(0xFF059669)
        diffDays < 0 -> Color(0xFFDC2626)
        diffDays == 0 -> Color(0xFF2563EB)
        isExtended -> Color(0xFF7C3AED)
        else -> Color(0xFFD97706)
    }

    val statusBadgeText = when {
        isCleared -> "CLEARED / ACTIVE"
        diffDays < 0 -> "OVERDUE BY ${-diffDays} DAYS"
        diffDays == 0 -> "ENDS TODAY"
        diffDays <= 4 -> "ENDS IN $diffDays DAYS"
        isExtended -> "EXTENDED (${record.planned_end_date})"
        else -> "QUARANTINE (${record.planned_end_date})"
    }

    val completedChecks = remember(record.checklist) {
        record.checklist.count { it.value }
    }
    val totalChecks = record.checklist.size

    Card(
        onClick = onOpenDetails,
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(14.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier.fillMaxWidth().testTag("quarantine_card_${record.goat_id}")
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(statusBadgeColor.copy(alpha = 0.12f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.Shield, contentDescription = null, tint = statusBadgeColor, modifier = Modifier.size(20.dp))
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = if (record.goat_tag.isNotBlank()) "Tag: ${record.goat_tag}" else "Goat #${record.goat_id.take(6)}",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                        Text(
                            text = "Pen: ${record.isolation_location}",
                            fontSize = 11.sp,
                            color = Color.Gray
                        )
                    }
                }

                Surface(
                    color = statusBadgeColor.copy(alpha = 0.12f),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        text = statusBadgeText,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = statusBadgeColor,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            HorizontalDivider(color = Color(0xFFF1F5F9))

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Column {
                    Text("Source / Seller", fontSize = 10.sp, color = Color.Gray)
                    Text(record.seller_name?.ifBlank { record.source_location ?: "Market Purchase" } ?: "Market Purchase", fontSize = 12.sp, fontWeight = FontWeight.Medium)
                }
                Column {
                    Text("Intake Date", fontSize = 10.sp, color = Color.Gray)
                    Text(record.start_date, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                }
                Column {
                    Text("Planned Release", fontSize = 10.sp, color = Color.Gray)
                    Text(record.planned_end_date, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                }
            }

            // Checklist Progress
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Checklist Progress: $completedChecks / $totalChecks items",
                    fontSize = 11.sp,
                    color = if (completedChecks == totalChecks) FarmGreenDark else Color.DarkGray,
                    fontWeight = FontWeight.SemiBold
                )

                if (!isCleared) {
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        OutlinedButton(
                            onClick = onExtendQuarantine,
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("Extend", fontSize = 11.sp)
                        }

                        Button(
                            onClick = onRequestClearance,
                            colors = ButtonDefaults.buttonColors(containerColor = FarmGreenPrimary),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("Clear", fontSize = 11.sp, color = Color.White)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun QuarantineDetailDialog(
    record: QuarantineRecord,
    onDismiss: () -> Unit,
    onUpdateChecklist: (Map<String, Boolean>) -> Unit,
    onRequestClearance: () -> Unit,
    onExtendQuarantine: () -> Unit,
    onVaccinate: () -> Unit,
    onDeworm: () -> Unit,
    onTreatment: () -> Unit
) {
    var checklistState by remember { mutableStateOf(record.checklist.toMutableMap()) }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = Color.White,
            modifier = Modifier.fillMaxWidth().fillMaxHeight(0.9f)
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Quarantine Record",
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp
                        )
                        Text(
                            text = "Goat ${record.goat_tag} (${record.status})",
                            fontSize = 12.sp,
                            color = Color.Gray
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close")
                    }
                }

                HorizontalDivider(modifier = Modifier.padding(vertical = 10.dp))

                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    item {
                        // Quick Clinical Actions
                        Text("QUICK HEALTH ACTIONS", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(
                                onClick = onVaccinate,
                                modifier = Modifier.weight(1f),
                                contentPadding = PaddingValues(horizontal = 6.dp, vertical = 6.dp)
                            ) {
                                Icon(Icons.Default.Vaccines, contentDescription = null, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Vaccinate", fontSize = 11.sp)
                            }
                            OutlinedButton(
                                onClick = onDeworm,
                                modifier = Modifier.weight(1f),
                                contentPadding = PaddingValues(horizontal = 6.dp, vertical = 6.dp)
                            ) {
                                Icon(Icons.Default.Medication, contentDescription = null, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Deworm", fontSize = 11.sp)
                            }
                            OutlinedButton(
                                onClick = onTreatment,
                                modifier = Modifier.weight(1f),
                                contentPadding = PaddingValues(horizontal = 6.dp, vertical = 6.dp)
                            ) {
                                Icon(Icons.Default.Healing, contentDescription = null, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Treatment", fontSize = 11.sp)
                            }
                        }
                    }

                    item {
                        // Intake Details Card
                        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFF8FAFC)), shape = RoundedCornerShape(10.dp)) {
                            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text("INTAKE & OBSERVATIONS", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.DarkGray)
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("Intake Date: ${record.start_date}", fontSize = 12.sp)
                                    Text("Planned End: ${record.planned_end_date}", fontSize = 12.sp)
                                }
                                Text("Location: ${record.isolation_location}", fontSize = 12.sp)
                                if (!record.seller_name.isNullOrBlank()) Text("Seller: ${record.seller_name} (${record.seller_contact ?: "N/A"})", fontSize = 12.sp)
                                if (record.temperature != null) Text("Initial Temp: ${record.temperature} °F", fontSize = 12.sp)
                                if (record.weight != null) Text("Initial Weight: ${record.weight} kg", fontSize = 12.sp)
                                if (!record.notes.isNullOrBlank()) Text("Notes: ${record.notes}", fontSize = 12.sp, color = Color.Gray)
                            }
                        }
                    }

                    item {
                        // 13. QUARANTINE 11-POINT CHECKLIST
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Text("11-POINT QUARANTINE CHECKLIST", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
                            Text("${checklistState.count { it.value }} / ${checklistState.size} done", fontSize = 11.sp, color = FarmGreenDark, fontWeight = FontWeight.Bold)
                        }
                    }

                    items(checklistState.keys.toList()) { key ->
                        val isChecked = checklistState[key] ?: false
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .clickable {
                                    val updated = checklistState.toMutableMap()
                                    updated[key] = !isChecked
                                    checklistState = updated
                                    onUpdateChecklist(updated)
                                }
                                .padding(vertical = 4.dp, horizontal = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Checkbox(
                                checked = isChecked,
                                onCheckedChange = { checked ->
                                    val updated = checklistState.toMutableMap()
                                    updated[key] = checked
                                    checklistState = updated
                                    onUpdateChecklist(updated)
                                }
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = key,
                                fontSize = 13.sp,
                                fontWeight = if (isChecked) FontWeight.SemiBold else FontWeight.Normal,
                                color = if (isChecked) Color.Black else Color.DarkGray
                            )
                        }
                    }

                    if (record.extensions.isNotEmpty()) {
                        item {
                            Text("EXTENSION HISTORY (${record.extensions.size})", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
                            record.extensions.forEach { ext ->
                                Surface(
                                    color = Color(0xFFF1F5F9),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                                ) {
                                    Column(modifier = Modifier.padding(10.dp)) {
                                        Text("Extended to ${ext.new_end_date} on ${ext.extended_date}", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                        Text("Reason: ${ext.reason}", fontSize = 11.sp)
                                        if (ext.veterinarian != null) Text("Vet: ${ext.veterinarian}", fontSize = 11.sp, color = Color.Gray)
                                    }
                                }
                            }
                        }
                    }
                }

                HorizontalDivider(modifier = Modifier.padding(vertical = 10.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    if (record.status != "CLEARED") {
                        OutlinedButton(
                            onClick = onExtendQuarantine,
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Extend")
                        }

                        Button(
                            onClick = onRequestClearance,
                            colors = ButtonDefaults.buttonColors(containerColor = FarmGreenPrimary),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Request Clearance", color = Color.White)
                        }
                    } else {
                        Button(
                            onClick = onDismiss,
                            colors = ButtonDefaults.buttonColors(containerColor = Color.Gray),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Close", color = Color.White)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun QuarantineReleaseDialog(
    record: QuarantineRecord,
    today: String,
    onDismiss: () -> Unit,
    onConfirmRelease: (releaseDate: String, vetName: String, comments: String) -> Unit
) {
    var releaseDate by remember { mutableStateOf(today) }
    var vetName by remember { mutableStateOf(record.veterinarian ?: "") }
    var comments by remember { mutableStateOf("") }
    var confirmedConfirmation by remember { mutableStateOf(false) }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = Color.White,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Text("Quarantine Clearance Release", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Text(
                    "Releasing goat ${record.goat_tag} will update its herd status to ACTIVE, making it eligible for breeding, general herd grazing, and operations.",
                    fontSize = 12.sp,
                    color = Color.DarkGray
                )

                DatePickerField(
                    label = "Clearance Date *",
                    dateValue = releaseDate,
                    onDateSelected = { releaseDate = it }
                )

                OutlinedTextField(
                    value = vetName,
                    onValueChange = { vetName = it },
                    label = { Text("Clearing Veterinarian / Officer *") },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = comments,
                    onValueChange = { comments = it },
                    label = { Text("Clinical Assessment / Clearance Notes") },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 2
                )

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(
                        checked = confirmedConfirmation,
                        onCheckedChange = { confirmedConfirmation = it }
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        "I confirm clinical examination showed no signs of contagious disease, parasites, or fever.",
                        fontSize = 11.sp,
                        color = Color.DarkGray
                    )
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f)) {
                        Text("Cancel")
                    }
                    Button(
                        onClick = {
                            if (vetName.isBlank()) return@Button
                            onConfirmRelease(releaseDate, vetName, comments)
                        },
                        enabled = confirmedConfirmation && vetName.isNotBlank(),
                        colors = ButtonDefaults.buttonColors(containerColor = FarmGreenPrimary),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("CLEAR QUARANTINE", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
private fun QuarantineExtensionDialog(
    record: QuarantineRecord,
    today: String,
    onDismiss: () -> Unit,
    onConfirmExtension: (newDate: String, reason: String, vetName: String?, notes: String?) -> Unit
) {
    val cal = remember {
        Calendar.getInstance().apply {
            add(Calendar.DAY_OF_YEAR, 14)
        }
    }
    val defaultExtDate = remember { SimpleDateFormat("yyyy-MM-dd", Locale.US).format(cal.time) }

    var newEndDate by remember { mutableStateOf(defaultExtDate) }
    var reason by remember { mutableStateOf("Pending recovery / observation of respiratory or digestive symptoms") }
    var vetName by remember { mutableStateOf(record.veterinarian ?: "") }
    var notes by remember { mutableStateOf("") }

    val reasons = listOf(
        "Observation of respiratory / nasal discharge symptoms",
        "Parasite or fever treatment in progress",
        "Pending laboratory fecal / blood test report",
        "Late vaccination booster window",
        "Veterinarian instructed extended isolation",
        "Other"
    )
    var showReasonDropdown by remember { mutableStateOf(false) }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = Color.White,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Text("Extend Quarantine Period", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Text("Original Planned End Date: ${record.planned_end_date}", fontSize = 12.sp, color = Color.Gray)

                DatePickerField(
                    label = "New Planned End Date *",
                    dateValue = newEndDate,
                    onDateSelected = { newEndDate = it }
                )

                Box(modifier = Modifier.fillMaxWidth()) {
                    OutlinedTextField(
                        value = reason,
                        onValueChange = { reason = it },
                        label = { Text("Extension Reason *") },
                        modifier = Modifier.fillMaxWidth(),
                        trailingIcon = {
                            IconButton(onClick = { showReasonDropdown = !showReasonDropdown }) {
                                Icon(Icons.Default.ArrowDropDown, contentDescription = null)
                            }
                        }
                    )
                    DropdownMenu(expanded = showReasonDropdown, onDismissRequest = { showReasonDropdown = false }) {
                        reasons.forEach { r ->
                            DropdownMenuItem(text = { Text(r, fontSize = 12.sp) }, onClick = {
                                reason = r
                                showReasonDropdown = false
                            })
                        }
                    }
                }

                OutlinedTextField(
                    value = vetName,
                    onValueChange = { vetName = it },
                    label = { Text("Advising Veterinarian") },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Additional Clinical Notes") },
                    modifier = Modifier.fillMaxWidth()
                )

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f)) {
                        Text("Cancel")
                    }
                    Button(
                        onClick = {
                            if (newEndDate.isNotBlank() && reason.isNotBlank()) {
                                onConfirmExtension(newEndDate, reason, vetName.ifBlank { null }, notes.ifBlank { null })
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD97706)),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Save Extension", color = Color.White)
                    }
                }
            }
        }
    }
}

@Composable
private fun QuarantineIntakeDialog(
    goats: List<Goat>,
    today: String,
    onDismiss: () -> Unit,
    onSave: (QuarantineRecord) -> Unit
) {
    var selectedGoatId by remember { mutableStateOf(goats.firstOrNull()?.id ?: "") }
    var startDate by remember { mutableStateOf(today) }

    val cal = remember {
        Calendar.getInstance().apply {
            add(Calendar.DAY_OF_YEAR, 21)
        }
    }
    val defaultEnd = remember { SimpleDateFormat("yyyy-MM-dd", Locale.US).format(cal.time) }
    var plannedEndDate by remember { mutableStateOf(defaultEnd) }

    var isolationLocation by remember { mutableStateOf("Isolation Pen A") }
    var sellerName by remember { mutableStateOf("") }
    var sellerContact by remember { mutableStateOf("") }
    var sourceLocation by remember { mutableStateOf("Livestock Shandy / Market") }
    var initialHealthStatus by remember { mutableStateOf("Under Observation") }
    var tempStr by remember { mutableStateOf("") }
    var weightStr by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }

    var showGoatDropdown by remember { mutableStateOf(false) }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = Color.White,
            modifier = Modifier.fillMaxWidth().fillMaxHeight(0.85f)
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text("New Quarantine Intake", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Text("Isolate goat and initiate 21-day observation protocol", fontSize = 12.sp, color = Color.Gray)

                HorizontalDivider(modifier = Modifier.padding(vertical = 10.dp))

                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    item {
                        // Goat selection
                        val selectedGoat = goats.find { it.id == selectedGoatId }
                        Box(modifier = Modifier.fillMaxWidth()) {
                            OutlinedTextField(
                                value = selectedGoat?.let { "${it.tag_c} - ${it.breed_c} (${it.sex_c})" } ?: "Select Goat",
                                onValueChange = {},
                                readOnly = true,
                                label = { Text("Goat to Quarantine *") },
                                modifier = Modifier.fillMaxWidth(),
                                trailingIcon = {
                                    IconButton(onClick = { showGoatDropdown = true }) {
                                        Icon(Icons.Default.ArrowDropDown, contentDescription = null)
                                    }
                                }
                            )
                            DropdownMenu(expanded = showGoatDropdown, onDismissRequest = { showGoatDropdown = false }) {
                                goats.forEach { g ->
                                    DropdownMenuItem(
                                        text = { Text("${g.tag_c} - ${g.name} (${g.breed_c})") },
                                        onClick = {
                                            selectedGoatId = g.id
                                            showGoatDropdown = false
                                        }
                                    )
                                }
                            }
                        }
                    }

                    item {
                        DatePickerField(label = "Intake Date *", dateValue = startDate, onDateSelected = { startDate = it })
                    }
                    item {
                        DatePickerField(label = "Planned Release Date *", dateValue = plannedEndDate, onDateSelected = { plannedEndDate = it })
                    }

                    item {
                        OutlinedTextField(
                            value = isolationLocation,
                            onValueChange = { isolationLocation = it },
                            label = { Text("Isolation Pen / Location *") },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }

                    item {
                        OutlinedTextField(
                            value = sourceLocation,
                            onValueChange = { sourceLocation = it },
                            label = { Text("Market / Shandy Source") },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }

                    item {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = sellerName,
                                onValueChange = { sellerName = it },
                                label = { Text("Seller Name") },
                                modifier = Modifier.weight(1f)
                            )
                            OutlinedTextField(
                                value = sellerContact,
                                onValueChange = { sellerContact = it },
                                label = { Text("Seller Phone") },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }

                    item {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = tempStr,
                                onValueChange = { tempStr = it },
                                label = { Text("Temp (°F)") },
                                modifier = Modifier.weight(1f)
                            )
                            OutlinedTextField(
                                value = weightStr,
                                onValueChange = { weightStr = it },
                                label = { Text("Weight (kg)") },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }

                    item {
                        OutlinedTextField(
                            value = notes,
                            onValueChange = { notes = it },
                            label = { Text("Intake Observations / Notes") },
                            modifier = Modifier.fillMaxWidth(),
                            minLines = 2
                        )
                    }
                }

                HorizontalDivider(modifier = Modifier.padding(vertical = 10.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f)) {
                        Text("Cancel")
                    }
                    Button(
                        onClick = {
                            if (selectedGoatId.isBlank()) return@Button
                            val record = QuarantineRecord(
                                goat_id = selectedGoatId,
                                start_date = startDate,
                                planned_end_date = plannedEndDate,
                                isolation_location = isolationLocation,
                                source_location = sourceLocation.ifBlank { null },
                                seller_name = sellerName.ifBlank { null },
                                seller_contact = sellerContact.ifBlank { null },
                                initial_health_status = initialHealthStatus,
                                temperature = tempStr.toDoubleOrNull(),
                                weight = weightStr.toDoubleOrNull(),
                                notes = notes.ifBlank { null },
                                status = "QUARANTINE"
                            )
                            onSave(record)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = FarmGreenPrimary),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Save Intake", color = Color.White)
                    }
                }
            }
        }
    }
}
