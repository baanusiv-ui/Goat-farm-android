package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.TrendingUp
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.supabase.Goat
import com.example.data.supabase.GoatRepository
import com.example.data.supabase.GoatWeight
import com.example.i18n.t
import com.example.ui.components.DatePickerField
import com.example.ui.components.FarmTopBar
import com.example.ui.components.GoatSelector
import com.example.ui.components.QuickWeightStepper
import com.example.ui.theme.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RecordWeightScreen(
    repository: GoatRepository,
    initialGoatId: String? = null,
    onNavigateBack: () -> Unit,
    onWeightSaved: () -> Unit,
    onNavigateToTrends: (() -> Unit)? = null
) {
    val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.US)
    val today = remember { dateFormat.format(Date()) }

    var goats by remember { mutableStateOf<List<Goat>>(emptyList()) }
    var selectedGoatId by remember { mutableStateOf(initialGoatId ?: "") }
    var weightStr by remember { mutableStateOf("30.0") }
    var date by remember { mutableStateOf(today) }
    var method by remember { mutableStateOf("Scale") }
    var notes by remember { mutableStateOf("") }

    var isLoadingGoats by remember { mutableStateOf(true) }
    var isSaving by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var showSuccessDialog by remember { mutableStateOf(false) }

    val coroutineScope = rememberCoroutineScope()
    val methods = listOf("Scale", "Weight Tape", "Visual Estimate")

    LaunchedEffect(Unit) {
        val res = repository.getGoats()
        isLoadingGoats = false
        if (res.isSuccess) {
            goats = res.getOrThrow()
            if (selectedGoatId.isBlank() && goats.isNotEmpty()) {
                selectedGoatId = goats.first().id
                goats.first().weight_kg_c?.let {
                    weightStr = String.format(Locale.US, "%.1f", it)
                }
            } else {
                val found = goats.find { it.id == selectedGoatId }
                found?.weight_kg_c?.let {
                    weightStr = String.format(Locale.US, "%.1f", it)
                }
            }
        }
    }

    val currentWeightDouble = weightStr.toDoubleOrNull() ?: 0.0

    Scaffold(
        topBar = {
            FarmTopBar(
                title = t("weight.title"),
                canNavigateBack = true,
                onNavigateBack = onNavigateBack,
                actions = {
                    if (onNavigateToTrends != null) {
                        IconButton(
                            onClick = onNavigateToTrends,
                            modifier = Modifier.testTag("btn_top_trends")
                        ) {
                            Icon(
                                Icons.AutoMirrored.Filled.TrendingUp,
                                contentDescription = "Weight Trends",
                                tint = FarmGreenDark
                            )
                        }
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(FarmBackgroundLight)
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            if (onNavigateToTrends != null) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = Color(0xFFECFDF5),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFA7F3D0)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onNavigateToTrends() }
                        .testTag("banner_view_recharts_trends")
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(
                                Icons.AutoMirrored.Filled.TrendingUp,
                                contentDescription = null,
                                tint = FarmGreenDark,
                                modifier = Modifier.size(20.dp)
                            )
                            Column {
                                Text(
                                    text = "Recharts Weight & ADG Visualizer",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp,
                                    color = Color(0xFF065F46)
                                )
                                Text(
                                    text = "Track growth curves against expected breed averages",
                                    fontSize = 10.sp,
                                    color = Color(0xFF047857)
                                )
                            }
                        }
                        Icon(
                            Icons.Default.ChevronRight,
                            contentDescription = null,
                            tint = FarmGreenDark,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    if (isLoadingGoats) {
                        CircularProgressIndicator(modifier = Modifier.size(24.dp), color = FarmGreenPrimary)
                    } else {
                        GoatSelector(
                            goats = goats,
                            selectedGoatId = selectedGoatId,
                            onGoatSelected = { g ->
                                selectedGoatId = g.id
                                if (g.weight_kg_c != null && g.weight_kg_c > 0) {
                                    weightStr = String.format(Locale.US, "%.1f", g.weight_kg_c)
                                }
                            }
                        )
                    }

                    // Weight Input with Big Digits
                    Text("${t("herd.weight")} (kg) *", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.SemiBold)
                    OutlinedTextField(
                        value = weightStr,
                        onValueChange = { weightStr = it; errorMessage = null },
                        placeholder = { Text("0.0") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        textStyle = MaterialTheme.typography.headlineMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = FarmGreenDark
                        ),
                        trailingIcon = {
                            Text(
                                "kg",
                                fontWeight = FontWeight.Bold,
                                fontSize = 18.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(end = 16.dp)
                            )
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("record_weight_input")
                    )

                    // Quick steppers for field entry
                    QuickWeightStepper(
                        currentWeight = currentWeightDouble,
                        onWeightChanged = { newWeight ->
                            weightStr = String.format(Locale.US, "%.1f", newWeight)
                        }
                    )
                }
            }

            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    DatePickerField(
                        dateValue = date,
                        onDateSelected = { date = it },
                        label = t("weight.date_label")
                    )

                    // Method Dropdown
                    var methodExpanded by remember { mutableStateOf(false) }
                    ExposedDropdownMenuBox(
                        expanded = methodExpanded,
                        onExpandedChange = { methodExpanded = !methodExpanded }
                    ) {
                        OutlinedTextField(
                            value = method,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Method *") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = methodExpanded) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .menuAnchor()
                        )
                        ExposedDropdownMenu(
                            expanded = methodExpanded,
                            onDismissRequest = { methodExpanded = false }
                        ) {
                            methods.forEach { m ->
                                DropdownMenuItem(
                                    text = { Text(m) },
                                    onClick = {
                                        method = m
                                        methodExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    OutlinedTextField(
                        value = notes,
                        onValueChange = { notes = it },
                        label = { Text(t("herd.notes")) },
                        placeholder = { Text("e.g. Weighing after grazing, healthy growth") },
                        modifier = Modifier.fillMaxWidth(),
                        minLines = 2,
                        maxLines = 3
                    )
                }
            }

            if (errorMessage != null) {
                Card(colors = CardDefaults.cardColors(containerColor = FarmErrorContainer)) {
                    Text(
                        text = errorMessage ?: "",
                        color = FarmError,
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier.padding(12.dp)
                    )
                }
            }

            Button(
                onClick = {
                    if (selectedGoatId.isBlank()) {
                        errorMessage = "Please select a goat."
                        return@Button
                    }
                    val weight = weightStr.toDoubleOrNull()
                    if (weight == null || weight <= 0.0) {
                        errorMessage = "Please enter a valid positive weight in kg."
                        return@Button
                    }

                    isSaving = true
                    errorMessage = null
                    coroutineScope.launch {
                        val record = GoatWeight(
                            goat_id_c = selectedGoatId,
                            weight_kg_c = weight,
                            date_c = date,
                            method_c = method,
                            notes_c = notes.ifBlank { null }
                        )
                        val res = repository.recordWeight(record)
                        isSaving = false
                        if (res.isSuccess) {
                            showSuccessDialog = true
                        } else {
                            errorMessage = res.exceptionOrNull()?.message ?: "Failed to save weight"
                        }
                    }
                },
                enabled = !isSaving,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp)
                    .testTag("save_weight_button"),
                colors = ButtonDefaults.buttonColors(containerColor = FarmGreenPrimary),
                shape = RoundedCornerShape(12.dp)
            ) {
                if (isSaving) {
                    CircularProgressIndicator(color = Color.White, modifier = Modifier.size(24.dp))
                } else {
                    Text(t("weight.btn_save"), fontSize = 16.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }

    if (showSuccessDialog) {
        val selectedGoat = goats.find { it.id == selectedGoatId }
        AlertDialog(
            onDismissRequest = {
                showSuccessDialog = false
                onWeightSaved()
            },
            icon = {
                Icon(Icons.Default.CheckCircle, contentDescription = null, tint = FarmSuccess, modifier = Modifier.size(48.dp))
            },
            title = { Text(t("weight.saved_success"), fontWeight = FontWeight.Bold) },
            text = {
                Text("$weightStr kg • ${selectedGoat?.name ?: "Goat"} (${selectedGoat?.tag_c ?: ""})")
            },
            confirmButton = {
                Button(
                    onClick = {
                        showSuccessDialog = false
                        onWeightSaved()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = FarmGreenPrimary)
                ) {
                    Text(t("btn.done"))
                }
            }
        )
    }
}
