package com.example.util

import java.util.Locale

object CurrencyUtils {
    const val CURRENCY_CODE = "INR"
    const val SYMBOL = "₹"

    /**
     * Formats an amount as Indian Rupees (₹) with commas and decimals.
     * Example: ₹1,250.00
     */
    fun formatInr(amount: Double, includeDecimals: Boolean = true): String {
        return if (includeDecimals) {
            String.format(Locale.US, "₹%,.2f", amount)
        } else {
            String.format(Locale.US, "₹%,.0f", amount)
        }
    }

    fun format(amount: Double): String = formatInr(amount)

    /**
     * Returns the formatted string or placeholder if null.
     */
    fun formatInrOrDash(amount: Double?): String {
        return if (amount != null) formatInr(amount) else "—"
    }
}
