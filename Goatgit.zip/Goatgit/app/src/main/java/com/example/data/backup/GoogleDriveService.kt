package com.example.data.backup

import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

data class DriveBackupFile(
    val id: String,
    val name: String,
    val sizeBytes: Long,
    val createdTime: String,
    val appVersion: String? = null,
    val recordCount: Int = 0
)

class GoogleDriveService(private val okHttpClient: OkHttpClient = OkHttpClient.Builder()
    .connectTimeout(30, TimeUnit.SECONDS)
    .readTimeout(60, TimeUnit.SECONDS)
    .writeTimeout(60, TimeUnit.SECONDS)
    .build()
) {
    companion object {
        private const val TAG = "GoogleDriveService"
        const val ROOT_FOLDER_NAME = "Goat Farm Manager"
        const val BACKUPS_FOLDER_NAME = "Backups"
        private const val API_BASE = "https://www.googleapis.com/drive/v3/files"
        private const val UPLOAD_BASE = "https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart"
    }

    suspend fun getOrCreateBackupsFolder(accessToken: String): Result<String> = withContext(Dispatchers.IO) {
        try {
            // 1. Find or create root folder "Goat Farm Manager"
            val rootFolderId = findOrCreateFolder(
                parentFolderId = null,
                folderName = ROOT_FOLDER_NAME,
                accessToken = accessToken
            ) ?: return@withContext Result.failure(Exception("Failed to locate or create '$ROOT_FOLDER_NAME' folder"))

            // 2. Find or create child folder "Backups"
            val backupsFolderId = findOrCreateFolder(
                parentFolderId = rootFolderId,
                folderName = BACKUPS_FOLDER_NAME,
                accessToken = accessToken
            ) ?: return@withContext Result.failure(Exception("Failed to locate or create '$BACKUPS_FOLDER_NAME' folder"))

            Result.success(backupsFolderId)
        } catch (e: Exception) {
            Log.e(TAG, "Error resolving backups folder: ${e.message}", e)
            Result.failure(e)
        }
    }

    private fun findOrCreateFolder(parentFolderId: String?, folderName: String, accessToken: String): String? {
        val query = if (parentFolderId == null) {
            "name = '$folderName' and mimeType = 'application/vnd.google-apps.folder' and trashed = false"
        } else {
            "name = '$folderName' and '$parentFolderId' in parents and mimeType = 'application/vnd.google-apps.folder' and trashed = false"
        }
        val encodedQuery = URLEncoder.encode(query, "UTF-8")
        val searchUrl = "$API_BASE?q=$encodedQuery&fields=files(id,name)&spaces=drive"

        val searchRequest = Request.Builder()
            .url(searchUrl)
            .addHeader("Authorization", "Bearer $accessToken")
            .get()
            .build()

        val searchResponse = okHttpClient.newCall(searchRequest).execute()
        if (searchResponse.isSuccessful) {
            val responseBody = searchResponse.body?.string().orEmpty()
            val filesJson = JSONObject(responseBody).optJSONArray("files") ?: JSONArray()
            if (filesJson.length() > 0) {
                return filesJson.getJSONObject(0).getString("id")
            }
        }

        // Folder doesn't exist, create it
        val createPayload = JSONObject().apply {
            put("name", folderName)
            put("mimeType", "application/vnd.google-apps.folder")
            if (parentFolderId != null) {
                put("parents", JSONArray().put(parentFolderId))
            }
        }

        val createRequest = Request.Builder()
            .url(API_BASE)
            .addHeader("Authorization", "Bearer $accessToken")
            .addHeader("Content-Type", "application/json; charset=UTF-8")
            .post(createPayload.toString().toRequestBody("application/json".toMediaType()))
            .build()

        val createResponse = okHttpClient.newCall(createRequest).execute()
        if (createResponse.isSuccessful) {
            val body = createResponse.body?.string().orEmpty()
            return JSONObject(body).getString("id")
        } else {
            Log.e(TAG, "Create folder failed: ${createResponse.code} - ${createResponse.message}")
            return null
        }
    }

    suspend fun uploadBackupFile(
        folderId: String,
        fileName: String,
        jsonContent: String,
        accessToken: String
    ): Result<String> = withContext(Dispatchers.IO) {
        try {
            val boundary = "==GoogleDriveBackupBoundary=="
            val metadataPart = JSONObject().apply {
                put("name", fileName)
                put("mimeType", "application/json")
                put("parents", JSONArray().put(folderId))
            }.toString()

            val multipartBody = buildString {
                append("--$boundary\r\n")
                append("Content-Type: application/json; charset=UTF-8\r\n\r\n")
                append(metadataPart)
                append("\r\n--$boundary\r\n")
                append("Content-Type: application/json; charset=UTF-8\r\n\r\n")
                append(jsonContent)
                append("\r\n--$boundary--\r\n")
            }

            val requestBody = multipartBody.toRequestBody("multipart/related; boundary=$boundary".toMediaType())

            val request = Request.Builder()
                .url(UPLOAD_BASE)
                .addHeader("Authorization", "Bearer $accessToken")
                .post(requestBody)
                .build()

            val response = okHttpClient.newCall(request).execute()
            if (response.isSuccessful) {
                val resBody = response.body?.string().orEmpty()
                val fileId = JSONObject(resBody).getString("id")
                Log.d(TAG, "Uploaded backup file to Google Drive: $fileName (id=$fileId)")
                Result.success(fileId)
            } else {
                val err = "Upload failed: ${response.code} ${response.message} ${response.body?.string()}"
                Log.e(TAG, err)
                Result.failure(Exception(err))
            }
        } catch (e: Exception) {
            Log.e(TAG, "Upload exception: ${e.message}", e)
            Result.failure(e)
        }
    }

    suspend fun listBackups(folderId: String, accessToken: String): Result<List<DriveBackupFile>> = withContext(Dispatchers.IO) {
        try {
            val query = "'$folderId' in parents and mimeType = 'application/json' and trashed = false"
            val encodedQuery = URLEncoder.encode(query, "UTF-8")
            val listUrl = "$API_BASE?q=$encodedQuery&orderBy=createdTime desc&fields=files(id,name,size,createdTime,description)&pageSize=50"

            val request = Request.Builder()
                .url(listUrl)
                .addHeader("Authorization", "Bearer $accessToken")
                .get()
                .build()

            val response = okHttpClient.newCall(request).execute()
            if (response.isSuccessful) {
                val body = response.body?.string().orEmpty()
                val filesArr = JSONObject(body).optJSONArray("files") ?: JSONArray()
                val list = mutableListOf<DriveBackupFile>()
                for (i in 0 until filesArr.length()) {
                    val obj = filesArr.getJSONObject(i)
                    val id = obj.getString("id")
                    val name = obj.getString("name")
                    val size = obj.optLong("size", 0L)
                    val createdTime = obj.optString("createdTime", "")
                    list.add(
                        DriveBackupFile(
                            id = id,
                            name = name,
                            sizeBytes = size,
                            createdTime = createdTime
                        )
                    )
                }
                Result.success(list)
            } else {
                Result.failure(Exception("List backups failed: ${response.code} ${response.message}"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun downloadBackupContent(fileId: String, accessToken: String): Result<String> = withContext(Dispatchers.IO) {
        try {
            val downloadUrl = "$API_BASE/$fileId?alt=media"
            val request = Request.Builder()
                .url(downloadUrl)
                .addHeader("Authorization", "Bearer $accessToken")
                .get()
                .build()

            val response = okHttpClient.newCall(request).execute()
            if (response.isSuccessful) {
                val content = response.body?.string().orEmpty()
                Result.success(content)
            } else {
                Result.failure(Exception("Download failed: ${response.code} ${response.message}"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun deleteFile(fileId: String, accessToken: String): Result<Boolean> = withContext(Dispatchers.IO) {
        try {
            val deleteUrl = "$API_BASE/$fileId"
            val request = Request.Builder()
                .url(deleteUrl)
                .addHeader("Authorization", "Bearer $accessToken")
                .delete()
                .build()

            val response = okHttpClient.newCall(request).execute()
            if (response.isSuccessful || response.code == 404) {
                Result.success(true)
            } else {
                Result.failure(Exception("Delete failed: ${response.code} ${response.message}"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun enforceRetention(folderId: String, keepCount: Int = 30, accessToken: String) = withContext(Dispatchers.IO) {
        try {
            val listRes = listBackups(folderId, accessToken)
            if (listRes.isSuccess) {
                val files = listRes.getOrThrow()
                // Never delete the only available backup
                if (files.size > keepCount && files.size > 1) {
                    val toDelete = files.subList(keepCount, files.size)
                    Log.d(TAG, "Retention policy: deleting ${toDelete.size} older backup files...")
                    for (file in toDelete) {
                        deleteFile(file.id, accessToken)
                    }
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "Retention enforcement warning: ${e.message}")
        }
    }
}
