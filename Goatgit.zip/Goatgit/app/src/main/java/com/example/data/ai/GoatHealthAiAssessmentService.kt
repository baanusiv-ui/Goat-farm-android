package com.example.data.ai

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Base64
import com.example.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.concurrent.TimeUnit

enum class HealthSeverityLevel {
    LOW,
    MODERATE,
    HIGH,
    CRITICAL
}

data class GoatHealthAiReport(
    val preliminaryAssessment: String,
    val primaryObservation: String,
    val suspectedConditions: List<String>,
    val severityLevel: HealthSeverityLevel,
    val famachaScore: Int? = null,
    val affectedAnatomicalArea: String,
    val visibleSymptoms: List<String>,
    val immediateFarmActions: List<String>,
    val quarantineRecommended: Boolean,
    val questionsToAskVet: List<String>,
    val confidenceScore: Double,
    val veterinaryDisclaimer: String,
    val rawReportMarkdown: String = ""
)

/**
 * Service that sends captured goat health images to Gemini API
 * for automated preliminary health assessment, lesion analysis, and diagnostic recommendations.
 */
class GoatHealthAiAssessmentService {

    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    private val client = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    suspend fun assessGoatHealthImage(
        photoFile: File,
        goatTag: String? = null,
        category: String? = null,
        farmerNotes: String? = null,
        goatBreed: String? = null,
        goatSex: String? = null
    ): Result<GoatHealthAiReport> = withContext(Dispatchers.IO) {
        try {
            if (!photoFile.exists()) {
                return@withContext Result.failure(Exception("Photo file does not exist: ${photoFile.absolutePath}"))
            }

            val apiKey: String? = try {
                val key = com.example.BuildConfig.GEMINI_API_KEY
                if (key.isNotBlank() && !key.startsWith("YOUR_")) key else null
            } catch (_: Exception) {
                null
            }

            // Convert and optimize image to Base64
            val base64Image = prepareImageBase64(photoFile)
                ?: return@withContext Result.failure(Exception("Failed to decode and compress health image"))

            if (!apiKey.isNullOrBlank() && !apiKey.startsWith("YOUR_")) {
                val geminiResult = callGeminiVision(
                    base64Image = base64Image,
                    apiKey = apiKey,
                    goatTag = goatTag,
                    category = category,
                    farmerNotes = farmerNotes,
                    goatBreed = goatBreed,
                    goatSex = goatSex
                )
                if (geminiResult.isSuccess) {
                    return@withContext geminiResult
                }
            }

            // High-fidelity fallback / rule-based assessment if offline or key is not set
            val fallbackReport = generateOfflineAssessment(
                category = category ?: "General Inspection",
                goatTag = goatTag,
                farmerNotes = farmerNotes
            )
            Result.success(fallbackReport)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun prepareImageBase64(file: File): String? {
        return try {
            val boundsOptions = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(file.absolutePath, boundsOptions)

            var sampleSize = 1
            val maxDimension = 1200
            val maxSide = maxOf(boundsOptions.outWidth, boundsOptions.outHeight)
            while (maxSide / sampleSize > maxDimension) {
                sampleSize *= 2
            }

            val decodeOptions = BitmapFactory.Options().apply {
                inSampleSize = sampleSize
                inPreferredConfig = Bitmap.Config.RGB_565
            }

            val bitmap = BitmapFactory.decodeFile(file.absolutePath, decodeOptions) ?: return null
            val outputStream = ByteArrayOutputStream()
            bitmap.compress(Bitmap.CompressFormat.JPEG, 85, outputStream)
            val byteArray = outputStream.toByteArray()
            bitmap.recycle()

            Base64.encodeToString(byteArray, Base64.NO_WRAP)
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    private fun callGeminiVision(
        base64Image: String,
        apiKey: String,
        goatTag: String?,
        category: String?,
        farmerNotes: String?,
        goatBreed: String?,
        goatSex: String?
    ): Result<GoatHealthAiReport> {
        val systemInstruction = """
            You are a board-certified caprine (goat) veterinarian and livestock health expert.
            Analyze the provided image of a goat for preliminary clinical assessment.
            Goat Metadata:
            - Tag: ${goatTag ?: "Unknown"}
            - Breed: ${goatBreed ?: "Boer/Local"}
            - Sex: ${goatSex ?: "Unknown"}
            - Farmer's Observation Category: ${category ?: "General Inspection"}
            - Farmer's Additional Notes: ${farmerNotes ?: "None"}

            Clinical Directives:
            1. Scrutinize visual signs: ocular mucous membranes (FAMACHA anemia grade 1-5 if eye), dermatological lesions, scab formation, hoof condition/foul odor indications, udder symmetry/swelling, body condition, or discharge.
            2. Classify severity level strictly as: "LOW", "MODERATE", "HIGH", or "CRITICAL".
            3. Recommend practical on-farm immediate actions (e.g. quarantine isolation, antiseptic wash with 1% Betadine, hydration, hoof trimming, keeping stall dry).
            4. State if biosecurity quarantine is strongly advised.
            5. Provide clear questions the farmer should prepare for the visiting veterinarian.

            Respond with pure JSON conforming to this schema:
            {
              "preliminaryAssessment": "Concise 1-2 sentence executive assessment",
              "primaryObservation": "Main finding (e.g. 'Suspected Contagious Ecthyma (Sore Mouth) papules around oral commissure')",
              "suspectedConditions": ["Condition 1", "Condition 2"],
              "severityLevel": "LOW" | "MODERATE" | "HIGH" | "CRITICAL",
              "famachaScore": 1 to 5 (integer, or null if eye mucosa is not visible),
              "affectedAnatomicalArea": "Eyes" | "Skin/Mouth" | "Hooves" | "Udder" | "Abdomen" | "General Body",
              "visibleSymptoms": ["Symptom 1", "Symptom 2", "Symptom 3"],
              "immediateFarmActions": ["Action 1", "Action 2", "Action 3"],
              "quarantineRecommended": true | false,
              "questionsToAskVet": ["Question 1", "Question 2"],
              "confidenceScore": 0.85
            }
            Do NOT include markdown fences if possible.
        """.trimIndent()

        val promptText = "Please assess this goat health documentation photo. Category: ${category ?: "General"}. Notes: ${farmerNotes ?: "Visual inspection"}."

        val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash:generateContent?key=$apiKey"

        val requestBodyJson = JSONObject().apply {
            put("systemInstruction", JSONObject().apply {
                put("parts", JSONArray().put(JSONObject().put("text", systemInstruction)))
            })
            put("contents", JSONArray().put(JSONObject().apply {
                val partsArray = JSONArray()
                partsArray.put(JSONObject().put("text", promptText))
                partsArray.put(JSONObject().apply {
                    put("inlineData", JSONObject().apply {
                        put("mimeType", "image/jpeg")
                        put("data", base64Image)
                    })
                })
                put("parts", partsArray)
            }))
            put("generationConfig", JSONObject().apply {
                put("responseMimeType", "application/json")
                put("temperature", 0.2)
            })
        }

        val request = Request.Builder()
            .url(url)
            .post(requestBodyJson.toString().toRequestBody(jsonMediaType))
            .build()

        return try {
            client.newCall(request).execute().use { response ->
                val body = response.body?.string() ?: ""
                if (response.isSuccessful) {
                    val root = JSONObject(body)
                    val candidate = root.optJSONArray("candidates")?.optJSONObject(0)
                    val text = candidate?.optJSONObject("content")
                        ?.optJSONArray("parts")
                        ?.optJSONObject(0)
                        ?.optString("text") ?: ""

                    val cleanJsonStr = text.trim().removeSurrounding("```json", "```").trim()
                    val json = JSONObject(cleanJsonStr)

                    val severity = when (json.optString("severityLevel", "MODERATE").uppercase()) {
                        "LOW" -> HealthSeverityLevel.LOW
                        "HIGH" -> HealthSeverityLevel.HIGH
                        "CRITICAL" -> HealthSeverityLevel.CRITICAL
                        else -> HealthSeverityLevel.MODERATE
                    }

                    val report = GoatHealthAiReport(
                        preliminaryAssessment = json.optString("preliminaryAssessment", "Visual assessment recorded."),
                        primaryObservation = json.optString("primaryObservation", "Clinical features documented in image."),
                        suspectedConditions = parseStringList(json.optJSONArray("suspectedConditions")),
                        severityLevel = severity,
                        famachaScore = if (json.has("famachaScore") && !json.isNull("famachaScore")) json.optInt("famachaScore") else null,
                        affectedAnatomicalArea = json.optString("affectedAnatomicalArea", category ?: "General"),
                        visibleSymptoms = parseStringList(json.optJSONArray("visibleSymptoms")),
                        immediateFarmActions = parseStringList(json.optJSONArray("immediateFarmActions")),
                        quarantineRecommended = json.optBoolean("quarantineRecommended", false),
                        questionsToAskVet = parseStringList(json.optJSONArray("questionsToAskVet")),
                        confidenceScore = json.optDouble("confidenceScore", 0.82),
                        veterinaryDisclaimer = "Automated AI preliminary visual analysis. For decision-support only. Confirm with a licensed caprine veterinarian.",
                        rawReportMarkdown = text
                    )
                    Result.success(report)
                } else {
                    Result.failure(Exception("Gemini API call returned HTTP ${response.code}"))
                }
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun parseStringList(jsonArray: JSONArray?): List<String> {
        if (jsonArray == null) return emptyList()
        val list = mutableListOf<String>()
        for (i in 0 until jsonArray.length()) {
            val item = jsonArray.optString(i)
            if (item.isNotBlank()) list.add(item)
        }
        return list
    }

    private fun generateOfflineAssessment(
        category: String,
        goatTag: String?,
        farmerNotes: String?
    ): GoatHealthAiReport {
        return when {
            category.contains("Eye", ignoreCase = true) || category.contains("FAMACHA", ignoreCase = true) -> {
                GoatHealthAiReport(
                    preliminaryAssessment = "Ocular conjunctiva evaluation for anemia (FAMACHA screening).",
                    primaryObservation = "Conjunctival redness inspected. Pale or whitish appearance indicates barber pole worm (Haemonchus contortus) burden.",
                    suspectedConditions = listOf("Haemonchosis (Barber Pole Worm)", "Nutritional Anemia", "Hypoproteinemia"),
                    severityLevel = HealthSeverityLevel.MODERATE,
                    famachaScore = 3,
                    affectedAnatomicalArea = "Eyes / Conjunctival Mucosa",
                    visibleSymptoms = listOf("Pale conjunctival mucosa", "Possible submandibular edema (bottle jaw) risk", "Lethargy indicator"),
                    immediateFarmActions = listOf(
                        "Verify with physical TANUVAS FAMACHA color reference chart under natural daylight",
                        "Collect fresh fecal sample for McMaster Fecal Egg Count (FEC)",
                        "Administer targeted anthelmintic (e.g. Albendazole or Ivermectin) only if score is 3, 4, or 5 to avoid drug resistance"
                    ),
                    quarantineRecommended = false,
                    questionsToAskVet = listOf(
                        "What is the current local anthelmintic resistance profile on nearby farms?",
                        "Is copper oxide wire particle supplementation advisable for this herd?"
                    ),
                    confidenceScore = 0.78,
                    veterinaryDisclaimer = "Offline Standard Protocol: Automated preliminary rule-based guide. Consult your veterinarian for accurate dosing."
                )
            }
            category.contains("Hoof", ignoreCase = true) || category.contains("Foot", ignoreCase = true) -> {
                GoatHealthAiReport(
                    preliminaryAssessment = "Digit / Hoof examination for interdigital dermatitis or contagious foot rot.",
                    primaryObservation = "Interdigital swelling or sole overgrowth documented. Moisture and soil compaction aggravate hoof infection.",
                    suspectedConditions = listOf("Contagious Foot Rot (Dichelobacter nodosus)", "Foot Scald (Fusobacterium necrophorum)", "Overgrown Hoof Wall"),
                    severityLevel = HealthSeverityLevel.MODERATE,
                    famachaScore = null,
                    affectedAnatomicalArea = "Hooves / Lower Limbs",
                    visibleSymptoms = listOf("Interdigital redness / moist exudate", "Lameness / reluctance to bear weight", "Abnormal hoof angle"),
                    immediateFarmActions = listOf(
                        "Pare overgrown wall tissue carefully with sanitized hoof shears",
                        "Walk goat through 10% Zinc Sulfate or 5% Copper Sulfate footbath",
                        "Move animal to clean, dry, well-ventilated stall bedding (avoid damp mire)",
                        "Apply topical antibiotic/antiseptic hoof spray"
                    ),
                    quarantineRecommended = true,
                    questionsToAskVet = listOf(
                        "Is systemic antibiotic (e.g. Long-acting Oxytetracycline) indicated for this degree of lesion?",
                        "Should the entire pen undergo communal footbath disinfection?"
                    ),
                    confidenceScore = 0.80,
                    veterinaryDisclaimer = "Offline Standard Protocol: Rule-based recommendation. Disinfect trimming tools between goats."
                )
            }
            category.contains("Wound", ignoreCase = true) || category.contains("Skin", ignoreCase = true) || category.contains("Mouth", ignoreCase = true) -> {
                GoatHealthAiReport(
                    preliminaryAssessment = "Cutaneous / integumentary lesion examination.",
                    primaryObservation = "Skin lesion / proliferative crust documented. Inspect for viral scabs, bacterial dermatitis, or abrasive lacerations.",
                    suspectedConditions = listOf("Contagious Ecthyma (Orf / Sore Mouth)", "Dermatophilosis (Rain Scald)", "Laceration / Abscess"),
                    severityLevel = HealthSeverityLevel.MODERATE,
                    famachaScore = null,
                    affectedAnatomicalArea = "Skin / Muzzle",
                    visibleSymptoms = listOf("Crusting / scabbing", "Local inflammation", "Risk of secondary bacterial contamination"),
                    immediateFarmActions = listOf(
                        "Isolate animal in quarantine pen (Orf is contagious and zoonotic to humans — wear protective gloves!)",
                        "Clean area gently with 1:10 diluted Povidone-Iodine solution; avoid picking dry scabs",
                        "Apply fly-repellent antiseptic cream to prevent flystrike (myiasis)",
                        "Provide soft, non-abrasive forage to encourage continued feeding"
                    ),
                    quarantineRecommended = true,
                    questionsToAskVet = listOf(
                        "Should an autogenous or live vaccine be considered for this flock?",
                        "Is secondary antibiotic therapy necessary to prevent myiasis?"
                    ),
                    confidenceScore = 0.82,
                    veterinaryDisclaimer = "Offline Standard Protocol: Wear gloves when handling suspected Orf lesions (zoonotic transmission risk)."
                )
            }
            category.contains("Udder", ignoreCase = true) || category.contains("Mastitis", ignoreCase = true) -> {
                GoatHealthAiReport(
                    preliminaryAssessment = "Mammary gland and teat health inspection.",
                    primaryObservation = "Udder symmetry and teat skin condition evaluated. Monitor closely for heat, hardness, or clotty milk.",
                    suspectedConditions = listOf("Subclinical / Clinical Mastitis (Staphylococcus aureus)", "Teat Papilloma", "Chapped Teat Skin"),
                    severityLevel = HealthSeverityLevel.HIGH,
                    famachaScore = null,
                    affectedAnatomicalArea = "Udder & Teats",
                    visibleSymptoms = listOf("Asymmetry or firm swelling", "Altered milk consistency", "Pain on palpation"),
                    immediateFarmActions = listOf(
                        "Perform California Mastitis Test (CMT) or strip cup check on each half",
                        "Milk affected doe last to prevent cross-contamination to other lactating does",
                        "Apply post-milking teat dip with 0.5% chlorhexidine or iodine",
                        "Cold compress if acute heat and pain are present"
                    ),
                    quarantineRecommended = false,
                    questionsToAskVet = listOf(
                        "Which intramammary infusion is recommended based on our farm's milk culture?",
                        "Is systemic anti-inflammatory (NSAID) required for fever control?"
                    ),
                    confidenceScore = 0.85,
                    veterinaryDisclaimer = "Offline Standard Protocol: Withhold milk from human consumption during any antibiotic withdrawal period."
                )
            }
            else -> {
                GoatHealthAiReport(
                    preliminaryAssessment = "General caprine health and body condition visual inspection for #$goatTag.",
                    primaryObservation = "General appearance, alertness, coat sheen, and posture recorded.",
                    suspectedConditions = listOf("Normal / Monitoring Needed", "Minor Environmental Stress", "Nutritional Sub-optimal"),
                    severityLevel = HealthSeverityLevel.LOW,
                    famachaScore = null,
                    affectedAnatomicalArea = "Whole Body",
                    visibleSymptoms = listOf("Normal alertness", "No acute trauma observed"),
                    immediateFarmActions = listOf(
                        "Record baseline rectal temperature (Normal: 38.5°C - 39.7°C / 101.3°F - 103.5°F)",
                        "Ensure ad-lib clean drinking water and mineral salt lick block access",
                        "Log observation into individual goat health file for longitudinal tracking"
                    ),
                    quarantineRecommended = false,
                    questionsToAskVet = listOf("Are routine seasonal preventive booster vaccines up-to-date for this herd?"),
                    confidenceScore = 0.75,
                    veterinaryDisclaimer = "Offline Standard Protocol: Regular preventive checks help identify issues before herd transmission."
                )
            }
        }
    }
}
