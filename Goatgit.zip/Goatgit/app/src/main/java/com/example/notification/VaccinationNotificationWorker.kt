package com.example.notification

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.work.*
import com.example.MainActivity
import com.example.R
import com.example.data.offline.AppDatabase
import com.example.data.offline.FarmSettingEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.TimeUnit

class VaccinationNotificationWorker(
    appContext: Context,
    workerParams: WorkerParameters
) : CoroutineWorker(appContext, workerParams) {

    companion object {
        const val TAG = "VaccinationWorker"
        const val CHANNEL_ID = "goat_vaccination_reminders"
        const val CHANNEL_NAME = "Vaccination Reminders"
    }

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        Log.d(TAG, "Starting recurring check for upcoming goat vaccinations...")
        val context = applicationContext
        val database = AppDatabase.getDatabase(context)

        try {
            createNotificationChannel(context)

            val enabledSetting = database.farmSettingsDao().getSetting("vaccination_notifications_enabled")?.value_c
            if (enabledSetting == "false") {
                Log.d(TAG, "Vaccination notifications are disabled by user. Skipping.")
                return@withContext Result.success()
            }

            val vaccinations = database.healthDao().getAllVaccinations()
            val goats = database.goatDao().getAllGoats().associateBy { it.id }

            val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
            val today = Date()
            val cal = Calendar.getInstance().apply {
                time = today
                set(Calendar.HOUR_OF_DAY, 0)
                set(Calendar.MINUTE, 0)
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
            }
            val todayStart = cal.time

            val alerts = mutableListOf<VaccinationAlertItem>()

            for (vac in vaccinations) {
                val nextDueStr = vac.next_due_date_c?.trim() ?: continue
                if (nextDueStr.isBlank()) continue

                val dueDate = try {
                    sdf.parse(nextDueStr)
                } catch (_: Exception) {
                    null
                } ?: continue

                val diffMillis = dueDate.time - todayStart.time
                val diffDays = TimeUnit.MILLISECONDS.toDays(diffMillis)

                // Alert if:
                // 1. Due today (diffDays == 0)
                // 2. Due within the next 7 days (diffDays in 1..7)
                // 3. Overdue within the last 14 days (diffDays in -14..-1)
                if (diffDays in -14..7) {
                    val goat = goats[vac.goat_id_c]
                    val goatLabel = if (goat != null) "${goat.tag_c} (${goat.name.ifBlank { "Goat" }})" else "Goat #${vac.goat_id_c.take(6)}"
                    alerts.add(
                        VaccinationAlertItem(
                            goatId = vac.goat_id_c,
                            goatLabel = goatLabel,
                            vaccineName = vac.vaccine_c,
                            dueDateStr = nextDueStr,
                            diffDays = diffDays
                        )
                    )
                }
            }

            Log.d(TAG, "Found ${alerts.size} upcoming or overdue vaccination events.")

            // Send notification if alerts found and permission granted
            if (alerts.isNotEmpty()) {
                sendVaccinationNotification(context, alerts)
            }

            // Save last checked timestamp & alert count in farm settings
            val nowTime = System.currentTimeMillis().toString()
            database.farmSettingsDao().saveSetting(FarmSettingEntity("last_vaccination_check_time", nowTime))
            database.farmSettingsDao().saveSetting(FarmSettingEntity("last_vaccination_alert_count", alerts.size.toString()))

            Result.success()
        } catch (e: Exception) {
            Log.e(TAG, "Error checking upcoming vaccination reminders: ${e.message}", e)
            Result.retry()
        }
    }

    private fun sendVaccinationNotification(context: Context, alerts: List<VaccinationAlertItem>) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val permission = ContextCompat.checkSelfPermission(context, android.Manifest.permission.POST_NOTIFICATIONS)
            if (permission != PackageManager.PERMISSION_GRANTED) {
                Log.w(TAG, "POST_NOTIFICATIONS permission not granted. Cannot display notification.")
                return
            }
        }

        val notificationManager = NotificationManagerCompat.from(context)

        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            putExtra("navigate_to", "vaccination")
        }
        val pendingIntent = PendingIntent.getActivity(
            context,
            1001,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val title = if (alerts.size == 1) {
            val alert = alerts.first()
            if (alert.diffDays == 0L) "Vaccination DUE TODAY: ${alert.goatLabel}"
            else if (alert.diffDays < 0) "Vaccination OVERDUE: ${alert.goatLabel}"
            else "Upcoming Vaccination: ${alert.goatLabel}"
        } else {
            "${alerts.size} Goats Due for Vaccination"
        }

        val contentText = if (alerts.size == 1) {
            val alert = alerts.first()
            val status = when {
                alert.diffDays == 0L -> "due today"
                alert.diffDays < 0 -> "overdue by ${-alert.diffDays} days"
                else -> "due in ${alert.diffDays} days"
            }
            "${alert.vaccineName} is $status (${alert.dueDateStr})"
        } else {
            val dueToday = alerts.count { it.diffDays == 0L }
            val overdue = alerts.count { it.diffDays < 0 }
            val upcoming = alerts.count { it.diffDays > 0 }
            "$dueToday due today, $upcoming upcoming this week, $overdue overdue."
        }

        val inboxStyle = NotificationCompat.InboxStyle()
            .setBigContentTitle(title)
            .setSummaryText("Herd Health Tracker")

        alerts.take(5).forEach { a ->
            val status = when {
                a.diffDays == 0L -> "DUE TODAY"
                a.diffDays < 0 -> "OVERDUE ${-a.diffDays}d"
                else -> "in ${a.diffDays}d"
            }
            inboxStyle.addLine("${a.goatLabel}: ${a.vaccineName} ($status)")
        }

        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle(title)
            .setContentText(contentText)
            .setStyle(inboxStyle)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .build()

        try {
            notificationManager.notify(7001, notification)
        } catch (e: SecurityException) {
            Log.e(TAG, "SecurityException sending vaccination notification: ${e.message}")
        }
    }

    private fun createNotificationChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                CHANNEL_NAME,
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Recurring reminders for scheduled and overdue goat vaccinations based on health history."
                enableVibration(true)
            }
            val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
            manager?.createNotificationChannel(channel)
        }
    }
}

data class VaccinationAlertItem(
    val goatId: String,
    val goatLabel: String,
    val vaccineName: String,
    val dueDateStr: String,
    val diffDays: Long
)
