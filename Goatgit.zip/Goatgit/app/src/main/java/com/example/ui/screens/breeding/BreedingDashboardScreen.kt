package com.example.ui.screens.breeding

import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.pedigree.*
import com.example.data.supabase.*
import com.example.i18n.t
import com.example.notification.KiddingReminderScheduler
import com.example.ui.components.DatePickerField
import com.example.ui.components.FarmTopBar
import com.example.ui.components.GoatSelector
import com.example.ui.components.OriginBadge
import com.example.ui.theme.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.TimeUnit

private val FarmPurple = Color(0xFF7B1FA2)
private val CardBorderColor = Color(0xFFE2E8F0)

data class BreedingPairItem(
    val id: String,
    val matingRecord: MatingRecord,
    val doe: Goat?,
    val buck: Goat?,
    val matingDate: String,
    val method: String,
    val isConfirmedPregnant: Boolean,
    val expectedKiddingDate: String?,
    val daysSinceMating: Int,
    val compatibilityCheck: MatingEligibility?
)

data class UpcomingKiddingItem(
    val pregnancyId: String,
    val doeId: String,
    val doeTag: String,
    val doeName: String,
    val breed: String,
    val sireTag: String?,
    val serviceDate: String,
    val expectedKiddingDate: String,
    val currentDay: Int,
    val totalGestationDays: Int,
    val daysRemaining: Int,
    val progressPct: Float,
    val isOverdue: Boolean,
    val notes: String?
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BreedingDashboardScreen(
    repository: GoatRepository,
    onNavigateBack: () -> Unit,
    onNavigateToRecordMating: () -> Unit,
    onNavigateToRecordPregnancy: () -> Unit,
    onNavigateToLogKidding: (doeId: String?) -> Unit,
    onNavigateToBreedingRecords: () -> Unit,
    onNavigateToLineageAudit: () -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val dateFormat = remember { SimpleDateFormat("yyyy-MM-dd", Locale.US) }
    val today = remember { dateFormat.format(Date()) }

    var goats by remember { mutableStateOf<List<Goat>>(emptyList()) }
    var matings by remember { mutableStateOf<List<MatingRecord>>(emptyList()) }
    var pregnancies by remember { mutableStateOf<List<PregnancyRecord>>(emptyList()) }
    var reproductiveEvents by remember { mutableStateOf<List<ReproductiveEvent>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }

    // Dialog state
    var showGestationCalcDialog by remember { mutableStateOf(false) }
    var showQuickPairDialog by remember { mutableStateOf(false) }

    // Selected Dashboard Tab: 0 = Overview, 1 = Active Breeding Pairs, 2 = Gestation & Kidding, 3 = Calculator
    var selectedTab by remember { mutableIntStateOf(0) }

    fun loadData() {
        isLoading = true
        coroutineScope.launch {
            val gRes = repository.getGoats()
            val mRes = repository.getMatingRecords()
            val pRes = repository.getPregnancies()
            val rRes = repository.insurance.getAbortions()
            isLoading = false
            if (gRes.isSuccess) goats = gRes.getOrThrow()
            if (mRes.isSuccess) matings = mRes.getOrThrow()
            if (pRes.isSuccess) pregnancies = pRes.getOrThrow()
            if (rRes.isSuccess) reproductiveEvents = rRes.getOrThrow()
        }
    }

    LaunchedEffect(Unit) {
        loadData()
    }

    // Process Active Breeding Pairs
    val activeBreedingPairs: List<BreedingPairItem> = remember(matings, goats, pregnancies, today) {
        val goatMap = goats.associateBy { it.id }
        val pregnancyMapByMating = pregnancies.associateBy { it.mating_record_id_c }
        val pregnancyMapByDoe = pregnancies.filter { it.status_c.equals("Confirmed", ignoreCase = true) || it.status_c.equals("Suspected", ignoreCase = true) }.associateBy { it.doe_id_c }
        val todayDate = try { dateFormat.parse(today) ?: Date() } catch (_: Exception) { Date() }

        matings.map { m ->
            val doe = goatMap[m.doe_id_c]
            val buck = goatMap[m.buck_id_c]
            val mDate = try { dateFormat.parse(m.mating_date_c ?: today) ?: todayDate } catch (_: Exception) { todayDate }
            val daysAgo = TimeUnit.MILLISECONDS.toDays(todayDate.time - mDate.time).toInt().coerceAtLeast(0)

            val linkedPregnancy = pregnancyMapByMating[m.id] ?: pregnancyMapByDoe[m.doe_id_c]
            val isConfirmed = linkedPregnancy != null && linkedPregnancy.status_c.equals("Confirmed", ignoreCase = true)
            val expectedDate = linkedPregnancy?.expected_kidding_date_c

            val compatibility = if (doe != null && buck != null) {
                PedigreeManager.evaluateMating(doe, buck, goats)
            } else null

            BreedingPairItem(
                id = m.id,
                matingRecord = m,
                doe = doe,
                buck = buck,
                matingDate = m.mating_date_c ?: today,
                method = m.method_c ?: "Natural",
                isConfirmedPregnant = isConfirmed,
                expectedKiddingDate = expectedDate,
                daysSinceMating = daysAgo,
                compatibilityCheck = compatibility
            )
        }.sortedByDescending { it.matingDate }
    }

    // Process Upcoming Kidding Dates
    val upcomingKiddings: List<UpcomingKiddingItem> = remember(pregnancies, goats, matings, today) {
        val goatMap = goats.associateBy { it.id }
        val matingMap = matings.associateBy { it.id }
        val todayDate = try { dateFormat.parse(today) ?: Date() } catch (_: Exception) { Date() }

        pregnancies
            .filter { it.status_c.equals("Confirmed", ignoreCase = true) || it.status_c.equals("Suspected", ignoreCase = true) }
            .map { preg ->
                val doe = goatMap[preg.doe_id_c]
                val mating = preg.mating_record_id_c?.let { matingMap[it] }
                val sire = mating?.buck_id_c?.let { goatMap[it] }

                val doeBreed = doe?.breed_c?.lowercase() ?: ""
                val totalGestationDays = when {
                    doeBreed.contains("nigerian") || doeBreed.contains("pygmy") -> 145
                    doeBreed.contains("nubian") -> 151
                    doeBreed.contains("boer") -> 149
                    else -> 150
                }

                val hasExpDate = !preg.expected_kidding_date_c.isNullOrBlank()
                val expDate: Date = if (hasExpDate) {
                    try { dateFormat.parse(preg.expected_kidding_date_c) ?: Date() } catch (_: Exception) { Date() }
                } else {
                    val conf = try { dateFormat.parse(preg.confirmation_date_c) ?: Date() } catch (_: Exception) { Date() }
                    Calendar.getInstance().apply {
                        time = conf
                        add(Calendar.DAY_OF_YEAR, totalGestationDays)
                    }.time
                }

                val serviceDate: Date = when {
                    mating != null && !mating.mating_date_c.isNullOrBlank() -> {
                        try { dateFormat.parse(mating.mating_date_c) ?: Date() } catch (_: Exception) { Date() }
                    }
                    hasExpDate -> {
                        Calendar.getInstance().apply {
                            time = expDate
                            add(Calendar.DAY_OF_YEAR, -totalGestationDays)
                        }.time
                    }
                    else -> {
                        try { dateFormat.parse(preg.confirmation_date_c) ?: Date() } catch (_: Exception) { Date() }
                    }
                }

                val diffDays = TimeUnit.MILLISECONDS.toDays(todayDate.time - serviceDate.time).toInt().coerceAtLeast(1)
                val currentDay = diffDays.coerceAtMost(165)
                val daysRemaining = TimeUnit.MILLISECONDS.toDays(expDate.time - todayDate.time).toInt()
                val isOverdue = daysRemaining < 0
                val progress = (currentDay.toFloat() / totalGestationDays.toFloat()).coerceIn(0f, 1f)

                UpcomingKiddingItem(
                    pregnancyId = preg.id,
                    doeId = preg.doe_id_c,
                    doeTag = doe?.tag_c ?: "Tag-${preg.doe_id_c.take(4)}",
                    doeName = doe?.name ?: "Unknown Doe",
                    breed = doe?.breed_c ?: "Caprine",
                    sireTag = sire?.tag_c ?: mating?.buck_id_c,
                    serviceDate = dateFormat.format(serviceDate),
                    expectedKiddingDate = if (hasExpDate) preg.expected_kidding_date_c!! else dateFormat.format(expDate),
                    currentDay = currentDay,
                    totalGestationDays = totalGestationDays,
                    daysRemaining = daysRemaining,
                    progressPct = progress,
                    isOverdue = isOverdue,
                    notes = preg.notes_c
                )
            }
            .sortedBy { it.daysRemaining }
    }

    // Key Statistics
    val activePregnancyCount = upcomingKiddings.size
    val overdueCount = upcomingKiddings.count { it.isOverdue }
    val dueWithin7Days = upcomingKiddings.count { it.daysRemaining in 0..7 }
    val totalBreedingPairs = activeBreedingPairs.size

    Scaffold(
        topBar = {
            FarmTopBar(
                title = "Breeding Dashboard",
                canNavigateBack = true,
                onNavigateBack = onNavigateBack,
                actions = {
                    IconButton(
                        onClick = onNavigateToBreedingRecords,
                        modifier = Modifier.testTag("btn_breeding_records_log")
                    ) {
                        Icon(
                            imageVector = Icons.Default.MenuBook,
                            contentDescription = "Breeding Log Records",
                            tint = Color.White
                        )
                    }
                    IconButton(
                        onClick = onNavigateToLineageAudit,
                        modifier = Modifier.testTag("btn_lineage_audit")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Verified,
                            contentDescription = "Lineage Audit",
                            tint = Color.White
                        )
                    }
                }
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { showGestationCalcDialog = true },
                containerColor = FarmPurple,
                contentColor = Color.White,
                icon = { Icon(Icons.Default.Calculate, contentDescription = null) },
                text = { Text("Gestation Calculator", fontWeight = FontWeight.Bold) },
                modifier = Modifier.testTag("fab_gestation_calculator")
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(FarmBackgroundLight)
                .padding(padding)
        ) {
            // Dashboard KPI Summary Header
            Surface(
                color = Color.White,
                shadowElevation = 2.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "HERD REPRODUCTION OVERVIEW",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = FarmGreenDark,
                                fontSize = 11.sp
                            )
                            Text(
                                text = "Active Pairs • Gestation Progress • Kidding Dates",
                                fontSize = 12.sp,
                                color = Color.Gray
                            )
                        }

                        FilledTonalButton(
                            onClick = onNavigateToRecordMating,
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                            modifier = Modifier.testTag("btn_new_breeding_pair")
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("New Pair", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // 4 Stat Cards
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        StatMetricCard(
                            label = "Active Pairs",
                            value = "$totalBreedingPairs",
                            icon = Icons.Default.Favorite,
                            color = FarmPurple,
                            modifier = Modifier.weight(1f)
                        )
                        StatMetricCard(
                            label = "In Gestation",
                            value = "$activePregnancyCount",
                            icon = Icons.Default.PregnantWoman,
                            color = Color(0xFF0284C7),
                            modifier = Modifier.weight(1f)
                        )
                        StatMetricCard(
                            label = "Due ≤ 7 Days",
                            value = "$dueWithin7Days",
                            icon = Icons.Default.NotificationsActive,
                            color = Color(0xFFD97706),
                            modifier = Modifier.weight(1f)
                        )
                        StatMetricCard(
                            label = "Overdue",
                            value = "$overdueCount",
                            icon = Icons.Default.Warning,
                            color = if (overdueCount > 0) Color(0xFFDC2626) else FarmGreenDark,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }

            // Tab Navigation Row
            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = Color.White,
                contentColor = FarmGreenDark,
                modifier = Modifier.fillMaxWidth()
            ) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = { Text("Overview", fontWeight = FontWeight.Bold, fontSize = 12.sp) }
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = { Text("Breeding Pairs ($totalBreedingPairs)", fontWeight = FontWeight.Bold, fontSize = 12.sp) }
                )
                Tab(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    text = { Text("Upcoming Kidding ($activePregnancyCount)", fontWeight = FontWeight.Bold, fontSize = 12.sp) }
                )
                Tab(
                    selected = selectedTab == 3,
                    onClick = { selectedTab = 3 },
                    text = { Text("Gestation Calc", fontWeight = FontWeight.Bold, fontSize = 12.sp) }
                )
            }

            if (isLoading) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = FarmGreenPrimary)
                }
            } else {
                when (selectedTab) {
                    0 -> DashboardOverviewTab(
                        breedingPairs = activeBreedingPairs,
                        upcomingKiddings = upcomingKiddings,
                        onOpenCalculator = { selectedTab = 3 },
                        onViewAllPairs = { selectedTab = 1 },
                        onViewAllKiddings = { selectedTab = 2 },
                        onLogKidding = onNavigateToLogKidding,
                        onRecordMating = onNavigateToRecordMating
                    )
                    1 -> ActiveBreedingPairsTab(
                        breedingPairs = activeBreedingPairs,
                        onRecordMating = onNavigateToRecordMating,
                        onConfirmPregnancy = onNavigateToRecordPregnancy
                    )
                    2 -> UpcomingKiddingDatesTab(
                        kiddings = upcomingKiddings,
                        onLogKidding = onNavigateToLogKidding,
                        onOpenCalculator = { selectedTab = 3 }
                    )
                    3 -> GestationCalculatorEmbeddedView(
                        goats = goats,
                        today = today,
                        dateFormat = dateFormat,
                        onSaveToTracker = { doeId, serviceDate, expectedDate, notes ->
                            coroutineScope.launch {
                                val record = PregnancyRecord(
                                    doe_id_c = doeId,
                                    confirmation_date_c = serviceDate,
                                    expected_kidding_date_c = expectedDate,
                                    status_c = "Confirmed",
                                    notes_c = notes
                                )
                                val res = repository.recordPregnancy(record)
                                if (res.isSuccess) {
                                    KiddingReminderScheduler.triggerImmediateCheck(context)
                                    Toast.makeText(context, "Pregnancy saved! Expected kidding scheduled for $expectedDate", Toast.LENGTH_SHORT).show()
                                    loadData()
                                    selectedTab = 2
                                }
                            }
                        }
                    )
                }
            }
        }
    }

    // Modal Gestation Calculator Dialog
    if (showGestationCalcDialog) {
        GestationCalculatorDialog(
            goats = goats,
            today = today,
            dateFormat = dateFormat,
            onDismiss = { showGestationCalcDialog = false },
            onSavePregnancy = { doeId, serviceDate, expectedDate, notes ->
                coroutineScope.launch {
                    val record = PregnancyRecord(
                        doe_id_c = doeId,
                        confirmation_date_c = serviceDate,
                        expected_kidding_date_c = expectedDate,
                        status_c = "Confirmed",
                        notes_c = notes
                    )
                    val res = repository.recordPregnancy(record)
                    showGestationCalcDialog = false
                    if (res.isSuccess) {
                        KiddingReminderScheduler.triggerImmediateCheck(context)
                        Toast.makeText(context, "Pregnancy saved! Kidding alert scheduled for $expectedDate", Toast.LENGTH_SHORT).show()
                        loadData()
                    }
                }
            }
        )
    }
}

@Composable
private fun StatMetricCard(
    label: String,
    value: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    color: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        color = color.copy(alpha = 0.08f),
        shape = RoundedCornerShape(10.dp),
        border = BorderStroke(1.dp, color.copy(alpha = 0.25f)),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = value,
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                color = color
            )
            Text(
                text = label,
                fontSize = 9.sp,
                fontWeight = FontWeight.Medium,
                color = Color.DarkGray,
                maxLines = 1
            )
        }
    }
}

/**
 * Tab 0: Comprehensive Dashboard Overview
 */
@Composable
private fun DashboardOverviewTab(
    breedingPairs: List<BreedingPairItem>,
    upcomingKiddings: List<UpcomingKiddingItem>,
    onOpenCalculator: () -> Unit,
    onViewAllPairs: () -> Unit,
    onViewAllKiddings: () -> Unit,
    onLogKidding: (doeId: String?) -> Unit,
    onRecordMating: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Quick Action Calculator Banner
        Card(
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Surface(
                        shape = CircleShape,
                        color = Color(0xFF7B1FA2).copy(alpha = 0.3f),
                        modifier = Modifier.size(40.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(Icons.Default.Calculate, contentDescription = null, tint = Color(0xFFCE93D8))
                        }
                    }
                    Column {
                        Text("Caprine Gestation Calculator", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 14.sp)
                        Text("Calculate expected delivery date & schedule ultrasound and CD&T milestones", fontSize = 11.sp, color = Color(0xFF94A3B8))
                    }
                }

                Button(
                    onClick = onOpenCalculator,
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = FarmGreenPrimary),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                    modifier = Modifier.testTag("btn_open_calculator_banner")
                ) {
                    Text("Calculate", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        // Section: Upcoming Kidding Dates (High Priority)
        Card(
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            border = BorderStroke(1.dp, CardBorderColor)
        ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Icon(Icons.Default.DateRange, contentDescription = null, tint = FarmPurple, modifier = Modifier.size(18.dp))
                        Text("Upcoming Kidding Dates", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color(0xFF1E293B))
                    }
                    TextButton(onClick = onViewAllKiddings, contentPadding = PaddingValues(0.dp)) {
                        Text("View All (${upcomingKiddings.size})", fontSize = 12.sp, color = FarmPurple, fontWeight = FontWeight.Bold)
                    }
                }

                if (upcomingKiddings.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 16.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("No confirmed pregnancies pending delivery.", fontSize = 12.sp, color = Color.Gray)
                    }
                } else {
                    upcomingKiddings.take(3).forEach { item ->
                        UpcomingKiddingMiniCard(item = item, onLogKidding = { onLogKidding(item.doeId) })
                    }
                }
            }
        }

        // Section: Active Breeding Pairs
        Card(
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            border = BorderStroke(1.dp, CardBorderColor)
        ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Icon(Icons.Default.Favorite, contentDescription = null, tint = Color(0xFFE11D48), modifier = Modifier.size(18.dp))
                        Text("Active Breeding Pairs", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color(0xFF1E293B))
                    }
                    TextButton(onClick = onViewAllPairs, contentPadding = PaddingValues(0.dp)) {
                        Text("View All (${breedingPairs.size})", fontSize = 12.sp, color = FarmGreenDark, fontWeight = FontWeight.Bold)
                    }
                }

                if (breedingPairs.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 16.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("No breeding pairs logged yet.", fontSize = 12.sp, color = Color.Gray)
                    }
                } else {
                    breedingPairs.take(3).forEach { pair ->
                        BreedingPairCard(pair = pair, onConfirmPregnancy = {})
                    }
                }
            }
        }
    }
}

/**
 * Tab 1: Active Breeding Pairs List
 */
@Composable
private fun ActiveBreedingPairsTab(
    breedingPairs: List<BreedingPairItem>,
    onRecordMating: () -> Unit,
    onConfirmPregnancy: () -> Unit
) {
    if (breedingPairs.isEmpty()) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Icon(Icons.Default.FavoriteBorder, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(48.dp))
                Text("No active breeding pairs found.", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = Color.DarkGray)
                Text("Log a mating event to pair a Buck and Doe.", fontSize = 12.sp, color = Color.Gray)
                Button(
                    onClick = onRecordMating,
                    colors = ButtonDefaults.buttonColors(containerColor = FarmGreenPrimary)
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Pair Doe & Buck")
                }
            }
        }
    } else {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "Active Matings & Pair Evaluations (${breedingPairs.size})",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = Color.DarkGray
                    )
                    FilledTonalButton(
                        onClick = onRecordMating,
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Add Pair", fontSize = 11.sp)
                    }
                }
            }

            items(breedingPairs) { pair ->
                BreedingPairCard(pair = pair, onConfirmPregnancy = onConfirmPregnancy)
            }
        }
    }
}

@Composable
private fun BreedingPairCard(
    pair: BreedingPairItem,
    onConfirmPregnancy: () -> Unit
) {
    val doeTag = pair.doe?.tag_c ?: "Tag-${pair.matingRecord.doe_id_c.take(4)}"
    val doeName = pair.doe?.name ?: "Doe"
    val buckTag = pair.buck?.tag_c ?: "Tag-${pair.matingRecord.buck_id_c.take(4)}"
    val buckName = pair.buck?.name ?: "Buck"

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("breeding_pair_card_${pair.id}"),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(1.dp, CardBorderColor),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Header: Mating Date, Status Badge
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Icon(Icons.Default.CalendarToday, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(14.dp))
                    Text("Mated: ${pair.matingDate} (${pair.daysSinceMating}d ago)", fontSize = 11.sp, color = Color.Gray, fontWeight = FontWeight.SemiBold)
                }

                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = if (pair.isConfirmedPregnant) Color(0xFFDCFCE7) else Color(0xFFFEF3C7)
                ) {
                    Text(
                        text = if (pair.isConfirmedPregnant) "✓ Confirmed Pregnant" else "Pending Confirmation",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (pair.isConfirmedPregnant) Color(0xFF166534) else Color(0xFFB45309),
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }

            // Buck x Doe pairing visualization
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFFF8FAFC), RoundedCornerShape(10.dp))
                    .padding(10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Buck
                Column(modifier = Modifier.weight(1f)) {
                    Text("BUCK (கிடா)", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color(0xFF0284C7))
                    Text("$buckName (#$buckTag)", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color(0xFF1E293B))
                    Text("Breed: ${pair.buck?.breed_c ?: "Unknown"}", fontSize = 11.sp, color = Color(0xFF64748B))
                }

                // Heart Icon
                Surface(
                    shape = CircleShape,
                    color = Color(0xFFFFE4E6),
                    modifier = Modifier.size(32.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.Favorite, contentDescription = null, tint = Color(0xFFE11D48), modifier = Modifier.size(16.dp))
                    }
                }

                // Doe
                Column(modifier = Modifier.weight(1f), horizontalAlignment = Alignment.End) {
                    Text("DOE (பெட்டை)", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color(0xFFC026D3))
                    Text("$doeName (#$doeTag)", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color(0xFF1E293B))
                    Text("Breed: ${pair.doe?.breed_c ?: "Unknown"}", fontSize = 11.sp, color = Color(0xFF64748B))
                }
            }

            // Compatibility Check Result (Lineage / Breed safety)
            pair.compatibilityCheck?.let { el ->
                when (val b = el.breedCheck) {
                    is BreedCheckResult.AllowedSameBreed -> {
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = Color(0xFFF0FDF4),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.CheckCircle, contentDescription = null, tint = FarmGreenDark, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Purebred Pair: ${b.breed} • Method: ${pair.method}", fontSize = 11.sp, color = FarmGreenDark, fontWeight = FontWeight.SemiBold)
                            }
                        }
                    }
                    is BreedCheckResult.BlockedCrossBreeding -> {
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = Color(0xFFFEF2F2),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Warning, contentDescription = null, tint = Color(0xFFDC2626), modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Cross-breed: ${b.doeBreed} × ${b.buckBreed}", fontSize = 11.sp, color = Color(0xFFDC2626), fontWeight = FontWeight.SemiBold)
                            }
                        }
                    }
                    else -> {}
                }
            }

            // Expected Delivery Date if confirmed
            if (!pair.expectedKiddingDate.isNullOrBlank()) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Expected Kidding Date:", fontSize = 11.sp, color = Color.Gray)
                    Text(pair.expectedKiddingDate, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = FarmPurple)
                }
            }
        }
    }
}

/**
 * Tab 2: Upcoming Kidding Dates
 */
@Composable
private fun UpcomingKiddingDatesTab(
    kiddings: List<UpcomingKiddingItem>,
    onLogKidding: (doeId: String?) -> Unit,
    onOpenCalculator: () -> Unit
) {
    if (kiddings.isEmpty()) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Icon(Icons.Default.ChildCare, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(48.dp))
                Text("No upcoming kidding dates.", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = Color.DarkGray)
                Text("Use the Gestation Calculator to forecast delivery for newly bred does.", fontSize = 12.sp, color = Color.Gray)
                Button(
                    onClick = onOpenCalculator,
                    colors = ButtonDefaults.buttonColors(containerColor = FarmPurple)
                ) {
                    Icon(Icons.Default.Calculate, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Open Gestation Calculator")
                }
            }
        }
    } else {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "Gestation Timeline & Kidding Schedule (${kiddings.size})",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = Color.DarkGray
                    )

                    val overdueCount = kiddings.count { it.isOverdue }
                    if (overdueCount > 0) {
                        Surface(shape = RoundedCornerShape(4.dp), color = Color(0xFFFEE2E2)) {
                            Text(
                                "🚨 $overdueCount Overdue",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFFDC2626),
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                }
            }

            items(kiddings) { item ->
                UpcomingKiddingDetailCard(item = item, onLogKidding = { onLogKidding(item.doeId) })
            }
        }
    }
}

@Composable
private fun UpcomingKiddingDetailCard(
    item: UpcomingKiddingItem,
    onLogKidding: () -> Unit
) {
    val (statusColor, badgeBg, badgeText) = when {
        item.isOverdue -> Triple(Color(0xFFDC2626), Color(0xFFFEE2E2), "🚨 ${-item.daysRemaining}d Overdue")
        item.daysRemaining in 0..3 -> Triple(Color(0xFFEA580C), Color(0xFFFFEDD5), "⚠️ Due in ${item.daysRemaining}d")
        item.daysRemaining in 4..7 -> Triple(Color(0xFFD97706), Color(0xFFFEF3C7), "🔔 Due in ${item.daysRemaining}d")
        else -> Triple(Color(0xFF16A34A), Color(0xFFDCFCE7), "${item.daysRemaining}d Remaining")
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("kidding_card_${item.doeTag}"),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(1.dp, if (item.isOverdue || item.daysRemaining in 0..3) statusColor else CardBorderColor),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Doe #${item.doeTag} • ${item.doeName}",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = Color(0xFF1E293B)
                    )
                    Text(
                        text = "Breed: ${item.breed} • Mated: ${item.serviceDate}",
                        fontSize = 11.sp,
                        color = Color(0xFF64748B)
                    )
                }

                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = badgeBg
                ) {
                    Text(
                        text = badgeText,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        color = statusColor,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            // Progress bar
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "Gestation: Day ${item.currentDay} of ${item.totalGestationDays} (${(item.progressPct * 100).toInt()}%)",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF334155)
                    )
                    Text(
                        text = "Expected: ${item.expectedKiddingDate}",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = FarmPurple
                    )
                }

                LinearProgressIndicator(
                    progress = { item.progressPct },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(8.dp)
                        .clip(RoundedCornerShape(4.dp)),
                    color = if (item.isOverdue) Color(0xFFDC2626) else FarmPurple,
                    trackColor = Color(0xFFE2E8F0)
                )
            }

            // Action row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                item.sireTag?.let { s ->
                    Text("Sire: $s", fontSize = 11.sp, color = Color.Gray)
                } ?: Spacer(modifier = Modifier.width(1.dp))

                Button(
                    onClick = onLogKidding,
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = FarmPurple),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                    modifier = Modifier.testTag("btn_log_kidding_${item.doeTag}")
                ) {
                    Icon(Icons.Default.ChildCare, contentDescription = null, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Log Delivery", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun UpcomingKiddingMiniCard(
    item: UpcomingKiddingItem,
    onLogKidding: () -> Unit
) {
    val (statusColor, badgeBg, badgeText) = when {
        item.isOverdue -> Triple(Color(0xFFDC2626), Color(0xFFFEE2E2), "🚨 ${-item.daysRemaining}d Overdue")
        item.daysRemaining in 0..3 -> Triple(Color(0xFFEA580C), Color(0xFFFFEDD5), "Due in ${item.daysRemaining}d")
        else -> Triple(FarmPurple, Color(0xFFF3E8FF), "Due in ${item.daysRemaining}d")
    }

    Surface(
        color = Color(0xFFF8FAFC),
        shape = RoundedCornerShape(8.dp),
        border = BorderStroke(0.5.dp, Color(0xFFCBD5E1)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text("${item.doeName} (#${item.doeTag})", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                Text("Expected: ${item.expectedKiddingDate} • Day ${item.currentDay}/${item.totalGestationDays}", fontSize = 10.sp, color = Color.Gray)
            }

            Surface(shape = RoundedCornerShape(4.dp), color = badgeBg) {
                Text(
                    badgeText,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = statusColor,
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                )
            }

            Spacer(modifier = Modifier.width(8.dp))

            IconButton(
                onClick = onLogKidding,
                modifier = Modifier.size(28.dp)
            ) {
                Icon(Icons.Default.ChildCare, contentDescription = "Log Kidding", tint = FarmPurple, modifier = Modifier.size(18.dp))
            }
        }
    }
}

/**
 * Tab 3: Embedded Gestation Calculator
 */
@Composable
private fun GestationCalculatorEmbeddedView(
    goats: List<Goat>,
    today: String,
    dateFormat: SimpleDateFormat,
    onSaveToTracker: (doeId: String, serviceDate: String, expectedDate: String, notes: String) -> Unit
) {
    val does = remember(goats) { goats.filter { it.sex_c.equals("Doe", ignoreCase = true) || it.sex_c.equals("Female", ignoreCase = true) } }
    var selectedDoeId by remember { mutableStateOf(does.firstOrNull()?.id ?: "") }
    var serviceDate by remember { mutableStateOf(today) }
    var selectedBreedType by remember { mutableStateOf("Standard (150 Days)") }

    val totalDays = when (selectedBreedType) {
        "Miniature / Nigerian Dwarf (145 Days)" -> 145
        "Boer Meat Goat (149 Days)" -> 149
        "Nubian Dairy (151 Days)" -> 151
        else -> 150
    }

    val expectedKiddingDate = remember(serviceDate, totalDays) {
        try {
            val parsed = dateFormat.parse(serviceDate) ?: Date()
            val cal = Calendar.getInstance().apply {
                time = parsed
                add(Calendar.DAY_OF_YEAR, totalDays)
            }
            dateFormat.format(cal.time)
        } catch (_: Exception) {
            today
        }
    }

    val displayFormat = SimpleDateFormat("dd MMM yyyy", Locale.US)
    fun addDaysFromService(days: Int): String {
        return try {
            val parsed = dateFormat.parse(serviceDate) ?: Date()
            val cal = Calendar.getInstance().apply {
                time = parsed
                add(Calendar.DAY_OF_YEAR, days)
            }
            displayFormat.format(cal.time)
        } catch (_: Exception) { "" }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Card(
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            border = BorderStroke(1.dp, CardBorderColor)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(Icons.Default.Calculate, contentDescription = null, tint = FarmPurple)
                    Text("Caprine Gestation Calculator", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Color(0xFF1E293B))
                }

                Text(
                    text = "Forecast delivery date and clinical milestones for any bred doe in your herd.",
                    fontSize = 12.sp,
                    color = Color.Gray
                )

                if (does.isNotEmpty()) {
                    GoatSelector(
                        goats = does,
                        selectedGoatId = selectedDoeId,
                        onGoatSelected = { selectedDoeId = it.id },
                        label = "Select Bred Doe"
                    )
                }

                DatePickerField(
                    dateValue = serviceDate,
                    onDateSelected = { serviceDate = it },
                    label = "Service / Mating Date"
                )

                Text("Breed Gestation Standard:", fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                val breedOptions = listOf(
                    "Standard (150 Days)",
                    "Boer Meat Goat (149 Days)",
                    "Miniature / Nigerian Dwarf (145 Days)",
                    "Nubian Dairy (151 Days)"
                )
                breedOptions.forEach { opt ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { selectedBreedType = opt }
                            .padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(
                            selected = selectedBreedType == opt,
                            onClick = { selectedBreedType = opt }
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(opt, fontSize = 12.sp)
                    }
                }

                // Calculated Results Card
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFF0FDF4)),
                    border = BorderStroke(1.dp, FarmGreenPrimary)
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text("PROJECTED CLINICAL TIMELINE", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = FarmGreenDark)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Expected Kidding Date:", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                            Text(expectedKiddingDate, fontWeight = FontWeight.Bold, fontSize = 15.sp, color = FarmPurple)
                        }

                        Divider(color = FarmGreenPrimary.copy(alpha = 0.2f), thickness = 1.dp)

                        Text("• Day 30 Ultrasound Scan: ${addDaysFromService(30)}", fontSize = 11.sp, color = Color(0xFF334155))
                        Text("• Day 100 Late Feed Ramp: ${addDaysFromService(100)}", fontSize = 11.sp, color = Color(0xFF334155))
                        Text("• Day 120 CD&T Vaccination Booster: ${addDaysFromService(120)}", fontSize = 11.sp, color = Color(0xFF334155))
                        Text("• Day 143 Transfer to Maternity Stall: ${addDaysFromService(143)}", fontSize = 11.sp, color = Color(0xFF334155))
                    }
                }

                Button(
                    onClick = {
                        onSaveToTracker(
                            selectedDoeId,
                            serviceDate,
                            expectedKiddingDate,
                            "Calculated via Breeding Dashboard ($selectedBreedType)"
                        )
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("btn_save_calculated_gestation"),
                    colors = ButtonDefaults.buttonColors(containerColor = FarmGreenPrimary),
                    enabled = selectedDoeId.isNotBlank()
                ) {
                    Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Save to Gestation Tracker", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
