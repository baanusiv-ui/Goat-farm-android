package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.pedigree.*
import com.example.data.supabase.*
import com.example.i18n.t
import com.example.ui.components.DatePickerField
import com.example.ui.components.FarmTopBar
import com.example.ui.components.GoatSelector
import com.example.ui.components.OriginBadge
import com.example.ui.screens.breeding.GestationTrackingAndKiddingAlertsView
import com.example.ui.screens.breeding.LineageAuditView
import com.example.ui.theme.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

private val FarmPurple = Color(0xFF7B1FA2)

@Composable
private fun BreedingKpiChip(
    title: String,
    value: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        color = color.copy(alpha = 0.08f),
        shape = RoundedCornerShape(8.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, color.copy(alpha = 0.2f)),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 4.dp, vertical = 6.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = value,
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
                color = color
            )
            Text(
                text = title,
                fontSize = 9.sp,
                fontWeight = FontWeight.SemiBold,
                color = Color.DarkGray,
                maxLines = 1
            )
        }
    }
}

data class KidEntryState(
    var tag: String = "",
    var gender: String = "Female",
    var birthWeight: String = "2.5",
    var birthOrder: Int = 1,
    var condition: String = "Healthy",
    var notes: String = ""
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BreedingPregnancyKiddingScreen(
    repository: GoatRepository,
    onNavigateBack: () -> Unit,
    onNavigateToBreedingRecords: () -> Unit = {},
    onNavigateToBreedingDashboard: () -> Unit = {}
) {
    var selectedTab by remember { mutableIntStateOf(0) } // 0 = Mating, 1 = Pregnancy, 2 = Kidding, 3 = Lineage & Audit
    var preselectedKiddingDoeId by remember { mutableStateOf<String?>(null) }
    var pregnancySubTab by remember { mutableIntStateOf(0) } // 0 = Gestation & Alerts, 1 = Record Pregnancy
    var goats by remember { mutableStateOf<List<Goat>>(emptyList()) }
    var matings by remember { mutableStateOf<List<MatingRecord>>(emptyList()) }
    var pregnancies by remember { mutableStateOf<List<PregnancyRecord>>(emptyList()) }
    var reproductiveEvents by remember { mutableStateOf<List<ReproductiveEvent>>(emptyList()) }
    var isLoadingGoats by remember { mutableStateOf(true) }

    val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.US)
    val today = remember { dateFormat.format(Date()) }
    val coroutineScope = rememberCoroutineScope()

    fun loadData() {
        isLoadingGoats = true
        coroutineScope.launch {
            val res = repository.getGoats()
            val mRes = repository.getMatingRecords()
            val pRes = repository.getPregnancies()
            val rRes = repository.insurance.getAbortions()
            isLoadingGoats = false
            if (res.isSuccess) goats = res.getOrThrow()
            if (mRes.isSuccess) matings = mRes.getOrThrow()
            if (pRes.isSuccess) pregnancies = pRes.getOrThrow()
            if (rRes.isSuccess) reproductiveEvents = rRes.getOrThrow()
        }
    }

    LaunchedEffect(Unit) {
        loadData()
    }

    // Breeding Dashboard Metrics (Requirement 13)
    val confirmedPregnancies = remember(pregnancies) {
        pregnancies.count { it.status_c.equals("Confirmed", ignoreCase = true) || it.status_c.equals("Delivered", ignoreCase = true) }
    }
    val successfulKidding = remember(pregnancies, reproductiveEvents) {
        reproductiveEvents.count { it.event_type.equals("NORMAL_DELIVERY", ignoreCase = true) || it.event_type.equals("KIDDING", ignoreCase = true) } +
            pregnancies.count { it.status_c.equals("Delivered", ignoreCase = true) }
    }
    val abortionsCount = remember(reproductiveEvents, pregnancies) {
        reproductiveEvents.count { it.event_type.equals("ABORTION", ignoreCase = true) } +
            pregnancies.count { it.status_c.equals("Aborted", ignoreCase = true) }
    }
    val stillbirthsCount = remember(reproductiveEvents) {
        reproductiveEvents.count { it.event_type.equals("STILLBIRTH", ignoreCase = true) }
    }
    val openDoesCount = remember(goats, pregnancies) {
        val pregnantDoeIds = pregnancies.filter { it.status_c.equals("Confirmed", ignoreCase = true) }.map { it.doe_id_c }.toSet()
        goats.count { (it.sex_c.equals("Doe", ignoreCase = true) || it.sex_c.equals("Female", ignoreCase = true)) && !pregnantDoeIds.contains(it.id) }
    }
    val dueSoonCount = remember(pregnancies) {
        pregnancies.count { p ->
            p.status_c.equals("Confirmed", ignoreCase = true) && !p.expected_kidding_date_c.isNullOrBlank()
        }
    }
    // Abortion Rate: Abortions / Confirmed Pregnancies * 100; if denominator is 0: show "N/A"
    val abortionRateStr = remember(abortionsCount, confirmedPregnancies) {
        if (confirmedPregnancies == 0) "N/A"
        else {
            val rate = (abortionsCount.toDouble() / confirmedPregnancies.toDouble()) * 100.0
            String.format(Locale.US, "%.1f%%", rate)
        }
    }

    Scaffold(
        topBar = {
            FarmTopBar(
                title = t("breeding.title"),
                canNavigateBack = true,
                onNavigateBack = onNavigateBack,
                actions = {
                    IconButton(
                        onClick = onNavigateToBreedingDashboard,
                        modifier = Modifier.testTag("btn_topbar_breeding_dashboard")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Dashboard,
                            contentDescription = "Breeding Dashboard",
                            tint = Color.White
                        )
                    }
                    IconButton(
                        onClick = onNavigateToBreedingRecords,
                        modifier = Modifier.testTag("btn_topbar_breeding_records")
                    ) {
                        Icon(
                            imageVector = Icons.Default.MenuBook,
                            contentDescription = "Breeding Records Log",
                            tint = Color.White
                        )
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(FarmBackgroundLight)
                .padding(padding)
        ) {
            ScrollableTabRow(
                selectedTabIndex = selectedTab,
                containerColor = Color.White,
                edgePadding = 0.dp
            ) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = { Text("1. ${t("breeding.tab_mating")}", fontWeight = FontWeight.Bold) }
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = { Text("2. Gestation & Alerts", fontWeight = FontWeight.Bold) }
                )
                Tab(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    text = { Text("3. ${t("breeding.tab_kidding")}", fontWeight = FontWeight.Bold) }
                )
                Tab(
                    selected = selectedTab == 3,
                    onClick = { selectedTab = 3 },
                    text = { Text(t("pedigree.tab_report"), fontWeight = FontWeight.Bold) }
                )
            }

            // Breeding Dashboard KPI Banner (Requirement 13 & 16)
            Surface(
                color = Color.White,
                shadowElevation = 1.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "BREEDING DASHBOARD",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            fontSize = 10.sp,
                            color = FarmGreenDark
                        )
                        Surface(
                            color = if (abortionRateStr != "N/A" && abortionsCount > 0) Color(0xFFFFEBEE) else Color(0xFFF0FDF4),
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Text(
                                text = "Abortion Rate: $abortionRateStr",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (abortionRateStr != "N/A" && abortionsCount > 0) Color(0xFFC62828) else FarmGreenDark,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        BreedingKpiChip("Preggo", "$confirmedPregnancies", FarmPurple, Modifier.weight(1f).clickable { selectedTab = 1; pregnancySubTab = 0 })
                        BreedingKpiChip("Kidding", "$successfulKidding", FarmGreenDark, Modifier.weight(1f).clickable { selectedTab = 2 })
                        BreedingKpiChip("Abortions", "$abortionsCount", Color(0xFFC62828), Modifier.weight(1f))
                        BreedingKpiChip("Stillborn", "$stillbirthsCount", Color(0xFFE65100), Modifier.weight(1f))
                        BreedingKpiChip("Open Does", "$openDoesCount", Color(0xFF0284C7), Modifier.weight(1f))
                        BreedingKpiChip("Due Soon", "$dueSoonCount", Color(0xFFD97706), Modifier.weight(1f).clickable { selectedTab = 1; pregnancySubTab = 0 })
                    }
                }
            }

            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp)
            ) {
                if (isLoadingGoats) {
                    CircularProgressIndicator(
                        modifier = Modifier.align(Alignment.Center),
                        color = FarmGreenPrimary
                    )
                } else {
                    when (selectedTab) {
                        0 -> MatingTab(
                            repository = repository,
                            goats = goats,
                            today = today,
                            onMatingSaved = { loadData() },
                            onGoatsUpdated = { loadData() }
                        )
                        1 -> {
                            Column(
                                modifier = Modifier.fillMaxWidth(),
                                verticalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                // Sub-navigation: Gestation & Alerts vs Record Pregnancy Form
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Surface(
                                        shape = RoundedCornerShape(10.dp),
                                        color = if (pregnancySubTab == 0) FarmPurple else Color.White,
                                        border = BorderStroke(1.dp, FarmPurple),
                                        modifier = Modifier
                                            .weight(1f)
                                            .clickable { pregnancySubTab = 0 }
                                            .testTag("tab_gestation_alerts")
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(vertical = 10.dp, horizontal = 10.dp),
                                            horizontalArrangement = Arrangement.Center,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Icon(
                                                Icons.Default.DateRange,
                                                contentDescription = null,
                                                tint = if (pregnancySubTab == 0) Color.White else FarmPurple,
                                                modifier = Modifier.size(16.dp)
                                            )
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text(
                                                "Gestation & Alerts (${pregnancies.count { it.status_c.equals("Confirmed", ignoreCase = true) }})",
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 12.sp,
                                                color = if (pregnancySubTab == 0) Color.White else FarmPurple
                                            )
                                        }
                                    }

                                    Surface(
                                        shape = RoundedCornerShape(10.dp),
                                        color = if (pregnancySubTab == 1) FarmGreenPrimary else Color.White,
                                        border = BorderStroke(1.dp, FarmGreenPrimary),
                                        modifier = Modifier
                                            .weight(1f)
                                            .clickable { pregnancySubTab = 1 }
                                            .testTag("tab_record_pregnancy")
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(vertical = 10.dp, horizontal = 10.dp),
                                            horizontalArrangement = Arrangement.Center,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Icon(
                                                Icons.Default.Add,
                                                contentDescription = null,
                                                tint = if (pregnancySubTab == 1) Color.White else FarmGreenPrimary,
                                                modifier = Modifier.size(16.dp)
                                            )
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text(
                                                "Record Pregnancy",
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 12.sp,
                                                color = if (pregnancySubTab == 1) Color.White else FarmGreenPrimary
                                            )
                                        }
                                    }
                                }

                                if (pregnancySubTab == 0) {
                                    GestationTrackingAndKiddingAlertsView(
                                        repository = repository,
                                        goats = goats,
                                        pregnancies = pregnancies,
                                        matings = matings,
                                        today = today,
                                        dateFormat = dateFormat,
                                        onNavigateToKiddingWithDoe = { doeId ->
                                            preselectedKiddingDoeId = doeId
                                            selectedTab = 2
                                        },
                                        onPregnancyUpdated = { loadData() }
                                    )
                                } else {
                                    PregnancyTab(
                                        repository = repository,
                                        goats = goats,
                                        today = today,
                                        dateFormat = dateFormat,
                                        onPregnancySaved = {
                                            loadData()
                                            pregnancySubTab = 0
                                        }
                                    )
                                }
                            }
                        }
                        2 -> KiddingTab(
                            repository = repository,
                            goats = goats,
                            today = today,
                            preselectedDoeId = preselectedKiddingDoeId,
                            onKiddingSaved = {
                                preselectedKiddingDoeId = null
                                loadData()
                            }
                        )
                        3 -> LineageAuditView(
                            repository = repository,
                            goats = goats,
                            matings = matings,
                            onGoatsUpdated = { loadData() }
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MatingTab(
    repository: GoatRepository,
    goats: List<Goat>,
    today: String,
    onMatingSaved: () -> Unit = {},
    onGoatsUpdated: () -> Unit = {}
) {
    val does = remember(goats) { goats.filter { it.sex_c.equals("Doe", ignoreCase = true) } }
    val bucks = remember(goats) { goats.filter { it.sex_c.equals("Buck", ignoreCase = true) } }

    var doeId by remember { mutableStateOf(does.firstOrNull()?.id ?: "") }
    var buckId by remember { mutableStateOf(bucks.firstOrNull()?.id ?: "") }
    var matingDate by remember { mutableStateOf(today) }
    var heatObserved by remember { mutableStateOf(true) }
    var method by remember { mutableStateOf("Natural") }
    var notes by remember { mutableStateOf("") }

    var isSaving by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    var isSuccess by remember { mutableStateOf(false) }
    val coroutineScope = rememberCoroutineScope()

    val selectedDoe = remember(doeId, goats) { goats.firstOrNull { it.id == doeId } }
    val selectedBuck = remember(buckId, goats) { goats.firstOrNull { it.id == buckId } }

    val eligibility = remember(selectedDoe, selectedBuck, goats) {
        if (selectedDoe != null && selectedBuck != null) {
            PedigreeManager.evaluateMating(selectedDoe, selectedBuck, goats)
        } else null
    }

    var goatToUpdateBreed by remember { mutableStateOf<Goat?>(null) }
    var newBreedChoice by remember { mutableStateOf("Boer") }
    var isUpdatingBreed by remember { mutableStateOf(false) }
    val commonBreeds = listOf("Salem Karupu", "Kodi Adu", "Boer", "Jamnapari", "Barbari", "Sirohi", "Saanen", "Nubian", "Alpine", "Beetal", "Kalahari Red")

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text(t("breeding.record_mating"), fontWeight = FontWeight.Bold, color = FarmGreenDark)

            // Select Doe & Buck
            GoatSelector(
                goats = does.ifEmpty { goats },
                selectedGoatId = doeId,
                onGoatSelected = { doeId = it.id },
                label = t("breeding.doe_label")
            )

            GoatSelector(
                goats = bucks.ifEmpty { goats },
                selectedGoatId = buckId,
                onGoatSelected = { buckId = it.id },
                label = t("breeding.buck_label")
            )

            // Pair Comparison Card (Requirement 8)
            if (selectedDoe != null && selectedBuck != null) {
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFFAFAFA)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        // DOE Summary
                        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("DOE (பெட்டை)", fontWeight = FontWeight.Bold, color = Color(0xFFC2185B), fontSize = 12.sp)
                                OriginBadge(origin = selectedDoe.effectiveOrigin)
                            }
                            Text("${selectedDoe.name} (${selectedDoe.tag_c})", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text("${t("pedigree.breed")}: ${selectedDoe.breed_c.ifBlank { "Unknown" }}", fontSize = 12.sp)
                            Text("${t("pedigree.sire")}: ${selectedDoe.sire_c ?: "Unknown"} • ${t("pedigree.dam")}: ${selectedDoe.dam_c ?: "Unknown"}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Text("×", fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, color = Color.Gray)
                        }

                        // BUCK Summary
                        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("BUCK (கிடா)", fontWeight = FontWeight.Bold, color = Color(0xFF1976D2), fontSize = 12.sp)
                                OriginBadge(origin = selectedBuck.effectiveOrigin)
                            }
                            Text("${selectedBuck.name} (${selectedBuck.tag_c})", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text("${t("pedigree.breed")}: ${selectedBuck.breed_c.ifBlank { "Unknown" }}", fontSize = 12.sp)
                            Text("${t("pedigree.sire")}: ${selectedBuck.sire_c ?: "Unknown"} • ${t("pedigree.dam")}: ${selectedBuck.dam_c ?: "Unknown"}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }

                // Live Checks Display
                eligibility?.let { el ->
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        // 1. BREED CHECK
                        Text(t("pedigree.check_breed"), fontWeight = FontWeight.Bold, fontSize = 12.sp, color = FarmGreenDark)
                        when (val b = el.breedCheck) {
                            is BreedCheckResult.AllowedSameBreed -> {
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = FarmGreenContainer.copy(alpha = 0.7f),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier.padding(10.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = FarmSuccess, modifier = Modifier.size(18.dp))
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(
                                            text = "${t("pedigree.check_breed_ok")} (${b.breed})",
                                            fontWeight = FontWeight.Bold,
                                            color = FarmGreenDark,
                                            fontSize = 13.sp
                                        )
                                    }
                                }
                            }
                            is BreedCheckResult.BlockedCrossBreeding -> {
                                Card(
                                    shape = RoundedCornerShape(8.dp),
                                    colors = CardDefaults.cardColors(containerColor = FarmErrorContainer)
                                ) {
                                    Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(Icons.Default.Warning, contentDescription = null, tint = FarmError, modifier = Modifier.size(20.dp))
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Text(
                                                text = "${t("pedigree.check_breed_diff")} • ${b.titleEn}",
                                                fontWeight = FontWeight.Bold,
                                                color = FarmError,
                                                fontSize = 13.sp
                                            )
                                        }
                                        Text(b.detailEn, fontSize = 12.sp, color = FarmError)
                                        Text("${b.titleTa} ${b.detailTa}", fontSize = 11.sp, color = FarmError)
                                        Text("Doe: ${b.doeBreed} vs Buck: ${b.buckBreed}", fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = Color.DarkGray)
                                    }
                                }
                            }
                            is BreedCheckResult.BreedMissing -> {
                                Card(
                                    shape = RoundedCornerShape(8.dp),
                                    colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF3E0))
                                ) {
                                    Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(Icons.Default.Warning, contentDescription = null, tint = Color(0xFFE65100), modifier = Modifier.size(18.dp))
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Text(
                                                text = "✕ ${t("pedigree.breed_info_required")}",
                                                fontWeight = FontWeight.Bold,
                                                color = Color(0xFFE65100),
                                                fontSize = 12.sp
                                            )
                                        }
                                        Text(b.messageTa, fontSize = 11.sp, color = Color(0xFFE65100))

                                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                            if (b.isDoeMissing) {
                                                OutlinedButton(
                                                    onClick = {
                                                        goatToUpdateBreed = selectedDoe
                                                        newBreedChoice = "Boer"
                                                    },
                                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                                    modifier = Modifier.height(32.dp)
                                                ) {
                                                    Text("Update Doe Breed", fontSize = 11.sp)
                                                }
                                            }
                                            if (b.isBuckMissing) {
                                                OutlinedButton(
                                                    onClick = {
                                                        goatToUpdateBreed = selectedBuck
                                                        newBreedChoice = "Boer"
                                                    },
                                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                                    modifier = Modifier.height(32.dp)
                                                ) {
                                                    Text("Update Buck Breed", fontSize = 11.sp)
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        // 2. PEDIGREE CHECK
                        Text(t("pedigree.check_pedigree"), fontWeight = FontWeight.Bold, fontSize = 12.sp, color = FarmGreenDark)
                        when (val p = el.pedigreeCheck) {
                            is PedigreeCheckResult.AllowedNoRelationship -> {
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = FarmGreenContainer.copy(alpha = 0.7f),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier.padding(10.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = FarmSuccess, modifier = Modifier.size(18.dp))
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(
                                            text = t("pedigree.check_pedigree_ok"),
                                            fontWeight = FontWeight.Bold,
                                            color = FarmGreenDark,
                                            fontSize = 13.sp
                                        )
                                    }
                                }
                            }
                            is PedigreeCheckResult.BlockedCloseRelative -> {
                                Card(
                                    shape = RoundedCornerShape(8.dp),
                                    colors = CardDefaults.cardColors(containerColor = FarmErrorContainer)
                                ) {
                                    Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(Icons.Default.Warning, contentDescription = null, tint = FarmError, modifier = Modifier.size(20.dp))
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Text(
                                                text = "${t("pedigree.check_pedigree_fail")} • ${p.titleEn}",
                                                fontWeight = FontWeight.Bold,
                                                color = FarmError,
                                                fontSize = 13.sp
                                            )
                                        }
                                        Text(p.reasonEn, fontSize = 12.sp, color = FarmError)
                                        Text("${p.titleTa} ${p.reasonTa}", fontSize = 11.sp, color = FarmError)
                                    }
                                }
                            }
                            is PedigreeCheckResult.BlockedSameAnimal -> {
                                Card(
                                    shape = RoundedCornerShape(8.dp),
                                    colors = CardDefaults.cardColors(containerColor = FarmErrorContainer)
                                ) {
                                    Row(modifier = Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.Warning, contentDescription = null, tint = FarmError, modifier = Modifier.size(18.dp))
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(p.messageEn, fontWeight = FontWeight.Bold, color = FarmError, fontSize = 12.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            }

            DatePickerField(
                dateValue = matingDate,
                onDateSelected = { matingDate = it },
                label = t("breeding.mating_date")
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("Heat Observed Standing", fontWeight = FontWeight.SemiBold)
                Switch(
                    checked = heatObserved,
                    onCheckedChange = { heatObserved = it }
                )
            }

            // Method
            Text(t("breeding.status"), fontWeight = FontWeight.SemiBold)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Natural", "Artificial Insemination").forEach { m ->
                    FilterChip(
                        selected = method == m,
                        onClick = { method = m },
                        label = { Text(m) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = FarmGreenPrimary,
                            selectedLabelColor = Color.White
                        )
                    )
                }
            }

            OutlinedTextField(
                value = notes,
                onValueChange = { notes = it },
                label = { Text(t("herd.notes")) },
                placeholder = { Text("e.g. Pasture mating, observed twice") },
                modifier = Modifier.fillMaxWidth()
            )

            if (message != null) {
                Card(colors = CardDefaults.cardColors(containerColor = if (isSuccess) FarmSuccessContainer else FarmErrorContainer)) {
                    Text(
                        message ?: "",
                        color = if (isSuccess) FarmSuccess else FarmError,
                        modifier = Modifier.padding(12.dp)
                    )
                }
            }

            val canRecord = eligibility?.canRecordMating == true

            Button(
                onClick = {
                    if (doeId.isBlank() || buckId.isBlank()) {
                        message = "Please select both a Doe and a Buck."
                        isSuccess = false
                        return@Button
                    }
                    if (!canRecord) {
                        message = eligibility?.rejectionReasonEn ?: "Cannot record mating: checks failed."
                        isSuccess = false
                        return@Button
                    }

                    isSaving = true
                    message = null
                    coroutineScope.launch {
                        val record = MatingRecord(
                            doe_id_c = doeId,
                            buck_id_c = buckId,
                            mating_date_c = matingDate,
                            heat_observed_c = heatObserved,
                            method_c = method,
                            notes_c = notes.ifBlank { null }
                        )
                        val res = repository.recordMating(record)
                        isSaving = false
                        if (res.isSuccess) {
                            isSuccess = true
                            message = "Mating record saved successfully!"
                            onMatingSaved()
                        } else {
                            isSuccess = false
                            message = res.exceptionOrNull()?.message ?: "Failed to save mating"
                        }
                    }
                },
                enabled = !isSaving && canRecord,
                modifier = Modifier.fillMaxWidth().height(52.dp).testTag("save_mating_button"),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (canRecord) FarmGreenPrimary else Color(0xFFB0BEC5),
                    disabledContainerColor = Color(0xFFCFD8DC)
                )
            ) {
                if (isSaving) {
                    CircularProgressIndicator(color = Color.White, modifier = Modifier.size(24.dp))
                } else {
                    Text(t("breeding.btn_save"), fontWeight = FontWeight.Bold)
                }
            }
        }
    }

    // Breed Update Dialog
    goatToUpdateBreed?.let { target ->
        var expanded by remember { mutableStateOf(false) }
        AlertDialog(
            onDismissRequest = { if (!isUpdatingBreed) goatToUpdateBreed = null },
            title = { Text("Update Breed for ${target.tag_c}") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Select a verified breed for this animal before proceeding with farm mating:")
                    ExposedDropdownMenuBox(
                        expanded = expanded,
                        onExpandedChange = { expanded = !expanded }
                    ) {
                        OutlinedTextField(
                            value = newBreedChoice,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text(t("pedigree.breed")) },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
                            modifier = Modifier.fillMaxWidth().menuAnchor()
                        )
                        ExposedDropdownMenu(
                            expanded = expanded,
                            onDismissRequest = { expanded = false }
                        ) {
                            commonBreeds.forEach { b ->
                                DropdownMenuItem(
                                    text = { Text(b) },
                                    onClick = {
                                        newBreedChoice = b
                                        expanded = false
                                    }
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        isUpdatingBreed = true
                        coroutineScope.launch {
                            val updated = target.copy(breed_c = newBreedChoice)
                            repository.updateGoat(updated)
                            isUpdatingBreed = false
                            goatToUpdateBreed = null
                            onGoatsUpdated()
                        }
                    },
                    enabled = !isUpdatingBreed,
                    colors = ButtonDefaults.buttonColors(containerColor = FarmGreenPrimary)
                ) {
                    if (isUpdatingBreed) CircularProgressIndicator(color = Color.White, modifier = Modifier.size(20.dp))
                    else Text("Save Breed")
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { goatToUpdateBreed = null },
                    enabled = !isUpdatingBreed
                ) {
                    Text(t("btn.cancel"))
                }
            }
        )
    }
}

@Composable
fun PregnancyTab(
    repository: GoatRepository,
    goats: List<Goat>,
    today: String,
    dateFormat: SimpleDateFormat,
    onPregnancySaved: () -> Unit = {}
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val does = remember(goats) { goats.filter { it.sex_c.equals("Doe", ignoreCase = true) } }
    var doeId by remember { mutableStateOf(does.firstOrNull()?.id ?: "") }
    var confirmationDate by remember { mutableStateOf(today) }
    var expectedKiddingDate by remember {
        val cal = Calendar.getInstance()
        cal.add(Calendar.DAY_OF_YEAR, 150) // 150 days average goat gestation
        mutableStateOf(dateFormat.format(cal.time))
    }
    var status by remember { mutableStateOf("Confirmed") }
    var actualKiddingDate by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }

    var isSaving by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    var isSuccess by remember { mutableStateOf(false) }
    val coroutineScope = rememberCoroutineScope()

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text(t("breeding.tab_pregnancy"), fontWeight = FontWeight.Bold, color = FarmGreenDark)

            GoatSelector(
                goats = does.ifEmpty { goats },
                selectedGoatId = doeId,
                onGoatSelected = { doeId = it.id },
                label = t("breeding.doe_label")
            )

            DatePickerField(
                dateValue = confirmationDate,
                onDateSelected = { confirmationDate = it },
                label = t("purchases.date")
            )

            DatePickerField(
                dateValue = expectedKiddingDate,
                onDateSelected = { expectedKiddingDate = it },
                label = t("breeding.expected_date")
            )

            // Auto calculate +150 days button
            OutlinedButton(
                onClick = {
                    try {
                        val parsed = dateFormat.parse(confirmationDate) ?: Date()
                        val cal = Calendar.getInstance().apply {
                            time = parsed
                            add(Calendar.DAY_OF_YEAR, 150)
                        }
                        expectedKiddingDate = dateFormat.format(cal.time)
                    } catch (_: Exception) {}
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(t("breeding.gestation_calc"))
            }

            Text(t("herd.status"), fontWeight = FontWeight.SemiBold)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Confirmed", "Suspected", "Delivered", "Aborted").forEach { st ->
                    FilterChip(
                        selected = status == st,
                        onClick = { status = st },
                        label = { Text(st) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = if (st == "Confirmed") Color(0xFF7B1FA2) else FarmGreenPrimary,
                            selectedLabelColor = Color.White
                        )
                    )
                }
            }

            if (status == "Delivered") {
                DatePickerField(
                    dateValue = actualKiddingDate,
                    onDateSelected = { actualKiddingDate = it },
                    label = t("breeding.kidding_date")
                )
            }

            OutlinedTextField(
                value = notes,
                onValueChange = { notes = it },
                label = { Text(t("herd.notes")) },
                placeholder = { Text("e.g. Ultrasound confirms twins, good fetal movement") },
                modifier = Modifier.fillMaxWidth()
            )

            if (message != null) {
                Card(colors = CardDefaults.cardColors(containerColor = if (isSuccess) FarmSuccessContainer else FarmErrorContainer)) {
                    Text(
                        message ?: "",
                        color = if (isSuccess) FarmSuccess else FarmError,
                        modifier = Modifier.padding(12.dp)
                    )
                }
            }

            Button(
                onClick = {
                    if (doeId.isBlank()) {
                        message = "Please select a Doe."
                        isSuccess = false
                        return@Button
                    }
                    isSaving = true
                    message = null
                    coroutineScope.launch {
                        val record = PregnancyRecord(
                            doe_id_c = doeId,
                            confirmation_date_c = confirmationDate,
                            expected_kidding_date_c = expectedKiddingDate,
                            status_c = status,
                            actual_kidding_date_c = actualKiddingDate.ifBlank { null },
                            notes_c = notes.ifBlank { null }
                        )
                        val res = repository.recordPregnancy(record)
                        isSaving = false
                        if (res.isSuccess) {
                            isSuccess = true
                            message = "Pregnancy record confirmed & Doe status updated to Pregnant in Supabase!"
                            com.example.notification.KiddingReminderScheduler.triggerImmediateCheck(context)
                            onPregnancySaved()
                        } else {
                            isSuccess = false
                            message = res.exceptionOrNull()?.message ?: "Failed to save pregnancy"
                        }
                    }
                },
                enabled = !isSaving,
                modifier = Modifier.fillMaxWidth().height(52.dp).testTag("save_pregnancy_button"),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF7B1FA2))
            ) {
                if (isSaving) CircularProgressIndicator(color = Color.White, modifier = Modifier.size(24.dp))
                else Text(t("breeding.btn_save"), fontWeight = FontWeight.Bold)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun KiddingTab(
    repository: GoatRepository,
    goats: List<Goat>,
    today: String,
    preselectedDoeId: String? = null,
    onKiddingSaved: () -> Unit = {}
) {
    val does = remember(goats) { goats.filter { it.sex_c.equals("Doe", ignoreCase = true) || it.sex_c.equals("Female", ignoreCase = true) } }
    var doeId by remember(preselectedDoeId, does) {
        mutableStateOf(preselectedDoeId?.takeIf { id -> does.any { it.id == id } } ?: does.firstOrNull()?.id ?: "")
    }
    var eventDate by remember { mutableStateOf(today) }

    // Pregnancy Outcome dropdown (Requirement 6)
    val outcomes = listOf(
        "NORMAL DELIVERY",
        "ASSISTED DELIVERY",
        "CAESAREAN / SURGICAL",
        "ABORTED",
        "STILLBIRTH",
        "MOTHER DIED",
        "PENDING",
        "OTHER"
    )
    var selectedOutcome by remember { mutableStateOf("NORMAL DELIVERY") }
    var outcomeExpanded by remember { mutableStateOf(false) }

    // Normal Kidding fields
    var birthType by remember { mutableStateOf("Twin") } // Single, Twin, Triplet, Quadruplet
    var assistance by remember { mutableStateOf("None") }
    var complications by remember { mutableStateOf("None") }
    var normalNotes by remember { mutableStateOf("") }
    val kidsList = remember {
        mutableStateListOf(
            KidEntryState(tag = "K1", gender = "Female", birthWeight = "2.8", birthOrder = 1, condition = "Healthy"),
            KidEntryState(tag = "K2", gender = "Male", birthWeight = "2.6", birthOrder = 2, condition = "Healthy")
        )
    }

    // Abortion fields (Requirement 7 & 8)
    var gestationDays by remember { mutableStateOf("90") }
    var numberOfFetuses by remember { mutableStateOf("1") }
    val abortionReasons = listOf(
        "INFECTIOUS DISEASE",
        "PARASITIC INFECTION",
        "NUTRITIONAL PROBLEM",
        "MINERAL DEFICIENCY",
        "TRAUMA / INJURY",
        "HEAT STRESS",
        "POISONING / TOXICITY",
        "FEVER / SYSTEMIC ILLNESS",
        "REPRODUCTIVE PROBLEM",
        "HORMONAL / REPRODUCTIVE",
        "UNKNOWN",
        "OTHER"
    )
    var abortionReason by remember { mutableStateOf("INFECTIOUS DISEASE") }
    var abortionReasonExpanded by remember { mutableStateOf(false) }
    var customAbortionReason by remember { mutableStateOf("") }
    var observedSigns by remember { mutableStateOf("") }
    var vetTreatment by remember { mutableStateOf("") }
    var veterinarian by remember { mutableStateOf("") }
    var medication by remember { mutableStateOf("") }
    var abortionNotes by remember { mutableStateOf("") }
    var attachmentNote by remember { mutableStateOf("") }

    // Mortality Connection (Requirement 10)
    var motherDied by remember { mutableStateOf(false) }
    var confirmRecordMortality by remember { mutableStateOf(false) }

    // Stillbirth fields (Requirement 9)
    var stillbornTotalBorn by remember { mutableStateOf("1") }
    var stillbornCount by remember { mutableStateOf("1") }
    var stillbornGender by remember { mutableStateOf("Unknown") }
    var stillbornReason by remember { mutableStateOf("Full-term stillborn / Dystocia") }
    var stillbornNotes by remember { mutableStateOf("") }

    var isSaving by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    var isSuccess by remember { mutableStateOf(false) }
    val coroutineScope = rememberCoroutineScope()

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text(
                text = "Kidding, Delivery & Pregnancy Outcomes",
                fontWeight = FontWeight.Bold,
                fontSize = 17.sp,
                color = FarmGreenDark
            )

            // Pregnant Doe Selector
            GoatSelector(
                goats = does.ifEmpty { goats },
                selectedGoatId = doeId,
                onGoatSelected = { doeId = it.id },
                label = t("breeding.doe_label") + " *"
            )

            // Pregnancy Outcome * (Requirement 6)
            ExposedDropdownMenuBox(
                expanded = outcomeExpanded,
                onExpandedChange = { outcomeExpanded = !outcomeExpanded }
            ) {
                OutlinedTextField(
                    value = selectedOutcome,
                    onValueChange = {},
                    readOnly = true,
                    label = { Text("PREGNANCY OUTCOME *") },
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = outcomeExpanded) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .menuAnchor()
                        .testTag("select_pregnancy_outcome"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = if (selectedOutcome == "ABORTED") Color(0xFFC62828) else FarmGreenPrimary,
                        unfocusedBorderColor = if (selectedOutcome == "ABORTED") Color(0xFFE57373) else Color.Gray
                    )
                )
                ExposedDropdownMenu(
                    expanded = outcomeExpanded,
                    onDismissRequest = { outcomeExpanded = false }
                ) {
                    outcomes.forEach { out ->
                        DropdownMenuItem(
                            text = {
                                Text(
                                    text = out,
                                    fontWeight = if (out == selectedOutcome) FontWeight.Bold else FontWeight.Normal,
                                    color = if (out == "ABORTED") Color(0xFFC62828) else if (out == "STILLBIRTH") Color(0xFFE65100) else Color.Unspecified
                                )
                            },
                            onClick = {
                                selectedOutcome = out
                                outcomeExpanded = false
                            }
                        )
                    }
                }
            }

            // ==============================================================================
            // CASE A: ABORTED PREGNANCY WORKFLOW (Requirements 7, 8, 9, 10, 14)
            // ==============================================================================
            if (selectedOutcome == "ABORTED") {
                Surface(
                    color = Color(0xFFFFF1F2),
                    shape = RoundedCornerShape(12.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFFECDD3)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Warning, contentDescription = null, tint = Color(0xFFE11D48))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "ABORTION DETAILS (Permanent Reproductive Record)",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = Color(0xFF9F1239)
                            )
                        }

                        DatePickerField(
                            dateValue = eventDate,
                            onDateSelected = { eventDate = it },
                            label = "Abortion Date *"
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            OutlinedTextField(
                                value = gestationDays,
                                onValueChange = { gestationDays = it },
                                label = { Text("Gestation Days") },
                                placeholder = { Text("e.g. 90") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                modifier = Modifier.weight(1f)
                            )
                            OutlinedTextField(
                                value = numberOfFetuses,
                                onValueChange = { numberOfFetuses = it },
                                label = { Text("Fetuses Expelled") },
                                placeholder = { Text("e.g. 1 or 2") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                modifier = Modifier.weight(1f)
                            )
                        }

                        // Abortion Reason Dropdown
                        ExposedDropdownMenuBox(
                            expanded = abortionReasonExpanded,
                            onExpandedChange = { abortionReasonExpanded = !abortionReasonExpanded }
                        ) {
                            OutlinedTextField(
                                value = abortionReason,
                                onValueChange = {},
                                readOnly = true,
                                label = { Text("Abortion Reason *") },
                                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = abortionReasonExpanded) },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .menuAnchor()
                                    .testTag("select_abortion_reason")
                            )
                            ExposedDropdownMenu(
                                expanded = abortionReasonExpanded,
                                onDismissRequest = { abortionReasonExpanded = false }
                            ) {
                                abortionReasons.forEach { r ->
                                    DropdownMenuItem(
                                        text = { Text(r) },
                                        onClick = {
                                            abortionReason = r
                                            abortionReasonExpanded = false
                                        }
                                    )
                                }
                            }
                        }

                        if (abortionReason == "OTHER") {
                            OutlinedTextField(
                                value = customAbortionReason,
                                onValueChange = { customAbortionReason = it },
                                label = { Text("Custom Abortion Reason *") },
                                placeholder = { Text("Specify clinical/observed cause") },
                                modifier = Modifier.fillMaxWidth()
                            )
                        }

                        OutlinedTextField(
                            value = observedSigns,
                            onValueChange = { observedSigns = it },
                            label = { Text("Observed Clinical Signs") },
                            placeholder = { Text("e.g. Vaginal discharge, anorexia, pyrexia") },
                            modifier = Modifier.fillMaxWidth()
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            OutlinedTextField(
                                value = veterinarian,
                                onValueChange = { veterinarian = it },
                                label = { Text("Veterinarian") },
                                placeholder = { Text("Attending Vet") },
                                modifier = Modifier.weight(1f)
                            )
                            OutlinedTextField(
                                value = medication,
                                onValueChange = { medication = it },
                                label = { Text("Medication") },
                                placeholder = { Text("e.g. Oxytetracycline") },
                                modifier = Modifier.weight(1f)
                            )
                        }

                        OutlinedTextField(
                            value = vetTreatment,
                            onValueChange = { vetTreatment = it },
                            label = { Text("Veterinary Treatment") },
                            placeholder = { Text("e.g. Uterine flush, supportive fluids") },
                            modifier = Modifier.fillMaxWidth()
                        )

                        OutlinedTextField(
                            value = attachmentNote,
                            onValueChange = { attachmentNote = it },
                            label = { Text("Photo / Lab Report Note") },
                            placeholder = { Text("e.g. Lab culture sent to IVRI; placental sample photo #A102") },
                            modifier = Modifier.fillMaxWidth()
                        )

                        OutlinedTextField(
                            value = abortionNotes,
                            onValueChange = { abortionNotes = it },
                            label = { Text("Additional Clinical Notes") },
                            modifier = Modifier.fillMaxWidth()
                        )

                        HorizontalDivider(color = Color(0xFFFECDD3))

                        // Mother Mortality Connection (Requirement 10)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Did the mother die?",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    color = Color(0xFF9F1239)
                                )
                                Text(
                                    text = "If YES, you can record confirmed maternal mortality. Doe is NOT marked deceased unless confirmed.",
                                    fontSize = 11.sp,
                                    color = Color.DarkGray
                                )
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                FilterChip(
                                    selected = !motherDied,
                                    onClick = {
                                        motherDied = false
                                        confirmRecordMortality = false
                                    },
                                    label = { Text("NO", fontWeight = FontWeight.Bold) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = FarmGreenDark,
                                        selectedLabelColor = Color.White
                                    )
                                )
                                FilterChip(
                                    selected = motherDied,
                                    onClick = {
                                        motherDied = true
                                        confirmRecordMortality = true
                                    },
                                    label = { Text("YES", fontWeight = FontWeight.Bold) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = Color(0xFFC62828),
                                        selectedLabelColor = Color.White
                                    )
                                )
                            }
                        }

                        if (motherDied) {
                            Surface(
                                color = Color(0xFFFEE2E2),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Text("Record Maternal Mortality", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color(0xFFB91C1C))
                                    Text("Goat ID: $doeId", fontSize = 11.sp)
                                    Text("Date: $eventDate", fontSize = 11.sp)
                                    Text("Related Event: Abortion ($abortionReason)", fontSize = 11.sp)
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text("Confirm Doe Deceased Status:", fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                                        Switch(
                                            checked = confirmRecordMortality,
                                            onCheckedChange = { confirmRecordMortality = it }
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
            // ==============================================================================
            // CASE B: STILLBIRTH WORKFLOW (Requirement 9)
            // ==============================================================================
            else if (selectedOutcome == "STILLBIRTH") {
                Surface(
                    color = Color(0xFFFFF7ED),
                    shape = RoundedCornerShape(12.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFFED7AA)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = "STILLBIRTH REGISTRATION",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = Color(0xFFC2410C)
                        )

                        DatePickerField(
                            dateValue = eventDate,
                            onDateSelected = { eventDate = it },
                            label = "Stillbirth Date *"
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            OutlinedTextField(
                                value = stillbornTotalBorn,
                                onValueChange = { stillbornTotalBorn = it },
                                label = { Text("Total Born") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                modifier = Modifier.weight(1f)
                            )
                            OutlinedTextField(
                                value = stillbornCount,
                                onValueChange = { stillbornCount = it },
                                label = { Text("Number Stillborn *") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                modifier = Modifier.weight(1f)
                            )
                        }

                        Text("Sex / Gender if known:", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf("Male", "Female", "Unknown", "Mixed").forEach { g ->
                                FilterChip(
                                    selected = stillbornGender == g,
                                    onClick = { stillbornGender = g },
                                    label = { Text(g) }
                                )
                            }
                        }

                        OutlinedTextField(
                            value = stillbornReason,
                            onValueChange = { stillbornReason = it },
                            label = { Text("Cause / Suspected Reason") },
                            placeholder = { Text("e.g. Dystocia / Prolonged labor / Unknown") },
                            modifier = Modifier.fillMaxWidth()
                        )

                        OutlinedTextField(
                            value = stillbornNotes,
                            onValueChange = { stillbornNotes = it },
                            label = { Text("Notes / Post-Mortem observations") },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }
            // ==============================================================================
            // CASE C: NORMAL, ASSISTED, CAESAREAN DELIVERY (Kid Registration Section)
            // ==============================================================================
            else {
                DatePickerField(
                    dateValue = eventDate,
                    onDateSelected = { eventDate = it },
                    label = t("breeding.kidding_date") + " *"
                )

                Text("Birth Type", fontWeight = FontWeight.SemiBold)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("Single", "Twin", "Triplet", "Quadruplet").forEach { bt ->
                        FilterChip(
                            selected = birthType == bt,
                            onClick = {
                                birthType = bt
                                val targetCount = when (bt) {
                                    "Single" -> 1
                                    "Twin" -> 2
                                    "Triplet" -> 3
                                    else -> 4
                                }
                                while (kidsList.size < targetCount) {
                                    kidsList.add(KidEntryState(tag = "K${kidsList.size + 1}", gender = if (kidsList.size % 2 == 0) "Female" else "Male", birthWeight = "2.5", birthOrder = kidsList.size + 1))
                                }
                                while (kidsList.size > targetCount) {
                                    kidsList.removeAt(kidsList.size - 1)
                                }
                            },
                            label = { Text(bt, fontSize = 11.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = FarmGreenPrimary,
                                selectedLabelColor = Color.White
                            )
                        )
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedTextField(
                        value = assistance,
                        onValueChange = { assistance = it },
                        label = { Text("Assistance") },
                        placeholder = { Text("None / Easy pull") },
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = complications,
                        onValueChange = { complications = it },
                        label = { Text("Complications") },
                        placeholder = { Text("None / Dystocia") },
                        modifier = Modifier.weight(1f)
                    )
                }

                HorizontalDivider()
                Text(
                    text = "${t("breeding.kids_born")} (${kidsList.size})",
                    fontWeight = FontWeight.Bold,
                    color = FarmBrown
                )

                kidsList.forEachIndexed { index, kid ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = FarmAmberContainer.copy(alpha = 0.25f)),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(10.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("#${index + 1}", fontWeight = FontWeight.Bold, color = FarmBrown)
                                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                    FilterChip(
                                        selected = kid.gender == "Female",
                                        onClick = { kid.gender = "Female" },
                                        label = { Text("Doe (F)", fontSize = 10.sp) }
                                    )
                                    FilterChip(
                                        selected = kid.gender == "Male",
                                        onClick = { kid.gender = "Male" },
                                        label = { Text("Buck (M)", fontSize = 10.sp) }
                                    )
                                }
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                OutlinedTextField(
                                    value = kid.tag,
                                    onValueChange = { kid.tag = it },
                                    label = { Text(t("herd.tag")) },
                                    modifier = Modifier.weight(1f),
                                    singleLine = true
                                )
                                OutlinedTextField(
                                    value = kid.birthWeight,
                                    onValueChange = { kid.birthWeight = it },
                                    label = { Text(t("herd.weight") + " (kg)") },
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                                    modifier = Modifier.weight(1f),
                                    singleLine = true
                                )
                            }
                        }
                    }
                }

                Button(
                    onClick = {
                        kidsList.add(KidEntryState(tag = "K${kidsList.size + 1}", gender = "Female", birthWeight = "2.5", birthOrder = kidsList.size + 1))
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.Add, contentDescription = null)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("+ Add Kid")
                }

                OutlinedTextField(
                    value = normalNotes,
                    onValueChange = { normalNotes = it },
                    label = { Text(t("herd.notes")) },
                    placeholder = { Text("Vigorous kids, nursing well, colostrum fed") },
                    modifier = Modifier.fillMaxWidth()
                )
            }

            if (message != null) {
                Card(colors = CardDefaults.cardColors(containerColor = if (isSuccess) FarmSuccessContainer else FarmErrorContainer)) {
                    Text(
                        message ?: "",
                        color = if (isSuccess) FarmSuccess else FarmError,
                        modifier = Modifier.padding(12.dp)
                    )
                }
            }

            Button(
                onClick = {
                    if (doeId.isBlank()) {
                        message = "Please select a Doe."
                        isSuccess = false
                        return@Button
                    }

                    isSaving = true
                    message = null

                    coroutineScope.launch {
                        try {
                            when (selectedOutcome) {
                                "ABORTED" -> {
                                    val finalReason = if (abortionReason == "OTHER") customAbortionReason.ifBlank { "OTHER" } else abortionReason
                                    val abRes = repository.insurance.recordAbortion(
                                        doeId = doeId,
                                        pregnancyId = null,
                                        abortionDate = eventDate,
                                        pregnancyAgeDays = gestationDays.toIntOrNull(),
                                        numberOfFetuses = numberOfFetuses.toIntOrNull(),
                                        suspectedCause = finalReason,
                                        confirmedCause = finalReason,
                                        causeCategory = abortionReason,
                                        vetDiagnosis = observedSigns.ifBlank { null },
                                        symptoms = observedSigns.ifBlank { null },
                                        treatment = if (medication.isNotBlank()) "$vetTreatment. Meds: $medication" else vetTreatment.ifBlank { null },
                                        vetDoctor = veterinarian.ifBlank { null },
                                        notes = buildString {
                                            if (abortionNotes.isNotBlank()) append(abortionNotes)
                                            if (attachmentNote.isNotBlank()) append(" | Attachment: $attachmentNote")
                                        }.ifBlank { null }
                                    )

                                    if (motherDied && confirmRecordMortality) {
                                        val doeGoat = does.find { it.id == doeId } ?: goats.find { it.id == doeId }
                                        val mEvent = MortalityEvent(
                                            goat_id = doeId,
                                            goat_tag = doeGoat?.tag_c ?: "Doe-$doeId",
                                            death_date = eventDate,
                                            event_type = "DOE_POST_DELIVERY_DEATH",
                                            immediate_cause = "Abortion Complication: $finalReason",
                                            underlying_cause = observedSigns.ifBlank { null },
                                            cause_category = "Reproductive complication",
                                            vet_doctor = veterinarian.ifBlank { null },
                                            treatment_history = vetTreatment.ifBlank { null },
                                            notes = "Mother confirmed deceased during abortion on $eventDate."
                                        )
                                        repository.insurance.recordMortality(mEvent)
                                    }

                                    isSaving = false
                                    if (abRes.isSuccess) {
                                        isSuccess = true
                                        message = if (motherDied && confirmRecordMortality) {
                                            "Abortion record saved and Doe marked deceased with mortality entry!"
                                        } else {
                                            "Abortion recorded permanently in reproductive history. Doe status returned to Active!"
                                        }
                                        onKiddingSaved()
                                    } else {
                                        isSuccess = false
                                        message = abRes.exceptionOrNull()?.message ?: "Failed to save abortion"
                                    }
                                }

                                "STILLBIRTH" -> {
                                    val sbCount = stillbornCount.toIntOrNull() ?: 1
                                    val res = repository.insurance.recordDeliveryOutcome(
                                        doeId = doeId,
                                        pregnancyId = null,
                                        deliveryDate = eventDate,
                                        deliveryType = "Stillbirth",
                                        numLiveKids = 0,
                                        numStillborn = sbCount,
                                        maleKids = if (stillbornGender == "Male") sbCount else 0,
                                        femaleKids = if (stillbornGender == "Female") sbCount else 0,
                                        birthWeight = null,
                                        complications = stillbornReason.ifBlank { null },
                                        vetDoctor = null,
                                        notes = stillbornNotes.ifBlank { null }
                                    )
                                    isSaving = false
                                    if (res.isSuccess) {
                                        isSuccess = true
                                        message = "Stillbirth ($sbCount kids) recorded permanently in reproductive history."
                                        onKiddingSaved()
                                    } else {
                                        isSuccess = false
                                        message = res.exceptionOrNull()?.message ?: "Failed to save stillbirth"
                                    }
                                }

                                else -> {
                                    // Normal, Assisted, Caesarean or other delivery
                                    val record = KiddingRecord(
                                        doe_id_c = doeId,
                                        kidding_date_c = eventDate,
                                        birth_type_c = birthType,
                                        assistance_c = if (selectedOutcome == "ASSISTED DELIVERY") "Assisted" else if (selectedOutcome == "CAESAREAN / SURGICAL") "Caesarean" else assistance,
                                        complications_c = complications,
                                        notes_c = "Outcome: $selectedOutcome. $normalNotes".trim()
                                    )
                                    val kidsToSave = kidsList.mapIndexed { idx, k ->
                                        KidRecord(
                                            kid_tag_c = k.tag.ifBlank { "Kid-${idx + 1}" },
                                            kidding_record_id_c = record.id,
                                            birth_weight_c = k.birthWeight.toDoubleOrNull(),
                                            birth_order_c = idx + 1
                                        )
                                    }
                                    val res = repository.recordKidding(record, kidsToSave)
                                    isSaving = false
                                    if (res.isSuccess) {
                                        isSuccess = true
                                        message = "Kidding record and ${kidsToSave.size} kids saved successfully!"
                                        onKiddingSaved()
                                    } else {
                                        isSuccess = false
                                        message = res.exceptionOrNull()?.message ?: "Failed to save kidding"
                                    }
                                }
                            }
                        } catch (e: Exception) {
                            isSaving = false
                            isSuccess = false
                            message = e.message ?: "An error occurred"
                        }
                    }
                },
                enabled = !isSaving,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("save_kidding_button"),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (selectedOutcome == "ABORTED") Color(0xFFC62828) else FarmGreenDark
                )
            ) {
                if (isSaving) {
                    CircularProgressIndicator(color = Color.White, modifier = Modifier.size(24.dp))
                } else {
                    Text(
                        text = if (selectedOutcome == "ABORTED") "Record Abortion Event" else t("breeding.btn_save"),
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}
