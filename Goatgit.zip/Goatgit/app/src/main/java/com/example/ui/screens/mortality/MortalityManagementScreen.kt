package com.example.ui.screens.mortality

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.supabase.*
import com.example.ui.components.DatePickerField
import com.example.ui.theme.*
import com.example.util.CurrencyUtils
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.TimeUnit

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MortalityManagementScreen(
    repository: GoatRepository,
    onNavigateBack: () -> Unit,
    onNavigateToInsurance: () -> Unit = {},
    showTopBar: Boolean = true,
    modifier: Modifier = Modifier
) {
    if (showTopBar) {
        BackHandler { onNavigateBack() }
    }

    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val dateFormat = remember { SimpleDateFormat("yyyy-MM-dd", Locale.US) }
    val today = remember { dateFormat.format(Date()) }

    var selectedTab by remember { mutableIntStateOf(0) } // 0: Records, 1: Goat Deaths, 2: Kid Deaths, 3: Reasons, 4: Statistics, 5: Cost
    var mortalities by remember { mutableStateOf<List<MortalityEvent>>(emptyList()) }
    var reproductiveEvents by remember { mutableStateOf<List<ReproductiveEvent>>(emptyList()) }
    var goats by remember { mutableStateOf<List<Goat>>(emptyList()) }
    var policies by remember { mutableStateOf<List<InsurancePolicy>>(emptyList()) }
    var summary by remember { mutableStateOf<FarmMortalitySummary?>(null) }
    var isLoading by remember { mutableStateOf(true) }

    var showRecordMortalityDialog by remember { mutableStateOf(false) }
    var pendingClaimPolicy by remember { mutableStateOf<InsurancePolicy?>(null) }
    var pendingMortalityEvent by remember { mutableStateOf<MortalityEvent?>(null) }
    var showInsuranceClaimAlert by remember { mutableStateOf(false) }
    var showAutoFillClaimDialog by remember { mutableStateOf(false) }
    var selectedReasonFilter by remember { mutableStateOf<String?>(null) }
    var selectedStatisticFilter by remember { mutableStateOf<String?>(null) }

    fun loadData() {
        isLoading = true
        coroutineScope.launch {
            val mRes = repository.insurance.getMortalityEvents()
            if (mRes.isSuccess) mortalities = mRes.getOrThrow()

            val rRes = repository.insurance.getAbortions()
            if (rRes.isSuccess) reproductiveEvents = rRes.getOrThrow()

            val gRes = repository.getGoats()
            if (gRes.isSuccess) goats = gRes.getOrThrow()

            val pRes = repository.insurance.getPolicies()
            if (pRes.isSuccess) policies = pRes.getOrThrow()

            val sRes = repository.insurance.getFarmMortalitySummary()
            if (sRes.isSuccess) summary = sRes.getOrThrow()

            isLoading = false
        }
    }

    LaunchedEffect(Unit) {
        loadData()
    }

    // Filter logic
    val currentMonth = today.take(7)
    val currentYear = today.take(4)

    val adultDeaths = remember(mortalities) {
        mortalities.filter { it.event_type.equals("ADULT_DEATH", ignoreCase = true) || it.event_type.equals("DOE_POST_DELIVERY_DEATH", ignoreCase = true) }
    }
    val kidDeaths = remember(mortalities) {
        mortalities.filter { it.event_type.equals("KID_DEATH", ignoreCase = true) }
    }
    val thisMonthDeaths = remember(mortalities) {
        mortalities.filter { it.death_date.startsWith(currentMonth) }
    }
    val thisYearDeaths = remember(mortalities) {
        mortalities.filter { it.death_date.startsWith(currentYear) }
    }
    val abortions = remember(reproductiveEvents) {
        reproductiveEvents.filter { it.event_type.equals("ABORTION", ignoreCase = true) }
    }
    val stillbirths = remember(reproductiveEvents, mortalities) {
        reproductiveEvents.filter { it.event_type.equals("STILLBIRTH", ignoreCase = true) }
    }

    // Repeated mortality alerts (> 1 death with same cause within 30 days)
    val recentAlerts = remember(mortalities) {
        val alerts = mutableListOf<String>()
        val recentDeaths = mortalities.filter {
            try {
                val d = dateFormat.parse(it.death_date) ?: Date()
                val diffDays = TimeUnit.MILLISECONDS.toDays(Date().time - d.time)
                diffDays <= 7
            } catch (_: Exception) { false }
        }
        if (recentDeaths.isNotEmpty()) {
            alerts.add("${recentDeaths.size} mortality recorded in the last 7 days. Check biosecurity and pen hygiene.")
        }
        val causeCounts = recentDeaths.groupBy { it.cause_category }
        causeCounts.forEach { (cat, list) ->
            if (list.size >= 2) {
                alerts.add("Repeated cause detected: ${list.size} cases of '$cat' within recent period.")
            }
        }
        val recentKidDeaths = recentDeaths.count { it.event_type.equals("KID_DEATH", ignoreCase = true) }
        if (recentKidDeaths >= 2) {
            alerts.add("Kid mortality spike: $recentKidDeaths kids lost recently. Review colostrum feeding, warmth & pneumonia prevention.")
        }
        alerts
    }

    Scaffold(
        topBar = {
            if (showTopBar) {
                TopAppBar(
                    title = {
                        Column {
                            Text(
                                text = "Mortality Management",
                                fontWeight = FontWeight.Bold,
                                fontSize = 18.sp
                            )
                            Text(
                                text = "Loss Tracking, Root Cause Analysis & Insurance Claims",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    },
                    navigationIcon = {
                        IconButton(
                            onClick = onNavigateBack,
                            modifier = Modifier.testTag("mortality_btn_back")
                        ) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                        }
                    },
                    actions = {
                        IconButton(
                            onClick = { loadData() },
                            modifier = Modifier.testTag("mortality_btn_refresh")
                        ) {
                            Icon(Icons.Default.Refresh, contentDescription = "Refresh")
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.White)
                )
            }
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { showRecordMortalityDialog = true },
                containerColor = Color(0xFFC62828),
                contentColor = Color.White,
                icon = { Icon(Icons.Default.Add, contentDescription = null) },
                text = { Text("Record Mortality", fontWeight = FontWeight.Bold) },
                modifier = Modifier.testTag("fab_record_mortality")
            )
        },
        containerColor = Color(0xFFF8F9FA),
        modifier = modifier
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Dashboard KPI Metric Cards Header
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color.White)
                    .padding(horizontal = 14.dp, vertical = 10.dp)
            ) {
                Text(
                    text = "MORTALITY DASHBOARD",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    color = Color(0xFFC62828)
                )
                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    MortalityKpiChip(
                        title = "Total",
                        value = "${mortalities.size}",
                        icon = Icons.Default.WarningAmber,
                        color = Color(0xFFC62828),
                        isSelected = selectedStatisticFilter == "ALL",
                        onClick = {
                            selectedStatisticFilter = if (selectedStatisticFilter == "ALL") null else "ALL"
                            selectedTab = 0
                        },
                        modifier = Modifier.weight(1f)
                    )
                    MortalityKpiChip(
                        title = "Adults",
                        value = "${adultDeaths.size}",
                        icon = Icons.Default.Pets,
                        color = Color(0xFFE65100),
                        isSelected = selectedStatisticFilter == "ADULTS",
                        onClick = {
                            selectedStatisticFilter = if (selectedStatisticFilter == "ADULTS") null else "ADULTS"
                            selectedTab = 1
                        },
                        modifier = Modifier.weight(1f)
                    )
                    MortalityKpiChip(
                        title = "Kids",
                        value = "${kidDeaths.size}",
                        icon = Icons.Default.ChildCare,
                        color = Color(0xFF8E24AA),
                        isSelected = selectedStatisticFilter == "KIDS",
                        onClick = {
                            selectedStatisticFilter = if (selectedStatisticFilter == "KIDS") null else "KIDS"
                            selectedTab = 2
                        },
                        modifier = Modifier.weight(1f)
                    )
                    MortalityKpiChip(
                        title = "This Month",
                        value = "${thisMonthDeaths.size}",
                        icon = Icons.Default.CalendarMonth,
                        color = Color(0xFF1565C0),
                        isSelected = selectedStatisticFilter == "MONTH",
                        onClick = {
                            selectedStatisticFilter = if (selectedStatisticFilter == "MONTH") null else "MONTH"
                            selectedTab = 0
                        },
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    val herdSize = goats.size.coerceAtLeast(1)
                    val mortalityRate = (mortalities.size.toDouble() / herdSize.toDouble()) * 100.0

                    MortalityKpiChip(
                        title = "Rate",
                        value = "${String.format(Locale.US, "%.1f", mortalityRate)}%",
                        icon = Icons.Default.Analytics,
                        color = Color(0xFFD32F2F),
                        isSelected = selectedStatisticFilter == "RATE",
                        onClick = { selectedTab = 4 },
                        modifier = Modifier.weight(1f)
                    )
                    MortalityKpiChip(
                        title = "This Year",
                        value = "${thisYearDeaths.size}",
                        icon = Icons.Default.DateRange,
                        color = Color(0xFF455A64),
                        isSelected = selectedStatisticFilter == "YEAR",
                        onClick = {
                            selectedStatisticFilter = if (selectedStatisticFilter == "YEAR") null else "YEAR"
                            selectedTab = 0
                        },
                        modifier = Modifier.weight(1f)
                    )
                    MortalityKpiChip(
                        title = "Abortions",
                        value = "${abortions.size}",
                        icon = Icons.Default.EventBusy,
                        color = Color(0xFF6A1B9A),
                        isSelected = selectedStatisticFilter == "ABORTIONS",
                        onClick = {
                            selectedStatisticFilter = if (selectedStatisticFilter == "ABORTIONS") null else "ABORTIONS"
                            selectedTab = 0
                        },
                        modifier = Modifier.weight(1f)
                    )
                    MortalityKpiChip(
                        title = "Stillbirths",
                        value = "${stillbirths.size}",
                        icon = Icons.Default.HeartBroken,
                        color = Color(0xFFB71C1C),
                        isSelected = selectedStatisticFilter == "STILLBIRTHS",
                        onClick = {
                            selectedStatisticFilter = if (selectedStatisticFilter == "STILLBIRTHS") null else "STILLBIRTHS"
                            selectedTab = 0
                        },
                        modifier = Modifier.weight(1f)
                    )
                }

                if (selectedStatisticFilter != null) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Filter active: $selectedStatisticFilter",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFC62828)
                        )
                        TextButton(
                            onClick = { selectedStatisticFilter = null },
                            contentPadding = PaddingValues(0.dp)
                        ) {
                            Text("Clear Filter", fontSize = 11.sp)
                        }
                    }
                }
            }

            // Notification / Alert Banner
            if (recentAlerts.isNotEmpty()) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFFFEBEE)),
                    shape = RoundedCornerShape(0.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.NotificationsActive, contentDescription = null, tint = Color(0xFFC62828), modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("MORTALITY ALERTS (${recentAlerts.size})", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = Color(0xFFC62828))
                        }
                        recentAlerts.take(2).forEach { alertMsg ->
                            Text("• $alertMsg", fontSize = 11.sp, color = Color(0xFFB71C1C), modifier = Modifier.padding(top = 2.dp))
                        }
                    }
                }
            }

            // Sections / Tabs
            ScrollableTabRow(
                selectedTabIndex = selectedTab,
                containerColor = Color.White,
                edgePadding = 12.dp
            ) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = { Text("Mortality Records (${mortalities.size})", fontSize = 12.sp, fontWeight = FontWeight.Bold) },
                    modifier = Modifier.testTag("tab_mortality_records")
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = { Text("Goat Deaths (${adultDeaths.size})", fontSize = 12.sp, fontWeight = FontWeight.Bold) },
                    modifier = Modifier.testTag("tab_goat_deaths")
                )
                Tab(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    text = { Text("Kid Deaths (${kidDeaths.size})", fontSize = 12.sp, fontWeight = FontWeight.Bold) },
                    modifier = Modifier.testTag("tab_kid_deaths")
                )
                Tab(
                    selected = selectedTab == 3,
                    onClick = { selectedTab = 3 },
                    text = { Text("Mortality Reasons", fontSize = 12.sp, fontWeight = FontWeight.Bold) },
                    modifier = Modifier.testTag("tab_mortality_reasons")
                )
                Tab(
                    selected = selectedTab == 4,
                    onClick = { selectedTab = 4 },
                    text = { Text("Statistics", fontSize = 12.sp, fontWeight = FontWeight.Bold) },
                    modifier = Modifier.testTag("tab_mortality_stats")
                )
                Tab(
                    selected = selectedTab == 5,
                    onClick = { selectedTab = 5 },
                    text = { Text("Mortality Cost", fontSize = 12.sp, fontWeight = FontWeight.Bold) },
                    modifier = Modifier.testTag("tab_mortality_cost")
                )
            }

            if (isLoading) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = Color(0xFFC62828))
                }
            } else {
                when (selectedTab) {
                    0 -> MortalityRecordsList(
                        records = when (selectedStatisticFilter) {
                            "ADULTS" -> adultDeaths
                            "KIDS" -> kidDeaths
                            "MONTH" -> thisMonthDeaths
                            "YEAR" -> thisYearDeaths
                            else -> mortalities
                        },
                        policies = policies,
                        onRecordMortality = { showRecordMortalityDialog = true },
                        onNavigateToInsurance = onNavigateToInsurance
                    )
                    1 -> MortalityRecordsList(
                        records = adultDeaths,
                        policies = policies,
                        onRecordMortality = { showRecordMortalityDialog = true },
                        onNavigateToInsurance = onNavigateToInsurance
                    )
                    2 -> MortalityRecordsList(
                        records = kidDeaths,
                        policies = policies,
                        onRecordMortality = { showRecordMortalityDialog = true },
                        onNavigateToInsurance = onNavigateToInsurance
                    )
                    3 -> MortalityReasonsBreakdown(
                        mortalities = mortalities,
                        selectedReason = selectedReasonFilter,
                        onSelectReason = { selectedReasonFilter = it }
                    )
                    4 -> MortalityStatisticsView(
                        summary = summary,
                        mortalities = mortalities,
                        goats = goats
                    )
                    5 -> MortalityCostView(
                        mortalities = mortalities,
                        goats = goats
                    )
                }
            }
        }
    }

    // Dialog: Record Mortality
    if (showRecordMortalityDialog) {
        RecordMortalityDialog(
            goats = goats,
            policies = policies,
            onDismiss = { showRecordMortalityDialog = false },
            onSave = { event ->
                showRecordMortalityDialog = false
                coroutineScope.launch {
                    val res = repository.insurance.recordMortality(event)
                    if (res.isSuccess) {
                        Toast.makeText(context, "Mortality record saved. Goat status updated to Deceased.", Toast.LENGTH_LONG).show()
                        loadData()

                        // Check if the deceased animal has an active insurance policy
                        val matchedPolicy = policies.find {
                            (it.id == event.insurance_policy_id || it.goat_id == event.goat_id || it.goat_tag.equals(event.goat_tag, ignoreCase = true)) &&
                            it.isActive
                        }
                        if (matchedPolicy != null) {
                            pendingClaimPolicy = matchedPolicy
                            pendingMortalityEvent = event
                            showInsuranceClaimAlert = true
                        }
                    } else {
                        Toast.makeText(context, "Error: ${res.exceptionOrNull()?.message}", Toast.LENGTH_LONG).show()
                    }
                }
            },
            onNavigateToInsurance = onNavigateToInsurance
        )
    }

    // Modal: Alert when Deceased Goat has Active Insurance Coverage
    if (showInsuranceClaimAlert && pendingClaimPolicy != null && pendingMortalityEvent != null) {
        val pol = pendingClaimPolicy!!
        val mort = pendingMortalityEvent!!
        AlertDialog(
            onDismissRequest = { showInsuranceClaimAlert = false },
            icon = {
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(Color(0xFFFEF3C7)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Shield,
                        contentDescription = null,
                        tint = Color(0xFFD97706),
                        modifier = Modifier.size(28.dp)
                    )
                }
            },
            title = {
                Text(
                    text = "Active Insurance Policy Detected",
                    fontWeight = FontWeight.Bold,
                    fontSize = 17.sp,
                    color = Color(0xFF1E3A8A)
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Deceased animal ${mort.goat_tag} is covered under active insurance policy #${pol.policy_number ?: pol.id.take(8)} with ${pol.insurance_company}.",
                        fontSize = 13.5.sp,
                        color = Color.DarkGray
                    )
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFEFF6FF)),
                        shape = RoundedCornerShape(10.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFBFDBFE)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text("Policy: ${pol.policy_name}", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            Text("Company: ${pol.insurance_company}", fontSize = 12.sp)
                            Text("Policy Number: ${pol.policy_number ?: "Pending"}", fontSize = 12.sp)
                            Text("Sum Insured: ${CurrencyUtils.formatInr(pol.sum_insured)}", fontWeight = FontWeight.Bold, color = FarmGreenDark, fontSize = 12.5.sp)
                            Text("Date of Death: ${mort.death_date}", fontSize = 11.5.sp, color = Color.Gray)
                            Text("Cause: ${mort.immediate_cause}", fontSize = 11.5.sp, color = Color.Gray)
                        }
                    }
                    Text(
                        text = "Would you like to auto-fill the claim form to submit for indemnity recovery?",
                        fontSize = 12.5.sp,
                        fontWeight = FontWeight.Medium,
                        color = Color(0xFF0F172A)
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        showInsuranceClaimAlert = false
                        showAutoFillClaimDialog = true
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = FarmGreenDark),
                    modifier = Modifier.testTag("btn_autofill_claim_confirm")
                ) {
                    Icon(Icons.Default.AddModerator, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Auto-Fill & Review Claim")
                }
            },
            dismissButton = {
                TextButton(onClick = { showInsuranceClaimAlert = false }) {
                    Text("File Later")
                }
            }
        )
    }

    // Dialog: Auto-Filled Insurance Claim Form
    if (showAutoFillClaimDialog && pendingClaimPolicy != null && pendingMortalityEvent != null) {
        val pol = pendingClaimPolicy!!
        val mort = pendingMortalityEvent!!
        AutoFillClaimDialog(
            policy = pol,
            mortalityEvent = mort,
            onDismiss = { showAutoFillClaimDialog = false },
            onSubmit = { claim ->
                showAutoFillClaimDialog = false
                coroutineScope.launch {
                    val cRes = repository.insurance.submitClaim(claim)
                    if (cRes.isSuccess) {
                        Toast.makeText(context, "Insurance claim #${claim.claim_number ?: claim.id.take(6)} submitted successfully!", Toast.LENGTH_LONG).show()
                        loadData()
                    } else {
                        Toast.makeText(context, "Claim submission error: ${cRes.exceptionOrNull()?.message}", Toast.LENGTH_LONG).show()
                    }
                }
            }
        )
    }
}

@Composable
private fun MortalityKpiChip(
    title: String,
    value: String,
    icon: ImageVector,
    color: Color,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(8.dp),
        color = if (isSelected) color.copy(alpha = 0.15f) else Color(0xFFF1F5F9),
        border = if (isSelected) androidx.compose.foundation.BorderStroke(1.5.dp, color) else null,
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .clickable { onClick() }
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 6.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(14.dp))
            Text(
                text = value,
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
                color = color
            )
            Text(
                text = title,
                fontSize = 9.sp,
                color = Color.DarkGray,
                maxLines = 1
            )
        }
    }
}

@Composable
private fun MortalityRecordsList(
    records: List<MortalityEvent>,
    policies: List<InsurancePolicy>,
    onRecordMortality: () -> Unit,
    onNavigateToInsurance: () -> Unit
) {
    if (records.isEmpty()) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(Icons.Default.CheckCircle, contentDescription = null, tint = FarmSuccess, modifier = Modifier.size(40.dp))
                Text("No mortality records found", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = FarmGreenDark)
                Text("All livestock in this category are active and healthy.", fontSize = 12.sp, color = Color.Gray)
                Spacer(modifier = Modifier.height(8.dp))
                Button(
                    onClick = onRecordMortality,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFC62828))
                ) {
                    Icon(Icons.Default.Add, contentDescription = null)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Record Mortality")
                }
            }
        }
    } else {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 14.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(records) { record ->
                MortalityCardItem(
                    record = record,
                    policy = policies.find { it.goat_id == record.goat_id },
                    onNavigateToInsurance = onNavigateToInsurance
                )
            }
            item {
                Spacer(modifier = Modifier.height(72.dp))
            }
        }
    }
}

@Composable
private fun MortalityCardItem(
    record: MortalityEvent,
    policy: InsurancePolicy?,
    onNavigateToInsurance: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(12.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier.fillMaxWidth().testTag("mortality_card_${record.id}")
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            // Header Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .background(Color(0xFFFFEBEE), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.WarningAmber, contentDescription = null, tint = Color(0xFFC62828), modifier = Modifier.size(20.dp))
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "Goat: ${record.goat_tag}",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = Color(0xFFC62828)
                        )
                        Text(
                            text = "Date: ${record.death_date} • Type: ${record.event_type.replace("_", " ")}",
                            fontSize = 11.sp,
                            color = Color.Gray
                        )
                    }
                }

                Surface(
                    color = Color(0xFFFEE2E2),
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text(
                        text = record.cause_category,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFFB91C1C),
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            HorizontalDivider(color = Color(0xFFF1F5F9))

            // Reason & Symptoms
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(
                    text = "Immediate Cause: ${record.immediate_cause}",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = Color(0xFF1E293B)
                )
                if (!record.underlying_cause.isNullOrBlank()) {
                    Text("Underlying Cause: ${record.underlying_cause}", fontSize = 12.sp, color = Color.Gray)
                }
                if (record.age_at_death_days != null) {
                    Text("Age at death: ${record.age_at_death_days} days (${record.age_at_death_days / 30} months)", fontSize = 11.sp, color = Color.Gray)
                }
                if (!record.vet_doctor.isNullOrBlank()) {
                    Text("Attending Vet: ${record.vet_doctor}", fontSize = 11.sp, color = Color.DarkGray)
                }
                if (!record.notes.isNullOrBlank()) {
                    Text("Notes: ${record.notes}", fontSize = 11.sp, color = Color.DarkGray)
                }
            }

            // Post-mortem indicator
            if (record.post_mortem_performed) {
                Surface(
                    color = Color(0xFFE0F2FE),
                    shape = RoundedCornerShape(4.dp)
                ) {
                    Text(
                        text = "✓ Post-Mortem Performed",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF0369A1),
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }

            // INSURANCE LINK SECTION (Requirement 15)
            if (policy != null) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFEFF6FF)),
                    shape = RoundedCornerShape(8.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFBFDBFE)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "INSURANCE POLICY",
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp,
                                color = Color(0xFF1E3A8A)
                            )
                            Surface(
                                color = Color(0xFFFEF3C7),
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Text(
                                    text = "Claim Eligibility: REVIEW REQUIRED",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF92400E),
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }

                        Text("Company: ${policy.insurance_company}", fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                        Text("Policy Number: ${policy.policy_number ?: "Pending"}", fontSize = 11.sp, color = Color.DarkGray)
                        Text("Sum Insured: ${CurrencyUtils.formatInr(policy.sum_insured)}", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = FarmGreenDark)

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                            Button(
                                onClick = onNavigateToInsurance,
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E3A8A)),
                                shape = RoundedCornerShape(6.dp),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                                modifier = Modifier.height(28.dp)
                            ) {
                                Icon(Icons.Default.AddModerator, contentDescription = null, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("+ Create Insurance Claim", fontSize = 11.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun MortalityReasonsBreakdown(
    mortalities: List<MortalityEvent>,
    selectedReason: String?,
    onSelectReason: (String?) -> Unit
) {
    val reasonCategories = listOf(
        "DISEASE",
        "INFECTION",
        "PARASITE",
        "PNEUMONIA",
        "DIARRHEA",
        "WEAKNESS",
        "STARVATION",
        "BIRTH COMPLICATION",
        "STILLBIRTH",
        "INJURY",
        "PREDATOR",
        "POISONING",
        "UNKNOWN",
        "OTHER"
    )

    val grouped = remember(mortalities) {
        val map = mutableMapOf<String, MutableList<MortalityEvent>>()
        reasonCategories.forEach { map[it] = mutableListOf() }
        mortalities.forEach { m ->
            val matched = reasonCategories.find { it.equals(m.cause_category, ignoreCase = true) } ?: "OTHER"
            map.getOrPut(matched) { mutableListOf() }.add(m)
        }
        map
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Text("Mortality Breakdown by Cause Category", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Color(0xFFC62828))
            Text("Causes are logged by the farm manager and verified by attending vet. No automated disease diagnoses.", fontSize = 11.sp, color = Color.Gray)
        }

        items(reasonCategories) { cat ->
            val list = grouped[cat] ?: emptyList()
            val isExpanded = selectedReason == cat

            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(10.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onSelectReason(if (isExpanded) null else cat) }
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(28.dp)
                                    .background(if (list.isNotEmpty()) Color(0xFFFFEBEE) else Color(0xFFF1F5F9), CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "${list.size}",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp,
                                    color = if (list.isNotEmpty()) Color(0xFFC62828) else Color.Gray
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(cat, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }

                        Icon(
                            if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                            contentDescription = null,
                            tint = Color.Gray
                        )
                    }

                    if (isExpanded && list.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(8.dp))
                        HorizontalDivider(color = Color(0xFFF1F5F9))
                        list.forEach { item ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Goat: ${item.goat_tag} (${item.immediate_cause})", fontSize = 11.sp, color = Color.DarkGray)
                                Text(item.death_date, fontSize = 11.sp, color = Color.Gray)
                            }
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(72.dp))
        }
    }
}

@Composable
private fun MortalityStatisticsView(
    summary: FarmMortalitySummary?,
    mortalities: List<MortalityEvent>,
    goats: List<Goat>
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("Mortality Statistics & Analytics", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Color(0xFFC62828))
        }

        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Herd Demographics & Survival Rates", fontWeight = FontWeight.Bold, fontSize = 13.sp)

                    val herdSize = goats.size.coerceAtLeast(1)
                    val adultCount = goats.count { !it.tag_c.contains("K", ignoreCase = true) }
                    val kidCount = goats.size - adultCount

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Active Herd Count:", fontSize = 12.sp)
                        Text("${goats.size} goats", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Adult Mortality Count:", fontSize = 12.sp)
                        Text("${mortalities.count { it.event_type.contains("ADULT") }}", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Kid Mortality Count:", fontSize = 12.sp)
                        Text("${mortalities.count { it.event_type.contains("KID") }}", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Overall Mortality Rate:", fontSize = 12.sp)
                        Text("${String.format(Locale.US, "%.1f", (mortalities.size.toDouble() / herdSize.toDouble()) * 100.0)}%", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color(0xFFC62828))
                    }
                }
            }
        }

        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Mortality Breakdown by Month", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    val byMonth = mortalities.groupBy { it.death_date.take(7) }
                    if (byMonth.isEmpty()) {
                        Text("No monthly data recorded yet.", fontSize = 11.sp, color = Color.Gray)
                    } else {
                        byMonth.forEach { (month, list) ->
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(month, fontSize = 12.sp)
                                Text("${list.size} deaths", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color(0xFFC62828))
                            }
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(72.dp))
        }
    }
}

@Composable
private fun MortalityCostView(
    mortalities: List<MortalityEvent>,
    goats: List<Goat>
) {
    val estimatedLossPerAdult = 12000.0
    val estimatedLossPerKid = 3500.0

    val adultCount = mortalities.count { !it.event_type.equals("KID_DEATH", ignoreCase = true) }
    val kidCount = mortalities.count { it.event_type.equals("KID_DEATH", ignoreCase = true) }
    val totalEstimatedFinancialLoss = (adultCount * estimatedLossPerAdult) + (kidCount * estimatedLossPerKid)

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("Mortality Financial Impact & Cost", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Color(0xFFC62828))
            Text("Estimates economic impact of animal loss to livestock asset equity and working capital.", fontSize = 11.sp, color = Color.Gray)
        }

        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF1F2)),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("ESTIMATED LIVESTOCK CAPITAL LOSS", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFFBE123C))
                    Text(
                        text = CurrencyUtils.formatInr(totalEstimatedFinancialLoss),
                        fontWeight = FontWeight.Bold,
                        fontSize = 24.sp,
                        color = Color(0xFF9F1239)
                    )
                    Text("Based on standard asset replacement valuation (Adult: ₹12,000, Kid: ₹3,500)", fontSize = 10.sp, color = Color.Gray)
                }
            }
        }

        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Loss Breakdown", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Adult Does & Bucks ($adultCount heads):", fontSize = 12.sp)
                        Text(CurrencyUtils.formatInr(adultCount * estimatedLossPerAdult), fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Kids & Young Stock ($kidCount heads):", fontSize = 12.sp)
                        Text(CurrencyUtils.formatInr(kidCount * estimatedLossPerKid), fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                    HorizontalDivider(color = Color(0xFFF1F5F9))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Total Estimated Cost:", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Text(CurrencyUtils.formatInr(totalEstimatedFinancialLoss), fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color(0xFFBE123C))
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(72.dp))
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun RecordMortalityDialog(
    goats: List<Goat>,
    policies: List<InsurancePolicy>,
    prefilledGoatId: String? = null,
    prefilledDate: String? = null,
    relatedEvent: String? = null,
    onDismiss: () -> Unit,
    onSave: (MortalityEvent) -> Unit,
    onNavigateToInsurance: () -> Unit
) {
    var selectedGoatId by remember { mutableStateOf(prefilledGoatId ?: goats.firstOrNull()?.id ?: "") }
    var goatExpanded by remember { mutableStateOf(false) }

    var deathDate by remember { mutableStateOf(prefilledDate ?: SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())) }
    var deathType by remember { mutableStateOf(if (relatedEvent.equals("Abortion", ignoreCase = true)) "DOE_POST_DELIVERY_DEATH" else "ADULT_DEATH") }
    var deathTypeExpanded by remember { mutableStateOf(false) }

    val reasonCategories = listOf(
        "DISEASE",
        "INFECTION",
        "PARASITE",
        "PNEUMONIA",
        "DIARRHEA",
        "WEAKNESS",
        "STARVATION",
        "BIRTH COMPLICATION",
        "STILLBIRTH",
        "INJURY",
        "PREDATOR",
        "POISONING",
        "UNKNOWN",
        "OTHER"
    )
    var selectedCategory by remember { mutableStateOf(if (relatedEvent.equals("Abortion", ignoreCase = true)) "BIRTH COMPLICATION" else "DISEASE") }
    var categoryExpanded by remember { mutableStateOf(false) }

    var immediateCause by remember { mutableStateOf(if (relatedEvent.equals("Abortion", ignoreCase = true)) "Complications following abortion" else "") }
    var secondaryReason by remember { mutableStateOf("") }
    var symptoms by remember { mutableStateOf("") }
    var vetTreatment by remember { mutableStateOf("") }
    var vetDoctor by remember { mutableStateOf("") }
    var postMortemPerformed by remember { mutableStateOf(false) }
    var notes by remember { mutableStateOf(if (relatedEvent != null) "Related Event: $relatedEvent" else "") }

    val selectedGoat = goats.find { it.id == selectedGoatId }
    val activePolicy = policies.find { it.goat_id == selectedGoatId && (it.status.equals("Active", ignoreCase = true) || it.status.equals("Expiring Soon", ignoreCase = true)) }

    Dialog(onDismissRequest = onDismiss) {
        Surface(shape = RoundedCornerShape(16.dp), color = Color.White, modifier = Modifier.fillMaxWidth()) {
            LazyColumn(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                item {
                    Text("Record Livestock Mortality", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = Color(0xFFC62828))
                    Text("Records irreversible loss. Updates goat status to Deceased. Historical logs preserved.", fontSize = 11.sp, color = Color.Gray)
                }

                item {
                    ExposedDropdownMenuBox(expanded = goatExpanded, onExpandedChange = { goatExpanded = !goatExpanded }) {
                        OutlinedTextField(
                            value = "${selectedGoat?.tag_c ?: "Select"} - ${selectedGoat?.name ?: ""}",
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Select Goat / Kid *") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = goatExpanded) },
                            modifier = Modifier.fillMaxWidth().menuAnchor().testTag("select_mortality_goat")
                        )
                        ExposedDropdownMenu(expanded = goatExpanded, onDismissRequest = { goatExpanded = false }) {
                            goats.filter { !it.status_c.equals("Deceased", ignoreCase = true) }.forEach { g ->
                                DropdownMenuItem(
                                    text = { Text("${g.tag_c} - ${g.name} (${g.sex_c}, ${g.breed_c})") },
                                    onClick = { selectedGoatId = g.id; goatExpanded = false }
                                )
                            }
                        }
                    }
                }

                item {
                    DatePickerField(dateValue = deathDate, onDateSelected = { deathDate = it }, label = "Date of Death *")
                }

                item {
                    ExposedDropdownMenuBox(expanded = deathTypeExpanded, onExpandedChange = { deathTypeExpanded = !deathTypeExpanded }) {
                        OutlinedTextField(
                            value = deathType.replace("_", " "),
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Death Type *") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = deathTypeExpanded) },
                            modifier = Modifier.fillMaxWidth().menuAnchor()
                        )
                        ExposedDropdownMenu(expanded = deathTypeExpanded, onDismissRequest = { deathTypeExpanded = false }) {
                            listOf("ADULT_DEATH", "KID_DEATH", "DOE_POST_DELIVERY_DEATH", "STILLBIRTH", "OTHER").forEach { dt ->
                                DropdownMenuItem(
                                    text = { Text(dt.replace("_", " ")) },
                                    onClick = { deathType = dt; deathTypeExpanded = false }
                                )
                            }
                        }
                    }
                }

                item {
                    ExposedDropdownMenuBox(expanded = categoryExpanded, onExpandedChange = { categoryExpanded = !categoryExpanded }) {
                        OutlinedTextField(
                            value = selectedCategory,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Primary Reason Category *") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = categoryExpanded) },
                            modifier = Modifier.fillMaxWidth().menuAnchor().testTag("select_mortality_reason")
                        )
                        ExposedDropdownMenu(expanded = categoryExpanded, onDismissRequest = { categoryExpanded = false }) {
                            reasonCategories.forEach { cat ->
                                DropdownMenuItem(
                                    text = { Text(cat) },
                                    onClick = { selectedCategory = cat; categoryExpanded = false }
                                )
                            }
                        }
                    }
                }

                item {
                    OutlinedTextField(
                        value = immediateCause,
                        onValueChange = { immediateCause = it },
                        label = { Text("Primary Reason / Immediate Cause *") },
                        placeholder = { Text("e.g. Severe Enterotoxemia / Pneumonia") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("input_immediate_cause")
                    )
                }

                item {
                    OutlinedTextField(
                        value = secondaryReason,
                        onValueChange = { secondaryReason = it },
                        label = { Text("Secondary Reason") },
                        placeholder = { Text("e.g. Acidosis, sudden weather change") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                item {
                    OutlinedTextField(
                        value = symptoms,
                        onValueChange = { symptoms = it },
                        label = { Text("Observed Symptoms") },
                        placeholder = { Text("e.g. High fever, labored breathing, loss of appetite") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                item {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = vetDoctor,
                            onValueChange = { vetDoctor = it },
                            label = { Text("Veterinarian") },
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = vetTreatment,
                            onValueChange = { vetTreatment = it },
                            label = { Text("Treatment Given") },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Post-Mortem Performed?", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                        Switch(
                            checked = postMortemPerformed,
                            onCheckedChange = { postMortemPerformed = it }
                        )
                    }
                }

                // INSURANCE POLICY SECTION (Requirement 15)
                if (activePolicy != null) {
                    item {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color(0xFFEFF6FF)),
                            shape = RoundedCornerShape(8.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFBFDBFE)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                Text("INSURANCE POLICY DETECTED", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = Color(0xFF1E3A8A))
                                Text("Company: ${activePolicy.insurance_company}", fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                                Text("Policy Number: ${activePolicy.policy_number ?: "Pending"}", fontSize = 11.sp)
                                Text("Sum Insured: ${CurrencyUtils.formatInr(activePolicy.sum_insured)}", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = FarmGreenDark)
                                Surface(
                                    color = Color(0xFFFEF3C7),
                                    shape = RoundedCornerShape(4.dp),
                                    modifier = Modifier.padding(vertical = 2.dp)
                                ) {
                                    Text(
                                        text = "Claim Eligibility: REVIEW REQUIRED",
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF92400E),
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                                Text("A claim can be submitted under Insurance Management.", fontSize = 10.sp, color = Color.Gray)
                                Button(
                                    onClick = {
                                        onDismiss()
                                        onNavigateToInsurance()
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E3A8A)),
                                    shape = RoundedCornerShape(6.dp),
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                                    modifier = Modifier.fillMaxWidth().height(32.dp).padding(top = 4.dp)
                                ) {
                                    Icon(Icons.Default.AddModerator, contentDescription = null, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("+ Create Insurance Claim", fontSize = 11.sp)
                                }
                            }
                        }
                    }
                }

                item {
                    OutlinedTextField(
                        value = notes,
                        onValueChange = { notes = it },
                        label = { Text("Notes / Post-Mortem Findings") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                item {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                        TextButton(onClick = onDismiss) { Text("Cancel") }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = {
                                val goat = selectedGoat ?: return@Button
                                val event = MortalityEvent(
                                    goat_id = goat.id,
                                    goat_tag = goat.tag_c,
                                    event_type = deathType,
                                    death_date = deathDate,
                                    immediate_cause = immediateCause.ifBlank { "Unspecified cause" },
                                    underlying_cause = secondaryReason.ifBlank { null },
                                    cause_category = selectedCategory,
                                    vet_doctor = vetDoctor.ifBlank { null },
                                    post_mortem_performed = postMortemPerformed,
                                    insurance_policy_id = activePolicy?.id,
                                    notes = buildString {
                                        if (symptoms.isNotBlank()) append("Symptoms: $symptoms. ")
                                        if (vetTreatment.isNotBlank()) append("Treatment: $vetTreatment. ")
                                        if (notes.isNotBlank()) append(notes)
                                    }.ifBlank { null }
                                )
                                onSave(event)
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFC62828)),
                            modifier = Modifier.testTag("btn_confirm_mortality")
                        ) {
                            Text("Confirm & Record Mortality")
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AutoFillClaimDialog(
    policy: InsurancePolicy,
    mortalityEvent: MortalityEvent,
    onDismiss: () -> Unit,
    onSubmit: (InsuranceClaim) -> Unit
) {
    var incidentDate by remember { mutableStateOf(mortalityEvent.death_date) }
    var cause by remember { mutableStateOf(mortalityEvent.immediate_cause) }
    var description by remember {
        mutableStateOf(
            mortalityEvent.notes ?: "Mortality recorded on ${mortalityEvent.death_date}. Cause: ${mortalityEvent.immediate_cause}. Vet: ${mortalityEvent.vet_doctor ?: "Not specified"}."
        )
    }
    var vetDoctor by remember { mutableStateOf(mortalityEvent.vet_doctor ?: "") }
    var claimAmountStr by remember { mutableStateOf("${policy.sum_insured.toInt()}") }
    var claimNumber by remember { mutableStateOf("CLM-${UUID.randomUUID().toString().take(6).uppercase()}") }
    var claimStatus by remember { mutableStateOf("SUBMITTED") }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = Color.White,
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.88f)
        ) {
            LazyColumn(
                modifier = Modifier.padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item {
                    Text(
                        text = "Auto-Filled Insurance Claim",
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,
                        color = Color(0xFFC2410C)
                    )
                    Text(
                        text = "Claim details pre-populated from mortality event. Review and submit to official insurance registry.",
                        fontSize = 11.5.sp,
                        color = Color.Gray
                    )
                }

                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFF8FAFC)),
                        shape = RoundedCornerShape(10.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text("Policy: ${policy.policy_name}", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            Text("Company: ${policy.insurance_company} • #${policy.policy_number ?: "POL"}", fontSize = 11.5.sp, color = Color.DarkGray)
                            Text("Animal Tag: ${mortalityEvent.goat_tag}", fontWeight = FontWeight.SemiBold, fontSize = 12.sp, color = FarmGreenDark)
                            Text("Sum Insured: ${CurrencyUtils.formatInr(policy.sum_insured)}", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = FarmGreenDark)
                        }
                    }
                }

                item {
                    OutlinedTextField(
                        value = claimNumber,
                        onValueChange = { claimNumber = it },
                        label = { Text("Claim Number *") },
                        modifier = Modifier.fillMaxWidth().testTag("input_claim_number_autofill")
                    )
                }

                item {
                    DatePickerField(
                        dateValue = incidentDate,
                        onDateSelected = { incidentDate = it },
                        label = "Incident / Death Date *"
                    )
                }

                item {
                    OutlinedTextField(
                        value = cause,
                        onValueChange = { cause = it },
                        label = { Text("Cause of Death *") },
                        modifier = Modifier.fillMaxWidth().testTag("input_claim_cause_autofill")
                    )
                }

                item {
                    OutlinedTextField(
                        value = claimAmountStr,
                        onValueChange = { claimAmountStr = it },
                        label = { Text("Claim Amount (₹) *") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth().testTag("input_claim_amount_autofill")
                    )
                }

                item {
                    OutlinedTextField(
                        value = vetDoctor,
                        onValueChange = { vetDoctor = it },
                        label = { Text("Attending Veterinarian") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                item {
                    OutlinedTextField(
                        value = description,
                        onValueChange = { description = it },
                        label = { Text("Incident Description / Post-Mortem Notes") },
                        modifier = Modifier.fillMaxWidth(),
                        minLines = 3
                    )
                }

                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        TextButton(onClick = onDismiss) { Text("Cancel") }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = {
                                val amt = claimAmountStr.toDoubleOrNull() ?: policy.sum_insured
                                val claim = InsuranceClaim(
                                    policy_id = policy.id,
                                    goat_id = policy.goat_id,
                                    goat_tag = policy.goat_tag,
                                    mortality_event_id = mortalityEvent.id,
                                    incident_date = incidentDate,
                                    incident_type = "Death",
                                    cause = cause.ifBlank { "Death" },
                                    description = description.ifBlank { null },
                                    vet_doctor = vetDoctor.ifBlank { null },
                                    claim_amount = amt,
                                    claim_number = claimNumber.ifBlank { null },
                                    status = claimStatus
                                )
                                onSubmit(claim)
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = FarmGreenDark),
                            modifier = Modifier.testTag("btn_submit_autofilled_claim")
                        ) {
                            Icon(Icons.AutoMirrored.Filled.Send, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Submit Official Claim")
                        }
                    }
                }
            }
        }
    }
}
