package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.supabase.*
import com.example.i18n.t
import com.example.ui.components.BatchHealthCheckDialog
import com.example.ui.components.BatchTreatmentDialog
import com.example.ui.components.FarmBottomNavigation
import com.example.ui.components.FarmTopBar
import com.example.ui.components.GoatListComponent
import com.example.ui.components.NewGoatEntryDialog
import com.example.ui.components.OriginBadge
import com.example.ui.components.PedigreeDetailSection
import com.example.ui.components.TagBadge
import com.example.ui.components.camera.GoatAvatar
import com.example.ui.theme.*
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GoatListScreen(
    repository: GoatRepository,
    onNavigateBack: () -> Unit,
    onNavigateToAddGoat: () -> Unit,
    onNavigateToRecordWeight: (String) -> Unit,
    onNavigateToVaccination: (String) -> Unit,
    onNavigateToDeworming: (String) -> Unit,
    onNavigateToProfile: (String) -> Unit = {},
    onNavigateToDashboard: () -> Unit = {},
    onNavigateToSales: () -> Unit = {},
    onNavigateToTasks: () -> Unit = {},
    onNavigateToAiEntry: () -> Unit = {},
    onNavigateToBreeding: () -> Unit = {},
    onNavigateToPopulationDashboard: () -> Unit = {}
) {
    var goats by remember { mutableStateOf<List<Goat>>(emptyList()) }
    var searchQuery by remember { mutableStateOf("") }
    var selectedFilter by remember { mutableStateOf("all") } // all, does, bucks, kids, pregnant
    var isLoading by remember { mutableStateOf(true) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var selectedGoatForDetail by remember { mutableStateOf<Goat?>(null) }
    var showQuickEntryDialog by remember { mutableStateOf(false) }
    var viewMode by remember { mutableStateOf("room_live") } // room_live or cards

    // Selection Mode State for Herd List
    var isSelectionMode by remember { mutableStateOf(false) }
    var selectedGoatIds by remember { mutableStateOf(setOf<String>()) }
    var showBatchHealthDialog by remember { mutableStateOf(false) }
    var showBatchTreatmentDialog by remember { mutableStateOf(false) }

    val coroutineScope = rememberCoroutineScope()

    fun loadGoats() {
        isLoading = true
        errorMessage = null
        coroutineScope.launch {
            val res = repository.getGoats()
            isLoading = false
            if (res.isSuccess) {
                goats = res.getOrThrow()
            } else {
                errorMessage = res.exceptionOrNull()?.message ?: "Failed to load goats"
            }
        }
    }

    LaunchedEffect(Unit) {
        loadGoats()
    }

    val filteredGoats = remember(goats, searchQuery, selectedFilter) {
        goats.filter { goat ->
            val matchesSearch = searchQuery.isBlank() ||
                goat.tag_c.contains(searchQuery, ignoreCase = true) ||
                goat.name.contains(searchQuery, ignoreCase = true) ||
                goat.breed_c.contains(searchQuery, ignoreCase = true)

            val matchesFilter = when (selectedFilter) {
                "does" -> goat.sex_c.equals("Doe", ignoreCase = true)
                "bucks" -> goat.sex_c.equals("Buck", ignoreCase = true)
                "kids" -> goat.sex_c.equals("Kid", ignoreCase = true) || goat.status_c.equals("Kid", ignoreCase = true)
                "pregnant" -> goat.status_c.equals("Pregnant", ignoreCase = true)
                else -> true
            }

            matchesSearch && matchesFilter
        }
    }

    Scaffold(
        topBar = {
            FarmTopBar(
                title = if (isSelectionMode) "${selectedGoatIds.size} Selected" else "${t("nav.herd")} (${goats.size})",
                canNavigateBack = true,
                onNavigateBack = {
                    if (isSelectionMode) {
                        isSelectionMode = false
                        selectedGoatIds = emptySet()
                    } else {
                        onNavigateBack()
                    }
                },
                syncManager = repository.syncManager,
                actions = {
                    if (isSelectionMode) {
                        IconButton(
                            onClick = { selectedGoatIds = filteredGoats.map { it.id }.toSet() },
                            modifier = Modifier.testTag("topbar_select_all_btn")
                        ) {
                            Icon(Icons.Default.SelectAll, contentDescription = "Select All", tint = Color.White)
                        }
                        IconButton(
                            onClick = { selectedGoatIds = emptySet() },
                            modifier = Modifier.testTag("topbar_deselect_all_btn")
                        ) {
                            Icon(Icons.Default.Deselect, contentDescription = "Deselect All", tint = Color.White)
                        }
                        IconButton(
                            onClick = {
                                isSelectionMode = false
                                selectedGoatIds = emptySet()
                            },
                            modifier = Modifier.testTag("topbar_exit_selection_btn")
                        ) {
                            Icon(Icons.Default.Close, contentDescription = "Cancel Selection", tint = Color.White)
                        }
                    } else {
                        IconButton(
                            onClick = { isSelectionMode = true },
                            modifier = Modifier.testTag("topbar_selection_mode_btn")
                        ) {
                            Icon(Icons.Default.Checklist, contentDescription = "Selection Mode", tint = Color.White)
                        }
                        IconButton(
                            onClick = onNavigateToPopulationDashboard,
                            modifier = Modifier.testTag("population_analytics_btn")
                        ) {
                            Icon(Icons.Default.BarChart, contentDescription = "Population Demographics", tint = Color.White)
                        }
                        IconButton(
                            onClick = { viewMode = if (viewMode == "room_live") "cards" else "room_live" },
                            modifier = Modifier.testTag("toggle_goat_view_btn")
                        ) {
                            Icon(
                                imageVector = if (viewMode == "room_live") Icons.Default.ViewAgenda else Icons.Default.TableRows,
                                contentDescription = "Switch View Mode",
                                tint = Color.White
                            )
                        }
                        IconButton(
                            onClick = { showQuickEntryDialog = true },
                            modifier = Modifier.testTag("quick_entry_goat_btn")
                        ) {
                            Icon(Icons.Default.FlashOn, contentDescription = "Quick Entry", tint = Color.White)
                        }
                        IconButton(
                            onClick = { loadGoats() },
                            modifier = Modifier.testTag("refresh_goats_btn")
                        ) {
                            Icon(Icons.Default.Refresh, contentDescription = t("topbar.refresh"), tint = Color.White)
                        }
                    }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = onNavigateToAddGoat,
                containerColor = FarmGreenDark,
                contentColor = Color.White,
                modifier = Modifier.testTag("fab_add_goat")
            ) {
                Icon(Icons.Default.Add, contentDescription = t("dashboard.add_goat"))
            }
        },
        bottomBar = {
            FarmBottomNavigation(
                currentRoute = "goats",
                onNavigateToDashboard = onNavigateToDashboard,
                onNavigateToGoats = {},
                onNavigateToBreeding = onNavigateToBreeding,
                onNavigateToSales = onNavigateToSales,
                onNavigateToTasks = onNavigateToTasks,
                onNavigateToAiEntry = onNavigateToAiEntry
            )
        }
    ) { padding ->
        if (viewMode == "room_live") {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(FarmBackgroundLight)
                    .padding(padding)
                    .padding(12.dp)
            ) {
                GoatListComponent(
                    repository = repository,
                    modifier = Modifier.fillMaxSize(),
                    onGoatClick = { onNavigateToProfile(it.id) },
                    onRecordWeight = { onNavigateToRecordWeight(it.id) },
                    onViewProfile = { onNavigateToProfile(it.id) },
                    onAddNewGoat = { showQuickEntryDialog = true },
                    isSelectionMode = isSelectionMode,
                    selectedGoatIds = selectedGoatIds,
                    onToggleSelectGoat = { goat ->
                        selectedGoatIds = if (selectedGoatIds.contains(goat.id)) selectedGoatIds - goat.id else selectedGoatIds + goat.id
                    },
                    onEnterSelectionMode = { isSelectionMode = true },
                    onExitSelectionMode = {
                        isSelectionMode = false
                        selectedGoatIds = emptySet()
                    },
                    onSelectAll = { list -> selectedGoatIds = list.map { it.id }.toSet() },
                    onDeselectAll = { selectedGoatIds = emptySet() },
                    onBatchHealthCheck = { showBatchHealthDialog = true },
                    onBatchTreatment = { showBatchTreatmentDialog = true }
                )
            }
        } else {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .background(FarmBackgroundLight)
                    .padding(padding)
            ) {
            // Search Bar
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text(t("herd.search_placeholder")) },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { searchQuery = "" }) {
                            Icon(Icons.Default.Close, contentDescription = t("btn.clear"))
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = Color.White,
                    unfocusedContainerColor = Color.White
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
                    .testTag("goat_search_input")
            )

            // Filter Chips
            val filters = listOf(
                "all" to t("herd.filter_all"),
                "does" to t("herd.filter_does"),
                "bucks" to t("herd.filter_bucks"),
                "kids" to t("herd.filter_kids"),
                "pregnant" to t("herd.filter_pregnant")
            )
            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.padding(bottom = 8.dp)
            ) {
                items(filters) { (key, label) ->
                    FilterChip(
                        selected = selectedFilter == key,
                        onClick = { selectedFilter = key },
                        label = { Text(label) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = FarmGreenPrimary,
                            selectedLabelColor = Color.White
                        ),
                        modifier = Modifier.testTag("filter_chip_$key")
                    )
                }
            }

            if (isLoading) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator(color = FarmGreenPrimary)
                }
            } else if (errorMessage != null) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = FarmErrorContainer),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(t("state.error"), fontWeight = FontWeight.Bold, color = FarmError)
                        Text(errorMessage ?: "", color = FarmError)
                        Spacer(modifier = Modifier.height(8.dp))
                        Button(
                            onClick = { loadGoats() },
                            colors = ButtonDefaults.buttonColors(containerColor = FarmError)
                        ) {
                            Text(t("btn.refresh"))
                        }
                    }
                }
            } else if (filteredGoats.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.Pets,
                            contentDescription = null,
                            modifier = Modifier.size(56.dp),
                            tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = if (searchQuery.isNotEmpty()) "${t("herd.empty_message")} \"$searchQuery\"" else t("herd.empty_message"),
                            style = MaterialTheme.typography.bodyLarge,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Button(
                            onClick = onNavigateToAddGoat,
                            colors = ButtonDefaults.buttonColors(containerColor = FarmGreenPrimary)
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(t("herd.add_first_goat"))
                        }
                    }
                }
            } else {
                if (isSelectionMode) {
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = Color(0xFFF1F8E9),
                        border = androidx.compose.foundation.BorderStroke(1.dp, FarmGreenPrimary.copy(alpha = 0.5f)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 4.dp)
                            .testTag("cards_selection_banner")
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 10.dp, vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "${selectedGoatIds.size} of ${filteredGoats.size} selected",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = FarmGreenDark
                            )
                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                TextButton(
                                    onClick = { selectedGoatIds = filteredGoats.map { it.id }.toSet() },
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                    modifier = Modifier.testTag("btn_cards_select_all")
                                ) {
                                    Text("Select All", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                                TextButton(
                                    onClick = { selectedGoatIds = emptySet() },
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                    modifier = Modifier.testTag("btn_cards_clear_selection")
                                ) {
                                    Text("Clear", fontSize = 11.sp, color = Color.Gray)
                                }
                            }
                        }
                    }
                }

                LazyColumn(
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = if (selectedGoatIds.isNotEmpty()) 120.dp else 80.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(filteredGoats, key = { it.id }) { goat ->
                        val isSelected = selectedGoatIds.contains(goat.id)
                        GoatCard(
                            goat = goat,
                            isSelectionMode = isSelectionMode,
                            isSelected = isSelected,
                            onToggleSelect = {
                                selectedGoatIds = if (selectedGoatIds.contains(goat.id)) {
                                    selectedGoatIds - goat.id
                                } else {
                                    selectedGoatIds + goat.id
                                }
                            },
                            onClick = {
                                if (isSelectionMode) {
                                    selectedGoatIds = if (selectedGoatIds.contains(goat.id)) {
                                        selectedGoatIds - goat.id
                                    } else {
                                        selectedGoatIds + goat.id
                                    }
                                } else {
                                    onNavigateToProfile(goat.id)
                                }
                            },
                            onRecordWeight = { onNavigateToRecordWeight(goat.id) },
                            onVaccinate = { onNavigateToVaccination(goat.id) },
                            onDeworm = { onNavigateToDeworming(goat.id) }
                        )
                    }
                }

                if (selectedGoatIds.isNotEmpty()) {
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = Color(0xFFF1F8E9),
                        border = androidx.compose.foundation.BorderStroke(1.5.dp, FarmGreenPrimary),
                        shadowElevation = 6.dp,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 8.dp)
                            .testTag("batch_action_bar")
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "${selectedGoatIds.size} Selected",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp,
                                    color = FarmGreenDark
                                )
                                Text(
                                    text = "Apply batch update",
                                    fontSize = 10.sp,
                                    color = Color.Gray
                                )
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(
                                    onClick = { showBatchHealthDialog = true },
                                    colors = ButtonDefaults.buttonColors(containerColor = FarmGreenPrimary),
                                    shape = RoundedCornerShape(8.dp),
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                                    modifier = Modifier.testTag("btn_batch_health_check")
                                ) {
                                    Icon(Icons.Default.HealthAndSafety, contentDescription = null, modifier = Modifier.size(15.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Health Check", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }

                                Button(
                                    onClick = { showBatchTreatmentDialog = true },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1565C0)),
                                    shape = RoundedCornerShape(8.dp),
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                                    modifier = Modifier.testTag("btn_batch_treatment")
                                ) {
                                    Icon(Icons.Default.Medication, contentDescription = null, modifier = Modifier.size(15.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Treatment", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

    // Detail Dialog
    selectedGoatForDetail?.let { goat ->
        GoatDetailDialog(
            goat = goat,
            allGoats = goats,
            repository = repository,
            onDismiss = { selectedGoatForDetail = null },
            onOpenProfile = {
                selectedGoatForDetail = null
                onNavigateToProfile(goat.id)
            },
            onSelectGoat = { targetGoat ->
                selectedGoatForDetail = null
                onNavigateToProfile(targetGoat.id)
            },
            onRecordWeight = {
                selectedGoatForDetail = null
                onNavigateToRecordWeight(goat.id)
            },
            onVaccinate = {
                selectedGoatForDetail = null
                onNavigateToVaccination(goat.id)
            },
            onDeworm = {
                selectedGoatForDetail = null
                onNavigateToDeworming(goat.id)
            }
        )
    }

    // Batch Health Check Dialog
    if (showBatchHealthDialog) {
        val selected = goats.filter { selectedGoatIds.contains(it.id) }
        if (selected.isNotEmpty()) {
            BatchHealthCheckDialog(
                selectedGoats = selected,
                repository = repository,
                onDismiss = { showBatchHealthDialog = false },
                onSuccess = {
                    showBatchHealthDialog = false
                    isSelectionMode = false
                    selectedGoatIds = emptySet()
                    loadGoats()
                }
            )
        }
    }

    // Batch Treatment Dialog
    if (showBatchTreatmentDialog) {
        val selected = goats.filter { selectedGoatIds.contains(it.id) }
        if (selected.isNotEmpty()) {
            BatchTreatmentDialog(
                selectedGoats = selected,
                repository = repository,
                onDismiss = { showBatchTreatmentDialog = false },
                onSuccess = {
                    showBatchTreatmentDialog = false
                    isSelectionMode = false
                    selectedGoatIds = emptySet()
                    loadGoats()
                }
            )
        }
    }

    // Quick New Goat Entry Dialog
    if (showQuickEntryDialog) {
        NewGoatEntryDialog(
            repository = repository,
            onGoatSaved = {
                showQuickEntryDialog = false
                loadGoats()
            },
            onDismiss = { showQuickEntryDialog = false }
        )
    }
}

@Composable
fun GoatCard(
    goat: Goat,
    onClick: () -> Unit,
    onRecordWeight: () -> Unit,
    onVaccinate: () -> Unit,
    onDeworm: () -> Unit,
    isSelectionMode: Boolean = false,
    isSelected: Boolean = false,
    onToggleSelect: () -> Unit = {}
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { if (isSelectionMode) onToggleSelect() else onClick() }
            .testTag("goat_card_${goat.tag_c}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = if (isSelected) Color(0xFFF1F8E9) else Color.White),
        border = if (isSelected) androidx.compose.foundation.BorderStroke(2.dp, FarmGreenPrimary) else null,
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (isSelectionMode) {
                        Checkbox(
                            checked = isSelected,
                            onCheckedChange = { onToggleSelect() },
                            colors = CheckboxDefaults.colors(checkedColor = FarmGreenDark),
                            modifier = Modifier
                                .size(24.dp)
                                .padding(end = 4.dp)
                                .testTag("checkbox_select_${goat.tag_c}")
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                    }
                    GoatAvatar(
                        photoUrl = goat.photo_url_c,
                        tag = goat.tag_c,
                        isBuck = goat.sex_c.equals("Buck", ignoreCase = true),
                        size = 38.dp,
                        modifier = Modifier.padding(end = 10.dp)
                    )
                    TagBadge(
                        tag = goat.tag_c,
                        isBuck = goat.sex_c.equals("Buck", ignoreCase = true),
                        isKid = goat.sex_c.equals("Kid", ignoreCase = true)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = goat.name,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OriginBadge(origin = goat.effectiveOrigin)
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = when (goat.status_c.lowercase()) {
                            "pregnant" -> Color(0xFFF3E5F5)
                            "lactating" -> Color(0xFFE8F5E9)
                            "quarantine" -> FarmErrorContainer
                            "sold", "deceased" -> Color(0xFFEEEEEE)
                            else -> FarmGreenContainer
                        }
                    ) {
                        Text(
                            text = goat.status_c,
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = when (goat.status_c.lowercase()) {
                                "pregnant" -> Color(0xFF7B1FA2)
                                "lactating" -> FarmGreenDark
                                "quarantine" -> FarmError
                                "sold", "deceased" -> Color(0xFF616161)
                                else -> FarmGreenDark
                            },
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text(
                    text = "${t("herd.breed")}: ${goat.breed_c}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = "${t("herd.sex")}: ${goat.sex_c}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = "${t("herd.weight")}: ${if (goat.weight_kg_c != null) "${goat.weight_kg_c} kg" else "--"}",
                    style = MaterialTheme.typography.bodySmall,
                    fontWeight = FontWeight.Bold,
                    color = FarmGreenDark
                )
            }

            if (!goat.farm_location_c.isNullOrBlank()) {
                Text(
                    text = "Location: ${goat.farm_location_c}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 2.dp)
                )
            }

            Spacer(modifier = Modifier.height(10.dp))
            HorizontalDivider(color = Color(0xFFF0F0F0))
            Spacer(modifier = Modifier.height(8.dp))

            // Quick field action buttons on card
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = onRecordWeight,
                    modifier = Modifier.weight(1f).height(36.dp),
                    contentPadding = PaddingValues(0.dp),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(Icons.Default.Scale, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(t("herd.weight"), fontSize = 12.sp)
                }

                OutlinedButton(
                    onClick = onVaccinate,
                    modifier = Modifier.weight(1f).height(36.dp),
                    contentPadding = PaddingValues(0.dp),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(Icons.Default.Vaccines, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(t("dashboard.vaccinate"), fontSize = 12.sp)
                }

                OutlinedButton(
                    onClick = onDeworm,
                    modifier = Modifier.weight(1f).height(36.dp),
                    contentPadding = PaddingValues(0.dp),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(Icons.Default.Healing, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(t("dashboard.deworm"), fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
fun GoatDetailDialog(
    goat: Goat,
    allGoats: List<Goat>,
    repository: GoatRepository,
    onDismiss: () -> Unit,
    onOpenProfile: () -> Unit = {},
    onSelectGoat: (Goat) -> Unit = {},
    onRecordWeight: () -> Unit,
    onVaccinate: () -> Unit,
    onDeworm: () -> Unit
) {
    var weights by remember { mutableStateOf<List<GoatWeight>>(emptyList()) }
    var vacs by remember { mutableStateOf<List<VaccinationRecord>>(emptyList()) }
    var deworms by remember { mutableStateOf<List<DewormingRecord>>(emptyList()) }
    var treatments by remember { mutableStateOf<List<TreatmentRecord>>(emptyList()) }
    var selectedTab by remember { mutableIntStateOf(0) }
    var loadingHistory by remember { mutableStateOf(true) }

    LaunchedEffect(goat.id) {
        loadingHistory = true
        val wRes = repository.getWeights(goat.id)
        if (wRes.isSuccess) weights = wRes.getOrThrow()
        val vRes = repository.getVaccinations(goat.id)
        if (vRes.isSuccess) vacs = vRes.getOrThrow()
        val dRes = repository.getDewormings(goat.id)
        if (dRes.isSuccess) deworms = dRes.getOrThrow()
        val tRes = repository.getTreatments(goat.id)
        if (tRes.isSuccess) treatments = tRes.getOrThrow()
        loadingHistory = false
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    TagBadge(tag = goat.tag_c)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(goat.name, fontWeight = FontWeight.Bold)
                }
                Text(
                    text = "${goat.weight_kg_c ?: "--"} kg",
                    fontWeight = FontWeight.Bold,
                    color = FarmGreenDark
                )
            }
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth().heightIn(max = 480.dp)) {
                // Info block
                Card(
                    colors = CardDefaults.cardColors(containerColor = FarmGreenContainer.copy(alpha = 0.5f)),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("${goat.breed_c} • ${goat.sex_c} • ${goat.status_c}", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            OriginBadge(origin = goat.effectiveOrigin)
                        }
                        if (!goat.birth_date_c.isNullOrBlank()) Text("${t("herd.dob")}: ${goat.birth_date_c}", fontSize = 12.sp)
                        if (!goat.farm_location_c.isNullOrBlank()) Text("Location: ${goat.farm_location_c}", fontSize = 12.sp)
                        if (!goat.dam_c.isNullOrBlank() || !goat.sire_c.isNullOrBlank()) {
                            Text("${t("herd.dam")}: ${goat.dam_c ?: "N/A"}, ${t("herd.sire")}: ${goat.sire_c ?: "N/A"}", fontSize = 12.sp)
                        }
                        if (!goat.notes_c.isNullOrBlank()) Text("${t("herd.notes")}: ${goat.notes_c}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // History & Pedigree Tabs
                ScrollableTabRow(
                    selectedTabIndex = selectedTab,
                    edgePadding = 0.dp
                ) {
                    Tab(selected = selectedTab == 0, onClick = { selectedTab = 0 }, text = { Text(t("pedigree.title"), fontSize = 11.sp, fontWeight = FontWeight.Bold) })
                    Tab(selected = selectedTab == 1, onClick = { selectedTab = 1 }, text = { Text("${t("herd.weight")} (${weights.size})", fontSize = 11.sp) })
                    Tab(selected = selectedTab == 2, onClick = { selectedTab = 2 }, text = { Text("${t("dashboard.vaccinate")} (${vacs.size})", fontSize = 11.sp) })
                    Tab(selected = selectedTab == 3, onClick = { selectedTab = 3 }, text = { Text("${t("dashboard.deworm")} (${deworms.size})", fontSize = 11.sp) })
                    Tab(selected = selectedTab == 4, onClick = { selectedTab = 4 }, text = { Text("${t("dashboard.treatment")} (${treatments.size})", fontSize = 11.sp) })
                }

                Spacer(modifier = Modifier.height(8.dp))

                if (loadingHistory) {
                    Box(modifier = Modifier.fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(modifier = Modifier.size(24.dp), color = FarmGreenPrimary)
                    }
                } else {
                    when (selectedTab) {
                        0 -> {
                            PedigreeDetailSection(
                                goat = goat,
                                allGoats = allGoats,
                                onOpenGoat = { targetGoat ->
                                    onSelectGoat(targetGoat)
                                },
                                modifier = Modifier.weight(1f, false)
                            )
                        }
                        1 -> {
                            if (weights.isEmpty()) {
                                Text(t("state.no_data"), modifier = Modifier.padding(16.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
                            } else {
                                LazyColumn(modifier = Modifier.weight(1f, false)) {
                                    items(weights) { w ->
                                        Row(
                                            modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Text("${w.weight_kg_c} kg (${w.method_c})", fontWeight = FontWeight.Bold)
                                            Text(w.date_c, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
                                        }
                                    }
                                }
                            }
                        }
                        2 -> {
                            if (vacs.isEmpty()) {
                                Text(t("state.no_data"), modifier = Modifier.padding(16.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
                            } else {
                                LazyColumn(modifier = Modifier.weight(1f, false)) {
                                    items(vacs) { v ->
                                        Column(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                                            Text("${v.vaccine_c} (${v.dose_c})", fontWeight = FontWeight.Bold)
                                            Text("${t("vaccination.date_given")}: ${v.administered_date_c}${if (!v.next_due_date_c.isNullOrBlank()) " • ${t("vaccination.next_due")}: ${v.next_due_date_c}" else ""}", fontSize = 12.sp)
                                        }
                                    }
                                }
                            }
                        }
                        3 -> {
                            if (deworms.isEmpty()) {
                                Text(t("state.no_data"), modifier = Modifier.padding(16.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
                            } else {
                                LazyColumn(modifier = Modifier.weight(1f, false)) {
                                    items(deworms) { d ->
                                        Column(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                                            Text("${d.medicine_c} (${d.dose_c})", fontWeight = FontWeight.Bold)
                                            Text("${t("deworming.date_given")}: ${d.treatment_date_c}${if (!d.next_due_date_c.isNullOrBlank()) " • ${t("deworming.next_due")}: ${d.next_due_date_c}" else ""}", fontSize = 12.sp)
                                        }
                                    }
                                }
                            }
                        }
                        4 -> {
                            if (treatments.isEmpty()) {
                                Text(t("state.no_data"), modifier = Modifier.padding(16.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
                            } else {
                                LazyColumn(modifier = Modifier.weight(1f, false)) {
                                    items(treatments) { tItem ->
                                        Column(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                                            Text("${tItem.diagnosis_c} - ${tItem.medicine_c}", fontWeight = FontWeight.Bold)
                                            Text("${tItem.symptoms_c} • ${tItem.outcome_c}", fontSize = 12.sp)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedButton(
                    onClick = onOpenProfile,
                    modifier = Modifier.testTag("goat_detail_btn_profile")
                ) {
                    Icon(Icons.Default.AccountCircle, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(t("profile.view_full"), fontSize = 12.sp)
                }
                Button(
                    onClick = onRecordWeight,
                    colors = ButtonDefaults.buttonColors(containerColor = FarmGreenPrimary)
                ) {
                    Text("+ ${t("herd.weight")}")
                }
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(t("btn.close"))
            }
        }
    )
}
