package com.example.ui.screens.health

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.supabase.*
import com.example.ui.theme.*
import com.example.util.CurrencyUtils
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HealthHistoryScreen(
    repository: GoatRepository,
    initialGoatId: String? = null,
    onNavigateBack: () -> Unit
) {
    BackHandler { onNavigateBack() }

    val coroutineScope = rememberCoroutineScope()
    var historyItems by remember { mutableStateOf<List<HealthHistoryItem>>(emptyList()) }
    var goats by remember { mutableStateOf<List<Goat>>(emptyList()) }
    var selectedGoatId by remember { mutableStateOf(initialGoatId ?: "") }
    var selectedFilter by remember { mutableStateOf("ALL") } // ALL, Vaccination, Deworming, Treatment, Vet Visit, Other
    var isLoading by remember { mutableStateOf(true) }

    fun loadData() {
        isLoading = true
        coroutineScope.launch {
            val histRes = repository.getUnifiedHealthHistory(selectedGoatId.ifBlank { null })
            if (histRes.isSuccess) historyItems = histRes.getOrThrow()

            val gRes = repository.getGoats()
            if (gRes.isSuccess) goats = gRes.getOrThrow()

            isLoading = false
        }
    }

    LaunchedEffect(selectedGoatId) {
        loadData()
    }

    val filters = listOf("ALL", "Vaccination", "Deworming", "Treatment", "Veterinary Visit")

    val filteredItems = remember(historyItems, selectedFilter) {
        if (selectedFilter == "ALL") historyItems
        else historyItems.filter { it.type.equals(selectedFilter, ignoreCase = true) }
    }

    var showGoatDropdown by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "Health History Timeline",
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp
                        )
                        Text(
                            text = if (selectedGoatId.isNotBlank()) "Goat #${selectedGoatId.take(6)}" else "Entire Herd Clinical Log",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack, modifier = Modifier.testTag("health_history_btn_back")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        if (isLoading) {
            Box(modifier = Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = FarmGreenPrimary)
            }
        } else {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xFFF8FAFC))
                    .padding(padding)
            ) {
                // Goat Selector & Filter Bar
                Surface(
                    color = Color.White,
                    shadowElevation = 1.dp,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Text("Select Goat:", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = Color.Gray)
                            Spacer(modifier = Modifier.width(8.dp))
                            Box(modifier = Modifier.weight(1f)) {
                                val currentGoat = goats.find { it.id == selectedGoatId }
                                TextButton(
                                    onClick = { showGoatDropdown = true },
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text(
                                        text = currentGoat?.let { "${it.tag_c} (${it.breed_c})" } ?: "All Goats (Herd-wide)",
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = FarmGreenDark
                                    )
                                    Icon(Icons.Default.ArrowDropDown, contentDescription = null, tint = FarmGreenDark)
                                }
                                DropdownMenu(expanded = showGoatDropdown, onDismissRequest = { showGoatDropdown = false }) {
                                    DropdownMenuItem(
                                        text = { Text("All Goats (Herd-wide)") },
                                        onClick = {
                                            selectedGoatId = ""
                                            showGoatDropdown = false
                                        }
                                    )
                                    goats.forEach { g ->
                                        DropdownMenuItem(
                                            text = { Text("${g.tag_c} - ${g.name} (${g.breed_c})") },
                                            onClick = {
                                                selectedGoatId = g.id
                                                showGoatDropdown = false
                                            }
                                        )
                                    }
                                }
                            }
                        }

                        // Filter Chips
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            filters.forEach { filter ->
                                val isSelected = selectedFilter == filter
                                FilterChip(
                                    selected = isSelected,
                                    onClick = { selectedFilter = filter },
                                    label = { Text(filter, fontSize = 11.sp) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = FarmGreenPrimary,
                                        selectedLabelColor = Color.White
                                    )
                                )
                            }
                        }
                    }
                }

                if (filteredItems.isEmpty()) {
                    Box(modifier = Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.History, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(48.dp))
                            Spacer(modifier = Modifier.height(10.dp))
                            Text("No Health History Records Found", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                            Text("Vaccinations, dewormings, and treatments will automatically populate this timeline.", fontSize = 12.sp, color = Color.Gray)
                        }
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        item {
                            Text(
                                text = "HEALTH EVENTS (${filteredItems.size})",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.Gray,
                                letterSpacing = 0.5.sp
                            )
                        }

                        items(filteredItems) { item ->
                            HealthHistoryTimelineCard(item = item)
                        }

                        item {
                            Spacer(modifier = Modifier.height(32.dp))
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun HealthHistoryTimelineCard(item: HealthHistoryItem) {
    val (typeColor, icon) = when (item.type.lowercase()) {
        "vaccination" -> Color(0xFF0284C7) to Icons.Default.Vaccines
        "deworming" -> Color(0xFF059669) to Icons.Default.Medication
        "treatment" -> Color(0xFF9333EA) to Icons.Default.Healing
        "veterinary visit" -> Color(0xFF2563EB) to Icons.Default.MedicalServices
        "mortality" -> Color(0xFFDC2626) to Icons.Default.WarningAmber
        else -> Color(0xFF475569) to Icons.Default.HealthAndSafety
    }

    Card(
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(12.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier.fillMaxWidth().testTag("history_item_${item.id}")
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.Top
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(typeColor.copy(alpha = 0.12f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = null, tint = typeColor, modifier = Modifier.size(22.dp))
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        color = typeColor.copy(alpha = 0.1f),
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text(
                            text = item.type.uppercase(),
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            color = typeColor,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }

                    Text(
                        text = item.date,
                        fontSize = 11.sp,
                        color = Color.Gray,
                        fontWeight = FontWeight.Medium
                    )
                }

                Text(
                    text = item.title,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )

                Text(
                    text = item.description,
                    fontSize = 12.sp,
                    color = Color.DarkGray
                )

                if (!item.veterinarian.isNullOrBlank()) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Person, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(12.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Administered / Attended by: ${item.veterinarian}",
                            fontSize = 11.sp,
                            color = Color.Gray
                        )
                    }
                }

                if (item.cost != null && item.cost > 0) {
                    Text(
                        text = "Cost: ${CurrencyUtils.format(item.cost)}",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = FarmGreenDark
                    )
                }

                if (item.is_seller_reported) {
                    Surface(
                        color = Color(0xFFFEF3C7),
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Text(
                            text = "HISTORICAL / SELLER-REPORTED (NOT FARM-ADMINISTERED)",
                            fontSize = 9.sp,
                            color = Color(0xFFB45309),
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }
            }
        }
    }
}
