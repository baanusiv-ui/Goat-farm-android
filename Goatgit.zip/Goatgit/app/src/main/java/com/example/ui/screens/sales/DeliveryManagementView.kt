package com.example.ui.screens.sales

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import coil.compose.AsyncImage
import com.example.data.payment.DeliveryStatus
import com.example.data.supabase.DeliveryRecord
import com.example.data.supabase.Goat
import com.example.data.supabase.GoatRepository
import com.example.data.supabase.SaleRecord
import com.example.ui.theme.*
import com.example.util.CurrencyUtils
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DeliveryManagementView(
    repository: GoatRepository,
    sales: List<SaleRecord>,
    goatsMap: Map<String, Goat>,
    modifier: Modifier = Modifier
) {
    val coroutineScope = rememberCoroutineScope()
    val deliveries by repository.getDeliveriesFlow().collectAsState(initial = emptyList())
    val dateFormat = remember { SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()) }

    var selectedFilter by remember { mutableStateOf("ALL") } // ALL, EXPECTED, READY, DISPATCHED, DELIVERED
    var searchQuery by remember { mutableStateOf("") }

    var deliveryToComplete by remember { mutableStateOf<DeliveryRecord?>(null) }
    var viewingPhotoUri by remember { mutableStateOf<String?>(null) }

    // Combine records from DB deliveries or fallback to sales with delivery status
    val displayDeliveries = remember(deliveries, sales, selectedFilter, searchQuery) {
        val baseList = if (deliveries.isNotEmpty()) {
            deliveries
        } else {
            sales.map { sale ->
                DeliveryRecord(
                    id = "del-${sale.id}",
                    sale_id_c = sale.id,
                    goat_id_c = sale.goat_id_c,
                    recipient_name_c = sale.buyer_name_c,
                    recipient_phone_c = sale.buyer_phone_c,
                    delivery_address_c = sale.buyer_address_c,
                    expected_delivery_date_c = sale.expected_delivery_date_c ?: sale.sale_date_c,
                    actual_delivery_date_c = sale.actual_delivery_date_c,
                    delivery_status_c = sale.delivery_status_c,
                    delivery_photo_uri_c = sale.delivery_photo_uri_c,
                    outstanding_balance_c = sale.balance_due_c,
                    is_delivered = DeliveryStatus.normalize(sale.delivery_status_c) == DeliveryStatus.DELIVERED
                )
            }
        }

        baseList.filter { item ->
            val matchesFilter = when (selectedFilter) {
                "EXPECTED" -> DeliveryStatus.normalize(item.delivery_status_c) == DeliveryStatus.EXPECTED
                "READY" -> DeliveryStatus.normalize(item.delivery_status_c) == DeliveryStatus.READY
                "DISPATCHED" -> DeliveryStatus.normalize(item.delivery_status_c) == DeliveryStatus.DISPATCHED
                "DELIVERED" -> DeliveryStatus.normalize(item.delivery_status_c) == DeliveryStatus.DELIVERED
                else -> true
            }

            val matchesSearch = if (searchQuery.isBlank()) true else {
                val q = searchQuery.trim().lowercase()
                item.recipient_name_c.lowercase().contains(q) ||
                        item.recipient_phone_c.contains(q) ||
                        item.delivery_address_c.lowercase().contains(q) ||
                        (item.goat_id_c?.let { goatsMap[it]?.tag_c?.lowercase()?.contains(q) } == true)
            }

            matchesFilter && matchesSearch
        }
    }

    val pendingCount = remember(deliveries, sales) {
        val list = if (deliveries.isNotEmpty()) deliveries else sales.map { it.delivery_status_c }
        if (deliveries.isNotEmpty()) {
            deliveries.count { DeliveryStatus.normalize(it.delivery_status_c) != DeliveryStatus.DELIVERED }
        } else {
            sales.count { DeliveryStatus.normalize(it.delivery_status_c) != DeliveryStatus.DELIVERED }
        }
    }

    Column(modifier = modifier.fillMaxSize()) {
        // Summary Header Card
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .clip(CircleShape)
                            .background(Color(0xFFE0F2FE)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.LocalShipping,
                            contentDescription = null,
                            tint = Color(0xFF0284C7),
                            modifier = Modifier.size(24.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "Goat Deliveries & Dispatch",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = FarmGreenDark
                        )
                        Text(
                            text = "Track shipments, photos & delivery status",
                            fontSize = 11.sp,
                            color = Color.Gray
                        )
                    }
                }

                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = if (pendingCount > 0) Color(0xFFFEF3C7) else FarmGreenContainer
                ) {
                    Text(
                        text = if (pendingCount > 0) "$pendingCount Pending" else "All Delivered",
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        color = if (pendingCount > 0) Color(0xFFB45309) else FarmGreenDark,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                    )
                }
            }
        }

        // Search Bar
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            placeholder = { Text("Search customer, phone, address or tag...") },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = Color.Gray) },
            trailingIcon = {
                if (searchQuery.isNotBlank()) {
                    IconButton(onClick = { searchQuery = "" }) {
                        Icon(Icons.Default.Clear, contentDescription = "Clear search", modifier = Modifier.size(18.dp))
                    }
                }
            },
            singleLine = true,
            shape = RoundedCornerShape(12.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = Color.White,
                unfocusedContainerColor = Color.White,
                focusedBorderColor = FarmGreenDark,
                unfocusedBorderColor = Color(0xFFE2E8F0)
            ),
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 4.dp)
                .testTag("delivery_search_field")
        )

        // Filter Chips Row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            listOf("ALL", "EXPECTED", "READY", "DISPATCHED", "DELIVERED").forEach { filter ->
                val isSelected = selectedFilter == filter
                FilterChip(
                    selected = isSelected,
                    onClick = { selectedFilter = filter },
                    label = { Text(filter, fontSize = 11.sp, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = when (filter) {
                            "DELIVERED" -> FarmGreenContainer
                            "DISPATCHED" -> Color(0xFFEDE9FE)
                            "READY" -> Color(0xFFE0F2FE)
                            "EXPECTED" -> Color(0xFFFEF3C7)
                            else -> FarmGreenDark
                        },
                        selectedLabelColor = when (filter) {
                            "DELIVERED" -> FarmGreenDark
                            "DISPATCHED" -> Color(0xFF6D28D9)
                            "READY" -> Color(0xFF0369A1)
                            "EXPECTED" -> Color(0xFF92400E)
                            else -> Color.White
                        }
                    ),
                    modifier = Modifier.height(32.dp)
                )
            }
        }

        // Deliveries List
        if (displayDeliveries.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.LocalShipping,
                        contentDescription = null,
                        tint = Color.LightGray,
                        modifier = Modifier.size(56.dp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = if (searchQuery.isNotBlank()) "No deliveries matching '$searchQuery'" else "No delivery records found",
                        color = Color.Gray,
                        fontWeight = FontWeight.Medium,
                        fontSize = 14.sp
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = PaddingValues(top = 4.dp, bottom = 80.dp)
            ) {
                items(displayDeliveries, key = { it.id }) { item ->
                    val goat = item.goat_id_c?.let { goatsMap[it] }
                    DeliveryCard(
                        delivery = item,
                        goat = goat,
                        onMarkDeliveredClick = { deliveryToComplete = item },
                        onQuickStatusChange = { newStatus ->
                            coroutineScope.launch {
                                repository.updateDeliveryStatus(item.sale_id_c, newStatus)
                            }
                        },
                        onViewPhotoClick = { uri -> viewingPhotoUri = uri }
                    )
                }
            }
        }
    }

    // Mark as Delivered Dialog
    deliveryToComplete?.let { delivery ->
        MarkAsDeliveredDialog(
            delivery = delivery,
            onDismiss = { deliveryToComplete = null },
            onConfirmDelivery = { actualDate, photoUri, notes ->
                coroutineScope.launch {
                    repository.updateDeliveryStatus(
                        saleId = delivery.sale_id_c,
                        status = DeliveryStatus.DELIVERED,
                        actualDate = actualDate,
                        photoUri = photoUri,
                        notes = notes,
                        isDelivered = true
                    )
                    deliveryToComplete = null
                }
            }
        )
    }

    // Photo Preview Dialog
    viewingPhotoUri?.let { uri ->
        Dialog(onDismissRequest = { viewingPhotoUri = null }) {
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = Color.Black,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Delivery Proof Photo", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        IconButton(onClick = { viewingPhotoUri = null }) {
                            Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.White)
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    AsyncImage(
                        model = uri,
                        contentDescription = "Delivery Photo",
                        contentScale = ContentScale.Fit,
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(max = 400.dp)
                            .clip(RoundedCornerShape(8.dp))
                    )
                }
            }
        }
    }
}

@Composable
fun DeliveryCard(
    delivery: DeliveryRecord,
    goat: Goat?,
    onMarkDeliveredClick: () -> Unit,
    onQuickStatusChange: (String) -> Unit,
    onViewPhotoClick: (String) -> Unit
) {
    val normStatus = DeliveryStatus.normalize(delivery.delivery_status_c)
    val isDelivered = normStatus == DeliveryStatus.DELIVERED
    val hasBalanceDue = delivery.outstanding_balance_c > 0.0

    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("delivery_card_${delivery.id}")
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Header Row: Customer Name & Status Badge
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                    Box(
                        modifier = Modifier
                            .size(34.dp)
                            .clip(CircleShape)
                            .background(
                                when (normStatus) {
                                    DeliveryStatus.DELIVERED -> FarmGreenContainer
                                    DeliveryStatus.DISPATCHED -> Color(0xFFEDE9FE)
                                    DeliveryStatus.READY -> Color(0xFFE0F2FE)
                                    else -> Color(0xFFFEF3C7)
                                }
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = when (normStatus) {
                                DeliveryStatus.DELIVERED -> Icons.Default.CheckCircle
                                DeliveryStatus.DISPATCHED -> Icons.Default.LocalShipping
                                DeliveryStatus.READY -> Icons.Default.Inventory
                                else -> Icons.Default.Schedule
                            },
                            contentDescription = null,
                            tint = when (normStatus) {
                                DeliveryStatus.DELIVERED -> FarmSuccess
                                DeliveryStatus.DISPATCHED -> Color(0xFF6D28D9)
                                DeliveryStatus.READY -> Color(0xFF0369A1)
                                else -> Color(0xFFB45309)
                            },
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = delivery.recipient_name_c.ifBlank { "Customer" },
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                        if (delivery.recipient_phone_c.isNotBlank()) {
                            Text(
                                text = delivery.recipient_phone_c,
                                fontSize = 11.sp,
                                color = Color.Gray
                            )
                        }
                    }
                }

                // Delivery Status Badge
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = when (normStatus) {
                        DeliveryStatus.DELIVERED -> FarmGreenContainer
                        DeliveryStatus.DISPATCHED -> Color(0xFFEDE9FE)
                        DeliveryStatus.READY -> Color(0xFFE0F2FE)
                        else -> Color(0xFFFEF3C7)
                    }
                ) {
                    Text(
                        text = normStatus,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        color = when (normStatus) {
                            DeliveryStatus.DELIVERED -> FarmGreenDark
                            DeliveryStatus.DISPATCHED -> Color(0xFF6D28D9)
                            DeliveryStatus.READY -> Color(0xFF0369A1)
                            else -> Color(0xFFB45309)
                        },
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))
            Divider(color = Color(0xFFF1F5F9))
            Spacer(modifier = Modifier.height(10.dp))

            // Details Grid
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Goat tag
                Column(modifier = Modifier.weight(1f)) {
                    Text("Goat / Tag", fontSize = 10.sp, color = Color.Gray)
                    Text(
                        text = goat?.tag_c ?: "Goat #${delivery.goat_id_c?.take(6) ?: "N/A"}",
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 12.sp
                    )
                }

                // Expected Delivery Date
                Column(modifier = Modifier.weight(1.2f)) {
                    Text("Expected Date", fontSize = 10.sp, color = Color.Gray)
                    Text(
                        text = delivery.expected_delivery_date_c ?: "Immediate",
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 12.sp
                    )
                }

                // Actual Delivery Date (if delivered)
                if (isDelivered && !delivery.actual_delivery_date_c.isNullOrBlank()) {
                    Column(modifier = Modifier.weight(1.2f)) {
                        Text("Delivered At", fontSize = 10.sp, color = Color.Gray)
                        Text(
                            text = delivery.actual_delivery_date_c ?: "-",
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 12.sp,
                            color = FarmSuccess
                        )
                    }
                }
            }

            // Destination address
            if (delivery.delivery_address_c.isNotBlank()) {
                Spacer(modifier = Modifier.height(6.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.LocationOn, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(13.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = delivery.delivery_address_c,
                        fontSize = 11.sp,
                        color = Color.DarkGray
                    )
                }
            }

            // Outstanding Balance Alert Banner (Crucial Requirement: allow delivery with balance, but highlight it!)
            if (hasBalanceDue) {
                Spacer(modifier = Modifier.height(8.dp))
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Color(0xFFFEF2F2),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFFCA5A5)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Warning, contentDescription = null, tint = Color(0xFFDC2626), modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Outstanding Balance: ${CurrencyUtils.format(delivery.outstanding_balance_c)}",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFDC2626)
                        )
                    }
                }
            }

            // Delivery Photo Thumbnail (if available)
            if (!delivery.delivery_photo_uri_c.isNullOrBlank()) {
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .clickable { onViewPhotoClick(delivery.delivery_photo_uri_c) }
                        .padding(vertical = 2.dp)
                ) {
                    AsyncImage(
                        model = delivery.delivery_photo_uri_c,
                        contentDescription = "Delivery Photo",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .size(36.dp)
                            .clip(RoundedCornerShape(6.dp))
                            .border(1.dp, Color(0xFFCBD5E1), RoundedCornerShape(6.dp))
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text("Delivery Photo Attached", fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = FarmGreenDark)
                        Text("Tap to view full proof", fontSize = 10.sp, color = Color.Gray)
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Action Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (!isDelivered) {
                    // Quick state progression buttons
                    when (normStatus) {
                        DeliveryStatus.EXPECTED -> {
                            OutlinedButton(
                                onClick = { onQuickStatusChange(DeliveryStatus.READY) },
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.height(34.dp)
                            ) {
                                Text("Mark Ready", fontSize = 11.sp)
                            }
                        }
                        DeliveryStatus.READY -> {
                            OutlinedButton(
                                onClick = { onQuickStatusChange(DeliveryStatus.DISPATCHED) },
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.height(34.dp)
                            ) {
                                Text("Dispatch", fontSize = 11.sp)
                            }
                        }
                        DeliveryStatus.DISPATCHED -> {
                            // Ready for delivered
                        }
                    }

                    // Primary [ MARK AS DELIVERED ] Button
                    Button(
                        onClick = onMarkDeliveredClick,
                        colors = ButtonDefaults.buttonColors(containerColor = FarmGreenDark),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 2.dp),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(34.dp)
                            .testTag("mark_delivered_btn_${delivery.id}")
                    ) {
                        Icon(Icons.Default.Done, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Mark as Delivered", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                } else {
                    // Already delivered
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = FarmGreenContainer,
                        modifier = Modifier.weight(1f)
                    ) {
                        Row(
                            modifier = Modifier.padding(vertical = 6.dp, horizontal = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Icon(Icons.Default.CheckCircle, contentDescription = null, tint = FarmSuccess, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Delivery Completed", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = FarmGreenDark)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun MarkAsDeliveredDialog(
    delivery: DeliveryRecord,
    onDismiss: () -> Unit,
    onConfirmDelivery: (actualDate: String, photoUri: String?, notes: String?) -> Unit
) {
    val dateTimeFormat = remember { SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()) }
    var actualDateStr by remember { mutableStateOf(dateTimeFormat.format(Date())) }
    var selectedPhotoUri by remember { mutableStateOf<String?>(delivery.delivery_photo_uri_c) }
    var deliveryNotes by remember { mutableStateOf(delivery.delivery_notes_c ?: "") }
    var confirmOutstandingUnderstood by remember { mutableStateOf(false) }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            selectedPhotoUri = uri.toString()
        }
    }

    val hasOutstandingBalance = delivery.outstanding_balance_c > 0.0

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.LocalShipping, contentDescription = null, tint = FarmGreenDark)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Confirm Goat Delivery", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            }
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "Customer: ${delivery.recipient_name_c}",
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 13.sp
                )

                if (delivery.delivery_address_c.isNotBlank()) {
                    Text(
                        text = "Address: ${delivery.delivery_address_c}",
                        fontSize = 12.sp,
                        color = Color.DarkGray
                    )
                }

                // Balance alert if outstanding
                if (hasOutstandingBalance) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = Color(0xFFFEF2F2),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFFCA5A5)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Warning, contentDescription = null, tint = Color(0xFFDC2626), modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "OUTSTANDING BALANCE DUE",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp,
                                    color = Color(0xFFDC2626)
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Amount Due: ${CurrencyUtils.format(delivery.outstanding_balance_c)}. You are delivering before full payment is collected.",
                                fontSize = 11.sp,
                                color = Color(0xFF7F1D1D)
                            )
                        }
                    }
                }

                // Actual Delivery Date/Time
                OutlinedTextField(
                    value = actualDateStr,
                    onValueChange = { actualDateStr = it },
                    label = { Text("Actual Delivery Date & Time") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                // Delivery Proof Photo Picker
                Card(
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFF8FAFC)),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        if (selectedPhotoUri != null) {
                            AsyncImage(
                                model = selectedPhotoUri,
                                contentDescription = "Delivery Proof",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(120.dp)
                                    .clip(RoundedCornerShape(8.dp))
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            OutlinedButton(
                                onClick = {
                                    photoPickerLauncher.launch(
                                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                    )
                                },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Icon(Icons.Default.PhotoCamera, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Change Proof Photo", fontSize = 12.sp)
                            }
                        } else {
                            OutlinedButton(
                                onClick = {
                                    photoPickerLauncher.launch(
                                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                    )
                                },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Icon(Icons.Default.PhotoCamera, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Attach Delivery Proof Photo (Optional)", fontSize = 12.sp)
                            }
                        }
                    }
                }

                // Delivery Notes
                OutlinedTextField(
                    value = deliveryNotes,
                    onValueChange = { deliveryNotes = it },
                    label = { Text("Delivery Notes") },
                    placeholder = { Text("e.g. Delivered to buyer's farm, handover signed") },
                    modifier = Modifier.fillMaxWidth(),
                    maxLines = 2
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onConfirmDelivery(actualDateStr.trim(), selectedPhotoUri, deliveryNotes.trim().ifBlank { null })
                },
                colors = ButtonDefaults.buttonColors(containerColor = FarmGreenDark),
                modifier = Modifier.testTag("confirm_delivery_action_btn")
            ) {
                Text("Confirm Delivered", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
