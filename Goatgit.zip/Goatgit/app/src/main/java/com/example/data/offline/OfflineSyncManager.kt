package com.example.data.offline

import android.content.Context
import android.util.Log
import com.example.data.supabase.RealtimeStatus
import com.example.data.supabase.SupabaseClient
import com.example.data.supabase.SupabaseRealtimeEvent
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale
import java.util.UUID

enum class SyncState {
    SYNCED,
    PENDING,
    OFFLINE,
    ERROR,
    SYNCING
}

class OfflineSyncManager(
    val context: Context,
    private val database: AppDatabase,
    private val client: SupabaseClient,
    private val networkMonitor: NetworkMonitor
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val tag = "OfflineSyncManager"

    private val syncQueueDao = database.syncQueueDao()
    private val syncConflictDao = database.syncConflictDao()

    private val _isSyncing = MutableStateFlow(false)
    val isSyncing: StateFlow<Boolean> = _isSyncing.asStateFlow()

    private val _lastSyncTime = MutableStateFlow(
        context.getSharedPreferences("offline_sync_prefs", Context.MODE_PRIVATE)
            .getLong("last_sync_timestamp", 0L)
    )
    val lastSyncTime: StateFlow<Long> = _lastSyncTime.asStateFlow()

    val pendingCount: Flow<Int> = syncQueueDao.getPendingCountFlow()
    val failedCount: Flow<Int> = syncQueueDao.getFailedCountFlow()
    val conflictCount: Flow<Int> = syncConflictDao.getUnresolvedConflictCountFlow()
    val pendingOperations: Flow<List<SyncQueueEntity>> = syncQueueDao.getAllPendingQueueFlow()
    val unresolvedConflicts: Flow<List<SyncConflictEntity>> = syncConflictDao.getUnresolvedConflictsFlow()

    // Real-time synchronization state from Supabase Realtime client
    val realtimeStatus: StateFlow<RealtimeStatus> = client.realtime.status
    val lastRealtimeEventTime: StateFlow<Long> = client.realtime.lastEventTime
    val realtimeEventCount: StateFlow<Int> = client.realtime.eventCount

    fun reconnectRealtime() {
        client.realtime.reconnect()
    }

    val syncState: StateFlow<SyncState> = combine(
        networkMonitor.isOnline,
        _isSyncing,
        syncQueueDao.getPendingCountFlow(),
        syncQueueDao.getFailedCountFlow()
    ) { isOnline, isSyncing, pending, failed ->
        when {
            !isOnline -> SyncState.OFFLINE
            isSyncing -> SyncState.SYNCING
            failed > 0 -> SyncState.ERROR
            pending > 0 -> SyncState.PENDING
            else -> SyncState.SYNCED
        }
    }.stateIn(scope, SharingStarted.Eagerly, SyncState.SYNCED)

    private fun isMissingRemoteTable(errorMsg: String?): Boolean {
        if (errorMsg.isNullOrBlank()) return false
        val lower = errorMsg.lowercase(Locale.ROOT)
        return lower.contains("could not find the table") ||
               lower.contains("schema cache") ||
               lower.contains("pgrst205") ||
               lower.contains("pgrst200") ||
               lower.contains("42p01") ||
               (lower.contains("relation") && lower.contains("does not exist"))
    }

    init {
        // Prune any legacy queued operations targeting unprovisioned remote tables
        scope.launch {
            try {
                val pending = syncQueueDao.getPendingOperations()
                for (op in pending) {
                    if (isMissingRemoteTable(op.lastError) || op.entityTable == "financial_accounts" || op.entityTable == "account_transactions") {
                        syncQueueDao.deleteOperation(op.operationId)
                    }
                }
            } catch (_: Exception) {}
        }

        // Observe connectivity changes: trigger automatic sync and manage Realtime WebSocket
        scope.launch {
            var wasOnline = networkMonitor.isOnline.value
            networkMonitor.isOnline.collect { isOnline ->
                if (isOnline) {
                    client.realtime.connect()
                    if (!wasOnline) {
                        Log.d(tag, "Internet connection restored. Triggering automatic sync.")
                        syncNow()
                    }
                } else {
                    client.realtime.disconnect()
                }
                wasOnline = isOnline
            }
        }

        // Listen for live Supabase Realtime PostgreSQL change events
        scope.launch {
            client.realtime.realtimeEvents.collect { event ->
                try {
                    handleRealtimeEvent(event)
                } catch (e: Exception) {
                    Log.e(tag, "Error handling realtime event: ${e.message}", e)
                }
            }
        }

        // Also trigger sync on startup if online
        scope.launch {
            delay(1000)
            if (networkMonitor.isOnline.value) {
                client.realtime.connect()
                syncNow()
            }
        }
    }

    suspend fun enqueueOperation(
        table: String,
        recordId: String,
        operationType: String,
        payload: JSONObject
    ): String = withContext(Dispatchers.IO) {
        val opId = UUID.randomUUID().toString()
        val queueItem = SyncQueueEntity(
            operationId = opId,
            entityTable = table,
            recordId = recordId,
            operationType = operationType,
            payloadJson = payload.toString(),
            createdAt = System.currentTimeMillis(),
            retryCount = 0,
            syncStatus = "PENDING"
        )
        syncQueueDao.insertOperation(queueItem)
        Log.d(tag, "Enqueued $operationType for $table ($recordId)")

        // If online, immediately process in background
        if (networkMonitor.isOnline.value && !_isSyncing.value) {
            scope.launch {
                processSyncQueue()
            }
        }
        opId
    }

    suspend fun syncNow(): Boolean = withContext(Dispatchers.IO) {
        if (!networkMonitor.isOnline.value) {
            Log.d(tag, "Cannot sync while offline")
            return@withContext false
        }
        if (_isSyncing.value) {
            Log.d(tag, "Sync already in progress")
            return@withContext false
        }

        _isSyncing.value = true
        try {
            // 1. Process local pending sync queue first
            processSyncQueue()

            // 2. Download remote updates to refresh local cache
            downloadRemoteChanges()

            val now = System.currentTimeMillis()
            _lastSyncTime.value = now
            context.getSharedPreferences("offline_sync_prefs", Context.MODE_PRIVATE)
                .edit().putLong("last_sync_timestamp", now).apply()

            true
        } catch (e: Exception) {
            Log.e(tag, "Sync failed: ${e.message}", e)
            false
        } finally {
            _isSyncing.value = false
        }
    }

    suspend fun retryFailed(): Boolean = withContext(Dispatchers.IO) {
        val failedOps = syncQueueDao.getPendingOperations().filter { it.syncStatus == "FAILED" }
        for (op in failedOps) {
            syncQueueDao.updateOperation(op.copy(syncStatus = "PENDING", retryCount = 0, lastError = null))
        }
        syncNow()
    }

    private suspend fun processSyncQueue() = withContext(Dispatchers.IO) {
        val operations = syncQueueDao.getPendingOperations()
        Log.d(tag, "Processing sync queue: ${operations.size} operations")

        for (op in operations) {
            if (!networkMonitor.isOnline.value) break

            // Skip and clear operations for tables that are not provisioned remotely or have failed with missing table
            if (isMissingRemoteTable(op.lastError) || op.entityTable == "financial_accounts" || op.entityTable == "account_transactions") {
                Log.i(tag, "Pruning sync operation ${op.operationId} for table '${op.entityTable}'; record is preserved locally in Room.")
                syncQueueDao.deleteOperation(op.operationId)
                continue
            }

            if (op.retryCount >= 5) {
                syncQueueDao.updateOperation(op.copy(syncStatus = "FAILED", lastError = op.lastError ?: "Max retry limit reached"))
                continue
            }

            syncQueueDao.updateOperation(op.copy(syncStatus = "IN_PROGRESS"))

            try {
                val payloadObj = JSONObject(op.payloadJson)

                // Financial and Sales conflict detection:
                if (op.entityTable == "sales_c" && op.operationType == "CREATE") {
                    val existingRes = client.get("sales_c", "id=eq.${op.recordId}")
                    if (existingRes.isSuccess) {
                        val arr = existingRes.getOrThrow()
                        if (arr.length() > 0) {
                            // Record already exists in Supabase! Idempotent check
                            val remoteObj = arr.getJSONObject(0)
                            val remoteAmount = remoteObj.optDouble("amount_c", 0.0)
                            val localAmount = payloadObj.optDouble("amount_c", 0.0)
                            if (Math.abs(remoteAmount - localAmount) > 0.01) {
                                // Conflict!
                                val conflict = SyncConflictEntity(
                                    operationId = op.operationId,
                                    entityTable = op.entityTable,
                                    recordId = op.recordId,
                                    localPayloadJson = op.payloadJson,
                                    remotePayloadJson = remoteObj.toString(),
                                    conflictReason = "Sale record amount discrepancy: local $localAmount vs remote $remoteAmount"
                                )
                                syncConflictDao.insertConflict(conflict)
                                syncQueueDao.updateOperation(op.copy(syncStatus = "CONFLICT", lastError = "Financial conflict detected"))
                                continue
                            } else {
                                // Already successfully inserted remotely, mark done!
                                syncQueueDao.deleteOperation(op.operationId)
                                continue
                            }
                        }
                    }
                }

                // Execute the operation
                val success = when (op.operationType) {
                    "CREATE" -> {
                        // Idempotent insertion
                        val insertRes = client.insert(op.entityTable, payloadObj)
                        if (insertRes.isSuccess) {
                            true
                        } else {
                            val err = insertRes.exceptionOrNull()?.message ?: "Unknown error"
                            if (err.contains("duplicate", ignoreCase = true) || err.contains("23505")) {
                                // Already exists remotely with this UUID, consider successful
                                true
                            } else if (isMissingRemoteTable(err)) {
                                Log.i(tag, "Remote table '${op.entityTable}' not provisioned in Supabase schema cache; record is maintained locally in Room.")
                                syncQueueDao.deleteOperation(op.operationId)
                                false
                            } else {
                                throw Exception(err)
                            }
                        }
                    }
                    "UPDATE" -> {
                        val updateRes = client.update(op.entityTable, "id=eq.${op.recordId}", payloadObj)
                        if (updateRes.isSuccess) {
                            true
                        } else {
                            val err = updateRes.exceptionOrNull()?.message ?: "Update failed"
                            if (isMissingRemoteTable(err)) {
                                Log.i(tag, "Remote table '${op.entityTable}' not provisioned in Supabase schema cache; record is maintained locally in Room.")
                                syncQueueDao.deleteOperation(op.operationId)
                                false
                            } else {
                                throw Exception(err)
                            }
                        }
                    }
                    "DELETE" -> {
                        val deleteRes = client.delete(op.entityTable, "id=eq.${op.recordId}")
                        if (deleteRes.isSuccess) {
                            true
                        } else {
                            val err = deleteRes.exceptionOrNull()?.message ?: "Delete failed"
                            if (isMissingRemoteTable(err)) {
                                Log.i(tag, "Remote table '${op.entityTable}' not provisioned in Supabase schema cache; record is maintained locally in Room.")
                                syncQueueDao.deleteOperation(op.operationId)
                                false
                            } else {
                                throw Exception(err)
                            }
                        }
                    }
                    else -> true
                }

                if (success) {
                    syncQueueDao.deleteOperation(op.operationId)
                    Log.d(tag, "Successfully synchronized operation ${op.operationId} for ${op.entityTable}")
                }
            } catch (e: Exception) {
                val errMsg = e.message ?: "Sync error"
                if (isMissingRemoteTable(errMsg)) {
                    Log.i(tag, "Remote table '${op.entityTable}' not in Supabase schema cache. Operation ${op.operationId} preserved locally in Room.")
                    syncQueueDao.deleteOperation(op.operationId)
                } else {
                    Log.e(tag, "Failed to sync operation ${op.operationId}: $errMsg")
                    val nextRetry = op.retryCount + 1
                    val newStatus = if (nextRetry >= 5) "FAILED" else "PENDING"
                    syncQueueDao.updateOperation(
                        op.copy(
                            retryCount = nextRetry,
                            lastError = errMsg,
                            syncStatus = newStatus,
                            updatedAt = System.currentTimeMillis()
                        )
                    )
                    // Exponential backoff delay
                    delay((1000L * (1 shl (op.retryCount.coerceAtMost(4)))).coerceAtMost(8000L))
                }
            }
        }
    }

    private suspend fun downloadRemoteChanges() = withContext(Dispatchers.IO) {
        val pendingOps = syncQueueDao.getPendingOperations().map { it.recordId }.toSet()

        // 1. Goats
        try {
            val goatsRes = client.get("goats_c", "order=name.asc")
            if (goatsRes.isSuccess) {
                val arr = goatsRes.getOrThrow()
                val list = mutableListOf<GoatEntity>()
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    val id = o.optString("id")
                    // If this record has a pending local modification, do NOT overwrite it
                    if (id in pendingOps) continue

                    list.add(
                        GoatEntity(
                            id = id,
                            name = o.optString("name", "Goat"),
                            tag_c = o.optString("tag_c", o.optString("tag", "")),
                            breed_c = o.optString("breed_c", o.optString("breed", "Boer")),
                            sex_c = o.optString("sex_c", o.optString("sex", "Doe")),
                            status_c = o.optString("status_c", o.optString("status", "Active")),
                            birth_date_c = o.optNullableString("birth_date_c"),
                            weight_kg_c = if (o.has("weight_kg_c") && !o.isNull("weight_kg_c")) o.optDouble("weight_kg_c") else null,
                            dam_c = o.optNullableString("dam_c"),
                            sire_c = o.optNullableString("sire_c"),
                            source_c = o.optString("source_c", "Born on farm"),
                            purchase_date_c = o.optNullableString("purchase_date_c"),
                            purchase_cost_c = if (o.has("purchase_cost_c") && !o.isNull("purchase_cost_c")) o.optDouble("purchase_cost_c") else null,
                            farm_location_c = o.optString("farm_location_c", "Barn A"),
                            color_c = o.optNullableString("color_c"),
                            notes_c = o.optNullableString("notes_c"),
                            created_at = o.optNullableString("created_at"),
                            updated_at = System.currentTimeMillis(),
                            is_synced = true,
                            origin_c = o.optNullableString("origin_c")
                        )
                    )
                }
                if (list.isNotEmpty()) {
                    database.goatDao().insertAll(list)
                }
            }
        } catch (e: Exception) {
            Log.w(tag, "Failed to download goats: ${e.message}")
        }

        // 2. Sales
        try {
            val salesRes = client.get("sales_c", "order=created_at.desc")
            if (salesRes.isSuccess) {
                val arr = salesRes.getOrThrow()
                val list = mutableListOf<SaleEntity>()
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    val id = o.optString("id")
                    if (id in pendingOps) continue

                    var buyerName = o.optString("buyer_name_c", "")
                    var buyerPhone = o.optString("buyer_phone_c", "")
                    var paymentMode = o.optString("payment_mode_c", "")
                    var paymentStatus = o.optString("payment_status_c", "")
                    var userNotes = o.optNullableString("notes_c")

                    val rawNotes = o.optNullableString("notes_c")
                    if (rawNotes != null && rawNotes.trim().startsWith("{") && rawNotes.trim().endsWith("}")) {
                        try {
                            val meta = JSONObject(rawNotes)
                            if (buyerName.isBlank()) buyerName = meta.optString("buyer_name", "")
                            if (buyerPhone.isBlank()) buyerPhone = meta.optString("buyer_phone", "")
                            if (paymentMode.isBlank()) paymentMode = meta.optString("payment_mode", "Cash")
                            if (paymentStatus.isBlank()) paymentStatus = meta.optString("payment_status", "Received")
                            userNotes = meta.optNullableString("notes")
                        } catch (_: Exception) {}
                    }

                    list.add(
                        SaleEntity(
                            id = id,
                            goat_id_c = o.optString("goat_id_c"),
                            amount_c = o.optDouble("amount_c", 0.0),
                            sale_date_c = o.optString("sale_date_c", ""),
                            buyer_name_c = buyerName,
                            buyer_phone_c = buyerPhone,
                            payment_mode_c = paymentMode.ifBlank { "Cash" },
                            payment_status_c = paymentStatus.ifBlank { "Received" },
                            notes_c = userNotes,
                            created_at = o.optNullableString("created_at"),
                            updated_at = System.currentTimeMillis(),
                            is_synced = true
                        )
                    )
                }
                if (list.isNotEmpty()) {
                    database.salesDao().insertAll(list)
                }
            }
        } catch (e: Exception) {
            Log.w(tag, "Failed to download sales: ${e.message}")
        }

        // 3. Tasks
        try {
            val tasksRes = client.get("tasks_c", "order=due_date_c.asc")
            if (tasksRes.isSuccess) {
                val arr = tasksRes.getOrThrow()
                val list = mutableListOf<TaskEntity>()
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    val id = o.optString("id")
                    if (id in pendingOps) continue
                    list.add(
                        TaskEntity(
                            id = id,
                            title_c = o.optString("title_c", o.optString("title", "")),
                            description_c = o.optNullableString("description_c"),
                            due_date_c = o.optString("due_date_c", ""),
                            priority_c = o.optString("priority_c", "Normal"),
                            status_c = o.optString("status_c", "Pending"),
                            assigned_to_c = o.optNullableString("assigned_to_c"),
                            related_goat_id_c = o.optNullableString("related_goat_id_c"),
                            updated_at = System.currentTimeMillis(),
                            is_synced = true
                        )
                    )
                }
                if (list.isNotEmpty()) {
                    database.tasksDao().insertAll(list)
                }
            }
        } catch (e: Exception) {
            Log.w(tag, "Failed to download tasks: ${e.message}")
        }

        // 4. Weights
        try {
            val res = client.get("goat_weights_c", "order=date_c.desc")
            if (res.isSuccess) {
                val arr = res.getOrThrow()
                val list = mutableListOf<GoatWeightEntity>()
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    val id = o.optString("id")
                    if (id in pendingOps) continue
                    list.add(
                        GoatWeightEntity(
                            id = id,
                            goat_id_c = o.optString("goat_id_c"),
                            weight_kg_c = o.optDouble("weight_kg_c", 0.0),
                            date_c = o.optString("date_c", ""),
                            method_c = o.optString("method_c", "Scale"),
                            notes_c = o.optNullableString("notes_c"),
                            updated_at = System.currentTimeMillis(),
                            is_synced = true
                        )
                    )
                }
                if (list.isNotEmpty()) database.healthDao().insertAllWeights(list)
            }
        } catch (_: Exception) {}

        // 5. Vaccinations
        try {
            val res = client.get("vaccinations_c", "order=administered_date_c.desc")
            if (res.isSuccess) {
                val arr = res.getOrThrow()
                val list = mutableListOf<VaccinationEntity>()
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    val id = o.optString("id")
                    if (id in pendingOps) continue
                    list.add(
                        VaccinationEntity(
                            id = id,
                            goat_id_c = o.optString("goat_id_c"),
                            vaccine_c = o.optString("vaccine_c", ""),
                            dose_c = o.optString("dose_c", "1 ml"),
                            administered_date_c = o.optString("administered_date_c", ""),
                            next_due_date_c = o.optNullableString("next_due_date_c"),
                            batch_number_c = o.optNullableString("batch_number_c"),
                            administered_by_c = o.optNullableString("administered_by_c"),
                            notes_c = o.optNullableString("notes_c"),
                            updated_at = System.currentTimeMillis(),
                            is_synced = true
                        )
                    )
                }
                if (list.isNotEmpty()) database.healthDao().insertAllVaccinations(list)
            }
        } catch (_: Exception) {}

        // 6. Dewormings
        try {
            val res = client.get("deworming_records_c", "order=treatment_date_c.desc")
            if (res.isSuccess) {
                val arr = res.getOrThrow()
                val list = mutableListOf<DewormingEntity>()
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    val id = o.optString("id")
                    if (id in pendingOps) continue
                    list.add(
                        DewormingEntity(
                            id = id,
                            goat_id_c = o.optString("goat_id_c"),
                            medicine_c = o.optString("medicine_c", ""),
                            dose_c = o.optString("dose_c", "5 ml"),
                            treatment_date_c = o.optString("treatment_date_c", ""),
                            next_due_date_c = o.optNullableString("next_due_date_c"),
                            weight_at_treatment_c = if (o.has("weight_at_treatment_c") && !o.isNull("weight_at_treatment_c")) o.optDouble("weight_at_treatment_c") else null,
                            administered_by_c = o.optNullableString("administered_by_c"),
                            notes_c = o.optNullableString("notes_c"),
                            updated_at = System.currentTimeMillis(),
                            is_synced = true
                        )
                    )
                }
                if (list.isNotEmpty()) database.healthDao().insertAllDewormings(list)
            }
        } catch (_: Exception) {}

        // 7. Treatments
        try {
            val res = client.get("treatments_c", "order=start_date_c.desc")
            if (res.isSuccess) {
                val arr = res.getOrThrow()
                val list = mutableListOf<TreatmentEntity>()
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    val id = o.optString("id")
                    if (id in pendingOps) continue
                    list.add(
                        TreatmentEntity(
                            id = id,
                            goat_id_c = o.optString("goat_id_c"),
                            symptoms_c = o.optString("symptoms_c", ""),
                            diagnosis_c = o.optString("diagnosis_c", ""),
                            medicine_c = o.optString("medicine_c", ""),
                            dose_c = o.optString("dose_c", "2 ml"),
                            start_date_c = o.optString("start_date_c", ""),
                            end_date_c = o.optNullableString("end_date_c"),
                            veterinarian_c = o.optNullableString("veterinarian_c"),
                            outcome_c = o.optString("outcome_c", "Under Treatment"),
                            notes_c = o.optNullableString("notes_c"),
                            updated_at = System.currentTimeMillis(),
                            is_synced = true
                        )
                    )
                }
                if (list.isNotEmpty()) database.healthDao().insertAllTreatments(list)
            }
        } catch (_: Exception) {}

        // 8. Feed inventory
        try {
            val res = client.get("feed_inventory_c", "order=name_c.asc")
            if (res.isSuccess) {
                val arr = res.getOrThrow()
                val list = mutableListOf<FeedItemEntity>()
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    val id = o.optString("id")
                    if (id in pendingOps) continue
                    list.add(
                        FeedItemEntity(
                            id = id,
                            name_c = o.optString("name_c", ""),
                            category_c = o.optNullableString("category_c") ?: "Green Fodder",
                            current_stock_kg_c = o.optDouble("current_stock_kg_c", 0.0),
                            unit_c = o.optString("unit_c", "kg"),
                            cost_per_unit_c = if (o.has("cost_per_unit_c") && !o.isNull("cost_per_unit_c")) o.optDouble("cost_per_unit_c") else null,
                            updated_at = System.currentTimeMillis(),
                            is_synced = true
                        )
                    )
                }
                if (list.isNotEmpty()) database.inventoryDao().insertAllFeedItems(list)
            }
        } catch (_: Exception) {}

        // 9. Medicine inventory
        try {
            val res = client.get("medicine_inventory_c", "order=medicine_name_c.asc")
            if (res.isSuccess) {
                val arr = res.getOrThrow()
                val list = mutableListOf<MedicineEntity>()
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    val id = o.optString("id")
                    if (id in pendingOps) continue
                    list.add(
                        MedicineEntity(
                            id = id,
                            medicine_name_c = o.optString("medicine_name_c", ""),
                            category_c = o.optString("category_c", "Antibiotic"),
                            quantity_c = o.optDouble("quantity_c", 0.0),
                            unit_c = o.optString("unit_c", "ml"),
                            reorder_level_c = o.optDouble("reorder_level_c", 10.0),
                            unit_cost_c = if (o.has("unit_cost_c") && !o.isNull("unit_cost_c")) o.optDouble("unit_cost_c") else null,
                            expiry_date_c = o.optNullableString("expiry_date_c"),
                            supplier_c = o.optNullableString("supplier_c"),
                            updated_at = System.currentTimeMillis(),
                            is_synced = true
                        )
                    )
                }
                if (list.isNotEmpty()) database.inventoryDao().insertAllMedicines(list)
            }
        } catch (_: Exception) {}

        // 9. Farm Assets
        try {
            val res = client.get("farm_assets", "order=created_at.desc")
            if (res.isSuccess) {
                val arr = res.getOrThrow()
                val list = mutableListOf<FarmAssetEntity>()
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    val id = o.optString("id")
                    if (id in pendingOps) continue
                    val costVal = if (o.has("cost") && !o.isNull("cost")) o.optDouble("cost", 0.0) else 0.0
                    val bookVal = if (o.has("current_book_value") && !o.isNull("current_book_value")) {
                        o.optDouble("current_book_value", costVal)
                    } else costVal
                    list.add(
                        FarmAssetEntity(
                            id = id,
                            name = o.optString("name", "Farm Asset"),
                            category = o.optString("category", "Equipment"),
                            purchase_date = o.optNullableString("purchase_date"),
                            cost = costVal,
                            useful_life = if (o.has("useful_life") && !o.isNull("useful_life")) o.optInt("useful_life", 5) else 5,
                            current_condition = o.optString("current_condition", "Good"),
                            location = o.optString("location", "Main Shed"),
                            warranty_expiry = o.optNullableString("warranty_expiry"),
                            maintenance_schedule = o.optNullableString("maintenance_schedule") ?: "Monthly",
                            asset_id = o.optNullableString("asset_id"),
                            supplier = o.optNullableString("supplier"),
                            quantity = if (o.has("quantity") && !o.isNull("quantity")) o.optInt("quantity", 1) else 1,
                            status = o.optString("status", "Active"),
                            amc_expiry = o.optNullableString("amc_expiry"),
                            last_maintenance = o.optNullableString("last_maintenance"),
                            next_maintenance = o.optNullableString("next_maintenance"),
                            residual_value = if (o.has("residual_value") && !o.isNull("residual_value")) o.optDouble("residual_value", 0.0) else 0.0,
                            depreciation_method = o.optString("depreciation_method", "Straight-line"),
                            accumulated_depreciation = if (o.has("accumulated_depreciation") && !o.isNull("accumulated_depreciation")) o.optDouble("accumulated_depreciation", 0.0) else 0.0,
                            current_book_value = bookVal,
                            is_capex = if (o.has("is_capex")) o.optBoolean("is_capex", true) else true,
                            notes = o.optNullableString("notes"),
                            photo_url = o.optNullableString("photo_url"),
                            created_at = o.optNullableString("created_at"),
                            updated_at = System.currentTimeMillis(),
                            is_synced = true
                        )
                    )
                }
                if (list.isNotEmpty()) database.farmAssetDao().insertAll(list)
            }
        } catch (_: Exception) {}

        // 10. Financial Accounts
        try {
            val res = client.get("financial_accounts", "order=created_at.desc")
            if (res.isSuccess) {
                val arr = res.getOrThrow()
                val list = mutableListOf<FinancialAccountEntity>()
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    val id = o.optString("id")
                    if (id in pendingOps) continue
                    list.add(
                        FinancialAccountEntity(
                            id = id,
                            account_name = o.optString("account_name", "Account"),
                            account_type = o.optString("account_type", "CASH"),
                            account_number = o.optNullableString("account_number"),
                            bank_name = o.optNullableString("bank_name"),
                            ifsc_code = o.optNullableString("ifsc_code"),
                            branch = o.optNullableString("branch"),
                            opening_balance = o.optDouble("opening_balance", 0.0),
                            current_balance = o.optDouble("current_balance", 0.0),
                            opening_date = o.optNullableString("opening_date"),
                            is_active = o.optBoolean("is_active", true),
                            created_at = o.optNullableString("created_at"),
                            updated_at = System.currentTimeMillis(),
                            is_synced = true
                        )
                    )
                }
                if (list.isNotEmpty()) database.financialAccountDao().insertAll(list)
            }
        } catch (_: Exception) {}
    }

    suspend fun resolveConflict(conflictId: String, useLocal: Boolean) = withContext(Dispatchers.IO) {
        val conflicts = syncConflictDao.getUnresolvedConflictsFlow().firstOrNull() ?: emptyList()
        val conflict = conflicts.find { it.conflictId == conflictId } ?: return@withContext

        if (useLocal) {
            // Push local payload
            val payload = JSONObject(conflict.localPayloadJson)
            client.update(conflict.entityTable, "id=eq.${conflict.recordId}", payload)
        } else {
            // Apply remote payload to local database
            val remote = JSONObject(conflict.remotePayloadJson)
            if (conflict.entityTable == "sales_c") {
                val entity = SaleEntity(
                    id = conflict.recordId,
                    goat_id_c = remote.optString("goat_id_c"),
                    amount_c = remote.optDouble("amount_c", 0.0),
                    sale_date_c = remote.optString("sale_date_c", ""),
                    buyer_name_c = remote.optString("buyer_name_c", ""),
                    buyer_phone_c = remote.optString("buyer_phone_c", ""),
                    payment_mode_c = remote.optString("payment_mode_c", "Cash"),
                    payment_status_c = remote.optString("payment_status_c", "Received"),
                    notes_c = remote.optNullableString("notes_c"),
                    created_at = remote.optNullableString("created_at"),
                    is_synced = true
                )
                database.salesDao().insertOrUpdate(entity)
            }
        }

        syncConflictDao.resolveConflict(conflictId)
        syncQueueDao.deleteOperation(conflict.operationId)
    }

    private suspend fun handleRealtimeEvent(event: SupabaseRealtimeEvent) = withContext(Dispatchers.IO) {
        val pendingOps = syncQueueDao.getPendingOperations().map { it.recordId }.toSet()
        val record = event.record
        val oldRecord = event.oldRecord
        val recordId = record?.optString("id")?.ifBlank { null }
            ?: oldRecord?.optString("id")?.ifBlank { null }

        Log.i(tag, "Handling realtime event: ${event.eventType} on '${event.table}' (id=$recordId)")

        when (event.table.lowercase(Locale.ROOT)) {
            "goats_c" -> {
                if (event.eventType == SupabaseRealtimeEvent.EventType.DELETE) {
                    if (recordId != null && recordId !in pendingOps) {
                        database.goatDao().deleteById(recordId)
                    }
                } else if (record != null && recordId != null && recordId !in pendingOps) {
                    val goat = GoatEntity(
                        id = recordId,
                        name = record.optString("name", "Goat"),
                        tag_c = record.optString("tag_c", record.optString("tag", "")),
                        breed_c = record.optString("breed_c", record.optString("breed", "Boer")),
                        sex_c = record.optString("sex_c", record.optString("sex", "Doe")),
                        status_c = record.optString("status_c", record.optString("status", "Active")),
                        birth_date_c = record.optNullableString("birth_date_c"),
                        weight_kg_c = if (record.has("weight_kg_c") && !record.isNull("weight_kg_c")) record.optDouble("weight_kg_c") else null,
                        dam_c = record.optNullableString("dam_c"),
                        sire_c = record.optNullableString("sire_c"),
                        source_c = record.optString("source_c", "Born on farm"),
                        purchase_date_c = record.optNullableString("purchase_date_c"),
                        purchase_cost_c = if (record.has("purchase_cost_c") && !record.isNull("purchase_cost_c")) record.optDouble("purchase_cost_c") else null,
                        farm_location_c = record.optString("farm_location_c", "Barn A"),
                        color_c = record.optNullableString("color_c"),
                        notes_c = record.optNullableString("notes_c"),
                        created_at = record.optNullableString("created_at"),
                        updated_at = System.currentTimeMillis(),
                        is_synced = true,
                        origin_c = record.optNullableString("origin_c")
                    )
                    database.goatDao().insertOrUpdate(goat)
                }
            }
            "goat_weights_c" -> {
                if (event.eventType == SupabaseRealtimeEvent.EventType.DELETE) {
                    if (recordId != null) database.healthDao().deleteWeightById(recordId)
                } else if (record != null && recordId != null) {
                    val weight = GoatWeightEntity(
                        id = recordId,
                        goat_id_c = record.optString("goat_id_c"),
                        weight_kg_c = record.optDouble("weight_kg_c", 0.0),
                        date_c = record.optString("date_c", ""),
                        method_c = record.optString("method_c", "Scale"),
                        notes_c = record.optNullableString("notes_c"),
                        updated_at = System.currentTimeMillis(),
                        is_synced = true
                    )
                    database.healthDao().insertWeight(weight)
                }
            }
            "vaccinations_c" -> {
                if (event.eventType == SupabaseRealtimeEvent.EventType.DELETE) {
                    if (recordId != null) database.healthDao().deleteVaccinationById(recordId)
                } else if (record != null && recordId != null) {
                    val vacc = VaccinationEntity(
                        id = recordId,
                        goat_id_c = record.optString("goat_id_c"),
                        vaccine_c = record.optString("vaccine_c", ""),
                        dose_c = record.optString("dose_c", "1 ml"),
                        administered_date_c = record.optString("administered_date_c", ""),
                        next_due_date_c = record.optNullableString("next_due_date_c"),
                        batch_number_c = record.optNullableString("batch_number_c"),
                        administered_by_c = record.optNullableString("administered_by_c"),
                        notes_c = record.optNullableString("notes_c"),
                        updated_at = System.currentTimeMillis(),
                        is_synced = true
                    )
                    database.healthDao().insertVaccination(vacc)
                }
            }
            "deworming_records_c" -> {
                if (event.eventType == SupabaseRealtimeEvent.EventType.DELETE) {
                    if (recordId != null) database.healthDao().deleteDewormingById(recordId)
                } else if (record != null && recordId != null) {
                    val dew = DewormingEntity(
                        id = recordId,
                        goat_id_c = record.optString("goat_id_c"),
                        medicine_c = record.optString("medicine_c", ""),
                        dose_c = record.optString("dose_c", "5 ml"),
                        treatment_date_c = record.optString("treatment_date_c", ""),
                        next_due_date_c = record.optNullableString("next_due_date_c"),
                        weight_at_treatment_c = if (record.has("weight_at_treatment_c") && !record.isNull("weight_at_treatment_c")) record.optDouble("weight_at_treatment_c") else null,
                        administered_by_c = record.optNullableString("administered_by_c"),
                        notes_c = record.optNullableString("notes_c"),
                        updated_at = System.currentTimeMillis(),
                        is_synced = true
                    )
                    database.healthDao().insertDeworming(dew)
                }
            }
            "treatments_c" -> {
                if (event.eventType == SupabaseRealtimeEvent.EventType.DELETE) {
                    if (recordId != null) database.healthDao().deleteTreatmentById(recordId)
                } else if (record != null && recordId != null) {
                    val treat = TreatmentEntity(
                        id = recordId,
                        goat_id_c = record.optString("goat_id_c"),
                        symptoms_c = record.optString("symptoms_c", ""),
                        diagnosis_c = record.optString("diagnosis_c", ""),
                        medicine_c = record.optString("medicine_c", ""),
                        dose_c = record.optString("dose_c", "2 ml"),
                        start_date_c = record.optString("start_date_c", ""),
                        end_date_c = record.optNullableString("end_date_c"),
                        veterinarian_c = record.optNullableString("veterinarian_c"),
                        outcome_c = record.optString("outcome_c", "Under Treatment"),
                        notes_c = record.optNullableString("notes_c"),
                        updated_at = System.currentTimeMillis(),
                        is_synced = true
                    )
                    database.healthDao().insertTreatment(treat)
                }
            }
            "tasks_c" -> {
                if (event.eventType == SupabaseRealtimeEvent.EventType.DELETE) {
                    if (recordId != null && recordId !in pendingOps) {
                        database.tasksDao().deleteById(recordId)
                    }
                } else if (record != null && recordId != null && recordId !in pendingOps) {
                    val task = TaskEntity(
                        id = recordId,
                        title_c = record.optString("title_c", record.optString("title", "")),
                        description_c = record.optNullableString("description_c"),
                        due_date_c = record.optString("due_date_c", ""),
                        priority_c = record.optString("priority_c", "Normal"),
                        status_c = record.optString("status_c", "Pending"),
                        assigned_to_c = record.optNullableString("assigned_to_c"),
                        related_goat_id_c = record.optNullableString("related_goat_id_c"),
                        updated_at = System.currentTimeMillis(),
                        is_synced = true
                    )
                    database.tasksDao().insertOrUpdate(task)
                }
            }
            "sales_c" -> {
                if (event.eventType == SupabaseRealtimeEvent.EventType.DELETE) {
                    if (recordId != null && recordId !in pendingOps) {
                        database.salesDao().deleteById(recordId)
                    }
                } else if (record != null && recordId != null && recordId !in pendingOps) {
                    val sale = SaleEntity(
                        id = recordId,
                        goat_id_c = record.optString("goat_id_c"),
                        amount_c = record.optDouble("amount_c", 0.0),
                        sale_date_c = record.optString("sale_date_c", ""),
                        buyer_name_c = record.optString("buyer_name_c", ""),
                        buyer_phone_c = record.optString("buyer_phone_c", ""),
                        payment_mode_c = record.optString("payment_mode_c", "Cash"),
                        payment_status_c = record.optString("payment_status_c", "Received"),
                        notes_c = record.optNullableString("notes_c"),
                        created_at = record.optNullableString("created_at"),
                        updated_at = System.currentTimeMillis(),
                        is_synced = true
                    )
                    database.salesDao().insertOrUpdate(sale)
                }
            }
            "feed_inventory_c" -> {
                if (event.eventType == SupabaseRealtimeEvent.EventType.DELETE) {
                    if (recordId != null) database.inventoryDao().deleteFeedItemById(recordId)
                } else if (record != null && recordId != null) {
                    val feed = FeedItemEntity(
                        id = recordId,
                        name_c = record.optString("name_c", ""),
                        category_c = record.optNullableString("category_c") ?: "Green Fodder",
                        current_stock_kg_c = record.optDouble("current_stock_kg_c", 0.0),
                        unit_c = record.optString("unit_c", "kg"),
                        cost_per_unit_c = if (record.has("cost_per_unit_c") && !record.isNull("cost_per_unit_c")) record.optDouble("cost_per_unit_c") else null,
                        updated_at = System.currentTimeMillis(),
                        is_synced = true
                    )
                    database.inventoryDao().insertFeedItem(feed)
                }
            }
            "medicine_inventory_c" -> {
                if (event.eventType == SupabaseRealtimeEvent.EventType.DELETE) {
                    if (recordId != null) database.inventoryDao().deleteMedicineById(recordId)
                } else if (record != null && recordId != null) {
                    val med = MedicineEntity(
                        id = recordId,
                        medicine_name_c = record.optString("medicine_name_c", ""),
                        category_c = record.optString("category_c", "Antibiotic"),
                        quantity_c = record.optDouble("quantity_c", 0.0),
                        unit_c = record.optString("unit_c", "ml"),
                        reorder_level_c = record.optDouble("reorder_level_c", 10.0),
                        unit_cost_c = if (record.has("unit_cost_c") && !record.isNull("unit_cost_c")) record.optDouble("unit_cost_c") else null,
                        expiry_date_c = record.optNullableString("expiry_date_c"),
                        supplier_c = record.optNullableString("supplier_c"),
                        updated_at = System.currentTimeMillis(),
                        is_synced = true
                    )
                    database.inventoryDao().insertMedicine(med)
                }
            }
            "farm_assets" -> {
                if (event.eventType == SupabaseRealtimeEvent.EventType.DELETE) {
                    if (recordId != null && recordId !in pendingOps) {
                        database.farmAssetDao().deleteById(recordId)
                    }
                } else if (record != null && recordId != null && recordId !in pendingOps) {
                    val costVal = if (record.has("cost") && !record.isNull("cost")) record.optDouble("cost", 0.0) else 0.0
                    val asset = FarmAssetEntity(
                        id = recordId,
                        name = record.optString("name", "Farm Asset"),
                        category = record.optString("category", "Equipment"),
                        purchase_date = record.optNullableString("purchase_date"),
                        cost = costVal,
                        useful_life = if (record.has("useful_life") && !record.isNull("useful_life")) record.optInt("useful_life", 5) else 5,
                        current_condition = record.optString("current_condition", "Good"),
                        location = record.optString("location", "Main Shed"),
                        warranty_expiry = record.optNullableString("warranty_expiry"),
                        maintenance_schedule = record.optNullableString("maintenance_schedule") ?: "Monthly",
                        asset_id = record.optNullableString("asset_id"),
                        supplier = record.optNullableString("supplier"),
                        quantity = if (record.has("quantity") && !record.isNull("quantity")) record.optInt("quantity", 1) else 1,
                        status = record.optString("status", "Active"),
                        current_book_value = costVal,
                        is_capex = if (record.has("is_capex")) record.optBoolean("is_capex", true) else true,
                        notes = record.optNullableString("notes"),
                        photo_url = record.optNullableString("photo_url"),
                        created_at = record.optNullableString("created_at"),
                        updated_at = System.currentTimeMillis(),
                        is_synced = true
                    )
                    database.farmAssetDao().insertOrUpdate(asset)
                }
            }
            "breeding_records", "breeding_records_c", "local_breeding_records" -> {
                if (event.eventType == SupabaseRealtimeEvent.EventType.DELETE) {
                    if (recordId != null) database.breedingRecordDao().deleteBreedingRecord(recordId)
                } else if (record != null && recordId != null) {
                    val breed = BreedingRecordEntity(
                        id = recordId,
                        buck_id = record.optString("buck_id", ""),
                        doe_id = record.optString("doe_id", ""),
                        mating_date = record.optString("mating_date", ""),
                        expected_kidding_date = record.optString("expected_kidding_date", ""),
                        outcome_notes = record.optNullableString("outcome_notes"),
                        status = record.optString("status", "Active"),
                        created_at = record.optLong("created_at", System.currentTimeMillis()),
                        updated_at = System.currentTimeMillis(),
                        is_synced = true
                    )
                    database.breedingRecordDao().insertBreedingRecord(breed)
                }
            }
            "weaning_records" -> {
                if (event.eventType == SupabaseRealtimeEvent.EventType.DELETE) {
                    if (recordId != null) database.weaningDao().deleteWeaningRecord(recordId)
                } else if (record != null && recordId != null) {
                    val weaning = WeaningRecordEntity(
                        id = recordId,
                        farm_id = record.optString("farm_id", "default_farm"),
                        goat_id = record.optString("goat_id", ""),
                        birth_date = record.optString("birth_date", ""),
                        weaning_due_date = record.optString("weaning_due_date", ""),
                        actual_weaning_date = record.optNullableString("actual_weaning_date"),
                        status = record.optString("status", "PLANNED"),
                        notes = record.optNullableString("notes"),
                        created_at = record.optString("created_at", ""),
                        updated_at = System.currentTimeMillis(),
                        is_synced = true
                    )
                    database.weaningDao().insertWeaningRecord(weaning)
                }
            }
        }
    }

    private fun JSONObject.optNullableString(key: String): String? {
        if (!has(key) || isNull(key)) return null
        val str = optString(key)
        return if (str.isBlank() || str.equals("null", ignoreCase = true)) null else str
    }
}
