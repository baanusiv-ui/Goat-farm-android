package com.example.data.offline

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface SyncQueueDao {
    @Query("SELECT * FROM sync_queue WHERE syncStatus != 'COMPLETED' ORDER BY createdAt ASC")
    fun getAllPendingQueueFlow(): Flow<List<SyncQueueEntity>>

    @Query("SELECT * FROM sync_queue WHERE syncStatus IN ('PENDING', 'FAILED') ORDER BY createdAt ASC")
    suspend fun getPendingOperations(): List<SyncQueueEntity>

    @Query("SELECT COUNT(*) FROM sync_queue WHERE syncStatus IN ('PENDING', 'IN_PROGRESS', 'FAILED')")
    fun getPendingCountFlow(): Flow<Int>

    @Query("SELECT COUNT(*) FROM sync_queue WHERE syncStatus = 'FAILED'")
    fun getFailedCountFlow(): Flow<Int>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOperation(op: SyncQueueEntity)

    @Update
    suspend fun updateOperation(op: SyncQueueEntity)

    @Query("DELETE FROM sync_queue WHERE operationId = :operationId")
    suspend fun deleteOperation(operationId: String)

    @Query("SELECT * FROM sync_queue WHERE recordId = :recordId AND syncStatus != 'COMPLETED' LIMIT 1")
    suspend fun getPendingByRecordId(recordId: String): SyncQueueEntity?

    @Query("DELETE FROM sync_queue")
    suspend fun clearQueue()
}

@Dao
interface SyncConflictDao {
    @Query("SELECT * FROM sync_conflicts WHERE isResolved = 0 ORDER BY createdAt DESC")
    fun getUnresolvedConflictsFlow(): Flow<List<SyncConflictEntity>>

    @Query("SELECT COUNT(*) FROM sync_conflicts WHERE isResolved = 0")
    fun getUnresolvedConflictCountFlow(): Flow<Int>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertConflict(conflict: SyncConflictEntity)

    @Query("UPDATE sync_conflicts SET isResolved = 1 WHERE conflictId = :conflictId")
    suspend fun resolveConflict(conflictId: String)

    @Query("DELETE FROM sync_conflicts WHERE conflictId = :conflictId")
    suspend fun deleteConflict(conflictId: String)
}

@Dao
interface GoatDao {
    @Query("SELECT * FROM local_goats ORDER BY tag_c ASC")
    fun getAllGoatsFlow(): Flow<List<GoatEntity>>

    @Query("SELECT * FROM local_goats ORDER BY tag_c ASC")
    suspend fun getAllGoats(): List<GoatEntity>

    @Query("SELECT * FROM local_goats WHERE id = :id LIMIT 1")
    suspend fun getGoatById(id: String): GoatEntity?

    @Query("SELECT * FROM local_goats WHERE id = :id LIMIT 1")
    fun getGoatByIdFlow(id: String): Flow<GoatEntity?>

    @Query("SELECT * FROM local_goats WHERE tag_c = :tag LIMIT 1")
    suspend fun getGoatByTag(tag: String): GoatEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(goat: GoatEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(goats: List<GoatEntity>)

    @Query("UPDATE local_goats SET status_c = :status, updated_at = :updatedAt, is_synced = :isSynced WHERE id = :id")
    suspend fun updateStatus(id: String, status: String, updatedAt: Long = System.currentTimeMillis(), isSynced: Boolean = false)

    @Query("UPDATE local_goats SET weight_kg_c = :weight, updated_at = :updatedAt, is_synced = :isSynced WHERE id = :id")
    suspend fun updateWeight(id: String, weight: Double, updatedAt: Long = System.currentTimeMillis(), isSynced: Boolean = false)

    @Query("UPDATE local_goats SET health_status_c = :healthStatus, updated_at = :updatedAt, is_synced = 0 WHERE id = :id")
    suspend fun updateHealthStatus(id: String, healthStatus: String, updatedAt: Long = System.currentTimeMillis())

    @Transaction
    @Query("SELECT * FROM local_goats WHERE id = :goatId LIMIT 1")
    fun getGoatWithWeightHistoryFlow(goatId: String): Flow<GoatWithWeightHistory?>

    @Transaction
    @Query("SELECT * FROM local_goats WHERE id = :goatId LIMIT 1")
    suspend fun getGoatWithWeightHistory(goatId: String): GoatWithWeightHistory?

    @Transaction
    @Query("SELECT * FROM local_goats ORDER BY tag_c ASC")
    fun getAllGoatsWithWeightHistoryFlow(): Flow<List<GoatWithWeightHistory>>

    @Query("UPDATE local_goats SET name = :name, tag_c = :tag, breed_c = :breed, sex_c = :sex, status_c = :status, birth_date_c = :birthDate, color_c = :color, dam_c = :dam, sire_c = :sire, notes_c = :notes, updated_at = :updatedAt, is_synced = 0 WHERE id = :id")
    suspend fun updateGoatProfile(
        id: String,
        name: String,
        tag: String,
        breed: String,
        sex: String,
        status: String,
        birthDate: String?,
        color: String?,
        dam: String?,
        sire: String?,
        notes: String?,
        updatedAt: Long = System.currentTimeMillis()
    )

    @Query("SELECT DISTINCT breed_c FROM local_goats WHERE breed_c IS NOT NULL AND breed_c != '' ORDER BY breed_c ASC")
    suspend fun getAllBreeds(): List<String>

    @Query("UPDATE local_goats SET photo_url_c = :photoUrl, updated_at = :updatedAt, is_synced = 0 WHERE id = :id")
    suspend fun updateGoatPhoto(
        id: String,
        photoUrl: String?,
        updatedAt: Long = System.currentTimeMillis()
    )

    @Query("DELETE FROM local_goats WHERE id = :id")
    suspend fun deleteById(id: String)
}

@Dao
interface GoatPhotoDao {
    @Query("SELECT * FROM local_goat_photos WHERE goat_id_c = :goatId ORDER BY created_at DESC")
    fun getPhotosForGoatFlow(goatId: String): Flow<List<GoatPhotoEntity>>

    @Query("SELECT * FROM local_goat_photos WHERE goat_id_c = :goatId ORDER BY created_at DESC")
    suspend fun getPhotosForGoat(goatId: String): List<GoatPhotoEntity>

    @Query("SELECT * FROM local_goat_photos WHERE goat_id_c = :goatId AND is_primary_c = 1 LIMIT 1")
    suspend fun getPrimaryPhotoForGoat(goatId: String): GoatPhotoEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPhoto(photo: GoatPhotoEntity)

    @Query("DELETE FROM local_goat_photos WHERE id = :id")
    suspend fun deletePhotoById(id: String)

    @Query("UPDATE local_goat_photos SET is_primary_c = 0 WHERE goat_id_c = :goatId")
    suspend fun clearPrimaryPhotos(goatId: String)

    @Query("UPDATE local_goat_photos SET is_primary_c = 1 WHERE id = :photoId")
    suspend fun setPrimaryPhoto(photoId: String)
}

@Dao
interface HealthDao {
    // Weights
    @Query("SELECT * FROM local_goat_weights ORDER BY date_c DESC")
    suspend fun getAllWeights(): List<GoatWeightEntity>

    @Query("SELECT * FROM local_goat_weights ORDER BY date_c ASC")
    fun getAllWeightsFlow(): Flow<List<GoatWeightEntity>>

    @Query("SELECT * FROM local_goat_weights WHERE goat_id_c = :goatId ORDER BY date_c DESC")
    suspend fun getWeightsByGoat(goatId: String): List<GoatWeightEntity>

    @Query("SELECT * FROM local_goat_weights WHERE goat_id_c = :goatId ORDER BY date_c DESC")
    fun getWeightsByGoatFlow(goatId: String): Flow<List<GoatWeightEntity>>

    @Query("SELECT * FROM local_goat_weights WHERE goat_id_c = :goatId ORDER BY date_c DESC LIMIT 1")
    suspend fun getLatestWeightForGoat(goatId: String): GoatWeightEntity?

    @Query("DELETE FROM local_goat_weights WHERE id = :id")
    suspend fun deleteWeightById(id: String)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWeight(w: GoatWeightEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllWeights(list: List<GoatWeightEntity>)

    // Vaccinations
    @Query("SELECT * FROM local_vaccinations ORDER BY administered_date_c DESC")
    suspend fun getAllVaccinations(): List<VaccinationEntity>

    @Query("SELECT * FROM local_vaccinations ORDER BY administered_date_c ASC")
    fun getAllVaccinationsFlow(): Flow<List<VaccinationEntity>>

    @Query("SELECT * FROM local_vaccinations WHERE goat_id_c = :goatId ORDER BY administered_date_c DESC")
    suspend fun getVaccinationsByGoat(goatId: String): List<VaccinationEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertVaccination(v: VaccinationEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllVaccinations(list: List<VaccinationEntity>)

    @Query("DELETE FROM local_vaccinations WHERE id = :id")
    suspend fun deleteVaccinationById(id: String)

    // Dewormings
    @Query("SELECT * FROM local_dewormings ORDER BY treatment_date_c DESC")
    suspend fun getAllDewormings(): List<DewormingEntity>

    @Query("SELECT * FROM local_dewormings ORDER BY treatment_date_c ASC")
    fun getAllDewormingsFlow(): Flow<List<DewormingEntity>>

    @Query("SELECT * FROM local_dewormings WHERE goat_id_c = :goatId ORDER BY treatment_date_c DESC")
    suspend fun getDewormingsByGoat(goatId: String): List<DewormingEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDeworming(d: DewormingEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllDewormings(list: List<DewormingEntity>)

    @Query("DELETE FROM local_dewormings WHERE id = :id")
    suspend fun deleteDewormingById(id: String)

    // Treatments
    @Query("SELECT * FROM local_treatments ORDER BY start_date_c DESC")
    suspend fun getAllTreatments(): List<TreatmentEntity>

    @Query("SELECT * FROM local_treatments ORDER BY start_date_c ASC")
    fun getAllTreatmentsFlow(): Flow<List<TreatmentEntity>>

    @Query("SELECT * FROM local_treatments WHERE goat_id_c = :goatId ORDER BY start_date_c DESC")
    suspend fun getTreatmentsByGoat(goatId: String): List<TreatmentEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTreatment(t: TreatmentEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllTreatments(list: List<TreatmentEntity>)

    @Query("DELETE FROM local_treatments WHERE id = :id")
    suspend fun deleteTreatmentById(id: String)
}

@Dao
interface BreedingDao {
    // Matings
    @Query("SELECT * FROM local_matings ORDER BY mating_date_c DESC")
    suspend fun getAllMatings(): List<MatingEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMating(m: MatingEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllMatings(list: List<MatingEntity>)

    // Pregnancies
    @Query("SELECT * FROM local_pregnancies ORDER BY expected_kidding_date_c ASC")
    suspend fun getAllPregnancies(): List<PregnancyEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPregnancy(p: PregnancyEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllPregnancies(list: List<PregnancyEntity>)

    @Query("UPDATE local_pregnancies SET status_c = :status, updated_at = :updatedAt WHERE id = :id")
    suspend fun updatePregnancyStatus(id: String, status: String, updatedAt: Long = System.currentTimeMillis())

    // Kiddings
    @Query("SELECT * FROM local_kiddings ORDER BY kidding_date_c DESC")
    suspend fun getAllKiddings(): List<KiddingEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertKidding(k: KiddingEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllKiddings(list: List<KiddingEntity>)

    // Kids
    @Query("SELECT * FROM local_kids ORDER BY kid_tag_c ASC")
    suspend fun getAllKids(): List<KidEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertKid(k: KidEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllKids(list: List<KidEntity>)
}

@Dao
interface InventoryDao {
    // Feed Inventory
    @Query("SELECT * FROM local_feed_inventory ORDER BY name_c ASC")
    fun getAllFeedItemsFlow(): Flow<List<FeedItemEntity>>

    @Query("SELECT * FROM local_feed_inventory ORDER BY name_c ASC")
    suspend fun getAllFeedItems(): List<FeedItemEntity>

    @Query("SELECT * FROM local_feed_inventory WHERE id = :id LIMIT 1")
    suspend fun getFeedItemById(id: String): FeedItemEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFeedItem(f: FeedItemEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllFeedItems(list: List<FeedItemEntity>)

    @Query("UPDATE local_feed_inventory SET current_stock_kg_c = :newStock, updated_at = :updatedAt WHERE id = :id")
    suspend fun updateFeedStock(id: String, newStock: Double, updatedAt: Long = System.currentTimeMillis())

    // Feed Movements
    @Query("SELECT * FROM local_feed_movements ORDER BY date_c DESC, updated_at DESC")
    fun getAllFeedMovementsFlow(): Flow<List<FeedMovementEntity>>

    @Query("SELECT * FROM local_feed_movements WHERE feed_id_c = :feedId ORDER BY date_c DESC, updated_at DESC")
    fun getFeedMovementsByFeedFlow(feedId: String): Flow<List<FeedMovementEntity>>

    @Query("SELECT * FROM local_feed_movements ORDER BY date_c DESC")
    suspend fun getAllFeedMovements(): List<FeedMovementEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFeedMovement(m: FeedMovementEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllFeedMovements(list: List<FeedMovementEntity>)

    @Query("DELETE FROM local_feed_movements WHERE id = :id")
    suspend fun deleteFeedMovementById(id: String)

    // Medicine Inventory
    @Query("SELECT * FROM local_medicine_inventory ORDER BY medicine_name_c ASC")
    suspend fun getAllMedicines(): List<MedicineEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMedicine(m: MedicineEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllMedicines(list: List<MedicineEntity>)

    @Query("DELETE FROM local_feed_inventory WHERE id = :id")
    suspend fun deleteFeedItemById(id: String)

    @Query("DELETE FROM local_medicine_inventory WHERE id = :id")
    suspend fun deleteMedicineById(id: String)
}

@Dao
interface SalesDao {
    @Query("SELECT * FROM local_sales ORDER BY sale_date_c DESC, created_at DESC")
    fun getAllSalesFlow(): Flow<List<SaleEntity>>

    @Query("SELECT * FROM local_sales ORDER BY sale_date_c DESC, created_at DESC")
    suspend fun getAllSales(): List<SaleEntity>

    @Query("SELECT * FROM local_sales WHERE id = :id LIMIT 1")
    suspend fun getSaleById(id: String): SaleEntity?

    @Query("SELECT * FROM local_sales WHERE goat_id_c = :goatId LIMIT 1")
    suspend fun getSaleByGoatId(goatId: String): SaleEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(s: SaleEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(list: List<SaleEntity>)

    @Query("DELETE FROM local_sales WHERE id = :id")
    suspend fun deleteById(id: String)

    @Query("UPDATE local_sales SET payment_status_c = :status, updated_at = :updatedAt, is_synced = :isSynced WHERE id = :id")
    suspend fun updatePaymentStatus(id: String, status: String, updatedAt: Long = System.currentTimeMillis(), isSynced: Boolean = false)

    @Query("UPDATE local_sales SET payment_status_c = :status, payment_mode_c = :paymentMode, reference_c = :reference, transaction_id_c = :txnId, bank_transaction_id_c = :bankTxnId, failure_reason_c = :failureReason, payment_timestamp_c = :timestamp, updated_at = :updatedAt, is_synced = :isSynced WHERE id = :id")
    suspend fun updatePaymentDetails(
        id: String,
        status: String,
        paymentMode: String,
        reference: String?,
        txnId: String?,
        bankTxnId: String?,
        failureReason: String?,
        timestamp: String?,
        updatedAt: Long = System.currentTimeMillis(),
        isSynced: Boolean = false
    )

    @Query("SELECT * FROM local_sales WHERE order_id_c = :orderId LIMIT 1")
    suspend fun getSaleByOrderId(orderId: String): SaleEntity?

    @Query("UPDATE local_sales SET amount_paid_c = :amountPaid, balance_due_c = :balanceDue, payment_status_c = :status, updated_at = :updatedAt, is_synced = :isSynced WHERE id = :id")
    suspend fun updateCreditPayment(
        id: String,
        amountPaid: Double,
        balanceDue: Double,
        status: String,
        updatedAt: Long = System.currentTimeMillis(),
        isSynced: Boolean = false
    )

    @Query("UPDATE local_sales SET delivery_status_c = :deliveryStatus, updated_at = :updatedAt, is_synced = :isSynced WHERE id = :id")
    suspend fun updateDeliveryStatus(
        id: String,
        deliveryStatus: String,
        updatedAt: Long = System.currentTimeMillis(),
        isSynced: Boolean = false
    )

    @Query("UPDATE local_sales SET delivery_status_c = :deliveryStatus, actual_delivery_date_c = :actualDate, delivery_photo_uri_c = :photoUri, updated_at = :updatedAt, is_synced = :isSynced WHERE id = :id")
    suspend fun updateFullDelivery(
        id: String,
        deliveryStatus: String,
        actualDate: String?,
        photoUri: String?,
        updatedAt: Long = System.currentTimeMillis(),
        isSynced: Boolean = false
    )

    @Query("SELECT * FROM local_sales WHERE balance_due_c > 0 OR payment_mode_c = 'CREDIT' ORDER BY sale_date_c DESC")
    suspend fun getCreditSales(): List<SaleEntity>
}

@Dao
interface PaymentLedgerDao {
    @Query("SELECT * FROM local_payment_ledger WHERE sale_id_c = :saleId ORDER BY created_at ASC")
    suspend fun getPaymentsForSale(saleId: String): List<PaymentLedgerEntity>

    @Query("SELECT * FROM local_payment_ledger ORDER BY created_at DESC")
    suspend fun getAllPayments(): List<PaymentLedgerEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPayment(p: PaymentLedgerEntity)
}

@Dao
interface CustomerDao {
    @Query("SELECT * FROM local_customers ORDER BY name_c ASC")
    suspend fun getAllCustomers(): List<CustomerEntity>

    @Query("SELECT * FROM local_customers WHERE id = :id LIMIT 1")
    suspend fun getCustomerById(id: String): CustomerEntity?

    @Query("SELECT * FROM local_customers WHERE LOWER(TRIM(name_c)) = LOWER(TRIM(:name)) LIMIT 1")
    suspend fun getCustomerByName(name: String): CustomerEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(c: CustomerEntity)

    @Query("UPDATE local_customers SET outstanding_balance_c = :balance, total_purchases_c = :purchases, total_paid_c = :paid, updated_at = :updatedAt WHERE id = :id")
    suspend fun updateBalances(
        id: String,
        balance: Double,
        purchases: Double,
        paid: Double,
        updatedAt: Long = System.currentTimeMillis()
    )
}

@Dao
interface SmsReconciliationDao {
    @Query("SELECT * FROM local_sms_payment_candidates ORDER BY timestamp DESC")
    suspend fun getAllCandidates(): List<SmsPaymentCandidateEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCandidate(c: SmsPaymentCandidateEntity)

    @Query("UPDATE local_sms_payment_candidates SET status = :status, matchedSaleId = :matchedSaleId WHERE id = :id")
    suspend fun updateCandidateStatus(id: String, status: String, matchedSaleId: String?)

    @Query("DELETE FROM local_sms_payment_candidates WHERE id = :id")
    suspend fun deleteCandidate(id: String)
}

@Dao
interface TasksDao {
    @Query("SELECT * FROM local_tasks ORDER BY due_date_c ASC")
    suspend fun getAllTasks(): List<TaskEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(t: TaskEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(list: List<TaskEntity>)

    @Query("UPDATE local_tasks SET status_c = :status, updated_at = :updatedAt, is_synced = :isSynced WHERE id = :id")
    suspend fun updateTaskStatus(id: String, status: String, updatedAt: Long = System.currentTimeMillis(), isSynced: Boolean = false)

    @Query("DELETE FROM local_tasks WHERE id = :id")
    suspend fun deleteById(id: String)
}

@Dao
interface TransactionDao {
    @Query("SELECT * FROM local_transactions ORDER BY date_c DESC")
    suspend fun getAllTransactions(): List<TransactionEntity>

    @Query("DELETE FROM local_transactions WHERE id = :id")
    suspend fun deleteById(id: String)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTransaction(t: TransactionEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(list: List<TransactionEntity>)
}

@Dao
interface FarmSettingsDao {
    @Query("SELECT * FROM local_farm_settings WHERE `key` = :key LIMIT 1")
    suspend fun getSetting(key: String): FarmSettingEntity?

    @Query("SELECT * FROM local_farm_settings WHERE `key` = :key LIMIT 1")
    fun observeSetting(key: String): Flow<FarmSettingEntity?>

    @Query("SELECT * FROM local_farm_settings")
    suspend fun getAllSettings(): List<FarmSettingEntity>

    @Query("SELECT * FROM local_farm_settings")
    fun getAllSettingsFlow(): Flow<List<FarmSettingEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveSetting(s: FarmSettingEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(list: List<FarmSettingEntity>)
}

@Dao
interface BackupLogDao {
    @Query("SELECT * FROM local_backup_logs ORDER BY startedAt DESC")
    fun getAllBackupLogsFlow(): Flow<List<BackupLogEntity>>

    @Query("SELECT * FROM local_backup_logs ORDER BY startedAt DESC LIMIT 30")
    suspend fun getRecentBackupLogs(): List<BackupLogEntity>

    @Query("SELECT * FROM local_backup_logs WHERE status = 'SUCCESS' ORDER BY startedAt DESC LIMIT 1")
    suspend fun getLastSuccessfulBackup(): BackupLogEntity?

    @Query("SELECT * FROM local_backup_logs WHERE backupId = :backupId LIMIT 1")
    suspend fun getBackupById(backupId: String): BackupLogEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(log: BackupLogEntity)

    @Query("DELETE FROM local_backup_logs WHERE backupId = :id")
    suspend fun deleteById(id: String)
}

@Dao
interface DeliveryDao {
    @Query("SELECT * FROM local_delivery_records ORDER BY created_at DESC")
    fun getAllDeliveriesFlow(): Flow<List<DeliveryRecordEntity>>

    @Query("SELECT * FROM local_delivery_records ORDER BY created_at DESC")
    suspend fun getAllDeliveries(): List<DeliveryRecordEntity>

    @Query("SELECT * FROM local_delivery_records WHERE id = :id LIMIT 1")
    suspend fun getDeliveryById(id: String): DeliveryRecordEntity?

    @Query("SELECT * FROM local_delivery_records WHERE sale_id_c = :saleId LIMIT 1")
    suspend fun getDeliveryBySaleId(saleId: String): DeliveryRecordEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(delivery: DeliveryRecordEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(deliveries: List<DeliveryRecordEntity>)

    @Query("UPDATE local_delivery_records SET delivery_status_c = :status, actual_delivery_date_c = :actualDate, delivery_photo_uri_c = :photoUri, is_delivered = :isDelivered, updated_at = :updatedAt, is_synced = :isSynced WHERE id = :id")
    suspend fun updateDeliveryStatus(
        id: String,
        status: String,
        actualDate: String?,
        photoUri: String?,
        isDelivered: Boolean,
        updatedAt: Long = System.currentTimeMillis(),
        isSynced: Boolean = false
    )

    @Query("SELECT * FROM local_delivery_records WHERE is_delivered = 0 AND delivery_status_c != 'CANCELLED' ORDER BY expected_delivery_date_c ASC")
    suspend fun getPendingDeliveries(): List<DeliveryRecordEntity>
}

@Dao
interface MilkDao {
    @Query("SELECT * FROM local_milk_records ORDER BY date_c DESC")
    suspend fun getAllMilkRecords(): List<MilkRecordEntity>

    @Query("SELECT * FROM local_milk_records WHERE goat_id_c = :goatId ORDER BY date_c DESC")
    suspend fun getMilkRecordsForGoat(goatId: String): List<MilkRecordEntity>

    @Query("SELECT * FROM local_milk_records WHERE date_c = :date ORDER BY date_c DESC")
    suspend fun getMilkRecordsForDate(date: String): List<MilkRecordEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMilkRecord(record: MilkRecordEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(list: List<MilkRecordEntity>)
}

@Dao
interface AuditLogDao {
    @Query("SELECT * FROM local_audit_logs ORDER BY timestamp_c DESC")
    suspend fun getAllLogs(): List<AuditLogEntity>

    @Query("SELECT * FROM local_audit_logs ORDER BY timestamp_c DESC LIMIT :limit")
    suspend fun getRecentLogs(limit: Int = 100): List<AuditLogEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLog(log: AuditLogEntity)
}

@Dao
interface FarmAssetDao {
    @Query("SELECT * FROM local_farm_assets ORDER BY created_at DESC, name ASC")
    fun getAllAssetsFlow(): Flow<List<FarmAssetEntity>>

    @Query("SELECT * FROM local_farm_assets ORDER BY created_at DESC, name ASC")
    suspend fun getAllAssets(): List<FarmAssetEntity>

    @Query("SELECT * FROM local_farm_assets WHERE id = :id LIMIT 1")
    suspend fun getAssetById(id: String): FarmAssetEntity?

    @Query("SELECT * FROM local_farm_assets WHERE category = :category ORDER BY name ASC")
    suspend fun getAssetsByCategory(category: String): List<FarmAssetEntity>

    @Query("SELECT * FROM local_farm_assets WHERE status = :status ORDER BY name ASC")
    suspend fun getAssetsByStatus(status: String): List<FarmAssetEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(asset: FarmAssetEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(assets: List<FarmAssetEntity>)

    @Query("DELETE FROM local_farm_assets WHERE id = :id")
    suspend fun deleteById(id: String)

    @Query("SELECT SUM(cost) FROM local_farm_assets")
    suspend fun getTotalCapexCost(): Double?

    @Query("SELECT COUNT(*) FROM local_farm_assets")
    suspend fun getAssetCount(): Int
}

@Dao
interface BreedingRecordDao {
    @Query("SELECT * FROM local_breeding_records ORDER BY mating_date DESC")
    suspend fun getAllBreedingRecords(): List<BreedingRecordEntity>

    @Query("SELECT * FROM local_breeding_records ORDER BY mating_date DESC")
    fun getAllBreedingRecordsFlow(): Flow<List<BreedingRecordEntity>>

    @Query("SELECT * FROM local_breeding_records WHERE doe_id = :goatId OR buck_id = :goatId ORDER BY mating_date DESC")
    suspend fun getBreedingRecordsForGoat(goatId: String): List<BreedingRecordEntity>

    @Query("SELECT * FROM local_breeding_records WHERE doe_id = :goatId OR buck_id = :goatId ORDER BY mating_date DESC")
    fun getBreedingRecordsForGoatFlow(goatId: String): Flow<List<BreedingRecordEntity>>

    @Query("UPDATE local_breeding_records SET status = :status, outcome_notes = :notes, updated_at = :updatedAt WHERE id = :id")
    suspend fun updateBreedingRecordStatus(id: String, status: String, notes: String?, updatedAt: Long = System.currentTimeMillis())

    @Query("SELECT * FROM local_breeding_records WHERE id = :id LIMIT 1")
    suspend fun getBreedingRecordById(id: String): BreedingRecordEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBreedingRecord(record: BreedingRecordEntity)

    @Query("DELETE FROM local_breeding_records WHERE id = :id")
    suspend fun deleteBreedingRecord(id: String)
}

