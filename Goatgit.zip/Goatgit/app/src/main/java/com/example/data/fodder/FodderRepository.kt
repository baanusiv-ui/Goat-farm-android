package com.example.data.fodder

import android.util.Log
import com.example.data.offline.*
import com.example.data.weather.WeatherReport
import com.example.data.weather.WeatherService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.TimeUnit

data class FodderStockSummary(
    val totalHarvestedKg: Double = 0.0,
    val totalPurchasedKg: Double = 0.0,
    val totalConsumedKg: Double = 0.0,
    val totalHomeGrownConsumedKg: Double = 0.0,
    val totalPurchasedConsumedKg: Double = 0.0,
    val totalWastageKg: Double = 0.0,
    val currentBalanceKg: Double = 0.0,
    val currentHomeGrownBalanceKg: Double = 0.0,
    val currentPurchasedBalanceKg: Double = 0.0,
    val actualHomeGrownCostPerKg: Double = 1.75,
    val avgPurchasedCostPerKg: Double = 3.50,
    val dailyHerdConsumptionRateKg: Double = 0.0,
    val daysOfStockRemaining: Int = 0
)

data class FodderPlannerData(
    val totalGoats: Int = 0,
    val adultDoes: Int = 0,
    val lactatingDoes: Int = 0,
    val adultBucks: Int = 0,
    val kidsWeaners: Int = 0,
    val dailyRequirementKg: Double = 0.0,
    val monthlyRequirementKg: Double = 0.0,
    val dailyProductionYieldKg: Double = 0.0,
    val monthlyProductionYieldKg: Double = 0.0,
    val dailySurplusDeficitKg: Double = 0.0,
    val isSelfSufficient: Boolean = false,
    val requiredAcreageForSelfSufficiency: Double = 0.0,
    val currentCultivatedAcreage: Double = 0.0
)

data class FodderCultivationTechnique(
    val id: String,
    val cropName: String,
    val scientificName: String,
    val category: String,
    val soilAndClimate: String,
    val landPreparation: String,
    val propagationAndSpacing: String,
    val seedOrSlipRate: String,
    val fertilizerDosage: String,
    val irrigationSchedule: String,
    val harvestingProtocol: String,
    val firstCutDays: String,
    val regrowthInterval: String,
    val expectedAnnualYield: String,
    val crudeProteinPct: Double,
    val dryMatterPct: Double,
    val feedingGuidelinesForGoats: String,
    val silageSuitability: String,
    val precautionsAndAntiNutritional: String
)

data class CultivationCalendarEvent(
    val id: String,
    val plotId: String,
    val plotName: String,
    val speciesName: String,
    val eventDate: String,
    val eventType: String, // Sowing, First Cut Due, Regrowth Cut Due, Fertilization, Irrigation, Overdue
    val description: String,
    val isCompleted: Boolean = false,
    val isOverdue: Boolean = false
)

data class FodderDashboardMetrics(
    val totalFields: Int = 0,
    val totalCultivatedAreaAcres: Double = 0.0,
    val totalRows: Int = 0,
    val totalRowLengthMetres: Double = 0.0,
    val rowsDueForCutting: Int = 0,
    val rowsHarvestedToday: Int = 0,
    val productionTodayKg: Double = 0.0,
    val productionThisMonthKg: Double = 0.0,
    val speciesCount: Int = 0,
    val nextCuttingDate: String? = null,
    val stockSummary: FodderStockSummary = FodderStockSummary()
)

data class PlotCuttingPlan(
    val plot: FodderPlotEntity,
    val totalRows: Int,
    val rowsPlanted: List<FodderRowEntity>,
    val rowsAvailable: List<FodderRowEntity>,
    val rowsHarvestedToday: List<FodderRowEntity>,
    val rowsPreviouslyHarvested: List<FodderRowEntity>,
    val rowsDue: List<FodderRowEntity>,
    val remainingRows: List<FodderRowEntity>,
    val lastCuttingDate: String?,
    val nextExpectedCuttingDate: String?
)

data class RowHarvestHistoryItem(
    val rowCode: String,
    val plantingDate: String?,
    val plantingMethod: String?,
    val cuttings: List<FodderCuttingEntity>,
    val activities: List<FodderActivityEntity>,
    val nextExpectedCutDate: String?,
    val totalCuts: Int,
    val totalYieldKg: Double,
    val currentStatus: String
)

data class CropCostSummary(
    val totalCost: Double = 0.0,
    val seedMaterialCost: Double = 0.0,
    val fertilizerCost: Double = 0.0,
    val irrigationCost: Double = 0.0,
    val labourCost: Double = 0.0,
    val otherCost: Double = 0.0,
    val totalRows: Int = 0,
    val totalRowLengthM: Double = 0.0,
    val totalHarvestedKg: Double = 0.0,
    val costPerRow: Double = 0.0,
    val costPerMetre: Double = 0.0,
    val costPerKgHarvested: Double = 0.0
)

data class SpeciesReportItem(
    val speciesName: String,
    val category: String,
    val crudeProteinPct: Double,
    val totalPlots: Int,
    val totalAreaAcres: Double,
    val totalHarvestedKg: Double,
    val totalCuts: Int,
    val avgYieldPerCutKg: Double
)

data class PlotReportItem(
    val plotId: String,
    val plotName: String,
    val speciesName: String,
    val areaAcres: Double,
    val currentCutCount: Int,
    val totalHarvestedKg: Double,
    val yieldPerAcreKg: Double,
    val daysSinceLastCut: Int?,
    val daysUntilNextCut: Int?,
    val regrowthProgressPct: Int,
    val status: String,
    val totalRows: Int = 0,
    val totalRowLengthM: Double = 0.0,
    val harvestedRowCount: Int = 0
)

class FodderRepository(
    private val database: AppDatabase,
    private val syncManager: OfflineSyncManager,
    val weatherService: WeatherService = WeatherService()
) {
    companion object {
        private const val TAG = "FodderRepository"
    }

    private val fodderDao = database.fodderDao()
    private val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.US)

    // Flow getters
    val speciesFlow: Flow<List<FodderSpeciesEntity>> = fodderDao.getAllSpeciesFlow()
    val plotsFlow: Flow<List<FodderPlotEntity>> = fodderDao.getAllPlotsFlow()
    val cuttingsFlow: Flow<List<FodderCuttingEntity>> = fodderDao.getAllCuttingsFlow()
    val feedingsFlow: Flow<List<FodderFeedingEntity>> = fodderDao.getAllFeedingsFlow()
    val adjustmentsFlow: Flow<List<FodderStockAdjustmentEntity>> = fodderDao.getAllStockAdjustmentsFlow()
    val materialsFlow: Flow<List<FodderPlantingMaterialEntity>> = fodderDao.getAllMaterialsFlow()
    val activitiesFlow: Flow<List<FodderActivityEntity>> = fodderDao.getAllActivitiesFlow()

    fun getRowsForPlotFlow(plotId: String): Flow<List<FodderRowEntity>> = fodderDao.getRowsByPlotFlow(plotId)
    fun getCropCyclesForPlotFlow(plotId: String): Flow<List<FodderCropCycleEntity>> = fodderDao.getCropCyclesByPlotFlow(plotId)
    fun getActivitiesForPlotFlow(plotId: String): Flow<List<FodderActivityEntity>> = fodderDao.getActivitiesByPlotFlow(plotId)

    // ==========================================
    // INITIALIZATION & PRE-POPULATION
    // ==========================================
    suspend fun initializeDefaultDataIfEmpty() = withContext(Dispatchers.IO) {
        val existingSpecies = fodderDao.getAllSpecies()
        if (existingSpecies.isEmpty()) {
            Log.d(TAG, "Pre-populating recommended goat fodder species...")
            val defaults = listOf(
                FodderSpeciesEntity(
                    id = "sp-super-napier",
                    name = "Super Napier (Pakchong 1)",
                    scientific_name = "Pennisetum purpureum x Pennisetum americanum",
                    category = "Perennial Grass",
                    crude_protein_pct = 16.5,
                    dry_matter_pct = 20.0,
                    days_to_first_cut = 75,
                    regrowth_interval_days = 42,
                    cutting_height_cm = 15.0,
                    expected_yield_per_acre_cut_kg = 20000.0,
                    water_requirement = "Medium",
                    notes = "Very juicy, tender stems, high tillering (up to 400 tons/ha/year). Top goat choice."
                ),
                FodderSpeciesEntity(
                    id = "sp-lucerne",
                    name = "Lucerne / Alfalfa (Queen of Fodder)",
                    scientific_name = "Medicago sativa",
                    category = "Legume Fodder",
                    crude_protein_pct = 21.0,
                    dry_matter_pct = 24.0,
                    days_to_first_cut = 55,
                    regrowth_interval_days = 28,
                    cutting_height_cm = 5.0,
                    expected_yield_per_acre_cut_kg = 8000.0,
                    water_requirement = "Medium",
                    notes = "Rich in calcium, vitamin A, and crude protein. Ideal for lactating does and kids."
                ),
                FodderSpeciesEntity(
                    id = "sp-cofs29",
                    name = "CoFS-29 Multicut Sorghum",
                    scientific_name = "Sorghum bicolor",
                    category = "Cereal Fodder",
                    crude_protein_pct = 11.5,
                    dry_matter_pct = 22.0,
                    days_to_first_cut = 60,
                    regrowth_interval_days = 40,
                    cutting_height_cm = 10.0,
                    expected_yield_per_acre_cut_kg = 16000.0,
                    water_requirement = "Low",
                    notes = "Drought tolerant, perennial 3-year multi-cut cereal with high palatability."
                ),
                FodderSpeciesEntity(
                    id = "sp-hedge-lucerne",
                    name = "Hedge Lucerne (Velimasal)",
                    scientific_name = "Desmanthus virgatus",
                    category = "Legume Fodder",
                    crude_protein_pct = 19.5,
                    dry_matter_pct = 25.0,
                    days_to_first_cut = 65,
                    regrowth_interval_days = 40,
                    cutting_height_cm = 20.0,
                    expected_yield_per_acre_cut_kg = 12000.0,
                    water_requirement = "Low",
                    notes = "Deep-rooted perennial legume, does not cause bloat, ideal companion for Super Napier."
                ),
                FodderSpeciesEntity(
                    id = "sp-co4",
                    name = "CO-4 Hybrid Napier",
                    scientific_name = "Pennisetum purpureum",
                    category = "Perennial Grass",
                    crude_protein_pct = 12.0,
                    dry_matter_pct = 20.0,
                    days_to_first_cut = 75,
                    regrowth_interval_days = 45,
                    cutting_height_cm = 15.0,
                    expected_yield_per_acre_cut_kg = 18000.0,
                    water_requirement = "Medium",
                    notes = "Robust tillering hybrid grass widely adapted across diverse soils."
                ),
                FodderSpeciesEntity(
                    id = "sp-guinea",
                    name = "Guinea Grass (Hamil)",
                    scientific_name = "Megathyrsus maximus",
                    category = "Perennial Grass",
                    crude_protein_pct = 13.5,
                    dry_matter_pct = 21.0,
                    days_to_first_cut = 60,
                    regrowth_interval_days = 35,
                    cutting_height_cm = 15.0,
                    expected_yield_per_acre_cut_kg = 14000.0,
                    water_requirement = "Medium",
                    notes = "Tolerates partial shade, rapid regrowth, succulent leaves goats love."
                ),
                FodderSpeciesEntity(
                    id = "sp-subabul",
                    name = "Subabul (Leucaena)",
                    scientific_name = "Leucaena leucocephala",
                    category = "Tree Fodder / Browse",
                    crude_protein_pct = 23.0,
                    dry_matter_pct = 28.0,
                    days_to_first_cut = 90,
                    regrowth_interval_days = 50,
                    cutting_height_cm = 80.0,
                    expected_yield_per_acre_cut_kg = 10000.0,
                    water_requirement = "Low",
                    notes = "Excellent high-protein tree browse for goats; feed up to 30% of daily ration."
                )
            )
            fodderDao.insertAllSpecies(defaults)
        }

        // Initialize default master settings if not present
        initializeDefaultMasterSettings()

        val existingPlots = fodderDao.getAllPlots()
        if (existingPlots.isEmpty()) {
            val now = System.currentTimeMillis()
            val cal = Calendar.getInstance()

            cal.timeInMillis = now - (68L * 24 * 60 * 60 * 1000)
            val sowing1 = dateFormat.format(cal.time)

            cal.timeInMillis = now - (110L * 24 * 60 * 60 * 1000)
            val sowing2 = dateFormat.format(cal.time)

            cal.timeInMillis = now - (18L * 24 * 60 * 60 * 1000)
            val lastCut2 = dateFormat.format(cal.time)

            cal.timeInMillis = now + (10L * 24 * 60 * 60 * 1000)
            val nextCut2 = dateFormat.format(cal.time)

            // Field A: 40 rows, 25m each, 1m spacing
            val plot1 = FodderPlotEntity(
                id = "plot-north-super-napier",
                plot_name = "Field A - Super Napier",
                area_value = 1.0,
                area_unit = "Acres",
                variety = "Pakchong 1",
                row_count = 40,
                row_length = 25.0,
                row_length_unit = "metre",
                row_spacing = 1.0,
                row_spacing_unit = "metre",
                calculated_cultivated_area = 40.0 * 25.0 * 1.0, // 1000 sq.m
                calculated_area_unit = "sq.m",
                latitude = 11.0185,
                longitude = 76.9582,
                gps_accuracy = 3.5f,
                location_tag = "Near Main Well",
                species_id = "sp-super-napier",
                species_name = "Super Napier (Pakchong 1)",
                sowing_date = sowing1,
                crop_cycle_status = "Due for cutting",
                current_cut_count = 0,
                next_expected_cut_date = dateFormat.format(Date(now + (2L * 24 * 60 * 60 * 1000))),
                irrigation_type = "Drip",
                soil_type = "Red Loam",
                notes = "Field A with 40 rows of 25m length. Ready for harvest."
            )

            val plot2 = FodderPlotEntity(
                id = "plot-river-lucerne",
                plot_name = "Field B - Lucerne",
                area_value = 0.75,
                area_unit = "Acres",
                variety = "Anand 2",
                row_count = 30,
                row_length = 20.0,
                row_length_unit = "metre",
                row_spacing = 0.5,
                row_spacing_unit = "metre",
                calculated_cultivated_area = 30.0 * 20.0 * 0.5, // 300 sq.m
                calculated_area_unit = "sq.m",
                latitude = 11.0142,
                longitude = 76.9531,
                gps_accuracy = 4.2f,
                location_tag = "Sector B South",
                species_id = "sp-lucerne",
                species_name = "Lucerne / Alfalfa (Queen of Fodder)",
                sowing_date = sowing2,
                crop_cycle_status = "Regrowth Stage",
                current_cut_count = 2,
                last_cut_date = lastCut2,
                next_expected_cut_date = nextCut2,
                irrigation_type = "Sprinkler",
                soil_type = "Sandy Loam",
                notes = "30 rows lucerne pasture."
            )

            fodderDao.insertOrUpdatePlot(plot1)
            fodderDao.insertOrUpdatePlot(plot2)

            // Generate initial rows for Plot 1
            generateRowsForPlot(plot1, initialStatus = "Due for cutting")
            // Generate initial rows for Plot 2
            generateRowsForPlot(plot2, initialStatus = "Regrowth")

            // Seed initial crop cycle
            fodderDao.insertCropCycle(
                FodderCropCycleEntity(
                    id = "cycle-plot1-c1",
                    plot_id = plot1.id,
                    cycle_number = 1,
                    cycle_name = "Crop Cycle 1",
                    species_name = plot1.species_name,
                    variety = plot1.variety,
                    planting_date = sowing1,
                    planting_method = "Slips",
                    row_codes = "R01–R40",
                    rows_count = 40,
                    status = "Active",
                    start_date = sowing1
                )
            )

            // Seed initial planting material
            val sampleMaterial = FodderPlantingMaterialEntity(
                id = "mat-napier-slips-1",
                material_type = "Slips",
                species_name = "Super Napier (Pakchong 1)",
                variety = "Pakchong 1",
                quantity_purchased = 4000.0,
                quantity_used = 3200.0,
                quantity_remaining = 800.0,
                unit = "slips",
                unit_cost = 0.50,
                total_cost = 2000.0,
                supplier = "State Agronomy Nursery",
                purchase_date = sowing1,
                batch_lot_number = "LOT-NAP-2026-01",
                notes = "High-tillering healthy vegetative stem slips"
            )
            fodderDao.insertOrUpdateMaterial(sampleMaterial)

            // Seed an activity log
            fodderDao.insertActivity(
                FodderActivityEntity(
                    id = "act-sowing-plot1",
                    plot_id = plot1.id,
                    plot_name = plot1.plot_name,
                    crop_cycle_id = "cycle-plot1-c1",
                    row_codes = "R01–R40",
                    species_name = plot1.species_name,
                    variety = plot1.variety,
                    activity_type = "Planting slips",
                    activity_date = sowing1,
                    quantity = 3200.0,
                    unit = "slips",
                    labour_hours = 16.0,
                    labour_cost = 60.0,
                    material_cost = 1600.0,
                    total_cost = 1660.0,
                    weather_temp_c = 28.5,
                    weather_condition = "Partly Cloudy",
                    notes = "Planted all 40 rows with 2 slips per hill at 1m spacing"
                )
            )
        }
    }

    private suspend fun initializeDefaultMasterSettings() {
        val defaultSettings = mapOf(
            "planting_methods" to "Seed,Direct sowing,Transplanting,Cuttings,Slips,Rooted slips,Vegetative propagation,Other",
            "cutting_methods" to "Hand Sickle,Brush Cutter,Forage Harvester,Mechanical Mower,Manual Chaff Harvester",
            "row_units" to "metre,feet",
            "spacing_units" to "metre,feet,cm,inches",
            "area_units" to "Acres,Hectares,Guntas,Cents,sq.m",
            "activity_types" to "Land preparation,Bed preparation,Seed purchase,Seed treatment,Sowing,Transplanting,Planting slips,Planting cuttings,Fertilization,Irrigation,Weeding,Pest control,Disease treatment,First cutting,Regrowth,Subsequent cutting,Wastage,Other",
            "crop_statuses" to "Planted,Growing,Due for cutting,Harvested,Regrowth,Damaged,Replanted,Abandoned"
        )
        for ((key, value) in defaultSettings) {
            val existing = fodderDao.getMasterSettingByKey(key)
            if (existing == null) {
                fodderDao.insertMasterSetting(FodderMasterSettingEntity(setting_key = key, setting_values_csv = value))
            }
        }
    }

    suspend fun getMasterSettingOptions(key: String): List<String> = withContext(Dispatchers.IO) {
        val setting = fodderDao.getMasterSettingByKey(key)
        setting?.setting_values_csv?.split(",")?.map { it.trim() }?.filter { it.isNotEmpty() } ?: emptyList()
    }

    suspend fun saveMasterSettingOptions(key: String, options: List<String>) = withContext(Dispatchers.IO) {
        fodderDao.insertMasterSetting(
            FodderMasterSettingEntity(
                setting_key = key,
                setting_values_csv = options.joinToString(","),
                updated_at = System.currentTimeMillis()
            )
        )
    }

    // ==========================================
    // FIELD ROW MASTER & PLOT MANAGEMENT
    // ==========================================
    suspend fun savePlot(
        plot: FodderPlotEntity,
        autoGenerateRows: Boolean = true
    ): Result<FodderPlotEntity> = withContext(Dispatchers.IO) {
        try {
            // Calculate row-based estimates
            val totalRowLength = plot.row_count * plot.row_length
            val calculatedArea = plot.row_count * plot.row_length * plot.row_spacing

            val updatedPlot = plot.copy(
                calculated_cultivated_area = calculatedArea,
                calculated_area_unit = if (plot.row_length_unit.equals("feet", ignoreCase = true)) "sq.ft" else "sq.m",
                updated_at = System.currentTimeMillis()
            )

            fodderDao.insertOrUpdatePlot(updatedPlot)

            if (autoGenerateRows) {
                val existingRows = fodderDao.getRowsByPlot(updatedPlot.id)
                if (existingRows.isEmpty() || existingRows.size != updatedPlot.row_count) {
                    generateRowsForPlot(updatedPlot, initialStatus = "Growing")
                }
            }

            // Sync queue
            enqueueFodderSync("local_fodder_plots", updatedPlot.id, "UPSERT", JSONObject().apply {
                put("id", updatedPlot.id)
                put("plot_name", updatedPlot.plot_name)
                put("area_value", updatedPlot.area_value)
                put("area_unit", updatedPlot.area_unit)
                put("variety", updatedPlot.variety)
                put("row_count", updatedPlot.row_count)
                put("row_length", updatedPlot.row_length)
                put("row_spacing", updatedPlot.row_spacing)
                put("species_id", updatedPlot.species_id)
                put("species_name", updatedPlot.species_name)
            })

            Result.success(updatedPlot)
        } catch (e: Exception) {
            Log.e(TAG, "Error saving plot", e)
            Result.failure(e)
        }
    }

    suspend fun generateRowsForPlot(
        plot: FodderPlotEntity,
        initialStatus: String = "Growing"
    ) = withContext(Dispatchers.IO) {
        val rows = (1..plot.row_count).map { idx ->
            val code = "R%02d".format(idx)
            FodderRowEntity(
                id = "${plot.id}-r$idx",
                plot_id = plot.id,
                row_index = idx,
                row_code = code,
                species_name = plot.species_name,
                variety = plot.variety,
                status = initialStatus,
                length_m = plot.row_length,
                spacing_m = plot.row_spacing,
                planting_date = plot.sowing_date,
                planting_method = "Slips",
                next_expected_cut_date = plot.next_expected_cut_date,
                updated_at = System.currentTimeMillis()
            )
        }
        fodderDao.deleteRowsByPlot(plot.id)
        fodderDao.insertAllRows(rows)
    }

    suspend fun deletePlot(id: String) = withContext(Dispatchers.IO) {
        fodderDao.deleteRowsByPlot(id)
        fodderDao.deletePlotById(id)
        enqueueFodderSync("local_fodder_plots", id, "DELETE", JSONObject().apply { put("id", id) })
    }

    suspend fun updateRowStatus(rowId: String, status: String) = withContext(Dispatchers.IO) {
        fodderDao.updateRowStatus(rowId, status, System.currentTimeMillis())
    }

    // ==========================================
    // REPLANTING & CROP CYCLES
    // ==========================================
    suspend fun replantRow(
        plotId: String,
        rowCode: String,
        speciesName: String,
        variety: String?,
        plantingDate: String,
        plantingMethod: String,
        materialQuantity: Double,
        materialUnit: String,
        source: String?,
        cost: Double,
        notes: String?
    ): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val plot = fodderDao.getPlotById(plotId) ?: throw IllegalArgumentException("Plot not found")
            val row = fodderDao.getRowByCode(plotId, rowCode) ?: throw IllegalArgumentException("Row $rowCode not found")

            // Create a crop cycle entry for this replant if new
            val existingCycles = fodderDao.getCropCyclesByPlot(plotId)
            val newCycleNumber = existingCycles.size + 1
            val cycleId = UUID.randomUUID().toString()

            val cropCycle = FodderCropCycleEntity(
                id = cycleId,
                plot_id = plotId,
                cycle_number = newCycleNumber,
                cycle_name = "Crop Cycle $newCycleNumber ($rowCode Replant)",
                species_name = speciesName,
                variety = variety,
                planting_date = plantingDate,
                planting_method = plantingMethod,
                row_codes = rowCode,
                rows_count = 1,
                status = "Active",
                start_date = plantingDate,
                notes = notes
            )
            fodderDao.insertCropCycle(cropCycle)

            // Update row entity to Replanted / Growing
            val updatedRow = row.copy(
                crop_cycle_id = cycleId,
                species_name = speciesName,
                variety = variety,
                status = "Replanted",
                planting_date = plantingDate,
                planting_method = plantingMethod,
                last_cut_date = null,
                next_expected_cut_date = dateFormat.format(Date(System.currentTimeMillis() + (60L * 24 * 60 * 60 * 1000))),
                notes = "Replanted on $plantingDate. $notes",
                updated_at = System.currentTimeMillis()
            )
            fodderDao.insertOrUpdateRow(updatedRow)

            // Log activity
            val act = FodderActivityEntity(
                plot_id = plotId,
                plot_name = plot.plot_name,
                crop_cycle_id = cycleId,
                row_codes = rowCode,
                species_name = speciesName,
                variety = variety,
                activity_type = if (plantingMethod.contains("slip", ignoreCase = true)) "Planting slips" else "Transplanting",
                activity_date = plantingDate,
                quantity = materialQuantity,
                unit = materialUnit,
                material_cost = cost,
                total_cost = cost,
                notes = "Replanted $rowCode from source: ${source ?: "Farm Stock"}. $notes"
            )
            fodderDao.insertActivity(act)

            Result.success(Unit)
        } catch (e: Exception) {
            Log.e(TAG, "Error replanting row", e)
            Result.failure(e)
        }
    }

    suspend fun getRowHarvestHistory(plotId: String, rowCode: String): RowHarvestHistoryItem = withContext(Dispatchers.IO) {
        val row = fodderDao.getRowByCode(plotId, rowCode)
        val allCuttings = fodderDao.getCuttingsByPlot(plotId)
        val allActivities = fodderDao.getAllActivities()

        // Filter cuttings that include this row code or "All Rows"
        val rowCuttings = allCuttings.filter { c ->
            c.row_codes.equals("All Rows", ignoreCase = true) ||
            c.row_codes.contains(rowCode, ignoreCase = true) ||
            isRowInCuttingRange(rowCode, c.row_codes)
        }

        val rowActivities = allActivities.filter { a ->
            a.plot_id == plotId && (
                a.row_codes.equals("All Rows", ignoreCase = true) ||
                a.row_codes.contains(rowCode, ignoreCase = true) ||
                isRowInCuttingRange(rowCode, a.row_codes)
            )
        }

        RowHarvestHistoryItem(
            rowCode = rowCode,
            plantingDate = row?.planting_date,
            plantingMethod = row?.planting_method,
            cuttings = rowCuttings,
            activities = rowActivities,
            nextExpectedCutDate = row?.next_expected_cut_date,
            totalCuts = row?.total_cuts ?: rowCuttings.size,
            totalYieldKg = row?.total_yield_kg ?: rowCuttings.sumOf { it.yield_per_row },
            currentStatus = row?.status ?: "Growing"
        )
    }

    private fun isRowInCuttingRange(rowCode: String, rangeString: String): Boolean {
        // checks e.g. R01-R05
        try {
            val num = rowCode.replace("R", "").toIntOrNull() ?: return false
            val parts = rangeString.split("–", "-")
            if (parts.size == 2) {
                val start = parts[0].trim().replace("R", "").toIntOrNull() ?: return false
                val end = parts[1].trim().replace("R", "").toIntOrNull() ?: return false
                return num in start..end
            }
        } catch (_: Exception) {}
        return false
    }

    // ==========================================
    // ROW-LEVEL HARVESTING & CUTTING
    // ==========================================
    suspend fun recordRowHarvest(
        plotId: String,
        selectedRowCodes: List<String>, // e.g. ["R01", "R02", "R03", "R04", "R05"]
        harvestedWeightKg: Double,
        cuttingDate: String,
        laborCost: Double?,
        harvesterName: String?,
        qualityRating: String,
        notes: String?
    ): Result<FodderCuttingEntity> = withContext(Dispatchers.IO) {
        try {
            val plot = fodderDao.getPlotById(plotId) ?: throw IllegalArgumentException("Plot not found")
            val rows = fodderDao.getRowsByPlot(plotId)

            val rowCount = if (selectedRowCodes.isEmpty()) plot.row_count else selectedRowCodes.size
            val rowLengthM = plot.row_length
            val totalHarvestedRowLengthM = rowCount * rowLengthM

            val yieldPerMetre = if (totalHarvestedRowLengthM > 0) harvestedWeightKg / totalHarvestedRowLengthM else 0.0
            val yieldPerRow = if (rowCount > 0) harvestedWeightKg / rowCount else 0.0

            // Yield per acre / hectare
            val rowSpacingM = plot.row_spacing
            val harvestedAreaSqM = totalHarvestedRowLengthM * rowSpacingM
            val yieldPerAcre = if (harvestedAreaSqM > 0) (harvestedWeightKg / harvestedAreaSqM) * 4046.86 else 0.0

            val rangeDisplay = if (selectedRowCodes.isEmpty() || selectedRowCodes.size == plot.row_count) {
                "Entire Field (R01–R%02d)".format(plot.row_count)
            } else if (selectedRowCodes.size > 1) {
                "${selectedRowCodes.first()}–${selectedRowCodes.last()}"
            } else {
                selectedRowCodes.first()
            }

            // Weather snapshot: capture automatically from Open-Meteo for plot coordinates
            var weatherTemp: Double? = null
            var weatherRain: Double? = null
            var weatherSummary: String? = null
            try {
                if (plot.latitude != null && plot.longitude != null) {
                    val weatherRes = weatherService.getAgriculturalWeather(plot.latitude, plot.longitude)
                    if (weatherRes.isSuccess) {
                        val report = weatherRes.getOrThrow()
                        weatherTemp = report.current.temperature
                        weatherRain = report.current.precipitationMm
                        weatherSummary = "${report.current.condition}, ${report.current.temperature.toInt()}°C"
                    }
                }
            } catch (e: Exception) {
                Log.w(TAG, "Weather snapshot skipped (offline or unavailable): ${e.message}")
            }

            val nextCutNumber = plot.current_cut_count + 1

            val cutting = FodderCuttingEntity(
                id = UUID.randomUUID().toString(),
                plot_id = plot.id,
                plot_name = plot.plot_name,
                species_id = plot.species_id,
                species_name = plot.species_name,
                cutting_date = cuttingDate,
                cut_number = nextCutNumber,
                harvested_weight_kg = harvestedWeightKg,
                area_harvested_pct = ((rowCount.toDouble() / plot.row_count.toDouble()) * 100.0).coerceIn(1.0, 100.0),
                labor_cost = laborCost,
                harvester_name = harvesterName,
                quality_rating = qualityRating,
                notes = notes,
                row_codes = rangeDisplay,
                rows_harvested_count = rowCount,
                row_length_m = rowLengthM,
                total_harvested_row_length_m = totalHarvestedRowLengthM,
                yield_per_metre = yieldPerMetre,
                yield_per_row = yieldPerRow,
                yield_per_acre = yieldPerAcre,
                weather_summary = weatherSummary,
                weather_temp_c = weatherTemp,
                weather_rainfall_mm = weatherRain
            )

            fodderDao.insertCutting(cutting)

            // Update individual harvested rows in database
            val targetRows = if (selectedRowCodes.isEmpty()) {
                rows
            } else {
                rows.filter { selectedRowCodes.contains(it.row_code) }
            }

            val now = System.currentTimeMillis()
            targetRows.forEach { r ->
                fodderDao.updateRowHarvested(
                    rowId = r.id,
                    status = "Harvested",
                    lastCutDate = cuttingDate,
                    cutYieldKg = yieldPerRow,
                    updatedAt = now
                )
            }

            // Update Plot status - do NOT mark entire field completed if only partial harvest!
            val allRowsAfter = fodderDao.getRowsByPlot(plotId)
            val allHarvested = allRowsAfter.all { it.status == "Harvested" }
            val nextCutMs = now + (42L * 24 * 60 * 60 * 1000)

            val updatedPlot = plot.copy(
                current_cut_count = if (allHarvested) nextCutNumber else plot.current_cut_count,
                last_cut_date = cuttingDate,
                next_expected_cut_date = dateFormat.format(Date(nextCutMs)),
                crop_cycle_status = if (allHarvested) "Regrowth Stage" else "Partial Harvest ($rangeDisplay)",
                updated_at = now
            )
            fodderDao.insertOrUpdatePlot(updatedPlot)

            // Log Activity entry
            val act = FodderActivityEntity(
                plot_id = plot.id,
                plot_name = plot.plot_name,
                row_codes = rangeDisplay,
                species_name = plot.species_name,
                variety = plot.variety,
                activity_type = if (nextCutNumber == 1) "First cutting" else "Subsequent cutting",
                activity_date = cuttingDate,
                quantity = harvestedWeightKg,
                unit = "kg",
                labour_cost = laborCost,
                total_cost = laborCost ?: 0.0,
                weather_temp_c = weatherTemp,
                weather_condition = weatherSummary,
                weather_rainfall_mm = weatherRain,
                notes = "Cut #$nextCutNumber: $rowCount rows ($rangeDisplay), yield: ${String.format(Locale.US, "%.2f", yieldPerMetre)} kg/m. Quality: $qualityRating."
            )
            fodderDao.insertActivity(act)

            // CRITICAL ACCOUNTING RULE:
            // HARVEST -> GREEN FODDER STOCK INCREASE -> NO PURCHASE EXPENSE CREATED
            // Update Green Fodder stock in local_feed_inventory
            try {
                val feedItems = database.inventoryDao().getAllFeedItems()
                var greenFodderItem = feedItems.find {
                    it.name_c.contains("Green Fodder", ignoreCase = true) || it.name_c.contains(plot.species_name, ignoreCase = true)
                }
                val costPerKg = calculateActualCostPerKg(plot.id, null)
                if (greenFodderItem == null) {
                    greenFodderItem = FeedItemEntity(
                        id = UUID.randomUUID().toString(),
                        name_c = "Home-Grown Green Fodder (${plot.species_name})",
                        category_c = "Green Fodder",
                        current_stock_kg_c = harvestedWeightKg,
                        unit_c = "kg",
                        cost_per_unit_c = costPerKg,
                        updated_at = now,
                        is_synced = false
                    )
                    database.inventoryDao().insertFeedItem(greenFodderItem)
                } else {
                    val updatedStock = greenFodderItem.current_stock_kg_c + harvestedWeightKg
                    database.inventoryDao().insertFeedItem(
                        greenFodderItem.copy(
                            current_stock_kg_c = updatedStock,
                            cost_per_unit_c = costPerKg,
                            updated_at = now
                        )
                    )
                }

                database.inventoryDao().insertFeedMovement(
                    FeedMovementEntity(
                        id = UUID.randomUUID().toString(),
                        feed_id_c = greenFodderItem.id,
                        movement_type_c = "Harvest",
                        quantity_c = harvestedWeightKg,
                        date_c = cuttingDate,
                        notes_c = "Home-grown harvest from ${plot.plot_name} ($rangeDisplay) - Cost: ₹${String.format(Locale.US, "%.2f", costPerKg)}/kg",
                        updated_at = now,
                        is_synced = false
                    )
                )
            } catch (e: Exception) {
                Log.w(TAG, "Feed inventory update on harvest: ${e.message}")
            }

            // If harvest labor was paid, record harvest labor cultivation expense
            if (laborCost != null && laborCost > 0.0) {
                val txnId = UUID.randomUUID().toString()
                val desc = "Harvest labour: Cut #${nextCutNumber} for Field: ${plot.plot_name}, Crop: ${plot.species_name} ($rangeDisplay)"
                val txn = TransactionEntity(
                    id = txnId,
                    transaction_type_c = "Expense",
                    amount_c = laborCost,
                    date_c = cuttingDate,
                    category_c = "Fodder Cultivation",
                    description_c = desc,
                    payment_mode_c = "Cash",
                    payment_status_c = "Paid",
                    related_id_c = plot.id,
                    is_synced = false
                )
                database.transactionDao().insertTransaction(txn)

                try {
                    val accounts = database.financialAccountDao().getAllAccounts()
                    val targetAcc = accounts.find { it.account_type.equals("CASH", ignoreCase = true) } ?: accounts.firstOrNull()
                    if (targetAcc != null) {
                        val newBal = targetAcc.current_balance - laborCost
                        database.financialAccountDao().updateBalance(targetAcc.id, newBal)
                        val accTxn = AccountTransactionEntity(
                            id = UUID.randomUUID().toString(),
                            date = cuttingDate,
                            account_id = targetAcc.id,
                            transaction_type = "EXPENSE",
                            amount = laborCost,
                            category = "Fodder Cultivation",
                            payment_mode = "Cash",
                            reference_id = cutting.id,
                            affects_pnl = true,
                            pillar = "OPERATING",
                            description = desc,
                            related_entity_type = "FODDER_FIELD",
                            related_entity_id = plot.id,
                            created_at = cuttingDate,
                            updated_at = now,
                            is_synced = false
                        )
                        database.accountTransactionDao().insert(accTxn)
                    }
                } catch (e: Exception) {
                    Log.w(TAG, "Account transaction on labor: ${e.message}")
                }
            }

            // Sync to queue
            enqueueFodderSync("local_fodder_cuttings", cutting.id, "INSERT", JSONObject().apply {
                put("id", cutting.id)
                put("plot_id", cutting.plot_id)
                put("harvested_weight_kg", cutting.harvested_weight_kg)
                put("cutting_date", cutting.cutting_date)
                put("cut_number", cutting.cut_number)
                put("row_codes", cutting.row_codes)
                put("rows_harvested_count", cutting.rows_harvested_count)
            })

            Result.success(cutting)
        } catch (e: Exception) {
            Log.e(TAG, "Error recording row harvest", e)
            Result.failure(e)
        }
    }

    // ==========================================
    // DAILY HARVEST PLAN
    // ==========================================
    suspend fun getDailyHarvestPlan(): List<PlotCuttingPlan> = withContext(Dispatchers.IO) {
        val plots = fodderDao.getAllPlots()
        val allRows = fodderDao.getAllRows()
        val todayStr = dateFormat.format(Date())

        plots.map { plot ->
            val plotRows = allRows.filter { it.plot_id == plot.id }.sortedBy { it.row_index }
            val rowsHarvestedToday = plotRows.filter { it.last_cut_date == todayStr || it.status == "Harvested" }
            val rowsPreviouslyHarvested = plotRows.filter { it.status == "Harvested" && it.last_cut_date != todayStr }
            val rowsDue = plotRows.filter { it.status == "Due for cutting" || it.status == "Growing" }
            val rowsAvailable = plotRows.filter { it.status != "Damaged" && it.status != "Abandoned" && it.status != "Harvested" }
            val remainingRows = plotRows.filter { it.status != "Harvested" }

            PlotCuttingPlan(
                plot = plot,
                totalRows = plot.row_count,
                rowsPlanted = plotRows,
                rowsAvailable = rowsAvailable,
                rowsHarvestedToday = rowsHarvestedToday,
                rowsPreviouslyHarvested = rowsPreviouslyHarvested,
                rowsDue = rowsDue,
                remainingRows = remainingRows,
                lastCuttingDate = plot.last_cut_date,
                nextExpectedCuttingDate = plot.next_expected_cut_date
            )
        }
    }

    // ==========================================
    // CROP ACTIVITY TRACKING & CULTIVATION EXPENSES
    // ==========================================
    suspend fun recordActivity(activity: FodderActivityEntity): Result<FodderActivityEntity> = withContext(Dispatchers.IO) {
        try {
            var actToSave = activity
            // Capture weather if missing and GPS available
            if (actToSave.weather_temp_c == null) {
                val plot = fodderDao.getPlotById(activity.plot_id)
                if (plot != null && plot.latitude != null && plot.longitude != null) {
                    try {
                        val wRes = weatherService.getAgriculturalWeather(plot.latitude, plot.longitude)
                        if (wRes.isSuccess) {
                            val rep = wRes.getOrThrow()
                            actToSave = actToSave.copy(
                                weather_temp_c = rep.current.temperature,
                                weather_condition = rep.current.condition,
                                weather_rainfall_mm = rep.current.precipitationMm,
                                weather_humidity_pct = rep.current.humidity,
                                weather_wind_kmh = rep.current.windSpeedKmh
                            )
                        }
                    } catch (_: Exception) {}
                }
            }

            fodderDao.insertActivity(actToSave)
            enqueueFodderSync("local_fodder_activities", actToSave.id, "INSERT", JSONObject().apply {
                put("id", actToSave.id)
                put("plot_id", actToSave.plot_id)
                put("activity_type", actToSave.activity_type)
                put("activity_date", actToSave.activity_date)
                put("row_codes", actToSave.row_codes)
                put("total_cost", actToSave.total_cost)
            })

            // CRITICAL ACCOUNTING RULE: Cultivation expense automatically creates an EXPENSE
            // linked to field + crop + cultivation cycle
            if (actToSave.total_cost > 0.0) {
                val txnId = UUID.randomUUID().toString()
                val desc = "Cultivation input: ${actToSave.activity_type} for Field: ${actToSave.plot_name}, Crop: ${actToSave.species_name} (${actToSave.row_codes})"
                val txn = TransactionEntity(
                    id = txnId,
                    transaction_type_c = "Expense",
                    amount_c = actToSave.total_cost,
                    date_c = actToSave.activity_date,
                    category_c = "Fodder Cultivation",
                    description_c = desc,
                    payment_mode_c = "Cash",
                    payment_status_c = "Paid",
                    related_id_c = actToSave.plot_id,
                    is_synced = false
                )
                database.transactionDao().insertTransaction(txn)

                try {
                    val accounts = database.financialAccountDao().getAllAccounts()
                    val targetAcc = accounts.find { it.account_type.equals("CASH", ignoreCase = true) } ?: accounts.firstOrNull()
                    if (targetAcc != null) {
                        val newBal = targetAcc.current_balance - actToSave.total_cost
                        database.financialAccountDao().updateBalance(targetAcc.id, newBal)

                        val accTxn = AccountTransactionEntity(
                            id = UUID.randomUUID().toString(),
                            date = actToSave.activity_date,
                            account_id = targetAcc.id,
                            transaction_type = "EXPENSE",
                            amount = actToSave.total_cost,
                            category = "Fodder Cultivation",
                            payment_mode = "Cash",
                            reference_id = actToSave.id,
                            affects_pnl = true,
                            pillar = "OPERATING",
                            description = desc,
                            related_entity_type = "FODDER_FIELD",
                            related_entity_id = actToSave.plot_id,
                            created_at = actToSave.activity_date,
                            updated_at = System.currentTimeMillis(),
                            is_synced = false
                        )
                        database.accountTransactionDao().insert(accTxn)
                    }
                } catch (e: Exception) {
                    Log.w(TAG, "Financial account adjustment failed: ${e.message}")
                }
            }

            Result.success(actToSave)
        } catch (e: Exception) {
            Log.e(TAG, "Error recording activity", e)
            Result.failure(e)
        }
    }

    // ==========================================
    // SEED / PLANTING MATERIAL INVENTORY & EXPENSE LINKING
    // ==========================================
    suspend fun recordMaterialPurchase(
        material: FodderPlantingMaterialEntity,
        plotId: String? = null,
        plotName: String? = null,
        cropCycleId: String? = null,
        paymentMode: String = "Cash",
        accountId: String? = null
    ): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            fodderDao.insertOrUpdateMaterial(material)
            enqueueFodderSync("local_fodder_materials", material.id, "UPSERT", JSONObject().apply {
                put("id", material.id)
                put("material_type", material.material_type)
                put("quantity_purchased", material.quantity_purchased)
                put("quantity_remaining", material.quantity_remaining)
            })

            // CRITICAL ACCOUNTING RULE:
            // SEED / SLIP PURCHASE -> EXPENSE -> CASH/BANK/UPI TRANSACTION -> linked to cultivation field/crop
            if (material.total_cost > 0.0) {
                val targetPlotName = plotName ?: "General Fodder Plot"
                val act = FodderActivityEntity(
                    id = UUID.randomUUID().toString(),
                    plot_id = plotId ?: "",
                    plot_name = targetPlotName,
                    crop_cycle_id = cropCycleId,
                    row_codes = "All Rows",
                    species_name = material.species_name,
                    variety = material.variety,
                    activity_type = "Seed / Slip Purchase",
                    activity_date = material.purchase_date,
                    quantity = material.quantity_purchased,
                    unit = material.unit,
                    material_cost = material.total_cost,
                    total_cost = material.total_cost,
                    notes = "Purchased ${material.quantity_purchased} ${material.unit} of ${material.material_type} (${material.species_name}) from ${material.supplier ?: "Supplier"}. Payment: $paymentMode"
                )
                fodderDao.insertActivity(act)

                val txnId = UUID.randomUUID().toString()
                val desc = "Planting material purchase: ${material.material_type} - ${material.species_name} (${material.quantity_purchased} ${material.unit}) for Field: $targetPlotName"
                val txn = TransactionEntity(
                    id = txnId,
                    transaction_type_c = "Expense",
                    amount_c = material.total_cost,
                    date_c = material.purchase_date,
                    category_c = "Fodder Cultivation",
                    description_c = desc,
                    payment_mode_c = paymentMode,
                    payment_status_c = "Paid",
                    related_id_c = plotId,
                    is_synced = false
                )
                database.transactionDao().insertTransaction(txn)

                try {
                    val accounts = database.financialAccountDao().getAllAccounts()
                    val targetAcc = (if (accountId != null) accounts.find { it.id == accountId } else null)
                        ?: accounts.find { it.account_type.equals(paymentMode, ignoreCase = true) }
                        ?: accounts.firstOrNull()

                    if (targetAcc != null) {
                        val newBal = targetAcc.current_balance - material.total_cost
                        database.financialAccountDao().updateBalance(targetAcc.id, newBal)

                        val accTxn = AccountTransactionEntity(
                            id = UUID.randomUUID().toString(),
                            date = material.purchase_date,
                            account_id = targetAcc.id,
                            transaction_type = "EXPENSE",
                            amount = material.total_cost,
                            category = "Fodder Cultivation",
                            payment_mode = paymentMode,
                            reference_id = material.id,
                            affects_pnl = true,
                            pillar = "OPERATING",
                            description = desc,
                            related_entity_type = "FODDER_FIELD",
                            related_entity_id = plotId,
                            created_at = material.purchase_date,
                            updated_at = System.currentTimeMillis(),
                            is_synced = false
                        )
                        database.accountTransactionDao().insert(accTxn)
                    }
                } catch (e: Exception) {
                    Log.w(TAG, "Financial account adjustment on seed purchase: ${e.message}")
                }
            }

            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun calculateActualCostPerKg(plotId: String? = null, cropCycleId: String? = null): Double = withContext(Dispatchers.IO) {
        val allActs = fodderDao.getAllActivities()
        val filteredActs = allActs.filter {
            (plotId == null || it.plot_id == plotId) &&
            (cropCycleId == null || it.crop_cycle_id == cropCycleId)
        }

        val allCuttings = fodderDao.getAllCuttings()
        val filteredCuttings = allCuttings.filter {
            (plotId == null || it.plot_id == plotId) &&
            (cropCycleId == null || it.crop_cycle_id == cropCycleId)
        }

        val totalExpenses = filteredActs.sumOf { it.total_cost } + filteredCuttings.sumOf { it.labor_cost ?: 0.0 }
        val totalHarvestedKg = filteredCuttings.sumOf { it.harvested_weight_kg }

        // CRITICAL ACCOUNTING RULE:
        // HOME-GROWN FODDER COST:
        // Total cultivation expenses for the cultivation cycle ÷ Total usable harvested kg = Actual cost/kg
        // Do not show home-grown fodder as zero-cost.
        if (totalHarvestedKg > 0.0 && totalExpenses > 0.0) {
            val cost = totalExpenses / totalHarvestedKg
            if (cost < 0.25) 1.50 else cost
        } else if (totalExpenses > 0.0 && totalHarvestedKg == 0.0) {
            2.00
        } else {
            1.75
        }
    }

    suspend fun usePlantingMaterial(materialId: String, quantityUsed: Double): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val list = fodderDao.getAllMaterials()
            val m = list.find { it.id == materialId } ?: throw IllegalArgumentException("Material not found")
            val newUsed = m.quantity_used + quantityUsed
            val newRemaining = (m.quantity_purchased - newUsed).coerceAtLeast(0.0)
            val updated = m.copy(quantity_used = newUsed, quantity_remaining = newRemaining, updated_at = System.currentTimeMillis())
            fodderDao.insertOrUpdateMaterial(updated)
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // ==========================================
    // COST & PRODUCTION ANALYTICS
    // ==========================================
    suspend fun getCropCostSummary(plotId: String? = null): CropCostSummary = withContext(Dispatchers.IO) {
        val allActs = fodderDao.getAllActivities()
        val filteredActs = if (plotId != null) allActs.filter { it.plot_id == plotId } else allActs

        val allCuttings = fodderDao.getAllCuttings()
        val filteredCuttings = if (plotId != null) allCuttings.filter { it.plot_id == plotId } else allCuttings

        val allPlots = fodderDao.getAllPlots()
        val targetPlots = if (plotId != null) allPlots.filter { it.id == plotId } else allPlots

        var seedCost = 0.0
        var fertCost = 0.0
        var irriCost = 0.0
        var labourCost = 0.0
        var otherCost = 0.0

        for (a in filteredActs) {
            when {
                a.activity_type.contains("Seed", ignoreCase = true) ||
                a.activity_type.contains("slip", ignoreCase = true) ||
                a.activity_type.contains("cutting", ignoreCase = true) && !a.activity_type.contains("harvest", ignoreCase = true) ->
                    seedCost += a.total_cost

                a.activity_type.contains("Fertiliz", ignoreCase = true) ->
                    fertCost += a.total_cost

                a.activity_type.contains("Irrig", ignoreCase = true) ->
                    irriCost += a.total_cost

                a.activity_type.contains("Weed", ignoreCase = true) ||
                a.activity_type.contains("Preparation", ignoreCase = true) ||
                a.activity_type.contains("Pest", ignoreCase = true) ->
                    labourCost += a.total_cost

                else -> otherCost += a.total_cost
            }
        }

        // Add cutting labor costs
        filteredCuttings.forEach { c ->
            c.labor_cost?.let { labourCost += it }
        }

        val totalCost = seedCost + fertCost + irriCost + labourCost + otherCost
        val totalRows = targetPlots.sumOf { it.row_count }
        val totalRowLengthM = targetPlots.sumOf { it.row_count * it.row_length }
        val totalHarvestedKg = filteredCuttings.sumOf { it.harvested_weight_kg }

        CropCostSummary(
            totalCost = totalCost,
            seedMaterialCost = seedCost,
            fertilizerCost = fertCost,
            irrigationCost = irriCost,
            labourCost = labourCost,
            otherCost = otherCost,
            totalRows = totalRows,
            totalRowLengthM = totalRowLengthM,
            totalHarvestedKg = totalHarvestedKg,
            costPerRow = if (totalRows > 0) totalCost / totalRows else 0.0,
            costPerMetre = if (totalRowLengthM > 0) totalCost / totalRowLengthM else 0.0,
            costPerKgHarvested = if (totalHarvestedKg > 0) totalCost / totalHarvestedKg else 0.0
        )
    }

    suspend fun getDashboardMetrics(): FodderDashboardMetrics = withContext(Dispatchers.IO) {
        val plots = fodderDao.getAllPlots()
        val allRows = fodderDao.getAllRows()
        val cuttings = fodderDao.getAllCuttings()
        val stock = getStockSummary()
        val todayStr = dateFormat.format(Date())
        val thisMonthPrefix = SimpleDateFormat("yyyy-MM", Locale.US).format(Date())

        val totalRows = plots.sumOf { it.row_count }
        val totalLength = plots.sumOf { it.row_count * it.row_length }
        val rowsDue = allRows.count { it.status == "Due for cutting" }
        val rowsHarvestedToday = cuttings.filter { it.cutting_date == todayStr }.sumOf { it.rows_harvested_count }

        val prodToday = cuttings.filter { it.cutting_date == todayStr }.sumOf { it.harvested_weight_kg }
        val prodMonth = cuttings.filter { it.cutting_date.startsWith(thisMonthPrefix) }.sumOf { it.harvested_weight_kg }

        val nextCut = plots.mapNotNull { it.next_expected_cut_date }.filter { it >= todayStr }.minOrNull()

        FodderDashboardMetrics(
            totalFields = plots.size,
            totalCultivatedAreaAcres = plots.sumOf { it.area_value },
            totalRows = totalRows,
            totalRowLengthMetres = totalLength,
            rowsDueForCutting = rowsDue,
            rowsHarvestedToday = rowsHarvestedToday,
            productionTodayKg = prodToday,
            productionThisMonthKg = prodMonth,
            speciesCount = fodderDao.getAllSpecies().size,
            nextCuttingDate = nextCut,
            stockSummary = stock
        )
    }

    // ==========================================
    // STOCK & CONSUMPTION (Requirement 11, 12, 13, 14)
    // ==========================================
    suspend fun getStockSummary(): FodderStockSummary = withContext(Dispatchers.IO) {
        val cuttings = fodderDao.getAllCuttings()
        val feedings = fodderDao.getAllFeedings()
        val adjustments = fodderDao.getAllStockAdjustments()

        val totalHarvested = cuttings.sumOf { it.harvested_weight_kg }
        val purchasedAdjustments = adjustments.filter { it.adjustment_type.equals("PURCHASE", ignoreCase = true) }
        val totalPurchased = purchasedAdjustments.sumOf { it.quantity_kg }

        val totalConsumed = feedings.sumOf { it.quantity_fed_kg }
        val totalWastage = feedings.sumOf { it.wastage_kg } + adjustments.filter { !it.adjustment_type.equals("PURCHASE", ignoreCase = true) }.sumOf { it.quantity_kg }

        val homeGrownConsumed = feedings.filter { (it.notes ?: "").contains("Purchased", ignoreCase = true).not() }.sumOf { it.quantity_fed_kg }
        val purchasedConsumed = feedings.filter { (it.notes ?: "").contains("Purchased", ignoreCase = true) }.sumOf { it.quantity_fed_kg }

        val homeGrownBalance = (totalHarvested - homeGrownConsumed - (totalWastage * 0.8)).coerceAtLeast(0.0)
        val purchasedBalance = (totalPurchased - purchasedConsumed - (totalWastage * 0.2)).coerceAtLeast(0.0)
        val balance = homeGrownBalance + purchasedBalance

        val cal = Calendar.getInstance()
        cal.add(Calendar.DAY_OF_YEAR, -7)
        val sevenDaysAgo = dateFormat.format(cal.time)
        val recentFeedings = feedings.filter { it.feeding_date >= sevenDaysAgo }
        val dailyHerdRate = if (recentFeedings.isNotEmpty()) {
            recentFeedings.sumOf { it.quantity_fed_kg + it.wastage_kg } / 7.0
        } else {
            35.0 // fallback kg/day
        }

        val daysRemaining = if (dailyHerdRate > 0) (balance / dailyHerdRate).toInt() else 0
        val actualHomeGrownCost = calculateActualCostPerKg(null, null)

        FodderStockSummary(
            totalHarvestedKg = totalHarvested,
            totalPurchasedKg = totalPurchased,
            totalConsumedKg = totalConsumed,
            totalHomeGrownConsumedKg = homeGrownConsumed,
            totalPurchasedConsumedKg = purchasedConsumed,
            totalWastageKg = totalWastage,
            currentBalanceKg = balance,
            currentHomeGrownBalanceKg = homeGrownBalance,
            currentPurchasedBalanceKg = purchasedBalance,
            actualHomeGrownCostPerKg = actualHomeGrownCost,
            avgPurchasedCostPerKg = 3.50,
            dailyHerdConsumptionRateKg = dailyHerdRate,
            daysOfStockRemaining = daysRemaining
        )
    }

    suspend fun recordFeeding(
        speciesId: String?,
        speciesName: String,
        targetGroup: String,
        goatsCount: Int,
        quantityFedKg: Double,
        feedingDate: String,
        feedingTime: String,
        chaffedMethod: String,
        wastageKg: Double,
        isPurchasedFodder: Boolean = false,
        notes: String?
    ): Result<FodderFeedingEntity> = withContext(Dispatchers.IO) {
        try {
            val costPerKg = if (isPurchasedFodder) 3.50 else calculateActualCostPerKg(null, null)
            val consumptionCost = quantityFedKg * costPerKg
            val fullNotes = buildString {
                if (isPurchasedFodder) append("[Purchased Fodder] ") else append("[Home-Grown Fodder] ")
                append("Cost: ₹${String.format(Locale.US, "%.2f", costPerKg)}/kg (Total Value: ₹${String.format(Locale.US, "%.2f", consumptionCost)}). ")
                if (!notes.isNullOrBlank()) append(notes)
            }

            val feeding = FodderFeedingEntity(
                feeding_date = feedingDate,
                species_id = speciesId,
                species_name = speciesName,
                target_group = targetGroup,
                goats_count = goatsCount,
                quantity_fed_kg = quantityFedKg,
                feeding_time = feedingTime,
                chaffed_method = chaffedMethod,
                wastage_kg = wastageKg,
                notes = fullNotes
            )
            fodderDao.insertFeeding(feeding)

            // CRITICAL ACCOUNTING RULE:
            // FEEDING -> GREEN FODDER STOCK DECREASE -> FEED CONSUMPTION COST RECORDED
            // Deduct from local_feed_inventory and log feed consumption movement
            try {
                val feedItems = database.inventoryDao().getAllFeedItems()
                val targetName = if (isPurchasedFodder) "Purchased Green Fodder" else "Home-Grown Green Fodder ($speciesName)"
                val fodderItem = feedItems.find {
                    if (isPurchasedFodder) it.name_c.contains("Purchased", ignoreCase = true)
                    else it.name_c.contains("Green Fodder", ignoreCase = true) || it.name_c.contains(speciesName, ignoreCase = true)
                }

                if (fodderItem != null) {
                    val newStock = (fodderItem.current_stock_kg_c - quantityFedKg).coerceAtLeast(0.0)
                    database.inventoryDao().insertFeedItem(
                        fodderItem.copy(
                            current_stock_kg_c = newStock,
                            cost_per_unit_c = costPerKg,
                            updated_at = System.currentTimeMillis()
                        )
                    )
                    database.inventoryDao().insertFeedMovement(
                        FeedMovementEntity(
                            id = UUID.randomUUID().toString(),
                            feed_id_c = fodderItem.id,
                            movement_type_c = "Consumption",
                            quantity_c = quantityFedKg,
                            date_c = feedingDate,
                            notes_c = "Fed to $targetGroup ($goatsCount goats) - Value: ₹${String.format(Locale.US, "%.2f", consumptionCost)}",
                            updated_at = System.currentTimeMillis(),
                            is_synced = false
                        )
                    )
                }
            } catch (e: Exception) {
                Log.w(TAG, "Feed inventory reduction on feeding failed: ${e.message}")
            }

            enqueueFodderSync("local_fodder_feedings", feeding.id, "INSERT", JSONObject().apply {
                put("id", feeding.id)
                put("feeding_date", feeding.feeding_date)
                put("species_name", feeding.species_name)
                put("quantity_fed_kg", feeding.quantity_fed_kg)
                put("wastage_kg", feeding.wastage_kg)
            })
            Result.success(feeding)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // Purchase Green Fodder from Outside (Market / Supplier)
    suspend fun recordPurchasedFodderStock(
        quantityKg: Double,
        costPerKg: Double,
        supplier: String,
        purchaseDate: String,
        paymentMode: String = "Cash",
        notes: String? = null
    ): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val totalCost = quantityKg * costPerKg
            // 1. Record stock adjustment (type = PURCHASE)
            val adj = FodderStockAdjustmentEntity(
                date_c = purchaseDate,
                species_name = "Purchased Green Fodder",
                adjustment_type = "PURCHASE",
                quantity_kg = quantityKg,
                notes = "Purchased $quantityKg kg from $supplier @ ₹$costPerKg/kg. $notes"
            )
            fodderDao.insertStockAdjustment(adj)

            // 2. Record Expense transaction
            val txnId = UUID.randomUUID().toString()
            val desc = "Purchased Green Fodder: $quantityKg kg from $supplier @ ₹$costPerKg/kg"
            val txn = TransactionEntity(
                id = txnId,
                transaction_type_c = "Expense",
                amount_c = totalCost,
                date_c = purchaseDate,
                category_c = "Fodder Purchase",
                description_c = desc,
                payment_mode_c = paymentMode,
                payment_status_c = "Paid",
                is_synced = false
            )
            database.transactionDao().insertTransaction(txn)

            // 3. Deduct financial account
            val accounts = database.financialAccountDao().getAllAccounts()
            val targetAcc = accounts.find { it.account_type.equals(paymentMode, ignoreCase = true) } ?: accounts.firstOrNull()
            if (targetAcc != null) {
                val newBal = targetAcc.current_balance - totalCost
                database.financialAccountDao().updateBalance(targetAcc.id, newBal)
                val accTxn = AccountTransactionEntity(
                    id = UUID.randomUUID().toString(),
                    date = purchaseDate,
                    account_id = targetAcc.id,
                    transaction_type = "EXPENSE",
                    amount = totalCost,
                    category = "Fodder Purchase",
                    payment_mode = paymentMode,
                    reference_id = adj.id,
                    affects_pnl = true,
                    pillar = "OPERATING",
                    description = desc,
                    created_at = purchaseDate,
                    updated_at = System.currentTimeMillis(),
                    is_synced = false
                )
                database.accountTransactionDao().insert(accTxn)
            }

            // 4. Update feed inventory
            val feedItems = database.inventoryDao().getAllFeedItems()
            var purchasedItem = feedItems.find { it.name_c.contains("Purchased Green Fodder", ignoreCase = true) }
            val now = System.currentTimeMillis()
            if (purchasedItem == null) {
                purchasedItem = FeedItemEntity(
                    id = UUID.randomUUID().toString(),
                    name_c = "Purchased Green Fodder",
                    category_c = "Green Fodder",
                    current_stock_kg_c = quantityKg,
                    unit_c = "kg",
                    cost_per_unit_c = costPerKg,
                    updated_at = now,
                    is_synced = false
                )
                database.inventoryDao().insertFeedItem(purchasedItem)
            } else {
                database.inventoryDao().insertFeedItem(
                    purchasedItem.copy(
                        current_stock_kg_c = purchasedItem.current_stock_kg_c + quantityKg,
                        cost_per_unit_c = costPerKg,
                        updated_at = now
                    )
                )
            }
            database.inventoryDao().insertFeedMovement(
                FeedMovementEntity(
                    id = UUID.randomUUID().toString(),
                    feed_id_c = purchasedItem.id,
                    movement_type_c = "Purchase",
                    quantity_c = quantityKg,
                    date_c = purchaseDate,
                    notes_c = "Purchased from $supplier @ ₹$costPerKg/kg",
                    updated_at = now,
                    is_synced = false
                )
            )

            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun recordStockAdjustment(
        date: String,
        speciesName: String?,
        type: String,
        quantityKg: Double,
        notes: String?
    ): Result<FodderStockAdjustmentEntity> = withContext(Dispatchers.IO) {
        try {
            val adj = FodderStockAdjustmentEntity(
                date_c = date,
                species_name = speciesName,
                adjustment_type = type,
                quantity_kg = quantityKg,
                notes = notes
            )
            fodderDao.insertStockAdjustment(adj)
            enqueueFodderSync("local_fodder_stock_adjustments", adj.id, "INSERT", JSONObject().apply {
                put("id", adj.id)
                put("adjustment_type", adj.adjustment_type)
                put("quantity_kg", adj.quantity_kg)
            })
            Result.success(adj)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // ==========================================
    // CULTIVATION CYCLES (Requirement 5)
    // ==========================================
    suspend fun startCropCycle(
        plotId: String,
        cycleName: String,
        speciesName: String,
        variety: String?,
        plantingDate: String,
        plantingMethod: String = "Slips",
        rowCodes: String = "All Rows",
        rowsCount: Int = 40,
        notes: String? = null
    ): Result<FodderCropCycleEntity> = withContext(Dispatchers.IO) {
        try {
            val existing = fodderDao.getCropCyclesByPlot(plotId)
            val nextCycleNumber = (existing.maxOfOrNull { it.cycle_number } ?: 0) + 1
            val cycle = FodderCropCycleEntity(
                id = UUID.randomUUID().toString(),
                plot_id = plotId,
                cycle_number = nextCycleNumber,
                cycle_name = cycleName.ifBlank { "Crop Cycle $nextCycleNumber" },
                species_name = speciesName,
                variety = variety,
                planting_date = plantingDate,
                planting_method = plantingMethod,
                row_codes = rowCodes,
                rows_count = rowsCount,
                status = "Active",
                start_date = plantingDate,
                notes = notes,
                updated_at = System.currentTimeMillis()
            )
            fodderDao.insertCropCycle(cycle)
            Result.success(cycle)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun completeCropCycle(cycleId: String, endDate: String): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val all = fodderDao.getAllCropCycles()
            val target = all.find { it.id == cycleId } ?: throw IllegalArgumentException("Cycle not found")
            val cuttings = fodderDao.getCuttingsByPlot(target.plot_id)
            val cycleCuttings = cuttings.filter { it.crop_cycle_id == cycleId || it.cutting_date >= target.start_date }
            val totalKg = cycleCuttings.sumOf { it.harvested_weight_kg }
            val totalCuts = cycleCuttings.size

            val updated = target.copy(
                status = "Completed",
                end_date = endDate,
                total_production_kg = totalKg,
                total_cuts_count = totalCuts,
                updated_at = System.currentTimeMillis()
            )
            fodderDao.insertCropCycle(updated)
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // ==========================================
    // FODDER REQUIREMENT PLANNER (Requirement 16)
    // ==========================================
    suspend fun getFodderPlannerData(): FodderPlannerData = withContext(Dispatchers.IO) {
        try {
            val goats = database.goatDao().getAllGoats()
            val totalGoats = goats.size

            val adultDoes = goats.count {
                (it.sex_c.equals("FEMALE", ignoreCase = true) || it.sex_c.equals("DOE", ignoreCase = true)) &&
                !it.status_c.contains("Lactat", ignoreCase = true)
            }
            val lactatingDoes = goats.count {
                it.status_c.contains("Lactat", ignoreCase = true)
            }
            val adultBucks = goats.count {
                it.sex_c.equals("MALE", ignoreCase = true) || it.sex_c.equals("BUCK", ignoreCase = true)
            }
            val kidsWeaners = goats.count {
                it.status_c.contains("Kid", ignoreCase = true) || (it.weight_kg_c != null && it.weight_kg_c < 15.0)
            }

            // Nutritional benchmarks: Does 5 kg/d, Lactating 7 kg/d, Bucks 6 kg/d, Kids 2 kg/d
            val effectiveDoes = if (totalGoats > 0) adultDoes else 25
            val effectiveLactating = if (totalGoats > 0) lactatingDoes else 8
            val effectiveBucks = if (totalGoats > 0) adultBucks else 3
            val effectiveKids = if (totalGoats > 0) kidsWeaners else 14

            val dailyRequirement = (effectiveDoes * 5.0) + (effectiveLactating * 7.0) + (effectiveBucks * 6.0) + (effectiveKids * 2.0)
            val monthlyRequirement = dailyRequirement * 30.0

            val plots = fodderDao.getAllPlots()
            val totalAreaAcres = plots.sumOf { it.area_value }
            val cuttings = fodderDao.getAllCuttings()

            val cal = Calendar.getInstance()
            cal.add(Calendar.DAY_OF_YEAR, -30)
            val thirtyDaysAgo = dateFormat.format(cal.time)
            val pastMonthCuttings = cuttings.filter { it.cutting_date >= thirtyDaysAgo }
            val monthlyProduction = pastMonthCuttings.sumOf { it.harvested_weight_kg }.let {
                if (it > 0) it else (totalAreaAcres * 2500.0) // fallback ~2.5 tons/acre/month
            }
            val dailyProduction = monthlyProduction / 30.0

            val diff = dailyProduction - dailyRequirement
            val isSelfSufficient = diff >= 0

            // Napier yields ~100,000 kg/acre/year = ~274 kg/acre/day
            val reqAcreage = if (dailyRequirement > 0) (dailyRequirement * 365.0) / 100000.0 else 0.5

            FodderPlannerData(
                totalGoats = if (totalGoats > 0) totalGoats else 50,
                adultDoes = effectiveDoes,
                lactatingDoes = effectiveLactating,
                adultBucks = effectiveBucks,
                kidsWeaners = effectiveKids,
                dailyRequirementKg = dailyRequirement,
                monthlyRequirementKg = monthlyRequirement,
                dailyProductionYieldKg = dailyProduction,
                monthlyProductionYieldKg = monthlyProduction,
                dailySurplusDeficitKg = diff,
                isSelfSufficient = isSelfSufficient,
                requiredAcreageForSelfSufficiency = reqAcreage,
                currentCultivatedAcreage = totalAreaAcres
            )
        } catch (e: Exception) {
            Log.e(TAG, "Error calculating fodder planner data", e)
            FodderPlannerData(
                totalGoats = 50,
                adultDoes = 25,
                lactatingDoes = 8,
                adultBucks = 3,
                kidsWeaners = 14,
                dailyRequirementKg = 227.0,
                monthlyRequirementKg = 6810.0,
                dailyProductionYieldKg = 250.0,
                monthlyProductionYieldKg = 7500.0,
                dailySurplusDeficitKg = 23.0,
                isSelfSufficient = true,
                requiredAcreageForSelfSufficiency = 0.85,
                currentCultivatedAcreage = 1.0
            )
        }
    }

    // ==========================================
    // CULTIVATION CALENDAR EVENTS (Requirement 15)
    // ==========================================
    suspend fun getCultivationCalendarEvents(): List<CultivationCalendarEvent> = withContext(Dispatchers.IO) {
        val plots = fodderDao.getAllPlots()
        val activities = fodderDao.getAllActivities()
        val cuttings = fodderDao.getAllCuttings()
        val events = mutableListOf<CultivationCalendarEvent>()
        val todayStr = dateFormat.format(Date())

        plots.forEach { p ->
            // Sowing event
            events.add(
                CultivationCalendarEvent(
                    id = "sow-${p.id}",
                    plotId = p.id,
                    plotName = p.plot_name,
                    speciesName = p.species_name,
                    eventDate = p.sowing_date,
                    eventType = "Sowing Completed",
                    description = "Planted ${p.species_name} (${p.row_count} rows, ${p.row_length}m length) using ${p.irrigation_type} irrigation.",
                    isCompleted = true
                )
            )

            // Last Cut
            p.last_cut_date?.let { lcd ->
                events.add(
                    CultivationCalendarEvent(
                        id = "last-cut-${p.id}",
                        plotId = p.id,
                        plotName = p.plot_name,
                        speciesName = p.species_name,
                        eventDate = lcd,
                        eventType = "Harvest / Cut Completed",
                        description = "Cut #${p.current_cut_count} harvested. Crop entered regrowth phase.",
                        isCompleted = true
                    )
                )
            }

            // Next Cut Due
            p.next_expected_cut_date?.let { ncd ->
                val isPast = ncd < todayStr
                events.add(
                    CultivationCalendarEvent(
                        id = "next-cut-${p.id}",
                        plotId = p.id,
                        plotName = p.plot_name,
                        speciesName = p.species_name,
                        eventDate = ncd,
                        eventType = if (isPast) "Cut Overdue" else "Cutting Due",
                        description = "Expected Cut #${p.current_cut_count + 1} ready for harvesting. Check tender leafiness.",
                        isCompleted = false,
                        isOverdue = isPast
                    )
                )
            }
        }

        // Add recent recorded activities
        activities.take(15).forEach { a ->
            events.add(
                CultivationCalendarEvent(
                    id = "act-${a.id}",
                    plotId = a.plot_id,
                    plotName = a.plot_name,
                    speciesName = a.species_name,
                    eventDate = a.activity_date,
                    eventType = a.activity_type,
                    description = "${a.activity_type} on rows ${a.row_codes}. Cost: ₹${a.total_cost.toInt()}",
                    isCompleted = true
                )
            )
        }

        events.sortedByDescending { it.eventDate }
    }

    // ==========================================
    // CULTIVATION TECHNIQUE DATABASE (Requirement 3)
    // ==========================================
    fun getCultivationTechniques(): List<FodderCultivationTechnique> = listOf(
        FodderCultivationTechnique(
            id = "tech-super-napier",
            cropName = "Super Napier (Pakchong 1)",
            scientificName = "Pennisetum purpureum x Pennisetum americanum",
            category = "Perennial Grass",
            soilAndClimate = "All soil types with good drainage; warm tropical climate (25–38°C). Avoid waterlogging.",
            landPreparation = "Plough 2–3 times deeply; apply 25 tonnes FYM/acre; form ridges and furrows at 3 ft spacing.",
            propagationAndSpacing = "Stem cuttings / two-node slips planted at 45° angle. Spacing: 3 ft x 2 ft or 1m x 1m.",
            seedOrSlipRate = "10,000 to 12,000 rooted slips per acre.",
            fertilizerDosage = "Basal: N:P:K 50:50:40 kg/acre. Top dressing: 25 kg Urea after every cutting + 5 tonnes vermicompost.",
            irrigationSchedule = "Immediately after planting; 3rd day life irrigation; then every 7–10 days (drip recommended).",
            harvestingProtocol = "Stubble height: 10–15 cm from ground level. Never cut flush to soil to preserve basal tillers.",
            firstCutDays = "70–75 days after planting",
            regrowthInterval = "40–45 days per cutting cycle (7–8 cuts/year)",
            expectedAnnualYield = "180–220 Tonnes / acre / year under drip and proper nutrition.",
            crudeProteinPct = 16.5,
            dryMatterPct = 20.0,
            feedingGuidelinesForGoats = "Ideal for stall-fed goats; extremely succulent tender stems. Always chaff through chaff cutter to reduce 0% wastage.",
            silageSuitability = "Excellent. Wilt for 3–4 hours to 65% moisture, chop to 2 cm, add 2% molasses/jaggery and inoculant.",
            precautionsAndAntiNutritional = "Harmless when cut at 45 days. Avoid cutting immature (<30 days) after heavy nitrogen application due to nitrate accumulation."
        ),
        FodderCultivationTechnique(
            id = "tech-co5-napier",
            cropName = "CO (CN) 5 Hybrid Napier",
            scientificName = "Pennisetum purpureum cross",
            category = "Perennial Grass",
            soilAndClimate = "Clay loam and sandy loam with pH 6.5–8.0. Tolerates mild salinity and summer heat.",
            landPreparation = "Deep ploughing, 20 tonnes compost/ha, ridges formed 60 cm apart.",
            propagationAndSpacing = "Rooted slips planted at 60 cm x 50 cm spacing in ridges.",
            seedOrSlipRate = "13,000 slips per acre.",
            fertilizerDosage = "NPK 75:50:40 kg/acre basal; 30 kg Nitrogen after each harvest.",
            irrigationSchedule = "Once every 8–10 days in winter; 5–7 days in peak summer.",
            harvestingProtocol = "Cut at 15 cm above ground level when crop reaches 1.5–1.8 m height.",
            firstCutDays = "65–70 days",
            regrowthInterval = "40 days",
            expectedAnnualYield = "150–180 Tonnes / acre / year.",
            crudeProteinPct = 15.0,
            dryMatterPct = 21.0,
            feedingGuidelinesForGoats = "Soft leaves, broad foliage, highly palatable for adult does and bucks.",
            silageSuitability = "Good when mixed with 20% legume fodder (Lucerne or Cowpea).",
            precautionsAndAntiNutritional = "Contains minor oxalates; mix with leguminous fodder in 3:1 ratio for balanced calcium absorption."
        ),
        FodderCultivationTechnique(
            id = "tech-lucerne",
            cropName = "Lucerne / Alfalfa (Queen of Fodder)",
            scientificName = "Medicago sativa",
            category = "Legume Fodder",
            soilAndClimate = "Deep, loamy, well-drained fertile soil with neutral to alkaline pH (7.0–8.5). Sensitive to acidity.",
            landPreparation = "Fine tilth required. Broadcast or line sow in flat beds (2m x 3m). Apply 10 tonnes FYM/acre.",
            propagationAndSpacing = "Line sowing in rows 20–25 cm apart with Rhizobium-treated seeds.",
            seedOrSlipRate = "8–10 kg seeds per acre.",
            fertilizerDosage = "Basal NPK 25:80:40 kg/acre + 20 kg Sulphur/acre. Requires high phosphorus for nodulation.",
            irrigationSchedule = "Light frequent irrigation; 1st day, 3rd day, then every 6–8 days. Avoid stagnant water.",
            harvestingProtocol = "Cut at 10% flowering stage or when crown buds sprout. Leave 5 cm stubble.",
            firstCutDays = "55–60 days",
            regrowthInterval = "25–30 days",
            expectedAnnualYield = "35–45 Tonnes / acre / year (10–12 cuts).",
            crudeProteinPct = 21.5,
            dryMatterPct = 24.0,
            feedingGuidelinesForGoats = "Supreme protein source for lactating does and growing kids (0.5–1.5 kg/head/day).",
            silageSuitability = "Low alone due to high buffering capacity; blend 1:3 with maize/napier or make sun-cured Hay.",
            precautionsAndAntiNutritional = "Can cause bloat if fed damp or exclusively. Always wilt before feeding and mix with dry roughage."
        ),
        FodderCultivationTechnique(
            id = "tech-hedge-lucerne",
            cropName = "Hedge Lucerne / Velimasal",
            scientificName = "Desmanthus virgatus",
            category = "Legume Fodder",
            soilAndClimate = "Drought-hardy perennial; grows in gravelly, stony, alkaline soils under low rainfall.",
            landPreparation = "Plough twice; form ridges at 50 cm spacing. Incorporate 5 tonnes compost/acre.",
            propagationAndSpacing = "Hot water seed treatment (80°C for 5 mins) to break hard seed coat. Row spacing 50 cm.",
            seedOrSlipRate = "6–8 kg treated seed per acre.",
            fertilizerDosage = "Basal NPK 20:60:20 kg/acre. No top dressing nitrogen needed (fixes atmospheric nitrogen).",
            irrigationSchedule = "Can survive rainfed; with irrigation every 15 days, yield doubles.",
            harvestingProtocol = "Cut at 20 cm height when crop reaches 80–100 cm height.",
            firstCutDays = "75–80 days",
            regrowthInterval = "45 days (6–7 cuts/year)",
            expectedAnnualYield = "40–50 Tonnes / acre / year.",
            crudeProteinPct = 20.0,
            dryMatterPct = 26.0,
            feedingGuidelinesForGoats = "Zero bloat risk! Ideal daily browse for stall-fed goats; excellent feed efficiency.",
            silageSuitability = "Moderate; usually fed green fresh or dried into leaf meal pellets.",
            precautionsAndAntiNutritional = "Completely safe with no anti-nutritional factors; can be fed up to 40% of daily ration."
        ),
        FodderCultivationTechnique(
            id = "tech-subabul",
            cropName = "Subabul / White Leadtree",
            scientificName = "Leucaena leucocephala",
            category = "Tree Fodder / Browse",
            soilAndClimate = "Deep well-drained soils; highly drought-resistant once established.",
            landPreparation = "Dig planting pits 30x30x30 cm or high-density hedgerows (1.5 m between paired rows).",
            propagationAndSpacing = "Seeds soaked in hot water; planted as intensive hedgerow (1m x 0.2m) or fence boundary.",
            seedOrSlipRate = "3–4 kg seeds / acre for intensive hedge fodder bank.",
            fertilizerDosage = "Apply 5 kg compost per pit during planting; 50 kg SSP per acre annually.",
            irrigationSchedule = "Establishment irrigation for 3 months; thereafter rainfed or monthly irrigation.",
            harvestingProtocol = "Lopping branches at 1 m height (pollarding) when shoots are 1.2 m long.",
            firstCutDays = "150–180 days after planting",
            regrowthInterval = "50–60 days (5–6 prunings/year)",
            expectedAnnualYield = "30–40 Tonnes fresh leafy biomass / acre / year.",
            crudeProteinPct = 23.0,
            dryMatterPct = 28.0,
            feedingGuidelinesForGoats = "Goats relish leaves and tender green pods. Boosts weight gain in male kids.",
            silageSuitability = "Not suitable alone; dry into leaf meal for concentrate replacement.",
            precautionsAndAntiNutritional = "Contains amino acid Mimosine. Limit Subabul to maximum 30% of total diet to prevent hair loss."
        ),
        FodderCultivationTechnique(
            id = "tech-guinea-grass",
            cropName = "Guinea Grass (Hamil / Riversdale)",
            scientificName = "Panicum maximum",
            category = "Perennial Grass",
            soilAndClimate = "Grows well under tree shade (agroforestry / coconut groves); prefers sandy loam.",
            landPreparation = "Two ploughings; ridges at 60 cm apart. Apply 10 tonnes FYM/acre.",
            propagationAndSpacing = "Rooted tussocks / slips at 60 cm x 40 cm spacing.",
            seedOrSlipRate = "15,000 rooted slips per acre.",
            fertilizerDosage = "NPK 40:30:20 kg/acre basal; 20 kg Urea after each cut.",
            irrigationSchedule = "Once every 10–12 days; drought tolerant.",
            harvestingProtocol = "Cut at 15 cm height before flowering stage.",
            firstCutDays = "60 days",
            regrowthInterval = "35–40 days",
            expectedAnnualYield = "70–90 Tonnes / acre / year.",
            crudeProteinPct = 12.0,
            dryMatterPct = 23.0,
            feedingGuidelinesForGoats = "Soft palatable grass; excellent maintenance roughage for adult doe herds.",
            silageSuitability = "Moderate; combine with energy source.",
            precautionsAndAntiNutritional = "Harvest before flowering to avoid lignification and dropped palatability."
        ),
        FodderCultivationTechnique(
            id = "tech-cofs29",
            cropName = "Multicut Fodder Sorghum (COFS-29 / Co-31)",
            scientificName = "Sorghum bicolor x Sorghum sudanense",
            category = "Cereal Fodder",
            soilAndClimate = "Grows in semi-arid plains; drought resistant; neutral to saline soils.",
            landPreparation = "Fine seedbed; line sowing in 30 cm rows with 5 tonnes FYM/acre.",
            propagationAndSpacing = "Direct seed drilling in 30 cm rows.",
            seedOrSlipRate = "5 kg seeds per acre.",
            fertilizerDosage = "Basal NPK 40:20:20 kg/acre; 20 kg Urea after every cutting.",
            irrigationSchedule = "Once every 12–15 days; tolerates dry spells.",
            harvestingProtocol = "Cut at 10–12 cm stubble height when crop is 50% flowering or 1.5m tall.",
            firstCutDays = "60–65 days",
            regrowthInterval = "45 days (4–5 cuts per sowing)",
            expectedAnnualYield = "80–100 Tonnes / acre / year.",
            crudeProteinPct = 11.5,
            dryMatterPct = 22.0,
            feedingGuidelinesForGoats = "Sweet juicy stalks, high soluble carbohydrates. Great energy source.",
            silageSuitability = "Excellent. High sugar content promotes natural lactic acid fermentation.",
            precautionsAndAntiNutritional = "DANGER: Immature sorghum (<45 days or drought stressed) contains HCN (Prussic acid). Never harvest before 50 days!"
        ),
        FodderCultivationTechnique(
            id = "tech-maize",
            cropName = "Fodder Maize (African Tall)",
            scientificName = "Zea mays var. African Tall",
            category = "Cereal Fodder",
            soilAndClimate = "Rich, loamy, fertile soil with good water holding capacity. Non-waterlogged.",
            landPreparation = "Well pulverised soil; ridges and furrows at 30 cm spacing.",
            propagationAndSpacing = "Direct seeding at 30 cm x 15 cm.",
            seedOrSlipRate = "16–18 kg seeds per acre.",
            fertilizerDosage = "Basal NPK 60:40:30 kg/acre; top dress 30 kg Nitrogen at 30 days.",
            irrigationSchedule = "Weekly irrigation; critical at tasseling and silking.",
            harvestingProtocol = "Single-cut crop. Harvest at milk to early-dough stage (cob formation).",
            firstCutDays = "65–70 days (single harvest)",
            regrowthInterval = "N/A (Single Cut)",
            expectedAnnualYield = "18–22 Tonnes / acre / crop (3 crops/year = 60 T/yr).",
            crudeProteinPct = 10.0,
            dryMatterPct = 25.0,
            feedingGuidelinesForGoats = "Gold standard for milk production in lactating does and intensive fattening.",
            silageSuitability = "The absolute #1 crop for high-energy silage bags/pits. Best starch & energy.",
            precautionsAndAntiNutritional = "Non-toxic, safe for all goat age groups. Chop fine to prevent wastage of thick lower stalk."
        )
    )

    // Species CRUD
    suspend fun saveSpecies(species: FodderSpeciesEntity): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            fodderDao.insertOrUpdateSpecies(species)
            enqueueFodderSync("local_fodder_species", species.id, "UPSERT", JSONObject().apply {
                put("id", species.id)
                put("name", species.name)
                put("category", species.category)
            })
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun deleteSpecies(id: String) = withContext(Dispatchers.IO) {
        fodderDao.deleteSpeciesById(id)
        enqueueFodderSync("local_fodder_species", id, "DELETE", JSONObject().apply { put("id", id) })
    }

    suspend fun deleteCutting(id: String) = withContext(Dispatchers.IO) {
        fodderDao.deleteCuttingById(id)
        enqueueFodderSync("local_fodder_cuttings", id, "DELETE", JSONObject().apply { put("id", id) })
    }

    suspend fun deleteFeeding(id: String) = withContext(Dispatchers.IO) {
        fodderDao.deleteFeedingById(id)
        enqueueFodderSync("local_fodder_feedings", id, "DELETE", JSONObject().apply { put("id", id) })
    }

    // Reports compilation
    suspend fun compileSpeciesReport(): List<SpeciesReportItem> = withContext(Dispatchers.IO) {
        val speciesList = fodderDao.getAllSpecies()
        val plotsList = fodderDao.getAllPlots()
        val cuttingsList = fodderDao.getAllCuttings()

        speciesList.map { sp ->
            val matchingPlots = plotsList.filter { it.species_id == sp.id || it.species_name == sp.name }
            val totalArea = matchingPlots.sumOf { it.area_value }
            val matchingCuttings = cuttingsList.filter { it.species_id == sp.id || it.species_name == sp.name }
            val totalHarvested = matchingCuttings.sumOf { it.harvested_weight_kg }
            val totalCuts = matchingCuttings.size
            val avgYield = if (totalCuts > 0) totalHarvested / totalCuts else 0.0

            SpeciesReportItem(
                speciesName = sp.name,
                category = sp.category,
                crudeProteinPct = sp.crude_protein_pct,
                totalPlots = matchingPlots.size,
                totalAreaAcres = totalArea,
                totalHarvestedKg = totalHarvested,
                totalCuts = totalCuts,
                avgYieldPerCutKg = avgYield
            )
        }
    }

    suspend fun compilePlotReport(): List<PlotReportItem> = withContext(Dispatchers.IO) {
        val plotsList = fodderDao.getAllPlots()
        val cuttingsList = fodderDao.getAllCuttings()
        val allRows = fodderDao.getAllRows()
        val now = System.currentTimeMillis()

        plotsList.map { plot ->
            val matchingCuttings = cuttingsList.filter { it.plot_id == plot.id }
            val totalHarvested = matchingCuttings.sumOf { it.harvested_weight_kg }
            val yieldPerAcre = if (plot.area_value > 0) totalHarvested / plot.area_value else 0.0

            val daysSince = plot.last_cut_date?.let {
                try {
                    val d = dateFormat.parse(it)
                    if (d != null) TimeUnit.MILLISECONDS.toDays(now - d.time).toInt() else null
                } catch (_: Exception) { null }
            }

            val daysUntil = plot.next_expected_cut_date?.let {
                try {
                    val d = dateFormat.parse(it)
                    if (d != null) TimeUnit.MILLISECONDS.toDays(d.time - now).toInt() else null
                } catch (_: Exception) { null }
            }

            val progressPct = when {
                plot.crop_cycle_status.contains("Ready", ignoreCase = true) -> 100
                daysSince != null -> ((daysSince.toFloat() / 42f) * 100f).toInt().coerceIn(0, 100)
                else -> 40
            }

            val pRows = allRows.filter { it.plot_id == plot.id }
            val harvestedRowsCount = pRows.count { it.status == "Harvested" }

            PlotReportItem(
                plotId = plot.id,
                plotName = plot.plot_name,
                speciesName = plot.species_name,
                areaAcres = plot.area_value,
                currentCutCount = plot.current_cut_count,
                totalHarvestedKg = totalHarvested,
                yieldPerAcreKg = yieldPerAcre,
                daysSinceLastCut = daysSince,
                daysUntilNextCut = daysUntil,
                regrowthProgressPct = progressPct,
                status = plot.crop_cycle_status,
                totalRows = plot.row_count,
                totalRowLengthM = plot.row_count * plot.row_length,
                harvestedRowCount = harvestedRowsCount
            )
        }
    }

    suspend fun deleteActivity(id: String) = withContext(Dispatchers.IO) {
        fodderDao.deleteActivityById(id)
        enqueueFodderSync("local_fodder_activities", id, "DELETE", JSONObject().apply { put("id", id) })
    }

    suspend fun deleteMaterial(id: String) = withContext(Dispatchers.IO) {
        fodderDao.deleteMaterialById(id)
        enqueueFodderSync("local_fodder_materials", id, "DELETE", JSONObject().apply { put("id", id) })
    }

    private suspend fun enqueueFodderSync(table: String, recordId: String, operation: String, payload: JSONObject) {
        try {
            syncManager.enqueueOperation(
                table = table,
                recordId = recordId,
                operationType = operation,
                payload = payload
            )
        } catch (e: Exception) {
            Log.w(TAG, "Sync enqueue failed: ${e.message}")
        }
    }
}
