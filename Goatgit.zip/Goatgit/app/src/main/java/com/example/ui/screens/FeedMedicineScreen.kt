package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.supabase.*
import com.example.i18n.t
import com.example.ui.components.DatePickerField
import com.example.ui.components.FarmTopBar
import com.example.ui.theme.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FeedMedicineScreen(
    repository: GoatRepository,
    initialTab: Int = 0, // 0 = Feed, 1 = Medicine
    onNavigateToFeedInventory: () -> Unit = {},
    onNavigateBack: () -> Unit
) {
    var selectedTab by remember { mutableIntStateOf(initialTab) }
    var feedItems by remember { mutableStateOf<List<FeedItem>>(emptyList()) }
    var medicineItems by remember { mutableStateOf<List<MedicineItem>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }
    var showMovementDialog by remember { mutableStateOf<FeedItem?>(null) }

    val coroutineScope = rememberCoroutineScope()
    val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.US)
    val today = remember { dateFormat.format(Date()) }

    fun loadData() {
        isLoading = true
        coroutineScope.launch {
            val fRes = repository.getFeedInventory()
            if (fRes.isSuccess) feedItems = fRes.getOrThrow()
            val mRes = repository.getMedicineInventory()
            if (mRes.isSuccess) medicineItems = mRes.getOrThrow()
            isLoading = false
        }
    }

    LaunchedEffect(Unit) {
        loadData()
    }

    Scaffold(
        topBar = {
            FarmTopBar(
                title = if (selectedTab == 0) t("feed.tab_feed") else t("feed.tab_medicine"),
                canNavigateBack = true,
                onNavigateBack = onNavigateBack,
                actions = {
                    IconButton(onClick = { loadData() }) {
                        Icon(Icons.Default.Refresh, contentDescription = t("topbar.refresh"), tint = Color.White)
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(FarmBackgroundLight)
                .padding(padding)
        ) {
            TabRow(selectedTabIndex = selectedTab, containerColor = Color.White) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = { Text("${t("feed.stock")} (${feedItems.size})", fontWeight = FontWeight.Bold) }
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = { Text("${t("feed.tab_medicine")} (${medicineItems.size})", fontWeight = FontWeight.Bold) }
                )
            }

            if (isLoading) {
                Box(modifier = Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = FarmGreenPrimary)
                }
            } else if (selectedTab == 0) {
                // Feed Tab
                LazyColumn(
                    modifier = Modifier.fillMaxSize().padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = FarmGreenContainer)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text("Goat Feed Inventory & Usage Manager", fontWeight = FontWeight.Bold, color = FarmOnGreenContainer)
                                    Text("Track stock levels, add new feed types & log daily usage per day", fontSize = 11.sp, color = FarmGreenDark)
                                }
                                Button(
                                    onClick = onNavigateToFeedInventory,
                                    colors = ButtonDefaults.buttonColors(containerColor = FarmGreenPrimary),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text("Open Manager", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }

                    if (feedItems.isEmpty()) {
                        item {
                            Card(
                                modifier = Modifier.fillMaxWidth().padding(16.dp),
                                colors = CardDefaults.cardColors(containerColor = Color.White)
                            ) {
                                Column(modifier = Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                    Icon(Icons.Default.Grass, contentDescription = null, tint = FarmGreenPrimary, modifier = Modifier.size(40.dp))
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text(t("state.no_data"), fontWeight = FontWeight.SemiBold)
                                }
                            }
                        }
                    }

                    items(feedItems) { feed ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(16.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(feed.name_c, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                                    Text("${feed.category_c ?: t("feed.stock")} • ${t("feed.stock")}: ${feed.current_stock_kg_c} ${feed.unit_c}", color = FarmGreenDark, fontWeight = FontWeight.SemiBold)
                                    if (feed.cost_per_unit_c != null) {
                                        Text("${t("feed.unit_cost")}: ₹${feed.cost_per_unit_c}/${feed.unit_c}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                }
                                Button(
                                    onClick = { showMovementDialog = feed },
                                    colors = ButtonDefaults.buttonColors(containerColor = FarmGreenContainer, contentColor = FarmOnGreenContainer),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text(t("feed.log_consumption"), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            } else {
                // Medicine Tab
                LazyColumn(
                    modifier = Modifier.fillMaxSize().padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    if (medicineItems.isEmpty()) {
                        item {
                            Card(
                                modifier = Modifier.fillMaxWidth().padding(16.dp),
                                colors = CardDefaults.cardColors(containerColor = Color.White)
                            ) {
                                Column(modifier = Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                    Icon(Icons.Default.Medication, contentDescription = null, tint = FarmGreenPrimary, modifier = Modifier.size(40.dp))
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text(t("state.no_data"), fontWeight = FontWeight.SemiBold)
                                }
                            }
                        }
                    }

                    items(medicineItems) { med ->
                        val isLowStock = med.quantity_c <= med.reorder_level_c
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(med.medicine_name_c, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                                    Surface(
                                        shape = RoundedCornerShape(8.dp),
                                        color = if (isLowStock) FarmWarningContainer else FarmGreenContainer
                                    ) {
                                        Text(
                                            text = "${med.quantity_c} ${med.unit_c}",
                                            fontWeight = FontWeight.Bold,
                                            color = if (isLowStock) FarmWarning else FarmOnGreenContainer,
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                                            style = MaterialTheme.typography.labelMedium
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(6.dp))
                                Text("${t("feed.stock")}: ${med.category_c} • ${t("feed.low_stock_warning")}: ${med.reorder_level_c} ${med.unit_c}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)

                                Row(
                                    modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    if (!med.expiry_date_c.isNullOrBlank()) {
                                        Text("Exp: ${med.expiry_date_c}", style = MaterialTheme.typography.bodySmall, color = Color(0xFFC62828))
                                    }
                                    if (!med.supplier_c.isNullOrBlank()) {
                                        Text("${t("feed.supplier")}: ${med.supplier_c}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Feed Movement Dialog
    showMovementDialog?.let { feed ->
        var movementType by remember { mutableStateOf("Consumption") } // Purchase, Consumption, Wastage, Adjustment
        var qtyStr by remember { mutableStateOf("10.0") }
        var movDate by remember { mutableStateOf(today) }
        var notes by remember { mutableStateOf("") }
        var savingMovement by remember { mutableStateOf(false) }
        var movementError by remember { mutableStateOf<String?>(null) }

        val movementTypes = listOf("Consumption", "Purchase", "Wastage", "Adjustment")

        AlertDialog(
            onDismissRequest = { showMovementDialog = null },
            title = { Text("${t("feed.log_consumption")} - ${feed.name_c}", fontWeight = FontWeight.Bold) },
            text = {
                Column(modifier = Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(t("feed.tab_feed"), fontWeight = FontWeight.SemiBold)
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        movementTypes.forEach { mt ->
                            FilterChip(
                                selected = movementType == mt,
                                onClick = { movementType = mt },
                                label = { Text(mt, fontSize = 10.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = FarmGreenPrimary,
                                    selectedLabelColor = Color.White
                                )
                            )
                        }
                    }

                    OutlinedTextField(
                        value = qtyStr,
                        onValueChange = { qtyStr = it },
                        label = { Text("${t("feed.quantity")} (${feed.unit_c}) *") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    DatePickerField(
                        dateValue = movDate,
                        onDateSelected = { movDate = it },
                        label = t("feed.date")
                    )

                    OutlinedTextField(
                        value = notes,
                        onValueChange = { notes = it },
                        label = { Text(t("herd.notes")) },
                        placeholder = { Text("e.g. Afternoon feeding pen A") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    if (movementError != null) {
                        Text(movementError ?: "", color = FarmError, style = MaterialTheme.typography.bodySmall)
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val qty = qtyStr.toDoubleOrNull()
                        if (qty == null || qty <= 0.0) {
                            movementError = "Please enter valid quantity."
                            return@Button
                        }
                        savingMovement = true
                        movementError = null
                        coroutineScope.launch {
                            val mov = FeedMovement(
                                feed_id_c = feed.id,
                                movement_type_c = movementType,
                                quantity_c = qty,
                                date_c = movDate,
                                notes_c = notes.ifBlank { null }
                            )
                            val res = repository.recordFeedMovement(mov)
                            savingMovement = false
                            if (res.isSuccess) {
                                showMovementDialog = null
                                loadData()
                            } else {
                                movementError = res.exceptionOrNull()?.message ?: "Failed to log movement"
                            }
                        }
                    },
                    enabled = !savingMovement,
                    colors = ButtonDefaults.buttonColors(containerColor = FarmGreenPrimary)
                ) {
                    if (savingMovement) CircularProgressIndicator(color = Color.White, modifier = Modifier.size(18.dp))
                    else Text(t("btn.save"))
                }
            },
            dismissButton = {
                TextButton(onClick = { showMovementDialog = null }) {
                    Text(t("btn.cancel"))
                }
            }
        )
    }
}
