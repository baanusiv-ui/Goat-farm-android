package com.example.ui.screens.finance

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.supabase.*
import com.example.ui.components.DatePickerField
import com.example.ui.theme.*
import com.example.util.CurrencyUtils
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LoansScreen(
    repository: GoatRepository,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler { onNavigateBack() }

    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val dateFormat = remember { SimpleDateFormat("yyyy-MM-dd", Locale.US) }
    val today = remember { dateFormat.format(Date()) }

    var loans by remember { mutableStateOf<List<Loan>>(emptyList()) }
    var accounts by remember { mutableStateOf<List<FinancialAccount>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }

    var showAddLoanDialog by remember { mutableStateOf(false) }
    var viewingSchedulesLoan by remember { mutableStateOf<Loan?>(null) }
    var loanSchedules by remember { mutableStateOf<List<LoanSchedule>>(emptyList()) }
    var payingSchedule by remember { mutableStateOf<LoanSchedule?>(null) }

    fun loadData() {
        isLoading = true
        coroutineScope.launch {
            val loanRes = repository.finance.getLoans()
            if (loanRes.isSuccess) {
                loans = loanRes.getOrThrow()
            }
            val accRes = repository.finance.getAccounts()
            if (accRes.isSuccess) {
                accounts = accRes.getOrThrow()
            }
            isLoading = false
        }
    }

    LaunchedEffect(Unit) {
        loadData()
    }

    val totalOutstanding = remember(loans) { loans.filter { it.status == "ACTIVE" }.sumOf { it.outstanding_principal } }
    val totalPrincipalRepaid = remember(loans) { loans.sumOf { it.total_principal_paid } }
    val totalInterestPaid = remember(loans) { loans.sumOf { it.total_interest_paid } }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "Loans & Borrowings",
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp
                        )
                        Text(
                            text = "Amortization Schedules & Principal/Interest Accounting",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack, modifier = Modifier.testTag("loans_btn_back")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(onClick = { loadData() }, modifier = Modifier.testTag("loans_btn_refresh")) {
                        Icon(Icons.Default.Refresh, contentDescription = "Refresh")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.White)
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { showAddLoanDialog = true },
                containerColor = Color(0xFF1E3A8A),
                contentColor = Color.White,
                icon = { Icon(Icons.Default.Add, contentDescription = null) },
                text = { Text("Add Loan", fontWeight = FontWeight.Bold) },
                modifier = Modifier.testTag("btn_add_loan")
            )
        },
        containerColor = Color(0xFFF8F9FA),
        modifier = modifier
    ) { innerPadding ->
        if (isLoading) {
            Box(modifier = Modifier.fillMaxSize().padding(innerPadding), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = FarmGreenDark)
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                item { Spacer(modifier = Modifier.height(4.dp)) }

                // Loans Dashboard Card
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF1E3A8A)),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.fillMaxWidth().testTag("loan_summary_card")
                    ) {
                        Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Text("Total Outstanding Loan Principal", color = Color.White.copy(alpha = 0.85f), fontSize = 12.sp)
                            Text(
                                text = CurrencyUtils.formatInr(totalOutstanding),
                                fontSize = 28.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = Color.White
                            )

                            HorizontalDivider(color = Color.White.copy(alpha = 0.2f))

                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Column {
                                    Text("Principal Repaid", color = Color.White.copy(alpha = 0.8f), fontSize = 11.sp)
                                    Text(CurrencyUtils.formatInr(totalPrincipalRepaid), fontWeight = FontWeight.Bold, color = Color.White, fontSize = 14.sp)
                                }
                                Column(horizontalAlignment = Alignment.End) {
                                    Text("Interest Paid (P&L Exp)", color = Color.White.copy(alpha = 0.8f), fontSize = 11.sp)
                                    Text(CurrencyUtils.formatInr(totalInterestPaid), fontWeight = FontWeight.Bold, color = Color(0xFFFDE047), fontSize = 14.sp)
                                }
                            }
                        }
                    }
                }

                // Accounting Rule Notice
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFEFF6FF)),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.AccountBalance, contentDescription = null, tint = Color(0xFF1E40AF), modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Accounting Integrity: Loan Receipt = Financing Inflow (NOT income). Principal Repayment = Financing Outflow (NOT operating expense). Only Interest is expensed.",
                                fontSize = 11.sp,
                                color = Color(0xFF1E3A8A),
                                lineHeight = 15.sp
                            )
                        }
                    }
                }

                item {
                    Text("Farm Loan Accounts", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = FarmGreenDark)
                }

                if (loans.isEmpty()) {
                    item {
                        Card(colors = CardDefaults.cardColors(containerColor = Color.White), modifier = Modifier.fillMaxWidth().padding(vertical = 16.dp)) {
                            Box(modifier = Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                                Text("No loans recorded. Tap '+ Add Loan' to track bank, vehicle, or equipment loans.", color = Color.Gray, fontSize = 13.sp)
                            }
                        }
                    }
                } else {
                    items(loans) { loan ->
                        LoanCardItem(
                            loan = loan,
                            onViewSchedule = {
                                viewingSchedulesLoan = loan
                                coroutineScope.launch {
                                    val res = repository.finance.getLoanSchedules(loan.id)
                                    if (res.isSuccess) {
                                        loanSchedules = res.getOrThrow()
                                    }
                                }
                            }
                        )
                    }
                }

                item { Spacer(modifier = Modifier.height(72.dp)) }
            }
        }
    }

    // Add Loan Dialog
    if (showAddLoanDialog) {
        AddLoanDialog(
            accounts = accounts,
            onDismiss = { showAddLoanDialog = false },
            onSave = { loan ->
                showAddLoanDialog = false
                coroutineScope.launch {
                    val res = repository.finance.addLoan(loan)
                    if (res.isSuccess) {
                        Toast.makeText(context, "Loan recorded & EMI schedule generated!", Toast.LENGTH_SHORT).show()
                        loadData()
                    } else {
                        Toast.makeText(context, "Failed: ${res.exceptionOrNull()?.message}", Toast.LENGTH_LONG).show()
                    }
                }
            }
        )
    }

    // View Amortization Schedule Dialog
    if (viewingSchedulesLoan != null) {
        LoanScheduleDialog(
            loan = viewingSchedulesLoan!!,
            schedules = loanSchedules,
            onDismiss = { viewingSchedulesLoan = null },
            onPayEmi = { sched ->
                payingSchedule = sched
            }
        )
    }

    // Pay EMI Dialog
    if (payingSchedule != null) {
        PayEmiDialog(
            schedule = payingSchedule!!,
            accounts = accounts,
            onDismiss = { payingSchedule = null },
            onConfirmPay = { schedId, accId, date ->
                payingSchedule = null
                coroutineScope.launch {
                    val res = repository.finance.payLoanEmi(schedId, accId, date)
                    if (res.isSuccess) {
                        Toast.makeText(context, "EMI paid: Principal & Interest split correctly!", Toast.LENGTH_SHORT).show()
                        loadData()
                        // refresh schedules
                        viewingSchedulesLoan?.let { l ->
                            val sRes = repository.finance.getLoanSchedules(l.id)
                            if (sRes.isSuccess) loanSchedules = sRes.getOrThrow()
                        }
                    } else {
                        Toast.makeText(context, "Payment failed: ${res.exceptionOrNull()?.message}", Toast.LENGTH_LONG).show()
                    }
                }
            }
        )
    }
}

@Composable
private fun LoanCardItem(
    loan: Loan,
    onViewSchedule: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(14.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier.fillMaxWidth().testTag("loan_card_${loan.id}")
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(loan.loan_name, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    Text("${loan.lender} • A/c: ${loan.loan_account_number}", fontSize = 11.sp, color = Color.Gray)
                }
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = if (loan.status == "ACTIVE") Color(0xFFE8F5E9) else Color(0xFFF5F5F5)
                ) {
                    Text(
                        text = loan.status,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (loan.status == "ACTIVE") FarmGreenDark else Color.DarkGray,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
            }

            HorizontalDivider(color = Color(0xFFF0F0F0))

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Column {
                    Text("Disbursed: ${CurrencyUtils.formatInr(loan.disbursed_amount)}", fontSize = 11.sp, color = Color.DarkGray)
                    Text("EMI: ${CurrencyUtils.formatInr(loan.emi_amount)}/mo", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = FarmGreenDark)
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text("Outstanding Principal", fontSize = 10.sp, color = Color.Gray)
                    Text(
                        text = CurrencyUtils.formatInr(loan.outstanding_principal),
                        fontSize = 14.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = if (loan.outstanding_principal > 0) Color(0xFF1E3A8A) else FarmGreenDark
                    )
                }
            }

            Button(
                onClick = onViewSchedule,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E3A8A)),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.fillMaxWidth().height(36.dp).testTag("btn_view_schedule_${loan.id}")
            ) {
                Icon(Icons.Default.CalendarMonth, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("View EMI Amortization Schedule", fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }
        }
    }
}

@Composable
private fun LoanScheduleDialog(
    loan: Loan,
    schedules: List<LoanSchedule>,
    onDismiss: () -> Unit,
    onPayEmi: (LoanSchedule) -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Surface(shape = RoundedCornerShape(16.dp), color = Color.White, modifier = Modifier.fillMaxWidth().fillMaxHeight(0.85f)) {
            Column(modifier = Modifier.padding(18.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(loan.loan_name, fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Color(0xFF1E3A8A))
                        Text("${schedules.size} EMI Schedule • ${loan.interest_rate}% p.a.", fontSize = 11.sp, color = Color.Gray)
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close")
                    }
                }

                HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

                LazyColumn(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(schedules) { s ->
                        val isPaid = s.status == "PAID"
                        Card(
                            colors = CardDefaults.cardColors(containerColor = if (isPaid) Color(0xFFF1F8E9) else Color(0xFFF9FAFB)),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text("EMI #${s.emi_number} • Due: ${s.due_date}", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                    Text(
                                        text = "Principal: ₹${s.principal_component.toInt()} | Interest: ₹${s.interest_component.toInt()}",
                                        fontSize = 11.sp,
                                        color = Color.DarkGray
                                    )
                                    Text("Balance: ₹${s.closing_principal.toInt()}", fontSize = 10.sp, color = Color.Gray)
                                }

                                if (isPaid) {
                                    Surface(shape = RoundedCornerShape(4.dp), color = Color(0xFFE8F5E9)) {
                                        Text("PAID", color = FarmGreenDark, fontWeight = FontWeight.Bold, fontSize = 10.sp, modifier = Modifier.padding(4.dp))
                                    }
                                } else {
                                    Button(
                                        onClick = { onPayEmi(s) },
                                        colors = ButtonDefaults.buttonColors(containerColor = FarmGreenDark),
                                        shape = RoundedCornerShape(6.dp),
                                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                                        modifier = Modifier.height(30.dp)
                                    ) {
                                        Text("Pay ₹${s.emi_amount.toInt()}", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AddLoanDialog(
    accounts: List<FinancialAccount>,
    onDismiss: () -> Unit,
    onSave: (Loan) -> Unit
) {
    var lender by remember { mutableStateOf("") }
    var loanName by remember { mutableStateOf("") }
    var accountNo by remember { mutableStateOf("") }
    var loanType by remember { mutableStateOf("BANK_LOAN") }
    var sanctionedStr by remember { mutableStateOf("500000") }
    var disbursedStr by remember { mutableStateOf("500000") }
    var rateStr by remember { mutableStateOf("10.5") }
    var tenureStr by remember { mutableStateOf("36") }
    var emiStr by remember { mutableStateOf("16254") }
    var firstEmiDate by remember { mutableStateOf(SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())) }
    var disbAccountId by remember { mutableStateOf(accounts.firstOrNull()?.id ?: "") }

    var typeExpanded by remember { mutableStateOf(false) }
    var accExpanded by remember { mutableStateOf(false) }

    val loanTypes = listOf("BANK_LOAN", "NBFC_LOAN", "VEHICLE_LOAN", "EQUIPMENT_LOAN", "BUSINESS_LOAN", "PERSONAL_LOAN", "OTHER")

    Dialog(onDismissRequest = onDismiss) {
        Surface(shape = RoundedCornerShape(16.dp), color = Color.White, modifier = Modifier.fillMaxWidth().fillMaxHeight(0.9f)) {
            Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Add Loan / Borrowing", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = Color(0xFF1E3A8A))
                Text("Disbursement amount will be credited to selected account as FINANCING INFLOW (not taxable income).", fontSize = 11.sp, color = Color.Gray)

                LazyColumn(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    item {
                        OutlinedTextField(value = lender, onValueChange = { lender = it }, label = { Text("Lender / Bank Name *") }, singleLine = true, modifier = Modifier.fillMaxWidth().testTag("input_lender"))
                    }
                    item {
                        OutlinedTextField(value = loanName, onValueChange = { loanName = it }, label = { Text("Loan Purpose / Name *") }, placeholder = { Text("e.g. Tractor Loan, Shed Construction") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    }
                    item {
                        OutlinedTextField(value = accountNo, onValueChange = { accountNo = it }, label = { Text("Loan Account Number *") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    }
                    item {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(value = sanctionedStr, onValueChange = { sanctionedStr = it }, label = { Text("Sanctioned (₹)") }, modifier = Modifier.weight(1f))
                            OutlinedTextField(value = disbursedStr, onValueChange = { disbursedStr = it }, label = { Text("Disbursed (₹) *") }, modifier = Modifier.weight(1f).testTag("input_disbursed"))
                        }
                    }
                    item {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(value = rateStr, onValueChange = { rateStr = it }, label = { Text("Interest Rate (%)") }, modifier = Modifier.weight(1f))
                            OutlinedTextField(value = tenureStr, onValueChange = { tenureStr = it }, label = { Text("Tenure (Months)") }, modifier = Modifier.weight(1f))
                        }
                    }
                    item {
                        OutlinedTextField(value = emiStr, onValueChange = { emiStr = it }, label = { Text("Monthly EMI (₹) *") }, modifier = Modifier.fillMaxWidth().testTag("input_emi"))
                    }
                    item {
                        DatePickerField(dateValue = firstEmiDate, onDateSelected = { firstEmiDate = it }, label = "First EMI Date *")
                    }
                    item {
                        // Disbursement Account Selector
                        ExposedDropdownMenuBox(expanded = accExpanded, onExpandedChange = { accExpanded = !accExpanded }) {
                            val selAcc = accounts.firstOrNull { it.id == disbAccountId }
                            OutlinedTextField(
                                value = "${selAcc?.account_name ?: "Select Account"} (${CurrencyUtils.formatInr(selAcc?.current_balance ?: 0.0)})",
                                onValueChange = {},
                                readOnly = true,
                                label = { Text("Disbursement Deposit Account") },
                                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = accExpanded) },
                                modifier = Modifier.fillMaxWidth().menuAnchor()
                            )
                            ExposedDropdownMenu(expanded = accExpanded, onDismissRequest = { accExpanded = false }) {
                                accounts.forEach { acc ->
                                    DropdownMenuItem(text = { Text("${acc.account_name} (${CurrencyUtils.formatInr(acc.current_balance)})") }, onClick = { disbAccountId = acc.id; accExpanded = false })
                                }
                            }
                        }
                    }
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    TextButton(onClick = onDismiss) { Text("Cancel") }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            val disbursed = disbursedStr.toDoubleOrNull() ?: 0.0
                            val emi = emiStr.toDoubleOrNull() ?: 0.0
                            val tenure = tenureStr.toIntOrNull() ?: 12
                            val rate = rateStr.toDoubleOrNull() ?: 10.0
                            if (lender.isBlank() || disbursed <= 0 || emi <= 0) return@Button

                            val cal = Calendar.getInstance()
                            cal.time = SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(firstEmiDate) ?: Date()
                            cal.add(Calendar.MONTH, tenure)
                            val maturity = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(cal.time)

                            val loan = Loan(
                                lender = lender.trim(),
                                loan_name = loanName.trim().ifBlank { "$lender Loan" },
                                loan_account_number = accountNo.trim().ifBlank { "LA-" + System.currentTimeMillis().toString().takeLast(6) },
                                loan_type = loanType,
                                sanctioned_amount = sanctionedStr.toDoubleOrNull() ?: disbursed,
                                disbursed_amount = disbursed,
                                interest_rate = rate,
                                tenure_months = tenure,
                                emi_amount = emi,
                                start_date = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date()),
                                first_emi_date = firstEmiDate,
                                maturity_date = maturity,
                                outstanding_principal = disbursed,
                                disbursement_account_id = disbAccountId.ifBlank { null }
                            )
                            onSave(loan)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E3A8A)),
                        enabled = lender.isNotBlank() && (disbursedStr.toDoubleOrNull() ?: 0.0) > 0,
                        modifier = Modifier.testTag("btn_save_loan")
                    ) {
                        Text("Create Loan & Schedule")
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun PayEmiDialog(
    schedule: LoanSchedule,
    accounts: List<FinancialAccount>,
    onDismiss: () -> Unit,
    onConfirmPay: (schedId: String, accountId: String, date: String) -> Unit
) {
    var accountId by remember { mutableStateOf(accounts.firstOrNull()?.id ?: "") }
    var payDate by remember { mutableStateOf(SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())) }
    var accExpanded by remember { mutableStateOf(false) }

    Dialog(onDismissRequest = onDismiss) {
        Surface(shape = RoundedCornerShape(16.dp), color = Color.White, modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Pay Loan EMI #${schedule.emi_number}", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = Color(0xFF1E3A8A))
                Text(
                    text = "Principal portion (₹${schedule.principal_component.toInt()}) will be treated as Financing Outflow, and Interest portion (₹${schedule.interest_component.toInt()}) will be expensed in P&L.",
                    fontSize = 11.sp,
                    color = Color.DarkGray
                )

                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFF1F8E9)), modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("Total EMI Amount: ${CurrencyUtils.formatInr(schedule.emi_amount)}", fontWeight = FontWeight.ExtraBold, fontSize = 16.sp, color = FarmGreenDark)
                        Text("• Principal Component: ₹${schedule.principal_component.toInt()}", fontSize = 12.sp)
                        Text("• Interest Component: ₹${schedule.interest_component.toInt()}", fontSize = 12.sp)
                    }
                }

                ExposedDropdownMenuBox(expanded = accExpanded, onExpandedChange = { accExpanded = !accExpanded }) {
                    val selAcc = accounts.firstOrNull { it.id == accountId }
                    OutlinedTextField(
                        value = "${selAcc?.account_name ?: "Select Account"} (${CurrencyUtils.formatInr(selAcc?.current_balance ?: 0.0)})",
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Payment Account *") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = accExpanded) },
                        modifier = Modifier.fillMaxWidth().menuAnchor()
                    )
                    ExposedDropdownMenu(expanded = accExpanded, onDismissRequest = { accExpanded = false }) {
                        accounts.forEach { acc ->
                            DropdownMenuItem(text = { Text("${acc.account_name} (${CurrencyUtils.formatInr(acc.current_balance)})") }, onClick = { accountId = acc.id; accExpanded = false })
                        }
                    }
                }

                DatePickerField(dateValue = payDate, onDateSelected = { payDate = it }, label = "Payment Date *")

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    TextButton(onClick = onDismiss) { Text("Cancel") }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            if (accountId.isNotBlank()) onConfirmPay(schedule.id, accountId, payDate)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = FarmGreenDark),
                        enabled = accountId.isNotBlank(),
                        modifier = Modifier.testTag("btn_confirm_pay_emi")
                    ) {
                        Text("Confirm EMI Payment")
                    }
                }
            }
        }
    }
}
