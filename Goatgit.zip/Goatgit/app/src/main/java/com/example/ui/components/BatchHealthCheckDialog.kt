package com.example.ui.components

import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.offline.DailyHealthObservationEntity
import com.example.data.supabase.Goat
import com.example.data.supabase.GoatRepository
import com.example.ui.theme.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun BatchHealthCheckDialog(
    selectedGoats: List<Goat>,
    repository: GoatRepository,
    onDismiss: () -> Unit,
    onSuccess: (count: Int) -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    var isSubmitting by remember { mutableStateOf(false) }

    val todayDate = remember {
        SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
    }

    var observationDate by remember { mutableStateOf(todayDate) }
    var overallHealthRating by remember { mutableStateOf("Healthy") }
    var selectedSymptoms by remember { mutableStateOf(setOf("None")) }
    var appetiteStatus by remember { mutableStateOf("Normal") }
    var activityLevel by remember { mutableStateOf("Active & Alert") }
    var famachaScore by remember { mutableStateOf("Score 1 - Optimal Pink") }
    var temperatureText by remember { mutableStateOf("") }
    var bodyConditionText by remember { mutableStateOf("3.0") }
    var observerName by remember { mutableStateOf("Farm Staff") }
    var notesText by remember { mutableStateOf("") }
    var updateGoatBadgeStatus by remember { mutableStateOf(true) }

    val availableSymptoms = listOf(
        "None",
        "Ticks/Parasites",
        "Cough/Respiratory",
        "Diarrhea/Scours",
        "Loss of Appetite",
        "Lethargy",
        "Lameness",
        "Skin Lesions",
        "Eye Discharge",
        "Fever Signs"
    )

    val healthRatings = listOf(
        "Healthy" to Color(0xFF2E7D32),
        "Mild Concern" to Color(0xFFE65100),
        "Needs Vet Attention" to Color(0xFFC62828),
        "Quarantine" to Color(0xFF6A1B9A)
    )

    Dialog(
        onDismissRequest = { if (!isSubmitting) onDismiss() },
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .fillMaxHeight(0.92f)
                .testTag("batch_health_check_dialog"),
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 6.dp
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(20.dp)
            ) {
                // Header Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(FarmGreenLight),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.HealthAndSafety,
                                contentDescription = null,
                                tint = FarmGreenDark,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "Batch Health Check",
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Applying simultaneously to ${selectedGoats.size} goats",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    IconButton(
                        onClick = onDismiss,
                        enabled = !isSubmitting,
                        modifier = Modifier.testTag("btn_close_batch_health_dialog")
                    ) {
                        Icon(Icons.Default.Close, contentDescription = "Close")
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Scrollable Form Content
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // Selected Goats Tag Chips
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFF1F8E9)),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(
                                text = "Selected Animals (${selectedGoats.size}):",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = FarmGreenDark
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            FlowRow(
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                selectedGoats.forEach { goat ->
                                    Surface(
                                        shape = RoundedCornerShape(8.dp),
                                        color = Color.White,
                                        border = BorderStroke(1.dp, FarmGreenDark.copy(alpha = 0.3f))
                                    ) {
                                        Text(
                                            text = "${goat.tag_c} (${goat.name.ifBlank { goat.breed_c }})",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.SemiBold,
                                            color = FarmGreenDark,
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // 1. Overall Health Rating
                    Column {
                        Text(
                            text = "Overall Health Assessment",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            healthRatings.forEach { (rating, color) ->
                                val isSelected = overallHealthRating == rating
                                FilterChip(
                                    selected = isSelected,
                                    onClick = { overallHealthRating = rating },
                                    label = { Text(rating, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal) },
                                    leadingIcon = if (isSelected) {
                                        { Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp)) }
                                    } else null,
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = color.copy(alpha = 0.15f),
                                        selectedLabelColor = color
                                    ),
                                    border = FilterChipDefaults.filterChipBorder(
                                        enabled = true,
                                        selected = isSelected,
                                        borderColor = if (isSelected) color else Color.LightGray
                                    ),
                                    modifier = Modifier.testTag("chip_health_status_${rating.lowercase().replace(" ", "_")}")
                                )
                            }
                        }
                    }

                    // 2. Symptoms & Observations (Multi-select)
                    Column {
                        Text(
                            text = "Observed Symptoms",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            availableSymptoms.forEach { symptom ->
                                val isSelected = selectedSymptoms.contains(symptom)
                                FilterChip(
                                    selected = isSelected,
                                    onClick = {
                                        selectedSymptoms = if (symptom == "None") {
                                            setOf("None")
                                        } else {
                                            val next = selectedSymptoms - "None"
                                            if (next.contains(symptom)) {
                                                val res = next - symptom
                                                if (res.isEmpty()) setOf("None") else res
                                            } else {
                                                next + symptom
                                            }
                                        }
                                    },
                                    label = { Text(symptom, fontSize = 12.sp) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = if (symptom == "None") FarmGreenContainer else FarmErrorContainer,
                                        selectedLabelColor = if (symptom == "None") FarmGreenDark else FarmError
                                    ),
                                    modifier = Modifier.testTag("chip_symptom_${symptom.lowercase().replace("/", "_").replace(" ", "_")}")
                                )
                            }
                        }
                    }

                    // 3. Clinical Parameters (FAMACHA, Appetite, Activity)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        // Appetite
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Appetite", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold)
                            Spacer(modifier = Modifier.height(4.dp))
                            val appetites = listOf("Normal", "Reduced", "Anorexic")
                            var expanded by remember { mutableStateOf(false) }
                            Box {
                                OutlinedButton(
                                    onClick = { expanded = true },
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text(appetiteStatus, maxLines = 1, fontSize = 12.sp)
                                }
                                DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                                    appetites.forEach {
                                        DropdownMenuItem(
                                            text = { Text(it) },
                                            onClick = {
                                                appetiteStatus = it
                                                expanded = false
                                            }
                                        )
                                    }
                                }
                            }
                        }

                        // Activity
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Activity", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold)
                            Spacer(modifier = Modifier.height(4.dp))
                            val activities = listOf("Active & Alert", "Lethargic", "Depressed")
                            var expanded by remember { mutableStateOf(false) }
                            Box {
                                OutlinedButton(
                                    onClick = { expanded = true },
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text(activityLevel, maxLines = 1, fontSize = 12.sp)
                                }
                                DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                                    activities.forEach {
                                        DropdownMenuItem(
                                            text = { Text(it) },
                                            onClick = {
                                                activityLevel = it
                                                expanded = false
                                            }
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // FAMACHA Anemia Score
                    Column {
                        Text(
                            text = "FAMACHA Eyelid Mucosa Score (Anemia Check)",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.SemiBold
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        val famachaScores = listOf(
                            "Score 1 - Optimal Pink" to Color(0xFFC2185B),
                            "Score 2 - Acceptable" to Color(0xFFE91E63),
                            "Score 3 - Borderline" to Color(0xFFF06292),
                            "Score 4 - Pale Anemic" to Color(0xFFF8BBD0),
                            "Score 5 - Severe White" to Color(0xFFEEEEEE)
                        )
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            famachaScores.forEach { (score, color) ->
                                val isSelected = famachaScore == score
                                FilterChip(
                                    selected = isSelected,
                                    onClick = { famachaScore = score },
                                    label = { Text(score.substringBefore(" -"), fontSize = 11.sp) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = color.copy(alpha = 0.3f)
                                    )
                                )
                            }
                        }
                    }

                    // Temperature and Body Condition Score
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedTextField(
                            value = temperatureText,
                            onValueChange = { temperatureText = it },
                            label = { Text("Temp (°C)") },
                            placeholder = { Text("e.g. 39.2") },
                            singleLine = true,
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("input_batch_temp")
                        )

                        OutlinedTextField(
                            value = bodyConditionText,
                            onValueChange = { bodyConditionText = it },
                            label = { Text("Body Score (1-5)") },
                            placeholder = { Text("e.g. 3.0") },
                            singleLine = true,
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("input_batch_bcs")
                        )
                    }

                    // Observation Date & Observer
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedTextField(
                            value = observationDate,
                            onValueChange = { observationDate = it },
                            label = { Text("Check Date") },
                            singleLine = true,
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("input_batch_date")
                        )

                        OutlinedTextField(
                            value = observerName,
                            onValueChange = { observerName = it },
                            label = { Text("Observed By") },
                            singleLine = true,
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("input_batch_observer")
                        )
                    }

                    // Health Notes
                    OutlinedTextField(
                        value = notesText,
                        onValueChange = { notesText = it },
                        label = { Text("Clinical / Batch Observation Notes") },
                        placeholder = { Text("e.g. Group morning check: all active, clear eyes, good rumen fill") },
                        minLines = 2,
                        maxLines = 4,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_batch_notes")
                    )

                    // Checkbox: Update animal profile health status badge
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { updateGoatBadgeStatus = !updateGoatBadgeStatus }
                    ) {
                        Checkbox(
                            checked = updateGoatBadgeStatus,
                            onCheckedChange = { updateGoatBadgeStatus = it }
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Update profile health status badge for all selected goats",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Bottom Action Buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        enabled = !isSubmitting,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("btn_cancel_batch_health_check")
                    ) {
                        Text("Cancel")
                    }

                    Button(
                        onClick = {
                            if (isSubmitting) return@Button
                            isSubmitting = true
                            coroutineScope.launch {
                                val tempVal = temperatureText.toDoubleOrNull()
                                val bcsVal = bodyConditionText.toDoubleOrNull()
                                val symptomsJoined = selectedSymptoms.joinToString(", ")

                                val observations = selectedGoats.map { goat ->
                                    DailyHealthObservationEntity(
                                        goat_id = goat.id,
                                        goat_tag = goat.tag_c,
                                        goat_name = goat.name,
                                        observation_date = observationDate,
                                        temperature_celsius = tempVal,
                                        appetite_status = appetiteStatus,
                                        activity_level = activityLevel,
                                        body_condition_score = bcsVal,
                                        mucous_membrane_famacha = famachaScore,
                                        abnormal_symptoms = symptomsJoined,
                                        overall_health_rating = overallHealthRating,
                                        observer_name = observerName,
                                        notes = notesText.ifBlank { "Batch health check: $overallHealthRating ($symptomsJoined)" },
                                        follow_up_required = overallHealthRating != "Healthy"
                                    )
                                }

                                val result = repository.saveBatchDailyHealthObservations(
                                    observations = observations,
                                    updateGoatHealthStatus = updateGoatBadgeStatus
                                )

                                isSubmitting = false
                                if (result.isSuccess) {
                                    Toast.makeText(
                                        context,
                                        "Batch health check saved for ${selectedGoats.size} goats",
                                        Toast.LENGTH_SHORT
                                    ).show()
                                    onSuccess(selectedGoats.size)
                                } else {
                                    Toast.makeText(
                                        context,
                                        "Failed to save batch health check: ${result.exceptionOrNull()?.message}",
                                        Toast.LENGTH_LONG
                                    ).show()
                                }
                            }
                        },
                        enabled = !isSubmitting,
                        colors = ButtonDefaults.buttonColors(containerColor = FarmGreenPrimary),
                        modifier = Modifier
                            .weight(1.5f)
                            .testTag("btn_apply_batch_health_check")
                    ) {
                        if (isSubmitting) {
                            CircularProgressIndicator(
                                color = Color.White,
                                modifier = Modifier.size(18.dp),
                                strokeWidth = 2.dp
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                        }
                        Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Apply to ${selectedGoats.size} Goats")
                    }
                }
            }
        }
    }
}
