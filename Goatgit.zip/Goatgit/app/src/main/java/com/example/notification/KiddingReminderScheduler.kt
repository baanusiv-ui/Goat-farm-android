package com.example.notification

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.work.*
import com.example.MainActivity
import com.example.R
import com.example.data.offline.AppDatabase
import com.example.data.offline.FarmSettingEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.util.concurrent.TimeUnit

object KiddingReminderScheduler {
    private const val TAG = "KiddingScheduler"
    private const val UNIQUE_WORK_NAME = "recurring_goat_kidding_reminders"
    private const val PREF_NAME = "kidding_notification_prefs"
    private const val KEY_ENABLED = "kidding_alerts_enabled"

    /**
     * Schedules periodic 24-hour background checking for expected kidding dates.
     * WorkManager automatically reschedules across device reboots and app updates.
     */
    fun scheduleDaily(context: Context) {
        try {
            val constraints = Constraints.Builder()
                .setRequiresBatteryNotLow(false)
                .build()

            val periodicWork = PeriodicWorkRequestBuilder<KiddingNotificationWorker>(
                24, TimeUnit.HOURS,
                4, TimeUnit.HOURS // flex interval
            )
                .setConstraints(constraints)
                .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 15, TimeUnit.MINUTES)
                .addTag("kidding_periodic_work")
                .build()

            WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                UNIQUE_WORK_NAME,
                ExistingPeriodicWorkPolicy.KEEP,
                periodicWork
            )
            Log.d(TAG, "Recurring kidding delivery notification system scheduled (every 24 hours).")
        } catch (e: Exception) {
            Log.w(TAG, "WorkManager not initialized or scheduling skipped: ${e.message}")
        }
    }

    /**
     * Triggers an immediate one-time check for upcoming kidding dates.
     * Useful for on-demand scanning upon recording or updating breeding records,
     * or when tapping 'Scan Now' in the UI.
     */
    fun triggerImmediateCheck(context: Context) {
        try {
            val oneTimeWork = OneTimeWorkRequestBuilder<KiddingNotificationWorker>()
                .setExpedited(OutOfQuotaPolicy.RUN_AS_NON_EXPEDITED_WORK_REQUEST)
                .addTag("kidding_immediate_work")
                .build()

            WorkManager.getInstance(context).enqueue(oneTimeWork)
            Log.d(TAG, "Immediate kidding reminder scan triggered via WorkManager.")
        } catch (e: Exception) {
            Log.w(TAG, "WorkManager not initialized or immediate scan skipped: ${e.message}")
        }
    }

    /**
     * Dispatches an immediate test local device notification so the user can verify
     * audio, vibration, heads-up banners, and intent routing on device.
     */
    fun sendTestNotification(
        context: Context,
        doeTag: String = "DOE-101",
        doeName: String = "Bella",
        expectedKiddingDate: String = "2026-10-15"
    ) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val permission = ContextCompat.checkSelfPermission(context, android.Manifest.permission.POST_NOTIFICATIONS)
            if (permission != PackageManager.PERMISSION_GRANTED) {
                Log.w(TAG, "POST_NOTIFICATIONS permission not granted. Cannot send test alert.")
                return
            }
        }

        // Ensure notification channel exists
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                KiddingNotificationWorker.CHANNEL_ID,
                KiddingNotificationWorker.CHANNEL_NAME,
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Timely alerts for expected goat delivery dates, 150-day gestation milestones, and kidding pen preparations."
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 400, 200, 400)
                setShowBadge(true)
            }
            val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
            manager?.createNotificationChannel(channel)
        }

        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            putExtra("navigate_to", "breeding")
        }
        val pendingIntent = PendingIntent.getActivity(
            context,
            2002,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val bigText = NotificationCompat.BigTextStyle()
            .setBigContentTitle("🔔 Kidding Alert Test: Doe #$doeTag ($doeName)")
            .bigText("Expected Kidding Date: $expectedKiddingDate (150-day gestation).\n\n" +
                    "Local device alerts are active! You will automatically receive notifications 7 days, 3 days, 1 day before delivery, on delivery day, and if overdue.\n\n" +
                    "👉 Tap here to open Breeding & Gestation Management.")
            .setSummaryText("Breeding Alert Test")

        val notification = NotificationCompat.Builder(context, KiddingNotificationWorker.CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle("🔔 Kidding Alert Active: Doe #$doeTag")
            .setContentText("Expected delivery: $expectedKiddingDate. Local device alerts verified.")
            .setStyle(bigText)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_EVENT)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .addAction(
                android.R.drawable.ic_menu_today,
                "Open Breeding",
                pendingIntent
            )
            .build()

        try {
            NotificationManagerCompat.from(context).notify(8199, notification)
            Log.d(TAG, "Test kidding alert notification posted successfully.")
        } catch (e: SecurityException) {
            Log.e(TAG, "SecurityException sending test kidding notification: ${e.message}")
        }
    }

    /**
     * Confirms the newly captured breeding event with a push notification reminder
     * detailing the service date, sire/dam IDs, and predicted kidding date with reminder milestones.
     */
    fun scheduleBreedingReminderNotification(
        context: Context,
        doeTag: String,
        buckTag: String,
        serviceDate: String,
        expectedKiddingDate: String,
        method: String = "Natural"
    ) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val permission = ContextCompat.checkSelfPermission(context, android.Manifest.permission.POST_NOTIFICATIONS)
            if (permission != PackageManager.PERMISSION_GRANTED) {
                Log.w(TAG, "POST_NOTIFICATIONS permission not granted.")
                return
            }
        }

        // Ensure notification channel exists
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                KiddingNotificationWorker.CHANNEL_ID,
                KiddingNotificationWorker.CHANNEL_NAME,
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Timely alerts for expected goat delivery dates, 150-day gestation milestones, and kidding pen preparations."
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 400, 200, 400)
                setShowBadge(true)
            }
            val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
            manager?.createNotificationChannel(channel)
        }

        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            putExtra("navigate_to", "breeding_records")
        }
        val pendingIntent = PendingIntent.getActivity(
            context,
            2005,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notifTitle = "🐐 Breeding Logged: Doe #$doeTag × Buck #$buckTag"
        val notifMessage = "Service Date: $serviceDate ($method)\n" +
                "Predicted Kidding: $expectedKiddingDate (150-Day Gestation)\n\n" +
                "Push Reminders Scheduled:\n" +
                "• Repeat Heat Check: Day +21\n" +
                "• CD&T Pre-Kidding Booster: Day +120\n" +
                "• Maternity Pen Prep: Day +143\n" +
                "• Imminent Delivery: Day +149 & +150"

        val bigText = NotificationCompat.BigTextStyle()
            .setBigContentTitle(notifTitle)
            .bigText(notifMessage)
            .setSummaryText("Predicted Kidding: $expectedKiddingDate")

        val notification = NotificationCompat.Builder(context, KiddingNotificationWorker.CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle(notifTitle)
            .setContentText("Service: $serviceDate • Predicted Kidding: $expectedKiddingDate")
            .setStyle(bigText)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_EVENT)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .addAction(
                android.R.drawable.ic_menu_today,
                "View Breeding",
                pendingIntent
            )
            .build()

        try {
            val notifId = 8200 + (System.currentTimeMillis() % 1000).toInt()
            NotificationManagerCompat.from(context).notify(notifId, notification)
            Log.d(TAG, "Breeding confirmation notification posted.")
        } catch (e: SecurityException) {
            Log.e(TAG, "SecurityException sending breeding notification: ${e.message}")
        }

        // Trigger WorkManager scan to ensure background recurring jobs are active
        triggerImmediateCheck(context)
    }

    /**
     * Checks if kidding notifications are enabled in local preferences.
     */
    fun areAlertsEnabled(context: Context): Boolean {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        return prefs.getBoolean(KEY_ENABLED, true)
    }

    /**
     * Toggles kidding notifications on/off and synchronizes with WorkManager and farm settings.
     */
    fun setAlertsEnabled(context: Context, enabled: Boolean) {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        prefs.edit().putBoolean(KEY_ENABLED, enabled).apply()

        // Sync with database farm settings asynchronously
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val db = AppDatabase.getDatabase(context)
                db.farmSettingsDao().saveSetting(
                    FarmSettingEntity("kidding_notifications_enabled", enabled.toString())
                )
            } catch (e: Exception) {
                Log.w(TAG, "Error saving kidding notification preference to DB: ${e.message}")
            }
        }

        if (enabled) {
            scheduleDaily(context)
            triggerImmediateCheck(context)
        } else {
            cancel(context)
        }
    }

    /**
     * Cancels the recurring notification worker.
     */
    fun cancel(context: Context) {
        try {
            WorkManager.getInstance(context).cancelUniqueWork(UNIQUE_WORK_NAME)
            Log.d(TAG, "Recurring kidding delivery notification system cancelled.")
        } catch (e: Exception) {
            Log.w(TAG, "WorkManager not initialized or cancel skipped: ${e.message}")
        }
    }
}
