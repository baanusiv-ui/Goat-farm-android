package com.example.ui.screens.finance

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.supabase.*
import com.example.ui.theme.*
import com.example.util.CurrencyUtils
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PaymentsDueScreen(
    repository: GoatRepository,
    onNavigateBack: () -> Unit,
    onNavigateToEb: () -> Unit,
    onNavigateToSuppliers: () -> Unit,
    onNavigateToLoans: () -> Unit,
    onNavigateToRecurring: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler { onNavigateBack() }

    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val dateFormat = remember { SimpleDateFormat("yyyy-MM-dd", Locale.US) }
    val today = remember { dateFormat.format(Date()) }

    var dueItems by remember { mutableStateOf<List<UnifiedPaymentsDueItem>>(emptyList()) }
    var selectedFilter by remember { mutableStateOf("ALL") } // ALL, EB, SUPPLIER, LOAN_EMI, RECURRING
    var isLoading by remember { mutableStateOf(true) }

    fun loadData() {
        isLoading = true
        coroutineScope.launch {
            val res = repository.finance.getUnifiedPaymentsDue()
            if (res.isSuccess) {
                dueItems = res.getOrThrow()
            }
            isLoading = false
        }
    }

    LaunchedEffect(Unit) {
        loadData()
    }

    val totalPayableDue = remember(dueItems) { dueItems.sumOf { it.amount } }
    val overdueCount = remember(dueItems) { dueItems.count { it.isOverdue } }

    val filteredItems = remember(dueItems, selectedFilter) {
        if (selectedFilter == "ALL") dueItems
        else dueItems.filter { it.type.equals(selectedFilter, ignoreCase = true) }
    }

    val filterOptions = listOf("ALL", "EB", "SUPPLIER", "LOAN_EMI", "RECURRING")

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "Unified Payments Due",
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp
                        )
                        Text(
                            text = "EB, Supplier Bills, Loan EMIs & Recurring Expenses",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack, modifier = Modifier.testTag("payments_due_btn_back")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(onClick = { loadData() }, modifier = Modifier.testTag("payments_due_btn_refresh")) {
                        Icon(Icons.Default.Refresh, contentDescription = "Refresh")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.White)
            )
        },
        containerColor = Color(0xFFF8F9FA),
        modifier = modifier
    ) { innerPadding ->
        if (isLoading) {
            Box(modifier = Modifier.fillMaxSize().padding(innerPadding), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = FarmGreenDark)
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item { Spacer(modifier = Modifier.height(4.dp)) }

                // Top Total Payable Card
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = if (overdueCount > 0) Color(0xFF991B1B) else FarmGreenDark),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.fillMaxWidth().testTag("total_due_banner")
                    ) {
                        Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text("Total Outflow Commitments Due", color = Color.White.copy(alpha = 0.85f), fontSize = 12.sp)
                            Text(
                                text = CurrencyUtils.formatInr(totalPayableDue),
                                fontSize = 28.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = Color.White
                            )
                            Text(
                                text = "${dueItems.size} Total Payable Items • $overdueCount Overdue Actions",
                                color = Color.White.copy(alpha = 0.85f),
                                fontSize = 11.sp
                            )
                        }
                    }
                }

                // Filter Chips
                item {
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(filterOptions) { opt ->
                            val isSelected = selectedFilter == opt
                            FilterChip(
                                selected = isSelected,
                                onClick = { selectedFilter = opt },
                                label = {
                                    Text(
                                        text = when (opt) {
                                            "ALL" -> "All Due (${dueItems.size})"
                                            "EB" -> "EB Electricity"
                                            "SUPPLIER" -> "Suppliers"
                                            "LOAN_EMI" -> "Loan EMIs"
                                            "RECURRING" -> "Recurring"
                                            else -> opt
                                        },
                                        fontSize = 12.sp,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                    )
                                },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = FarmGreenDark,
                                    selectedLabelColor = Color.White
                                )
                            )
                        }
                    }
                }

                if (filteredItems.isEmpty()) {
                    item {
                        Card(colors = CardDefaults.cardColors(containerColor = Color.White), modifier = Modifier.fillMaxWidth().padding(vertical = 16.dp)) {
                            Box(modifier = Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                                Text("No pending payments due in this category!", color = FarmGreenDark, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                            }
                        }
                    }
                } else {
                    items(filteredItems) { item ->
                        PaymentDueRowCard(
                            item = item,
                            onAction = {
                                when (item.type) {
                                    "EB" -> onNavigateToEb()
                                    "SUPPLIER" -> onNavigateToSuppliers()
                                    "LOAN_EMI" -> onNavigateToLoans()
                                    "RECURRING" -> onNavigateToRecurring()
                                }
                            }
                        )
                    }
                }

                item { Spacer(modifier = Modifier.height(32.dp)) }
            }
        }
    }
}

@Composable
private fun PaymentDueRowCard(
    item: UnifiedPaymentsDueItem,
    onAction: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(12.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier.fillMaxWidth().testTag("due_item_${item.id}")
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                Box(
                    modifier = Modifier
                        .size(38.dp)
                        .clip(CircleShape)
                        .background(
                            when (item.type) {
                                "EB" -> Color(0xFFFFF3E0)
                                "SUPPLIER" -> Color(0xFFEFF6FF)
                                "LOAN_EMI" -> Color(0xFFEDE7F6)
                                else -> Color(0xFFE8F5E9)
                            }
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = when (item.type) {
                            "EB" -> Icons.Default.Bolt
                            "SUPPLIER" -> Icons.Default.Storefront
                            "LOAN_EMI" -> Icons.Default.AccountBalance
                            else -> Icons.Default.Update
                        },
                        contentDescription = null,
                        tint = when (item.type) {
                            "EB" -> Color(0xFFE65100)
                            "SUPPLIER" -> Color(0xFF1E40AF)
                            "LOAN_EMI" -> Color(0xFF6B21A8)
                            else -> FarmGreenDark
                        },
                        modifier = Modifier.size(20.dp)
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(item.title, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Text(item.subtitle, fontSize = 11.sp, color = Color.Gray, maxLines = 1)
                    Text(
                        text = if (item.isOverdue) "OVERDUE (Due: ${item.dueDate})" else "Due in ${item.daysRemaining} days (${item.dueDate})",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (item.isOverdue) FarmError else Color.DarkGray
                    )
                }
            }

            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = CurrencyUtils.formatInr(item.amount),
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 15.sp,
                    color = if (item.isOverdue) FarmError else FarmGreenDark
                )
                Spacer(modifier = Modifier.height(4.dp))
                Button(
                    onClick = onAction,
                    colors = ButtonDefaults.buttonColors(containerColor = if (item.isOverdue) FarmError else FarmGreenDark),
                    shape = RoundedCornerShape(6.dp),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                    modifier = Modifier.height(30.dp).testTag("btn_pay_due_${item.id}")
                ) {
                    Text("Pay Now", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
