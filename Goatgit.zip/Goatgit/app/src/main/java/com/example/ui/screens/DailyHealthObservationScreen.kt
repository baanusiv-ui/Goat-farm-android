package com.example.ui.screens

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.TrendingUp
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.offline.DailyHealthObservationEntity
import com.example.data.supabase.Goat
import com.example.data.supabase.GoatRepository
import com.example.ui.components.FarmTopBar
import com.example.ui.theme.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DailyHealthObservationScreen(
    repository: GoatRepository,
    preselectedGoatId: String? = null,
    onNavigateBack: () -> Unit,
    onNavigateToTrends: (() -> Unit)? = null
) {
    BackHandler { onNavigateBack() }

    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }

    var selectedTab by remember { mutableStateOf(0) } // 0: Record Form, 1: History Logs

    // Observations list flow from Room
    val observations by repository.getDailyHealthObservationsFlow().collectAsState(initial = emptyList())
    val goatsList by repository.getLocalGoatsFlow().collectAsState(initial = emptyList())

    // Form State
    val todayDateStr = remember { SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date()) }
    var selectedGoat by remember { mutableStateOf<Goat?>(null) }
    var showGoatPicker by remember { mutableStateOf(false) }

    var observationDate by remember { mutableStateOf(todayDateStr) }
    var observerName by remember { mutableStateOf("Farm Staff") }
    var temperatureInput by remember { mutableStateOf("") }
    var pulseInput by remember { mutableStateOf("") }
    var respirationInput by remember { mutableStateOf("") }

    var appetiteStatus by remember { mutableStateOf("Normal") }
    var activityLevel by remember { mutableStateOf("Active & Alert") }
    var fecesConsistency by remember { mutableStateOf("Normal Pellets") }
    var rumenMotility by remember { mutableStateOf("Normal") }
    var famachaScore by remember { mutableStateOf("Score 1 - Optimal Pink") }
    var bcsScore by remember { mutableStateOf(3.0f) }

    val activeSymptoms = remember { mutableStateListOf<String>() }
    var overallRating by remember { mutableStateOf("Healthy") }
    var clinicalNotes by remember { mutableStateOf("") }
    var followUpRequired by remember { mutableStateOf(false) }
    var isSaving by remember { mutableStateOf(false) }

    // Initialize preselected goat if provided
    LaunchedEffect(goatsList, preselectedGoatId) {
        if (preselectedGoatId != null && selectedGoat == null && goatsList.isNotEmpty()) {
            selectedGoat = goatsList.find { it.id == preselectedGoatId }
        }
    }

    // Auto-update overall rating when symptoms or high temp are entered
    LaunchedEffect(activeSymptoms.toList(), temperatureInput) {
        val tempVal = temperatureInput.toDoubleOrNull()
        val hasSevereSymptoms = activeSymptoms.any {
            it in listOf("Mastitis / Udder Heat", "Bloat / Severe Distension", "Bottle Jaw / Swelling")
        }
        val hasMildSymptoms = activeSymptoms.isNotEmpty() && !activeSymptoms.contains("None")
        val isFever = tempVal != null && tempVal > 39.7
        val isHypothermia = tempVal != null && tempVal < 38.5

        if (hasSevereSymptoms || (tempVal != null && tempVal > 40.5)) {
            overallRating = "Critical"
        } else if (hasMildSymptoms || isFever || isHypothermia) {
            overallRating = if (overallRating == "Healthy") "Needs Vet Attention" else overallRating
        }
    }

    Scaffold(
        topBar = {
            FarmTopBar(
                title = "Daily Health Check",
                syncManager = repository.syncManager,
                backupManager = repository.backupManager,
                canNavigateBack = true,
                onNavigateBack = onNavigateBack
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(MaterialTheme.colorScheme.background)
        ) {
            // Tab Selector: Form vs History
            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = MaterialTheme.colorScheme.primary
            ) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.EditNote, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Record Observation", fontWeight = FontWeight.Bold)
                        }
                    },
                    modifier = Modifier.testTag("tab_record_observation")
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.History, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Observation Logs (${observations.size})", fontWeight = FontWeight.Bold)
                        }
                    },
                    modifier = Modifier.testTag("tab_observation_logs")
                )
            }

            if (selectedTab == 0) {
                // ==========================================
                // RECORD OBSERVATION FORM
                // ==========================================
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .verticalScroll(rememberScrollState())
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    if (onNavigateToTrends != null) {
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = Color(0xFFEFF6FF),
                            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFBFDBFE)),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onNavigateToTrends() }
                                .testTag("banner_view_health_trends")
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        Icons.AutoMirrored.Filled.TrendingUp,
                                        contentDescription = null,
                                        tint = Color(0xFF1D4ED8),
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Column {
                                        Text(
                                            "Historical Trends & Growth Analytics",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 12.sp,
                                            color = Color(0xFF1E40AF)
                                        )
                                        Text(
                                            "View ADG spline curves, clinical vitals & intervention frequency",
                                            fontSize = 10.sp,
                                            color = Color(0xFF334155)
                                        )
                                    }
                                }
                                Icon(Icons.Default.ChevronRight, contentDescription = null, tint = Color(0xFF1D4ED8), modifier = Modifier.size(18.dp))
                            }
                        }
                    }

                    // 1. Goat Selection Card
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { showGoatPicker = true }
                            .testTag("goat_selector_card")
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(40.dp)
                                            .clip(CircleShape)
                                            .background(FarmGreenContainer),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Pets,
                                            contentDescription = null,
                                            tint = FarmGreenDark,
                                            modifier = Modifier.size(22.dp)
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Column {
                                        Text(
                                            text = if (selectedGoat != null) "Goat: ${selectedGoat?.tag_c} - ${selectedGoat?.name}" else "Select Goat *",
                                            style = MaterialTheme.typography.titleMedium,
                                            fontWeight = FontWeight.Bold,
                                            color = if (selectedGoat != null) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.primary
                                        )
                                        Text(
                                            text = if (selectedGoat != null)
                                                "${selectedGoat?.breed_c} • ${selectedGoat?.sex_c} • Current Weight: ${selectedGoat?.weight_kg_c ?: "N/A"} kg"
                                            else
                                                "Tap here to choose a goat from the active herd",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                                Icon(
                                    imageVector = Icons.Default.ArrowDropDown,
                                    contentDescription = "Select Goat",
                                    tint = MaterialTheme.colorScheme.primary
                                )
                            }
                        }
                    }

                    // 2. Date and Observer Info Card
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            Text(
                                text = "Observation Details",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )

                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                OutlinedTextField(
                                    value = observationDate,
                                    onValueChange = { observationDate = it },
                                    label = { Text("Date (YYYY-MM-DD)") },
                                    leadingIcon = { Icon(Icons.Default.DateRange, contentDescription = null) },
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("input_observation_date"),
                                    singleLine = true
                                )
                                OutlinedTextField(
                                    value = observerName,
                                    onValueChange = { observerName = it },
                                    label = { Text("Observed By") },
                                    leadingIcon = { Icon(Icons.Default.Person, contentDescription = null) },
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("input_observer_name"),
                                    singleLine = true
                                )
                            }
                        }
                    }

                    // 3. Clinical Vitals (Temperature, Pulse, Respiration)
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Thermostat, contentDescription = null, tint = FarmGreenDark)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Clinical Vitals",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }

                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                OutlinedTextField(
                                    value = temperatureInput,
                                    onValueChange = { temperatureInput = it },
                                    label = { Text("Temp (°C)") },
                                    placeholder = { Text("e.g. 39.1") },
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("input_temperature"),
                                    singleLine = true
                                )

                                OutlinedTextField(
                                    value = pulseInput,
                                    onValueChange = { pulseInput = it },
                                    label = { Text("Pulse (bpm)") },
                                    placeholder = { Text("70-90") },
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("input_pulse"),
                                    singleLine = true
                                )

                                OutlinedTextField(
                                    value = respirationInput,
                                    onValueChange = { respirationInput = it },
                                    label = { Text("Resp (rpm)") },
                                    placeholder = { Text("15-30") },
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("input_respiration"),
                                    singleLine = true
                                )
                            }

                            // Temperature Reference Banner
                            val tempDouble = temperatureInput.toDoubleOrNull()
                            if (tempDouble != null) {
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = when {
                                        tempDouble > 39.7 -> Color(0xFFFFEBEE)
                                        tempDouble < 38.5 -> Color(0xFFE1F5FE)
                                        else -> Color(0xFFE8F5E9)
                                    },
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = when {
                                                tempDouble > 39.7 -> "⚠️ Elevated Temperature / Fever (>39.7°C)"
                                                tempDouble < 38.5 -> "❄️ Hypothermia / Subnormal (<38.5°C)"
                                                else -> "✓ Normal Body Temperature (38.5°C - 39.7°C)"
                                            },
                                            style = MaterialTheme.typography.labelSmall,
                                            fontWeight = FontWeight.Bold,
                                            color = when {
                                                tempDouble > 39.7 -> Color(0xFFC62828)
                                                tempDouble < 38.5 -> Color(0xFF0277BD)
                                                else -> Color(0xFF2E7D32)
                                            }
                                        )
                                    }
                                }
                            } else {
                                Text(
                                    text = "Normal goat temp: 38.5°C - 39.7°C • Pulse: 70-90 bpm • Respiration: 15-30 breaths/min",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }

                    // 4. Appetite & Attitude Behavior
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                            // Appetite
                            Text(
                                text = "Appetite & Feeding",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold
                            )
                            val appetiteOptions = listOf("Normal", "Reduced", "Not Eating (Anorexia)", "Voracious")
                            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                items(appetiteOptions) { option ->
                                    FilterChip(
                                        selected = appetiteStatus == option,
                                        onClick = { appetiteStatus = option },
                                        label = { Text(option) },
                                        leadingIcon = if (appetiteStatus == option) {
                                            { Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp)) }
                                        } else null
                                    )
                                }
                            }

                            // Activity & Demeanor
                            Text(
                                text = "Activity & Attitude",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold
                            )
                            val activityOptions = listOf("Active & Alert", "Lethargic / Sluggish", "Depressed", "Isolated from Herd")
                            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                items(activityOptions) { option ->
                                    FilterChip(
                                        selected = activityLevel == option,
                                        onClick = { activityLevel = option },
                                        label = { Text(option) },
                                        leadingIcon = if (activityLevel == option) {
                                            { Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp)) }
                                        } else null
                                    )
                                }
                            }
                        }
                    }

                    // 5. Digestive & FAMACHA Eye Score
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                            Text(
                                text = "Digestive & Physical Exam",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold
                            )

                            // Feces
                            Text("Feces Consistency:", style = MaterialTheme.typography.labelMedium, color = Color.Gray)
                            val fecesOptions = listOf("Normal Pellets", "Soft Pellets", "Diarrhea / Scours", "Constipated")
                            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                items(fecesOptions) { option ->
                                    FilterChip(
                                        selected = fecesConsistency == option,
                                        onClick = { fecesConsistency = option },
                                        label = { Text(option) }
                                    )
                                }
                            }

                            // Rumen Motility
                            Text("Rumen Contractions:", style = MaterialTheme.typography.labelMedium, color = Color.Gray)
                            val rumenOptions = listOf("Normal (1-2/min)", "Weak / Hypomotile", "Bloated / Distended")
                            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                items(rumenOptions) { option ->
                                    FilterChip(
                                        selected = rumenMotility == option,
                                        onClick = { rumenMotility = option },
                                        label = { Text(option) }
                                    )
                                }
                            }

                            // FAMACHA Score
                            Text("FAMACHA Eye Mucosa (Anemia Check):", style = MaterialTheme.typography.labelMedium, color = Color.Gray)
                            val famachaOptions = listOf(
                                "Score 1 - Optimal Pink",
                                "Score 2 - Acceptable",
                                "Score 3 - Borderline",
                                "Score 4 - Anemic (Deworm)",
                                "Score 5 - Severely Anemic"
                            )
                            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                items(famachaOptions) { option ->
                                    FilterChip(
                                        selected = famachaScore == option,
                                        onClick = { famachaScore = option },
                                        label = { Text(option) },
                                        colors = FilterChipDefaults.filterChipColors(
                                            selectedContainerColor = when {
                                                option.startsWith("Score 1") || option.startsWith("Score 2") -> Color(0xFFC8E6C9)
                                                option.startsWith("Score 3") -> Color(0xFFFFF9C4)
                                                else -> Color(0xFFFFCDD2)
                                            }
                                        )
                                    )
                                }
                            }

                            // Body Condition Score (BCS 1.0 - 5.0)
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("Body Condition Score (BCS):", style = MaterialTheme.typography.labelMedium, color = Color.Gray)
                                Text(
                                    text = String.format(Locale.US, "%.1f / 5.0 (%s)", bcsScore, when {
                                        bcsScore <= 1.5f -> "Emaciated"
                                        bcsScore <= 2.5f -> "Thin"
                                        bcsScore <= 3.5f -> "Ideal"
                                        bcsScore <= 4.5f -> "Fat"
                                        else -> "Obese"
                                    }),
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                            Slider(
                                value = bcsScore,
                                onValueChange = { bcsScore = it },
                                valueRange = 1.0f..5.0f,
                                steps = 7, // 1.0, 1.5, 2.0, 2.5, 3.0, 3.5, 4.0, 4.5, 5.0
                                modifier = Modifier.fillMaxWidth().testTag("slider_bcs")
                            )
                        }
                    }

                    // 6. Abnormal Clinical Symptoms (Multi-select)
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            Text(
                                text = "Abnormal Symptoms Checklist",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold
                            )

                            val symptomsList = listOf(
                                "None (Normal)",
                                "Coughing / Wheezing",
                                "Nasal Discharge",
                                "Eye Discharge / Lacrimation",
                                "Lameness / Limping",
                                "Bottle Jaw / Under-jaw Swelling",
                                "Skin Lesions / Mange",
                                "Mastitis / Udder Heat",
                                "Bloat / Severe Distension"
                            )

                            // Flow-like display using chunked or wrapping items
                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                symptomsList.chunked(2).forEach { rowSymptoms ->
                                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        rowSymptoms.forEach { symptom ->
                                            val isSelected = if (symptom == "None (Normal)") {
                                                activeSymptoms.isEmpty() || activeSymptoms.contains("None")
                                            } else {
                                                activeSymptoms.contains(symptom)
                                            }

                                            FilterChip(
                                                selected = isSelected,
                                                onClick = {
                                                    if (symptom == "None (Normal)") {
                                                        activeSymptoms.clear()
                                                        activeSymptoms.add("None")
                                                    } else {
                                                        activeSymptoms.remove("None")
                                                        if (activeSymptoms.contains(symptom)) {
                                                            activeSymptoms.remove(symptom)
                                                        } else {
                                                            activeSymptoms.add(symptom)
                                                        }
                                                    }
                                                },
                                                label = { Text(symptom, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                                                modifier = Modifier.weight(1f)
                                            )
                                        }
                                        if (rowSymptoms.size == 1) {
                                            Spacer(modifier = Modifier.weight(1f))
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // 7. Overall Health Status Rating & Triage
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            Text(
                                text = "Overall Triage & Health Rating *",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold
                            )

                            val ratingOptions = listOf(
                                "Healthy" to "🟢 Healthy & Alert",
                                "Mild Concern" to "🟡 Mild Concern (Monitor)",
                                "Needs Vet Attention" to "🟠 Needs Vet Review",
                                "Critical" to "🔴 Critical / Isolation"
                            )

                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                ratingOptions.forEach { (key, label) ->
                                    val isSelected = overallRating == key
                                    Surface(
                                        shape = RoundedCornerShape(10.dp),
                                        color = if (isSelected) {
                                            when (key) {
                                                "Healthy" -> Color(0xFFE8F5E9)
                                                "Mild Concern" -> Color(0xFFFFF8E1)
                                                "Needs Vet Attention" -> Color(0xFFFFE0B2)
                                                else -> Color(0xFFFFCDD2)
                                            }
                                        } else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                                        border = if (isSelected) {
                                            androidx.compose.foundation.BorderStroke(
                                                1.5.dp,
                                                when (key) {
                                                    "Healthy" -> Color(0xFF2E7D32)
                                                    "Mild Concern" -> Color(0xFFF57F17)
                                                    "Needs Vet Attention" -> Color(0xFFE65100)
                                                    else -> Color(0xFFC62828)
                                                }
                                            )
                                        } else null,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clickable { overallRating = key }
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(12.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Text(
                                                text = label,
                                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                                color = if (isSelected) Color.Black else MaterialTheme.colorScheme.onSurface
                                            )
                                            if (isSelected) {
                                                Icon(
                                                    Icons.Default.CheckCircle,
                                                    contentDescription = null,
                                                    tint = when (key) {
                                                        "Healthy" -> Color(0xFF2E7D32)
                                                        "Mild Concern" -> Color(0xFFF57F17)
                                                        "Needs Vet Attention" -> Color(0xFFE65100)
                                                        else -> Color(0xFFC62828)
                                                    }
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // 8. Follow-up & Clinical Notes
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "Requires Follow-up Check Tomorrow",
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Switch(
                                    checked = followUpRequired,
                                    onCheckedChange = { followUpRequired = it },
                                    modifier = Modifier.testTag("switch_follow_up")
                                )
                            }

                            OutlinedTextField(
                                value = clinicalNotes,
                                onValueChange = { clinicalNotes = it },
                                label = { Text("Clinical Findings & Notes") },
                                placeholder = { Text("Enter detailed observations, medication administered, or vet instructions...") },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .heightIn(min = 100.dp)
                                    .testTag("input_health_notes"),
                                maxLines = 5
                            )
                        }
                    }

                    // 9. Save Button
                    Button(
                        onClick = {
                            val goat = selectedGoat
                            if (goat == null) {
                                Toast.makeText(context, "Please select a goat first", Toast.LENGTH_SHORT).show()
                                return@Button
                            }

                            isSaving = true
                            coroutineScope.launch {
                                val symptomsStr = if (activeSymptoms.isEmpty() || activeSymptoms.contains("None")) {
                                    "None"
                                } else {
                                    activeSymptoms.joinToString(", ")
                                }

                                val entity = DailyHealthObservationEntity(
                                    goat_id = goat.id,
                                    goat_tag = goat.tag_c,
                                    goat_name = goat.name,
                                    observation_date = observationDate,
                                    temperature_celsius = temperatureInput.toDoubleOrNull(),
                                    pulse_bpm = pulseInput.toIntOrNull(),
                                    respiration_rate = respirationInput.toIntOrNull(),
                                    appetite_status = appetiteStatus,
                                    activity_level = activityLevel,
                                    body_condition_score = bcsScore.toDouble(),
                                    feces_consistency = fecesConsistency,
                                    rumen_motility = rumenMotility,
                                    mucous_membrane_famacha = famachaScore,
                                    abnormal_symptoms = symptomsStr,
                                    overall_health_rating = overallRating,
                                    observer_name = observerName.ifBlank { "Farm Staff" },
                                    notes = clinicalNotes.ifBlank { null },
                                    follow_up_required = followUpRequired
                                )

                                val res = repository.saveDailyHealthObservation(entity)
                                isSaving = false
                                if (res.isSuccess) {
                                    Toast.makeText(context, "Health observation saved for Goat #${goat.tag_c}!", Toast.LENGTH_SHORT).show()
                                    // Reset form
                                    temperatureInput = ""
                                    pulseInput = ""
                                    respirationInput = ""
                                    clinicalNotes = ""
                                    activeSymptoms.clear()
                                    overallRating = "Healthy"
                                    // Switch to logs tab
                                    selectedTab = 1
                                } else {
                                    val err = res.exceptionOrNull()?.message ?: "Failed to save observation"
                                    snackbarHostState.showSnackbar(err)
                                }
                            }
                        },
                        enabled = !isSaving,
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = FarmGreenDark),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(54.dp)
                            .testTag("save_health_observation_btn")
                    ) {
                        if (isSaving) {
                            CircularProgressIndicator(color = Color.White, modifier = Modifier.size(24.dp))
                        } else {
                            Icon(Icons.Default.Save, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Save Daily Health Observation", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(modifier = Modifier.height(30.dp))
                }
            } else {
                // ==========================================
                // OBSERVATION LOGS & HISTORY
                // ==========================================
                DailyHealthLogsView(
                    observations = observations,
                    onDeleteObservation = { obsId ->
                        coroutineScope.launch {
                            val res = repository.deleteDailyHealthObservation(obsId)
                            if (res.isSuccess) {
                                Toast.makeText(context, "Observation record deleted", Toast.LENGTH_SHORT).show()
                            }
                        }
                    }
                )
            }
        }
    }

    // Modal Sheet / Dialog to Pick a Goat
    if (showGoatPicker) {
        GoatPickerDialog(
            goats = goatsList,
            selectedGoatId = selectedGoat?.id,
            onSelectGoat = { goat ->
                selectedGoat = goat
                showGoatPicker = false
            },
            onDismiss = { showGoatPicker = false }
        )
    }
}

/**
 * Filterable and searchable observation history logs view.
 */
@Composable
private fun DailyHealthLogsView(
    observations: List<DailyHealthObservationEntity>,
    onDeleteObservation: (String) -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    var filterRating by remember { mutableStateOf("All") } // All, Needs Attention, Healthy
    var observationToDelete by remember { mutableStateOf<DailyHealthObservationEntity?>(null) }

    val filteredList = remember(observations, searchQuery, filterRating) {
        observations.filter { obs ->
            val matchesSearch = searchQuery.isBlank() ||
                    obs.goat_tag.contains(searchQuery, ignoreCase = true) ||
                    obs.goat_name.contains(searchQuery, ignoreCase = true) ||
                    obs.observer_name.contains(searchQuery, ignoreCase = true)

            val matchesFilter = when (filterRating) {
                "Needs Attention" -> obs.overall_health_rating != "Healthy" || obs.follow_up_required
                "Healthy" -> obs.overall_health_rating == "Healthy"
                else -> true
            }

            matchesSearch && matchesFilter
        }
    }

    val attentionCount = remember(observations) {
        observations.count { it.overall_health_rating != "Healthy" || it.follow_up_required }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Summary Cards Bar
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Card(
                modifier = Modifier.weight(1f),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Column(modifier = Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Total Recorded", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                    Text("${observations.size}", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                }
            }
            Card(
                modifier = Modifier.weight(1f),
                colors = CardDefaults.cardColors(
                    containerColor = if (attentionCount > 0) Color(0xFFFFEBEE) else Color(0xFFE8F5E9)
                ),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Column(modifier = Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Needs Attention", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                    Text(
                        "$attentionCount",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = if (attentionCount > 0) Color(0xFFC62828) else Color(0xFF2E7D32)
                    )
                }
            }
        }

        // Search Bar
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            placeholder = { Text("Search by ear tag or observer...") },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
            trailingIcon = if (searchQuery.isNotEmpty()) {
                { IconButton(onClick = { searchQuery = "" }) { Icon(Icons.Default.Clear, contentDescription = "Clear") } }
            } else null,
            modifier = Modifier
                .fillMaxWidth()
                .testTag("search_observations"),
            singleLine = true,
            shape = RoundedCornerShape(12.dp)
        )

        // Filter Chips
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(
                selected = filterRating == "All",
                onClick = { filterRating = "All" },
                label = { Text("All (${observations.size})") }
            )
            FilterChip(
                selected = filterRating == "Needs Attention",
                onClick = { filterRating = "Needs Attention" },
                label = { Text("⚠️ Needs Attention ($attentionCount)") }
            )
            FilterChip(
                selected = filterRating == "Healthy",
                onClick = { filterRating = "Healthy" },
                label = { Text("✓ Healthy") }
            )
        }

        // Observation Records List
        if (filteredList.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        Icons.Default.MedicalServices,
                        contentDescription = null,
                        modifier = Modifier.size(56.dp),
                        tint = Color.LightGray
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = if (observations.isEmpty()) "No daily health observations recorded yet." else "No records match search criteria.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = Color.Gray
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(filteredList, key = { it.id }) { item ->
                    ObservationRecordCard(
                        observation = item,
                        onDelete = { observationToDelete = item }
                    )
                }
            }
        }
    }

    // Confirmation dialog before deleting observation
    observationToDelete?.let { obs ->
        AlertDialog(
            onDismissRequest = { observationToDelete = null },
            title = { Text("Delete Observation?") },
            text = { Text("Are you sure you want to delete the observation recorded on ${obs.observation_date} for Goat #${obs.goat_tag}?") },
            confirmButton = {
                Button(
                    onClick = {
                        onDeleteObservation(obs.id)
                        observationToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("Delete")
                }
            },
            dismissButton = {
                TextButton(onClick = { observationToDelete = null }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
private fun ObservationRecordCard(
    observation: DailyHealthObservationEntity,
    onDelete: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            // Header Row: Tag & Date + Rating Badge
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = FarmGreenContainer,
                        modifier = Modifier.padding(end = 8.dp)
                    ) {
                        Text(
                            text = "#${observation.goat_tag}",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = FarmGreenDark,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                    Text(
                        text = if (observation.goat_name.isNotBlank()) observation.goat_name else "Goat",
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleMedium
                    )
                }

                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = when (observation.overall_health_rating) {
                        "Healthy" -> Color(0xFFE8F5E9)
                        "Mild Concern" -> Color(0xFFFFF8E1)
                        "Needs Vet Attention" -> Color(0xFFFFE0B2)
                        else -> Color(0xFFFFCDD2)
                    }
                ) {
                    Text(
                        text = observation.overall_health_rating,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        color = when (observation.overall_health_rating) {
                            "Healthy" -> Color(0xFF2E7D32)
                            "Mild Concern" -> Color(0xFFF57F17)
                            "Needs Vet Attention" -> Color(0xFFE65100)
                            else -> Color(0xFFC62828)
                        },
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            // Date & Observer
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.DateRange, contentDescription = null, modifier = Modifier.size(14.dp), tint = Color.Gray)
                Spacer(modifier = Modifier.width(4.dp))
                Text(observation.observation_date, style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                Spacer(modifier = Modifier.width(12.dp))
                Icon(Icons.Default.Person, contentDescription = null, modifier = Modifier.size(14.dp), tint = Color.Gray)
                Spacer(modifier = Modifier.width(4.dp))
                Text(observation.observer_name, style = MaterialTheme.typography.labelSmall, color = Color.Gray)
            }

            Divider(modifier = Modifier.padding(vertical = 4.dp), color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))

            // Clinical metrics chip row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (observation.temperature_celsius != null) {
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = if (observation.isFever) Color(0xFFFFEBEE) else Color(0xFFF1F8E9)
                    ) {
                        Text(
                            text = "Temp: ${observation.temperature_celsius}°C" + if (observation.isFever) " ⚠️" else "",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium,
                            color = if (observation.isFever) Color(0xFFC62828) else Color(0xFF2E7D32),
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }

                if (observation.pulse_bpm != null) {
                    Surface(shape = RoundedCornerShape(6.dp), color = Color(0xFFF5F5F5)) {
                        Text(
                            text = "Pulse: ${observation.pulse_bpm} bpm",
                            fontSize = 11.sp,
                            color = Color.DarkGray,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }

                if (observation.body_condition_score != null) {
                    Surface(shape = RoundedCornerShape(6.dp), color = Color(0xFFF5F5F5)) {
                        Text(
                            text = "BCS: ${observation.body_condition_score}",
                            fontSize = 11.sp,
                            color = Color.DarkGray,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }
            }

            // Symptoms & Clinical findings
            if (observation.abnormal_symptoms != "None") {
                Text(
                    text = "Symptoms: ${observation.abnormal_symptoms}",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color(0xFFD32F2F),
                    fontWeight = FontWeight.Medium
                )
            }

            if (!observation.notes.isNullOrBlank()) {
                Text(
                    text = observation.notes,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            if (observation.follow_up_required) {
                Surface(shape = RoundedCornerShape(6.dp), color = Color(0xFFFFF3E0)) {
                    Row(
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.NotificationImportant, contentDescription = null, tint = Color(0xFFE65100), modifier = Modifier.size(12.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Follow-up check required tomorrow",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFE65100)
                        )
                    }
                }
            }

            // Actions Row (Delete)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End
            ) {
                IconButton(
                    onClick = onDelete,
                    modifier = Modifier.size(30.dp)
                ) {
                    Icon(
                        Icons.Default.DeleteOutline,
                        contentDescription = "Delete record",
                        tint = Color.Gray,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
    }
}

/**
 * Dialog to pick a goat from the registered herd list.
 */
@Composable
private fun GoatPickerDialog(
    goats: List<Goat>,
    selectedGoatId: String?,
    onSelectGoat: (Goat) -> Unit,
    onDismiss: () -> Unit
) {
    var query by remember { mutableStateOf("") }
    val filteredGoats = remember(goats, query) {
        if (query.isBlank()) goats else {
            goats.filter {
                it.tag_c.contains(query, ignoreCase = true) ||
                        it.name.contains(query, ignoreCase = true) ||
                        it.breed_c.contains(query, ignoreCase = true)
            }
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Select Goat for Health Check", fontWeight = FontWeight.Bold) },
        text = {
            Column(modifier = Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    placeholder = { Text("Search by tag or name...") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    shape = RoundedCornerShape(10.dp)
                )

                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 350.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    items(filteredGoats, key = { it.id }) { goat ->
                        val isSelected = goat.id == selectedGoatId
                        Card(
                            shape = RoundedCornerShape(10.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = if (isSelected) FarmGreenContainer else MaterialTheme.colorScheme.surface
                            ),
                            border = if (isSelected) androidx.compose.foundation.BorderStroke(1.5.dp, FarmGreenDark) else null,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onSelectGoat(goat) }
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(36.dp)
                                            .clip(CircleShape)
                                            .background(if (isSelected) FarmGreenDark else Color(0xFFE0E0E0)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = goat.tag_c.takeLast(2),
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 12.sp,
                                            color = if (isSelected) Color.White else Color.DarkGray
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column {
                                        Text(
                                            text = "Tag: ${goat.tag_c} • ${goat.name}",
                                            fontWeight = FontWeight.Bold,
                                            style = MaterialTheme.typography.bodyMedium
                                        )
                                        Text(
                                            text = "${goat.breed_c} • ${goat.sex_c} • ${goat.health_status_c ?: "Healthy"}",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = Color.Gray
                                        )
                                    }
                                }
                                if (isSelected) {
                                    Icon(Icons.Default.Check, contentDescription = null, tint = FarmGreenDark)
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Close")
            }
        }
    )
}
