package com.example.notification

import java.io.Serializable

enum class KiddingAlertStage {
    OVERDUE,
    DUE_TODAY,
    DUE_TOMORROW,
    DUE_IN_3_DAYS,
    DUE_IN_7_DAYS,
    DUE_IN_14_DAYS,
    CDT_BOOSTER
}

data class KiddingAlertItem(
    val id: String,
    val recordId: String,
    val recordType: String, // "BreedingRecord" or "Pregnancy"
    val doeId: String,
    val doeTag: String,
    val doeName: String,
    val sireTag: String? = null,
    val expectedKiddingDate: String,
    val diffDays: Long, // negative = overdue, 0 = today, positive = in future
    val gestationDay: Int? = null,
    val stage: KiddingAlertStage,
    val title: String,
    val message: String,
    val actionRecommendation: String
) : Serializable
