package com.example.ui.screens.weaning

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.offline.WeaningBatchEntity
import com.example.data.supabase.GoatRepository
import com.example.data.weaning.*
import kotlinx.coroutines.launch
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WeaningManagementScreen(
    repository: GoatRepository,
    weaningRepository: WeaningRepository,
    onNavigateBack: () -> Unit,
    onNavigateToKidProfile: (String) -> Unit = {},
    showTopBar: Boolean = true
) {
    if (showTopBar) {
        BackHandler { onNavigateBack() }
    }

    val coroutineScope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }

    var selectedTab by remember { mutableIntStateOf(0) }
    val tabTitles = listOf("Due & Pending", "Weaned History", "Batches", "Reports", "Farm Rules")

    var metrics by remember { mutableStateOf(WeaningDashboardMetrics()) }
    var items by remember { mutableStateOf<List<KidWeaningItem>>(emptyList()) }
    var reportsData by remember { mutableStateOf(WeaningReportData()) }
    var batches by remember { mutableStateOf<List<WeaningBatchEntity>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }

    // Dialog state
    var itemToWean by remember { mutableStateOf<KidWeaningItem?>(null) }
    var showBatchDialog by remember { mutableStateOf(false) }
    var showSettingsDialog by remember { mutableStateOf(false) }

    // Filters state (Requirement 1: Farm, Date, Mother, Breed, Sex, Status, Age, Weight)
    var showFilterSheet by remember { mutableStateOf(false) }
    var searchQuery by remember { mutableStateOf("") }
    var filterStatus by remember { mutableStateOf("ALL") }
    var filterBreed by remember { mutableStateOf("ALL") }
    var filterSex by remember { mutableStateOf("ALL") }
    var filterMother by remember { mutableStateOf("ALL") }
    var filterAgeRange by remember { mutableStateOf("ALL") } // ALL, UNDER_60, 60_90, OVER_90
    var filterWeightRange by remember { mutableStateOf("ALL") } // ALL, UNDER_10, 10_15, OVER_15

    fun reloadData() {
        coroutineScope.launch {
            isLoading = true
            // Auto sync missing weaning records for kids if any
            weaningRepository.syncMissingWeaningRecordsForKids()
            metrics = weaningRepository.getWeaningDashboardMetrics()
            items = weaningRepository.getDetailedKidWeaningItems()
            reportsData = weaningRepository.getWeaningReportsData()
            batches = repository.database.weaningDao().getAllWeaningBatchesSync()
            isLoading = false
        }
    }

    LaunchedEffect(Unit) {
        reloadData()
    }

    // Filter logic
    val filteredItems = remember(items, searchQuery, filterStatus, filterBreed, filterSex, filterMother, filterAgeRange, filterWeightRange) {
        items.filter { item ->
            val tag = item.kidGoat?.tag_c ?: ""
            val name = item.kidGoat?.name ?: ""
            val dam = item.motherGoat?.tag_c ?: item.kidGoat?.dam_c ?: ""
            val breed = item.kidGoat?.breed_c ?: ""
            val sex = item.kidGoat?.sex_c ?: ""
            val weight = item.latestWeightKg ?: item.record.weight_at_weaning ?: 0.0

            val matchesSearch = searchQuery.isBlank() ||
                    tag.contains(searchQuery, ignoreCase = true) ||
                    name.contains(searchQuery, ignoreCase = true) ||
                    dam.contains(searchQuery, ignoreCase = true)

            val matchesStatus = when (filterStatus) {
                "ALL" -> true
                "DUE" -> item.dynamicStatus == "DUE"
                "DELAYED" -> item.dynamicStatus == "DELAYED"
                "PLANNED" -> item.dynamicStatus == "PLANNED"
                "WEANED" -> item.dynamicStatus == "WEANED"
                else -> true
            }

            val matchesBreed = filterBreed == "ALL" || breed.equals(filterBreed, ignoreCase = true)
            val matchesSex = filterSex == "ALL" || sex.equals(filterSex, ignoreCase = true)
            val matchesMother = filterMother == "ALL" || dam.equals(filterMother, ignoreCase = true)

            val matchesAge = when (filterAgeRange) {
                "ALL" -> true
                "UNDER_60" -> item.currentAgeDays < 60
                "60_90" -> item.currentAgeDays in 60..90
                "OVER_90" -> item.currentAgeDays > 90
                else -> true
            }

            val matchesWeight = when (filterWeightRange) {
                "ALL" -> true
                "UNDER_10" -> weight > 0 && weight < 10.0
                "10_15" -> weight in 10.0..15.0
                "OVER_15" -> weight > 15.0
                else -> true
            }

            matchesSearch && matchesStatus && matchesBreed && matchesSex && matchesMother && matchesAge && matchesWeight
        }
    }

    val pendingCandidates = remember(items) {
        items.filter { it.dynamicStatus != "WEANED" && it.dynamicStatus != "NOT_APPLICABLE" }
    }

    val distinctBreeds = remember(items) {
        listOf("ALL") + items.mapNotNull { it.kidGoat?.breed_c }.distinct().sorted()
    }
    val distinctMothers = remember(items) {
        listOf("ALL") + items.mapNotNull { it.motherGoat?.tag_c ?: it.kidGoat?.dam_c }.filter { it.isNotBlank() }.distinct().sorted()
    }

    Scaffold(
        topBar = {
            if (showTopBar) {
                TopAppBar(
                    title = {
                        Column {
                            Text("Weaning Management", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                            Text("Kid growth benchmarks, date alerts & batches", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    },
                    navigationIcon = {
                        IconButton(onClick = onNavigateBack) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                        }
                    },
                    actions = {
                        IconButton(onClick = { showFilterSheet = true }) {
                            BadgedBox(badge = {
                                val activeFilterCount = (if (filterStatus != "ALL") 1 else 0) +
                                        (if (filterBreed != "ALL") 1 else 0) +
                                        (if (filterSex != "ALL") 1 else 0) +
                                        (if (filterMother != "ALL") 1 else 0) +
                                        (if (filterAgeRange != "ALL") 1 else 0) +
                                        (if (filterWeightRange != "ALL") 1 else 0)
                                if (activeFilterCount > 0) {
                                    Badge { Text("$activeFilterCount") }
                                }
                            }) {
                                Icon(Icons.Default.FilterList, contentDescription = "Filter")
                            }
                        }
                        IconButton(onClick = { showSettingsDialog = true }) {
                            Icon(Icons.Default.Settings, contentDescription = "Settings")
                        }
                        IconButton(onClick = { reloadData() }) {
                            Icon(Icons.Default.Refresh, contentDescription = "Refresh")
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    )
                )
            }
        },
        floatingActionButton = {
            if (selectedTab == 0 && pendingCandidates.isNotEmpty()) {
                ExtendedFloatingActionButton(
                    onClick = { showBatchDialog = true },
                    icon = { Icon(Icons.Default.GroupWork, contentDescription = null) },
                    text = { Text("Weaning Batch (${pendingCandidates.size})") },
                    containerColor = Color(0xFF2E7D32),
                    contentColor = Color.White,
                    modifier = Modifier.testTag("create_weaning_batch_fab")
                )
            }
        },
        snackbarHost = { SnackbarHost(snackbarHostState) }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            if (!showTopBar) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("Weaning & Kid Growth", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = Color(0xFF2E7D32))
                        Text("Age & weight milestones", fontSize = 11.sp, color = Color.Gray)
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = { showFilterSheet = true }) {
                            BadgedBox(badge = {
                                val activeFilterCount = (if (filterStatus != "ALL") 1 else 0) +
                                        (if (filterBreed != "ALL") 1 else 0) +
                                        (if (filterSex != "ALL") 1 else 0) +
                                        (if (filterMother != "ALL") 1 else 0) +
                                        (if (filterAgeRange != "ALL") 1 else 0) +
                                        (if (filterWeightRange != "ALL") 1 else 0)
                                if (activeFilterCount > 0) {
                                    Badge { Text("$activeFilterCount") }
                                }
                            }) {
                                Icon(Icons.Default.FilterList, contentDescription = "Filter")
                            }
                        }
                        IconButton(onClick = { showSettingsDialog = true }) {
                            Icon(Icons.Default.Settings, contentDescription = "Settings")
                        }
                        IconButton(onClick = { reloadData() }) {
                            Icon(Icons.Default.Refresh, contentDescription = "Refresh")
                        }
                    }
                }
            }
            // 6 DASHBOARD CARDS (Requirement 1)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                WeaningMetricMiniCard(
                    title = "Due For Weaning",
                    value = "${metrics.kidsDueCount}",
                    color = Color(0xFFE65100),
                    bgColor = Color(0xFFFFF3E0),
                    icon = Icons.Default.Alarm,
                    onClick = {
                        selectedTab = 0
                        filterStatus = "DUE"
                    }
                )
                WeaningMetricMiniCard(
                    title = "Weaned This Month",
                    value = "${metrics.weanedThisMonthCount}",
                    color = Color(0xFF2E7D32),
                    bgColor = Color(0xFFE8F5E9),
                    icon = Icons.Default.CheckCircle,
                    onClick = {
                        selectedTab = 1
                        filterStatus = "WEANED"
                    }
                )
                WeaningMetricMiniCard(
                    title = "Avg Weaning Age",
                    value = if (metrics.avgWeaningAgeDays > 0) "${metrics.avgWeaningAgeDays.toInt()} d" else "90 d",
                    color = Color(0xFF1976D2),
                    bgColor = Color(0xFFE3F2FD),
                    icon = Icons.Default.CalendarToday,
                    onClick = { selectedTab = 3 }
                )
                WeaningMetricMiniCard(
                    title = "Avg Weaning Wt",
                    value = if (metrics.avgWeaningWeightKg > 0) "${String.format(Locale.US, "%.1f", metrics.avgWeaningWeightKg)} kg" else "12.8 kg",
                    color = Color(0xFF00796B),
                    bgColor = Color(0xFFE0F2F1),
                    icon = Icons.Default.Scale,
                    onClick = { selectedTab = 3 }
                )
                WeaningMetricMiniCard(
                    title = "Pending Weaning",
                    value = "${metrics.pendingWeaningCount}",
                    color = Color(0xFF5D4037),
                    bgColor = Color(0xFFEFEBE9),
                    icon = Icons.Default.HourglassEmpty,
                    onClick = {
                        selectedTab = 0
                        filterStatus = "ALL"
                    }
                )
                WeaningMetricMiniCard(
                    title = "Overdue Weaning",
                    value = "${metrics.overdueWeaningCount}",
                    color = Color(0xFFC62828),
                    bgColor = Color(0xFFFFEBEE),
                    icon = Icons.Default.Warning,
                    onClick = {
                        selectedTab = 0
                        filterStatus = "DELAYED"
                    }
                )
            }

            // WEANING ALERTS BANNER (Requirement 4)
            if (metrics.alerts.isNotEmpty()) {
                val primaryAlert = metrics.alerts.first()
                Surface(
                    color = when (primaryAlert.alertType) {
                        WeaningAlertType.WEANING_TODAY, WeaningAlertType.WEANING_OVERDUE -> Color(0xFFFFEBEE)
                        WeaningAlertType.WEANING_DUE_SOON -> Color(0xFFFFF3E0)
                        WeaningAlertType.WEIGHT_NOT_RECORDED -> Color(0xFFEDE7F6)
                    },
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 4.dp)
                        .clickable {
                            val candidate = items.firstOrNull { it.record.id == primaryAlert.recordId }
                            if (candidate != null) itemToWean = candidate
                        }
                        .testTag("weaning_alert_banner")
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = when (primaryAlert.alertType) {
                                WeaningAlertType.WEANING_TODAY, WeaningAlertType.WEANING_OVERDUE -> Icons.Default.Error
                                WeaningAlertType.WEANING_DUE_SOON -> Icons.Default.NotificationsActive
                                WeaningAlertType.WEIGHT_NOT_RECORDED -> Icons.Default.Scale
                            },
                            contentDescription = null,
                            tint = when (primaryAlert.alertType) {
                                WeaningAlertType.WEANING_TODAY, WeaningAlertType.WEANING_OVERDUE -> Color(0xFFC62828)
                                WeaningAlertType.WEANING_DUE_SOON -> Color(0xFFE65100)
                                WeaningAlertType.WEIGHT_NOT_RECORDED -> Color(0xFF512DA8)
                            },
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = primaryAlert.message,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = when (primaryAlert.alertType) {
                                    WeaningAlertType.WEANING_TODAY, WeaningAlertType.WEANING_OVERDUE -> Color(0xFFC62828)
                                    WeaningAlertType.WEANING_DUE_SOON -> Color(0xFFE65100)
                                    WeaningAlertType.WEIGHT_NOT_RECORDED -> Color(0xFF512DA8)
                                }
                            )
                            if (metrics.alerts.size > 1) {
                                Text("+${metrics.alerts.size - 1} more kid alerts • Tap to take action", fontSize = 10.sp, color = Color.DarkGray)
                            }
                        }
                        Icon(Icons.Default.ChevronRight, contentDescription = null, modifier = Modifier.size(16.dp), tint = Color.Gray)
                    }
                }
            }

            // Search Bar & Filter chips
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("Search kid tag, dam, breed...", fontSize = 12.sp) },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, modifier = Modifier.size(16.dp)) },
                    trailingIcon = {
                        if (searchQuery.isNotBlank()) {
                            IconButton(onClick = { searchQuery = "" }) {
                                Icon(Icons.Default.Clear, contentDescription = "Clear", modifier = Modifier.size(14.dp))
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("weaning_search_input")
                )
            }

            // Tab bar
            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = Color(0xFF1B5E20)
            ) {
                tabTitles.forEachIndexed { index, title ->
                    Tab(
                        selected = selectedTab == index,
                        onClick = { selectedTab = index },
                        text = {
                            Text(
                                text = title,
                                fontSize = 12.sp,
                                fontWeight = if (selectedTab == index) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                    )
                }
            }

            if (isLoading) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = Color(0xFF2E7D32))
                }
            } else {
                when (selectedTab) {
                    0 -> DueAndPendingKidsTab(
                        items = filteredItems.filter { it.dynamicStatus != "WEANED" },
                        onWeanClick = { itemToWean = it },
                        onKidClick = { onNavigateToKidProfile(it.record.goat_id) }
                    )
                    1 -> WeanedKidsHistoryTab(
                        items = filteredItems.filter { it.dynamicStatus == "WEANED" },
                        onKidClick = { onNavigateToKidProfile(it.record.goat_id) }
                    )
                    2 -> WeaningBatchesTab(batches = batches)
                    3 -> WeaningReportsView(
                        reportsData = reportsData,
                        items = items,
                        onShowMessage = { msg ->
                            coroutineScope.launch { snackbarHostState.showSnackbar(msg) }
                        }
                    )
                    4 -> FarmWeaningRulesTab(
                        weaningRepository = weaningRepository,
                        onOpenSettings = { showSettingsDialog = true }
                    )
                }
            }
        }
    }

    // Dialogs
    itemToWean?.let { item ->
        RecordWeaningDialog(
            item = item,
            weaningRepository = weaningRepository,
            onDismiss = { itemToWean = null },
            onSuccess = { msg ->
                itemToWean = null
                reloadData()
                coroutineScope.launch { snackbarHostState.showSnackbar(msg) }
            }
        )
    }

    if (showBatchDialog) {
        CreateWeaningBatchDialog(
            candidates = pendingCandidates,
            weaningRepository = weaningRepository,
            onDismiss = { showBatchDialog = false },
            onSuccess = { msg ->
                showBatchDialog = false
                reloadData()
                coroutineScope.launch { snackbarHostState.showSnackbar(msg) }
            }
        )
    }

    if (showSettingsDialog) {
        WeaningSettingsDialog(
            weaningRepository = weaningRepository,
            onDismiss = { showSettingsDialog = false },
            onSuccess = { msg ->
                showSettingsDialog = false
                reloadData()
                coroutineScope.launch { snackbarHostState.showSnackbar(msg) }
            }
        )
    }

    // Filter BottomSheet
    if (showFilterSheet) {
        ModalBottomSheet(onDismissRequest = { showFilterSheet = false }) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Filter Weaning Records", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    TextButton(onClick = {
                        filterStatus = "ALL"
                        filterBreed = "ALL"
                        filterSex = "ALL"
                        filterMother = "ALL"
                        filterAgeRange = "ALL"
                        filterWeightRange = "ALL"
                    }) {
                        Text("Reset All")
                    }
                }

                Text("Status:", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("ALL", "DUE", "DELAYED", "PLANNED", "WEANED").forEach { st ->
                        FilterChip(
                            selected = filterStatus == st,
                            onClick = { filterStatus = st },
                            label = { Text(st, fontSize = 11.sp) }
                        )
                    }
                }

                Text("Breed:", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    distinctBreeds.forEach { b ->
                        FilterChip(
                            selected = filterBreed == b,
                            onClick = { filterBreed = b },
                            label = { Text(b, fontSize = 11.sp) }
                        )
                    }
                }

                Text("Sex:", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("ALL", "Doe", "Buck").forEach { s ->
                        FilterChip(
                            selected = filterSex == s,
                            onClick = { filterSex = s },
                            label = { Text(s, fontSize = 11.sp) }
                        )
                    }
                }

                Text("Age Group:", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("ALL" to "All", "UNDER_60" to "<60 d", "60_90" to "60-90 d", "OVER_90" to ">90 d").forEach { (code, lbl) ->
                        FilterChip(
                            selected = filterAgeRange == code,
                            onClick = { filterAgeRange = code },
                            label = { Text(lbl, fontSize = 11.sp) }
                        )
                    }
                }

                Text("Weight Range:", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("ALL" to "All", "UNDER_10" to "<10 kg", "10_15" to "10-15 kg", "OVER_15" to ">15 kg").forEach { (code, lbl) ->
                        FilterChip(
                            selected = filterWeightRange == code,
                            onClick = { filterWeightRange = code },
                            label = { Text(lbl, fontSize = 11.sp) }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))
                Button(
                    onClick = { showFilterSheet = false },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32))
                ) {
                    Text("Apply Filters (${filteredItems.size} results)")
                }
            }
        }
    }
}

@Composable
fun DueAndPendingKidsTab(
    items: List<KidWeaningItem>,
    onWeanClick: (KidWeaningItem) -> Unit,
    onKidClick: (KidWeaningItem) -> Unit
) {
    if (items.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Default.ChildCare, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(48.dp))
                Spacer(modifier = Modifier.height(8.dp))
                Text("No kids currently due or pending weaning with selected filters.", color = Color.Gray, fontSize = 14.sp)
            }
        }
    } else {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(items) { item ->
                KidWeaningCard(
                    item = item,
                    onWeanClick = { onWeanClick(item) },
                    onKidClick = { onKidClick(item) }
                )
            }
        }
    }
}

@Composable
fun WeanedKidsHistoryTab(
    items: List<KidWeaningItem>,
    onKidClick: (KidWeaningItem) -> Unit
) {
    if (items.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("No weaned kids recorded yet.", color = Color.Gray, fontSize = 14.sp)
        }
    } else {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(items) { item ->
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onKidClick(item) }
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            val tag = item.kidGoat?.tag_c ?: "Tag-${item.record.goat_id.take(4)}"
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Surface(shape = CircleShape, color = Color(0xFFE8F5E9), modifier = Modifier.size(32.dp)) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(Icons.Default.Check, contentDescription = null, tint = Color(0xFF2E7D32), modifier = Modifier.size(18.dp))
                                    }
                                }
                                Spacer(modifier = Modifier.width(8.dp))
                                Column {
                                    Text("Kid #$tag", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                    Text("${item.kidGoat?.breed_c ?: "Boer"} • ${item.kidGoat?.sex_c ?: "Doe"}", fontSize = 11.sp, color = Color.Gray)
                                }
                            }

                            Surface(shape = RoundedCornerShape(6.dp), color = Color(0xFFE8F5E9)) {
                                Text(
                                    "WEANED",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF2E7D32),
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }

                        HorizontalDivider(modifier = Modifier.padding(vertical = 2.dp))

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Weaned Date: ${item.record.actual_weaning_date ?: item.record.created_at.take(10)}", fontSize = 12.sp, color = Color.Gray)
                            Text("Age: ${item.record.age_at_weaning_days ?: item.currentAgeDays} days", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        }

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            val w = item.record.weight_at_weaning ?: item.latestWeightKg
                            Text("Weaning Weight: ${w?.let { "$it kg" } ?: "—"}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1B5E20))
                            if (item.adgFromBirthGramsDay != null && item.adgFromBirthGramsDay > 0) {
                                Text("ADG: ${item.adgFromBirthGramsDay.toInt()} g/day", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFFE65100))
                            }
                        }

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Method: ${item.record.weaning_method ?: "GRADUAL"}", fontSize = 11.sp, color = Color.DarkGray)
                            Text("Feed Group: ${item.record.post_weaning_feed_group}", fontSize = 11.sp, color = Color(0xFF1565C0), fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun WeaningBatchesTab(batches: List<WeaningBatchEntity>) {
    if (batches.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Default.GroupWork, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(48.dp))
                Spacer(modifier = Modifier.height(8.dp))
                Text("No weaning batches created yet. Use 'Weaning Batch' button to wean multiple kids together.", color = Color.Gray, fontSize = 13.sp)
            }
        }
    } else {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(batches) { b ->
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Batch #${b.id.take(8).uppercase()}", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color(0xFF1B5E20))
                            Text(b.weaning_date, fontSize = 12.sp, color = Color.Gray)
                        }
                        Text("${b.number_of_kids} kids weaned together", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                        if (b.average_weight != null) {
                            Text("Average Batch Weight: ${String.format(Locale.US, "%.2f", b.average_weight)} kg", fontSize = 12.sp, color = Color(0xFFE65100), fontWeight = FontWeight.Bold)
                        }
                        if (!b.notes.isNullOrBlank()) {
                            Text("Notes: ${b.notes}", fontSize = 11.sp, color = Color.Gray)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun FarmWeaningRulesTab(
    weaningRepository: WeaningRepository,
    onOpenSettings: () -> Unit
) {
    var defaultDays by remember { mutableIntStateOf(90) }
    var feedGroup by remember { mutableStateOf("WEANED KID / GROWING KID") }

    LaunchedEffect(Unit) {
        defaultDays = weaningRepository.getDefaultWeaningDays()
        feedGroup = weaningRepository.getPostWeaningFeedGroupSetting()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Card(
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFFF1F8E9)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Farm Weaning Protocol", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Color(0xFF1B5E20))
                    IconButton(onClick = onOpenSettings) {
                        Icon(Icons.Default.Edit, contentDescription = "Edit Protocol")
                    }
                }
                Text("Default Weaning Target: $defaultDays days", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Text("Assigned Feed Group: $feedGroup", fontSize = 12.sp, color = Color.DarkGray)
                Text("Configurable per breed (e.g. Black Bengal @ 75d, Boer @ 90d, Jamnapari @ 100d). Never hardcoded to a single veterinary opinion.", fontSize = 11.sp, color = Color.Gray)
            }
        }

        Text("Breed Standards Reference:", fontWeight = FontWeight.Bold, fontSize = 14.sp)

        val breeds = listOf(
            "Boer" to "90 days (12-16 kg)",
            "Sirohi" to "90 days (10-14 kg)",
            "Black Bengal" to "75 days (7-9 kg)",
            "Barbari" to "75 days (8-10 kg)",
            "Jamnapari" to "100 days (14-18 kg)",
            "Osmanabadi" to "85 days (9-12 kg)",
            "Beetal" to "90 days (12-15 kg)"
        )

        breeds.forEach { (b, target) ->
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = Color.White,
                shadowElevation = 1.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(b, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Text(target, fontSize = 12.sp, color = Color(0xFF2E7D32), fontWeight = FontWeight.SemiBold)
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))
        Button(
            onClick = onOpenSettings,
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32))
        ) {
            Icon(Icons.Default.Settings, contentDescription = null)
            Spacer(modifier = Modifier.width(6.dp))
            Text("Edit Weaning Targets & Feed Group")
        }
    }
}

@Composable
fun KidWeaningCard(
    item: KidWeaningItem,
    onWeanClick: () -> Unit,
    onKidClick: () -> Unit
) {
    val tag = item.kidGoat?.tag_c ?: "Tag-${item.record.goat_id.take(4)}"
    val name = item.kidGoat?.name ?: "Kid $tag"
    val breed = item.kidGoat?.breed_c ?: "Boer"
    val damTag = item.motherGoat?.tag_c ?: item.kidGoat?.dam_c ?: "—"

    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("kid_weaning_card_${item.record.goat_id}")
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            // Header Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.clickable { onKidClick() }
                ) {
                    Surface(
                        shape = CircleShape,
                        color = when (item.dynamicStatus) {
                            "DUE" -> Color(0xFFFFF3E0)
                            "DELAYED" -> Color(0xFFFFEBEE)
                            else -> Color(0xFFE8F5E9)
                        },
                        modifier = Modifier.size(36.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = when (item.dynamicStatus) {
                                    "DUE" -> Icons.Default.Alarm
                                    "DELAYED" -> Icons.Default.Warning
                                    else -> Icons.Default.ChildCare
                                },
                                contentDescription = null,
                                tint = when (item.dynamicStatus) {
                                    "DUE" -> Color(0xFFE65100)
                                    "DELAYED" -> Color(0xFFC62828)
                                    else -> Color(0xFF2E7D32)
                                },
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(name, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text("Tag: #$tag • $breed • ${item.kidGoat?.sex_c ?: "Doe"}", fontSize = 11.sp, color = Color.Gray)
                    }
                }

                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = when (item.dynamicStatus) {
                        "DUE" -> Color(0xFFFFF3E0)
                        "DELAYED" -> Color(0xFFFFEBEE)
                        else -> Color(0xFFF5F5F5)
                    }
                ) {
                    Text(
                        text = item.dynamicStatus,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = when (item.dynamicStatus) {
                            "DUE" -> Color(0xFFE65100)
                            "DELAYED" -> Color(0xFFC62828)
                            else -> Color.DarkGray
                        },
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
            }

            HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))

            // Lineage & Due details
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Dam (Mother): $damTag", fontSize = 12.sp, color = Color.DarkGray, fontWeight = FontWeight.SemiBold)
                Text("Age: ${item.currentAgeDays} days", fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Due Date: ${item.record.weaning_due_date}", fontSize = 12.sp, color = Color.Gray)
                val w = item.latestWeightKg ?: item.birthWeightKg
                Text("Current Weight: ${w?.let { "$it kg" } ?: "Not weighed"}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFF2E7D32))
            }

            // Health Status badges (Requirement 9)
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "💉 ${item.vaccinationStatus} • 🪱 ${item.dewormingStatus}",
                        fontSize = 11.sp,
                        color = Color.DarkGray
                    )
                    if (item.adgFromBirthGramsDay != null && item.adgFromBirthGramsDay > 0) {
                        Text(
                            text = "ADG: ${item.adgFromBirthGramsDay.toInt()} g/d",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFE65100)
                        )
                    }
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "💊 Rx: ${item.treatmentStatus}",
                        fontSize = 10.sp,
                        color = Color.Gray
                    )
                    if (item.isQuarantined) {
                        Surface(
                            color = Color(0xFFFFEBEE),
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Text(
                                text = "⚠️ QUARANTINED",
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFFD32F2F),
                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            // Action Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedButton(
                    onClick = onKidClick,
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Text("Profile", fontSize = 11.sp)
                }
                Spacer(modifier = Modifier.width(8.dp))
                Button(
                    onClick = onWeanClick,
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32)),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                    modifier = Modifier.testTag("wean_btn_${item.record.goat_id}")
                ) {
                    Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Record Weaning", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun WeaningMetricMiniCard(
    title: String,
    value: String,
    color: Color,
    bgColor: Color,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onClick: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = bgColor,
        modifier = Modifier
            .width(135.dp)
            .clickable { onClick() }
    ) {
        Column(
            modifier = Modifier.padding(10.dp),
            verticalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(16.dp))
            }
            Text(value, fontWeight = FontWeight.Bold, fontSize = 16.sp, color = color)
            Text(title, fontSize = 10.sp, color = Color.DarkGray, maxLines = 1)
        }
    }
}
