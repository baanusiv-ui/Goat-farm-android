package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.offline.OfflineSyncManager
import com.example.data.offline.SyncConflictEntity
import com.example.data.offline.SyncQueueEntity
import com.example.data.offline.SyncState
import com.example.ui.theme.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SyncCenterDialog(
    syncManager: OfflineSyncManager,
    isOnline: Boolean,
    backupManager: com.example.data.backup.BackupManager? = null,
    onNavigateToSettings: (() -> Unit)? = null,
    onDismiss: () -> Unit
) {
    val coroutineScope = rememberCoroutineScope()
    val syncState by syncManager.syncState.collectAsState()
    val isSyncing by syncManager.isSyncing.collectAsState()
    val lastSyncTime by syncManager.lastSyncTime.collectAsState()
    val pendingOps by syncManager.pendingOperations.collectAsState(initial = emptyList())
    val conflicts by syncManager.unresolvedConflicts.collectAsState(initial = emptyList())

    val dateFormat = remember { SimpleDateFormat("MMM dd, yyyy HH:mm", Locale.getDefault()) }
    val lastSyncStr = remember(lastSyncTime) {
        if (lastSyncTime > 0) dateFormat.format(Date(lastSyncTime)) else "Never"
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(FarmGreenContainer),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Sync,
                            contentDescription = null,
                            tint = FarmGreenDark,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "Sync Center",
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleLarge
                    )
                }
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Default.Close, contentDescription = "Close")
                }
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 500.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Status Header Card
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = when (syncState) {
                            SyncState.SYNCED -> FarmGreenContainer
                            SyncState.PENDING -> FarmAmberContainer
                            SyncState.OFFLINE -> Color(0xFFECEFF1)
                            SyncState.ERROR -> FarmErrorContainer
                            SyncState.SYNCING -> Color(0xFFE1F5FE)
                        }
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(10.dp)
                                        .clip(CircleShape)
                                        .background(
                                            if (isOnline) FarmSuccess else Color.Gray
                                        )
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = if (isOnline) "Online" else "Offline",
                                    fontWeight = FontWeight.Bold,
                                    style = MaterialTheme.typography.labelLarge,
                                    color = if (isOnline) FarmSuccess else Color.DarkGray
                                )
                            }

                            // Sync State badge
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = Color.White.copy(alpha = 0.8f)
                            ) {
                                Text(
                                    text = when (syncState) {
                                        SyncState.SYNCED -> "All Synced"
                                        SyncState.PENDING -> "${pendingOps.size} Pending"
                                        SyncState.OFFLINE -> "Offline Mode"
                                        SyncState.ERROR -> "Sync Error"
                                        SyncState.SYNCING -> "Syncing..."
                                    },
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                    color = when (syncState) {
                                        SyncState.SYNCED -> FarmSuccess
                                        SyncState.PENDING -> FarmWarning
                                        SyncState.OFFLINE -> Color.DarkGray
                                        SyncState.ERROR -> FarmError
                                        SyncState.SYNCING -> Color(0xFF0277BD)
                                    }
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Last synced: $lastSyncStr",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        if (!isOnline) {
                            Text(
                                text = "All changes are saved safely to your phone and will auto-sync once connection returns.",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(top = 4.dp)
                            )
                        }
                    }
                }

                // Stats row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Card(
                        modifier = Modifier.weight(1f),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                    ) {
                        Column(modifier = Modifier.padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("Pending", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                            Text(
                                "${pendingOps.size}",
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold,
                                color = if (pendingOps.isNotEmpty()) FarmWarning else FarmSuccess
                            )
                        }
                    }

                    Card(
                        modifier = Modifier.weight(1f),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                    ) {
                        Column(modifier = Modifier.padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("Failed", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                            Text(
                                "${pendingOps.count { it.syncStatus == "FAILED" }}",
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold,
                                color = if (pendingOps.any { it.syncStatus == "FAILED" }) FarmError else Color.Gray
                            )
                        }
                    }

                    Card(
                        modifier = Modifier.weight(1f),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                    ) {
                        Column(modifier = Modifier.padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("Conflicts", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                            Text(
                                "${conflicts.size}",
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold,
                                color = if (conflicts.isNotEmpty()) FarmError else Color.Gray
                            )
                        }
                    }
                }

                // Conflicts Section (if any)
                if (conflicts.isNotEmpty()) {
                    Text(
                        "Sync Conflicts (${conflicts.size})",
                        fontWeight = FontWeight.Bold,
                        color = FarmError,
                        style = MaterialTheme.typography.titleSmall
                    )
                    conflicts.forEach { conflict ->
                        ConflictItemCard(conflict = conflict, onResolve = { useLocal ->
                            coroutineScope.launch {
                                syncManager.resolveConflict(conflict.conflictId, useLocal)
                            }
                        })
                    }
                }

                // Google Drive Backup Status Card
                backupManager?.let { bm ->
                    val backupStatus by bm.backupStatus.collectAsState()
                    val authManager = bm.authManager
                    val connectedEmail by authManager.connectedAccountEmail.collectAsState()

                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFF1F8E9)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.CloudSync,
                                        contentDescription = null,
                                        tint = FarmGreenDark,
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "Google Drive Backup",
                                        fontWeight = FontWeight.Bold,
                                        style = MaterialTheme.typography.titleSmall
                                    )
                                }
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = when (backupStatus) {
                                        com.example.data.backup.DriveBackupStatus.SYNCED -> FarmGreenContainer
                                        com.example.data.backup.DriveBackupStatus.PENDING -> FarmAmberContainer
                                        com.example.data.backup.DriveBackupStatus.FAILED -> FarmErrorContainer
                                        else -> Color.White
                                    }
                                ) {
                                    Text(
                                        text = when (backupStatus) {
                                            com.example.data.backup.DriveBackupStatus.SYNCED -> "Backed up"
                                            com.example.data.backup.DriveBackupStatus.PENDING -> "Pending"
                                            com.example.data.backup.DriveBackupStatus.FAILED -> "Failed"
                                            com.example.data.backup.DriveBackupStatus.IN_PROGRESS -> "Backing up..."
                                            com.example.data.backup.DriveBackupStatus.IDLE -> if (authManager.isConnected()) "Connected" else "Not connected"
                                        },
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = when (backupStatus) {
                                            com.example.data.backup.DriveBackupStatus.SYNCED -> FarmGreenDark
                                            com.example.data.backup.DriveBackupStatus.PENDING -> FarmBrown
                                            com.example.data.backup.DriveBackupStatus.FAILED -> FarmError
                                            else -> Color.DarkGray
                                        },
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }

                            Text(
                                text = bm.getStatusDisplayMessage(isOnline),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(top = 4.dp)
                            )

                            if (onNavigateToSettings != null) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(top = 4.dp),
                                    horizontalArrangement = Arrangement.End
                                ) {
                                    TextButton(
                                        onClick = {
                                            onDismiss()
                                            onNavigateToSettings()
                                        },
                                        modifier = Modifier.testTag("dialog_open_backup_settings_btn")
                                    ) {
                                        Icon(Icons.Default.Settings, contentDescription = null, modifier = Modifier.size(14.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Cloud Backup Settings", fontSize = 12.sp)
                                    }
                                }
                            }
                        }
                    }
                }

                // Pending Queue List
                Text(
                    text = "Sync Queue (${pendingOps.size})",
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.titleSmall
                )

                if (pendingOps.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 16.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.CloudDone, contentDescription = null, tint = FarmSuccess, modifier = Modifier.size(36.dp))
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("Local database is completely up to date!", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                        }
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(max = 200.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        items(pendingOps, key = { it.operationId }) { op ->
                            QueueItemRow(op = op)
                        }
                    }
                }
            }
        },
        confirmButton = {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (pendingOps.any { it.syncStatus == "FAILED" }) {
                    OutlinedButton(
                        onClick = {
                            coroutineScope.launch { syncManager.retryFailed() }
                        },
                        enabled = isOnline && !isSyncing,
                        modifier = Modifier.testTag("retry_failed_sync_btn")
                    ) {
                        Text("Retry Failed")
                    }
                }

                Button(
                    onClick = {
                        coroutineScope.launch { syncManager.syncNow() }
                    },
                    enabled = isOnline && !isSyncing,
                    colors = ButtonDefaults.buttonColors(containerColor = FarmGreenDark),
                    modifier = Modifier.testTag("sync_now_modal_btn")
                ) {
                    if (isSyncing) {
                        CircularProgressIndicator(color = Color.White, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Syncing...")
                    } else {
                        Icon(Icons.Default.Sync, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Sync Now", fontWeight = FontWeight.Bold)
                    }
                }
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Close")
            }
        }
    )
}

@Composable
fun QueueItemRow(op: SyncQueueEntity) {
    val tableNameClean = op.entityTable.removeSuffix("_c").replace("_", " ").capitalize(Locale.ROOT)
    Card(
        colors = CardDefaults.cardColors(
            containerColor = if (op.syncStatus == "FAILED") FarmErrorContainer.copy(alpha = 0.5f) else Color.White
        ),
        shape = RoundedCornerShape(8.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        shape = RoundedCornerShape(4.dp),
                        color = when (op.operationType) {
                            "CREATE" -> FarmGreenContainer
                            "UPDATE" -> FarmAmberContainer
                            else -> FarmErrorContainer
                        }
                    ) {
                        Text(
                            text = op.operationType,
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = when (op.operationType) {
                                "CREATE" -> FarmGreenDark
                                "UPDATE" -> FarmBrown
                                else -> FarmError
                            },
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = tableNameClean,
                        fontWeight = FontWeight.SemiBold,
                        style = MaterialTheme.typography.bodyMedium
                    )
                }

                if (!op.lastError.isNullOrBlank()) {
                    Text(
                        text = "Error: ${op.lastError}",
                        color = FarmError,
                        style = MaterialTheme.typography.labelSmall,
                        maxLines = 1,
                        modifier = Modifier.padding(top = 2.dp)
                    )
                }
            }

            if (op.retryCount > 0) {
                Text(
                    text = "Retry: ${op.retryCount}",
                    style = MaterialTheme.typography.labelSmall,
                    color = Color.Gray
                )
            }
        }
    }
}

@Composable
fun ConflictItemCard(
    conflict: SyncConflictEntity,
    onResolve: (useLocal: Boolean) -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = FarmErrorContainer),
        shape = RoundedCornerShape(10.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(
                text = "${conflict.entityTable.removeSuffix("_c")} Conflict",
                fontWeight = FontWeight.Bold,
                color = FarmError
            )
            Text(
                text = conflict.conflictReason,
                style = MaterialTheme.typography.bodySmall,
                color = Color.Black
            )
            Spacer(modifier = Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = { onResolve(true) },
                    colors = ButtonDefaults.buttonColors(containerColor = FarmGreenDark),
                    modifier = Modifier.weight(1f)
                ) {
                    Text("Keep Local", fontSize = 12.sp)
                }
                OutlinedButton(
                    onClick = { onResolve(false) },
                    modifier = Modifier.weight(1f)
                ) {
                    Text("Use Remote", fontSize = 12.sp)
                }
            }
        }
    }
}
