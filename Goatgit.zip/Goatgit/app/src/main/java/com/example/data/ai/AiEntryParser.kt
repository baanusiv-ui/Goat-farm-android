package com.example.data.ai

import com.example.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit
import java.util.regex.Pattern

sealed class ParsedFarmEntry {
    data class Weight(
        val tag: String,
        val weightKg: Double,
        val date: String,
        val method: String = "Scale",
        val notes: String? = null
    ) : ParsedFarmEntry()

    data class Vaccination(
        val tag: String,
        val vaccine: String,
        val dose: String = "1 ml",
        val administeredDate: String,
        val nextDueDate: String? = null,
        val batchNumber: String? = null,
        val administeredBy: String? = null,
        val notes: String? = null
    ) : ParsedFarmEntry()

    data class Deworming(
        val tag: String,
        val medicine: String,
        val dose: String = "5 ml",
        val treatmentDate: String,
        val nextDueDate: String? = null,
        val weightAtTreatment: Double? = null,
        val administeredBy: String? = null,
        val notes: String? = null
    ) : ParsedFarmEntry()

    data class Treatment(
        val tag: String,
        val symptoms: String,
        val diagnosis: String,
        val medicine: String,
        val dose: String = "2 ml",
        val startDate: String,
        val notes: String? = null
    ) : ParsedFarmEntry()

    data class NewGoat(
        val name: String,
        val tag: String,
        val breed: String = "Boer",
        val sex: String = "Doe",
        val weightKg: Double? = null,
        val notes: String? = null
    ) : ParsedFarmEntry()
}

class AiEntryParser {

    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()
    private val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.US)

    private val client = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    suspend fun parseFarmerInput(input: String): Result<ParsedFarmEntry> = withContext(Dispatchers.IO) {
        val apiKey = try {
            BuildConfig::class.java.getField("GEMINI_API_KEY").get(null) as? String
        } catch (e: Exception) {
            null
        }

        if (!apiKey.isNullOrBlank()) {
            val geminiResult = callGemini(input, apiKey)
            if (geminiResult.isSuccess) {
                return@withContext geminiResult
            }
        }

        // Fallback rule-based parser for fast offline / local parsing
        val localParsed = parseRuleBased(input)
        if (localParsed != null) {
            Result.success(localParsed)
        } else {
            Result.failure(Exception("Could not understand input. Please include goat tag (e.g., G102) and action (weight, vaccine, deworming)."))
        }
    }

    private fun callGemini(input: String, apiKey: String): Result<ParsedFarmEntry> {
        val todayStr = dateFormat.format(Date())
        val systemPrompt = """
            You are a goat farm voice & text field-entry parser.
            Today's date is $todayStr.
            Given natural language input from a farmer, parse into JSON:
            Output MUST be valid JSON with this exact schema:
            {
              "type": "weight" | "vaccination" | "deworming" | "treatment" | "new_goat",
              "tag": "Goat Tag or ID e.g. G102",
              "weight_kg": 32.0 (number or null),
              "vaccine": "PPR" (or null),
              "medicine": "Albendazole" (or null),
              "dose": "1 ml" (or null),
              "date": "$todayStr" (YYYY-MM-DD),
              "next_due_date": "YYYY-MM-DD" (or null),
              "symptoms": "symptoms" (or null),
              "diagnosis": "diagnosis" (or null),
              "breed": "breed" (or null),
              "sex": "Doe" | "Buck" | "Kid" (or null),
              "notes": "notes" (or null)
            }
            Do not wrap in markdown quotes if possible, output pure JSON.
        """.trimIndent()

        val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash:generateContent?key=$apiKey"
        val requestBodyJson = JSONObject().apply {
            put("systemInstruction", JSONObject().apply {
                put("parts", JSONArray().put(JSONObject().put("text", systemPrompt)))
            })
            put("contents", JSONArray().put(JSONObject().apply {
                put("parts", JSONArray().put(JSONObject().put("text", input)))
            }))
            put("generationConfig", JSONObject().apply {
                put("responseMimeType", "application/json")
                put("temperature", 0.1)
            })
        }

        val request = Request.Builder()
            .url(url)
            .post(requestBodyJson.toString().toRequestBody(jsonMediaType))
            .build()

        return try {
            client.newCall(request).execute().use { response ->
                val body = response.body?.string() ?: ""
                if (response.isSuccessful) {
                    val root = JSONObject(body)
                    val text = root.getJSONArray("candidates")
                        .getJSONObject(0)
                        .getJSONObject("content")
                        .getJSONArray("parts")
                        .getJSONObject(0)
                        .getString("text")

                    val json = JSONObject(text.trim().removeSurrounding("```json", "```").trim())
                    val entry = parseJsonToEntry(json, todayStr)
                    if (entry != null) Result.success(entry) else Result.failure(Exception("Incomplete parsed data"))
                } else {
                    Result.failure(Exception("AI request failed with code ${response.code}"))
                }
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun parseJsonToEntry(json: JSONObject, todayStr: String): ParsedFarmEntry? {
        val type = json.optString("type").lowercase()
        val tag = json.optString("tag").ifBlank { "G101" }
        val date = json.optString("date").ifBlank { todayStr }
        val notes = json.optString("notes").ifBlank { null }

        return when (type) {
            "weight" -> {
                val weight = json.optDouble("weight_kg", 0.0)
                if (weight > 0) ParsedFarmEntry.Weight(tag, weight, date, "Scale", notes) else null
            }
            "vaccination" -> {
                val vaccine = json.optString("vaccine").ifBlank { "PPR" }
                val dose = json.optString("dose").ifBlank { "1 ml" }
                val nextDue = json.optString("next_due_date").ifBlank { null }
                ParsedFarmEntry.Vaccination(tag, vaccine, dose, date, nextDue, null, null, notes)
            }
            "deworming" -> {
                val medicine = json.optString("medicine").ifBlank { "Albendazole" }
                val dose = json.optString("dose").ifBlank { "5 ml" }
                val nextDue = json.optString("next_due_date").ifBlank { null }
                val weight = if (json.has("weight_kg") && !json.isNull("weight_kg")) json.optDouble("weight_kg") else null
                ParsedFarmEntry.Deworming(tag, medicine, dose, date, nextDue, weight, null, notes)
            }
            "treatment" -> {
                val symptoms = json.optString("symptoms").ifBlank { "Unspecified symptoms" }
                val diagnosis = json.optString("diagnosis").ifBlank { "General illness" }
                val med = json.optString("medicine").ifBlank { "Antibiotic" }
                val dose = json.optString("dose").ifBlank { "2 ml" }
                ParsedFarmEntry.Treatment(tag, symptoms, diagnosis, med, dose, date, notes)
            }
            "new_goat" -> {
                val name = json.optString("name", tag)
                val breed = json.optString("breed").ifBlank { "Boer" }
                val sex = json.optString("sex").ifBlank { "Doe" }
                val weight = if (json.has("weight_kg") && !json.isNull("weight_kg")) json.optDouble("weight_kg") else null
                ParsedFarmEntry.NewGoat(name, tag, breed, sex, weight, notes)
            }
            else -> null
        }
    }

    private fun parseRuleBased(input: String): ParsedFarmEntry? {
        val lower = input.lowercase()
        val todayStr = dateFormat.format(Date())

        // Extract Tag (e.g. G102, G-102, Tag 102, 102)
        val tagMatcher = Pattern.compile("(?i)(?:tag|goat)?\\s*([a-z]?\\d{2,5})").matcher(input)
        val tag = if (tagMatcher.find()) tagMatcher.group(1)!!.uppercase() else "G101"

        if (lower.contains("weigh") || lower.contains("kg") || lower.contains("kilo")) {
            val weightMatcher = Pattern.compile("(\\d+(?:\\.\\d+)?)\\s*(?:kg|kilos|kilo|kgs)").matcher(lower)
            val weight = if (weightMatcher.find()) {
                weightMatcher.group(1)!!.toDoubleOrNull() ?: 30.0
            } else {
                // Look for any number
                val numMatcher = Pattern.compile("\\b(\\d{2}(?:\\.\\d+)?)\\b").matcher(lower)
                if (numMatcher.find()) numMatcher.group(1)!!.toDoubleOrNull() ?: 30.0 else 30.0
            }
            return ParsedFarmEntry.Weight(tag = tag, weightKg = weight, date = todayStr, notes = input)
        }

        if (lower.contains("vaccin") || lower.contains("ppr") || lower.contains("et") || lower.contains("fmd")) {
            val vaccine = when {
                lower.contains("ppr") -> "PPR"
                lower.contains("fmd") -> "FMD"
                lower.contains("et") || lower.contains("enterotox") -> "Enterotoxaemia (ET)"
                lower.contains("pox") -> "Goat Pox"
                lower.contains("anthrax") -> "Anthrax"
                else -> "PPR"
            }
            // Check due date mentioned e.g. "in 6 months", "in 3 months", "next year"
            val nextDue = calculateFutureDate(lower)
            return ParsedFarmEntry.Vaccination(
                tag = tag,
                vaccine = vaccine,
                dose = "1 ml",
                administeredDate = todayStr,
                nextDueDate = nextDue,
                notes = input
            )
        }

        if (lower.contains("deworm") || lower.contains("worm") || lower.contains("albendazole") || lower.contains("ivermectin")) {
            val medicine = when {
                lower.contains("ivermectin") -> "Ivermectin"
                lower.contains("fenbendazole") -> "Fenbendazole"
                lower.contains("levamisole") -> "Levamisole"
                else -> "Albendazole"
            }
            val nextDue = calculateFutureDate(lower) ?: run {
                // Default deworming interval is 3 months
                val cal = Calendar.getInstance()
                cal.add(Calendar.MONTH, 3)
                dateFormat.format(cal.time)
            }
            return ParsedFarmEntry.Deworming(
                tag = tag,
                medicine = medicine,
                dose = "5 ml",
                treatmentDate = todayStr,
                nextDueDate = nextDue,
                notes = input
            )
        }

        if (lower.contains("treat") || lower.contains("sick") || lower.contains("fever") || lower.contains("cough") || lower.contains("wound")) {
            return ParsedFarmEntry.Treatment(
                tag = tag,
                symptoms = if (lower.contains("cough")) "Coughing" else if (lower.contains("fever")) "Fever" else "Unwell",
                diagnosis = "Respiratory/General",
                medicine = "Oxytetracycline",
                dose = "2 ml",
                startDate = todayStr,
                notes = input
            )
        }

        return null
    }

    private fun calculateFutureDate(lower: String): String? {
        val cal = Calendar.getInstance()
        return when {
            lower.contains("6 month") || lower.contains("six month") -> {
                cal.add(Calendar.MONTH, 6)
                dateFormat.format(cal.time)
            }
            lower.contains("3 month") || lower.contains("three month") -> {
                cal.add(Calendar.MONTH, 3)
                dateFormat.format(cal.time)
            }
            lower.contains("1 year") || lower.contains("one year") || lower.contains("annual") -> {
                cal.add(Calendar.YEAR, 1)
                dateFormat.format(cal.time)
            }
            lower.contains("1 month") || lower.contains("one month") -> {
                cal.add(Calendar.MONTH, 1)
                dateFormat.format(cal.time)
            }
            else -> null
        }
    }
}
