package com.example.ui.screens.health

import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.supabase.Goat
import com.example.data.supabase.GoatRepository
import com.example.data.supabase.VaccinationRecord
import com.example.notification.VaccinationReminderScheduler
import com.example.ui.components.DatePickerField
import com.example.ui.theme.FarmGreenDark
import com.example.ui.theme.FarmGreenPrimary
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

enum class VaccineDrugType(val displayName: String, val description: String) {
    INACTIVATED("Inactivated / Killed", "Non-replicating killed pathogens; often requires primary booster."),
    LIVE_ATTENUATED("Live Attenuated (MLV)", "Weakened live organism; triggers strong immune response."),
    TOXOID("Toxoid", "Inactivated toxin (e.g., Tetanus, Enterotoxaemia) inducing antitoxin."),
    RECOMBINANT("Recombinant / Subunit", "Purified viral or bacterial antigen components."),
    BACTERIN("Bacterin", "Killed bacterial culture offering targeted protective immunity.")
}

data class VaccinePreset(
    val name: String,
    val disease: String,
    val defaultDrugType: VaccineDrugType,
    val standardDose: String,
    val recommendedRoute: String,
    val boosterMonths: Int,
    val boosterDays: Int = 0
)

val STANDARD_GOAT_VACCINES = listOf(
    VaccinePreset(
        name = "PPR Live Vaccine",
        disease = "PPR (Goat Plague)",
        defaultDrugType = VaccineDrugType.LIVE_ATTENUATED,
        standardDose = "1 ml",
        recommendedRoute = "Subcutaneous (S/C)",
        boosterMonths = 36 // 3 years immunity
    ),
    VaccinePreset(
        name = "Enterotoxaemia (ET) Vaccine",
        disease = "Enterotoxaemia (Pulpy Kidney)",
        defaultDrugType = VaccineDrugType.TOXOID,
        standardDose = "2 ml",
        recommendedRoute = "Subcutaneous (S/C)",
        boosterMonths = 6 // Bi-annual booster
    ),
    VaccinePreset(
        name = "Goat Pox Vaccine",
        disease = "Goat Pox",
        defaultDrugType = VaccineDrugType.LIVE_ATTENUATED,
        standardDose = "1 ml",
        recommendedRoute = "Subcutaneous (S/C)",
        boosterMonths = 12 // Annual booster
    ),
    VaccinePreset(
        name = "CCPP Inactivated Vaccine",
        disease = "Contagious Caprine Pleuropneumonia",
        defaultDrugType = VaccineDrugType.INACTIVATED,
        standardDose = "1 ml",
        recommendedRoute = "Subcutaneous (S/C)",
        boosterMonths = 6
    ),
    VaccinePreset(
        name = "FMD Polyvalent Vaccine",
        disease = "Foot & Mouth Disease",
        defaultDrugType = VaccineDrugType.INACTIVATED,
        standardDose = "2 ml",
        recommendedRoute = "Deep Intramuscular (I/M)",
        boosterMonths = 6
    ),
    VaccinePreset(
        name = "Tetanus Toxoid (TT)",
        disease = "Tetanus (Lockjaw)",
        defaultDrugType = VaccineDrugType.TOXOID,
        standardDose = "1 ml",
        recommendedRoute = "Intramuscular (I/M)",
        boosterMonths = 0,
        boosterDays = 21 // 3 weeks primary booster
    ),
    VaccinePreset(
        name = "Anthrax Spore Vaccine",
        disease = "Anthrax",
        defaultDrugType = VaccineDrugType.LIVE_ATTENUATED,
        standardDose = "1 ml",
        recommendedRoute = "Subcutaneous (S/C)",
        boosterMonths = 12
    ),
    VaccinePreset(
        name = "HS Alum Precipitated",
        disease = "Haemorrhagic Septicaemia",
        defaultDrugType = VaccineDrugType.INACTIVATED,
        standardDose = "2 ml",
        recommendedRoute = "Subcutaneous (S/C)",
        boosterMonths = 12
    )
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VaccinationRecordDialog(
    goats: List<Goat>,
    initialGoatId: String? = null,
    today: String = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date()),
    onDismiss: () -> Unit,
    onSaveSuccess: () -> Unit,
    repository: GoatRepository
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val sdf = remember { SimpleDateFormat("yyyy-MM-dd", Locale.US) }

    val activeGoats = remember(goats) {
        goats.filter { !it.status_c.equals("Deceased", ignoreCase = true) }
    }

    // Target Selection
    var selectionMode by remember { mutableStateOf("INDIVIDUAL") } // INDIVIDUAL, MULTIPLE, ALL_HERD, DOES, KIDS
    var singleGoatId by remember { mutableStateOf(initialGoatId ?: activeGoats.firstOrNull()?.id ?: "") }
    var singleGoatExpanded by remember { mutableStateOf(false) }
    val multipleSelectedIds = remember { mutableStateListOf<String>().apply { if (initialGoatId != null) add(initialGoatId) } }

    // Preset Selection
    var selectedPreset by remember { mutableStateOf<VaccinePreset?>(STANDARD_GOAT_VACCINES.first()) }
    var isCustomVaccine by remember { mutableStateOf(false) }

    // Drug fields
    var vaccineName by remember { mutableStateOf(STANDARD_GOAT_VACCINES.first().name) }
    var diseaseName by remember { mutableStateOf(STANDARD_GOAT_VACCINES.first().disease) }
    var selectedDrugType by remember { mutableStateOf(STANDARD_GOAT_VACCINES.first().defaultDrugType) }
    var dose by remember { mutableStateOf(STANDARD_GOAT_VACCINES.first().standardDose) }
    var route by remember { mutableStateOf(STANDARD_GOAT_VACCINES.first().recommendedRoute) }
    var administeredDate by remember { mutableStateOf(today) }

    // Automated Booster Shot Reminder fields
    var enableBoosterReminder by remember { mutableStateOf(true) }
    var boosterIntervalPreset by remember { mutableStateOf("6 Months") } // 14 Days, 21 Days, 28 Days, 6 Months, 12 Months, Custom
    var boosterDueDate by remember {
        val cal = Calendar.getInstance()
        cal.add(Calendar.MONTH, 6)
        mutableStateOf(sdf.format(cal.time))
    }
    var reminderAdvanceDays by remember { mutableIntStateOf(7) } // 7 days before

    // Batch & Logistics fields
    var batchNumber by remember { mutableStateOf("") }
    var expiryDate by remember { mutableStateOf("") }
    var manufacturer by remember { mutableStateOf("") }
    var veterinarian by remember { mutableStateOf("") }
    var totalCostStr by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }

    // Helper to compute booster due date when administeredDate or interval changes
    fun recalculateBoosterDate(baseDateStr: String, interval: String) {
        try {
            val baseDate = sdf.parse(baseDateStr) ?: Date()
            val cal = Calendar.getInstance().apply { time = baseDate }
            when (interval) {
                "14 Days" -> cal.add(Calendar.DAY_OF_YEAR, 14)
                "21 Days" -> cal.add(Calendar.DAY_OF_YEAR, 21)
                "28 Days" -> cal.add(Calendar.DAY_OF_YEAR, 28)
                "6 Months" -> cal.add(Calendar.MONTH, 6)
                "12 Months" -> cal.add(Calendar.YEAR, 1)
                "36 Months" -> cal.add(Calendar.YEAR, 3)
            }
            boosterDueDate = sdf.format(cal.time)
        } catch (_: Exception) {}
    }

    val coveredGoats = remember(selectionMode, singleGoatId, multipleSelectedIds.toList(), activeGoats) {
        when (selectionMode) {
            "INDIVIDUAL" -> activeGoats.filter { it.id == singleGoatId }
            "MULTIPLE" -> activeGoats.filter { multipleSelectedIds.contains(it.id) }
            "ALL_HERD" -> activeGoats
            "DOES" -> activeGoats.filter { it.sex_c.equals("Doe", ignoreCase = true) }
            "BUCKS" -> activeGoats.filter { it.sex_c.equals("Buck", ignoreCase = true) }
            "KIDS" -> activeGoats.filter { it.sex_c.equals("Kid", ignoreCase = true) || it.tag_c.contains("K", ignoreCase = true) }
            else -> activeGoats.filter { it.id == singleGoatId }
        }
    }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = Color.White,
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.94f)
                .testTag("dialog_vaccination_record")
        ) {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Header
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(40.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFFE0F2FE)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Vaccines,
                                    contentDescription = null,
                                    tint = Color(0xFF0284C7),
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                            Column {
                                Text(
                                    text = "Log Vaccination Record",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 17.sp,
                                    color = Color(0xFF0F172A)
                                )
                                Text(
                                    text = "Log dates, drug types & set automated booster reminders",
                                    fontSize = 11.sp,
                                    color = Color(0xFF64748B)
                                )
                            }
                        }

                        IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
                            Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.Gray)
                        }
                    }
                }

                // 1. Target Animal Selection
                item {
                    Text(
                        text = "1. TARGET ANIMALS",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF475569)
                    )
                    Spacer(Modifier.height(4.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        listOf("INDIVIDUAL", "MULTIPLE", "ALL_HERD", "DOES", "KIDS").forEach { mode ->
                            FilterChip(
                                selected = selectionMode == mode,
                                onClick = { selectionMode = mode },
                                label = { Text(mode.replace("_", " "), fontSize = 10.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = Color(0xFF0284C7),
                                    selectedLabelColor = Color.White
                                )
                            )
                        }
                    }

                    if (selectionMode == "INDIVIDUAL") {
                        Spacer(Modifier.height(6.dp))
                        ExposedDropdownMenuBox(
                            expanded = singleGoatExpanded,
                            onExpandedChange = { singleGoatExpanded = !singleGoatExpanded }
                        ) {
                            val cur = activeGoats.find { it.id == singleGoatId }
                            OutlinedTextField(
                                value = if (cur != null) "${cur.tag_c} - ${cur.name} (${cur.sex_c})" else "Select Goat",
                                onValueChange = {},
                                readOnly = true,
                                label = { Text("Selected Goat *") },
                                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = singleGoatExpanded) },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .menuAnchor()
                            )
                            ExposedDropdownMenu(
                                expanded = singleGoatExpanded,
                                onDismissRequest = { singleGoatExpanded = false }
                            ) {
                                activeGoats.forEach { g ->
                                    DropdownMenuItem(
                                        text = { Text("${g.tag_c} - ${g.name} (${g.sex_c}, ${g.breed})") },
                                        onClick = {
                                            singleGoatId = g.id
                                            singleGoatExpanded = false
                                        }
                                    )
                                }
                            }
                        }
                    } else if (selectionMode == "MULTIPLE") {
                        Spacer(Modifier.height(6.dp))
                        Surface(
                            color = Color(0xFFF8FAFC),
                            shape = RoundedCornerShape(8.dp),
                            border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text(
                                    "Select Multi-Goat Cohort (${multipleSelectedIds.size} selected):",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                activeGoats.take(15).forEach { g ->
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clickable {
                                                if (multipleSelectedIds.contains(g.id)) multipleSelectedIds.remove(g.id)
                                                else multipleSelectedIds.add(g.id)
                                            },
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Checkbox(
                                            checked = multipleSelectedIds.contains(g.id),
                                            onCheckedChange = { chk ->
                                                if (chk) multipleSelectedIds.add(g.id)
                                                else multipleSelectedIds.remove(g.id)
                                            }
                                        )
                                        Text("${g.tag_c} - ${g.name} (${g.sex_c})", fontSize = 12.sp)
                                    }
                                }
                            }
                        }
                    }

                    Spacer(Modifier.height(4.dp))
                    Text(
                        "Target: ${coveredGoats.size} animal(s) will receive this vaccination record.",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Color(0xFF0369A1)
                    )
                }

                // 2. Standard Goat Vaccine Presets
                item {
                    Text(
                        text = "2. CHOOSE VACCINE PRESET OR CUSTOM",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF475569)
                    )
                    Spacer(Modifier.height(4.dp))
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        items(STANDARD_GOAT_VACCINES) { preset ->
                            val isSelected = !isCustomVaccine && selectedPreset?.name == preset.name
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = if (isSelected) Color(0xFFE0F2FE) else Color(0xFFF1F5F9),
                                border = BorderStroke(
                                    1.dp,
                                    if (isSelected) Color(0xFF0284C7) else Color(0xFFCBD5E1)
                                ),
                                modifier = Modifier.clickable {
                                    isCustomVaccine = false
                                    selectedPreset = preset
                                    vaccineName = preset.name
                                    diseaseName = preset.disease
                                    selectedDrugType = preset.defaultDrugType
                                    dose = preset.standardDose
                                    route = preset.recommendedRoute
                                    boosterIntervalPreset = if (preset.boosterMonths > 0) "${preset.boosterMonths} Months" else "${preset.boosterDays} Days"
                                    recalculateBoosterDate(administeredDate, boosterIntervalPreset)
                                }
                            ) {
                                Column(modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)) {
                                    Text(
                                        text = preset.disease,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 11.sp,
                                        color = if (isSelected) Color(0xFF0369A1) else Color(0xFF334155)
                                    )
                                    Text(
                                        text = preset.defaultDrugType.displayName.take(18),
                                        fontSize = 9.sp,
                                        color = Color.Gray
                                    )
                                }
                            }
                        }

                        item {
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = if (isCustomVaccine) Color(0xFFE0F2FE) else Color(0xFFF1F5F9),
                                border = BorderStroke(
                                    1.dp,
                                    if (isCustomVaccine) Color(0xFF0284C7) else Color(0xFFCBD5E1)
                                ),
                                modifier = Modifier.clickable {
                                    isCustomVaccine = true
                                    selectedPreset = null
                                }
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(12.dp))
                                    Spacer(Modifier.width(4.dp))
                                    Text("Custom Entry", fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                }
                            }
                        }
                    }
                }

                // 3. Drug Type Selection
                item {
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(
                            text = "3. DRUG TYPE / CLASSIFICATION *",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF475569)
                        )
                        Text(
                            text = "Specifies formulation technology & biological immune mechanism",
                            fontSize = 10.sp,
                            color = Color.Gray
                        )
                        Spacer(Modifier.height(4.dp))

                        // Drug type buttons
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            VaccineDrugType.values().forEach { drugType ->
                                val isSelected = selectedDrugType == drugType
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = if (isSelected) Color(0xFFF0FDF4) else Color(0xFFF8FAFC),
                                    border = BorderStroke(
                                        1.dp,
                                        if (isSelected) Color(0xFF16A34A) else Color(0xFFE2E8F0)
                                    ),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { selectedDrugType = drugType }
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        RadioButton(
                                            selected = isSelected,
                                            onClick = { selectedDrugType = drugType },
                                            colors = RadioButtonDefaults.colors(selectedColor = Color(0xFF16A34A))
                                        )
                                        Spacer(Modifier.width(6.dp))
                                        Column {
                                            Text(
                                                text = drugType.displayName,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 12.sp,
                                                color = if (isSelected) Color(0xFF15803D) else Color(0xFF1E293B)
                                            )
                                            Text(
                                                text = drugType.description,
                                                fontSize = 10.sp,
                                                color = Color(0xFF64748B)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // 4. Vaccination Details (Date, Drug Product, Dose, Route)
                item {
                    Text(
                        text = "4. VACCINATION DETAILS",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF475569)
                    )
                    Spacer(Modifier.height(4.dp))

                    DatePickerField(
                        dateValue = administeredDate,
                        onDateSelected = { newDate ->
                            administeredDate = newDate
                            recalculateBoosterDate(newDate, boosterIntervalPreset)
                        },
                        label = "Vaccination Administration Date *"
                    )

                    Spacer(Modifier.height(8.dp))

                    OutlinedTextField(
                        value = vaccineName,
                        onValueChange = { vaccineName = it },
                        label = { Text("Vaccine Product / Brand Name *") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_vaccine_name")
                    )

                    Spacer(Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = diseaseName,
                            onValueChange = { diseaseName = it },
                            label = { Text("Target Disease *") },
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = dose,
                            onValueChange = { dose = it },
                            label = { Text("Dose & Route *") },
                            placeholder = { Text("e.g. 1 ml S/C") },
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Spacer(Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = batchNumber,
                            onValueChange = { batchNumber = it },
                            label = { Text("Batch / Lot #") },
                            placeholder = { Text("e.g. ET24A09") },
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = expiryDate,
                            onValueChange = { expiryDate = it },
                            label = { Text("Expiry (YYYY-MM)") },
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Spacer(Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = manufacturer,
                            onValueChange = { manufacturer = it },
                            label = { Text("Manufacturer") },
                            placeholder = { Text("e.g. Indian Immunologicals") },
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = veterinarian,
                            onValueChange = { veterinarian = it },
                            label = { Text("Administered By") },
                            placeholder = { Text("Dr. / Staff") },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                // 5. Automated Reminder for Booster Shots
                item {
                    Surface(
                        color = Color(0xFFF0FDF4),
                        shape = RoundedCornerShape(14.dp),
                        border = BorderStroke(1.dp, Color(0xFFBBF7D0)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.NotificationsActive,
                                        contentDescription = null,
                                        tint = Color(0xFF15803D),
                                        modifier = Modifier.size(22.dp)
                                    )
                                    Column {
                                        Text(
                                            text = "Automated Booster Shot Reminders",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 13.sp,
                                            color = Color(0xFF14532D)
                                        )
                                        Text(
                                            text = "Triggers Android local notification & alerts",
                                            fontSize = 10.sp,
                                            color = Color(0xFF166534)
                                        )
                                    }
                                }

                                Switch(
                                    checked = enableBoosterReminder,
                                    onCheckedChange = { enableBoosterReminder = it },
                                    colors = SwitchDefaults.colors(
                                        checkedThumbColor = Color.White,
                                        checkedTrackColor = Color(0xFF16A34A)
                                    ),
                                    modifier = Modifier.testTag("switch_booster_reminder")
                                )
                            }

                            if (enableBoosterReminder) {
                                Text(
                                    text = "Booster Schedule Interval:",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = Color(0xFF15803D)
                                )

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    listOf("14 Days", "21 Days", "6 Months", "12 Months", "36 Months").forEach { interval ->
                                        FilterChip(
                                            selected = boosterIntervalPreset == interval,
                                            onClick = {
                                                boosterIntervalPreset = interval
                                                recalculateBoosterDate(administeredDate, interval)
                                            },
                                            label = { Text(interval, fontSize = 10.sp) },
                                            colors = FilterChipDefaults.filterChipColors(
                                                selectedContainerColor = Color(0xFF16A34A),
                                                selectedLabelColor = Color.White
                                            )
                                        )
                                    }
                                }

                                DatePickerField(
                                    dateValue = boosterDueDate,
                                    onDateSelected = { newBoosterDate ->
                                        boosterDueDate = newBoosterDate
                                        boosterIntervalPreset = "Custom"
                                    },
                                    label = "Booster Shot Due Date *"
                                )

                                Surface(
                                    color = Color(0xFFDCFCE7),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier.padding(8.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Event,
                                            contentDescription = null,
                                            tint = Color(0xFF15803D),
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Spacer(Modifier.width(6.dp))
                                        Text(
                                            text = "Next booster scheduled for $boosterDueDate. Daily background worker will notify you 7 days before and on due date.",
                                            fontSize = 11.sp,
                                            color = Color(0xFF14532D)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                // 6. Cost & Clinical Notes
                item {
                    Text(
                        text = "6. COSTS & CLINICAL OBSERVATIONS",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF475569)
                    )
                    Spacer(Modifier.height(4.dp))

                    OutlinedTextField(
                        value = totalCostStr,
                        onValueChange = { totalCostStr = it },
                        label = { Text("Total Vaccination Cost (₹ optional)") },
                        placeholder = { Text("e.g. 350") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(Modifier.height(8.dp))

                    OutlinedTextField(
                        value = notes,
                        onValueChange = { notes = it },
                        label = { Text("Clinical Notes / Adverse Reaction Observations") },
                        placeholder = { Text("e.g. Normal injection site, no swelling after 30 mins.") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                // Actions: Cancel & Save
                item {
                    Spacer(Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        TextButton(onClick = onDismiss) {
                            Text("Cancel", color = Color.Gray)
                        }
                        Spacer(Modifier.width(8.dp))
                        Button(
                            onClick = {
                                if (coveredGoats.isEmpty()) {
                                    Toast.makeText(context, "Please select at least 1 goat", Toast.LENGTH_SHORT).show()
                                    return@Button
                                }
                                if (vaccineName.isBlank()) {
                                    Toast.makeText(context, "Please enter vaccine name", Toast.LENGTH_SHORT).show()
                                    return@Button
                                }

                                coroutineScope.launch {
                                    val nextDue = if (enableBoosterReminder) boosterDueDate.ifBlank { null } else null

                                    val records = coveredGoats.map { goat ->
                                        val combinedNotes = buildString {
                                            append("Drug Type: ${selectedDrugType.displayName}")
                                            if (enableBoosterReminder) {
                                                append(" | Booster Reminder: Auto-Scheduled ($boosterDueDate)")
                                            }
                                            if (batchNumber.isNotBlank()) append(" | Batch: $batchNumber")
                                            if (manufacturer.isNotBlank()) append(" | Mfg: $manufacturer")
                                            if (expiryDate.isNotBlank()) append(" | Exp: $expiryDate")
                                            if (notes.isNotBlank()) append(" | Note: $notes")
                                        }

                                        VaccinationRecord(
                                            goat_id_c = goat.id,
                                            vaccine_c = vaccineName.trim(),
                                            dose_c = "$dose ($route)".trim(),
                                            administered_date_c = administeredDate,
                                            next_due_date_c = nextDue,
                                            batch_number_c = batchNumber.ifBlank { null },
                                            administered_by_c = veterinarian.ifBlank { null },
                                            notes_c = combinedNotes
                                        )
                                    }

                                    val cost = totalCostStr.toDoubleOrNull()
                                    val res = repository.recordVaccinationsForGoats(
                                        records = records,
                                        totalCost = cost,
                                        diseaseOrVaccine = diseaseName.ifBlank { vaccineName }
                                    )

                                    if (res.isSuccess) {
                                        if (enableBoosterReminder) {
                                            // Ensure automated reminder notification worker is scheduled and triggers immediate evaluation
                                            try {
                                                repository.saveFarmSetting("vaccination_notifications_enabled", "true")
                                                VaccinationReminderScheduler.scheduleDaily(context)
                                                VaccinationReminderScheduler.triggerImmediateCheck(context)
                                            } catch (_: Exception) {}
                                        }

                                        Toast.makeText(
                                            context,
                                            "Logged vaccination for ${records.size} goat(s)${if (enableBoosterReminder) " & booster reminder armed!" else "!"}",
                                            Toast.LENGTH_LONG
                                        ).show()
                                        onSaveSuccess()
                                    } else {
                                        Toast.makeText(
                                            context,
                                            "Error saving: ${res.exceptionOrNull()?.message}",
                                            Toast.LENGTH_SHORT
                                        ).show()
                                    }
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7)),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.testTag("btn_save_vaccination_record")
                        ) {
                            Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(6.dp))
                            Text(
                                "Save Record (${coveredGoats.size} Goats)",
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }
}
