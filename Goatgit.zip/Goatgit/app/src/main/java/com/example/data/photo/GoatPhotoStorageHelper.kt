package com.example.data.photo

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import androidx.core.content.FileProvider
import android.media.ExifInterface
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Utility for capturing, compressing, storing, and managing photos of goats
 * in the device's persistent app-specific storage.
 */
object GoatPhotoStorageHelper {

    private const val PHOTO_DIR_NAME = "goat_photos"

    /**
     * Get or create the local persistent directory where goat photos are saved.
     */
    fun getGoatPhotosDir(context: Context): File {
        val dir = File(context.filesDir, PHOTO_DIR_NAME)
        if (!dir.exists()) {
            dir.mkdirs()
        }
        return dir
    }

    /**
     * Create a new file ready for camera output, named with timestamp and goat tag/ID.
     */
    fun createCameraOutputFile(context: Context, goatId: String = "general"): File {
        val dir = getGoatPhotosDir(context)
        val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val sanitizedId = goatId.replace("[^a-zA-Z0-9_-]".toRegex(), "_").take(20)
        return File(dir, "goat_${sanitizedId}_${timeStamp}.jpg")
    }

    /**
     * Get a content URI for camera output using Android FileProvider.
     */
    fun getFileUri(context: Context, file: File): Uri {
        return FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file
        )
    }

    /**
     * Copy an external or temporary image Uri into the app's persistent storage,
     * maintaining correct EXIF rotation and resizing if exceedingly large.
     */
    fun saveImageUriToPermanentStorage(
        context: Context,
        sourceUri: Uri,
        goatId: String = "general"
    ): File? {
        return try {
            val destinationFile = createCameraOutputFile(context, goatId)
            context.contentResolver.openInputStream(sourceUri)?.use { input ->
                destinationFile.outputStream().use { output ->
                    input.copyTo(output)
                }
            }
            normalizeImageOrientation(destinationFile)
            destinationFile
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    /**
     * Save a bitmap directly to persistent storage.
     */
    fun saveBitmapToStorage(
        context: Context,
        bitmap: Bitmap,
        goatId: String = "general"
    ): File? {
        return try {
            val file = createCameraOutputFile(context, goatId)
            FileOutputStream(file).use { out ->
                bitmap.compress(Bitmap.CompressFormat.JPEG, 88, out)
            }
            file
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    /**
     * Ensures image is saved right-side up based on EXIF metadata.
     */
    private fun normalizeImageOrientation(file: File) {
        try {
            val exif = ExifInterface(file.absolutePath)
            val orientation = exif.getAttributeInt(
                ExifInterface.TAG_ORIENTATION,
                ExifInterface.ORIENTATION_NORMAL
            )

            val rotationAngle = when (orientation) {
                ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                else -> 0f
            }

            if (rotationAngle != 0f) {
                val bitmap = BitmapFactory.decodeFile(file.absolutePath) ?: return
                val matrix = Matrix().apply { postRotate(rotationAngle) }
                val rotatedBitmap = Bitmap.createBitmap(
                    bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true
                )
                FileOutputStream(file).use { out ->
                    rotatedBitmap.compress(Bitmap.CompressFormat.JPEG, 90, out)
                }
                bitmap.recycle()
                rotatedBitmap.recycle()
            }
        } catch (e: Exception) {
            // Non-critical, ignore orientation fix error
        }
    }

    /**
     * Delete an existing goat photo file if it exists.
     */
    fun deletePhotoFile(filePathOrUri: String) {
        try {
            val path = if (filePathOrUri.startsWith("file://")) {
                filePathOrUri.removePrefix("file://")
            } else {
                filePathOrUri
            }
            val file = File(path)
            if (file.exists()) {
                file.delete()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}
