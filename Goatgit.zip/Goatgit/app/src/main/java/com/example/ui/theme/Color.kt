package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Farm Fresh Green & Warm Earth Palette
val FarmGreenPrimary = Color(0xFF2D6A4F)
val FarmGreenDark = Color(0xFF1B4332)
val FarmGreenLight = Color(0xFF52B788)
val FarmGreenContainer = Color(0xFFD8F3DC)
val FarmOnGreenContainer = Color(0xFF081C15)

val FarmAmber = Color(0xFFD4A373)
val FarmAmberDark = Color(0xFFB45309)
val FarmAmberContainer = Color(0xFFFAEDCD)
val FarmBrown = Color(0xFF7F4F24)

val FarmSurfaceLight = Color(0xFFFBFBFA)
val FarmBackgroundLight = Color(0xFFF3F4F1)
val FarmCardLight = Color(0xFFFFFFFF)

val FarmSurfaceDark = Color(0xFF161B18)
val FarmBackgroundDark = Color(0xFF0F1411)
val FarmCardDark = Color(0xFF1F2622)

val FarmError = Color(0xFFBA1A1A)
val FarmErrorContainer = Color(0xFFFFDAD6)
val FarmSuccess = Color(0xFF2E7D32)
val FarmSuccessContainer = Color(0xFFC8E6C9)
val FarmWarning = Color(0xFFE65100)
val FarmWarningContainer = Color(0xFFFFE0B2)

val TextPrimaryLight = Color(0xFF1A1C19)
val TextSecondaryLight = Color(0xFF535F52)
val TextPrimaryDark = Color(0xFFE1E3DE)
val TextSecondaryDark = Color(0xFF889387)

