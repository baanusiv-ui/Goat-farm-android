package com.example.data.payment

import android.content.Context
import android.database.Cursor
import android.net.Uri
import android.provider.Telephony
import com.example.data.offline.AppDatabase
import com.example.data.offline.SmsPaymentCandidateEntity
import com.example.data.supabase.CustomerRecord
import com.example.data.supabase.SaleRecord
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.Locale
import java.util.UUID
import java.util.regex.Pattern

data class SmsPaymentCandidate(
    val id: String = UUID.randomUUID().toString(),
    val amount: Double,
    val referenceNumber: String? = null,
    val upiId: String? = null,
    val sender: String = "",
    val snippet: String = "",
    val timestamp: Long = System.currentTimeMillis(),
    val status: String = "PENDING", // PENDING, MATCHED, IGNORED
    val matchedSaleId: String? = null,
    val suggestedSale: SaleRecord? = null,
    val matchReason: String? = null
)

class SmsReconciliationManager(
    private val context: Context,
    private val database: AppDatabase
) {
    private val dao = database.smsReconciliationDao()

    /**
     * Check if a message is an INCOMING payment confirmation (credit/received).
     * Strictly filters out debits, withdrawals, balance alerts, and personal messages.
     */
    fun isPaymentReceivedSms(body: String): Boolean {
        val lower = body.lowercase(Locale.ROOT)
        // Must contain credit/receipt indicators
        val hasCreditKeyword = lower.contains("credited") ||
                lower.contains("received") ||
                lower.contains("deposited") ||
                lower.contains("cr to a/c") ||
                lower.contains("credit to") ||
                lower.contains("payment of rs") ||
                lower.contains("received rs") ||
                lower.contains("received inr") ||
                lower.contains("payment received")

        // Reject debit/spent alerts
        val hasDebitKeyword = lower.contains("debited") ||
                lower.contains("withdrawn") ||
                lower.contains("spent") ||
                lower.contains("paid to") ||
                lower.contains("sent rs")

        if (hasDebitKeyword && !lower.contains("credited")) return false

        return hasCreditKeyword
    }

    /**
     * Extract amount, reference, and UPI ID from the SMS text safely.
     */
    fun parsePaymentSms(sender: String, body: String, timestamp: Long): SmsPaymentCandidate? {
        if (!isPaymentReceivedSms(body)) return null

        // 1. Extract Amount: supports ₹, Rs, Rs., INR
        val amountRegex = Pattern.compile(
            """(?:rs\.?|inr|₹)\s*([0-9,]+(?:\.[0-9]{1,2})?)""",
            Pattern.CASE_INSENSITIVE
        )
        val matcher = amountRegex.matcher(body)
        var amount: Double? = null
        if (matcher.find()) {
            val numStr = matcher.group(1)?.replace(",", "")
            amount = numStr?.toDoubleOrNull()
        }

        // Secondary amount fallback (e.g., "5000.00 credited")
        if (amount == null) {
            val secondaryRegex = Pattern.compile(
                """([0-9,]+(?:\.[0-9]{1,2})?)\s*(?:is credited|has been credited|credited)""",
                Pattern.CASE_INSENSITIVE
            )
            val secMatcher = secondaryRegex.matcher(body)
            if (secMatcher.find()) {
                val numStr = secMatcher.group(1)?.replace(",", "")
                amount = numStr?.toDoubleOrNull()
            }
        }

        if (amount == null || amount <= 0.0) return null

        // 2. Extract Reference / UTR / Txn ID
        var refNumber: String? = null
        val refRegex = Pattern.compile(
            """(?:ref(?:\s*no\.?|\s*num)?|utr|txn(?:\s*id)?|rrn|order)\s*[:#-]?\s*([A-Za-z0-9]{6,25})""",
            Pattern.CASE_INSENSITIVE
        )
        val refMatcher = refRegex.matcher(body)
        if (refMatcher.find()) {
            refNumber = refMatcher.group(1)
        }

        // 3. Extract UPI ID if present
        var upiId: String? = null
        val upiRegex = Pattern.compile(
            """\b([a-zA-Z0-9.\-_]{2,50}@[a-zA-Z]{2,30})\b"""
        )
        val upiMatcher = upiRegex.matcher(body)
        if (upiMatcher.find()) {
            upiId = upiMatcher.group(1)
        }

        // Create clean snippet (privacy friendly: no sensitive personal text stored)
        val cleanSnippet = "Payment of ₹$amount from $sender" +
                if (!refNumber.isNullOrBlank()) " (Ref: $refNumber)" else ""

        return SmsPaymentCandidate(
            id = UUID.randomUUID().toString(),
            amount = amount,
            referenceNumber = refNumber,
            upiId = upiId,
            sender = sender.take(20),
            snippet = cleanSnippet,
            timestamp = timestamp,
            status = "PENDING"
        )
    }

    /**
     * Scan device SMS inbox for recent payment confirmations with explicit user permission.
     * Complies with Android & Play Store policy: does NOT upload raw SMS, stores only candidate amounts.
     */
    suspend fun scanInboxForPayments(
        activeSales: List<SaleRecord>,
        customers: List<CustomerRecord> = emptyList()
    ): List<SmsPaymentCandidate> = withContext(Dispatchers.IO) {
        val candidates = mutableListOf<SmsPaymentCandidate>()
        val existingCandidates = dao.getAllCandidates().associateBy { it.referenceNumber ?: "${it.amount}_${it.timestamp}" }

        try {
            val uri: Uri = Telephony.Sms.Inbox.CONTENT_URI
            val projection = arrayOf(
                Telephony.Sms._ID,
                Telephony.Sms.ADDRESS,
                Telephony.Sms.BODY,
                Telephony.Sms.DATE
            )

            // Look back up to 7 days
            val sevenDaysAgo = System.currentTimeMillis() - (7L * 24 * 60 * 60 * 1000)
            val selection = "${Telephony.Sms.DATE} >= ?"
            val selectionArgs = arrayOf(sevenDaysAgo.toString())
            val sortOrder = "${Telephony.Sms.DATE} DESC"

            val cursor: Cursor? = context.contentResolver.query(
                uri,
                projection,
                selection,
                selectionArgs,
                sortOrder
            )

            cursor?.use { c ->
                val addressIdx = c.getColumnIndex(Telephony.Sms.ADDRESS)
                val bodyIdx = c.getColumnIndex(Telephony.Sms.BODY)
                val dateIdx = c.getColumnIndex(Telephony.Sms.DATE)

                var count = 0
                while (c.moveToNext() && count < 60) {
                    val address = if (addressIdx != -1) c.getString(addressIdx) ?: "" else ""
                    val body = if (bodyIdx != -1) c.getString(bodyIdx) ?: "" else ""
                    val date = if (dateIdx != -1) c.getLong(dateIdx) else System.currentTimeMillis()

                    val parsed = parsePaymentSms(address, body, date)
                    if (parsed != null) {
                        val key = parsed.referenceNumber ?: "${parsed.amount}_${parsed.timestamp}"
                        if (!existingCandidates.containsKey(key)) {
                            // Match against sales
                            val (suggestedSale, reason) = findMatchForCandidate(parsed, activeSales, customers)
                            val enriched = parsed.copy(
                                suggestedSale = suggestedSale,
                                matchReason = reason,
                                matchedSaleId = suggestedSale?.id
                            )
                            candidates.add(enriched)

                            // Save to local database
                            dao.insertCandidate(
                                SmsPaymentCandidateEntity(
                                    id = enriched.id,
                                    amount = enriched.amount,
                                    referenceNumber = enriched.referenceNumber,
                                    upiId = enriched.upiId,
                                    sender = enriched.sender,
                                    rawSnippet = enriched.snippet,
                                    timestamp = enriched.timestamp,
                                    matchedSaleId = suggestedSale?.id,
                                    status = "PENDING"
                                )
                            )
                        }
                    }
                    count++
                }
            }
        } catch (_: Exception) {
            // Permission not granted or reading failed
        }

        // Return all pending candidates from DB with matched sales
        val allStored = dao.getAllCandidates()
        allStored.filter { it.status == "PENDING" }.map { entity ->
            val match = activeSales.find { it.id == entity.matchedSaleId }
            SmsPaymentCandidate(
                id = entity.id,
                amount = entity.amount,
                referenceNumber = entity.referenceNumber,
                upiId = entity.upiId,
                sender = entity.sender,
                snippet = entity.rawSnippet,
                timestamp = entity.timestamp,
                status = entity.status,
                matchedSaleId = entity.matchedSaleId,
                suggestedSale = match,
                matchReason = if (match != null) "Matches sale #${match.id.take(6)} balance of ₹${match.balance_due_c}" else null
            )
        }
    }

    /**
     * Smart Match Engine:
     * 1. Existing pending Paytm transaction (order ID or txn ID)
     * 2. Existing UPI payment reference
     * 3. Customer phone number in message
     * 4. Customer name in message
     * 5. Exact outstanding balance amount
     */
    fun findMatchForCandidate(
        candidate: SmsPaymentCandidate,
        sales: List<SaleRecord>,
        customers: List<CustomerRecord>
    ): Pair<SaleRecord?, String?> {
        // 1. Pending Paytm transaction
        if (!candidate.referenceNumber.isNullOrBlank()) {
            val paytmMatch = sales.find { sale ->
                sale.payment_mode_c == PaymentMethod.PAYTM_GATEWAY &&
                        (sale.order_id_c?.equals(candidate.referenceNumber, ignoreCase = true) == true ||
                                sale.transaction_id_c?.equals(candidate.referenceNumber, ignoreCase = true) == true)
            }
            if (paytmMatch != null) {
                return Pair(paytmMatch, "Matched Paytm Order ID / Txn ID: ${candidate.referenceNumber}")
            }
        }

        // 2. Pending UPI payment reference
        if (!candidate.referenceNumber.isNullOrBlank()) {
            val upiMatch = sales.find { sale ->
                sale.payment_mode_c == PaymentMethod.UPI_QR &&
                        sale.payment_status_c == PaymentStatus.PENDING &&
                        (sale.reference_c?.equals(candidate.referenceNumber, ignoreCase = true) == true ||
                                sale.transaction_id_c?.equals(candidate.referenceNumber, ignoreCase = true) == true)
            }
            if (upiMatch != null) {
                return Pair(upiMatch, "Matched UPI Reference Number: ${candidate.referenceNumber}")
            }
        }

        // 3. Exact outstanding credit balance or pending sale amount
        // Prioritize unpaid/partially paid credit sales or pending UPI sales
        val pendingOrCreditSales = sales.filter {
            it.payment_status_c != PaymentStatus.PAID &&
                    (it.balance_due_c == candidate.amount || it.amount_c == candidate.amount)
        }

        if (pendingOrCreditSales.size == 1) {
            val matched = pendingOrCreditSales.first()
            val reason = if (matched.balance_due_c > 0) {
                "Exact match to credit balance of ₹${matched.balance_due_c} for ${matched.buyer_name_c}"
            } else {
                "Exact match to sale amount of ₹${matched.amount_c} for ${matched.buyer_name_c}"
            }
            return Pair(matched, reason)
        }

        // If multiple, try to filter by customer
        if (pendingOrCreditSales.isNotEmpty()) {
            val matched = pendingOrCreditSales.first()
            return Pair(matched, "Matches outstanding balance of ₹${candidate.amount}")
        }

        return Pair(null, null)
    }

    suspend fun markCandidateMatched(candidateId: String, saleId: String) = withContext(Dispatchers.IO) {
        dao.updateCandidateStatus(candidateId, "MATCHED", saleId)
    }

    suspend fun markCandidateIgnored(candidateId: String) = withContext(Dispatchers.IO) {
        dao.updateCandidateStatus(candidateId, "IGNORED", null)
    }

    suspend fun deleteCandidate(candidateId: String) = withContext(Dispatchers.IO) {
        dao.deleteCandidate(candidateId)
    }
}
