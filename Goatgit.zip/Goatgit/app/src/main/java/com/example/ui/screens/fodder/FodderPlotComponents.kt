package com.example.ui.screens.fodder

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.core.content.ContextCompat
import com.example.data.offline.FodderActivityEntity
import com.example.data.offline.FodderCuttingEntity
import com.example.data.offline.FodderPlotEntity
import com.example.data.offline.FodderRowEntity
import com.example.data.offline.FodderSpeciesEntity
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.TimeUnit

@Composable
fun FodderPlotCard(
    plot: FodderPlotEntity,
    rows: List<FodderRowEntity> = emptyList(),
    onRecordCutting: () -> Unit,
    onViewLayout: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    val now = System.currentTimeMillis()
    val dateFormat = remember { SimpleDateFormat("yyyy-MM-dd", Locale.US) }

    val daysSinceLastCut = remember(plot.last_cut_date) {
        plot.last_cut_date?.let {
            try {
                val d = dateFormat.parse(it)
                if (d != null) TimeUnit.MILLISECONDS.toDays(now - d.time).toInt() else null
            } catch (_: Exception) { null }
        }
    }

    val daysUntilNextCut = remember(plot.next_expected_cut_date) {
        plot.next_expected_cut_date?.let {
            try {
                val d = dateFormat.parse(it)
                if (d != null) TimeUnit.MILLISECONDS.toDays(d.time - now).toInt() else null
            } catch (_: Exception) { null }
        }
    }

    val regrowthProgressPct = remember(plot.crop_cycle_status, daysSinceLastCut) {
        when {
            plot.crop_cycle_status.contains("Ready", ignoreCase = true) || plot.crop_cycle_status.contains("Due", ignoreCase = true) -> 100
            daysSinceLastCut != null -> ((daysSinceLastCut.toFloat() / 42f) * 100f).toInt().coerceIn(0, 100)
            else -> 40
        }
    }

    val totalRowLength = plot.row_count * plot.row_length
    val harvestedCount = rows.count { it.status == "Harvested" }
    val remainingCount = plot.row_count - harvestedCount

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("plot_card_${plot.id}")
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Header Row: Plot Name & Status Chip
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = plot.plot_name,
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.titleMedium,
                            color = FarmGreenDark
                        )
                        if (!plot.variety.isNullOrBlank()) {
                            Spacer(modifier = Modifier.width(6.dp))
                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = FarmGreenContainer
                            ) {
                                Text(
                                    text = plot.variety,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = FarmGreenDark,
                                    modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp)
                                )
                            }
                        }
                    }
                    Text(
                        text = "${plot.area_value} ${plot.area_unit} • ${plot.species_name}",
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.SemiBold,
                        color = Color.DarkGray
                    )
                }

                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = when {
                        plot.crop_cycle_status.contains("Ready", ignoreCase = true) || plot.crop_cycle_status.contains("Due", ignoreCase = true) -> FarmGreenContainer
                        plot.crop_cycle_status.contains("Partial", ignoreCase = true) -> Color(0xFFFFF3E0)
                        plot.crop_cycle_status.contains("Regrowth", ignoreCase = true) -> Color(0xFFE1F5FE)
                        plot.crop_cycle_status.contains("Sown", ignoreCase = true) -> FarmAmberContainer
                        else -> Color(0xFFF5F5F5)
                    }
                ) {
                    Text(
                        text = plot.crop_cycle_status,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = when {
                            plot.crop_cycle_status.contains("Ready", ignoreCase = true) || plot.crop_cycle_status.contains("Due", ignoreCase = true) -> FarmGreenDark
                            plot.crop_cycle_status.contains("Partial", ignoreCase = true) -> FarmBrown
                            plot.crop_cycle_status.contains("Regrowth", ignoreCase = true) -> Color(0xFF0277BD)
                            plot.crop_cycle_status.contains("Sown", ignoreCase = true) -> FarmBrown
                            else -> Color.DarkGray
                        },
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // FIELD ROW MASTER METRICS STRIP
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = Color(0xFFF9FBF9),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 10.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Rows", fontSize = 10.sp, color = Color.Gray)
                        Text("${plot.row_count}", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = FarmGreenDark)
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Row Length", fontSize = 10.sp, color = Color.Gray)
                        Text("${plot.row_length} ${plot.row_length_unit.take(1)}", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color.DarkGray)
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Total Length", fontSize = 10.sp, color = Color.Gray)
                        Text("${totalRowLength.toInt()} ${plot.row_length_unit.take(1)}", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = FarmGreenDark)
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Spacing", fontSize = 10.sp, color = Color.Gray)
                        Text("${plot.row_spacing} ${plot.row_spacing_unit.take(1)}", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color.DarkGray)
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Cultivated", fontSize = 10.sp, color = Color.Gray)
                        Text("${plot.calculated_cultivated_area.toInt()} ${plot.calculated_area_unit}", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color(0xFF0277BD))
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Row Harvest Progress (e.g. 5 of 40 harvested)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Row Status: $harvestedCount harvested • $remainingCount remaining",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = if (harvestedCount > 0) FarmSuccess else Color.DarkGray
                )
                Text(
                    text = when {
                        daysUntilNextCut != null && daysUntilNextCut > 0 -> "Cut in ~$daysUntilNextCut d"
                        daysUntilNextCut != null && daysUntilNextCut <= 0 -> "Due now!"
                        else -> "Growing"
                    },
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (daysUntilNextCut != null && daysUntilNextCut <= 0) FarmWarning else Color.Gray
                )
            }

            LinearProgressIndicator(
                progress = { (regrowthProgressPct / 100f).coerceIn(0f, 1f) },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(6.dp)
                    .padding(top = 4.dp)
                    .clip(RoundedCornerShape(3.dp)),
                color = if (regrowthProgressPct >= 90) FarmSuccess else Color(0xFF26A69A),
                trackColor = Color(0xFFE0E0E0)
            )

            // GPS & Dates Info
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = Color(0xFFFAFAFA),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp)
            ) {
                Column(modifier = Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("• Sown: ${plot.sowing_date}", fontSize = 11.sp, color = Color.Gray)
                        Text("• Cuts Done: ${plot.current_cut_count}", fontSize = 11.sp, color = Color.DarkGray)
                        Text("• Last Cut: ${plot.last_cut_date ?: "None"}", fontSize = 11.sp, color = Color.Gray)
                    }

                    if (plot.latitude != null && plot.longitude != null) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(top = 2.dp)
                        ) {
                            Icon(Icons.Default.Place, contentDescription = null, tint = FarmAmber, modifier = Modifier.size(13.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "GPS: ${String.format(Locale.US, "%.4f, %.4f", plot.latitude, plot.longitude)}${if (plot.gps_accuracy != null) " (±${plot.gps_accuracy.toInt()}m)" else ""}${if (!plot.location_tag.isNullOrBlank()) " • ${plot.location_tag}" else ""}",
                                fontSize = 10.sp,
                                color = Color.Gray
                            )
                        }
                    }
                }
            }

            // Action Buttons
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedButton(
                    onClick = onViewLayout,
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                    modifier = Modifier.testTag("view_layout_btn_${plot.id}")
                ) {
                    Icon(Icons.Default.GridOn, contentDescription = null, modifier = Modifier.size(15.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Field Layout (${plot.row_count} Rows)", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }

                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    Button(
                        onClick = onRecordCutting,
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = FarmGreenDark),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                        modifier = Modifier.testTag("cut_plot_${plot.id}")
                    ) {
                        Icon(Icons.Default.ContentCut, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Harvest", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }

                    IconButton(
                        onClick = onEdit,
                        modifier = Modifier.size(32.dp).testTag("edit_plot_${plot.id}")
                    ) {
                        Icon(Icons.Default.Edit, contentDescription = "Edit", tint = Color.Gray, modifier = Modifier.size(16.dp))
                    }

                    IconButton(
                        onClick = onDelete,
                        modifier = Modifier.size(32.dp).testTag("delete_plot_${plot.id}")
                    ) {
                        Icon(Icons.Default.Delete, contentDescription = "Delete", tint = FarmError, modifier = Modifier.size(16.dp))
                    }
                }
            }
        }
    }
}

// ==========================================
// VISUAL FIELD LAYOUT & ROW IDENTIFICATION
// ==========================================
@Composable
fun FieldVisualLayoutView(
    plot: FodderPlotEntity,
    rows: List<FodderRowEntity>,
    selectedRowCodes: Set<String>,
    onToggleRowSelection: (String) -> Unit,
    onSelectRange: (startIndex: Int, endIndex: Int) -> Unit,
    onSelectAllAvailable: () -> Unit,
    onClearSelection: () -> Unit,
    onRowDetailsClick: (FodderRowEntity) -> Unit,
    onHarvestSelectedClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val totalRowLength = plot.row_count * plot.row_length
    val selectedRowsList = rows.filter { selectedRowCodes.contains(it.row_code) }
    val selectedLength = selectedRowsList.sumOf { it.length_m }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Field Title & Stats Card
        Card(
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFFF1F8E9)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "${plot.plot_name} — Visual Layout",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = FarmGreenDark
                        )
                        Text(
                            text = "${plot.species_name} ${plot.variety?.let { "($it)" } ?: ""} • ${plot.row_count} rows × ${plot.row_length} ${plot.row_length_unit}",
                            fontSize = 11.sp,
                            color = Color.DarkGray
                        )
                    }

                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = Color.White
                    ) {
                        Text(
                            text = "${totalRowLength.toInt()}m Total Length",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = FarmGreenDark,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Legend row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    StatusLegendBadge(color = Color(0xFF43A047), label = "Growing")
                    StatusLegendBadge(color = Color(0xFFFFA000), label = "Due")
                    StatusLegendBadge(color = Color(0xFF00897B), label = "Harvested")
                    StatusLegendBadge(color = Color(0xFFE53935), label = "Damaged")
                    StatusLegendBadge(color = Color(0xFF8E24AA), label = "Replanted")
                }
            }
        }

        // Quick Selection Action Chips (Requirement 2 & 6: select rows or range R01-R05)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            AssistChip(
                onClick = { onSelectRange(1, 5.coerceAtMost(plot.row_count)) },
                label = { Text("R01–R05", fontSize = 11.sp) },
                modifier = Modifier.weight(1f)
            )
            AssistChip(
                onClick = { onSelectRange(1, 10.coerceAtMost(plot.row_count)) },
                label = { Text("R01–R10", fontSize = 11.sp) },
                modifier = Modifier.weight(1f)
            )
            AssistChip(
                onClick = onSelectAllAvailable,
                label = { Text("All Due", fontSize = 11.sp) },
                modifier = Modifier.weight(1f)
            )
            AssistChip(
                onClick = onClearSelection,
                label = { Text("Clear", fontSize = 11.sp) },
                modifier = Modifier.weight(0.8f)
            )
        }

        // Selected Rows Banner & Harvest Action
        if (selectedRowCodes.isNotEmpty()) {
            Card(
                shape = RoundedCornerShape(10.dp),
                colors = CardDefaults.cardColors(containerColor = FarmGreenDark),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "${selectedRowCodes.size} Rows Selected",
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            fontSize = 13.sp
                        )
                        Text(
                            text = "${selectedLength.toInt()} m row length • ${selectedRowCodes.sorted().first()} to ${selectedRowCodes.sorted().last()}",
                            fontSize = 11.sp,
                            color = Color.White.copy(alpha = 0.85f)
                        )
                    }

                    Button(
                        onClick = onHarvestSelectedClick,
                        colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = FarmGreenDark),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Icon(Icons.Default.ContentCut, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Record Cut", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }
            }
        }

        // Interactive Rows Grid / Visual Layout
        Text(
            text = "Tap any row to select for cutting or tap ⓘ for row history / replant:",
            fontSize = 11.sp,
            color = Color.Gray
        )

        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(max = 500.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            items(rows, key = { it.id }) { row ->
                val isSelected = selectedRowCodes.contains(row.row_code)
                RowVisualBar(
                    row = row,
                    isSelected = isSelected,
                    onToggleSelect = { onToggleRowSelection(row.row_code) },
                    onDetailsClick = { onRowDetailsClick(row) }
                )
            }
        }
    }
}

@Composable
fun RowVisualBar(
    row: FodderRowEntity,
    isSelected: Boolean,
    onToggleSelect: () -> Unit,
    onDetailsClick: () -> Unit
) {
    val statusColor = when (row.status) {
        "Planted" -> Color(0xFF5C6BC0)
        "Growing" -> Color(0xFF43A047)
        "Due for cutting" -> Color(0xFFFFA000)
        "Harvested" -> Color(0xFF00897B)
        "Regrowth" -> Color(0xFF039BE5)
        "Damaged" -> Color(0xFFE53935)
        "Replanted" -> Color(0xFF8E24AA)
        "Abandoned" -> Color(0xFF757575)
        else -> Color(0xFF43A047)
    }

    Surface(
        shape = RoundedCornerShape(8.dp),
        color = if (isSelected) FarmGreenContainer else Color.White,
        border = androidx.compose.foundation.BorderStroke(
            width = if (isSelected) 2.dp else 1.dp,
            color = if (isSelected) FarmGreenDark else Color(0xFFE0E0E0)
        ),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onToggleSelect() }
            .testTag("row_bar_${row.row_code}")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 10.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                Checkbox(
                    checked = isSelected,
                    onCheckedChange = { onToggleSelect() },
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = row.row_code,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = if (isSelected) FarmGreenDark else Color.Black
                )
                Spacer(modifier = Modifier.width(8.dp))

                // Visual Representation Bar (█████)
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(10.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(statusColor)
                )

                Spacer(modifier = Modifier.width(8.dp))
                Surface(
                    shape = RoundedCornerShape(4.dp),
                    color = statusColor.copy(alpha = 0.15f)
                ) {
                    Text(
                        text = row.status,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = statusColor,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.width(6.dp))

            // Info icon to open row harvest history & replant
            IconButton(
                onClick = onDetailsClick,
                modifier = Modifier.size(28.dp).testTag("row_info_${row.row_code}")
            ) {
                Icon(
                    imageVector = Icons.Default.Info,
                    contentDescription = "Row Details",
                    tint = FarmGreenDark,
                    modifier = Modifier.size(16.dp)
                )
            }
        }
    }
}

@Composable
fun StatusLegendBadge(color: Color, label: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier
                .size(8.dp)
                .clip(CircleShape)
                .background(color)
        )
        Spacer(modifier = Modifier.width(3.dp))
        Text(text = label, fontSize = 9.sp, color = Color.DarkGray)
    }
}

// ==========================================
// ROW HARVEST & ACTIVITY HISTORY DIALOG
// ==========================================
@Composable
fun RowHistoryDialog(
    row: FodderRowEntity,
    plot: FodderPlotEntity,
    cuttings: List<FodderCuttingEntity>,
    activities: List<FodderActivityEntity>,
    onDismiss: () -> Unit,
    onReplantClick: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = Color.White,
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "${plot.plot_name} — Row ${row.row_code}",
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.titleMedium,
                            color = FarmGreenDark
                        )
                        Text(
                            text = "Species: ${row.species_name} • Length: ${row.length_m}m",
                            fontSize = 11.sp,
                            color = Color.Gray
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close")
                    }
                }

                // Row Status Card
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Color(0xFFF9FBF9),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("Current Status", fontSize = 10.sp, color = Color.Gray)
                            Text(row.status, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = FarmGreenDark)
                        }
                        Column {
                            Text("Planted Date", fontSize = 10.sp, color = Color.Gray)
                            Text(row.planting_date ?: "Initial", fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                        }
                        Column {
                            Text("Total Cuts", fontSize = 10.sp, color = Color.Gray)
                            Text("${row.total_cuts}", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                        Column {
                            Text("Total Yield", fontSize = 10.sp, color = Color.Gray)
                            Text("${row.total_yield_kg.toInt()} kg", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = FarmSuccess)
                        }
                    }
                }

                // Historical Cuttings for this row
                Text("Harvest History for ${row.row_code}:", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                if (cuttings.isEmpty()) {
                    Text("No harvests logged yet for this row.", fontSize = 11.sp, color = Color.Gray)
                } else {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(max = 180.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        items(cuttings) { c ->
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = Color(0xFFF5F5F5),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(8.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text("Cut #${c.cut_number} • ${c.cutting_date}", fontWeight = FontWeight.SemiBold, fontSize = 11.sp)
                                        Text("${c.row_codes} (${c.quality_rating})", fontSize = 10.sp, color = Color.Gray)
                                    }
                                    Text(
                                        "${String.format(Locale.US, "%.1f", c.yield_per_row)} kg",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp,
                                        color = FarmGreenDark
                                    )
                                }
                            }
                        }
                    }
                }

                // Replant row action
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedButton(
                        onClick = onReplantClick,
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFF8E24AA)),
                        modifier = Modifier.testTag("replant_row_btn_${row.row_code}")
                    ) {
                        Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Replant Row", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }

                    Button(
                        onClick = onDismiss,
                        colors = ButtonDefaults.buttonColors(containerColor = FarmGreenDark)
                    ) {
                        Text("Done")
                    }
                }
            }
        }
    }
}

// ==========================================
// REPLANT ROW DIALOG (Requirement 11 & 12)
// ==========================================
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReplantRowDialog(
    row: FodderRowEntity,
    plot: FodderPlotEntity,
    speciesList: List<FodderSpeciesEntity>,
    plantingMethods: List<String>,
    onDismiss: () -> Unit,
    onSave: (
        speciesName: String,
        variety: String?,
        plantingDate: String,
        plantingMethod: String,
        materialQuantity: Double,
        materialUnit: String,
        source: String?,
        cost: Double,
        notes: String?
    ) -> Unit
) {
    var selectedSpecies by remember { mutableStateOf(row.species_name) }
    var variety by remember { mutableStateOf(row.variety ?: "") }
    var plantingDate by remember { mutableStateOf(SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())) }
    var selectedMethod by remember { mutableStateOf(plantingMethods.firstOrNull() ?: "Slips") }
    var quantity by remember { mutableStateOf("50") }
    var unit by remember { mutableStateOf("slips") }
    var source by remember { mutableStateOf("Farm Nursery") }
    var cost by remember { mutableStateOf("25.0") }
    var notes by remember { mutableStateOf("Replanted damaged row section") }

    var speciesDropdownExpanded by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Eco, contentDescription = null, tint = Color(0xFF8E24AA))
                Spacer(modifier = Modifier.width(8.dp))
                Text("Replant Row ${row.row_code}", fontWeight = FontWeight.Bold)
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 480.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "Replanting resets the crop cycle for ${row.row_code} while completely preserving previous harvest history.",
                    fontSize = 11.sp,
                    color = Color.DarkGray
                )

                // Species dropdown
                ExposedDropdownMenuBox(
                    expanded = speciesDropdownExpanded,
                    onExpandedChange = { speciesDropdownExpanded = !speciesDropdownExpanded }
                ) {
                    OutlinedTextField(
                        value = selectedSpecies,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Species *") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = speciesDropdownExpanded) },
                        modifier = Modifier.fillMaxWidth().menuAnchor()
                    )
                    ExposedDropdownMenu(
                        expanded = speciesDropdownExpanded,
                        onDismissRequest = { speciesDropdownExpanded = false }
                    ) {
                        speciesList.forEach { sp ->
                            DropdownMenuItem(
                                text = { Text(sp.name) },
                                onClick = {
                                    selectedSpecies = sp.name
                                    speciesDropdownExpanded = false
                                }
                            )
                        }
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = variety,
                        onValueChange = { variety = it },
                        label = { Text("Variety") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = plantingDate,
                        onValueChange = { plantingDate = it },
                        label = { Text("Date") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                }

                // Planting Method chips
                Text("Planting Method:", fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    plantingMethods.take(3).forEach { m ->
                        FilterChip(
                            selected = selectedMethod == m,
                            onClick = { selectedMethod = m },
                            label = { Text(m, fontSize = 10.sp) }
                        )
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = quantity,
                        onValueChange = { quantity = it },
                        label = { Text("Quantity") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = unit,
                        onValueChange = { unit = it },
                        label = { Text("Unit") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = source,
                        onValueChange = { source = it },
                        label = { Text("Supplier / Source") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = cost,
                        onValueChange = { cost = it },
                        label = { Text("Cost ($)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                }

                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Notes") },
                    modifier = Modifier.fillMaxWidth(),
                    maxLines = 2
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val q = quantity.toDoubleOrNull() ?: 1.0
                    val c = cost.toDoubleOrNull() ?: 0.0
                    onSave(selectedSpecies, variety.trim().ifBlank { null }, plantingDate, selectedMethod, q, unit, source, c, notes.trim().ifBlank { null })
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF8E24AA)),
                modifier = Modifier.testTag("confirm_replant_btn")
            ) {
                Text("Confirm Replant")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

// ==========================================
// ADD / EDIT FIELD PLOT DIALOG (FIELD ROW MASTER)
// ==========================================
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddEditPlotDialog(
    initialPlot: FodderPlotEntity? = null,
    speciesList: List<FodderSpeciesEntity>,
    rowUnits: List<String> = listOf("metre", "feet"),
    areaUnits: List<String> = listOf("Acres", "Hectares", "Guntas", "Cents", "sq.m"),
    onDismiss: () -> Unit,
    onSave: (FodderPlotEntity) -> Unit
) {
    val context = LocalContext.current

    var plotName by remember { mutableStateOf(initialPlot?.plot_name ?: "") }
    var areaValue by remember { mutableStateOf(initialPlot?.area_value?.toString() ?: "1.0") }
    var areaUnit by remember { mutableStateOf(initialPlot?.area_unit ?: "Acres") }
    var variety by remember { mutableStateOf(initialPlot?.variety ?: "Pakchong 1") }

    // Row Master parameters
    var rowCountStr by remember { mutableStateOf((initialPlot?.row_count ?: 40).toString()) }
    var rowLengthStr by remember { mutableStateOf((initialPlot?.row_length ?: 25.0).toString()) }
    var rowLengthUnit by remember { mutableStateOf(initialPlot?.row_length_unit ?: "metre") }
    var rowSpacingStr by remember { mutableStateOf((initialPlot?.row_spacing ?: 1.0).toString()) }
    var rowSpacingUnit by remember { mutableStateOf(initialPlot?.row_spacing_unit ?: "metre") }

    var selectedSpeciesId by remember { mutableStateOf(initialPlot?.species_id ?: speciesList.firstOrNull()?.id ?: "") }
    var selectedSpeciesName by remember { mutableStateOf(initialPlot?.species_name ?: speciesList.firstOrNull()?.name ?: "") }
    var sowingDate by remember { mutableStateOf(initialPlot?.sowing_date ?: SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())) }
    var cropCycleStatus by remember { mutableStateOf(initialPlot?.crop_cycle_status ?: "Growing") }
    var irrigationType by remember { mutableStateOf(initialPlot?.irrigation_type ?: "Drip") }
    var soilType by remember { mutableStateOf(initialPlot?.soil_type ?: "Red Loam") }
    var notes by remember { mutableStateOf(initialPlot?.notes ?: "") }

    var latitude by remember { mutableStateOf(initialPlot?.latitude?.toString() ?: "") }
    var longitude by remember { mutableStateOf(initialPlot?.longitude?.toString() ?: "") }
    var gpsAccuracy by remember { mutableStateOf(initialPlot?.gps_accuracy?.toString() ?: "") }
    var locationTag by remember { mutableStateOf(initialPlot?.location_tag ?: "") }

    var speciesDropdownExpanded by remember { mutableStateOf(false) }

    // Live Row Calculations (Requirement 1)
    val parsedRowCount = rowCountStr.toIntOrNull() ?: 0
    val parsedRowLength = rowLengthStr.toDoubleOrNull() ?: 0.0
    val parsedRowSpacing = rowSpacingStr.toDoubleOrNull() ?: 0.0

    val calculatedTotalRowLength = parsedRowCount * parsedRowLength
    val calculatedCultivatedArea = parsedRowCount * parsedRowLength * parsedRowSpacing
    val calculatedAreaUnit = if (rowLengthUnit.equals("feet", ignoreCase = true)) "sq.ft" else "sq.m"

    val locationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { perms ->
        if (perms[Manifest.permission.ACCESS_FINE_LOCATION] == true || perms[Manifest.permission.ACCESS_COARSE_LOCATION] == true) {
            captureDeviceLocation(context) { lat, lon, acc ->
                latitude = String.format(Locale.US, "%.5f", lat)
                longitude = String.format(Locale.US, "%.5f", lon)
                if (acc != null) gpsAccuracy = String.format(Locale.US, "%.1f", acc)
            }
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = if (initialPlot == null) "Add Field / Plot & Row Master" else "Edit Field / Plot",
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 500.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Plot Name
                OutlinedTextField(
                    value = plotName,
                    onValueChange = { plotName = it },
                    label = { Text("Field / Plot Name *") },
                    placeholder = { Text("e.g. Field A - Super Napier") },
                    modifier = Modifier.fillMaxWidth().testTag("plot_name_input"),
                    singleLine = true
                )

                // Species dropdown
                ExposedDropdownMenuBox(
                    expanded = speciesDropdownExpanded,
                    onExpandedChange = { speciesDropdownExpanded = !speciesDropdownExpanded }
                ) {
                    OutlinedTextField(
                        value = selectedSpeciesName,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Assigned Fodder Species *") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = speciesDropdownExpanded) },
                        modifier = Modifier.fillMaxWidth().menuAnchor()
                    )
                    ExposedDropdownMenu(
                        expanded = speciesDropdownExpanded,
                        onDismissRequest = { speciesDropdownExpanded = false }
                    ) {
                        speciesList.forEach { sp ->
                            DropdownMenuItem(
                                text = { Text(sp.name) },
                                onClick = {
                                    selectedSpeciesId = sp.id
                                    selectedSpeciesName = sp.name
                                    speciesDropdownExpanded = false
                                }
                            )
                        }
                    }
                }

                // Variety & Sowing Date
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = variety,
                        onValueChange = { variety = it },
                        label = { Text("Variety") },
                        placeholder = { Text("e.g. Pakchong 1") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = sowingDate,
                        onValueChange = { sowingDate = it },
                        label = { Text("Sowing Date") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                }

                // Registered Total Field Area
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = areaValue,
                        onValueChange = { areaValue = it },
                        label = { Text("Total Field Area *") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.weight(1f).testTag("plot_area_input"),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = areaUnit,
                        onValueChange = { areaUnit = it },
                        label = { Text("Area Unit") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                }

                // ==========================================
                // FIELD ROW MASTER SECTION (Requirement 1)
                // ==========================================
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = Color(0xFFF1F8E9),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(10.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = "FIELD ROW MASTER & SPACING",
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            color = FarmGreenDark
                        )

                        // Rows count & Row Length
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedTextField(
                                value = rowCountStr,
                                onValueChange = { rowCountStr = it },
                                label = { Text("Number of Rows *") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                modifier = Modifier.weight(1f),
                                singleLine = true
                            )
                            OutlinedTextField(
                                value = rowLengthStr,
                                onValueChange = { rowLengthStr = it },
                                label = { Text("Row Length *") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                                modifier = Modifier.weight(1f),
                                singleLine = true
                            )
                            OutlinedTextField(
                                value = rowLengthUnit,
                                onValueChange = { rowLengthUnit = it },
                                label = { Text("Unit") },
                                modifier = Modifier.weight(0.8f),
                                singleLine = true
                            )
                        }

                        // Row Spacing
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedTextField(
                                value = rowSpacingStr,
                                onValueChange = { rowSpacingStr = it },
                                label = { Text("Row Spacing *") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                                modifier = Modifier.weight(1.2f),
                                singleLine = true
                            )
                            OutlinedTextField(
                                value = rowSpacingUnit,
                                onValueChange = { rowSpacingUnit = it },
                                label = { Text("Spacing Unit") },
                                modifier = Modifier.weight(1f),
                                singleLine = true
                            )
                        }

                        // Live Row Calculations Display (Requirement 1)
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = Color.White,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text("Total Row Length:", fontSize = 10.sp, color = Color.Gray)
                                    Text(
                                        "${calculatedTotalRowLength.toInt()} $rowLengthUnit",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp,
                                        color = FarmGreenDark
                                    )
                                }
                                Column(horizontalAlignment = Alignment.End) {
                                    Text("Est. Cultivated Area:", fontSize = 10.sp, color = Color.Gray)
                                    Text(
                                        "${calculatedCultivatedArea.toInt()} $calculatedAreaUnit",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp,
                                        color = Color(0xFF0277BD)
                                    )
                                }
                            }
                        }
                    }
                }

                // Irrigation & Status
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = irrigationType,
                        onValueChange = { irrigationType = it },
                        label = { Text("Irrigation") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = cropCycleStatus,
                        onValueChange = { cropCycleStatus = it },
                        label = { Text("Status") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                }

                // GPS Section with Auto-detect button
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Color(0xFFF5F5F5),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.LocationOn, contentDescription = null, tint = FarmGreenDark, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("GPS Coordinates & Accuracy", fontWeight = FontWeight.Bold, fontSize = 11.sp)
                            }
                            TextButton(
                                onClick = {
                                    val hasPerm = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
                                            ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
                                    if (hasPerm) {
                                        captureDeviceLocation(context) { lat, lon, acc ->
                                            latitude = String.format(Locale.US, "%.5f", lat)
                                            longitude = String.format(Locale.US, "%.5f", lon)
                                            if (acc != null) gpsAccuracy = String.format(Locale.US, "%.1f", acc)
                                        }
                                    } else {
                                        locationPermissionLauncher.launch(
                                            arrayOf(
                                                Manifest.permission.ACCESS_FINE_LOCATION,
                                                Manifest.permission.ACCESS_COARSE_LOCATION
                                            )
                                        )
                                    }
                                }
                            ) {
                                Icon(Icons.Default.MyLocation, contentDescription = null, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Get GPS", fontSize = 11.sp)
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            OutlinedTextField(
                                value = latitude,
                                onValueChange = { latitude = it },
                                label = { Text("Latitude") },
                                modifier = Modifier.weight(1f),
                                singleLine = true
                            )
                            OutlinedTextField(
                                value = longitude,
                                onValueChange = { longitude = it },
                                label = { Text("Longitude") },
                                modifier = Modifier.weight(1f),
                                singleLine = true
                            )
                            OutlinedTextField(
                                value = gpsAccuracy,
                                onValueChange = { gpsAccuracy = it },
                                label = { Text("Accuracy (m)") },
                                modifier = Modifier.weight(0.9f),
                                singleLine = true
                            )
                        }

                        OutlinedTextField(
                            value = locationTag,
                            onValueChange = { locationTag = it },
                            label = { Text("Location Name / Landmark") },
                            placeholder = { Text("e.g. Near Borewell 2") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )
                    }
                }

                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Field Notes") },
                    modifier = Modifier.fillMaxWidth(),
                    maxLines = 2
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val area = areaValue.toDoubleOrNull() ?: 1.0
                    val rowCount = parsedRowCount.coerceAtLeast(1)
                    val rowLength = parsedRowLength.coerceAtLeast(1.0)
                    val rowSpacing = parsedRowSpacing.coerceAtLeast(0.1)

                    val plot = FodderPlotEntity(
                        id = initialPlot?.id ?: UUID.randomUUID().toString(),
                        plot_name = plotName.trim().ifBlank { "Field Plot" },
                        area_value = area,
                        area_unit = areaUnit,
                        variety = variety.trim().ifBlank { null },
                        row_count = rowCount,
                        row_length = rowLength,
                        row_length_unit = rowLengthUnit,
                        row_spacing = rowSpacing,
                        row_spacing_unit = rowSpacingUnit,
                        calculated_cultivated_area = calculatedCultivatedArea,
                        calculated_area_unit = calculatedAreaUnit,
                        latitude = latitude.toDoubleOrNull(),
                        longitude = longitude.toDoubleOrNull(),
                        gps_accuracy = gpsAccuracy.toFloatOrNull(),
                        location_tag = locationTag.trim().ifBlank { null },
                        species_id = selectedSpeciesId,
                        species_name = selectedSpeciesName,
                        sowing_date = sowingDate,
                        crop_cycle_status = cropCycleStatus,
                        current_cut_count = initialPlot?.current_cut_count ?: 0,
                        last_cut_date = initialPlot?.last_cut_date,
                        next_expected_cut_date = initialPlot?.next_expected_cut_date,
                        irrigation_type = irrigationType,
                        soil_type = soilType,
                        notes = notes.trim().ifBlank { null }
                    )
                    onSave(plot)
                },
                enabled = plotName.isNotBlank() && areaValue.toDoubleOrNull() != null && selectedSpeciesName.isNotBlank(),
                colors = ButtonDefaults.buttonColors(containerColor = FarmGreenDark),
                modifier = Modifier.testTag("save_plot_btn")
            ) {
                Text("Save Field & Rows")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

@SuppressLint("MissingPermission")
private fun captureDeviceLocation(context: Context, onResult: (latitude: Double, longitude: Double, accuracy: Float?) -> Unit) {
    val locationManager = context.getSystemService(Context.LOCATION_SERVICE) as? LocationManager ?: return
    var loc: Location? = null
    try {
        if (locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
            loc = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER)
        }
        if (loc == null && locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {
            loc = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER)
        }
    } catch (_: Exception) {}

    if (loc != null) {
        onResult(loc.latitude, loc.longitude, loc.accuracy)
    } else {
        // Fallback default coordinates if unavailable
        onResult(11.0185, 76.9582, 5.0f)
    }
}
