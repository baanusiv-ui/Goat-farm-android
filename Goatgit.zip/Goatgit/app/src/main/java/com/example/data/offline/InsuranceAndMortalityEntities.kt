package com.example.data.offline

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.UUID

@Entity(tableName = "local_insurance_providers")
data class InsuranceProviderEntity(
    @PrimaryKey
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val company_name: String,
    val code: String? = null,
    val type: String = "GENERAL", // GENERAL, LIVESTOCK, OTHER
    val website: String? = null,
    val phone: String? = null,
    val email: String? = null,
    val api_base_url: String? = null,
    val sandbox_url: String? = null,
    val production_url: String? = null,
    val api_version: String = "v1",
    val auth_type: String = "API_KEY",
    val webhook_url: String? = null,
    val is_active: Boolean = true,
    val is_sandbox: Boolean = true,
    val notes: String? = null,
    val created_at: String? = null,
    val updated_at: Long = System.currentTimeMillis(),
    val is_synced: Boolean = false
)

@Entity(tableName = "local_insurance_policies")
data class InsurancePolicyEntity(
    @PrimaryKey
    val id: String = UUID.randomUUID().toString(),
    val goat_id: String,
    val goat_tag: String,
    val rfid: String? = null,
    val goat_name: String? = null,
    val provider_id: String? = null,
    val insurance_company: String,
    val policy_name: String,
    val policy_number: String? = null,
    val proposal_number: String? = null,
    val sum_insured: Double = 0.0,
    val market_value: Double = 0.0,
    val premium: Double = 0.0,
    val tax_amount: Double = 0.0,
    val total_premium: Double = 0.0,
    val start_date: String,
    val expiry_date: String,
    val renewal_date: String? = null,
    val status: String = "Active",
    val coverage_type: String = "Comprehensive (Death & PTD)",
    val deductible: Double = 0.0,
    val claim_eligibility: String? = null,
    val agent_name: String? = null,
    val agent_contact: String? = null,
    val policy_document_url: String? = null,
    val vet_certificate_url: String? = null,
    val animal_photo_url: String? = null,
    val eartag_photo_url: String? = null,
    val payment_account_id: String? = null,
    val created_at: String? = null,
    val updated_at: Long = System.currentTimeMillis(),
    val is_synced: Boolean = false
)

@Entity(tableName = "local_insurance_quotes")
data class InsuranceQuoteEntity(
    @PrimaryKey
    val id: String = UUID.randomUUID().toString(),
    val goat_id: String,
    val goat_tag: String,
    val provider_id: String? = null,
    val provider_name: String,
    val product_name: String,
    val sum_insured: Double,
    val premium: Double,
    val tax_amount: Double,
    val total_premium: Double,
    val validity_date: String,
    val coverage_details: String? = null,
    val terms_and_conditions: String? = null,
    val exclusions: String? = null,
    val status: String = "AVAILABLE",
    val created_at: String? = null,
    val updated_at: Long = System.currentTimeMillis(),
    val is_synced: Boolean = false
)

@Entity(tableName = "local_insurance_claims")
data class InsuranceClaimEntity(
    @PrimaryKey
    val id: String = UUID.randomUUID().toString(),
    val policy_id: String,
    val goat_id: String,
    val goat_tag: String,
    val mortality_event_id: String? = null,
    val incident_date: String,
    val incident_type: String = "Death",
    val cause: String,
    val description: String? = null,
    val location: String? = null,
    val vet_doctor: String? = null,
    val vet_certificate_url: String? = null,
    val photos_urls: String? = null,
    val eartag_photo_url: String? = null,
    val post_mortem_report_url: String? = null,
    val police_report_url: String? = null,
    val claim_amount: Double,
    val claim_number: String? = null,
    val submitted_date: String? = null,
    val insurer_response: String? = null,
    val approved_amount: Double? = null,
    val settlement_date: String? = null,
    val settlement_amount: Double? = null,
    val settlement_account_id: String? = null,
    val rejection_reason: String? = null,
    val status: String = "Draft",
    val notes: String? = null,
    val created_at: String? = null,
    val updated_at: Long = System.currentTimeMillis(),
    val is_synced: Boolean = false
)

@Entity(tableName = "local_insurance_alerts")
data class InsuranceAlertEntity(
    @PrimaryKey
    val id: String = UUID.randomUUID().toString(),
    val policy_id: String? = null,
    val claim_id: String? = null,
    val goat_id: String? = null,
    val alert_type: String,
    val title: String,
    val message: String,
    val due_date: String,
    val days_before_expiry: Int = 0,
    val is_dismissed: Boolean = false,
    val created_at: String? = null,
    val updated_at: Long = System.currentTimeMillis()
)

@Entity(tableName = "local_reproductive_events")
data class ReproductiveEventEntity(
    @PrimaryKey
    val id: String = UUID.randomUUID().toString(),
    val doe_id: String,
    val pregnancy_id: String? = null,
    val sire_id: String? = null,
    val event_type: String, // NORMAL_DELIVERY, ABORTION, STILLBIRTH, KID_DEATH, DOE_DEATH, POST_DELIVERY_DEATH, OTHER_MORTALITY
    val event_date: String,
    val mating_date: String? = null,
    val expected_delivery_date: String? = null,
    val pregnancy_age_days: Int? = null,
    val number_of_fetuses: Int? = null,
    val suspected_cause: String? = null,
    val confirmed_cause: String? = null,
    val cause_category: String? = null,
    val vet_diagnosis: String? = null,
    val symptoms: String? = null,
    val treatment: String? = null,
    val vet_doctor: String? = null,
    val certificate_url: String? = null,
    val photo_url: String? = null,
    val notes: String? = null,
    val created_at: String? = null,
    val updated_at: Long = System.currentTimeMillis(),
    val is_synced: Boolean = false
)

@Entity(tableName = "local_post_delivery_checks")
data class PostDeliveryCheckEntity(
    @PrimaryKey
    val id: String = UUID.randomUUID().toString(),
    val doe_id: String,
    val delivery_date: String,
    val check_date: String,
    val days_post_delivery: Int,
    val appetite: String = "Normal",
    val temperature: Double? = null,
    val milk_production_ltr: Double? = null,
    val complications: String? = null,
    val treatment: String? = null,
    val medication: String? = null,
    val vet_visit: Boolean = false,
    val vet_doctor: String? = null,
    val recovery_status: String = "Recovering",
    val notes: String? = null,
    val created_at: String? = null,
    val updated_at: Long = System.currentTimeMillis(),
    val is_synced: Boolean = false
)

@Entity(tableName = "local_mortality_events")
data class MortalityEventEntity(
    @PrimaryKey
    val id: String = UUID.randomUUID().toString(),
    val goat_id: String,
    val goat_tag: String,
    val event_type: String, // ADULT_DEATH, KID_DEATH, DOE_POST_DELIVERY_DEATH, STILLBIRTH, OTHER
    val death_date: String,
    val death_time: String? = null,
    val age_at_death_days: Int? = null,
    val weight_at_death: Double? = null,
    val delivery_date: String? = null,
    val days_post_delivery: Int? = null,
    val immediate_cause: String,
    val underlying_cause: String? = null,
    val cause_certainty: String = "Suspected",
    val cause_category: String,
    val disease_name: String? = null,
    val injury_details: String? = null,
    val treatment_history: String? = null,
    val vet_doctor: String? = null,
    val post_mortem_performed: Boolean = false,
    val post_mortem_report_url: String? = null,
    val photos_urls: String? = null,
    val insurance_policy_id: String? = null,
    val insurance_claim_id: String? = null,
    val notes: String? = null,
    val created_at: String? = null,
    val updated_at: Long = System.currentTimeMillis(),
    val is_synced: Boolean = false
)
