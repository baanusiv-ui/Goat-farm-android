package com.example.ui.screens.finance

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.supabase.*
import com.example.ui.components.DatePickerField
import com.example.ui.theme.*
import com.example.util.CurrencyUtils
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ElectricityScreen(
    repository: GoatRepository,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler { onNavigateBack() }

    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val dateFormat = remember { SimpleDateFormat("yyyy-MM-dd", Locale.US) }
    val today = remember { dateFormat.format(Date()) }

    var connections by remember { mutableStateOf<List<ElectricityConnection>>(emptyList()) }
    var bills by remember { mutableStateOf<List<ElectricityBill>>(emptyList()) }
    var accounts by remember { mutableStateOf<List<FinancialAccount>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }

    var showAddBillDialog by remember { mutableStateOf(false) }
    var showAddConnDialog by remember { mutableStateOf(false) }
    var payingBill by remember { mutableStateOf<ElectricityBill?>(null) }
    var selectedTab by remember { mutableStateOf(0) } // 0: Bills History, 1: Meters / Connections, 2: Consumption Trends

    fun loadData() {
        isLoading = true
        coroutineScope.launch {
            val connRes = repository.finance.getElectricityConnections()
            if (connRes.isSuccess) {
                connections = connRes.getOrThrow()
            }
            val billsRes = repository.finance.getElectricityBills()
            if (billsRes.isSuccess) {
                bills = billsRes.getOrThrow().sortedByDescending { it.bill_date }
            }
            val accRes = repository.finance.getAccounts()
            if (accRes.isSuccess) {
                accounts = accRes.getOrThrow()
            }
            isLoading = false
        }
    }

    LaunchedEffect(Unit) {
        loadData()
    }

    val totalUnits = remember(bills) { bills.sumOf { it.units_consumed } }
    val totalBilled = remember(bills) { bills.sumOf { it.total_bill } }
    val totalPending = remember(bills) { bills.sumOf { it.balance_amount } }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "Electricity & EB Management",
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp
                        )
                        Text(
                            text = "Meters, Consumption Units & Tariff Billing",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack, modifier = Modifier.testTag("eb_btn_back")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(onClick = { loadData() }, modifier = Modifier.testTag("eb_btn_refresh")) {
                        Icon(Icons.Default.Refresh, contentDescription = "Refresh")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.White)
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { showAddBillDialog = true },
                containerColor = FarmGreenDark,
                contentColor = Color.White,
                icon = { Icon(Icons.Default.Add, contentDescription = null) },
                text = { Text("Log Monthly Bill", fontWeight = FontWeight.Bold) },
                modifier = Modifier.testTag("btn_log_eb_bill")
            )
        },
        containerColor = Color(0xFFF8F9FA),
        modifier = modifier
    ) { innerPadding ->
        if (isLoading) {
            Box(modifier = Modifier.fillMaxSize().padding(innerPadding), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = FarmGreenDark)
            }
        } else {
            Column(modifier = Modifier.fillMaxSize().padding(innerPadding)) {
                TabRow(
                    selectedTabIndex = selectedTab,
                    containerColor = Color.White,
                    contentColor = FarmGreenDark
                ) {
                    Tab(
                        selected = selectedTab == 0,
                        onClick = { selectedTab = 0 },
                        text = { Text("EB Bills (${bills.size})", fontWeight = if (selectedTab == 0) FontWeight.Bold else FontWeight.Normal) }
                    )
                    Tab(
                        selected = selectedTab == 1,
                        onClick = { selectedTab = 1 },
                        text = { Text("Meters (${connections.size})", fontWeight = if (selectedTab == 1) FontWeight.Bold else FontWeight.Normal) }
                    )
                    Tab(
                        selected = selectedTab == 2,
                        onClick = { selectedTab = 2 },
                        text = { Text("Trends & Units", fontWeight = if (selectedTab == 2) FontWeight.Bold else FontWeight.Normal) }
                    )
                }

                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    item { Spacer(modifier = Modifier.height(4.dp)) }

                    // Summary KPI Cards
                    item {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            Card(
                                colors = CardDefaults.cardColors(containerColor = Color(0xFFE8F5E9)),
                                modifier = Modifier.weight(1f).testTag("eb_total_units_card")
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Text("Total Units", fontSize = 11.sp, color = FarmGreenDark)
                                    Text("${totalUnits.toInt()} kWh", fontSize = 18.sp, fontWeight = FontWeight.ExtraBold, color = FarmGreenDark)
                                }
                            }
                            Card(
                                colors = CardDefaults.cardColors(containerColor = Color(0xFFEFF6FF)),
                                modifier = Modifier.weight(1f).testTag("eb_total_billed_card")
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Text("Total Billed", fontSize = 11.sp, color = Color(0xFF1E40AF))
                                    Text(CurrencyUtils.formatInr(totalBilled), fontSize = 18.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFF1E40AF))
                                }
                            }
                            Card(
                                colors = CardDefaults.cardColors(containerColor = if (totalPending > 0) Color(0xFFFFEBEE) else Color(0xFFF5F5F5)),
                                modifier = Modifier.weight(1f).testTag("eb_total_pending_card")
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Text("Unpaid Due", fontSize = 11.sp, color = if (totalPending > 0) FarmError else Color.DarkGray)
                                    Text(
                                        CurrencyUtils.formatInr(totalPending),
                                        fontSize = 18.sp,
                                        fontWeight = FontWeight.ExtraBold,
                                        color = if (totalPending > 0) FarmError else Color.DarkGray
                                    )
                                }
                            }
                        }
                    }

                    if (selectedTab == 0) {
                        if (bills.isEmpty()) {
                            item {
                                Card(colors = CardDefaults.cardColors(containerColor = Color.White), modifier = Modifier.fillMaxWidth().padding(vertical = 20.dp)) {
                                    Box(modifier = Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                                        Text("No electricity bills logged yet. Tap '+ Log Monthly Bill'.", color = Color.Gray, fontSize = 13.sp)
                                    }
                                }
                            }
                        } else {
                            items(bills) { bill ->
                                ElectricityBillCard(
                                    bill = bill,
                                    connectionsMap = connections.associateBy { it.id },
                                    onPayNow = { payingBill = bill }
                                )
                            }
                        }
                    } else if (selectedTab == 1) {
                        item {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("Registered Electricity Connections", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                                TextButton(onClick = { showAddConnDialog = true }) {
                                    Text("+ Add Meter", fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                        items(connections) { conn ->
                            ElectricityConnectionCard(conn = conn)
                        }
                    } else {
                        // Trends
                        item {
                            Card(
                                colors = CardDefaults.cardColors(containerColor = Color.White),
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)
                            ) {
                                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                    Text("Recent Power Consumption Trend", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                    bills.take(6).forEach { b ->
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(b.billing_period, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                            Text("${b.units_consumed.toInt()} Units", fontSize = 12.sp, color = FarmGreenDark, fontWeight = FontWeight.Bold)
                                            Text(CurrencyUtils.formatInr(b.total_bill), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                        }
                                        HorizontalDivider(color = Color(0xFFF5F5F5))
                                    }
                                }
                            }
                        }
                    }

                    item { Spacer(modifier = Modifier.height(72.dp)) }
                }
            }
        }
    }

    // Add Bill Dialog
    if (showAddBillDialog) {
        AddElectricityBillDialog(
            connections = connections,
            accounts = accounts,
            onDismiss = { showAddBillDialog = false },
            onSave = { bill ->
                showAddBillDialog = false
                coroutineScope.launch {
                    val res = repository.finance.recordElectricityBill(bill)
                    if (res.isSuccess) {
                        Toast.makeText(context, "EB bill recorded (Units auto-calculated)", Toast.LENGTH_SHORT).show()
                        loadData()
                    } else {
                        Toast.makeText(context, "Failed: ${res.exceptionOrNull()?.message}", Toast.LENGTH_LONG).show()
                    }
                }
            }
        )
    }

    // Add Connection Dialog
    if (showAddConnDialog) {
        AddElectricityConnectionDialog(
            onDismiss = { showAddConnDialog = false },
            onSave = { conn ->
                showAddConnDialog = false
                coroutineScope.launch {
                    val res = repository.finance.addElectricityConnection(conn)
                    if (res.isSuccess) {
                        Toast.makeText(context, "Meter connection added & synced", Toast.LENGTH_SHORT).show()
                        loadData()
                    } else {
                        Toast.makeText(context, "Failed: ${res.exceptionOrNull()?.message}", Toast.LENGTH_LONG).show()
                    }
                }
            }
        )
    }

    // Pay Bill Dialog
    if (payingBill != null) {
        PayElectricityBillDialog(
            bill = payingBill!!,
            accounts = accounts,
            onDismiss = { payingBill = null },
            onConfirmPay = { billId, accId, amt, date ->
                payingBill = null
                coroutineScope.launch {
                    val res = repository.finance.payElectricityBill(billId, accId, amt, date)
                    if (res.isSuccess) {
                        Toast.makeText(context, "EB bill paid & posted to account ledger!", Toast.LENGTH_SHORT).show()
                        loadData()
                    } else {
                        Toast.makeText(context, "Payment error: ${res.exceptionOrNull()?.message}", Toast.LENGTH_LONG).show()
                    }
                }
            }
        )
    }
}

@Composable
private fun ElectricityBillCard(
    bill: ElectricityBill,
    connectionsMap: Map<String, ElectricityConnection>,
    onPayNow: () -> Unit
) {
    val conn = connectionsMap[bill.connection_id]
    val isPaid = bill.payment_status.equals("PAID", ignoreCase = true)

    Card(
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(14.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier.fillMaxWidth().testTag("eb_bill_card_${bill.id}")
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(bill.billing_period, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    Text(conn?.connection_name ?: "Main Meter", fontSize = 11.sp, color = Color.Gray)
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = CurrencyUtils.formatInr(bill.total_bill),
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 16.sp,
                        color = if (isPaid) FarmGreenDark else FarmError
                    )
                    Text(bill.payment_status, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = if (isPaid) FarmGreenDark else FarmError)
                }
            }

            HorizontalDivider(color = Color(0xFFF0F0F0))

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Column {
                    Text("Readings: ${bill.previous_reading.toInt()} → ${bill.current_reading.toInt()}", fontSize = 11.sp, color = Color.DarkGray)
                    Text("Consumed: ${bill.units_consumed.toInt()} Units", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = FarmGreenDark)
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text("Due Date: ${bill.due_date}", fontSize = 11.sp, color = Color.Gray)
                    if (!isPaid && bill.balance_amount > 0) {
                        Text("Bal: ${CurrencyUtils.formatInr(bill.balance_amount)}", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = FarmError)
                    }
                }
            }

            if (!isPaid) {
                Button(
                    onClick = onPayNow,
                    colors = ButtonDefaults.buttonColors(containerColor = FarmGreenDark),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth().height(36.dp).testTag("btn_pay_eb_${bill.id}")
                ) {
                    Text("Pay EB Bill (${CurrencyUtils.formatInr(bill.balance_amount)})", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
private fun ElectricityConnectionCard(conn: ElectricityConnection) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(conn.connection_name, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Text("Consumer No: ${conn.consumer_number} • Meter: ${conn.meter_number}", fontSize = 12.sp, color = Color.DarkGray)
            Text("Provider: ${conn.service_provider} • Tariff: ${conn.tariff_category}", fontSize = 11.sp, color = Color.Gray)
            Text("Location: ${conn.location} • Cycle: ${conn.billing_cycle}", fontSize = 11.sp, color = Color.Gray)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AddElectricityBillDialog(
    connections: List<ElectricityConnection>,
    accounts: List<FinancialAccount>,
    onDismiss: () -> Unit,
    onSave: (ElectricityBill) -> Unit
) {
    var connectionId by remember { mutableStateOf(connections.firstOrNull()?.id ?: "") }
    var billingPeriod by remember { mutableStateOf("October 2026") }
    var billDate by remember { mutableStateOf(SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())) }
    var dueDate by remember { mutableStateOf(SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())) }
    var prevReadingStr by remember { mutableStateOf("1200") }
    var currReadingStr by remember { mutableStateOf("1450") }
    var baseAmountStr by remember { mutableStateOf("1250") }
    var otherChargesStr by remember { mutableStateOf("50") }
    var taxStr by remember { mutableStateOf("60") }
    var notes by remember { mutableStateOf("") }

    val prevReading = prevReadingStr.toDoubleOrNull() ?: 0.0
    val currReading = currReadingStr.toDoubleOrNull() ?: 0.0
    val calculatedUnits = remember(prevReading, currReading) {
        (currReading - prevReading).coerceAtLeast(0.0)
    }

    val baseAmt = baseAmountStr.toDoubleOrNull() ?: 0.0
    val otherAmt = otherChargesStr.toDoubleOrNull() ?: 0.0
    val taxAmt = taxStr.toDoubleOrNull() ?: 0.0
    val totalBill = remember(baseAmt, otherAmt, taxAmt) {
        baseAmt + otherAmt + taxAmt
    }

    var connExpanded by remember { mutableStateOf(false) }

    Dialog(onDismissRequest = onDismiss) {
        Surface(shape = RoundedCornerShape(16.dp), color = Color.White, modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Log Monthly Electricity Bill", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = FarmGreenDark)

                // Connection Dropdown
                ExposedDropdownMenuBox(expanded = connExpanded, onExpandedChange = { connExpanded = !connExpanded }) {
                    val selConn = connections.firstOrNull { it.id == connectionId }
                    OutlinedTextField(
                        value = selConn?.connection_name ?: "Select Meter",
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Connection Meter *") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = connExpanded) },
                        modifier = Modifier.fillMaxWidth().menuAnchor()
                    )
                    ExposedDropdownMenu(expanded = connExpanded, onDismissRequest = { connExpanded = false }) {
                        connections.forEach { c ->
                            DropdownMenuItem(text = { Text("${c.connection_name} (${c.consumer_number})") }, onClick = { connectionId = c.id; connExpanded = false })
                        }
                    }
                }

                OutlinedTextField(
                    value = billingPeriod,
                    onValueChange = { billingPeriod = it },
                    label = { Text("Billing Period *") },
                    placeholder = { Text("e.g. Oct 2026") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = prevReadingStr,
                        onValueChange = { prevReadingStr = it },
                        label = { Text("Prev Reading") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f).testTag("input_prev_reading")
                    )
                    OutlinedTextField(
                        value = currReadingStr,
                        onValueChange = { currReadingStr = it },
                        label = { Text("Current Reading") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f).testTag("input_curr_reading")
                    )
                }

                // Units Calculated Banner
                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFE8F5E9)), modifier = Modifier.fillMaxWidth()) {
                    Row(modifier = Modifier.padding(10.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("Calculated Units Consumed:", fontSize = 12.sp, color = FarmGreenDark)
                        Text("${calculatedUnits.toInt()} kWh", fontWeight = FontWeight.ExtraBold, fontSize = 14.sp, color = FarmGreenDark)
                    }
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = baseAmountStr,
                        onValueChange = { baseAmountStr = it },
                        label = { Text("Base Amt (₹)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = taxStr,
                        onValueChange = { taxStr = it },
                        label = { Text("Tax (₹)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f)
                    )
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("Total Bill Amount:", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Text(CurrencyUtils.formatInr(totalBill), fontWeight = FontWeight.ExtraBold, fontSize = 16.sp, color = FarmGreenDark)
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    TextButton(onClick = onDismiss) { Text("Cancel") }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            if (connectionId.isBlank() || totalBill <= 0) return@Button
                            val bill = ElectricityBill(
                                connection_id = connectionId,
                                billing_period = billingPeriod.trim(),
                                bill_date = billDate,
                                due_date = dueDate,
                                previous_reading = prevReading,
                                current_reading = currReading,
                                units_consumed = calculatedUnits,
                                base_amount = baseAmt,
                                other_charges = otherAmt,
                                tax_amount = taxAmt,
                                total_bill = totalBill,
                                balance_amount = totalBill,
                                payment_status = "UNPAID",
                                notes = notes.trim().ifBlank { null }
                            )
                            onSave(bill)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = FarmGreenDark),
                        enabled = totalBill > 0,
                        modifier = Modifier.testTag("btn_save_eb_bill")
                    ) {
                        Text("Save EB Bill")
                    }
                }
            }
        }
    }
}

@Composable
private fun AddElectricityConnectionDialog(
    onDismiss: () -> Unit,
    onSave: (ElectricityConnection) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var consumerNo by remember { mutableStateOf("") }
    var meterNo by remember { mutableStateOf("") }
    var provider by remember { mutableStateOf("TANGEDCO (State EB)") }
    var tariff by remember { mutableStateOf("Agricultural") }
    var location by remember { mutableStateOf("Main Shed") }

    Dialog(onDismissRequest = onDismiss) {
        Surface(shape = RoundedCornerShape(16.dp), color = Color.White, modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Add Electricity Meter Connection", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = FarmGreenDark)

                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Connection Name *") }, placeholder = { Text("e.g. Borewell Meter, Barn Shed") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = consumerNo, onValueChange = { consumerNo = it }, label = { Text("Consumer Number *") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = meterNo, onValueChange = { meterNo = it }, label = { Text("Meter Number *") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = provider, onValueChange = { provider = it }, label = { Text("Service Provider") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = location, onValueChange = { location = it }, label = { Text("Location") }, singleLine = true, modifier = Modifier.fillMaxWidth())

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    TextButton(onClick = onDismiss) { Text("Cancel") }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            if (name.isBlank() || consumerNo.isBlank()) return@Button
                            val conn = ElectricityConnection(
                                connection_name = name.trim(),
                                consumer_number = consumerNo.trim(),
                                meter_number = meterNo.trim().ifBlank { "MTR-" + consumerNo.takeLast(4) },
                                service_provider = provider.trim(),
                                tariff_category = tariff,
                                location = location.trim(),
                                is_active = true
                            )
                            onSave(conn)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = FarmGreenDark),
                        enabled = name.isNotBlank() && consumerNo.isNotBlank()
                    ) {
                        Text("Save Connection")
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun PayElectricityBillDialog(
    bill: ElectricityBill,
    accounts: List<FinancialAccount>,
    onDismiss: () -> Unit,
    onConfirmPay: (billId: String, accountId: String, amount: Double, date: String) -> Unit
) {
    var accountId by remember { mutableStateOf(accounts.firstOrNull()?.id ?: "") }
    var payAmountStr by remember { mutableStateOf(bill.balance_amount.toString()) }
    var payDate by remember { mutableStateOf(SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())) }
    var accExpanded by remember { mutableStateOf(false) }

    Dialog(onDismissRequest = onDismiss) {
        Surface(shape = RoundedCornerShape(16.dp), color = Color.White, modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Pay Electricity Bill", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = FarmGreenDark)
                Text("Paying this bill will debit the selected account and log the actual expense in the farm ledger.", fontSize = 11.sp, color = Color.Gray)

                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFF1F8E9)), modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text("Bill Period: ${bill.billing_period}", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text("Units Consumed: ${bill.units_consumed} kWh", fontSize = 12.sp)
                        Text("Outstanding: ${CurrencyUtils.formatInr(bill.balance_amount)}", fontWeight = FontWeight.ExtraBold, fontSize = 16.sp, color = FarmGreenDark)
                    }
                }

                // Account Dropdown
                ExposedDropdownMenuBox(expanded = accExpanded, onExpandedChange = { accExpanded = !accExpanded }) {
                    val selAcc = accounts.firstOrNull { it.id == accountId }
                    OutlinedTextField(
                        value = "${selAcc?.account_name ?: "Select Account"} (${CurrencyUtils.formatInr(selAcc?.current_balance ?: 0.0)})",
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Payment Account *") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = accExpanded) },
                        modifier = Modifier.fillMaxWidth().menuAnchor().testTag("select_eb_pay_account")
                    )
                    ExposedDropdownMenu(expanded = accExpanded, onDismissRequest = { accExpanded = false }) {
                        accounts.forEach { acc ->
                            DropdownMenuItem(
                                text = { Text("${acc.account_name} (${CurrencyUtils.formatInr(acc.current_balance)})") },
                                onClick = { accountId = acc.id; accExpanded = false }
                            )
                        }
                    }
                }

                OutlinedTextField(
                    value = payAmountStr,
                    onValueChange = { payAmountStr = it },
                    label = { Text("Amount to Pay (₹) *") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                DatePickerField(
                    dateValue = payDate,
                    onDateSelected = { payDate = it },
                    label = "Payment Date *"
                )

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    TextButton(onClick = onDismiss) { Text("Cancel") }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            val amt = payAmountStr.toDoubleOrNull() ?: 0.0
                            if (amt > 0 && accountId.isNotBlank()) {
                                onConfirmPay(bill.id, accountId, amt, payDate)
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = FarmGreenDark),
                        enabled = (payAmountStr.toDoubleOrNull() ?: 0.0) > 0 && accountId.isNotBlank(),
                        modifier = Modifier.testTag("btn_confirm_eb_payment")
                    ) {
                        Text("Confirm Payment")
                    }
                }
            }
        }
    }
}
