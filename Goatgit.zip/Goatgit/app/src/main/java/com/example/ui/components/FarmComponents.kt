package com.example.ui.components

import android.app.DatePickerDialog
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Label
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.supabase.Goat
import com.example.i18n.LocalLanguage
import com.example.i18n.LocalLanguageManager
import com.example.i18n.LanguageToggle
import com.example.i18n.t
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FarmTopBar(
    title: String,
    canNavigateBack: Boolean = false,
    onNavigateBack: () -> Unit = {},
    syncManager: com.example.data.offline.OfflineSyncManager? = null,
    backupManager: com.example.data.backup.BackupManager? = null,
    onNavigateToSettings: (() -> Unit)? = null,
    isOnline: Boolean = true,
    showLanguageToggle: Boolean = true,
    actions: @Composable RowScope.() -> Unit = {}
) {
    var showSyncCenter by remember { mutableStateOf(false) }
    val currentLang = LocalLanguage.current
    val languageManager = LocalLanguageManager.current
    val farmProfile = com.example.data.farm.LocalFarmProfile.current

    if (showSyncCenter && syncManager != null) {
        SyncCenterDialog(
            syncManager = syncManager,
            isOnline = isOnline,
            backupManager = backupManager,
            onNavigateToSettings = onNavigateToSettings,
            onDismiss = { showSyncCenter = false }
        )
    }

    TopAppBar(
        title = {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (canNavigateBack) {
                        com.example.data.farm.FarmLogoImage(
                            logoUri = farmProfile.logoUri,
                            modifier = Modifier
                                .size(24.dp)
                                .clip(CircleShape),
                            fallbackIconSize = 14.dp,
                            contentDescription = "Farm Logo"
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                    }
                    Text(
                        text = if (title.isBlank() || title.equals("Goat Farm", ignoreCase = true) || title.equals("Tamil Nadu Goat Farm", ignoreCase = true)) farmProfile.farmName else title,
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,
                        color = Color.White,
                        maxLines = 1
                    )
                }
                syncManager?.let { sm ->
                    val syncState by sm.syncState.collectAsState()
                    val pendingCount by sm.pendingCount.collectAsState(initial = 0)
                    val isSyncing by sm.isSyncing.collectAsState()
                    val realtimeStatus by sm.realtimeStatus.collectAsState()
                    val driveStatus = backupManager?.backupStatus?.collectAsState()?.value

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .clickable { showSyncCenter = true }
                            .testTag("topbar_sync_indicator")
                    ) {
                        Box(
                            modifier = Modifier
                                .size(7.dp)
                                .clip(CircleShape)
                                .background(
                                    when {
                                        realtimeStatus == com.example.data.supabase.RealtimeStatus.SUBSCRIBED -> Color(0xFF00E676)
                                        syncState == com.example.data.offline.SyncState.SYNCED -> Color(0xFF69F0AE)
                                        syncState == com.example.data.offline.SyncState.PENDING -> FarmAmber
                                        syncState == com.example.data.offline.SyncState.OFFLINE -> Color(0xFFFFB74D)
                                        syncState == com.example.data.offline.SyncState.ERROR -> Color(0xFFFF5252)
                                        syncState == com.example.data.offline.SyncState.SYNCING -> Color(0xFF40C4FF)
                                        else -> Color(0xFF69F0AE)
                                    }
                                )
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = when {
                                syncState == com.example.data.offline.SyncState.SYNCED && realtimeStatus == com.example.data.supabase.RealtimeStatus.SUBSCRIBED -> "Live Synced 🟢"
                                syncState == com.example.data.offline.SyncState.SYNCED -> t("topbar.synced")
                                syncState == com.example.data.offline.SyncState.PENDING -> if (pendingCount > 0) "${t("topbar.pending")} ($pendingCount)" else t("topbar.pending")
                                syncState == com.example.data.offline.SyncState.OFFLINE -> if (pendingCount > 0) "${t("topbar.offline")} ($pendingCount)" else t("topbar.offline")
                                syncState == com.example.data.offline.SyncState.ERROR -> t("topbar.sync_error")
                                syncState == com.example.data.offline.SyncState.SYNCING -> t("topbar.syncing")
                                else -> t("topbar.synced")
                            },
                            style = MaterialTheme.typography.labelSmall,
                            fontSize = 11.sp,
                            color = Color.White.copy(alpha = 0.9f)
                        )

                        // Google Drive backup status indicator badge
                        if (driveStatus != null && driveStatus != com.example.data.backup.DriveBackupStatus.IDLE) {
                            Text(
                                text = " • ",
                                style = MaterialTheme.typography.labelSmall,
                                fontSize = 11.sp,
                                color = Color.White.copy(alpha = 0.6f)
                            )
                            Icon(
                                imageVector = when (driveStatus) {
                                    com.example.data.backup.DriveBackupStatus.SYNCED -> Icons.Default.CloudDone
                                    com.example.data.backup.DriveBackupStatus.PENDING -> Icons.Default.CloudQueue
                                    com.example.data.backup.DriveBackupStatus.FAILED -> Icons.Default.CloudOff
                                    com.example.data.backup.DriveBackupStatus.IN_PROGRESS -> Icons.Default.CloudSync
                                    else -> Icons.Default.Cloud
                                },
                                contentDescription = "Drive Backup",
                                tint = when (driveStatus) {
                                    com.example.data.backup.DriveBackupStatus.SYNCED -> Color(0xFF69F0AE)
                                    com.example.data.backup.DriveBackupStatus.PENDING -> FarmAmber
                                    com.example.data.backup.DriveBackupStatus.FAILED -> Color(0xFFFF5252)
                                    else -> Color.White.copy(alpha = 0.8f)
                                },
                                modifier = Modifier.size(11.dp)
                            )
                            Spacer(modifier = Modifier.width(2.dp))
                            Text(
                                text = when (driveStatus) {
                                    com.example.data.backup.DriveBackupStatus.SYNCED -> t("topbar.drive_synced")
                                    com.example.data.backup.DriveBackupStatus.PENDING -> t("topbar.drive_pending")
                                    com.example.data.backup.DriveBackupStatus.FAILED -> t("topbar.drive_failed")
                                    com.example.data.backup.DriveBackupStatus.IN_PROGRESS -> t("topbar.drive_backing_up")
                                    else -> t("topbar.drive")
                                },
                                style = MaterialTheme.typography.labelSmall,
                                fontSize = 11.sp,
                                color = Color.White.copy(alpha = 0.9f)
                            )
                        }

                        Spacer(modifier = Modifier.width(4.dp))
                        Icon(
                            imageVector = Icons.Default.KeyboardArrowDown,
                            contentDescription = t("topbar.sync_options"),
                            tint = Color.White.copy(alpha = 0.7f),
                            modifier = Modifier.size(12.dp)
                        )
                    }
                }
            }
        },
        navigationIcon = {
            if (canNavigateBack) {
                IconButton(
                    onClick = onNavigateBack,
                    modifier = Modifier.testTag("nav_back_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = t("btn.back"),
                        tint = Color.White
                    )
                }
            } else {
                Box(
                    modifier = Modifier
                        .padding(start = 12.dp, end = 4.dp)
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(Color.White.copy(alpha = 0.2f)),
                    contentAlignment = Alignment.Center
                ) {
                    com.example.data.farm.FarmLogoImage(
                        logoUri = farmProfile.logoUri,
                        modifier = Modifier.size(36.dp),
                        fallbackIconSize = 22.dp,
                        contentDescription = "Farm Logo"
                    )
                }
            }
        },
        actions = {
            if (showLanguageToggle && languageManager != null) {
                LanguageToggle(
                    currentLanguage = currentLang,
                    onLanguageChange = { languageManager.setLanguage(it) },
                    modifier = Modifier.padding(end = 4.dp),
                    isDarkHeader = true
                )
            }
            actions()
        },
        colors = TopAppBarDefaults.topAppBarColors(
            containerColor = FarmGreenDark,
            titleContentColor = Color.White,
            navigationIconContentColor = Color.White,
            actionIconContentColor = Color.White
        )
    )
}

@Composable
fun StatCard(
    title: String,
    value: String,
    icon: ImageVector,
    color: Color,
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null
) {
    Card(
        modifier = modifier
            .then(if (onClick != null) Modifier.clickable { onClick() } else Modifier),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(color.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = color,
                    modifier = Modifier.size(24.dp)
                )
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column {
                Text(
                    text = value,
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = title,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
fun TagBadge(
    tag: String,
    modifier: Modifier = Modifier,
    isBuck: Boolean = false,
    isKid: Boolean = false
) {
    val bgColor = when {
        isKid -> FarmAmberContainer
        isBuck -> FarmGreenContainer
        else -> MaterialTheme.colorScheme.secondaryContainer
    }
    val textColor = when {
        isKid -> FarmBrown
        isBuck -> FarmOnGreenContainer
        else -> MaterialTheme.colorScheme.onSecondaryContainer
    }

    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(8.dp),
        color = bgColor
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.Label,
                contentDescription = null,
                tint = textColor,
                modifier = Modifier.size(12.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = tag,
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.Bold,
                color = textColor
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GoatSelector(
    goats: List<Goat>,
    selectedGoatId: String,
    onGoatSelected: (Goat) -> Unit,
    label: String = t("weight.select_goat"),
    filterSex: String? = null,
    modifier: Modifier = Modifier
) {
    var expanded by remember { mutableStateOf(false) }
    var searchQuery by remember { mutableStateOf("") }

    val filteredGoats = remember(goats, filterSex, searchQuery) {
        goats.filter { g ->
            (filterSex == null || g.sex_c.equals(filterSex, ignoreCase = true)) &&
            (searchQuery.isEmpty() || g.tag_c.contains(searchQuery, ignoreCase = true) || g.name.contains(searchQuery, ignoreCase = true))
        }
    }

    val currentGoat = remember(goats, selectedGoatId) {
        goats.find { it.id == selectedGoatId }
    }

    Column(modifier = modifier) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelLarge,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.padding(bottom = 6.dp)
        )

        OutlinedCard(
            onClick = { expanded = true },
            modifier = Modifier
                .fillMaxWidth()
                .testTag("goat_selector_trigger"),
            shape = RoundedCornerShape(12.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                if (currentGoat != null) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        TagBadge(
                            tag = currentGoat.tag_c,
                            isBuck = currentGoat.sex_c.equals("Buck", ignoreCase = true),
                            isKid = currentGoat.sex_c.equals("Kid", ignoreCase = true)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = currentGoat.name,
                                fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.bodyLarge
                            )
                            Text(
                                text = "${currentGoat.breed_c} • ${currentGoat.sex_c}${if (currentGoat.weight_kg_c != null) " • ${currentGoat.weight_kg_c} kg" else ""}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                } else {
                    Text(
                        text = t("weight.select_goat"),
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        style = MaterialTheme.typography.bodyLarge
                    )
                }
                Icon(imageVector = Icons.Default.ArrowDropDown, contentDescription = "Expand")
            }
        }

        if (expanded) {
            AlertDialog(
                onDismissRequest = { expanded = false },
                title = { Text(t("weight.select_goat"), fontWeight = FontWeight.Bold) },
                text = {
                    Column(modifier = Modifier.fillMaxWidth().heightIn(max = 400.dp)) {
                        OutlinedTextField(
                            value = searchQuery,
                            onValueChange = { searchQuery = it },
                            placeholder = { Text(t("herd.search_placeholder")) },
                            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 8.dp)
                                .testTag("goat_selector_search")
                        )

                        if (filteredGoats.isEmpty()) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(32.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(t("herd.empty_message"), color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        } else {
                            androidx.compose.foundation.lazy.LazyColumn {
                                items(filteredGoats.size) { index ->
                                    val goat = filteredGoats[index]
                                    Card(
                                        onClick = {
                                            onGoatSelected(goat)
                                            expanded = false
                                        },
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(vertical = 4.dp),
                                        colors = CardDefaults.cardColors(
                                            containerColor = if (goat.id == selectedGoatId)
                                                MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f)
                                            else
                                                MaterialTheme.colorScheme.surface
                                        )
                                    ) {
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(12.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            TagBadge(
                                                tag = goat.tag_c,
                                                isBuck = goat.sex_c.equals("Buck", ignoreCase = true),
                                                isKid = goat.sex_c.equals("Kid", ignoreCase = true)
                                            )
                                            Spacer(modifier = Modifier.width(12.dp))
                                            Column {
                                                Text(goat.name, fontWeight = FontWeight.SemiBold)
                                                Text(
                                                    "${goat.breed_c} • ${goat.sex_c}${if (goat.weight_kg_c != null) " • ${goat.weight_kg_c} kg" else ""}",
                                                    style = MaterialTheme.typography.bodySmall,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick = { expanded = false }) {
                        Text(t("btn.close"))
                    }
                }
            )
        }
    }
}

@Composable
fun DatePickerField(
    dateValue: String,
    onDateSelected: (String) -> Unit,
    label: String = t("weight.date_label"),
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val calendar = Calendar.getInstance()
    val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)

    if (dateValue.isNotBlank()) {
        try {
            val parsed = sdf.parse(dateValue)
            if (parsed != null) calendar.time = parsed
        } catch (_: Exception) {}
    }

    val datePickerDialog = remember {
        DatePickerDialog(
            context,
            { _, year, month, dayOfMonth ->
                val cal = Calendar.getInstance()
                cal.set(year, month, dayOfMonth)
                onDateSelected(sdf.format(cal.time))
            },
            calendar.get(Calendar.YEAR),
            calendar.get(Calendar.MONTH),
            calendar.get(Calendar.DAY_OF_MONTH)
        )
    }

    OutlinedTextField(
        value = dateValue,
        onValueChange = {},
        readOnly = true,
        label = { Text(label) },
        trailingIcon = {
            IconButton(
                onClick = { datePickerDialog.show() },
                modifier = Modifier.testTag("date_picker_button")
            ) {
                Icon(Icons.Default.CalendarToday, contentDescription = t("state.select_date"))
            }
        },
        modifier = modifier
            .fillMaxWidth()
            .clickable { datePickerDialog.show() }
    )
}

@Composable
fun QuickWeightStepper(
    currentWeight: Double,
    onWeightChanged: (Double) -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        FilledTonalButton(
            onClick = { onWeightChanged((currentWeight - 1.0).coerceAtLeast(0.5)) },
            modifier = Modifier.weight(1f).height(48.dp),
            contentPadding = PaddingValues(0.dp)
        ) {
            Text("-1 kg", fontWeight = FontWeight.Bold)
        }
        FilledTonalButton(
            onClick = { onWeightChanged((currentWeight - 0.5).coerceAtLeast(0.5)) },
            modifier = Modifier.weight(1f).height(48.dp),
            contentPadding = PaddingValues(0.dp)
        ) {
            Text("-0.5", fontWeight = FontWeight.Bold)
        }
        FilledTonalButton(
            onClick = { onWeightChanged(currentWeight + 0.5) },
            modifier = Modifier.weight(1f).height(48.dp),
            contentPadding = PaddingValues(0.dp)
        ) {
            Text("+0.5", fontWeight = FontWeight.Bold)
        }
        FilledTonalButton(
            onClick = { onWeightChanged(currentWeight + 1.0) },
            modifier = Modifier.weight(1f).height(48.dp),
            contentPadding = PaddingValues(0.dp)
        ) {
            Text("+1 kg", fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun FarmBottomNavigation(
    currentRoute: String,
    onNavigateToDashboard: () -> Unit,
    onNavigateToGoats: () -> Unit,
    onNavigateToSales: () -> Unit,
    onNavigateToTasks: () -> Unit,
    onNavigateToAiEntry: () -> Unit,
    onNavigateToBreeding: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    NavigationBar(
        modifier = modifier.testTag("main_navigation_bar"),
        containerColor = Color.White,
        tonalElevation = 8.dp
    ) {
        NavigationBarItem(
            selected = currentRoute == "dashboard",
            onClick = onNavigateToDashboard,
            icon = { Icon(Icons.Default.Home, contentDescription = t("nav.home")) },
            label = { Text(t("nav.home"), fontWeight = if (currentRoute == "dashboard") FontWeight.Bold else FontWeight.Normal) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = FarmGreenDark,
                selectedTextColor = FarmGreenDark,
                indicatorColor = FarmGreenContainer,
                unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
            ),
            modifier = Modifier.testTag("nav_item_dashboard")
        )
        NavigationBarItem(
            selected = currentRoute == "goats",
            onClick = onNavigateToGoats,
            icon = { Icon(Icons.Default.Pets, contentDescription = t("nav.herd")) },
            label = { Text(t("nav.herd"), fontWeight = if (currentRoute == "goats") FontWeight.Bold else FontWeight.Normal) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = FarmGreenDark,
                selectedTextColor = FarmGreenDark,
                indicatorColor = FarmGreenContainer,
                unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
            ),
            modifier = Modifier.testTag("nav_item_goats")
        )
        NavigationBarItem(
            selected = currentRoute.startsWith("breeding") || currentRoute.startsWith("weaning") || currentRoute == "delivery",
            onClick = onNavigateToBreeding,
            icon = { Icon(Icons.Default.Favorite, contentDescription = t("nav.breeding")) },
            label = { Text(t("nav.breeding"), fontWeight = if (currentRoute.startsWith("breeding") || currentRoute.startsWith("weaning") || currentRoute == "delivery") FontWeight.Bold else FontWeight.Normal) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = FarmGreenDark,
                selectedTextColor = FarmGreenDark,
                indicatorColor = FarmGreenContainer,
                unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
            ),
            modifier = Modifier.testTag("nav_item_breeding")
        )
        NavigationBarItem(
            selected = currentRoute == "sales",
            onClick = onNavigateToSales,
            icon = { Icon(Icons.Default.MonetizationOn, contentDescription = t("nav.sales")) },
            label = { Text(t("nav.sales"), fontWeight = if (currentRoute == "sales") FontWeight.Bold else FontWeight.Normal) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = FarmGreenDark,
                selectedTextColor = FarmGreenDark,
                indicatorColor = FarmGreenContainer,
                unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
            ),
            modifier = Modifier.testTag("nav_item_sales")
        )
        NavigationBarItem(
            selected = currentRoute.startsWith("tasks_and_due"),
            onClick = onNavigateToTasks,
            icon = { Icon(Icons.Default.CheckCircle, contentDescription = t("nav.tasks")) },
            label = { Text(t("nav.tasks"), fontWeight = if (currentRoute.startsWith("tasks_and_due")) FontWeight.Bold else FontWeight.Normal) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = FarmGreenDark,
                selectedTextColor = FarmGreenDark,
                indicatorColor = FarmGreenContainer,
                unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
            ),
            modifier = Modifier.testTag("nav_item_tasks")
        )
        NavigationBarItem(
            selected = currentRoute == "ai_entry",
            onClick = onNavigateToAiEntry,
            icon = { Icon(Icons.Default.AutoAwesome, contentDescription = t("nav.ai_entry")) },
            label = { Text(t("nav.ai_entry"), fontWeight = if (currentRoute == "ai_entry") FontWeight.Bold else FontWeight.Normal) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = FarmGreenDark,
                selectedTextColor = FarmGreenDark,
                indicatorColor = FarmGreenContainer,
                unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
            ),
            modifier = Modifier.testTag("nav_item_ai_entry")
        )
    }
}

