package com.example.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.data.photo.GoatPhotoStorageHelper
import com.example.data.supabase.Goat
import com.example.data.supabase.GoatRepository
import com.example.data.supabase.QuarantineRecord
import com.example.data.pedigree.AnimalOrigin
import com.example.i18n.t
import com.example.ui.components.DatePickerField
import com.example.ui.components.FarmTopBar
import com.example.ui.theme.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.io.File
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddGoatScreen(
    repository: GoatRepository,
    onNavigateBack: () -> Unit,
    onGoatSaved: () -> Unit,
    initialBreed: String? = null
) {
    BackHandler { onNavigateBack() }

    val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.US)
    val today = remember { dateFormat.format(Date()) }

    var name by remember { mutableStateOf("") }
    var tag by remember { mutableStateOf("") }
    var breed by remember { mutableStateOf(initialBreed ?: "Salem Karupu") }
    var sex by remember { mutableStateOf("Doe") }
    var status by remember { mutableStateOf("Active") }
    var birthDate by remember { mutableStateOf("") }
    var weightStr by remember { mutableStateOf("") }
    var dam by remember { mutableStateOf("") }
    var sire by remember { mutableStateOf("") }
    var origin by remember { mutableStateOf(AnimalOrigin.FARM_BORN) }
    var source by remember { mutableStateOf("BORN ON FARM") }
    var purchaseDate by remember { mutableStateOf(today) }
    var purchaseCostStr by remember { mutableStateOf("") }
    var farmLocation by remember { mutableStateOf("Barn A") }
    var color by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }
    var photoUrl by remember { mutableStateOf("") }
    var tempCameraFile by remember { mutableStateOf<File?>(null) }

    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    val cameraLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.TakePicture()
    ) { success ->
        if (success && tempCameraFile != null && tempCameraFile!!.exists() && tempCameraFile!!.length() > 0) {
            photoUrl = tempCameraFile!!.absolutePath
        } else {
            tempCameraFile?.delete()
            tempCameraFile = null
        }
    }

    val cameraPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            try {
                val file = GoatPhotoStorageHelper.createCameraOutputFile(context, tag.ifBlank { "new_goat" })
                val uri = GoatPhotoStorageHelper.getFileUri(context, file)
                tempCameraFile = file
                cameraLauncher.launch(uri)
            } catch (e: Exception) {
                Toast.makeText(context, "Cannot open camera: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
            }
        } else {
            Toast.makeText(context, "Camera permission needed to take goat photo", Toast.LENGTH_SHORT).show()
        }
    }

    fun launchCamera() {
        val hasPermission = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.CAMERA
        ) == PackageManager.PERMISSION_GRANTED
        if (hasPermission) {
            try {
                val file = GoatPhotoStorageHelper.createCameraOutputFile(context, tag.ifBlank { "new_goat" })
                val uri = GoatPhotoStorageHelper.getFileUri(context, file)
                tempCameraFile = file
                cameraLauncher.launch(uri)
            } catch (e: Exception) {
                Toast.makeText(context, "Cannot open camera: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
            }
        } else {
            cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
        }
    }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            coroutineScope.launch(Dispatchers.IO) {
                val file = GoatPhotoStorageHelper.saveImageUriToPermanentStorage(context, uri, tag.ifBlank { "new_goat" })
                if (file != null) {
                    photoUrl = file.absolutePath
                }
            }
        }
    }

    // Quarantine Workflow variables (Requirements 10-13, 17)
    var isQuarantineRequired by remember { mutableStateOf(false) }
    var quarantineLocation by remember { mutableStateOf("Isolation Pen Q1") }
    var sellerName by remember { mutableStateOf("") }
    var sellerContact by remember { mutableStateOf("") }
    var sourceMarketLocation by remember { mutableStateOf("Livestock Shandy / Market") }
    var initialHealthAssessment by remember { mutableStateOf("Under Observation") }
    var initialTempStr by remember { mutableStateOf("102.5") }
    var sellerReportedHealthHistory by remember { mutableStateOf("") }

    val quarantineCal = remember {
        Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, 21) }
    }
    val defaultPlannedEnd = remember { SimpleDateFormat("yyyy-MM-dd", Locale.US).format(quarantineCal.time) }
    var plannedQuarantineEndDate by remember { mutableStateOf(defaultPlannedEnd) }

    var herdGoats by remember { mutableStateOf<List<Goat>>(emptyList()) }
    LaunchedEffect(Unit) {
        val res = repository.getGoats()
        if (res.isSuccess) {
            herdGoats = res.getOrThrow()
        }
    }

    var isSaving by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var showSuccessDialog by remember { mutableStateOf(false) }

    val breeds = listOf("Salem Karupu", "Kodi Adu", "Boer", "Jamnapari", "Barbari", "Sirohi", "Saanen", "Nubian", "Alpine", "Beetal", "Kalahari Red", "Cross")
    val sexes = listOf("Doe", "Buck", "Kid", "Wether")
    val statuses = listOf("Active", "Pregnant", "Lactating", "Quarantine", "Sold")
    val sources = listOf("OWN FARM", "BORN ON FARM", "MARKET PURCHASE", "OTHER FARM", "TRANSFER", "OTHER")

    Scaffold(
        topBar = {
            FarmTopBar(
                title = t("add_goat.title_new"),
                canNavigateBack = true,
                onNavigateBack = onNavigateBack
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(FarmBackgroundLight)
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Goat Photo Capture Section
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Goat Photo (Device Camera / Gallery)",
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.titleMedium,
                            color = FarmGreenDark
                        )
                        if (photoUrl.isNotBlank()) {
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = FarmGreenContainer,
                                contentColor = FarmGreenDark
                            ) {
                                Text(
                                    text = "PHOTO ATTACHED",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                    }

                    if (photoUrl.isNotBlank()) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(190.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color.Black)
                        ) {
                            AsyncImage(
                                model = ImageRequest.Builder(context)
                                    .data(File(photoUrl))
                                    .crossfade(true)
                                    .build(),
                                contentDescription = "Captured Goat Photo Preview",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )

                            Surface(
                                modifier = Modifier
                                    .align(Alignment.TopEnd)
                                    .padding(8.dp),
                                shape = CircleShape,
                                color = Color.Black.copy(alpha = 0.6f)
                            ) {
                                IconButton(
                                    onClick = {
                                        GoatPhotoStorageHelper.deletePhotoFile(photoUrl)
                                        photoUrl = ""
                                    },
                                    modifier = Modifier.size(36.dp)
                                ) {
                                    Icon(
                                        Icons.Default.Delete,
                                        contentDescription = "Remove Photo",
                                        tint = Color.White,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedButton(
                                onClick = { launchCamera() },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("add_goat_retake_camera_btn"),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Icon(Icons.Default.PhotoCamera, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Retake Photo", fontSize = 13.sp)
                            }
                            OutlinedButton(
                                onClick = {
                                    photoPickerLauncher.launch(
                                        androidx.activity.result.PickVisualMediaRequest(
                                            ActivityResultContracts.PickVisualMedia.ImageOnly
                                        )
                                    )
                                },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Icon(Icons.Default.PhotoLibrary, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Choose Gallery", fontSize = 13.sp)
                            }
                        }
                    } else {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Button(
                                onClick = { launchCamera() },
                                modifier = Modifier
                                    .weight(1.3f)
                                    .height(48.dp)
                                    .testTag("add_goat_camera_btn"),
                                colors = ButtonDefaults.buttonColors(containerColor = FarmGreenPrimary),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Icon(Icons.Default.PhotoCamera, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Capture Photo", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            }

                            OutlinedButton(
                                onClick = {
                                    photoPickerLauncher.launch(
                                        androidx.activity.result.PickVisualMediaRequest(
                                            ActivityResultContracts.PickVisualMedia.ImageOnly
                                        )
                                    )
                                },
                                modifier = Modifier
                                    .weight(1f)
                                    .height(48.dp)
                                    .testTag("add_goat_gallery_btn"),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Icon(Icons.Default.PhotoLibrary, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("From Gallery", fontSize = 13.sp)
                            }
                        }
                    }
                }
            }

            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = t("add_goat.section_basic"),
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleMedium,
                        color = FarmGreenDark
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        OutlinedTextField(
                            value = tag,
                            onValueChange = { tag = it.uppercase(); errorMessage = null },
                            label = { Text(t("add_goat.tag_id_label")) },
                            placeholder = { Text(t("add_goat.tag_id_hint")) },
                            singleLine = true,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("add_goat_tag_input")
                        )
                        OutlinedTextField(
                            value = name,
                            onValueChange = { name = it; errorMessage = null },
                            label = { Text(t("add_goat.name_label")) },
                            placeholder = { Text(t("add_goat.name_hint")) },
                            singleLine = true,
                            modifier = Modifier
                                .weight(1.2f)
                                .testTag("add_goat_name_input")
                        )
                    }

                    // Sex Selection
                    Text(t("add_goat.sex_label"), style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.SemiBold)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        sexes.forEach { s ->
                            val sexLabel = when (s) {
                                "Doe" -> t("herd.doe")
                                "Buck" -> t("herd.buck")
                                "Kid" -> t("herd.kid")
                                else -> s
                            }
                            FilterChip(
                                selected = sex == s,
                                onClick = { sex = s },
                                label = { Text(sexLabel) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = FarmGreenPrimary,
                                    selectedLabelColor = Color.White
                                ),
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }

                    // Breed Dropdown
                    var breedExpanded by remember { mutableStateOf(false) }
                    ExposedDropdownMenuBox(
                        expanded = breedExpanded,
                        onExpandedChange = { breedExpanded = !breedExpanded }
                    ) {
                        OutlinedTextField(
                            value = breed,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text(t("add_goat.breed_label")) },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = breedExpanded) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .menuAnchor()
                                .testTag("add_goat_breed_input")
                        )
                        ExposedDropdownMenu(
                            expanded = breedExpanded,
                            onDismissRequest = { breedExpanded = false }
                        ) {
                            breeds.forEach { b ->
                                DropdownMenuItem(
                                    text = { Text(b) },
                                    onClick = {
                                        breed = b
                                        breedExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    // Status Dropdown
                    var statusExpanded by remember { mutableStateOf(false) }
                    ExposedDropdownMenuBox(
                        expanded = statusExpanded,
                        onExpandedChange = { statusExpanded = !statusExpanded }
                    ) {
                        val statusLabel = when (status) {
                            "Active" -> t("herd.active")
                            "Sold" -> t("herd.sold")
                            "Pregnant" -> t("breeding.pregnant")
                            else -> status
                        }
                        OutlinedTextField(
                            value = statusLabel,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text(t("herd.status") + " *") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = statusExpanded) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .menuAnchor()
                                .testTag("add_goat_status_input")
                        )
                        ExposedDropdownMenu(
                            expanded = statusExpanded,
                            onDismissRequest = { statusExpanded = false }
                        ) {
                            statuses.forEach { st ->
                                val stLabel = when (st) {
                                    "Active" -> t("herd.active")
                                    "Sold" -> t("herd.sold")
                                    "Pregnant" -> t("breeding.pregnant")
                                    else -> st
                                }
                                DropdownMenuItem(
                                    text = { Text(stLabel) },
                                    onClick = {
                                        status = st
                                        statusExpanded = false
                                    }
                                )
                            }
                        }
                    }
                }
            }

            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = t("herd.details_title"),
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleMedium,
                        color = FarmGreenDark
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        OutlinedTextField(
                            value = weightStr,
                            onValueChange = { weightStr = it },
                            label = { Text(t("add_goat.weight_label")) },
                            placeholder = { Text(t("add_goat.weight_hint")) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            singleLine = true,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("add_goat_weight_input")
                        )

                        DatePickerField(
                            dateValue = birthDate,
                            onDateSelected = { birthDate = it },
                            label = t("add_goat.dob_label"),
                            modifier = Modifier
                                .weight(1.2f)
                                .testTag("add_goat_birth_date_input")
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        OutlinedTextField(
                            value = farmLocation,
                            onValueChange = { farmLocation = it },
                            label = { Text(t("fodder.plot")) },
                            placeholder = { Text("e.g. Pen B") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = color,
                            onValueChange = { color = it },
                            label = { Text(t("herd.notes")) },
                            placeholder = { Text("e.g. Brown & White") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }

            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = t("pedigree.lineage"),
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleMedium,
                        color = FarmGreenDark
                    )

                    // Source & Origin Selection (Requirement 10: Ask SOURCE: OWN FARM, BORN ON FARM, MARKET PURCHASE, OTHER FARM, TRANSFER, OTHER)
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            text = "SOURCE *",
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.SemiBold
                        )

                        // Source selection chips
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            sources.take(3).forEach { s ->
                                FilterChip(
                                    selected = source == s,
                                    onClick = {
                                        source = s
                                        if (s == "MARKET PURCHASE") {
                                            origin = AnimalOrigin.MARKET_BOUGHT
                                            isQuarantineRequired = true
                                            status = "Quarantine"
                                        } else if (s == "BORN ON FARM" || s == "OWN FARM") {
                                            origin = AnimalOrigin.FARM_BORN
                                            isQuarantineRequired = false
                                            if (status == "Quarantine") status = "Active"
                                        } else {
                                            origin = AnimalOrigin.MARKET_BOUGHT
                                            isQuarantineRequired = false
                                            if (status == "Quarantine") status = "Active"
                                        }
                                    },
                                    label = { Text(s, fontSize = 10.sp) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = if (s == "MARKET PURCHASE") Color(0xFFD97706) else FarmGreenPrimary,
                                        selectedLabelColor = Color.White
                                    ),
                                    modifier = Modifier.weight(1f).testTag("source_chip_${s.lowercase().replace(" ", "_")}")
                                )
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            sources.drop(3).forEach { s ->
                                FilterChip(
                                    selected = source == s,
                                    onClick = {
                                        source = s
                                        if (s == "MARKET PURCHASE") {
                                            origin = AnimalOrigin.MARKET_BOUGHT
                                            isQuarantineRequired = true
                                            status = "Quarantine"
                                        } else {
                                            origin = AnimalOrigin.MARKET_BOUGHT
                                            isQuarantineRequired = false
                                            if (status == "Quarantine") status = "Active"
                                        }
                                    },
                                    label = { Text(s, fontSize = 10.sp) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = FarmGreenPrimary,
                                        selectedLabelColor = Color.White
                                    ),
                                    modifier = Modifier.weight(1f).testTag("source_chip_${s.lowercase().replace(" ", "_")}")
                                )
                            }
                        }
                    }

                    // Requirement 10: If MARKET PURCHASE, automatically activate QUARANTINE REQUIRED
                    if (source == "MARKET PURCHASE" || isQuarantineRequired) {
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = Color(0xFFFEF3C7),
                            border = androidx.compose.foundation.BorderStroke(1.5.dp, Color(0xFFF59E0B)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Security, contentDescription = null, tint = Color(0xFFB45309), modifier = Modifier.size(22.dp))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "QUARANTINE REQUIRED (Biosecurity Protocol)",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp,
                                        color = Color(0xFF92400E)
                                    )
                                }
                                Text(
                                    text = "This goat CANNOT be integrated into the active herd or included in breeding until quarantine observation and clinical clearance are completed.",
                                    fontSize = 11.sp,
                                    color = Color(0xFF78350F)
                                )

                                HorizontalDivider(color = Color(0xFFFDE68A))

                                OutlinedTextField(
                                    value = quarantineLocation,
                                    onValueChange = { quarantineLocation = it },
                                    label = { Text("Isolation Pen / Facility *") },
                                    placeholder = { Text("e.g. Isolation Pen Q1, North Barn") },
                                    modifier = Modifier.fillMaxWidth()
                                )

                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    DatePickerField(
                                        dateValue = purchaseDate,
                                        onDateSelected = { purchaseDate = it },
                                        label = "Intake Date",
                                        modifier = Modifier.weight(1f)
                                    )
                                    DatePickerField(
                                        dateValue = plannedQuarantineEndDate,
                                        onDateSelected = { plannedQuarantineEndDate = it },
                                        label = "Planned Clearance (21d)",
                                        modifier = Modifier.weight(1f)
                                    )
                                }

                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    OutlinedTextField(
                                        value = sellerName,
                                        onValueChange = { sellerName = it },
                                        label = { Text("Seller / Vendor") },
                                        modifier = Modifier.weight(1f)
                                    )
                                    OutlinedTextField(
                                        value = sellerContact,
                                        onValueChange = { sellerContact = it },
                                        label = { Text("Seller Contact Phone") },
                                        modifier = Modifier.weight(1f)
                                    )
                                }

                                OutlinedTextField(
                                    value = sourceMarketLocation,
                                    onValueChange = { sourceMarketLocation = it },
                                    label = { Text("Market / Shandy Location") },
                                    modifier = Modifier.fillMaxWidth()
                                )

                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    OutlinedTextField(
                                        value = initialHealthAssessment,
                                        onValueChange = { initialHealthAssessment = it },
                                        label = { Text("Initial Assessment (Not Auto-Healthy)") },
                                        modifier = Modifier.weight(1.2f)
                                    )
                                    OutlinedTextField(
                                        value = initialTempStr,
                                        onValueChange = { initialTempStr = it },
                                        label = { Text("Temp (°F)") },
                                        modifier = Modifier.weight(0.8f)
                                    )
                                }

                                OutlinedTextField(
                                    value = sellerReportedHealthHistory,
                                    onValueChange = { sellerReportedHealthHistory = it },
                                    label = { Text("Seller-Reported Vaccination/Deworming") },
                                    placeholder = { Text("Stored as HISTORICAL / SELLER-REPORTED (not farm-administered)") },
                                    modifier = Modifier.fillMaxWidth(),
                                    minLines = 2
                                )
                            }
                        }
                    }

                    if (origin == AnimalOrigin.FARM_BORN) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = FarmGreenContainer.copy(alpha = 0.5f),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "Farm-born goat: Maintain known Sire & Dam for pedigree tracking.",
                                style = MaterialTheme.typography.bodySmall,
                                color = FarmGreenDark,
                                modifier = Modifier.padding(10.dp)
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            OutlinedTextField(
                                value = dam,
                                onValueChange = { dam = it },
                                label = { Text(t("add_goat.dam_label")) },
                                placeholder = { Text("e.g. G045") },
                                singleLine = true,
                                modifier = Modifier.weight(1f).testTag("dam_input")
                            )
                            OutlinedTextField(
                                value = sire,
                                onValueChange = { sire = it },
                                label = { Text(t("add_goat.sire_label")) },
                                placeholder = { Text("e.g. B010") },
                                singleLine = true,
                                modifier = Modifier.weight(1f).testTag("sire_input")
                            )
                        }

                        // Quick suggestion chips for herd does and bucks
                        val potentialDams = remember(herdGoats) { herdGoats.filter { it.sex_c.equals("Doe", ignoreCase = true) }.take(4) }
                        val potentialSires = remember(herdGoats) { herdGoats.filter { it.sex_c.equals("Buck", ignoreCase = true) }.take(4) }

                        if (potentialDams.isNotEmpty() && dam.isBlank()) {
                            Text("Suggested Does (Dam):", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                potentialDams.forEach { d ->
                                    SuggestionChip(
                                        onClick = { dam = d.tag_c },
                                        label = { Text("${d.tag_c} (${d.breed_c})", fontSize = 11.sp) }
                                    )
                                }
                            }
                        }

                        if (potentialSires.isNotEmpty() && sire.isBlank()) {
                            Text("Suggested Bucks (Sire):", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                potentialSires.forEach { s ->
                                    SuggestionChip(
                                        onClick = { sire = s.tag_c },
                                        label = { Text("${s.tag_c} (${s.breed_c})", fontSize = 11.sp) }
                                    )
                                }
                            }
                        }
                    } else {
                        // Market-bought
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = Color(0xFFE3F2FD),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "Market-bought goat: Pedigree not required. Parents remain Unknown unless recorded.",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color(0xFF0D47A1),
                                modifier = Modifier.padding(10.dp)
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            DatePickerField(
                                dateValue = purchaseDate,
                                onDateSelected = { purchaseDate = it },
                                label = t("purchases.date"),
                                modifier = Modifier.weight(1f)
                            )
                            OutlinedTextField(
                                value = purchaseCostStr,
                                onValueChange = { purchaseCostStr = it },
                                label = { Text(t("expenses.cost") + " (₹)") },
                                placeholder = { Text("e.g. 8500") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                                singleLine = true,
                                modifier = Modifier.weight(1f)
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            OutlinedTextField(
                                value = dam,
                                onValueChange = { dam = it },
                                label = { Text("${t("add_goat.dam_label")} (Optional)") },
                                placeholder = { Text("Leave blank if Unknown") },
                                singleLine = true,
                                modifier = Modifier.weight(1f)
                            )
                            OutlinedTextField(
                                value = sire,
                                onValueChange = { sire = it },
                                label = { Text("${t("add_goat.sire_label")} (Optional)") },
                                placeholder = { Text("Leave blank if Unknown") },
                                singleLine = true,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }

                    OutlinedTextField(
                        value = notes,
                        onValueChange = { notes = it },
                        label = { Text(t("add_goat.notes_label")) },
                        placeholder = { Text("Temperament, ear notch, vaccinations, etc.") },
                        modifier = Modifier.fillMaxWidth(),
                        minLines = 2,
                        maxLines = 4
                    )
                }
            }

            if (errorMessage != null) {
                Card(colors = CardDefaults.cardColors(containerColor = FarmErrorContainer)) {
                    Text(
                        text = errorMessage ?: "",
                        color = FarmError,
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier.padding(12.dp)
                    )
                }
            }

            val tagRequiredError = t("add_goat.tag_id_required")

            Button(
                onClick = {
                    if (tag.isBlank()) {
                        errorMessage = tagRequiredError
                        return@Button
                    }
                    if (name.isBlank()) {
                        name = "Goat $tag"
                    }
                    val weightKg = weightStr.toDoubleOrNull()
                    val purchaseCost = purchaseCostStr.toDoubleOrNull()

                    val isMarket = source == "MARKET PURCHASE"
                    val finalStatus = if (isMarket) "Quarantine" else status
                    val finalHealthStatus = if (isMarket) "Under Observation" else "Healthy"

                    val combinedNotes = buildString {
                        if (!notes.isBlank()) append(notes.trim())
                        if (isMarket && sellerReportedHealthHistory.isNotBlank()) {
                            if (isNotEmpty()) append(" | ")
                            append("[HISTORICAL / SELLER-REPORTED: $sellerReportedHealthHistory]")
                        }
                    }

                    val newGoat = Goat(
                        name = name.trim(),
                        tag_c = tag.trim(),
                        breed_c = breed,
                        sex_c = sex,
                        status_c = finalStatus,
                        birth_date_c = birthDate.ifBlank { null },
                        weight_kg_c = weightKg,
                        dam_c = dam.ifBlank { null },
                        sire_c = sire.ifBlank { null },
                        source_c = source,
                        purchase_date_c = purchaseDate.ifBlank { null },
                        purchase_cost_c = purchaseCost,
                        farm_location_c = if (isMarket) quarantineLocation else farmLocation.ifBlank { null },
                        color_c = color.ifBlank { null },
                        notes_c = combinedNotes.ifBlank { null },
                        origin_c = origin,
                        photo_url_c = photoUrl.ifBlank { null },
                        health_status_c = finalHealthStatus
                    )

                    isSaving = true
                    errorMessage = null
                    coroutineScope.launch {
                        val res = repository.addGoat(newGoat)
                        if (res.isSuccess) {
                            val createdGoat = res.getOrThrow()

                            // Save photo into local_goat_photos if captured
                            if (photoUrl.isNotBlank()) {
                                repository.saveGoatPhotoRecord(
                                    goatId = createdGoat.id,
                                    photoUri = photoUrl,
                                    title = "${createdGoat.tag_c} Profile Photo",
                                    category = "Profile",
                                    notes = "Captured during registration",
                                    isPrimary = true
                                )
                            }

                            // Requirement 11 & 17: Automatically create Quarantine Record for market purchase
                            if (isMarket) {
                                val qRecord = QuarantineRecord(
                                    goat_id = createdGoat.id,
                                    goat_tag = createdGoat.tag_c,
                                    goat_name = createdGoat.name,
                                    start_date = purchaseDate.ifBlank { today },
                                    planned_end_date = plannedQuarantineEndDate,
                                    isolation_location = quarantineLocation,
                                    source_location = sourceMarketLocation.ifBlank { null },
                                    seller_name = sellerName.ifBlank { null },
                                    seller_contact = sellerContact.ifBlank { null },
                                    initial_health_status = initialHealthAssessment,
                                    temperature = initialTempStr.toDoubleOrNull(),
                                    weight = weightKg,
                                    status = "QUARANTINE",
                                    notes = if (sellerReportedHealthHistory.isNotBlank()) "Seller-reported: $sellerReportedHealthHistory" else null
                                )
                                repository.saveQuarantineRecord(qRecord)
                            }
                            isSaving = false
                            showSuccessDialog = true
                        } else {
                            isSaving = false
                            errorMessage = res.exceptionOrNull()?.message ?: "Failed to save goat"
                        }
                    }
                },
                enabled = !isSaving,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp)
                    .testTag("save_goat_button"),
                colors = ButtonDefaults.buttonColors(containerColor = FarmGreenPrimary),
                shape = RoundedCornerShape(12.dp)
            ) {
                if (isSaving) {
                    CircularProgressIndicator(color = Color.White, modifier = Modifier.size(24.dp))
                } else {
                    Text(t("add_goat.btn_save"), fontSize = 16.sp, fontWeight = FontWeight.Bold)
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }

    if (showSuccessDialog) {
        AlertDialog(
            onDismissRequest = {
                showSuccessDialog = false
                onGoatSaved()
            },
            icon = {
                Icon(
                    imageVector = Icons.Default.CheckCircle,
                    contentDescription = null,
                    tint = FarmSuccess,
                    modifier = Modifier.size(48.dp)
                )
            },
            title = { Text(t("add_goat.success_saved"), fontWeight = FontWeight.Bold) },
            text = { Text("Goat $name ($tag)") },
            confirmButton = {
                Button(
                    onClick = {
                        showSuccessDialog = false
                        onGoatSaved()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = FarmGreenPrimary)
                ) {
                    Text(t("herd.title"))
                }
            }
        )
    }
}
