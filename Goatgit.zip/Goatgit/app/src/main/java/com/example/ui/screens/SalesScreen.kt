package com.example.ui.screens

import android.content.Context
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.payment.*
import com.example.data.supabase.*
import com.example.i18n.t
import com.example.ui.components.*
import com.example.ui.screens.sales.AddCustomerDialog
import com.example.ui.screens.sales.CustomerSearchSelectionDialog
import com.example.ui.screens.sales.CustomersCreditView
import com.example.ui.screens.sales.DeliveryManagementView
import com.example.ui.screens.sales.PaytmGatewayCheckoutDialog
import com.example.ui.screens.sales.RecordCreditPaymentDialog
import com.example.ui.screens.sales.SaleReceiptDialog
import com.example.ui.screens.sales.SmsReconciliationView
import com.example.ui.theme.*
import com.example.util.CurrencyUtils
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SalesScreen(
    repository: GoatRepository,
    onNavigateBack: () -> Unit,
    onNavigateToDashboard: () -> Unit = {},
    onNavigateToGoats: () -> Unit = {},
    onNavigateToTasks: () -> Unit = {},
    onNavigateToAiEntry: () -> Unit = {},
    onNavigateToBreeding: () -> Unit = {}
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val dateFormat = remember { SimpleDateFormat("yyyy-MM-dd", Locale.US) }
    val today = remember { dateFormat.format(Date()) }

    val paymentSettings = remember { PaymentSettingsManager.getInstance(context) }
    val paytmService = remember {
        PaytmService(
            config = SupabaseConfig(context),
            settingsManager = paymentSettings
        )
    }
    val smsManager = remember {
        SmsReconciliationManager(context, com.example.data.offline.AppDatabase.getDatabase(context))
    }

    var selectedMainTab by remember { mutableStateOf(0) } // 0: Sales, 1: Credit & Udhaar, 2: Customers, 3: SMS Reconcile
    var sales by remember { mutableStateOf<List<SaleRecord>>(emptyList()) }
    var customers by remember { mutableStateOf<List<CustomerRecord>>(emptyList()) }
    var goatsMap by remember { mutableStateOf<Map<String, Goat>>(emptyMap()) }
    var unsoldGoats by remember { mutableStateOf<List<Goat>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var selectedFilter by remember { mutableStateOf("All") } // All, PAID, PARTIAL, UNPAID, PENDING, FAILED

    var showRecordSaleDialog by remember { mutableStateOf(false) }
    var saleForReceipt by remember { mutableStateOf<SaleRecord?>(null) }
    var saleForCreditPayment by remember { mutableStateOf<SaleRecord?>(null) }
    var saleToConfirmUpi by remember { mutableStateOf<SaleRecord?>(null) }
    var upiReferenceInput by remember { mutableStateOf("") }
    var confirmingUpi by remember { mutableStateOf(false) }

    // Active Paytm checkout session
    var paytmCheckoutSale by remember { mutableStateOf<SaleRecord?>(null) }

    val isOnline = repository.syncManager.syncState.collectAsState().value != com.example.data.offline.SyncState.OFFLINE

    fun loadData() {
        isLoading = true
        errorMessage = null
        coroutineScope.launch {
            val goatsRes = repository.getGoats()
            if (goatsRes.isSuccess) {
                goatsMap = goatsRes.getOrThrow().associateBy { it.id }
            }

            val unsoldRes = repository.getUnsoldGoats()
            if (unsoldRes.isSuccess) {
                unsoldGoats = unsoldRes.getOrThrow()
            }

            val salesRes = repository.getSales()
            if (salesRes.isSuccess) {
                sales = salesRes.getOrThrow()
            } else {
                errorMessage = salesRes.exceptionOrNull()?.message ?: "Failed to load sales"
            }

            val custRes = repository.getCustomers()
            if (custRes.isSuccess) {
                customers = custRes.getOrThrow()
            }
            isLoading = false
        }
    }

    LaunchedEffect(Unit) {
        loadData()
    }

    // Payment & Credit Metrics
    val todaySales = remember(sales, today) {
        sales.filter { it.sale_date_c == today && PaymentStatus.isPaid(it.payment_status_c) }.sumOf { it.amount_c }
    }
    val cashReceived = remember(sales) {
        sales.filter {
            PaymentMethod.normalize(it.payment_mode_c) == PaymentMethod.CASH &&
                    PaymentStatus.isPaid(it.payment_status_c)
        }.sumOf { it.amount_c }
    }
    val upiReceived = remember(sales) {
        sales.filter {
            PaymentMethod.normalize(it.payment_mode_c) == PaymentMethod.UPI_QR &&
                    PaymentStatus.isPaid(it.payment_status_c)
        }.sumOf { it.amount_c }
    }
    val paytmReceived = remember(sales) {
        sales.filter {
            PaymentMethod.normalize(it.payment_mode_c) == PaymentMethod.PAYTM_GATEWAY &&
                    PaymentStatus.isPaid(it.payment_status_c)
        }.sumOf { it.amount_c }
    }
    val totalCreditBalance = remember(sales) {
        sales.sumOf { it.balance_due_c }
    }
    val pendingTotal = remember(sales) {
        sales.filter { PaymentStatus.normalize(it.payment_status_c) == PaymentStatus.PENDING }.sumOf { it.amount_c }
    }
    val grandTotalPaid = remember(sales) {
        sales.sumOf {
            if (it.amount_paid_c > 0) it.amount_paid_c
            else if (PaymentStatus.isPaid(it.payment_status_c)) it.amount_c
            else 0.0
        }
    }

    val creditSales = remember(sales) {
        sales.filter { it.balance_due_c > 0 || PaymentMethod.normalize(it.payment_mode_c) == PaymentMethod.CREDIT }
    }

    val filteredSales = remember(sales, selectedFilter) {
        when (selectedFilter) {
            "PAID" -> sales.filter { PaymentStatus.isPaid(it.payment_status_c) }
            "PARTIAL" -> sales.filter { PaymentStatus.normalize(it.payment_status_c) == PaymentStatus.PARTIALLY_PAID }
            "UNPAID" -> sales.filter { PaymentStatus.normalize(it.payment_status_c) == PaymentStatus.UNPAID }
            "PENDING" -> sales.filter { PaymentStatus.normalize(it.payment_status_c) == PaymentStatus.PENDING }
            "FAILED" -> sales.filter {
                val s = PaymentStatus.normalize(it.payment_status_c)
                s == PaymentStatus.FAILED || s == PaymentStatus.CANCELLED
            }
            else -> sales
        }
    }

    Scaffold(
        topBar = {
            FarmTopBar(
                title = t("sales.title"),
                canNavigateBack = true,
                onNavigateBack = onNavigateBack,
                syncManager = repository.syncManager,
                actions = {
                    IconButton(
                        onClick = { loadData() },
                        modifier = Modifier.testTag("refresh_sales_btn")
                    ) {
                        Icon(Icons.Default.Refresh, contentDescription = t("topbar.refresh"), tint = Color.White)
                    }
                }
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { showRecordSaleDialog = true },
                icon = { Icon(Icons.Default.AddShoppingCart, contentDescription = null) },
                text = { Text(t("sales.record_sale"), fontWeight = FontWeight.Bold) },
                containerColor = FarmGreenDark,
                contentColor = Color.White,
                modifier = Modifier.testTag("fab_record_sale")
            )
        },
        bottomBar = {
            FarmBottomNavigation(
                currentRoute = "sales",
                onNavigateToDashboard = onNavigateToDashboard,
                onNavigateToGoats = onNavigateToGoats,
                onNavigateToBreeding = onNavigateToBreeding,
                onNavigateToSales = {},
                onNavigateToTasks = onNavigateToTasks,
                onNavigateToAiEntry = onNavigateToAiEntry
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(FarmBackgroundLight)
                .padding(padding)
        ) {
            // Main Top Tabs: Sales | Deliveries | Credit & Udhaar | Customers | SMS Reconcile
            ScrollableTabRow(
                selectedTabIndex = selectedMainTab,
                containerColor = Color.White,
                contentColor = FarmGreenDark,
                edgePadding = 12.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Tab(
                    selected = selectedMainTab == 0,
                    onClick = { selectedMainTab = 0 },
                    text = { Text("Sales (${sales.size})", fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                )
                Tab(
                    selected = selectedMainTab == 1,
                    onClick = { selectedMainTab = 1 },
                    text = {
                        val pendingDelivCount = sales.count { it.delivery_status_c != "DELIVERED" }
                        Text(
                            text = if (pendingDelivCount > 0) "Deliveries ($pendingDelivCount)" else "Deliveries",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (pendingDelivCount > 0) Color(0xFF0284C7) else Color.Unspecified
                        )
                    }
                )
                Tab(
                    selected = selectedMainTab == 2,
                    onClick = { selectedMainTab = 2 },
                    text = {
                        val activeBalCount = creditSales.count { it.balance_due_c > 0 }
                        Text(
                            text = if (activeBalCount > 0) "Credit ($activeBalCount)" else "Credit",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (activeBalCount > 0) Color(0xFFDC2626) else Color.Unspecified
                        )
                    }
                )
                Tab(
                    selected = selectedMainTab == 3,
                    onClick = { selectedMainTab = 3 },
                    text = { Text("Customers (${customers.size})", fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                )
                Tab(
                    selected = selectedMainTab == 4,
                    onClick = { selectedMainTab = 4 },
                    text = { Text("SMS Match", fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                )
            }

            when (selectedMainTab) {
                0 -> {
                    // ==========================================
                    // SALES HISTORY TAB
                    // ==========================================
                    Column(modifier = Modifier.fillMaxSize()) {
                        // Summary Metric Cards
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            // Grand Total Revenue Card (Formatted as ₹)
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("stat_total_sales"),
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(containerColor = FarmGreenDark)
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(16.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column {
                                        Text(
                                            text = t("sales.total_revenue"),
                                            style = MaterialTheme.typography.bodyMedium,
                                            color = Color.White.copy(alpha = 0.8f)
                                        )
                                        Text(
                                            text = CurrencyUtils.formatInr(grandTotalPaid),
                                            style = MaterialTheme.typography.headlineMedium,
                                            fontWeight = FontWeight.Bold,
                                            color = Color.White
                                        )
                                        Text(
                                            text = "${sales.size} ${t("sales.goats_sold")} • Balance Due: ${CurrencyUtils.formatInr(totalCreditBalance)}",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = Color.White.copy(alpha = 0.9f)
                                        )
                                    }
                                    Box(
                                        modifier = Modifier
                                            .size(50.dp)
                                            .clip(CircleShape)
                                            .background(Color.White.copy(alpha = 0.2f)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = "₹",
                                            fontSize = 28.sp,
                                            fontWeight = FontWeight.ExtraBold,
                                            color = Color.White
                                        )
                                    }
                                }
                            }

                            // Payment Methods Breakdown Row: Cash | UPI / QR | Paytm Gateway | Udhaar
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                PaymentStatChip(
                                    title = "Cash",
                                    amount = cashReceived,
                                    icon = Icons.Default.AccountBalanceWallet,
                                    color = Color(0xFF2E7D32),
                                    modifier = Modifier.weight(1f)
                                )
                                PaymentStatChip(
                                    title = "UPI / QR",
                                    amount = upiReceived,
                                    icon = Icons.Default.QrCode,
                                    color = PaytmCyan,
                                    modifier = Modifier.weight(1.1f)
                                )
                                PaymentStatChip(
                                    title = "Paytm",
                                    amount = paytmReceived,
                                    icon = Icons.Default.PhoneAndroid,
                                    color = PaytmNavy,
                                    modifier = Modifier.weight(1f)
                                )
                                PaymentStatChip(
                                    title = "Udhaar",
                                    amount = totalCreditBalance,
                                    icon = Icons.Default.CreditCard,
                                    color = Color(0xFFDC2626),
                                    modifier = Modifier.weight(1.1f)
                                )
                            }
                        }

                        // Filter Chips
                        val filterTabs = listOf(
                            Triple("All", t("herd.filter_all"), sales.size),
                            Triple("PAID", t("sales.payment_received"), sales.count { PaymentStatus.isPaid(it.payment_status_c) }),
                            Triple("PARTIAL", "Partial", sales.count { PaymentStatus.normalize(it.payment_status_c) == PaymentStatus.PARTIALLY_PAID }),
                            Triple("UNPAID", "Udhaar", sales.count { PaymentStatus.normalize(it.payment_status_c) == PaymentStatus.UNPAID }),
                            Triple("PENDING", t("sales.payment_pending"), sales.count { PaymentStatus.normalize(it.payment_status_c) == PaymentStatus.PENDING })
                        )

                        LazyRow(
                            contentPadding = PaddingValues(horizontal = 16.dp),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.padding(bottom = 8.dp)
                        ) {
                            items(filterTabs) { (filterKey, label, count) ->
                                FilterChip(
                                    selected = selectedFilter == filterKey,
                                    onClick = { selectedFilter = filterKey },
                                    label = { Text("$label ($count)", fontSize = 11.sp) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = when (filterKey) {
                                            "PENDING" -> FarmWarning
                                            "UNPAID", "PARTIAL" -> Color(0xFFDC2626)
                                            else -> FarmGreenPrimary
                                        },
                                        selectedLabelColor = Color.White
                                    ),
                                    modifier = Modifier.testTag("sales_filter_$filterKey")
                                )
                            }
                        }

                        if (isLoading) {
                            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                CircularProgressIndicator(color = FarmGreenPrimary)
                            }
                        } else if (filteredSales.isEmpty()) {
                            Box(modifier = Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
                                Text("No sales matching filter", color = Color.Gray)
                            }
                        } else {
                            LazyColumn(
                                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 88.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                items(filteredSales, key = { it.id }) { sale ->
                                    val goat = goatsMap[sale.goat_id_c]
                                    EnhancedSaleHistoryCard(
                                        sale = sale,
                                        goat = goat,
                                        onConfirmUpi = {
                                            saleToConfirmUpi = sale
                                            upiReferenceInput = ""
                                        },
                                        onOpenPaytmCheckout = {
                                            paytmCheckoutSale = sale
                                        },
                                        onViewReceipt = {
                                            saleForReceipt = sale
                                        },
                                        onCollectCreditPayment = {
                                            saleForCreditPayment = sale
                                        },
                                        onCycleDeliveryStatus = {
                                            val nextStatus = when (DeliveryStatus.normalize(sale.delivery_status_c)) {
                                                DeliveryStatus.EXPECTED -> DeliveryStatus.READY
                                                DeliveryStatus.READY -> DeliveryStatus.DISPATCHED
                                                DeliveryStatus.DISPATCHED -> DeliveryStatus.DELIVERED
                                                else -> DeliveryStatus.EXPECTED
                                            }
                                            coroutineScope.launch {
                                                repository.updateDeliveryStatus(sale.id, nextStatus)
                                                loadData()
                                            }
                                        }
                                    )
                                }
                            }
                        }
                    }
                }

                1 -> {
                    // ==========================================
                    // DELIVERIES & DISPATCH TAB
                    // ==========================================
                    DeliveryManagementView(
                        repository = repository,
                        sales = sales,
                        goatsMap = goatsMap
                    )
                }

                2 -> {
                    // ==========================================
                    // CREDIT / UDHAAR LEDGER TAB
                    // ==========================================
                    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
                        // Outstanding Banner
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = Color(0xFFFEF2F2),
                            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFFECACA)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(14.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text("Outstanding Credit Due", fontSize = 11.sp, color = Color.Gray)
                                    Text(
                                        CurrencyUtils.formatInr(totalCreditBalance),
                                        fontWeight = FontWeight.ExtraBold,
                                        fontSize = 20.sp,
                                        color = Color(0xFFDC2626)
                                    )
                                    Text("${creditSales.count { it.balance_due_c > 0 }} active credit sales pending collection", fontSize = 11.sp, color = Color.Gray)
                                }
                                Box(
                                    modifier = Modifier.size(44.dp).clip(CircleShape).background(Color(0xFFFEE2E2)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(Icons.Default.CreditScore, contentDescription = null, tint = Color(0xFFDC2626))
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        if (creditSales.isEmpty()) {
                            Box(modifier = Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                                Text("No credit sales recorded yet.", color = Color.Gray)
                            }
                        } else {
                            LazyColumn(
                                contentPadding = PaddingValues(bottom = 88.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                items(creditSales, key = { it.id }) { sale ->
                                    val goat = goatsMap[sale.goat_id_c]
                                    EnhancedSaleHistoryCard(
                                        sale = sale,
                                        goat = goat,
                                        onConfirmUpi = { saleToConfirmUpi = sale },
                                        onOpenPaytmCheckout = { paytmCheckoutSale = sale },
                                        onViewReceipt = { saleForReceipt = sale },
                                        onCollectCreditPayment = { saleForCreditPayment = sale },
                                        onCycleDeliveryStatus = {
                                            val nextStatus = when (DeliveryStatus.normalize(sale.delivery_status_c)) {
                                                DeliveryStatus.EXPECTED -> DeliveryStatus.READY
                                                DeliveryStatus.READY -> DeliveryStatus.DISPATCHED
                                                DeliveryStatus.DISPATCHED -> DeliveryStatus.DELIVERED
                                                else -> DeliveryStatus.EXPECTED
                                            }
                                            coroutineScope.launch {
                                                repository.updateDeliveryStatus(sale.id, nextStatus)
                                                loadData()
                                            }
                                        }
                                    )
                                }
                            }
                        }
                    }
                }

                3 -> {
                    // ==========================================
                    // CUSTOMERS MANAGEMENT TAB
                    // ==========================================
                    CustomersCreditView(
                        customers = customers,
                        sales = sales,
                        onRecordPaymentClick = { targetSale ->
                            saleForCreditPayment = targetSale
                        }
                    )
                }

                4 -> {
                    // ==========================================
                    // SMS PAYMENT RECONCILIATION TAB
                    // ==========================================
                    SmsReconciliationView(
                        smsManager = smsManager,
                        sales = sales,
                        customers = customers,
                        onMatchConfirmed = { candidate, targetSale ->
                            coroutineScope.launch {
                                // Record payment against this sale
                                repository.recordCreditPayment(
                                    saleId = targetSale.id,
                                    amount = candidate.amount,
                                    method = PaymentMethod.UPI_QR,
                                    reference = candidate.referenceNumber,
                                    notes = "Auto-reconciled from SMS alert (${candidate.sender})"
                                )
                                smsManager.markCandidateMatched(candidate.id, targetSale.id)
                                loadData()
                                Toast.makeText(context, "Payment reconciled: ${CurrencyUtils.formatInr(candidate.amount)} matched to ${targetSale.buyer_name_c}", Toast.LENGTH_LONG).show()
                            }
                        }
                    )
                }
            }
        }
    }

    // ==========================================
    // RECORD SALE DIALOG (Piece vs Weight, Cash, UPI/QR, Paytm Gateway, Credit)
    // ==========================================
    if (showRecordSaleDialog) {
        RecordSaleDialog(
            unsoldGoats = unsoldGoats,
            today = today,
            isOnline = isOnline,
            merchantName = paymentSettings.merchantName,
            merchantVpa = paymentSettings.merchantUpiId,
            customers = customers,
            onSaveNewCustomer = { newCust ->
                val res = repository.saveCustomer(newCust)
                if (res.isSuccess) {
                    val saved = res.getOrThrow()
                    customers = (customers.filter { it.id != saved.id } + saved).sortedBy { it.name_c }
                    saved
                } else null
            },
            onDismiss = { showRecordSaleDialog = false },
            onSaveCashOrUpiOrCredit = { sale, reference ->
                coroutineScope.launch {
                    val res = repository.recordSale(sale)
                    if (res.isSuccess) {
                        showRecordSaleDialog = false
                        val savedSale = res.getOrThrow()
                        loadData()

                        if (PaymentMethod.normalize(savedSale.payment_mode_c) == PaymentMethod.CASH ||
                            (PaymentMethod.normalize(savedSale.payment_mode_c) == PaymentMethod.CREDIT && savedSale.balance_due_c == 0.0)) {
                            saleForReceipt = savedSale
                        } else if (PaymentMethod.normalize(savedSale.payment_mode_c) == PaymentMethod.UPI_QR) {
                            Toast.makeText(context, "UPI / QR sale recorded as Pending. Confirm payment when received.", Toast.LENGTH_LONG).show()
                        } else if (PaymentMethod.normalize(savedSale.payment_mode_c) == PaymentMethod.CREDIT) {
                            Toast.makeText(context, "Credit sale recorded for ${savedSale.buyer_name_c}. Balance: ${CurrencyUtils.formatInr(savedSale.balance_due_c)}", Toast.LENGTH_LONG).show()
                            saleForReceipt = savedSale
                        }
                    } else {
                        errorMessage = res.exceptionOrNull()?.message ?: "Failed to save sale"
                    }
                }
            },
            onLaunchPaytm = { sale ->
                coroutineScope.launch {
                    val res = repository.recordSale(sale)
                    if (res.isSuccess) {
                        showRecordSaleDialog = false
                        val savedSale = res.getOrThrow()
                        loadData()
                        paytmCheckoutSale = savedSale
                    } else {
                        errorMessage = res.exceptionOrNull()?.message ?: "Failed to create Paytm sale"
                    }
                }
            }
        )
    }

    // ==========================================
    // RECORD CREDIT SUBSEQUENT PAYMENT DIALOG
    // ==========================================
    saleForCreditPayment?.let { sale ->
        val goat = goatsMap[sale.goat_id_c]
        RecordCreditPaymentDialog(
            sale = sale,
            goat = goat,
            onDismiss = { saleForCreditPayment = null },
            onConfirmPayment = { amount, method, reference, notes ->
                coroutineScope.launch {
                    val res = repository.recordCreditPayment(sale.id, amount, method, reference, notes)
                    saleForCreditPayment = null
                    if (res.isSuccess) {
                        loadData()
                        Toast.makeText(context, "Payment of ${CurrencyUtils.formatInr(amount)} recorded successfully!", Toast.LENGTH_LONG).show()
                    } else {
                        Toast.makeText(context, "Error saving payment: ${res.exceptionOrNull()?.message}", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        )
    }

    // ==========================================
    // PAYTM GATEWAY CHECKOUT DIALOG
    // ==========================================
    paytmCheckoutSale?.let { sale ->
        val goat = goatsMap[sale.goat_id_c]
        val orderId = remember(sale.id) {
            sale.order_id_c ?: PaytmService.generateOrderId()
        }

        PaytmGatewayCheckoutDialog(
            orderId = orderId,
            amount = sale.amount_c,
            goatTag = goat?.tag_c ?: sale.goat_id_c,
            goatName = goat?.name ?: "Goat",
            buyerName = sale.buyer_name_c,
            buyerPhone = sale.buyer_phone_c,
            paytmService = paytmService,
            isOnline = isOnline,
            onDismiss = { paytmCheckoutSale = null },
            onPaymentSuccess = { verifyResult ->
                coroutineScope.launch {
                    val res = repository.confirmPaytmPayment(sale, verifyResult)
                    paytmCheckoutSale = null
                    if (res.isSuccess) {
                        val paidSale = res.getOrThrow()
                        loadData()
                        saleForReceipt = paidSale
                    } else {
                        Toast.makeText(context, "Error updating sale record: ${res.exceptionOrNull()?.message}", Toast.LENGTH_SHORT).show()
                    }
                }
            },
            onPaymentFailed = { verifyResult ->
                coroutineScope.launch {
                    val status = if (verifyResult.paymentStatus == PaymentStatus.CANCELLED) PaymentStatus.CANCELLED else PaymentStatus.FAILED
                    repository.markPaymentFailed(sale, status, verifyResult.failureReason)
                    paytmCheckoutSale = null
                    loadData()
                    Toast.makeText(context, "Paytm payment ${verifyResult.paymentStatus.lowercase()}: ${verifyResult.failureReason}", Toast.LENGTH_LONG).show()
                }
            }
        )
    }

    // ==========================================
    // UPI CONFIRMATION DIALOG
    // ==========================================
    saleToConfirmUpi?.let { sale ->
        val goat = goatsMap[sale.goat_id_c]
        AlertDialog(
            onDismissRequest = { if (!confirmingUpi) saleToConfirmUpi = null },
            icon = {
                Icon(
                    imageVector = Icons.Default.CheckCircle,
                    contentDescription = null,
                    tint = Color(0xFF2E7D32),
                    modifier = Modifier.size(44.dp)
                )
            },
            title = {
                Text(t("sales.confirm_payment_title"), fontWeight = FontWeight.Bold, fontSize = 16.sp)
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Buyer: ${sale.buyer_name_c.ifBlank { "Buyer" }}${if (sale.buyer_phone_c.isNotBlank()) " (${sale.buyer_phone_c})" else ""}",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Text(
                        text = "Amount: ${CurrencyUtils.formatInr(sale.amount_c)}",
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleMedium,
                        color = Color(0xFF2E7D32)
                    )
                    Text(
                        text = "Goat: ${goat?.name ?: "Goat"} (${goat?.tag_c ?: sale.goat_id_c})",
                        style = MaterialTheme.typography.bodyMedium
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    OutlinedTextField(
                        value = upiReferenceInput,
                        onValueChange = { upiReferenceInput = it },
                        label = { Text("UPI / Bank Reference Number") },
                        placeholder = { Text("e.g. 324156789012") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("upi_reference_input")
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        confirmingUpi = true
                        coroutineScope.launch {
                            val res = repository.confirmUpiPayment(sale, upiReferenceInput.trim().ifBlank { null })
                            confirmingUpi = false
                            saleToConfirmUpi = null
                            if (res.isSuccess) {
                                val paidSale = res.getOrThrow()
                                loadData()
                                saleForReceipt = paidSale
                            } else {
                                Toast.makeText(context, "Failed to confirm UPI payment: ${res.exceptionOrNull()?.message}", Toast.LENGTH_SHORT).show()
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32)),
                    enabled = !confirmingUpi,
                    modifier = Modifier.height(44.dp).testTag("confirm_payment_received_btn")
                ) {
                    if (confirmingUpi) {
                        CircularProgressIndicator(modifier = Modifier.size(18.dp), color = Color.White)
                    } else {
                        Text("Confirm Received")
                    }
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { if (!confirmingUpi) saleToConfirmUpi = null },
                    enabled = !confirmingUpi
                ) {
                    Text(t("btn.cancel"))
                }
            }
        )
    }

    // ==========================================
    // OFFICIAL SALE RECEIPT DIALOG
    // ==========================================
    saleForReceipt?.let { sale ->
        val goat = goatsMap[sale.goat_id_c]
        SaleReceiptDialog(
            sale = sale,
            goat = goat,
            onDismiss = { saleForReceipt = null }
        )
    }
}

// ==========================================
// PAYMENT STAT CHIP COMPONENT
// ==========================================
@Composable
private fun PaymentStatChip(
    title: String,
    amount: Double,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    color: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(modifier = Modifier.padding(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(12.dp))
                Spacer(modifier = Modifier.width(3.dp))
                Text(title, style = MaterialTheme.typography.labelSmall, color = Color.Gray, fontSize = 10.sp)
            }
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = CurrencyUtils.formatInr(amount),
                fontWeight = FontWeight.Bold,
                color = color,
                fontSize = 11.sp,
                maxLines = 1
            )
        }
    }
}

// ==========================================
// ENHANCED SALE HISTORY CARD COMPONENT
// ==========================================
@Composable
fun EnhancedSaleHistoryCard(
    sale: SaleRecord,
    goat: Goat?,
    onConfirmUpi: () -> Unit,
    onOpenPaytmCheckout: () -> Unit,
    onViewReceipt: () -> Unit,
    onCollectCreditPayment: () -> Unit = {},
    onCycleDeliveryStatus: () -> Unit = {}
) {
    val normMethod = PaymentMethod.normalize(sale.payment_mode_c)
    val normStatus = PaymentStatus.normalize(sale.payment_status_c)
    val isPaid = normStatus == PaymentStatus.PAID
    val isPartial = normStatus == PaymentStatus.PARTIALLY_PAID
    val isUnpaid = normStatus == PaymentStatus.UNPAID
    val isPending = normStatus == PaymentStatus.PENDING
    val isFailed = normStatus == PaymentStatus.FAILED || normStatus == PaymentStatus.CANCELLED

    val methodIcon = when (normMethod) {
        PaymentMethod.CASH -> Icons.Default.AccountBalanceWallet
        PaymentMethod.UPI_QR -> Icons.Default.QrCode
        PaymentMethod.PAYTM_GATEWAY -> Icons.Default.PhoneAndroid
        PaymentMethod.CREDIT -> Icons.Default.CreditCard
        else -> Icons.Default.Payments
    }

    val methodColor = when (normMethod) {
        PaymentMethod.CASH -> Color(0xFF2E7D32)
        PaymentMethod.UPI_QR -> PaytmCyan
        PaymentMethod.PAYTM_GATEWAY -> PaytmNavy
        PaymentMethod.CREDIT -> Color(0xFFDC2626)
        else -> Color.DarkGray
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable {
                if (isPaid || isPartial) {
                    onViewReceipt()
                } else if (isPending && normMethod == PaymentMethod.UPI_QR) {
                    onConfirmUpi()
                } else if (isPending && normMethod == PaymentMethod.PAYTM_GATEWAY) {
                    onOpenPaytmCheckout()
                } else if (sale.balance_due_c > 0) {
                    onCollectCreditPayment()
                }
            }
            .testTag("sale_card_${sale.id}"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Header Row: Goat Info & Amount
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    goat?.let { g ->
                        TagBadge(tag = g.tag_c)
                        Spacer(modifier = Modifier.width(8.dp))
                    }
                    Column {
                        Text(
                            text = goat?.name ?: "Goat Sale",
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.titleMedium,
                            color = Color(0xFF1E293B)
                        )
                        Text(
                            text = "${sale.sale_type_c} • ${sale.sale_date_c}",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color.Gray
                        )
                    }
                }

                // Amount Formatted as ₹
                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = CurrencyUtils.formatInr(sale.amount_c),
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.ExtraBold,
                        color = if (isPaid) Color(0xFF2E7D32) else Color(0xFF1E293B)
                    )
                    if (sale.balance_due_c > 0) {
                        Text(
                            text = "Due: ${CurrencyUtils.formatInr(sale.balance_due_c)}",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFDC2626)
                        )
                    }
                }
            }

            // Mode Breakdown description
            val modeText = if (sale.sale_type_c == "WEIGHT") {
                "${sale.quantity_c} goats • ${sale.total_weight_kg_c} kg @ ${CurrencyUtils.formatInr(sale.rate_per_unit_c)}/kg"
            } else {
                "${sale.quantity_c} pcs @ ${CurrencyUtils.formatInr(sale.rate_per_unit_c)}/pc"
            }
            Text(modeText, fontSize = 11.sp, color = Color(0xFF475569), fontWeight = FontWeight.Medium)

            Spacer(modifier = Modifier.height(6.dp))

            // Buyer & Address Details
            if (sale.buyer_name_c.isNotBlank()) {
                val addr = listOfNotNull(
                    sale.buyer_name_c,
                    sale.buyer_phone_c.ifBlank { null },
                    sale.buyer_address_c.ifBlank { null }
                ).joinToString(" • ")
                Text(
                    text = "Customer: $addr",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Badges & Action Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                    // Payment Method Badge
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = methodColor.copy(alpha = 0.12f)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(imageVector = methodIcon, contentDescription = null, tint = methodColor, modifier = Modifier.size(13.dp))
                            Spacer(modifier = Modifier.width(3.dp))
                            Text(
                                text = PaymentMethod.displayName(normMethod),
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = methodColor,
                                fontSize = 10.sp
                            )
                        }
                    }

                    // Payment Status Badge
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = when {
                            isPaid -> FarmSuccessContainer
                            isPartial -> Color(0xFFFEF3C7)
                            isUnpaid -> Color(0xFFFEE2E2)
                            isPending -> FarmWarningContainer
                            else -> FarmErrorContainer
                        }
                    ) {
                        Text(
                            text = normStatus,
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = when {
                                isPaid -> FarmSuccess
                                isPartial -> Color(0xFFB45309)
                                isUnpaid -> Color(0xFFDC2626)
                                isPending -> FarmWarning
                                else -> FarmError
                            },
                            fontSize = 10.sp,
                            modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp)
                        )
                    }

                    // Delivery Status Badge (clickable to cycle status)
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = Color(0xFFF1F5F9),
                        modifier = Modifier.clickable { onCycleDeliveryStatus() }
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.LocalShipping, contentDescription = null, tint = Color(0xFF475569), modifier = Modifier.size(11.dp))
                            Spacer(modifier = Modifier.width(3.dp))
                            Text(
                                text = sale.delivery_status_c,
                                style = MaterialTheme.typography.labelSmall,
                                color = Color(0xFF334155),
                                fontSize = 10.sp
                            )
                        }
                    }
                }

                // Action buttons based on status
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (sale.balance_due_c > 0) {
                        Button(
                            onClick = onCollectCreditPayment,
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626)),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.height(32.dp).testTag("collect_payment_btn_${sale.id}")
                        ) {
                            Text("Collect", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    if (isPaid || isPartial) {
                        OutlinedButton(
                            onClick = onViewReceipt,
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.height(32.dp).testTag("view_receipt_btn_${sale.id}")
                        ) {
                            Icon(Icons.Default.Receipt, contentDescription = null, modifier = Modifier.size(13.dp))
                            Spacer(modifier = Modifier.width(3.dp))
                            Text("Receipt", fontSize = 11.sp)
                        }
                    } else if (isPending && normMethod == PaymentMethod.UPI_QR) {
                        Button(
                            onClick = onConfirmUpi,
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32)),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.height(32.dp).testTag("confirm_upi_btn_${sale.id}")
                        ) {
                            Text("Confirm Paid", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    } else if (isPending && normMethod == PaymentMethod.PAYTM_GATEWAY) {
                        Button(
                            onClick = onOpenPaytmCheckout,
                            colors = ButtonDefaults.buttonColors(containerColor = PaytmNavy),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.height(32.dp).testTag("open_paytm_checkout_${sale.id}")
                        ) {
                            Text("Paytm Checkout", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// RECORD SALE DIALOG COMPONENT
// ==========================================
@Composable
fun RecordSaleDialog(
    unsoldGoats: List<Goat>,
    today: String,
    isOnline: Boolean,
    merchantName: String,
    merchantVpa: String,
    customers: List<CustomerRecord> = emptyList(),
    onSaveNewCustomer: (suspend (CustomerRecord) -> CustomerRecord?)? = null,
    onDismiss: () -> Unit,
    onSaveCashOrUpiOrCredit: (SaleRecord, String?) -> Unit,
    onLaunchPaytm: (SaleRecord) -> Unit
) {
    val coroutineScope = rememberCoroutineScope()
    var currentCustomers by remember(customers) { mutableStateOf(customers) }

    var selectedGoatId by remember { mutableStateOf(unsoldGoats.firstOrNull()?.id ?: "") }
    var saleDate by remember { mutableStateOf(today) }

    // 1. Sales Mode: Piece vs Weight
    var saleType by remember { mutableStateOf(SaleType.PIECE) } // PIECE, WEIGHT
    var quantityStr by remember { mutableStateOf("1") }
    var ratePerPieceStr by remember { mutableStateOf("8000") }

    var goatCountStr by remember { mutableStateOf("1") }
    var weightKgStr by remember { mutableStateOf("35.0") }
    var ratePerKgStr by remember { mutableStateOf("500") } // Default ₹500/kg editable

    // Customer selection & details
    var selectedCustomerId by remember { mutableStateOf<String?>(null) }
    var buyerName by remember { mutableStateOf("") }
    var buyerPhone by remember { mutableStateOf("") }
    var buyerAddress by remember { mutableStateOf("") }
    var buyerVillage by remember { mutableStateOf("") }

    var showCustomerSearchDialog by remember { mutableStateOf(false) }
    var showAddCustomerDialog by remember { mutableStateOf(false) }

    // Payment Type & Part Payment
    var selectedPaymentMethod by remember { mutableStateOf(PaymentMethod.CASH) } // CASH, UPI_QR, PAYTM_GATEWAY, CREDIT
    var amountPaidStr by remember { mutableStateOf("") }

    // Delivery Details (Do NOT automatically mark as DELIVERED on payment)
    var deliveryStatus by remember { mutableStateOf(DeliveryStatus.EXPECTED) }
    var expectedDeliveryDate by remember { mutableStateOf(today) }

    var notes by remember { mutableStateOf("") }
    var validationError by remember { mutableStateOf<String?>(null) }
    var showUpiQrArtwork by remember { mutableStateOf(false) }

    val selectedGoat = remember(selectedGoatId, unsoldGoats) {
        unsoldGoats.find { it.id == selectedGoatId }
    }

    val selectedCustomer = remember(selectedCustomerId, currentCustomers) {
        currentCustomers.find { it.id == selectedCustomerId }
    }

    fun selectCustomer(cust: CustomerRecord) {
        selectedCustomerId = cust.id
        buyerName = cust.name_c
        buyerPhone = cust.phone_c
        buyerAddress = cust.address_c
        buyerVillage = cust.village_c
        validationError = null
    }

    fun clearCustomer() {
        selectedCustomerId = null
        buyerName = ""
        buyerPhone = ""
        buyerAddress = ""
        buyerVillage = ""
    }

    // Auto-update weight if goat has weight
    LaunchedEffect(selectedGoatId) {
        selectedGoat?.weight_kg_c?.let { w ->
            if (w > 0) weightKgStr = w.toString()
        }
    }

    // Computed Total Amount based on Sale Type formula
    val computedTotalAmount = remember(saleType, quantityStr, ratePerPieceStr, weightKgStr, ratePerKgStr) {
        if (saleType == SaleType.WEIGHT) {
            val w = weightKgStr.toDoubleOrNull() ?: 0.0
            val r = ratePerKgStr.toDoubleOrNull() ?: 500.0
            w * r
        } else {
            val q = quantityStr.toIntOrNull() ?: 1
            val r = ratePerPieceStr.toDoubleOrNull() ?: 0.0
            q * r
        }
    }

    val computedPaidAmount = remember(selectedPaymentMethod, amountPaidStr, computedTotalAmount) {
        if (selectedPaymentMethod == PaymentMethod.CASH) {
            computedTotalAmount
        } else if (selectedPaymentMethod == PaymentMethod.CREDIT) {
            (amountPaidStr.toDoubleOrNull() ?: 0.0).coerceAtLeast(0.0).coerceAtMost(computedTotalAmount)
        } else {
            0.0
        }
    }

    val computedBalanceDue = remember(computedTotalAmount, computedPaidAmount, selectedPaymentMethod) {
        if (selectedPaymentMethod == PaymentMethod.CREDIT) {
            (computedTotalAmount - computedPaidAmount).coerceAtLeast(0.0)
        } else if (selectedPaymentMethod == PaymentMethod.CASH) {
            0.0
        } else {
            computedTotalAmount
        }
    }

    val isCredit = selectedPaymentMethod == PaymentMethod.CREDIT

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.AddShoppingCart,
                    contentDescription = null,
                    tint = FarmGreenPrimary,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = t("sales.record_sale"),
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                if (unsoldGoats.isEmpty()) {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = FarmWarningContainer),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = t("herd.empty_message"),
                            color = FarmWarning,
                            style = MaterialTheme.typography.bodySmall,
                            modifier = Modifier.padding(12.dp)
                        )
                    }
                } else {
                    GoatSelector(
                        goats = unsoldGoats,
                        selectedGoatId = selectedGoatId,
                        onGoatSelected = { selectedGoatId = it.id },
                        label = "${t("weight.select_goat")} *"
                    )
                }

                // ==========================================
                // 1. SALES MODE SELECTOR: [ Piece ] [ Weight ]
                // ==========================================
                Text(
                    text = "Sale Type *",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilterChip(
                        selected = saleType == SaleType.PIECE,
                        onClick = { saleType = SaleType.PIECE },
                        label = { Text("Piece Sale", fontWeight = FontWeight.Bold) },
                        leadingIcon = { Icon(Icons.Default.Numbers, contentDescription = null, modifier = Modifier.size(16.dp)) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = FarmGreenDark,
                            selectedLabelColor = Color.White
                        ),
                        modifier = Modifier.weight(1f).height(44.dp).testTag("sale_mode_piece")
                    )

                    FilterChip(
                        selected = saleType == SaleType.WEIGHT,
                        onClick = { saleType = SaleType.WEIGHT },
                        label = { Text("Weight Sale", fontWeight = FontWeight.Bold) },
                        leadingIcon = { Icon(Icons.Default.Scale, contentDescription = null, modifier = Modifier.size(16.dp)) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = FarmGreenDark,
                            selectedLabelColor = Color.White
                        ),
                        modifier = Modifier.weight(1f).height(44.dp).testTag("sale_mode_weight")
                    )
                }

                // Inputs based on Sale Mode
                if (saleType == SaleType.PIECE) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = quantityStr,
                            onValueChange = { quantityStr = it },
                            label = { Text("Pieces / Qty *") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = ratePerPieceStr,
                            onValueChange = { ratePerPieceStr = it },
                            label = { Text("Rate / pc (₹) *") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            singleLine = true,
                            leadingIcon = { Text("₹", fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 8.dp), color = MaterialTheme.colorScheme.onSurface) },
                            modifier = Modifier.weight(1.3f)
                        )
                    }
                } else {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = goatCountStr,
                            onValueChange = { goatCountStr = it },
                            label = { Text("Goats count") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = weightKgStr,
                            onValueChange = { weightKgStr = it },
                            label = { Text("Weight (kg) *") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = ratePerKgStr,
                            onValueChange = { ratePerKgStr = it },
                            label = { Text("Rate/kg (₹) *") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            singleLine = true,
                            leadingIcon = { Text("₹", fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 6.dp), color = MaterialTheme.colorScheme.onSurface) },
                            modifier = Modifier.weight(1.2f)
                        )
                    }
                }

                // Total Calculation Display Banner
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = FarmGreenContainer.copy(alpha = 0.5f),
                    border = BorderStroke(1.dp, FarmGreenDark.copy(alpha = 0.3f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Total Amount Formula:", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            val formula = if (saleType == SaleType.WEIGHT) {
                                "${weightKgStr.ifBlank { "0" }} kg × ₹${ratePerKgStr.ifBlank { "500" }}/kg"
                            } else {
                                "${quantityStr.ifBlank { "1" }} pcs × ₹${ratePerPieceStr.ifBlank { "0" }}/pc"
                            }
                            Text(formula, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = FarmGreenDark)
                        }
                        Text(
                            text = CurrencyUtils.formatInr(computedTotalAmount),
                            fontSize = 18.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = FarmGreenDark
                        )
                    }
                }

                DatePickerField(
                    dateValue = saleDate,
                    onDateSelected = { saleDate = it },
                    label = t("sales.sale_date")
                )

                // ==========================================
                // 2. PAYMENT TYPE SELECTOR (Requirement 6: 2x2 Responsive Grid to prevent text wrapping)
                // ==========================================
                Text(
                    text = "Payment Type *",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        SalePaymentTypeCard(
                            title = "Cash",
                            icon = Icons.Default.AccountBalanceWallet,
                            isSelected = selectedPaymentMethod == PaymentMethod.CASH,
                            selectedColor = Color(0xFF2E7D32),
                            modifier = Modifier.weight(1f).testTag("payment_method_cash"),
                            onClick = { selectedPaymentMethod = PaymentMethod.CASH; validationError = null }
                        )

                        SalePaymentTypeCard(
                            title = "UPI / QR",
                            icon = Icons.Default.QrCode,
                            isSelected = selectedPaymentMethod == PaymentMethod.UPI_QR,
                            selectedColor = PaytmCyan,
                            modifier = Modifier.weight(1f).testTag("payment_method_upi"),
                            onClick = { selectedPaymentMethod = PaymentMethod.UPI_QR; validationError = null }
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        SalePaymentTypeCard(
                            title = "Paytm",
                            icon = Icons.Default.PhoneAndroid,
                            isSelected = selectedPaymentMethod == PaymentMethod.PAYTM_GATEWAY,
                            selectedColor = PaytmNavy,
                            modifier = Modifier.weight(1f).testTag("payment_method_paytm"),
                            onClick = { selectedPaymentMethod = PaymentMethod.PAYTM_GATEWAY; validationError = null }
                        )

                        SalePaymentTypeCard(
                            title = "Credit",
                            icon = Icons.Default.CreditCard,
                            isSelected = selectedPaymentMethod == PaymentMethod.CREDIT,
                            selectedColor = Color(0xFFDC2626),
                            modifier = Modifier.weight(1f).testTag("payment_method_credit"),
                            onClick = { selectedPaymentMethod = PaymentMethod.CREDIT; validationError = null }
                        )
                    }
                }

                // ==========================================
                // 3. CUSTOMER SECTION (Requirements 1, 2, 3, 4 & 7)
                // ==========================================
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    // Header Row with Label and "+ Add Customer" Button
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = if (isCredit) "Customer *" else "Customer",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = if (isCredit && selectedCustomerId.isNullOrBlank()) Color(0xFFEF4444) else MaterialTheme.colorScheme.onSurface
                            )
                            if (isCredit) {
                                Spacer(modifier = Modifier.width(6.dp))
                                Surface(
                                    shape = RoundedCornerShape(4.dp),
                                    color = Color(0xFFFEE2E2)
                                ) {
                                    Text(
                                        text = "Mandatory for Credit",
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFFDC2626),
                                        modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp)
                                    )
                                }
                            }
                        }

                        // [+ Add Customer] Button beside/above
                        OutlinedButton(
                            onClick = { showAddCustomerDialog = true },
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                            border = BorderStroke(1.dp, FarmGreenLight.copy(alpha = 0.7f)),
                            colors = ButtonDefaults.outlinedButtonColors(
                                contentColor = FarmGreenLight
                            ),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .height(34.dp)
                                .testTag("btn_add_customer")
                        ) {
                            Icon(Icons.Default.PersonAdd, contentDescription = null, modifier = Modifier.size(15.dp), tint = FarmGreenLight)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("+ Add Customer", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = FarmGreenLight)
                        }
                    }

                    // Customer Selection Box (Visible, Proper border, Height >= 56dp, Dark Mode High Contrast)
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        border = BorderStroke(
                            width = if (isCredit && selectedCustomerId.isNullOrBlank()) 1.5.dp else 1.dp,
                            color = if (isCredit && selectedCustomerId.isNullOrBlank()) Color(0xFFEF4444)
                                    else if (selectedCustomer != null) FarmGreenLight
                                    else MaterialTheme.colorScheme.outline.copy(alpha = 0.8f)
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 56.dp)
                            .clickable { showCustomerSearchDialog = true }
                            .testTag("customer_selection_box")
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 14.dp, vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                modifier = Modifier.weight(1f),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Search,
                                    contentDescription = null,
                                    tint = if (isCredit && selectedCustomer == null) Color(0xFFEF4444) else FarmGreenLight,
                                    modifier = Modifier.size(22.dp)
                                )
                                Spacer(modifier = Modifier.width(12.dp))

                                if (selectedCustomer != null) {
                                    Column {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text(
                                                text = selectedCustomer.name_c,
                                                style = MaterialTheme.typography.bodyLarge,
                                                fontWeight = FontWeight.Bold,
                                                color = MaterialTheme.colorScheme.onSurface
                                            )
                                            if (selectedCustomer.outstanding_balance_c > 0) {
                                                Spacer(modifier = Modifier.width(8.dp))
                                                Surface(
                                                    shape = RoundedCornerShape(4.dp),
                                                    color = Color(0xFFFEE2E2)
                                                ) {
                                                    Text(
                                                        text = "Bal: ${CurrencyUtils.formatInr(selectedCustomer.outstanding_balance_c)}",
                                                        fontSize = 11.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        color = Color(0xFFDC2626),
                                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                    )
                                                }
                                            }
                                        }

                                        val details = listOfNotNull(
                                            selectedCustomer.phone_c.takeIf { it.isNotBlank() }?.let { "📞 $it" },
                                            selectedCustomer.village_c.takeIf { it.isNotBlank() } ?: selectedCustomer.address_c.takeIf { it.isNotBlank() }
                                        ).joinToString(" • ")

                                        if (details.isNotBlank()) {
                                            Text(
                                                text = details,
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                    }
                                } else {
                                    Text(
                                        text = if (isCredit) "Search customer / Select customer (Required) *" else "Search customer / Select customer",
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = FontWeight.Medium,
                                        color = if (isCredit) Color(0xFFEF4444) else MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }

                            Row(verticalAlignment = Alignment.CenterVertically) {
                                if (selectedCustomer != null) {
                                    IconButton(
                                        onClick = { clearCustomer() },
                                        modifier = Modifier.size(30.dp).testTag("btn_clear_customer")
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Close,
                                            contentDescription = "Clear Customer",
                                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                }
                                Icon(
                                    imageVector = Icons.Default.ArrowDropDown,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                        }
                    }

                    // Centered "+ Add Customer" below selection box
                    if (selectedCustomer == null) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.Center
                        ) {
                            TextButton(
                                onClick = { showAddCustomerDialog = true },
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                                modifier = Modifier.testTag("btn_add_customer_sub")
                            ) {
                                Icon(Icons.Default.PersonAdd, contentDescription = null, modifier = Modifier.size(16.dp), tint = FarmGreenLight)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("+ Add Customer", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = FarmGreenLight)
                            }
                        }
                    }
                }

                // ==========================================
                // 4. CREDIT BREAKDOWN & PART PAYMENT (Requirement 5)
                // ==========================================
                if (isCredit) {
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        border = BorderStroke(1.dp, Color(0xFFDC2626).copy(alpha = 0.5f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.CreditCard, contentDescription = null, tint = Color(0xFFDC2626), modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Credit & Part Payment Breakdown", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface)
                            }

                            OutlinedTextField(
                                value = amountPaidStr,
                                onValueChange = { amountPaidStr = it },
                                label = { Text("Paid Now / Upfront (₹)") },
                                placeholder = { Text("0 for full credit, or partial upfront") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                                singleLine = true,
                                leadingIcon = { Text("₹", fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 10.dp), color = MaterialTheme.colorScheme.onSurface) },
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = FarmGreenLight,
                                    unfocusedBorderColor = MaterialTheme.colorScheme.outline,
                                    focusedTextColor = MaterialTheme.colorScheme.onSurface,
                                    unfocusedTextColor = MaterialTheme.colorScheme.onSurface,
                                    focusedContainerColor = MaterialTheme.colorScheme.surface,
                                    unfocusedContainerColor = MaterialTheme.colorScheme.surface
                                ),
                                modifier = Modifier.fillMaxWidth().testTag("amount_paid_upfront_input")
                            )

                            // Prominently show: Sale Amount, Paid Now, Credit Balance
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = MaterialTheme.colorScheme.surface,
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(12.dp),
                                    horizontalArrangement = Arrangement.SpaceAround
                                ) {
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Text("Sale Amount", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, fontWeight = FontWeight.Bold)
                                        Spacer(modifier = Modifier.height(2.dp))
                                        Text(CurrencyUtils.formatInr(computedTotalAmount), fontSize = 14.sp, fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.onSurface)
                                    }
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Text("Paid Now", fontSize = 11.sp, color = FarmGreenLight, fontWeight = FontWeight.Bold)
                                        Spacer(modifier = Modifier.height(2.dp))
                                        Text(CurrencyUtils.formatInr(computedPaidAmount), fontSize = 14.sp, fontWeight = FontWeight.ExtraBold, color = FarmGreenLight)
                                    }
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Text("Credit Balance", fontSize = 11.sp, color = Color(0xFFDC2626), fontWeight = FontWeight.Bold)
                                        Spacer(modifier = Modifier.height(2.dp))
                                        Text(CurrencyUtils.formatInr(computedBalanceDue), fontSize = 14.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFFDC2626))
                                    }
                                }
                            }
                        }
                    }
                }

                // Expected Delivery Date
                OutlinedTextField(
                    value = expectedDeliveryDate,
                    onValueChange = { expectedDeliveryDate = it },
                    label = { Text("Expected Delivery Date (YYYY-MM-DD)") },
                    singleLine = true,
                    leadingIcon = { Icon(Icons.Default.DateRange, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant) },
                    modifier = Modifier.fillMaxWidth().testTag("expected_delivery_date_input")
                )

                // Delivery Status Selector
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Delivery Status:", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurface)
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        listOf(DeliveryStatus.EXPECTED, DeliveryStatus.READY, DeliveryStatus.DISPATCHED, DeliveryStatus.DELIVERED).forEach { st ->
                            FilterChip(
                                selected = deliveryStatus == st,
                                onClick = { deliveryStatus = st },
                                label = { Text(st, fontSize = 9.sp) },
                                modifier = Modifier.height(32.dp)
                            )
                        }
                    }
                }

                // Contextual Instructions
                when (selectedPaymentMethod) {
                    PaymentMethod.UPI_QR -> {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = PaytmLightBg,
                            border = BorderStroke(1.dp, PaytmCyan.copy(alpha = 0.4f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Text(
                                    text = "• UPI / QR: Displays Paytm All-In-One QR standee. Created as PENDING until confirmed.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = PaytmNavy
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                TextButton(
                                    onClick = { showUpiQrArtwork = !showUpiQrArtwork },
                                    contentPadding = PaddingValues(0.dp)
                                ) {
                                    Text(if (showUpiQrArtwork) "Hide QR Standee" else "Show Paytm QR Standee", fontSize = 11.sp, color = PaytmNavy)
                                }

                                if (showUpiQrArtwork) {
                                    PaytmQrStandeeCard(
                                        amount = computedTotalAmount,
                                        merchantName = merchantName,
                                        merchantVpa = merchantVpa,
                                        orderReference = selectedGoat?.tag_c ?: "SALE",
                                        onPaymentReceivedClick = {}
                                    )
                                }
                            }
                        }
                    }

                    PaymentMethod.PAYTM_GATEWAY -> {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = if (!isOnline) FarmErrorContainer else Color(0xFFF1F5F9),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                if (!isOnline) {
                                    Text(
                                        text = "Paytm Gateway requires an internet connection.\nUse Cash or UPI / QR for offline payment.",
                                        style = MaterialTheme.typography.bodySmall,
                                        fontWeight = FontWeight.Bold,
                                        color = FarmError
                                    )
                                } else {
                                    Text(
                                        text = "• Paytm Payment Gateway: Generates order ID and verifies with Paytm server before marking payment PAID.",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = PaytmNavy
                                    )
                                }
                            }
                        }
                    }

                    else -> {}
                }

                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text(t("herd.notes")) },
                    placeholder = { Text("e.g. Notes / conditions") },
                    modifier = Modifier.fillMaxWidth(),
                    maxLines = 2
                )

                if (validationError != null) {
                    Text(
                        text = validationError ?: "",
                        color = Color(0xFFDC2626),
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (unsoldGoats.isEmpty() || selectedGoatId.isBlank()) {
                        validationError = "Please select an unsold goat."
                        return@Button
                    }
                    if (computedTotalAmount <= 0.0) {
                        validationError = "Please enter a valid positive sale amount."
                        return@Button
                    }
                    if (selectedPaymentMethod == PaymentMethod.CREDIT) {
                        if (selectedCustomerId.isNullOrBlank()) {
                            validationError = "Customer is mandatory for Credit sales. Please select or add a customer."
                            return@Button
                        }
                    }
                    if (selectedPaymentMethod == PaymentMethod.PAYTM_GATEWAY && !isOnline) {
                        validationError = "Paytm Gateway requires an internet connection. Use Cash or UPI / QR for offline payment."
                        return@Button
                    }

                    val rate = if (saleType == SaleType.WEIGHT) (ratePerKgStr.toDoubleOrNull() ?: 500.0) else (ratePerPieceStr.toDoubleOrNull() ?: 0.0)
                    val qty = if (saleType == SaleType.WEIGHT) (goatCountStr.toIntOrNull() ?: 1) else (quantityStr.toIntOrNull() ?: 1)
                    val weight = if (saleType == SaleType.WEIGHT) (weightKgStr.toDoubleOrNull() ?: 0.0) else 0.0

                    val sale = SaleRecord(
                        goat_id_c = selectedGoatId,
                        amount_c = computedTotalAmount,
                        sale_date_c = saleDate,
                        buyer_name_c = selectedCustomer?.name_c ?: buyerName.trim().ifBlank { "Direct Buyer" },
                        buyer_phone_c = selectedCustomer?.phone_c ?: buyerPhone.trim(),
                        payment_mode_c = selectedPaymentMethod,
                        payment_status_c = when (selectedPaymentMethod) {
                            PaymentMethod.CASH -> PaymentStatus.PAID
                            PaymentMethod.CREDIT -> {
                                if (computedBalanceDue <= 0.0) PaymentStatus.PAID
                                else if (computedPaidAmount > 0.0) PaymentStatus.PARTIALLY_PAID
                                else PaymentStatus.UNPAID
                            }
                            else -> PaymentStatus.PENDING
                        },
                        order_id_c = if (selectedPaymentMethod == PaymentMethod.PAYTM_GATEWAY) PaytmService.generateOrderId() else null,
                        currency_c = "INR",
                        notes_c = notes.ifBlank { null },
                        sale_type_c = saleType,
                        quantity_c = qty,
                        total_weight_kg_c = weight,
                        rate_per_unit_c = rate,
                        buyer_address_c = selectedCustomer?.address_c ?: buyerAddress.trim(),
                        buyer_village_c = selectedCustomer?.village_c ?: buyerVillage.trim(),
                        amount_paid_c = computedPaidAmount,
                        balance_due_c = computedBalanceDue,
                        delivery_status_c = deliveryStatus,
                        expected_delivery_date_c = expectedDeliveryDate.trim().ifBlank { null },
                        customer_id_c = selectedCustomerId
                    )

                    if (selectedPaymentMethod == PaymentMethod.PAYTM_GATEWAY) {
                        onLaunchPaytm(sale)
                    } else {
                        onSaveCashOrUpiOrCredit(sale, null)
                    }
                },
                enabled = unsoldGoats.isNotEmpty() && (selectedPaymentMethod != PaymentMethod.CREDIT || !selectedCustomerId.isNullOrBlank()),
                colors = ButtonDefaults.buttonColors(
                    containerColor = when (selectedPaymentMethod) {
                        PaymentMethod.CASH -> Color(0xFF2E7D32)
                        PaymentMethod.UPI_QR -> PaytmCyan
                        PaymentMethod.PAYTM_GATEWAY -> PaytmNavy
                        PaymentMethod.CREDIT -> Color(0xFFDC2626)
                        else -> FarmGreenDark
                    }
                ),
                modifier = Modifier.height(48.dp).testTag("submit_record_sale_btn")
            ) {
                Text(
                    text = when {
                        selectedPaymentMethod == PaymentMethod.CREDIT && selectedCustomerId.isNullOrBlank() -> "Select Customer for Credit Sale"
                        selectedPaymentMethod == PaymentMethod.CREDIT -> "Complete Credit Sale"
                        selectedPaymentMethod == PaymentMethod.PAYTM_GATEWAY -> "Proceed to Paytm Gateway"
                        selectedPaymentMethod == PaymentMethod.UPI_QR -> "Create UPI / QR Sale"
                        selectedPaymentMethod == PaymentMethod.CASH -> "Complete Cash Sale"
                        else -> "Record Sale"
                    },
                    fontWeight = FontWeight.Bold
                )
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss, modifier = Modifier.height(48.dp)) {
                Text(t("btn.cancel"))
            }
        }
    )

    // Customer Selection Dialog
    if (showCustomerSearchDialog) {
        CustomerSearchSelectionDialog(
            customers = currentCustomers,
            selectedCustomerId = selectedCustomerId,
            onCustomerSelected = { cust ->
                selectCustomer(cust)
                showCustomerSearchDialog = false
            },
            onAddNewCustomerClick = {
                showCustomerSearchDialog = false
                showAddCustomerDialog = true
            },
            onDismiss = { showCustomerSearchDialog = false }
        )
    }

    // Add Customer Form Dialog
    if (showAddCustomerDialog) {
        AddCustomerDialog(
            onDismiss = { showAddCustomerDialog = false },
            onSaveCustomer = { name, phone, address, village, notesVal ->
                coroutineScope.launch {
                    val newCust = CustomerRecord(
                        name_c = name,
                        phone_c = phone,
                        address_c = address,
                        village_c = village,
                        notes_c = notesVal,
                        outstanding_balance_c = 0.0,
                        total_purchases_c = 0.0,
                        total_paid_c = 0.0,
                        created_at = today
                    )
                    val saved = onSaveNewCustomer?.invoke(newCust) ?: newCust
                    currentCustomers = (currentCustomers.filter { it.id != saved.id } + saved).sortedBy { it.name_c }
                    // Automatically select newly created customer
                    selectCustomer(saved)
                    showAddCustomerDialog = false
                }
            }
        )
    }
}

/**
 * Responsive payment type selection card designed to avoid text wrapping.
 */
@Composable
private fun SalePaymentTypeCard(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    isSelected: Boolean,
    selectedColor: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(10.dp),
        color = if (isSelected) selectedColor else MaterialTheme.colorScheme.surfaceVariant,
        border = BorderStroke(
            width = if (isSelected) 1.5.dp else 1.dp,
            color = if (isSelected) selectedColor else MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)
        ),
        modifier = modifier.height(46.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = if (isSelected) Color.White else selectedColor,
                modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = title,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface,
                maxLines = 1,
                softWrap = false
            )
        }
    }
}

