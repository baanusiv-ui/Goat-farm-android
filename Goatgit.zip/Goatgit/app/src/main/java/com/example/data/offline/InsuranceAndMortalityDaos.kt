package com.example.data.offline

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface InsuranceDao {
    // --- Providers ---
    @Query("SELECT * FROM local_insurance_providers WHERE is_active = 1 ORDER BY company_name ASC")
    suspend fun getAllProviders(): List<InsuranceProviderEntity>

    @Query("SELECT * FROM local_insurance_providers ORDER BY company_name ASC")
    suspend fun getAllProvidersAdmin(): List<InsuranceProviderEntity>

    @Query("SELECT * FROM local_insurance_providers WHERE id = :id LIMIT 1")
    suspend fun getProviderById(id: String): InsuranceProviderEntity?

    @Query("UPDATE local_insurance_providers SET is_active = :isActive, updated_at = :updatedAt WHERE id = :id")
    suspend fun setProviderActive(id: String, isActive: Boolean, updatedAt: Long = System.currentTimeMillis())

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProvider(provider: InsuranceProviderEntity)

    // --- Policies ---
    @Query("SELECT * FROM local_insurance_policies ORDER BY expiry_date ASC")
    fun getAllPoliciesFlow(): Flow<List<InsurancePolicyEntity>>

    @Query("SELECT * FROM local_insurance_policies ORDER BY expiry_date ASC")
    suspend fun getAllPolicies(): List<InsurancePolicyEntity>

    @Query("SELECT * FROM local_insurance_policies WHERE id = :id LIMIT 1")
    suspend fun getPolicyById(id: String): InsurancePolicyEntity?

    @Query("SELECT * FROM local_insurance_policies WHERE goat_id = :goatId ORDER BY expiry_date DESC")
    suspend fun getPoliciesForGoat(goatId: String): List<InsurancePolicyEntity>

    @Query("SELECT * FROM local_insurance_policies WHERE goat_id = :goatId AND status IN ('Active', 'Expiring Soon') LIMIT 1")
    suspend fun getActivePolicyForGoat(goatId: String): InsurancePolicyEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPolicy(policy: InsurancePolicyEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllPolicies(policies: List<InsurancePolicyEntity>)

    @Query("UPDATE local_insurance_policies SET status = :status, updated_at = :updatedAt WHERE id = :id")
    suspend fun updatePolicyStatus(id: String, status: String, updatedAt: Long = System.currentTimeMillis())

    @Query("DELETE FROM local_insurance_policies WHERE id = :id")
    suspend fun deletePolicyById(id: String)

    // --- Quotes ---
    @Query("SELECT * FROM local_insurance_quotes WHERE goat_id = :goatId ORDER BY total_premium ASC")
    suspend fun getQuotesForGoat(goatId: String): List<InsuranceQuoteEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertQuote(quote: InsuranceQuoteEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllQuotes(quotes: List<InsuranceQuoteEntity>)

    @Query("DELETE FROM local_insurance_quotes WHERE goat_id = :goatId")
    suspend fun deleteQuotesForGoat(goatId: String)

    // --- Claims ---
    @Query("SELECT * FROM local_insurance_claims ORDER BY incident_date DESC")
    fun getAllClaimsFlow(): Flow<List<InsuranceClaimEntity>>

    @Query("SELECT * FROM local_insurance_claims ORDER BY incident_date DESC")
    suspend fun getAllClaims(): List<InsuranceClaimEntity>

    @Query("SELECT * FROM local_insurance_claims WHERE id = :id LIMIT 1")
    suspend fun getClaimById(id: String): InsuranceClaimEntity?

    @Query("SELECT * FROM local_insurance_claims WHERE policy_id = :policyId ORDER BY incident_date DESC")
    suspend fun getClaimsForPolicy(policyId: String): List<InsuranceClaimEntity>

    @Query("SELECT * FROM local_insurance_claims WHERE goat_id = :goatId ORDER BY incident_date DESC")
    suspend fun getClaimsForGoat(goatId: String): List<InsuranceClaimEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertClaim(claim: InsuranceClaimEntity)

    @Query("UPDATE local_insurance_claims SET status = :status, approved_amount = :approvedAmount, settlement_amount = :settlementAmount, settlement_date = :settlementDate, updated_at = :updatedAt WHERE id = :id")
    suspend fun updateClaimStatus(id: String, status: String, approvedAmount: Double?, settlementAmount: Double?, settlementDate: String?, updatedAt: Long = System.currentTimeMillis())

    @Query("UPDATE local_insurance_claims SET status = :status, updated_at = :updatedAt WHERE id = :id")
    suspend fun updateClaimStatusOnly(id: String, status: String, updatedAt: Long = System.currentTimeMillis())

    // --- Alerts ---
    @Query("SELECT * FROM local_insurance_alerts WHERE is_dismissed = 0 ORDER BY due_date ASC")
    suspend fun getActiveAlerts(): List<InsuranceAlertEntity>

    @Query("SELECT * FROM local_insurance_alerts WHERE policy_id = :policyId AND alert_type = :alertType AND days_before_expiry = :daysBeforeExpiry LIMIT 1")
    suspend fun findExistingAlert(policyId: String, alertType: String, daysBeforeExpiry: Int): InsuranceAlertEntity?

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertAlert(alert: InsuranceAlertEntity)

    @Query("UPDATE local_insurance_alerts SET is_dismissed = 1 WHERE id = :id")
    suspend fun dismissAlert(id: String)
}

@Dao
interface MortalityAndReproductionDao {
    // --- Reproductive Events (Deliveries, Abortions, Stillbirths) ---
    @Query("SELECT * FROM local_reproductive_events ORDER BY event_date DESC")
    fun getAllReproductiveEventsFlow(): Flow<List<ReproductiveEventEntity>>

    @Query("SELECT * FROM local_reproductive_events ORDER BY event_date DESC")
    suspend fun getAllReproductiveEvents(): List<ReproductiveEventEntity>

    @Query("SELECT * FROM local_reproductive_events WHERE doe_id = :doeId ORDER BY event_date DESC")
    suspend fun getEventsForDoe(doeId: String): List<ReproductiveEventEntity>

    @Query("SELECT * FROM local_reproductive_events WHERE event_type = 'ABORTION' ORDER BY event_date DESC")
    suspend fun getAbortions(): List<ReproductiveEventEntity>

    @Query("SELECT * FROM local_reproductive_events WHERE event_type = 'STILLBIRTH' ORDER BY event_date DESC")
    suspend fun getStillbirths(): List<ReproductiveEventEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertReproductiveEvent(event: ReproductiveEventEntity)

    // --- Post Delivery Monitoring ---
    @Query("SELECT * FROM local_post_delivery_checks WHERE doe_id = :doeId ORDER BY check_date DESC")
    suspend fun getChecksForDoe(doeId: String): List<PostDeliveryCheckEntity>

    @Query("SELECT * FROM local_post_delivery_checks ORDER BY check_date DESC")
    suspend fun getAllPostDeliveryChecks(): List<PostDeliveryCheckEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPostDeliveryCheck(check: PostDeliveryCheckEntity)

    // --- Mortality Events ---
    @Query("SELECT * FROM local_mortality_events ORDER BY death_date DESC")
    fun getAllMortalityEventsFlow(): Flow<List<MortalityEventEntity>>

    @Query("SELECT * FROM local_mortality_events ORDER BY death_date DESC")
    suspend fun getAllMortalityEvents(): List<MortalityEventEntity>

    @Query("SELECT * FROM local_mortality_events WHERE id = :id LIMIT 1")
    suspend fun getMortalityEventById(id: String): MortalityEventEntity?

    @Query("SELECT * FROM local_mortality_events WHERE goat_id = :goatId LIMIT 1")
    suspend fun getMortalityForGoat(goatId: String): MortalityEventEntity?

    @Query("SELECT * FROM local_mortality_events WHERE event_type = 'KID_DEATH' ORDER BY death_date DESC")
    suspend fun getKidDeaths(): List<MortalityEventEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMortalityEvent(event: MortalityEventEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllMortalityEvents(events: List<MortalityEventEntity>)

    @Query("DELETE FROM local_mortality_events WHERE id = :id")
    suspend fun deleteMortalityEventById(id: String)
}
