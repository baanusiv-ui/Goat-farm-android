package com.example.data.payment

import android.content.Context
import android.content.SharedPreferences

class PaymentSettingsManager(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences("payment_settings_prefs", Context.MODE_PRIVATE)

    companion object {
        private const val KEY_CURRENCY = "payment_currency"
        private const val KEY_UPI_QR_ENABLED = "payment_upi_qr_enabled"
        private const val KEY_MERCHANT_UPI_ID = "payment_merchant_upi_id"
        private const val KEY_MERCHANT_NAME = "payment_merchant_name"
        private const val KEY_PAYTM_GATEWAY_ENABLED = "payment_paytm_gateway_enabled"
        private const val KEY_PAYTM_ENVIRONMENT = "payment_paytm_environment"
        private const val KEY_PAYTM_MERCHANT_ID = "payment_paytm_merchant_id"

        const val ENV_STAGING = "STAGING"
        const val ENV_PRODUCTION = "PRODUCTION"

        @Volatile
        private var INSTANCE: PaymentSettingsManager? = null

        fun getInstance(context: Context): PaymentSettingsManager {
            return INSTANCE ?: synchronized(this) {
                val instance = PaymentSettingsManager(context.applicationContext)
                INSTANCE = instance
                instance
            }
        }
    }

    val currency: String
        get() = prefs.getString(KEY_CURRENCY, "INR") ?: "INR"

    val isUpiQrEnabled: Boolean
        get() = prefs.getBoolean(KEY_UPI_QR_ENABLED, true)

    val merchantUpiId: String
        get() = prefs.getString(KEY_MERCHANT_UPI_ID, "goatfarm.paytm@paytm") ?: "goatfarm.paytm@paytm"

    val merchantName: String
        get() = prefs.getString(KEY_MERCHANT_NAME, "Goat Farm Management") ?: "Goat Farm Management"

    val isPaytmGatewayEnabled: Boolean
        get() = prefs.getBoolean(KEY_PAYTM_GATEWAY_ENABLED, true)

    val paytmEnvironment: String
        get() = prefs.getString(KEY_PAYTM_ENVIRONMENT, ENV_STAGING) ?: ENV_STAGING

    val isTestMode: Boolean
        get() = paytmEnvironment == ENV_STAGING

    val paytmMerchantId: String
        get() = prefs.getString(KEY_PAYTM_MERCHANT_ID, "TEST_GOAT_FARM_MID_01") ?: "TEST_GOAT_FARM_MID_01"

    fun setUpiQrEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_UPI_QR_ENABLED, enabled).apply()
    }

    fun setMerchantUpiId(upiId: String) {
        prefs.edit().putString(KEY_MERCHANT_UPI_ID, upiId.trim()).apply()
    }

    fun setMerchantName(name: String) {
        prefs.edit().putString(KEY_MERCHANT_NAME, name.trim()).apply()
    }

    fun setPaytmGatewayEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_PAYTM_GATEWAY_ENABLED, enabled).apply()
    }

    fun setPaytmEnvironment(env: String) {
        val safeEnv = if (env == ENV_PRODUCTION) ENV_PRODUCTION else ENV_STAGING
        prefs.edit().putString(KEY_PAYTM_ENVIRONMENT, safeEnv).apply()
    }

    fun setPaytmMerchantId(mid: String) {
        prefs.edit().putString(KEY_PAYTM_MERCHANT_ID, mid.trim()).apply()
    }
}
