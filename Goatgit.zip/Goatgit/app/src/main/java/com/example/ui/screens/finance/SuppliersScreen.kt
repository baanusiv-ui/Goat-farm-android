package com.example.ui.screens.finance

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.supabase.*
import com.example.ui.components.DatePickerField
import com.example.ui.theme.*
import com.example.util.CurrencyUtils
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.TimeUnit

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SuppliersScreen(
    repository: GoatRepository,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler { onNavigateBack() }

    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val dateFormat = remember { SimpleDateFormat("yyyy-MM-dd", Locale.US) }
    val today = remember { dateFormat.format(Date()) }

    var suppliers by remember { mutableStateOf<List<Supplier>>(emptyList()) }
    var invoices by remember { mutableStateOf<List<SupplierInvoice>>(emptyList()) }
    var accounts by remember { mutableStateOf<List<FinancialAccount>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }

    var showAddSupplierDialog by remember { mutableStateOf(false) }
    var showAddInvoiceDialog by remember { mutableStateOf(false) }
    var payingInvoice by remember { mutableStateOf<SupplierInvoice?>(null) }
    var selectedTab by remember { mutableStateOf(0) } // 0: Invoices / Payables, 1: Supplier Directory, 2: Aging Schedule

    fun loadData() {
        isLoading = true
        coroutineScope.launch {
            val supRes = repository.finance.getSuppliers()
            if (supRes.isSuccess) suppliers = supRes.getOrThrow()

            val invRes = repository.finance.getSupplierInvoices()
            if (invRes.isSuccess) invoices = invRes.getOrThrow().sortedByDescending { it.invoice_date }

            val accRes = repository.finance.getAccounts()
            if (accRes.isSuccess) accounts = accRes.getOrThrow()

            isLoading = false
        }
    }

    LaunchedEffect(Unit) {
        loadData()
    }

    val totalPayable = remember(invoices) { invoices.sumOf { it.balance_due } }
    val overdueCount = remember(invoices, today) { invoices.count { it.status != "PAID" && it.due_date < today } }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "Creditors & Suppliers",
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp
                        )
                        Text(
                            text = "Purchase Invoices, Payables Ledger & Ageing",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack, modifier = Modifier.testTag("suppliers_btn_back")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(onClick = { loadData() }, modifier = Modifier.testTag("suppliers_btn_refresh")) {
                        Icon(Icons.Default.Refresh, contentDescription = "Refresh")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.White)
            )
        },
        floatingActionButton = {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = { showAddInvoiceDialog = true },
                    colors = ButtonDefaults.buttonColors(containerColor = FarmGreenDark),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.testTag("btn_add_supplier_invoice")
                ) {
                    Icon(Icons.Default.Receipt, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Add Invoice", fontWeight = FontWeight.Bold)
                }
                Button(
                    onClick = { showAddSupplierDialog = true },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E3A8A)),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.testTag("btn_add_supplier_master")
                ) {
                    Icon(Icons.Default.PersonAdd, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("New Supplier", fontWeight = FontWeight.Bold)
                }
            }
        },
        containerColor = Color(0xFFF8F9FA),
        modifier = modifier
    ) { innerPadding ->
        if (isLoading) {
            Box(modifier = Modifier.fillMaxSize().padding(innerPadding), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = FarmGreenDark)
            }
        } else {
            Column(modifier = Modifier.fillMaxSize().padding(innerPadding)) {
                TabRow(selectedTabIndex = selectedTab, containerColor = Color.White, contentColor = FarmGreenDark) {
                    Tab(selected = selectedTab == 0, onClick = { selectedTab = 0 }, text = { Text("Invoices (${invoices.size})", fontWeight = if (selectedTab == 0) FontWeight.Bold else FontWeight.Normal) })
                    Tab(selected = selectedTab == 1, onClick = { selectedTab = 1 }, text = { Text("Suppliers (${suppliers.size})", fontWeight = if (selectedTab == 1) FontWeight.Bold else FontWeight.Normal) })
                    Tab(selected = selectedTab == 2, onClick = { selectedTab = 2 }, text = { Text("Aging Analysis", fontWeight = if (selectedTab == 2) FontWeight.Bold else FontWeight.Normal) })
                }

                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    item { Spacer(modifier = Modifier.height(4.dp)) }

                    // Total Payables Card
                    item {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = if (totalPayable > 0) Color(0xFF991B1B) else FarmGreenDark),
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier.fillMaxWidth().testTag("supplier_payables_card")
                        ) {
                            Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text("Total Accounts Payable to Suppliers", color = Color.White.copy(alpha = 0.85f), fontSize = 12.sp)
                                Text(
                                    text = CurrencyUtils.formatInr(totalPayable),
                                    fontSize = 26.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = Color.White
                                )
                                Text(
                                    text = "$overdueCount Overdue Invoices • ${suppliers.size} Supplier Accounts",
                                    color = Color.White.copy(alpha = 0.85f),
                                    fontSize = 11.sp
                                )
                            }
                        }
                    }

                    if (selectedTab == 0) {
                        if (invoices.isEmpty()) {
                            item {
                                Card(colors = CardDefaults.cardColors(containerColor = Color.White), modifier = Modifier.fillMaxWidth().padding(vertical = 16.dp)) {
                                    Box(modifier = Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                                        Text("No supplier invoices recorded. Tap '+ Add Invoice' to log feed, medicine, or equipment bills.", color = Color.Gray, fontSize = 13.sp)
                                    }
                                }
                            }
                        } else {
                            items(invoices) { inv ->
                                SupplierInvoiceCard(
                                    invoice = inv,
                                    suppliersMap = suppliers.associateBy { it.id },
                                    today = today,
                                    onPayNow = { payingInvoice = inv }
                                )
                            }
                        }
                    } else if (selectedTab == 1) {
                        items(suppliers) { sup ->
                            SupplierMasterCard(supplier = sup)
                        }
                    } else {
                        // Aging Analysis
                        item {
                            SupplierAgingAnalysisCard(invoices = invoices, today = today)
                        }
                    }

                    item { Spacer(modifier = Modifier.height(72.dp)) }
                }
            }
        }
    }

    // Add Supplier Dialog
    if (showAddSupplierDialog) {
        AddSupplierDialog(
            onDismiss = { showAddSupplierDialog = false },
            onSave = { sup ->
                showAddSupplierDialog = false
                coroutineScope.launch {
                    val res = repository.finance.addSupplier(sup)
                    if (res.isSuccess) {
                        Toast.makeText(context, "Supplier created & synced to Supabase", Toast.LENGTH_SHORT).show()
                        loadData()
                    } else {
                        Toast.makeText(context, "Failed: ${res.exceptionOrNull()?.message}", Toast.LENGTH_LONG).show()
                    }
                }
            }
        )
    }

    // Add Invoice Dialog
    if (showAddInvoiceDialog) {
        AddSupplierInvoiceDialog(
            suppliers = suppliers,
            onDismiss = { showAddInvoiceDialog = false },
            onSave = { inv ->
                showAddInvoiceDialog = false
                coroutineScope.launch {
                    val res = repository.finance.createSupplierInvoice(inv)
                    if (res.isSuccess) {
                        Toast.makeText(context, "Supplier invoice recorded & payable updated!", Toast.LENGTH_SHORT).show()
                        loadData()
                    } else {
                        Toast.makeText(context, "Failed: ${res.exceptionOrNull()?.message}", Toast.LENGTH_LONG).show()
                    }
                }
            }
        )
    }

    // Pay Invoice Dialog
    if (payingInvoice != null) {
        PaySupplierInvoiceDialog(
            invoice = payingInvoice!!,
            suppliers = suppliers,
            accounts = accounts,
            onDismiss = { payingInvoice = null },
            onConfirmPay = { invId, supId, accId, amt, date ->
                payingInvoice = null
                coroutineScope.launch {
                    val res = repository.finance.paySupplierInvoice(invId, supId, accId, amt, date)
                    if (res.isSuccess) {
                        Toast.makeText(context, "Supplier payment recorded (No duplicate expense)", Toast.LENGTH_SHORT).show()
                        loadData()
                    } else {
                        Toast.makeText(context, "Payment failed: ${res.exceptionOrNull()?.message}", Toast.LENGTH_LONG).show()
                    }
                }
            }
        )
    }
}

@Composable
private fun SupplierInvoiceCard(
    invoice: SupplierInvoice,
    suppliersMap: Map<String, Supplier>,
    today: String,
    onPayNow: () -> Unit
) {
    val sup = suppliersMap[invoice.supplier_id]
    val isPaid = invoice.status.equals("PAID", ignoreCase = true)
    val isOverdue = !isPaid && invoice.due_date < today

    Card(
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(14.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier.fillMaxWidth().testTag("invoice_card_${invoice.id}")
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(sup?.name ?: "Supplier", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    Text("Inv #${invoice.invoice_number} • Date: ${invoice.invoice_date}", fontSize = 11.sp, color = Color.Gray)
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = CurrencyUtils.formatInr(invoice.total_amount),
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 16.sp
                    )
                    Surface(shape = RoundedCornerShape(4.dp), color = if (isPaid) Color(0xFFE8F5E9) else if (isOverdue) Color(0xFFFFEBEE) else Color(0xFFFFF3E0)) {
                        Text(
                            text = if (isOverdue) "OVERDUE" else invoice.status,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isPaid) FarmGreenDark else if (isOverdue) FarmError else Color(0xFFE65100),
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }
            }

            HorizontalDivider(color = Color(0xFFF0F0F0))

            Text("Items: ${invoice.items_description}", fontSize = 12.sp, color = Color.DarkGray)

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text("Due: ${invoice.due_date}", fontSize = 11.sp, color = if (isOverdue) FarmError else Color.Gray)
                if (!isPaid) {
                    Text("Balance: ${CurrencyUtils.formatInr(invoice.balance_due)}", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = FarmError)
                }
            }

            if (!isPaid) {
                Button(
                    onClick = onPayNow,
                    colors = ButtonDefaults.buttonColors(containerColor = FarmGreenDark),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth().height(36.dp).testTag("btn_pay_supplier_${invoice.id}")
                ) {
                    Text("Pay Supplier (${CurrencyUtils.formatInr(invoice.balance_due)})", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
private fun SupplierMasterCard(supplier: Supplier) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier.fillMaxWidth().testTag("supplier_master_${supplier.id}")
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(supplier.name, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                Text(
                    text = CurrencyUtils.formatInr(supplier.current_outstanding),
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 15.sp,
                    color = if (supplier.current_outstanding > 0) FarmError else FarmGreenDark
                )
            }
            if (!supplier.gstin.isNullOrBlank()) Text("GSTIN: ${supplier.gstin}", fontSize = 11.sp, color = Color.Gray)
            if (!supplier.phone.isNullOrBlank()) Text("Phone: ${supplier.phone}", fontSize = 11.sp, color = Color.Gray)
            Text("Credit Period: ${supplier.credit_period_days} Days • Limit: ${CurrencyUtils.formatInr(supplier.credit_limit)}", fontSize = 11.sp, color = Color.DarkGray)
        }
    }
}

@Composable
private fun SupplierAgingAnalysisCard(invoices: List<SupplierInvoice>, today: String) {
    val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
    val todayDate = try { sdf.parse(today) ?: Date() } catch (_: Exception) { Date() }

    var bucketCurrent = 0.0 // not overdue
    var bucket0to30 = 0.0
    var bucket31to60 = 0.0
    var bucket61to90 = 0.0
    var bucket90plus = 0.0

    for (inv in invoices.filter { it.status != "PAID" && it.balance_due > 0 }) {
        try {
            val dueDate = sdf.parse(inv.due_date) ?: todayDate
            val diffMs = todayDate.time - dueDate.time
            val daysOverdue = TimeUnit.MILLISECONDS.toDays(diffMs).toInt()

            when {
                daysOverdue <= 0 -> bucketCurrent += inv.balance_due
                daysOverdue in 1..30 -> bucket0to30 += inv.balance_due
                daysOverdue in 31..60 -> bucket31to60 += inv.balance_due
                daysOverdue in 61..90 -> bucket61to90 += inv.balance_due
                else -> bucket90plus += inv.balance_due
            }
        } catch (_: Exception) {}
    }

    Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth().testTag("aging_analysis_card")) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Supplier Ageing Schedule (Accounts Payable)", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = Color(0xFF1E3A8A))
            Text("Tracks overdue credit days to manage cash flow and vendor credit terms.", fontSize = 11.sp, color = Color.Gray)

            HorizontalDivider(color = Color(0xFFEEEEEE))

            AgingRow(label = "Not Overdue (Within Credit Terms)", amount = bucketCurrent, color = FarmGreenDark)
            AgingRow(label = "1 - 30 Days Overdue", amount = bucket0to30, color = Color(0xFFE65100))
            AgingRow(label = "31 - 60 Days Overdue", amount = bucket31to60, color = Color(0xFFD97706))
            AgingRow(label = "61 - 90 Days Overdue", amount = bucket61to90, color = Color(0xFFB45309))
            AgingRow(label = "90+ Days Critical Overdue", amount = bucket90plus, color = FarmError)
        }
    }
}

@Composable
private fun AgingRow(label: String, amount: Double, color: Color) {
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(label, fontSize = 12.sp, color = Color.DarkGray)
        Text(CurrencyUtils.formatInr(amount), fontWeight = FontWeight.Bold, fontSize = 13.sp, color = color)
    }
}

@Composable
private fun AddSupplierDialog(
    onDismiss: () -> Unit,
    onSave: (Supplier) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var address by remember { mutableStateOf("") }
    var gstin by remember { mutableStateOf("") }
    var creditLimitStr by remember { mutableStateOf("50000") }
    var creditDaysStr by remember { mutableStateOf("30") }

    Dialog(onDismissRequest = onDismiss) {
        Surface(shape = RoundedCornerShape(16.dp), color = Color.White, modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("New Supplier / Creditor", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = Color(0xFF1E3A8A))

                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Supplier Name *") }, singleLine = true, modifier = Modifier.fillMaxWidth().testTag("input_supplier_name"))
                OutlinedTextField(value = phone, onValueChange = { phone = it }, label = { Text("Phone Number") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = gstin, onValueChange = { gstin = it }, label = { Text("GSTIN (Optional)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = address, onValueChange = { address = it }, label = { Text("Address / City") }, singleLine = true, modifier = Modifier.fillMaxWidth())

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = creditDaysStr, onValueChange = { creditDaysStr = it }, label = { Text("Credit Days") }, modifier = Modifier.weight(1f))
                    OutlinedTextField(value = creditLimitStr, onValueChange = { creditLimitStr = it }, label = { Text("Credit Limit (₹)") }, modifier = Modifier.weight(1f))
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    TextButton(onClick = onDismiss) { Text("Cancel") }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            if (name.isBlank()) return@Button
                            val sup = Supplier(
                                name = name.trim(),
                                phone = phone.trim().ifBlank { null },
                                address = address.trim().ifBlank { null },
                                gstin = gstin.trim().ifBlank { null },
                                credit_limit = creditLimitStr.toDoubleOrNull() ?: 0.0,
                                credit_period_days = creditDaysStr.toIntOrNull() ?: 30
                            )
                            onSave(sup)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E3A8A)),
                        enabled = name.isNotBlank(),
                        modifier = Modifier.testTag("btn_save_supplier")
                    ) {
                        Text("Save Supplier")
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AddSupplierInvoiceDialog(
    suppliers: List<Supplier>,
    onDismiss: () -> Unit,
    onSave: (SupplierInvoice) -> Unit
) {
    var supplierId by remember { mutableStateOf(suppliers.firstOrNull()?.id ?: "") }
    var invoiceNo by remember { mutableStateOf("INV-" + System.currentTimeMillis().toString().takeLast(5)) }
    var invoiceDate by remember { mutableStateOf(SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())) }
    var dueDate by remember { mutableStateOf(SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())) }
    var itemsDesc by remember { mutableStateOf("") }
    var taxableStr by remember { mutableStateOf("") }
    var gstRateStr by remember { mutableStateOf("5") }

    val taxable = taxableStr.toDoubleOrNull() ?: 0.0
    val gstRate = gstRateStr.toDoubleOrNull() ?: 0.0
    val gstAmount = taxable * (gstRate / 100.0)
    val totalAmount = taxable + gstAmount

    var supExpanded by remember { mutableStateOf(false) }

    Dialog(onDismissRequest = onDismiss) {
        Surface(shape = RoundedCornerShape(16.dp), color = Color.White, modifier = Modifier.fillMaxWidth().fillMaxHeight(0.9f)) {
            Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Add Supplier Purchase Invoice", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = FarmGreenDark)

                LazyColumn(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    item {
                        ExposedDropdownMenuBox(expanded = supExpanded, onExpandedChange = { supExpanded = !supExpanded }) {
                            val sel = suppliers.firstOrNull { it.id == supplierId }
                            OutlinedTextField(
                                value = sel?.name ?: "Select Supplier",
                                onValueChange = {},
                                readOnly = true,
                                label = { Text("Supplier *") },
                                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = supExpanded) },
                                modifier = Modifier.fillMaxWidth().menuAnchor()
                            )
                            ExposedDropdownMenu(expanded = supExpanded, onDismissRequest = { supExpanded = false }) {
                                suppliers.forEach { s ->
                                    DropdownMenuItem(text = { Text(s.name) }, onClick = { supplierId = s.id; supExpanded = false })
                                }
                            }
                        }
                    }

                    item {
                        OutlinedTextField(value = invoiceNo, onValueChange = { invoiceNo = it }, label = { Text("Invoice Number *") }, singleLine = true, modifier = Modifier.fillMaxWidth().testTag("input_invoice_number"))
                    }

                    item {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            DatePickerField(dateValue = invoiceDate, onDateSelected = { invoiceDate = it }, label = "Invoice Date", modifier = Modifier.weight(1f))
                            DatePickerField(dateValue = dueDate, onDateSelected = { dueDate = it }, label = "Due Date", modifier = Modifier.weight(1f))
                        }
                    }

                    item {
                        OutlinedTextField(value = itemsDesc, onValueChange = { itemsDesc = it }, label = { Text("Items Description *") }, placeholder = { Text("e.g. 50 bags Concentrate Feed, Vaccines") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    }

                    item {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(value = taxableStr, onValueChange = { taxableStr = it }, label = { Text("Taxable Value (₹) *") }, modifier = Modifier.weight(1.3f).testTag("input_taxable_value"))
                            OutlinedTextField(value = gstRateStr, onValueChange = { gstRateStr = it }, label = { Text("GST (%)") }, modifier = Modifier.weight(0.9f))
                        }
                    }

                    item {
                        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFF1F8E9)), modifier = Modifier.fillMaxWidth()) {
                            Row(modifier = Modifier.padding(10.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Total Invoice Value (with GST):", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                Text(CurrencyUtils.formatInr(totalAmount), fontWeight = FontWeight.ExtraBold, fontSize = 14.sp, color = FarmGreenDark)
                            }
                        }
                    }
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    TextButton(onClick = onDismiss) { Text("Cancel") }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            if (supplierId.isBlank() || invoiceNo.isBlank() || taxable <= 0) return@Button
                            val inv = SupplierInvoice(
                                supplier_id = supplierId,
                                invoice_number = invoiceNo.trim(),
                                invoice_date = invoiceDate,
                                due_date = dueDate,
                                items_description = itemsDesc.trim().ifBlank { "Farm supplies" },
                                taxable_value = taxable,
                                gst_rate = gstRate,
                                gst_amount = gstAmount,
                                total_amount = totalAmount,
                                balance_due = totalAmount,
                                status = "UNPAID"
                            )
                            onSave(inv)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = FarmGreenDark),
                        enabled = supplierId.isNotBlank() && taxable > 0,
                        modifier = Modifier.testTag("btn_save_invoice")
                    ) {
                        Text("Save Invoice")
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun PaySupplierInvoiceDialog(
    invoice: SupplierInvoice,
    suppliers: List<Supplier>,
    accounts: List<FinancialAccount>,
    onDismiss: () -> Unit,
    onConfirmPay: (invId: String, supId: String, accountId: String, amount: Double, date: String) -> Unit
) {
    val sup = suppliers.firstOrNull { it.id == invoice.supplier_id }
    var accountId by remember { mutableStateOf(accounts.firstOrNull()?.id ?: "") }
    var payAmountStr by remember { mutableStateOf(invoice.balance_due.toString()) }
    var payDate by remember { mutableStateOf(SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())) }
    var accExpanded by remember { mutableStateOf(false) }

    Dialog(onDismissRequest = onDismiss) {
        Surface(shape = RoundedCornerShape(16.dp), color = Color.White, modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Pay Supplier Invoice", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = FarmGreenDark)
                Text("Accounting integrity: This reduces bank/cash and decreases the supplier payable without creating a duplicate expense.", fontSize = 11.sp, color = Color.Gray)

                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFF1F8E9)), modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text("Supplier: ${sup?.name ?: "Supplier"}", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text("Invoice #${invoice.invoice_number} • Balance: ${CurrencyUtils.formatInr(invoice.balance_due)}", fontSize = 12.sp)
                    }
                }

                ExposedDropdownMenuBox(expanded = accExpanded, onExpandedChange = { accExpanded = !accExpanded }) {
                    val selAcc = accounts.firstOrNull { it.id == accountId }
                    OutlinedTextField(
                        value = "${selAcc?.account_name ?: "Select Account"} (${CurrencyUtils.formatInr(selAcc?.current_balance ?: 0.0)})",
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Payment Account *") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = accExpanded) },
                        modifier = Modifier.fillMaxWidth().menuAnchor()
                    )
                    ExposedDropdownMenu(expanded = accExpanded, onDismissRequest = { accExpanded = false }) {
                        accounts.forEach { acc ->
                            DropdownMenuItem(text = { Text("${acc.account_name} (${CurrencyUtils.formatInr(acc.current_balance)})") }, onClick = { accountId = acc.id; accExpanded = false })
                        }
                    }
                }

                OutlinedTextField(
                    value = payAmountStr,
                    onValueChange = { payAmountStr = it },
                    label = { Text("Amount (₹) *") },
                    modifier = Modifier.fillMaxWidth()
                )

                DatePickerField(dateValue = payDate, onDateSelected = { payDate = it }, label = "Payment Date *")

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    TextButton(onClick = onDismiss) { Text("Cancel") }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            val amt = payAmountStr.toDoubleOrNull() ?: 0.0
                            if (amt > 0 && accountId.isNotBlank()) {
                                onConfirmPay(invoice.id, invoice.supplier_id, accountId, amt, payDate)
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = FarmGreenDark),
                        enabled = (payAmountStr.toDoubleOrNull() ?: 0.0) > 0 && accountId.isNotBlank(),
                        modifier = Modifier.testTag("btn_confirm_pay_supplier")
                    ) {
                        Text("Confirm Payment")
                    }
                }
            }
        }
    }
}
