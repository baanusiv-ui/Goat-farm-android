package com.example.ui.screens.sales

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.supabase.CustomerRecord
import com.example.data.supabase.SaleRecord
import com.example.ui.theme.FarmGreenDark
import com.example.util.CurrencyUtils

@Composable
fun CustomersCreditView(
    customers: List<CustomerRecord>,
    sales: List<SaleRecord>,
    onRecordPaymentClick: (sale: SaleRecord) -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }

    val filteredCustomers = remember(customers, searchQuery) {
        if (searchQuery.isBlank()) customers
        else customers.filter {
            it.name_c.contains(searchQuery, ignoreCase = true) ||
                    it.phone_c.contains(searchQuery) ||
                    it.village_c.contains(searchQuery, ignoreCase = true)
        }
    }

    val totalOutstanding = remember(customers) {
        customers.sumOf { it.outstanding_balance_c }
    }

    Column(modifier = Modifier.fillMaxWidth().padding(16.dp)) {
        // Summary Header Card
        Surface(
            shape = RoundedCornerShape(12.dp),
            color = Color(0xFFFEF2F2),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFFECACA)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier.padding(14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier.size(42.dp).clip(CircleShape).background(Color(0xFFFEE2E2)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.CreditCard, contentDescription = null, tint = Color(0xFFDC2626), modifier = Modifier.size(24.dp))
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text("Total Udhaar / Credit Balance", fontSize = 11.sp, color = Color.Gray, fontWeight = FontWeight.Medium)
                        Text(CurrencyUtils.formatInr(totalOutstanding), fontSize = 18.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFFDC2626))
                    }
                }
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Color.White
                ) {
                    Text(
                        text = "${customers.count { it.outstanding_balance_c > 0 }} with balance",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Color(0xFFB91C1C),
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Search Field
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            placeholder = { Text("Search by customer name, phone, village...") },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = Color.Gray) },
            singleLine = true,
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier.fillMaxWidth().testTag("customer_search_input")
        )

        Spacer(modifier = Modifier.height(12.dp))

        if (filteredCustomers.isEmpty()) {
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = Color.White,
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
                modifier = Modifier.fillMaxWidth().padding(vertical = 20.dp)
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(Icons.Default.PeopleOutline, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(44.dp))
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("No Customers Found", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    Text("Customers recorded with Credit sales will appear here.", fontSize = 12.sp, color = Color.Gray)
                }
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(filteredCustomers, key = { it.id }) { customer ->
                    val customerSales = sales.filter {
                        (it.customer_id_c == customer.id || it.buyer_name_c.equals(customer.name_c, ignoreCase = true)) &&
                                it.balance_due_c > 0
                    }

                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            // Top Row: Name and Balance
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier.size(36.dp).clip(CircleShape).background(Color(0xFFE2E8F0)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(customer.name_c.take(1).uppercase(), fontWeight = FontWeight.Bold, color = Color(0xFF334155))
                                    }
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column {
                                        Text(customer.name_c, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                                        val subtitle = listOfNotNull(
                                            customer.phone_c.ifBlank { null },
                                            customer.village_c.ifBlank { null } ?: customer.address_c.ifBlank { null }
                                        ).joinToString(" • ")
                                        if (subtitle.isNotBlank()) {
                                            Text(subtitle, fontSize = 11.sp, color = Color.Gray)
                                        }
                                    }
                                }

                                Column(horizontalAlignment = Alignment.End) {
                                    Text("Balance", fontSize = 10.sp, color = Color.Gray)
                                    Text(
                                        CurrencyUtils.formatInr(customer.outstanding_balance_c),
                                        fontWeight = FontWeight.ExtraBold,
                                        fontSize = 15.sp,
                                        color = if (customer.outstanding_balance_c > 0) Color(0xFFDC2626) else FarmGreenDark
                                    )
                                }
                            }

                            HorizontalDivider(color = Color(0xFFF1F5F9))

                            // Stats: Purchases & Paid
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Total Purchases: ${CurrencyUtils.formatInr(customer.total_purchases_c)}", fontSize = 11.sp, color = Color.Gray)
                                Text("Total Paid: ${CurrencyUtils.formatInr(customer.total_paid_c)}", fontSize = 11.sp, color = Color(0xFF15803D), fontWeight = FontWeight.SemiBold)
                            }

                            // Action: Record Payment if there is an active credit sale
                            if (customerSales.isNotEmpty()) {
                                val latestSale = customerSales.first()
                                Button(
                                    onClick = { onRecordPaymentClick(latestSale) },
                                    shape = RoundedCornerShape(8.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = FarmGreenDark),
                                    modifier = Modifier.fillMaxWidth().height(38.dp),
                                    contentPadding = PaddingValues(0.dp)
                                ) {
                                    Icon(Icons.Default.Payments, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Record Payment (${CurrencyUtils.formatInr(customer.outstanding_balance_c)})", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
