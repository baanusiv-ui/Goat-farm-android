package com.example.ui.components

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.i18n.t
import com.example.util.CurrencyUtils
import java.util.Locale

// Paytm Brand Colors
val PaytmNavy = Color(0xFF002E6E)
val PaytmCyan = Color(0xFF00BAF2)
val PaytmLightBg = Color(0xFFF2F7FD)

@Composable
fun PaytmQrStandeeCard(
    amount: Double,
    merchantName: String,
    merchantVpa: String,
    orderReference: String,
    onPaymentReceivedClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var isQrExpanded by remember { mutableStateOf(true) }

    val formattedAmount = CurrencyUtils.formatInr(amount)
    val upiUriString = remember(amount, merchantVpa, merchantName, orderReference) {
        "upi://pay?pa=$merchantVpa&pn=${Uri.encode(merchantName)}&am=${String.format(Locale.US, "%.2f", amount)}&cu=INR&tn=${Uri.encode("Goat Farm $orderReference")}"
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("paytm_qr_standee_card"),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 6.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Standee Header: Paytm Navy Banner with All-in-One QR branding
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(PaytmNavy)
                    .padding(vertical = 12.dp, horizontal = 16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = Color.White,
                            modifier = Modifier.size(width = 46.dp, height = 24.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Text(
                                    text = "Paytm",
                                    color = PaytmNavy,
                                    fontWeight = FontWeight.Black,
                                    fontSize = 11.sp
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = "Accepted Here",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                            Text(
                                text = "Paytm Se UPI • All-in-One QR",
                                color = PaytmCyan,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }

                    // UPI Badge
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = Color.White.copy(alpha = 0.2f),
                        modifier = Modifier.padding(2.dp)
                    ) {
                        Text(
                            text = "BHIM UPI",
                            color = Color.White,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }
            }

            // Merchant Name & Verified Tag
            Spacer(modifier = Modifier.height(10.dp))
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                Text(
                    text = merchantName,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    color = Color(0xFF1E293B)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Icon(
                    imageVector = Icons.Default.CheckCircle,
                    contentDescription = "Verified Merchant",
                    tint = PaytmCyan,
                    modifier = Modifier.size(16.dp)
                )
            }
            Text(
                text = "UPI ID: $merchantVpa",
                fontSize = 11.sp,
                color = Color.Gray
            )

            // Prominent Amount To Pay Banner
            Spacer(modifier = Modifier.height(12.dp))
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = PaytmLightBg,
                border = androidx.compose.foundation.BorderStroke(1.dp, PaytmCyan.copy(alpha = 0.5f)),
                modifier = Modifier
                    .fillMaxWidth(0.88f)
                    .testTag("qr_amount_banner")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = t("sales.pay_label", "Pay"),
                            style = MaterialTheme.typography.labelMedium,
                            color = Color.Gray
                        )
                        Text(
                            text = formattedAmount,
                            fontSize = 24.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = PaytmNavy
                        )
                    }
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = PaytmCyan,
                        contentColor = Color.White
                    ) {
                        Text(
                            text = "INR ₹",
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }
            }

            // Toggle QR Visibility / Zoom Button
            Spacer(modifier = Modifier.height(10.dp))
            OutlinedButton(
                onClick = { isQrExpanded = !isQrExpanded },
                shape = RoundedCornerShape(20.dp),
                contentPadding = PaddingValues(horizontal = 14.dp, vertical = 4.dp),
                modifier = Modifier
                    .height(34.dp)
                    .testTag("toggle_qr_button")
            ) {
                Icon(
                    imageVector = if (isQrExpanded) Icons.Default.VisibilityOff else Icons.Default.QrCode,
                    contentDescription = null,
                    modifier = Modifier.size(16.dp),
                    tint = PaytmNavy
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = if (isQrExpanded) "Hide QR" else "SHOW QR",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = PaytmNavy
                )
            }

            // QR Code Matrix Artwork Display
            AnimatedVisibility(visible = isQrExpanded) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.padding(top = 10.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(230.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .background(Color.White)
                            .border(2.dp, PaytmNavy.copy(alpha = 0.2f), RoundedCornerShape(16.dp))
                            .padding(10.dp)
                            .testTag("paytm_qr_image"),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            painter = painterResource(id = R.drawable.ic_paytm_qr_code),
                            contentDescription = "Paytm Merchant QR Code",
                            tint = Color.Unspecified,
                            modifier = Modifier.fillMaxSize()
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Scan with any UPI App (GPay, PhonePe, Paytm, BHIM)",
                        fontSize = 11.sp,
                        color = Color.Gray,
                        textAlign = TextAlign.Center
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))
            Divider(color = Color(0xFFE2E8F0), thickness = 1.dp)

            // Primary Action Buttons
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // OPEN UPI APP
                Button(
                    onClick = {
                        openUpiApp(context, upiUriString)
                    },
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = PaytmCyan),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("open_upi_app_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Launch,
                        contentDescription = null,
                        tint = Color.White
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "OPEN UPI APP",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = Color.White
                    )
                }

                // PAYMENT RECEIVED (Manual confirmation triggers)
                Button(
                    onClick = onPaymentReceivedClick,
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("payment_received_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = null,
                        tint = Color.White
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "PAYMENT RECEIVED",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = Color.White
                    )
                }
            }
        }
    }
}

private fun openUpiApp(context: Context, upiUriString: String) {
    try {
        val upiUri = Uri.parse(upiUriString)
        val intent = Intent(Intent.ACTION_VIEW, upiUri)
        val chooser = Intent.createChooser(intent, "Pay via UPI App")
        context.startActivity(chooser)
    } catch (e: ActivityNotFoundException) {
        Toast.makeText(
            context,
            "No UPI app (Paytm, GPay, PhonePe) found on this device. Please scan the QR code using another phone.",
            Toast.LENGTH_LONG
        ).show()
    } catch (e: Exception) {
        Toast.makeText(context, "Could not open UPI: ${e.message}", Toast.LENGTH_SHORT).show()
    }
}
