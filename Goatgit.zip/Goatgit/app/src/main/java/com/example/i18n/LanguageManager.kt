package com.example.i18n

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateOf

class LanguageManager private constructor(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    private val _currentLanguage = mutableStateOf(
        AppLanguage.fromCode(
            prefs.getString(KEY_LANGUAGE, AppLanguage.ENGLISH.code) ?: AppLanguage.ENGLISH.code
        )
    )
    val currentLanguage: State<AppLanguage> = _currentLanguage

    fun getLanguage(): AppLanguage = _currentLanguage.value

    fun setLanguage(language: AppLanguage) {
        _currentLanguage.value = language
        prefs.edit().putString(KEY_LANGUAGE, language.code).apply()
    }

    companion object {
        private const val PREFS_NAME = "farm_app_language_prefs"
        private const val KEY_LANGUAGE = "selected_language"

        @Volatile
        private var INSTANCE: LanguageManager? = null

        fun getInstance(context: Context): LanguageManager {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: LanguageManager(context.applicationContext).also {
                    INSTANCE = it
                }
            }
        }
    }
}
