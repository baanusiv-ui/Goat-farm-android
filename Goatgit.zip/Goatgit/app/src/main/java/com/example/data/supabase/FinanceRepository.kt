package com.example.data.supabase

import com.example.data.offline.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.TimeUnit

class FinanceRepository(
    private val client: SupabaseClient,
    private val database: AppDatabase,
    private val syncManager: OfflineSyncManager
) {
    private val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.US)

    private fun JSONObject.optNullableString(key: String): String? =
        if (has(key) && !isNull(key) && optString(key).isNotBlank()) optString(key) else null

    // ==============================================================================
    // 1. FINANCIAL ACCOUNTS (Multi-Account Cash & Bank)
    // ==============================================================================
    suspend fun getAccounts(): Result<List<FinancialAccount>> = withContext(Dispatchers.IO) {
        try {
            var entities = database.financialAccountDao().getAllAccounts()
            if (entities.isEmpty()) {
                // Check remote
                val res = client.get("financial_accounts", "select=*&order=account_name.asc")
                if (res.isSuccess) {
                    val arr = res.getOrThrow()
                    val list = mutableListOf<FinancialAccountEntity>()
                    for (i in 0 until arr.length()) {
                        val o = arr.getJSONObject(i)
                        list.add(
                            FinancialAccountEntity(
                                id = o.optString("id", UUID.randomUUID().toString()),
                                account_name = o.optString("account_name", "Account"),
                                account_type = o.optString("account_type", "CASH"),
                                account_number = o.optNullableString("account_number"),
                                bank_name = o.optNullableString("bank_name"),
                                ifsc_code = o.optNullableString("ifsc_code"),
                                branch = o.optNullableString("branch"),
                                opening_balance = o.optDouble("opening_balance", 0.0),
                                current_balance = o.optDouble("current_balance", 0.0),
                                opening_date = o.optNullableString("opening_date"),
                                is_active = o.optBoolean("is_active", true),
                                created_at = o.optNullableString("created_at"),
                                updated_at = System.currentTimeMillis(),
                                is_synced = true
                            )
                        )
                    }
                    if (list.isNotEmpty()) {
                        database.financialAccountDao().insertAll(list)
                        entities = list
                    }
                }
            }

            // Seed default primary accounts if database is completely fresh
            if (entities.isEmpty()) {
                val todayStr = dateFormat.format(Date())
                val defaults = listOf(
                    FinancialAccountEntity(
                        id = UUID.randomUUID().toString(),
                        account_name = "Farm Cash in Hand",
                        account_type = "CASH",
                        opening_balance = 25000.0,
                        current_balance = 25000.0,
                        opening_date = todayStr,
                        is_active = true
                    ),
                    FinancialAccountEntity(
                        id = UUID.randomUUID().toString(),
                        account_name = "State Bank Current A/c",
                        account_type = "CURRENT_BANK",
                        account_number = "5401928374",
                        bank_name = "State Bank of India",
                        ifsc_code = "SBIN0001234",
                        branch = "Rural Agri Branch",
                        opening_balance = 150000.0,
                        current_balance = 150000.0,
                        opening_date = todayStr,
                        is_active = true
                    ),
                    FinancialAccountEntity(
                        id = UUID.randomUUID().toString(),
                        account_name = "Farm UPI / QR Wallet",
                        account_type = "UPI",
                        bank_name = "Paytm / NPCI UPI",
                        opening_balance = 10000.0,
                        current_balance = 10000.0,
                        opening_date = todayStr,
                        is_active = true
                    )
                )
                database.financialAccountDao().insertAll(defaults)
                entities = defaults
            }

            Result.success(entities.map { it.toDomain() })
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun addAccount(account: FinancialAccount): Result<FinancialAccount> = withContext(Dispatchers.IO) {
        try {
            val entity = account.toEntity(isSynced = false)
            database.financialAccountDao().insertOrUpdate(entity)
            enqueueAccount(entity)
            Result.success(account)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private suspend fun enqueueAccount(entity: FinancialAccountEntity) {
        val json = JSONObject().apply {
            put("id", entity.id)
            put("account_name", entity.account_name)
            put("account_type", entity.account_type)
            if (!entity.account_number.isNullOrBlank()) put("account_number", entity.account_number)
            if (!entity.upi_id.isNullOrBlank()) put("upi_id", entity.upi_id)
            if (!entity.bank_name.isNullOrBlank()) put("bank_name", entity.bank_name)
            if (!entity.ifsc_code.isNullOrBlank()) put("ifsc_code", entity.ifsc_code)
            if (!entity.branch.isNullOrBlank()) put("branch", entity.branch)
            put("opening_balance", entity.opening_balance)
            put("current_balance", entity.current_balance)
            if (!entity.opening_date.isNullOrBlank()) put("opening_date", entity.opening_date)
            put("is_active", entity.is_active)
        }
        syncManager.enqueueOperation("financial_accounts", entity.id, "CREATE", json)
    }

    // ==============================================================================
    // 2. ACCOUNT TRANSACTIONS & NON-P&L TRANSFERS
    // ==============================================================================
    suspend fun getTransactions(): Result<List<AccountTransaction>> = withContext(Dispatchers.IO) {
        try {
            val list = database.accountTransactionDao().getAllTransactions().map { it.toDomain() }
            Result.success(list)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * CRITICAL ACCOUNTING RULE:
     * Account-to-account transfer is NOT income and NOT expense.
     * Decreases fromAccount, increases toAccount.
     * Total liquid funds remain unchanged.
     * Guaranteed ZERO effect on Profit & Loss (affects_pnl = false, pillar = NON_CASH).
     */
    suspend fun recordTransfer(
        fromAccountId: String,
        toAccountId: String,
        amount: Double,
        date: String,
        description: String? = null,
        referenceId: String? = null
    ): Result<Boolean> = withContext(Dispatchers.IO) {
        try {
            if (fromAccountId == toAccountId) {
                return@withContext Result.failure(IllegalArgumentException("Source and destination accounts must be different"))
            }
            if (amount <= 0.0) {
                return@withContext Result.failure(IllegalArgumentException("Transfer amount must be greater than zero"))
            }

            val fromAcc = database.financialAccountDao().getAccountById(fromAccountId)
                ?: return@withContext Result.failure(IllegalArgumentException("Source account not found"))
            val toAcc = database.financialAccountDao().getAccountById(toAccountId)
                ?: return@withContext Result.failure(IllegalArgumentException("Destination account not found"))

            // Update balances
            val newFromBal = fromAcc.current_balance - amount
            val newToBal = toAcc.current_balance + amount
            database.financialAccountDao().updateBalance(fromAccountId, newFromBal)
            database.financialAccountDao().updateBalance(toAccountId, newToBal)

            // Record Transfer Transaction (affects_pnl = false, pillar = NON_CASH)
            val tx = AccountTransactionEntity(
                id = UUID.randomUUID().toString(),
                date = date,
                account_id = fromAccountId,
                to_account_id = toAccountId,
                transaction_type = "TRANSFER",
                amount = amount,
                category = "Internal Transfer",
                payment_mode = "Internal Transfer",
                reference_id = referenceId,
                affects_pnl = false, // CRITICAL: NEVER AFFECTS P&L
                pillar = "NON_CASH", // CRITICAL: ZERO EFFECT ON CASH FLOW PILLARS
                description = description ?: "Transfer from ${fromAcc.account_name} to ${toAcc.account_name}",
                created_at = date,
                updated_at = System.currentTimeMillis(),
                is_synced = false
            )
            database.accountTransactionDao().insert(tx)

            // Enqueue transfer to Supabase shared 'transactions' and 'account_transactions'
            val json = JSONObject().apply {
                put("id", tx.id)
                put("date", tx.date)
                put("account_id", tx.account_id)
                put("to_account_id", tx.to_account_id)
                put("transaction_type", tx.transaction_type)
                put("amount", tx.amount)
                put("category", tx.category)
                put("payment_mode", tx.payment_mode)
                if (!tx.reference_id.isNullOrBlank()) put("reference_id", tx.reference_id)
                put("affects_pnl", false)
                put("pillar", "NON_CASH")
                put("description", tx.description)
            }
            syncManager.enqueueOperation("transactions", tx.id, "CREATE", json)
            syncManager.enqueueOperation("account_transactions", tx.id, "CREATE", json)

            Result.success(true)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun recordIncome(
        accountId: String,
        amount: Double,
        category: String,
        date: String,
        paymentMode: String = "Cash",
        description: String? = null,
        referenceId: String? = null
    ): Result<AccountTransaction> = recordAccountTransaction(
        accountId = accountId,
        type = "INCOME",
        amount = amount,
        category = category,
        date = date,
        pillar = "OPERATING",
        description = description,
        referenceId = referenceId,
        paymentMode = paymentMode,
        affectsPnl = true
    )

    suspend fun recordExpense(
        accountId: String,
        amount: Double,
        category: String,
        date: String,
        paymentMode: String = "Cash",
        description: String? = null,
        referenceId: String? = null,
        isCapex: Boolean = false
    ): Result<AccountTransaction> = recordAccountTransaction(
        accountId = accountId,
        type = "EXPENSE",
        amount = amount,
        category = category,
        date = date,
        pillar = if (isCapex) "INVESTING" else "OPERATING",
        description = description,
        referenceId = referenceId,
        paymentMode = paymentMode,
        affectsPnl = true
    )

    suspend fun recordAccountTransaction(
        accountId: String,
        type: String, // INCOME, EXPENSE, DEPOSIT, WITHDRAWAL, OWNER_INVESTMENT, OWNER_WITHDRAWAL, LOAN_RECEIPT, LOAN_REPAYMENT, CUSTOMER_RECEIPT, SUPPLIER_PAYMENT
        amount: Double,
        category: String,
        date: String,
        pillar: String = "OPERATING", // OPERATING, INVESTING, FINANCING, NON_CASH
        description: String? = null,
        referenceId: String? = null,
        paymentMode: String = "Cash",
        affectsPnl: Boolean = when (type.uppercase()) {
            "TRANSFER", "DEPOSIT", "WITHDRAWAL", "LOAN_RECEIPT", "LOAN_REPAYMENT", "OWNER_INVESTMENT", "OWNER_WITHDRAWAL" -> false
            else -> true
        },
        relatedEntityType: String? = null,
        relatedEntityId: String? = null
    ): Result<AccountTransaction> = withContext(Dispatchers.IO) {
        try {
            val acc = database.financialAccountDao().getAccountById(accountId)
                ?: return@withContext Result.failure(IllegalArgumentException("Account not found"))

            // Adjust account balance based on transaction nature
            val isCredit = when (type) {
                "INCOME", "DEPOSIT", "OWNER_INVESTMENT", "LOAN_RECEIPT", "CUSTOMER_RECEIPT" -> true
                else -> false
            }
            val newBal = if (isCredit) acc.current_balance + amount else acc.current_balance - amount
            database.financialAccountDao().updateBalance(accountId, newBal)

            val txEntity = AccountTransactionEntity(
                id = UUID.randomUUID().toString(),
                date = date,
                account_id = accountId,
                transaction_type = type,
                amount = amount,
                category = category,
                payment_mode = paymentMode,
                reference_id = referenceId,
                affects_pnl = affectsPnl,
                pillar = pillar,
                description = description,
                related_entity_type = relatedEntityType,
                related_entity_id = relatedEntityId,
                created_at = date,
                updated_at = System.currentTimeMillis(),
                is_synced = false
            )
            database.accountTransactionDao().insert(txEntity)

            val json = JSONObject().apply {
                put("id", txEntity.id)
                put("date", txEntity.date)
                put("account_id", txEntity.account_id)
                put("transaction_type", txEntity.transaction_type)
                put("amount", txEntity.amount)
                put("category", txEntity.category)
                put("payment_mode", txEntity.payment_mode)
                put("pillar", txEntity.pillar)
                put("affects_pnl", txEntity.affects_pnl)
                if (!txEntity.reference_id.isNullOrBlank()) put("reference_id", txEntity.reference_id)
                if (!txEntity.description.isNullOrBlank()) put("description", txEntity.description)
                if (!txEntity.related_entity_type.isNullOrBlank()) put("related_entity_type", txEntity.related_entity_type)
                if (!txEntity.related_entity_id.isNullOrBlank()) put("related_entity_id", txEntity.related_entity_id)
            }
            syncManager.enqueueOperation("transactions", txEntity.id, "CREATE", json)
            syncManager.enqueueOperation("account_transactions", txEntity.id, "CREATE", json)

            Result.success(txEntity.toDomain())
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // ==============================================================================
    // 3. RECURRING EXPENSES
    // ==============================================================================
    suspend fun getRecurringExpenses(): Result<List<RecurringExpense>> = withContext(Dispatchers.IO) {
        try {
            var list = database.recurringExpenseDao().getAllRecurring().map { it.toDomain() }
            if (list.isEmpty()) {
                val res = client.get("recurring_expenses", "select=*&order=next_due_date.asc")
                if (res.isSuccess) {
                    val arr = res.getOrThrow()
                    val remote = mutableListOf<RecurringExpenseEntity>()
                    for (i in 0 until arr.length()) {
                        val o = arr.getJSONObject(i)
                        remote.add(
                            RecurringExpenseEntity(
                                id = o.optString("id", UUID.randomUUID().toString()),
                                expense_name = o.optString("expense_name", "Recurring Expense"),
                                category = o.optString("category", "General"),
                                vendor = o.optNullableString("vendor"),
                                amount = o.optDouble("amount", 0.0),
                                frequency = o.optString("frequency", "MONTHLY"),
                                start_date = o.optString("start_date", dateFormat.format(Date())),
                                end_date = o.optNullableString("end_date"),
                                next_due_date = o.optString("next_due_date", dateFormat.format(Date())),
                                payment_account_id = o.optNullableString("payment_account_id"),
                                payment_method = o.optString("payment_method", "BANK"),
                                gst_applicable = o.optBoolean("gst_applicable", false),
                                gst_rate = o.optDouble("gst_rate", 0.0),
                                notes = o.optNullableString("notes"),
                                is_active = o.optBoolean("is_active", true),
                                created_at = o.optNullableString("created_at"),
                                updated_at = System.currentTimeMillis(),
                                is_synced = true
                            )
                        )
                    }
                    if (remote.isNotEmpty()) {
                        database.recurringExpenseDao().insertAll(remote)
                        list = remote.map { it.toDomain() }
                    }
                }
            }
            Result.success(list)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun addRecurringExpense(expense: RecurringExpense): Result<RecurringExpense> = withContext(Dispatchers.IO) {
        try {
            val entity = expense.toEntity(isSynced = false)
            database.recurringExpenseDao().insertOrUpdate(entity)

            val json = JSONObject().apply {
                put("id", entity.id)
                put("expense_name", entity.expense_name)
                put("category", entity.category)
                if (!entity.vendor.isNullOrBlank()) put("vendor", entity.vendor)
                put("amount", entity.amount)
                put("frequency", entity.frequency)
                put("start_date", entity.start_date)
                if (!entity.end_date.isNullOrBlank()) put("end_date", entity.end_date)
                put("next_due_date", entity.next_due_date)
                if (!entity.payment_account_id.isNullOrBlank()) put("payment_account_id", entity.payment_account_id)
                put("payment_method", entity.payment_method)
                put("gst_applicable", entity.gst_applicable)
                put("gst_rate", entity.gst_rate)
                if (!entity.notes.isNullOrBlank()) put("notes", entity.notes)
                put("is_active", entity.is_active)
            }
            syncManager.enqueueOperation("recurring_expenses", entity.id, "CREATE", json)

            Result.success(expense)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun payRecurringExpense(
        recurringId: String,
        accountId: String,
        paymentDate: String,
        notes: String? = null
    ): Result<Boolean> = withContext(Dispatchers.IO) {
        try {
            val item = database.recurringExpenseDao().getById(recurringId)
                ?: return@withContext Result.failure(IllegalArgumentException("Recurring expense not found"))

            // 1. Post actual operating expense to selected cash/bank account
            recordAccountTransaction(
                accountId = accountId,
                type = "EXPENSE",
                amount = item.amount,
                category = item.category,
                date = paymentDate,
                pillar = "OPERATING",
                description = "Recurring payment: ${item.expense_name} (${notes ?: ""})".trim(),
                relatedEntityType = "RECURRING",
                relatedEntityId = recurringId
            )

            // 2. Advance next due date according to frequency
            val nextDate = advanceDueDate(item.next_due_date, item.frequency)
            val updated = item.copy(
                next_due_date = nextDate,
                updated_at = System.currentTimeMillis()
            )
            database.recurringExpenseDao().insertOrUpdate(updated)

            val json = JSONObject().apply {
                put("next_due_date", nextDate)
            }
            syncManager.enqueueOperation("recurring_expenses", recurringId, "UPDATE", json)

            Result.success(true)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun advanceDueDate(currentDue: String, frequency: String): String {
        return try {
            val cal = Calendar.getInstance()
            val d = dateFormat.parse(currentDue) ?: Date()
            cal.time = d
            when (frequency.uppercase()) {
                "DAILY" -> cal.add(Calendar.DAY_OF_YEAR, 1)
                "WEEKLY" -> cal.add(Calendar.WEEK_OF_YEAR, 1)
                "MONTHLY" -> cal.add(Calendar.MONTH, 1)
                "QUARTERLY" -> cal.add(Calendar.MONTH, 3)
                "HALF_YEARLY" -> cal.add(Calendar.MONTH, 6)
                "YEARLY" -> cal.add(Calendar.YEAR, 1)
                else -> cal.add(Calendar.MONTH, 1)
            }
            dateFormat.format(cal.time)
        } catch (_: Exception) {
            currentDue
        }
    }

    // ==============================================================================
    // 4. ELECTRICITY / EB
    // ==============================================================================
    suspend fun getElectricityConnections(): Result<List<ElectricityConnection>> = withContext(Dispatchers.IO) {
        try {
            var list = database.electricityDao().getAllConnections().map { it.toDomain() }
            if (list.isEmpty()) {
                // Seed default EB connection if none exists
                val defaultConn = ElectricityConnectionEntity(
                    id = UUID.randomUUID().toString(),
                    connection_name = "Farm Main Meter (Barn & Sheds)",
                    consumer_number = "04-201-008-912",
                    meter_number = "EB-MTR-8841",
                    service_provider = "TANGEDCO (State EB)",
                    tariff_category = "Tariff III-A (Agri / Allied)",
                    location = "Main Goat Shed",
                    billing_cycle = "Monthly",
                    is_active = true
                )
                database.electricityDao().insertConnection(defaultConn)
                list = listOf(defaultConn.toDomain())
            }
            Result.success(list)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun addElectricityConnection(conn: ElectricityConnection): Result<ElectricityConnection> = withContext(Dispatchers.IO) {
        try {
            val entity = conn.toEntity(isSynced = false)
            database.electricityDao().insertConnection(entity)

            val json = JSONObject().apply {
                put("id", entity.id)
                put("connection_name", entity.connection_name)
                put("consumer_number", entity.consumer_number)
                put("meter_number", entity.meter_number)
                put("service_provider", entity.service_provider)
                put("tariff_category", entity.tariff_category)
                put("location", entity.location)
                put("billing_cycle", entity.billing_cycle)
                put("is_active", entity.is_active)
            }
            syncManager.enqueueOperation("electricity_connections", entity.id, "CREATE", json)

            Result.success(conn)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getElectricityBills(): Result<List<ElectricityBill>> = withContext(Dispatchers.IO) {
        try {
            val list = database.electricityDao().getAllBills().map { it.toDomain() }
            Result.success(list)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun recordElectricityBill(bill: ElectricityBill): Result<ElectricityBill> = withContext(Dispatchers.IO) {
        try {
            val entity = bill.toEntity(isSynced = false)
            database.electricityDao().insertBill(entity)

            val json = JSONObject().apply {
                put("id", entity.id)
                put("connection_id", entity.connection_id)
                put("billing_period", entity.billing_period)
                put("bill_date", entity.bill_date)
                put("due_date", entity.due_date)
                put("previous_reading", entity.previous_reading)
                put("current_reading", entity.current_reading)
                put("base_amount", entity.base_amount)
                put("other_charges", entity.other_charges)
                put("tax_amount", entity.tax_amount)
                put("total_bill", entity.total_bill)
                put("paid_amount", entity.paid_amount)
                put("balance_amount", entity.balance_amount)
                put("payment_status", entity.payment_status)
                if (!entity.notes.isNullOrBlank()) put("notes", entity.notes)
            }
            syncManager.enqueueOperation("electricity_bills", entity.id, "CREATE", json)

            Result.success(bill)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun payElectricityBill(
        billId: String,
        accountId: String,
        paidAmount: Double,
        paymentDate: String
    ): Result<Boolean> = withContext(Dispatchers.IO) {
        try {
            val bill = database.electricityDao().getBillById(billId)
                ?: return@withContext Result.failure(IllegalArgumentException("Bill not found"))

            val newPaid = bill.paid_amount + paidAmount
            val newBalance = (bill.total_bill - newPaid).coerceAtLeast(0.0)
            val newStatus = if (newBalance <= 0.0) "PAID" else "PARTIALLY_PAID"

            // 1. Post expense to account
            recordAccountTransaction(
                accountId = accountId,
                type = "EXPENSE",
                amount = paidAmount,
                category = "Electricity / EB",
                date = paymentDate,
                pillar = "OPERATING",
                description = "EB Bill payment (${bill.billing_period}) - Units: ${bill.units_consumed}",
                relatedEntityType = "EB",
                relatedEntityId = billId
            )

            // 2. Update Bill in DB
            val updatedBill = bill.copy(
                paid_amount = newPaid,
                balance_amount = newBalance,
                payment_date = paymentDate,
                payment_account_id = accountId,
                payment_status = newStatus,
                updated_at = System.currentTimeMillis()
            )
            database.electricityDao().insertBill(updatedBill)

            val json = JSONObject().apply {
                put("paid_amount", newPaid)
                put("balance_amount", newBalance)
                put("payment_date", paymentDate)
                put("payment_account_id", accountId)
                put("payment_status", newStatus)
            }
            syncManager.enqueueOperation("electricity_bills", billId, "UPDATE", json)

            Result.success(true)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // ==============================================================================
    // 5. LOANS & BORROWINGS
    // ==============================================================================
    suspend fun getLoans(): Result<List<Loan>> = withContext(Dispatchers.IO) {
        try {
            val list = database.loanDao().getAllLoans().map { it.toDomain() }
            Result.success(list)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getLoanSchedules(loanId: String): Result<List<LoanSchedule>> = withContext(Dispatchers.IO) {
        try {
            val list = database.loanDao().getSchedulesForLoan(loanId).map { it.toDomain() }
            Result.success(list)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun addLoan(loan: Loan): Result<Loan> = withContext(Dispatchers.IO) {
        try {
            val loanEntity = loan.toEntity(isSynced = false)
            database.loanDao().insertLoan(loanEntity)

            // If a disbursement account was chosen:
            // CRITICAL: Loan receipt = FINANCING INFLOW, NOT income!
            if (!loan.disbursement_account_id.isNullOrBlank()) {
                recordAccountTransaction(
                    accountId = loan.disbursement_account_id,
                    type = "LOAN_RECEIPT",
                    amount = loan.disbursed_amount,
                    category = "Loan Disbursement",
                    date = loan.start_date,
                    pillar = "FINANCING",
                    description = "Loan sanctioned & disbursed: ${loan.loan_name} (${loan.lender})",
                    relatedEntityType = "LOAN",
                    relatedEntityId = loan.id
                )
            }

            // Generate Amortization Schedule
            val schedules = generateAmortizationSchedule(loan)
            database.loanDao().insertAllSchedules(schedules.map { it.toEntity() })

            // Enqueue loan to Supabase
            val json = JSONObject().apply {
                put("id", loanEntity.id)
                put("lender", loanEntity.lender)
                put("loan_name", loanEntity.loan_name)
                put("loan_account_number", loanEntity.loan_account_number)
                put("loan_type", loanEntity.loan_type)
                put("sanctioned_amount", loanEntity.sanctioned_amount)
                put("disbursed_amount", loanEntity.disbursed_amount)
                put("interest_rate", loanEntity.interest_rate)
                put("interest_type", loanEntity.interest_type)
                put("tenure_months", loanEntity.tenure_months)
                put("emi_amount", loanEntity.emi_amount)
                put("start_date", loanEntity.start_date)
                put("first_emi_date", loanEntity.first_emi_date)
                put("maturity_date", loanEntity.maturity_date)
                put("processing_fee", loanEntity.processing_fee)
                put("outstanding_principal", loanEntity.outstanding_principal)
                put("status", loanEntity.status)
            }
            syncManager.enqueueOperation("loans", loanEntity.id, "CREATE", json)

            Result.success(loan)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun generateAmortizationSchedule(loan: Loan): List<LoanSchedule> {
        val list = mutableListOf<LoanSchedule>()
        var remainingPrincipal = loan.disbursed_amount
        val monthlyRate = (loan.interest_rate / 12.0) / 100.0
        val cal = Calendar.getInstance()
        try {
            val d = dateFormat.parse(loan.first_emi_date) ?: Date()
            cal.time = d
        } catch (_: Exception) {}

        for (i in 1..loan.tenure_months) {
            val dueDateStr = dateFormat.format(cal.time)
            val interestPart = remainingPrincipal * monthlyRate
            val principalPart = (loan.emi_amount - interestPart).coerceAtLeast(0.0).coerceAtMost(remainingPrincipal)
            val closingPrincipal = (remainingPrincipal - principalPart).coerceAtLeast(0.0)

            list.add(
                LoanSchedule(
                    id = UUID.randomUUID().toString(),
                    loan_id = loan.id,
                    emi_number = i,
                    due_date = dueDateStr,
                    opening_principal = remainingPrincipal,
                    principal_component = principalPart,
                    interest_component = interestPart,
                    emi_amount = loan.emi_amount,
                    closing_principal = closingPrincipal,
                    status = "PENDING"
                )
            )

            remainingPrincipal = closingPrincipal
            cal.add(Calendar.MONTH, 1)
        }
        return list
    }

    /**
     * CRITICAL ACCOUNTING RULE:
     * When an EMI is paid:
     * - Principal portion -> FINANCING outflow (NOT operating expense!)
     * - Interest portion -> OPERATING / FINANCE expense (deducted in P&L)
     * - Total payment -> Deducted from selected cash/bank account.
     * No double-counting!
     */
    suspend fun payLoanEmi(
        scheduleId: String,
        accountId: String,
        paymentDate: String
    ): Result<Boolean> = withContext(Dispatchers.IO) {
        try {
            val sched = database.loanDao().getScheduleById(scheduleId)
                ?: return@withContext Result.failure(IllegalArgumentException("Schedule item not found"))
            val loan = database.loanDao().getLoanById(sched.loan_id)
                ?: return@withContext Result.failure(IllegalArgumentException("Loan not found"))

            // 1. Post Principal Repayment (FINANCING OUTFLOW)
            if (sched.principal_component > 0) {
                recordAccountTransaction(
                    accountId = accountId,
                    type = "LOAN_REPAYMENT",
                    amount = sched.principal_component,
                    category = "Loan Principal Repayment",
                    date = paymentDate,
                    pillar = "FINANCING",
                    description = "EMI #${sched.emi_number} Principal Repayment for ${loan.loan_name}",
                    relatedEntityType = "LOAN",
                    relatedEntityId = loan.id
                )
            }

            // 2. Post Interest Component (OPERATING FINANCE EXPENSE)
            if (sched.interest_component > 0) {
                recordAccountTransaction(
                    accountId = accountId,
                    type = "EXPENSE",
                    amount = sched.interest_component,
                    category = "Loan Interest Expense",
                    date = paymentDate,
                    pillar = "OPERATING",
                    description = "EMI #${sched.emi_number} Interest for ${loan.loan_name}",
                    relatedEntityType = "LOAN",
                    relatedEntityId = loan.id
                )
            }

            // 3. Update Schedule Status
            val updatedSched = sched.copy(
                status = "PAID",
                paid_date = paymentDate,
                paid_amount = sched.emi_amount,
                payment_account_id = accountId,
                updated_at = System.currentTimeMillis()
            )
            database.loanDao().insertSchedule(updatedSched)

            // 4. Update Loan balances
            val newOutstanding = (loan.outstanding_principal - sched.principal_component).coerceAtLeast(0.0)
            val newPrincPaid = loan.total_principal_paid + sched.principal_component
            val newIntPaid = loan.total_interest_paid + sched.interest_component
            val newStatus = if (newOutstanding <= 0.0) "CLOSED" else loan.status

            val updatedLoan = loan.copy(
                outstanding_principal = newOutstanding,
                total_principal_paid = newPrincPaid,
                total_interest_paid = newIntPaid,
                status = newStatus,
                updated_at = System.currentTimeMillis()
            )
            database.loanDao().insertLoan(updatedLoan)

            // Enqueue schedule update
            val json = JSONObject().apply {
                put("status", "PAID")
                put("paid_date", paymentDate)
                put("paid_amount", sched.emi_amount)
                put("payment_account_id", accountId)
            }
            syncManager.enqueueOperation("loan_schedules", sched.id, "UPDATE", json)

            Result.success(true)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // ==============================================================================
    // 6. CREDITORS / SUPPLIERS
    // ==============================================================================
    suspend fun getSuppliers(): Result<List<Supplier>> = withContext(Dispatchers.IO) {
        try {
            val list = database.supplierDao().getAllSuppliers().map { it.toDomain() }
            Result.success(list)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun addSupplier(supplier: Supplier): Result<Supplier> = withContext(Dispatchers.IO) {
        try {
            val entity = supplier.toEntity(isSynced = false)
            database.supplierDao().insertSupplier(entity)

            val json = JSONObject().apply {
                put("id", entity.id)
                put("name", entity.name)
                if (!entity.phone.isNullOrBlank()) put("phone", entity.phone)
                if (!entity.address.isNullOrBlank()) put("address", entity.address)
                if (!entity.gstin.isNullOrBlank()) put("gstin", entity.gstin)
                put("credit_limit", entity.credit_limit)
                put("credit_period_days", entity.credit_period_days)
                put("opening_balance", entity.opening_balance)
                put("current_outstanding", entity.current_outstanding)
                put("is_active", entity.is_active)
            }
            syncManager.enqueueOperation("suppliers", entity.id, "CREATE", json)

            Result.success(supplier)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getSupplierInvoices(): Result<List<SupplierInvoice>> = withContext(Dispatchers.IO) {
        try {
            val list = database.supplierDao().getAllInvoices().map { it.toDomain() }
            Result.success(list)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun createSupplierInvoice(invoice: SupplierInvoice): Result<SupplierInvoice> = withContext(Dispatchers.IO) {
        try {
            val entity = invoice.toEntity(isSynced = false)
            database.supplierDao().insertInvoice(entity)

            // Update Supplier current outstanding
            val supplier = database.supplierDao().getSupplierById(invoice.supplier_id)
            if (supplier != null) {
                val newOutstanding = supplier.current_outstanding + invoice.total_amount
                database.supplierDao().updateOutstanding(supplier.id, newOutstanding)
            }

            val json = JSONObject().apply {
                put("id", entity.id)
                put("supplier_id", entity.supplier_id)
                put("invoice_number", entity.invoice_number)
                put("invoice_date", entity.invoice_date)
                put("due_date", entity.due_date)
                put("items_description", entity.items_description)
                put("quantity", entity.quantity)
                put("rate", entity.rate)
                put("taxable_value", entity.taxable_value)
                put("gst_rate", entity.gst_rate)
                put("gst_amount", entity.gst_amount)
                put("total_amount", entity.total_amount)
                put("paid_amount", entity.paid_amount)
                put("balance_due", entity.balance_due)
                put("status", entity.status)
                if (!entity.notes.isNullOrBlank()) put("notes", entity.notes)
            }
            syncManager.enqueueOperation("supplier_invoices", entity.id, "CREATE", json)

            Result.success(invoice)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Supplier payment reduces:
     * - Cash/bank balance
     * - Supplier outstanding
     * Does NOT create duplicate expense if original invoice purchase was already tracked!
     */
    suspend fun paySupplierInvoice(
        invoiceId: String,
        supplierId: String,
        accountId: String,
        amount: Double,
        paymentDate: String,
        paymentMode: String = "BANK",
        referenceNumber: String? = null
    ): Result<Boolean> = withContext(Dispatchers.IO) {
        try {
            val invoice = database.supplierDao().getInvoiceById(invoiceId)
                ?: return@withContext Result.failure(IllegalArgumentException("Invoice not found"))
            val supplier = database.supplierDao().getSupplierById(supplierId)
                ?: return@withContext Result.failure(IllegalArgumentException("Supplier not found"))

            val newPaid = invoice.paid_amount + amount
            val newBalance = (invoice.total_amount - newPaid).coerceAtLeast(0.0)
            val newStatus = if (newBalance <= 0.0) "PAID" else "PARTIALLY_PAID"

            // 1. Post Supplier Payment Transaction
            recordAccountTransaction(
                accountId = accountId,
                type = "SUPPLIER_PAYMENT",
                amount = amount,
                category = "Supplier Settlement",
                date = paymentDate,
                pillar = "OPERATING",
                description = "Supplier Payment to ${supplier.name} for Inv #${invoice.invoice_number}",
                relatedEntityType = "SUPPLIER",
                relatedEntityId = supplierId
            )

            // 2. Insert Payment record
            val paymentEntity = SupplierPaymentEntity(
                id = UUID.randomUUID().toString(),
                invoice_id = invoiceId,
                supplier_id = supplierId,
                payment_date = paymentDate,
                amount = amount,
                payment_account_id = accountId,
                payment_mode = paymentMode,
                reference_number = referenceNumber,
                is_synced = false
            )
            database.supplierDao().insertPayment(paymentEntity)

            // 3. Update Invoice balance
            val updatedInv = invoice.copy(
                paid_amount = newPaid,
                balance_due = newBalance,
                status = newStatus,
                updated_at = System.currentTimeMillis()
            )
            database.supplierDao().insertInvoice(updatedInv)

            // 4. Update Supplier outstanding
            val newOutstanding = (supplier.current_outstanding - amount).coerceAtLeast(0.0)
            database.supplierDao().updateOutstanding(supplierId, newOutstanding)

            // Enqueue to Supabase
            val json = JSONObject().apply {
                put("paid_amount", newPaid)
                put("balance_due", newBalance)
                put("status", newStatus)
            }
            syncManager.enqueueOperation("supplier_invoices", invoiceId, "UPDATE", json)

            Result.success(true)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // ==============================================================================
    // 7. GST CONFIGURATION
    // ==============================================================================
    suspend fun getGstSettings(): Result<GstSettings> = withContext(Dispatchers.IO) {
        try {
            val entity = database.gstDao().getSettings() ?: GstSettingsEntity()
            Result.success(entity.toDomain())
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun saveGstSettings(settings: GstSettings): Result<GstSettings> = withContext(Dispatchers.IO) {
        try {
            database.gstDao().saveSettings(settings.toEntity())
            Result.success(settings)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Deterministic GST Tax Calculation
     * Intra-state: CGST (rate/2) + SGST (rate/2)
     * Inter-state: IGST (rate)
     * Never applies both to the same item!
     */
    fun calculateGstBreakdown(taxableValue: Double, gstRate: Double, isInterState: Boolean): GstTaxBreakdown {
        return GstTaxBreakdown(
            taxableValue = taxableValue,
            gstRate = gstRate,
            isInterState = isInterState
        )
    }

    // ==============================================================================
    // 8. E-WAY BILL
    // ==============================================================================
    suspend fun getEWayBills(): Result<List<EWayBill>> = withContext(Dispatchers.IO) {
        try {
            val list = database.ewayBillDao().getAllEWayBills().map { it.toDomain() }
            Result.success(list)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun createEWayBill(bill: EWayBill): Result<EWayBill> = withContext(Dispatchers.IO) {
        try {
            // Check if authorised government API is configured.
            // As per user instructions: DO NOT fake government integration.
            // Show "Government E-Way Bill API is not configured." and keep status as "Ready" or "Draft".
            val finalBill = bill.copy(
                eway_bill_number = null,
                status = "Ready",
                error_message = "Government E-Way Bill API is not configured."
            )
            val entity = finalBill.toEntity(isSynced = false)
            database.ewayBillDao().insert(entity)

            val json = JSONObject().apply {
                put("id", entity.id)
                put("invoice_id", entity.invoice_id)
                put("invoice_number", entity.invoice_number)
                put("supplier_gstin", entity.supplier_gstin)
                if (!entity.recipient_gstin.isNullOrBlank()) put("recipient_gstin", entity.recipient_gstin)
                put("place_of_supply", entity.place_of_supply)
                put("delivery_address", entity.delivery_address)
                put("hsn_code", entity.hsn_code)
                put("quantity", entity.quantity)
                put("taxable_value", entity.taxable_value)
                put("gst_amount", entity.gst_amount)
                put("total_value", entity.total_value)
                if (!entity.transporter_id.isNullOrBlank()) put("transporter_id", entity.transporter_id)
                if (!entity.transporter_name.isNullOrBlank()) put("transporter_name", entity.transporter_name)
                put("vehicle_number", entity.vehicle_number)
                put("transport_mode", entity.transport_mode)
                if (!entity.transport_doc_number.isNullOrBlank()) put("transport_doc_number", entity.transport_doc_number)
                put("document_date", entity.document_date)
                put("status", entity.status)
                put("error_message", entity.error_message)
            }
            syncManager.enqueueOperation("eway_bills", entity.id, "CREATE", json)

            Result.success(finalBill)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // ==============================================================================
    // 9. THREE-PILLAR CASH FLOW CALCULATION
    // ==============================================================================
    suspend fun getThreePillarCashFlow(): Result<ThreePillarCashFlowSummary> = withContext(Dispatchers.IO) {
        try {
            val accounts = database.financialAccountDao().getAllAccounts()
            val transactions = database.accountTransactionDao().getAllTransactions()

            val openingTotal = accounts.sumOf { it.opening_balance }
            val currentTotal = accounts.sumOf { it.current_balance }

            var opInflow = 0.0
            var opOutflow = 0.0
            var invInflow = 0.0
            var invOutflow = 0.0
            var finInflow = 0.0
            var finOutflow = 0.0

            for (tx in transactions) {
                val isCredit = when (tx.transaction_type) {
                    "INCOME", "DEPOSIT", "CUSTOMER_RECEIPT", "LOAN_RECEIPT", "OWNER_INVESTMENT" -> true
                    else -> false
                }
                val amount = tx.amount

                when (tx.pillar.uppercase()) {
                    "OPERATING" -> {
                        if (isCredit) opInflow += amount else opOutflow += amount
                    }
                    "INVESTING" -> {
                        if (isCredit) invInflow += amount else invOutflow += amount
                    }
                    "FINANCING" -> {
                        if (isCredit) finInflow += amount else finOutflow += amount
                    }
                    else -> {
                        // NON_CASH / CONTRA / INTERNAL TRANSFER - does not affect cash pillars
                    }
                }
            }

            val summary = ThreePillarCashFlowSummary(
                openingCashAndBank = openingTotal,
                operatingInflow = opInflow,
                operatingOutflow = opOutflow,
                investingInflow = invInflow,
                investingOutflow = invOutflow,
                financingInflow = finInflow,
                financingOutflow = finOutflow,
                totalLiquidFundsInAccounts = currentTotal
            )
            Result.success(summary)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // ==============================================================================
    // 10. UNIFIED PAYMENTS DUE (EB, Supplier, Loan EMI, Recurring)
    // ==============================================================================
    suspend fun getUnifiedPaymentsDue(): Result<List<UnifiedPaymentsDueItem>> = withContext(Dispatchers.IO) {
        try {
            val list = mutableListOf<UnifiedPaymentsDueItem>()
            val today = dateFormat.format(Date())

            // 1. EB Bills due
            val ebBills = database.electricityDao().getAllBills().filter { it.payment_status != "PAID" }
            for (b in ebBills) {
                val daysDiff = calculateDaysDifference(today, b.due_date)
                list.add(
                    UnifiedPaymentsDueItem(
                        id = b.id,
                        type = "EB",
                        title = "EB Bill: ${b.billing_period}",
                        subtitle = "Units: ${b.units_consumed} kWh",
                        dueDate = b.due_date,
                        amount = b.balance_amount,
                        isOverdue = b.due_date < today,
                        daysRemaining = daysDiff,
                        referenceId = b.id
                    )
                )
            }

            // 2. Supplier Invoices due
            val invoices = database.supplierDao().getAllInvoices().filter { it.status != "PAID" }
            val suppliersMap = database.supplierDao().getAllSuppliers().associateBy { it.id }
            for (inv in invoices) {
                val sName = suppliersMap[inv.supplier_id]?.name ?: "Supplier"
                val daysDiff = calculateDaysDifference(today, inv.due_date)
                list.add(
                    UnifiedPaymentsDueItem(
                        id = inv.id,
                        type = "SUPPLIER",
                        title = "Supplier Payable: $sName",
                        subtitle = "Inv #${inv.invoice_number} • ${inv.items_description}",
                        dueDate = inv.due_date,
                        amount = inv.balance_due,
                        isOverdue = inv.due_date < today,
                        daysRemaining = daysDiff,
                        referenceId = inv.id
                    )
                )
            }

            // 3. Loan EMIs due
            val emiSchedules = database.loanDao().getUpcomingEmiSchedules()
            val loansMap = database.loanDao().getAllLoans().associateBy { it.id }
            for (s in emiSchedules) {
                val lName = loansMap[s.loan_id]?.loan_name ?: "Loan"
                val daysDiff = calculateDaysDifference(today, s.due_date)
                list.add(
                    UnifiedPaymentsDueItem(
                        id = s.id,
                        type = "LOAN_EMI",
                        title = "EMI #${s.emi_number}: $lName",
                        subtitle = "Principal: ₹${s.principal_component.toInt()} | Interest: ₹${s.interest_component.toInt()}",
                        dueDate = s.due_date,
                        amount = s.emi_amount,
                        isOverdue = s.due_date < today,
                        daysRemaining = daysDiff,
                        referenceId = s.id
                    )
                )
            }

            // 4. Recurring Expenses due
            val recurring = database.recurringExpenseDao().getAllRecurring().filter { it.is_active }
            for (r in recurring) {
                val daysDiff = calculateDaysDifference(today, r.next_due_date)
                list.add(
                    UnifiedPaymentsDueItem(
                        id = r.id,
                        type = "RECURRING",
                        title = "Recurring: ${r.expense_name}",
                        subtitle = "Category: ${r.category} (${r.frequency})",
                        dueDate = r.next_due_date,
                        amount = r.amount,
                        isOverdue = r.next_due_date < today,
                        daysRemaining = daysDiff,
                        referenceId = r.id
                    )
                )
            }

            Result.success(list.sortedBy { it.dueDate })
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun calculateDaysDifference(fromDate: String, toDate: String): Int {
        return try {
            val d1 = dateFormat.parse(fromDate) ?: Date()
            val d2 = dateFormat.parse(toDate) ?: Date()
            val diffMs = d2.time - d1.time
            TimeUnit.MILLISECONDS.toDays(diffMs).toInt()
        } catch (_: Exception) {
            0
        }
    }
}

// ==============================================================================
// MAPPERS: Domain <-> Entity
// ==============================================================================
fun FinancialAccount.toEntity(isSynced: Boolean = false) = FinancialAccountEntity(
    id = id,
    account_name = account_name,
    account_type = account_type,
    account_number = account_number,
    upi_id = upi_id,
    bank_name = bank_name,
    ifsc_code = ifsc_code,
    branch = branch,
    opening_balance = opening_balance,
    current_balance = current_balance,
    opening_date = opening_date,
    is_active = is_active,
    created_at = created_at,
    is_synced = isSynced
)

fun FinancialAccountEntity.toDomain() = FinancialAccount(
    id = id,
    account_name = account_name,
    account_type = account_type,
    account_number = account_number,
    upi_id = upi_id,
    bank_name = bank_name,
    ifsc_code = ifsc_code,
    branch = branch,
    opening_balance = opening_balance,
    current_balance = current_balance,
    opening_date = opening_date,
    is_active = is_active,
    created_at = created_at
)

fun AccountTransactionEntity.toDomain() = AccountTransaction(
    id = id,
    date = date,
    account_id = account_id,
    transaction_type = transaction_type,
    amount = amount,
    category = category,
    payment_mode = payment_mode,
    reference_id = reference_id,
    to_account_id = to_account_id,
    affects_pnl = affects_pnl,
    pillar = pillar,
    description = description,
    related_entity_type = related_entity_type,
    related_entity_id = related_entity_id,
    created_by = created_by,
    created_at = created_at
)

fun AccountTransaction.toEntity(isSynced: Boolean = false) = AccountTransactionEntity(
    id = id,
    date = date,
    account_id = account_id,
    transaction_type = transaction_type,
    amount = amount,
    category = category,
    payment_mode = payment_mode,
    reference_id = reference_id,
    to_account_id = to_account_id,
    affects_pnl = affects_pnl,
    pillar = pillar,
    description = description,
    related_entity_type = related_entity_type,
    related_entity_id = related_entity_id,
    created_by = created_by,
    created_at = created_at,
    is_synced = isSynced
)

fun RecurringExpense.toEntity(isSynced: Boolean = false) = RecurringExpenseEntity(
    id = id,
    expense_name = expense_name,
    category = category,
    vendor = vendor,
    amount = amount,
    frequency = frequency,
    start_date = start_date,
    end_date = end_date,
    next_due_date = next_due_date,
    payment_account_id = payment_account_id,
    payment_method = payment_method,
    gst_applicable = gst_applicable,
    gst_rate = gst_rate,
    notes = notes,
    is_active = is_active,
    created_at = created_at,
    is_synced = isSynced
)

fun RecurringExpenseEntity.toDomain() = RecurringExpense(
    id = id,
    expense_name = expense_name,
    category = category,
    vendor = vendor,
    amount = amount,
    frequency = frequency,
    start_date = start_date,
    end_date = end_date,
    next_due_date = next_due_date,
    payment_account_id = payment_account_id,
    payment_method = payment_method,
    gst_applicable = gst_applicable,
    gst_rate = gst_rate,
    notes = notes,
    is_active = is_active,
    created_at = created_at
)

fun ElectricityConnection.toEntity(isSynced: Boolean = false) = ElectricityConnectionEntity(
    id = id,
    connection_name = connection_name,
    consumer_number = consumer_number,
    meter_number = meter_number,
    service_provider = service_provider,
    tariff_category = tariff_category,
    location = location,
    billing_cycle = billing_cycle,
    is_active = is_active,
    created_at = created_at,
    is_synced = isSynced
)

fun ElectricityConnectionEntity.toDomain() = ElectricityConnection(
    id = id,
    connection_name = connection_name,
    consumer_number = consumer_number,
    meter_number = meter_number,
    service_provider = service_provider,
    tariff_category = tariff_category,
    location = location,
    billing_cycle = billing_cycle,
    is_active = is_active,
    created_at = created_at
)

fun ElectricityBill.toEntity(isSynced: Boolean = false) = ElectricityBillEntity(
    id = id,
    connection_id = connection_id,
    billing_period = billing_period,
    bill_date = bill_date,
    due_date = due_date,
    previous_reading = previous_reading,
    current_reading = current_reading,
    units_consumed = units_consumed,
    base_amount = base_amount,
    other_charges = other_charges,
    tax_amount = tax_amount,
    total_bill = total_bill,
    paid_amount = paid_amount,
    balance_amount = balance_amount,
    payment_date = payment_date,
    payment_account_id = payment_account_id,
    payment_status = payment_status,
    notes = notes,
    created_at = created_at,
    is_synced = isSynced
)

fun ElectricityBillEntity.toDomain() = ElectricityBill(
    id = id,
    connection_id = connection_id,
    billing_period = billing_period,
    bill_date = bill_date,
    due_date = due_date,
    previous_reading = previous_reading,
    current_reading = current_reading,
    units_consumed = units_consumed,
    base_amount = base_amount,
    other_charges = other_charges,
    tax_amount = tax_amount,
    total_bill = total_bill,
    paid_amount = paid_amount,
    balance_amount = balance_amount,
    payment_date = payment_date,
    payment_account_id = payment_account_id,
    payment_status = payment_status,
    notes = notes,
    created_at = created_at
)

fun Loan.toEntity(isSynced: Boolean = false) = LoanEntity(
    id = id,
    lender = lender,
    loan_name = loan_name,
    loan_account_number = loan_account_number,
    loan_type = loan_type,
    sanctioned_amount = sanctioned_amount,
    disbursed_amount = disbursed_amount,
    interest_rate = interest_rate,
    interest_type = interest_type,
    tenure_months = tenure_months,
    emi_amount = emi_amount,
    start_date = start_date,
    first_emi_date = first_emi_date,
    maturity_date = maturity_date,
    processing_fee = processing_fee,
    outstanding_principal = outstanding_principal,
    total_interest_paid = total_interest_paid,
    total_principal_paid = total_principal_paid,
    disbursement_account_id = disbursement_account_id,
    status = status,
    notes = notes,
    created_at = created_at,
    is_synced = isSynced
)

fun LoanEntity.toDomain() = Loan(
    id = id,
    lender = lender,
    loan_name = loan_name,
    loan_account_number = loan_account_number,
    loan_type = loan_type,
    sanctioned_amount = sanctioned_amount,
    disbursed_amount = disbursed_amount,
    interest_rate = interest_rate,
    interest_type = interest_type,
    tenure_months = tenure_months,
    emi_amount = emi_amount,
    start_date = start_date,
    first_emi_date = first_emi_date,
    maturity_date = maturity_date,
    processing_fee = processing_fee,
    outstanding_principal = outstanding_principal,
    total_interest_paid = total_interest_paid,
    total_principal_paid = total_principal_paid,
    disbursement_account_id = disbursement_account_id,
    status = status,
    notes = notes,
    created_at = created_at
)

fun LoanSchedule.toEntity(isSynced: Boolean = false) = LoanScheduleEntity(
    id = id,
    loan_id = loan_id,
    emi_number = emi_number,
    due_date = due_date,
    opening_principal = opening_principal,
    principal_component = principal_component,
    interest_component = interest_component,
    emi_amount = emi_amount,
    closing_principal = closing_principal,
    paid_date = paid_date,
    paid_amount = paid_amount,
    payment_account_id = payment_account_id,
    status = status,
    created_at = created_at,
    is_synced = isSynced
)

fun LoanScheduleEntity.toDomain() = LoanSchedule(
    id = id,
    loan_id = loan_id,
    emi_number = emi_number,
    due_date = due_date,
    opening_principal = opening_principal,
    principal_component = principal_component,
    interest_component = interest_component,
    emi_amount = emi_amount,
    closing_principal = closing_principal,
    paid_date = paid_date,
    paid_amount = paid_amount,
    payment_account_id = payment_account_id,
    status = status,
    created_at = created_at
)

fun Supplier.toEntity(isSynced: Boolean = false) = SupplierEntity(
    id = id,
    name = name,
    phone = phone,
    address = address,
    gstin = gstin,
    credit_limit = credit_limit,
    credit_period_days = credit_period_days,
    opening_balance = opening_balance,
    current_outstanding = current_outstanding,
    is_active = is_active,
    created_at = created_at,
    is_synced = isSynced
)

fun SupplierEntity.toDomain() = Supplier(
    id = id,
    name = name,
    phone = phone,
    address = address,
    gstin = gstin,
    credit_limit = credit_limit,
    credit_period_days = credit_period_days,
    opening_balance = opening_balance,
    current_outstanding = current_outstanding,
    is_active = is_active,
    created_at = created_at
)

fun SupplierInvoice.toEntity(isSynced: Boolean = false) = SupplierInvoiceEntity(
    id = id,
    supplier_id = supplier_id,
    invoice_number = invoice_number,
    invoice_date = invoice_date,
    due_date = due_date,
    items_description = items_description,
    quantity = quantity,
    rate = rate,
    taxable_value = taxable_value,
    gst_rate = gst_rate,
    gst_amount = gst_amount,
    total_amount = total_amount,
    paid_amount = paid_amount,
    balance_due = balance_due,
    status = status,
    notes = notes,
    created_at = created_at,
    is_synced = isSynced
)

fun SupplierInvoiceEntity.toDomain() = SupplierInvoice(
    id = id,
    supplier_id = supplier_id,
    invoice_number = invoice_number,
    invoice_date = invoice_date,
    due_date = due_date,
    items_description = items_description,
    quantity = quantity,
    rate = rate,
    taxable_value = taxable_value,
    gst_rate = gst_rate,
    gst_amount = gst_amount,
    total_amount = total_amount,
    paid_amount = paid_amount,
    balance_due = balance_due,
    status = status,
    notes = notes,
    created_at = created_at
)

fun GstSettings.toEntity() = GstSettingsEntity(
    id = id,
    gst_enabled = gst_enabled,
    business_name = business_name,
    business_address = business_address,
    gstin = gstin,
    state_name = state_name,
    state_code = state_code,
    invoice_prefix = invoice_prefix,
    next_invoice_number = next_invoice_number,
    default_hsn = default_hsn,
    default_tax_rate = default_tax_rate,
    updated_at = updated_at
)

fun GstSettingsEntity.toDomain() = GstSettings(
    id = id,
    gst_enabled = gst_enabled,
    business_name = business_name,
    business_address = business_address,
    gstin = gstin,
    state_name = state_name,
    state_code = state_code,
    invoice_prefix = invoice_prefix,
    next_invoice_number = next_invoice_number,
    default_hsn = default_hsn,
    default_tax_rate = default_tax_rate,
    updated_at = updated_at
)

fun EWayBill.toEntity(isSynced: Boolean = false) = EWayBillEntity(
    id = id,
    invoice_id = invoice_id,
    invoice_number = invoice_number,
    supplier_gstin = supplier_gstin,
    recipient_gstin = recipient_gstin,
    place_of_supply = place_of_supply,
    delivery_address = delivery_address,
    hsn_code = hsn_code,
    quantity = quantity,
    taxable_value = taxable_value,
    gst_amount = gst_amount,
    total_value = total_value,
    transporter_id = transporter_id,
    transporter_name = transporter_name,
    vehicle_number = vehicle_number,
    transport_mode = transport_mode,
    transport_doc_number = transport_doc_number,
    document_date = document_date,
    eway_bill_number = eway_bill_number,
    status = status,
    error_message = error_message,
    created_at = created_at,
    is_synced = isSynced
)

fun EWayBillEntity.toDomain() = EWayBill(
    id = id,
    invoice_id = invoice_id,
    invoice_number = invoice_number,
    supplier_gstin = supplier_gstin,
    recipient_gstin = recipient_gstin,
    place_of_supply = place_of_supply,
    delivery_address = delivery_address,
    hsn_code = hsn_code,
    quantity = quantity,
    taxable_value = taxable_value,
    gst_amount = gst_amount,
    total_value = total_value,
    transporter_id = transporter_id,
    transporter_name = transporter_name,
    vehicle_number = vehicle_number,
    transport_mode = transport_mode,
    transport_doc_number = transport_doc_number,
    document_date = document_date,
    eway_bill_number = eway_bill_number,
    status = status,
    error_message = error_message,
    created_at = created_at
)
