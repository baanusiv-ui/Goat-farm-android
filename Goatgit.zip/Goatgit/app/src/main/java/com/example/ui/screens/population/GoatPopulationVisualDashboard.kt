package com.example.ui.screens.population

import androidx.compose.animation.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.TrendingUp
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.supabase.Goat
import com.example.data.supabase.GoatRepository
import com.example.ui.theme.*
import java.util.Locale
import kotlin.math.cos
import kotlin.math.sin

// ==============================================================================
// 1. DATA MODELS & COLOR PALETTE
// ==============================================================================

data class BreedPopulationStat(
    val breed: String,
    val totalCount: Int,
    val activeCount: Int,
    val pregnantCount: Int,
    val lactatingCount: Int,
    val dryCount: Int,
    val kidCount: Int,
    val quarantinedCount: Int,
    val doesCount: Int,
    val bucksCount: Int,
    val otherSexCount: Int,
    val percentage: Float,
    val color: Color
)

data class StatusPopulationStat(
    val status: String,
    val count: Int,
    val percentage: Float,
    val color: Color,
    val icon: ImageVector
)

data class HerdPopulationSummary(
    val totalGoats: Int,
    val totalBreeds: Int,
    val activeCount: Int,
    val pregnantCount: Int,
    val lactatingCount: Int,
    val dryCount: Int,
    val kidCount: Int,
    val quarantineCount: Int,
    val doesCount: Int,
    val bucksCount: Int,
    val breedStats: List<BreedPopulationStat>,
    val statusStats: List<StatusPopulationStat>
)

// Distinct Recharts-inspired vibrant palette for breeds
val RechartsColorPalette = listOf(
    Color(0xFF2E7D32), // Farm Green - Salem Karupu primary
    Color(0xFF0284C7), // Sky Blue - Kodi Adu primary
    Color(0xFF7C3AED), // Vivid Purple
    Color(0xFFF59E0B), // Warm Amber
    Color(0xFFEC4899), // Pink
    Color(0xFF14B8A6), // Teal
    Color(0xFFEF4444), // Coral Red
    Color(0xFF8B5CF6), // Violet
    Color(0xFF10B981), // Emerald
    Color(0xFF6366F1), // Indigo
    Color(0xFFF97316), // Orange
    Color(0xFF64748B)  // Slate
)

val StatusColorActive = Color(0xFF16A34A)
val StatusColorPregnant = Color(0xFF9333EA)
val StatusColorLactating = Color(0xFF0284C7)
val StatusColorDry = Color(0xFFEAB308)
val StatusColorKid = Color(0xFFF97316)
val StatusColorQuarantine = Color(0xFFDC2626)
val StatusColorSold = Color(0xFF64748B)

fun getStatusColor(status: String): Color = when (status.lowercase(Locale.ROOT)) {
    "active" -> StatusColorActive
    "pregnant" -> StatusColorPregnant
    "lactating", "in milk" -> StatusColorLactating
    "dry" -> StatusColorDry
    "kid", "weaned" -> StatusColorKid
    "quarantine", "quarantined" -> StatusColorQuarantine
    "sold" -> StatusColorSold
    else -> Color(0xFF8B5CF6)
}

fun getStatusIcon(status: String): ImageVector = when (status.lowercase(Locale.ROOT)) {
    "active" -> Icons.Default.CheckCircle
    "pregnant" -> Icons.Default.Favorite
    "lactating", "in milk" -> Icons.Default.WaterDrop
    "dry" -> Icons.Default.WbSunny
    "kid", "weaned" -> Icons.Default.ChildCare
    "quarantine", "quarantined" -> Icons.Default.Warning
    "sold" -> Icons.Default.Sell
    else -> Icons.Default.Pets
}

/**
 * Computes population summary stats categorized by breed and status.
 */
fun computeHerdPopulationSummary(goats: List<Goat>): HerdPopulationSummary {
    val totalGoats = goats.size
    if (totalGoats == 0) {
        return HerdPopulationSummary(
            totalGoats = 0,
            totalBreeds = 0,
            activeCount = 0,
            pregnantCount = 0,
            lactatingCount = 0,
            dryCount = 0,
            kidCount = 0,
            quarantineCount = 0,
            doesCount = 0,
            bucksCount = 0,
            breedStats = emptyList(),
            statusStats = emptyList()
        )
    }

    // Standardize breed names
    fun normalizeBreed(b: String?): String {
        val trimmed = b?.trim().orEmpty()
        return if (trimmed.isBlank()) "Crossbred" else trimmed
    }

    // Standardize status names
    fun normalizeStatus(s: String?): String {
        val trimmed = s?.trim().orEmpty()
        return when {
            trimmed.isBlank() -> "Active"
            trimmed.contains("pregnant", ignoreCase = true) -> "Pregnant"
            trimmed.contains("lactat", ignoreCase = true) || trimmed.contains("milk", ignoreCase = true) -> "Lactating"
            trimmed.contains("dry", ignoreCase = true) -> "Dry"
            trimmed.contains("kid", ignoreCase = true) -> "Kid"
            trimmed.contains("quarantin", ignoreCase = true) -> "Quarantine"
            trimmed.contains("sold", ignoreCase = true) -> "Sold"
            else -> trimmed.replaceFirstChar { if (it.isLowerCase()) it.titlecase(Locale.ROOT) else it.toString() }
        }
    }

    val goatsByBreed = goats.groupBy { normalizeBreed(it.breed_c) }

    // Prioritize Salem Karupu and Kodi Adu at top of list if present
    val sortedBreeds = goatsByBreed.keys.sortedWith(Comparator { a, b ->
        val rankA = when {
            a.contains("Salem Karupu", ignoreCase = true) -> 0
            a.contains("Kodi Adu", ignoreCase = true) -> 1
            else -> 2
        }
        val rankB = when {
            b.contains("Salem Karupu", ignoreCase = true) -> 0
            b.contains("Kodi Adu", ignoreCase = true) -> 1
            else -> 2
        }
        if (rankA != rankB) rankA.compareTo(rankB)
        else (goatsByBreed[b]?.size ?: 0).compareTo(goatsByBreed[a]?.size ?: 0)
    })

    val breedStats = sortedBreeds.mapIndexed { index, breedName ->
        val list = goatsByBreed[breedName] ?: emptyList()
        val count = list.size
        val active = list.count { normalizeStatus(it.status_c) == "Active" }
        val pregnant = list.count { normalizeStatus(it.status_c) == "Pregnant" }
        val lactating = list.count { normalizeStatus(it.status_c) == "Lactating" }
        val dry = list.count { normalizeStatus(it.status_c) == "Dry" }
        val kid = list.count { normalizeStatus(it.status_c) == "Kid" || it.sex_c.equals("Kid", true) }
        val quarantined = list.count { normalizeStatus(it.status_c) == "Quarantine" }
        val does = list.count { it.sex_c.equals("Doe", true) }
        val bucks = list.count { it.sex_c.equals("Buck", true) }
        val otherSex = count - does - bucks
        val pct = (count.toFloat() / totalGoats) * 100f

        BreedPopulationStat(
            breed = breedName,
            totalCount = count,
            activeCount = active,
            pregnantCount = pregnant,
            lactatingCount = lactating,
            dryCount = dry,
            kidCount = kid,
            quarantinedCount = quarantined,
            doesCount = does,
            bucksCount = bucks,
            otherSexCount = otherSex,
            percentage = pct,
            color = RechartsColorPalette[index % RechartsColorPalette.size]
        )
    }

    val goatsByStatus = goats.groupBy { normalizeStatus(it.status_c) }
    val standardStatusOrder = listOf("Active", "Pregnant", "Lactating", "Dry", "Kid", "Quarantine", "Sold")
    val allStatuses = (standardStatusOrder.filter { goatsByStatus.containsKey(it) } +
            (goatsByStatus.keys - standardStatusOrder.toSet())).distinct()

    val statusStats = allStatuses.map { statusName ->
        val count = goatsByStatus[statusName]?.size ?: 0
        val pct = (count.toFloat() / totalGoats) * 100f
        StatusPopulationStat(
            status = statusName,
            count = count,
            percentage = pct,
            color = getStatusColor(statusName),
            icon = getStatusIcon(statusName)
        )
    }

    val activeCount = goats.count { normalizeStatus(it.status_c) == "Active" }
    val pregnantCount = goats.count { normalizeStatus(it.status_c) == "Pregnant" }
    val lactatingCount = goats.count { normalizeStatus(it.status_c) == "Lactating" }
    val dryCount = goats.count { normalizeStatus(it.status_c) == "Dry" }
    val kidsCount = goats.count { normalizeStatus(it.status_c) == "Kid" || it.sex_c.equals("Kid", true) }
    val quarantineCount = goats.count { normalizeStatus(it.status_c) == "Quarantine" }
    val doesCount = goats.count { it.sex_c.equals("Doe", true) }
    val bucksCount = goats.count { it.sex_c.equals("Buck", true) }

    return HerdPopulationSummary(
        totalGoats = totalGoats,
        totalBreeds = breedStats.size,
        activeCount = activeCount,
        pregnantCount = pregnantCount,
        lactatingCount = lactatingCount,
        dryCount = dryCount,
        kidCount = kidsCount,
        quarantineCount = quarantineCount,
        doesCount = doesCount,
        bucksCount = bucksCount,
        breedStats = breedStats,
        statusStats = statusStats
    )
}

// ==============================================================================
// 2. RECHARTS-STYLE BREED BAR CHART (VERTICAL ROUNDED BARS WITH GRID & TOOLTIP)
// ==============================================================================

@Composable
fun RechartsBreedBarChart(
    breedStats: List<BreedPopulationStat>,
    selectedBreed: String?,
    onSelectBreed: (String?) -> Unit,
    modifier: Modifier = Modifier
) {
    if (breedStats.isEmpty()) {
        Box(
            modifier = modifier
                .fillMaxWidth()
                .height(200.dp)
                .background(Color(0xFFF8FAFC), RoundedCornerShape(12.dp)),
            contentAlignment = Alignment.Center
        ) {
            Text("No herd population data available to chart", color = Color.Gray, fontSize = 13.sp)
        }
        return
    }

    val maxCount = remember(breedStats) {
        val m = breedStats.maxOfOrNull { it.totalCount } ?: 1
        // Round up to nearest nice number
        if (m <= 5) 5 else if (m <= 10) 10 else ((m + 4) / 5) * 5
    }

    val activeIndex = remember(selectedBreed, breedStats) {
        if (selectedBreed == null) null
        else breedStats.indexOfFirst { it.breed.equals(selectedBreed, ignoreCase = true) }.takeIf { it >= 0 }
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(Color.White)
            .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(16.dp))
            .padding(16.dp)
    ) {
        // Chart Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .background(FarmGreenPrimary, CircleShape)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Population by Breed",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF0F172A)
                    )
                }
                Text(
                    text = "Tap any bar to inspect status distribution & drill down",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color(0xFF64748B)
                )
            }

            if (selectedBreed != null) {
                TextButton(
                    onClick = { onSelectBreed(null) },
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                ) {
                    Text("Clear Filter", fontSize = 11.sp, color = FarmGreenPrimary)
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Tooltip Banner for Selected Breed
        activeIndex?.let { idx ->
            if (idx in breedStats.indices) {
                val stat = breedStats[idx]
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = Color(0xFF0F172A),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 12.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(modifier = Modifier.size(8.dp).background(stat.color, CircleShape))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = stat.breed,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    color = Color.White
                                )
                            }
                            Text(
                                text = "${stat.doesCount} Does • ${stat.bucksCount} Bucks • ${stat.kidCount} Kids",
                                fontSize = 11.sp,
                                color = Color(0xFF94A3B8)
                            )
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = "${stat.totalCount} Goats",
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp,
                                color = stat.color
                            )
                            Text(
                                text = "${String.format(Locale.US, "%.1f", stat.percentage)}% of total herd",
                                fontSize = 11.sp,
                                color = Color(0xFFE2E8F0)
                            )
                        }
                    }
                }
            }
        }

        // Canvas Recharts Bar Chart
        val barCount = breedStats.size
        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(220.dp)
                .pointerInput(breedStats) {
                    detectTapGestures { offset ->
                        val leftPad = 32.dp.toPx()
                        val rightPad = 16.dp.toPx()
                        val chartW = size.width - leftPad - rightPad
                        val slotW = chartW / barCount.coerceAtLeast(1)
                        if (offset.x >= leftPad && offset.x <= size.width - rightPad) {
                            val clickedIdx = ((offset.x - leftPad) / slotW).toInt().coerceIn(0, barCount - 1)
                            val clickedBreed = breedStats[clickedIdx].breed
                            if (clickedBreed.equals(selectedBreed, ignoreCase = true)) {
                                onSelectBreed(null)
                            } else {
                                onSelectBreed(clickedBreed)
                            }
                        }
                    }
                }
        ) {
            val leftPad = 32.dp.toPx()
            val rightPad = 16.dp.toPx()
            val topPad = 20.dp.toPx()
            val bottomPad = 40.dp.toPx()

            val chartW = size.width - leftPad - rightPad
            val chartH = size.height - topPad - bottomPad

            // 1. Dotted Cartesian Grid Lines (Recharts signature)
            val gridSteps = 4
            val gridColor = Color(0xFFE2E8F0)
            val dashEffect = PathEffect.dashPathEffect(floatArrayOf(6f, 6f), 0f)

            for (i in 0..gridSteps) {
                val y = topPad + chartH * (1f - (i.toFloat() / gridSteps))
                drawLine(
                    color = gridColor,
                    start = Offset(leftPad, y),
                    end = Offset(size.width - rightPad, y),
                    strokeWidth = 1f,
                    pathEffect = dashEffect
                )

                // Y-Axis labels
                val tickVal = (maxCount * (i.toFloat() / gridSteps)).toInt()
                drawContext.canvas.nativeCanvas.apply {
                    val paint = android.graphics.Paint().apply {
                        color = android.graphics.Color.GRAY
                        textSize = 24f
                        textAlign = android.graphics.Paint.Align.RIGHT
                        isAntiAlias = true
                    }
                    drawText(
                        tickVal.toString(),
                        leftPad - 12f,
                        y + 8f,
                        paint
                    )
                }
            }

            // 2. Draw Bars
            val slotW = chartW / barCount.coerceAtLeast(1)
            val barW = (slotW * 0.65f).coerceIn(16.dp.toPx(), 44.dp.toPx())

            breedStats.forEachIndexed { idx, stat ->
                val centerX = leftPad + slotW * idx + (slotW / 2f)
                val barLeft = centerX - (barW / 2f)

                val ratio = if (maxCount > 0) stat.totalCount.toFloat() / maxCount else 0f
                val barH = chartH * ratio.coerceIn(0f, 1f)
                val barTop = topPad + chartH - barH

                val isSelected = selectedBreed?.equals(stat.breed, ignoreCase = true) == true
                val barColor = if (selectedBreed == null || isSelected) stat.color else stat.color.copy(alpha = 0.35f)

                // Draw Bar with rounded top corners
                drawRoundRect(
                    color = barColor,
                    topLeft = Offset(barLeft, barTop),
                    size = Size(barW, barH.coerceAtLeast(4f)),
                    cornerRadius = CornerRadius(8.dp.toPx(), 8.dp.toPx())
                )

                // If selected, draw accent stroke
                if (isSelected) {
                    drawRoundRect(
                        color = Color(0xFF0F172A),
                        topLeft = Offset(barLeft - 2f, barTop - 2f),
                        size = Size(barW + 4f, barH + 4f),
                        cornerRadius = CornerRadius(10.dp.toPx(), 10.dp.toPx()),
                        style = Stroke(width = 3.dp.toPx())
                    )
                }

                // Value above bar
                drawContext.canvas.nativeCanvas.apply {
                    val paint = android.graphics.Paint().apply {
                        color = if (isSelected) android.graphics.Color.BLACK else android.graphics.Color.DKGRAY
                        textSize = 26f
                        textAlign = android.graphics.Paint.Align.CENTER
                        isFakeBoldText = isSelected
                        isAntiAlias = true
                    }
                    drawText(
                        stat.totalCount.toString(),
                        centerX,
                        barTop - 10f,
                        paint
                    )
                }

                // X-Axis Breed Label (truncated if long)
                val labelText = if (stat.breed.length > 8) stat.breed.take(7) + "…" else stat.breed
                drawContext.canvas.nativeCanvas.apply {
                    val paint = android.graphics.Paint().apply {
                        color = if (isSelected) android.graphics.Color.parseColor("#1B4332") else android.graphics.Color.GRAY
                        textSize = 24f
                        textAlign = android.graphics.Paint.Align.CENTER
                        isFakeBoldText = isSelected
                        isAntiAlias = true
                    }
                    drawText(
                        labelText,
                        centerX,
                        topPad + chartH + 26f,
                        paint
                    )
                }
            }
        }

        // Legend row with pill chips
        Spacer(modifier = Modifier.height(10.dp))
        LazyRow(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(breedStats) { stat ->
                val isSelected = selectedBreed?.equals(stat.breed, ignoreCase = true) == true
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = if (isSelected) stat.color.copy(alpha = 0.15f) else Color(0xFFF8FAFC),
                    border = androidx.compose.foundation.BorderStroke(
                        width = if (isSelected) 1.5.dp else 1.dp,
                        color = if (isSelected) stat.color else Color(0xFFE2E8F0)
                    ),
                    modifier = Modifier.clickable {
                        if (isSelected) onSelectBreed(null) else onSelectBreed(stat.breed)
                    }
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .background(stat.color, CircleShape)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = stat.breed,
                            fontSize = 11.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                            color = if (isSelected) stat.color else Color(0xFF334155)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "(${stat.totalCount})",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF64748B)
                        )
                    }
                }
            }
        }
    }
}

// ==============================================================================
// 3. RECHARTS-STYLE STATUS DONUT / PIE CHART
// ==============================================================================

@Composable
fun RechartsStatusDonutChart(
    statusStats: List<StatusPopulationStat>,
    totalGoats: Int,
    selectedStatus: String?,
    onSelectStatus: (String?) -> Unit,
    modifier: Modifier = Modifier
) {
    if (statusStats.isEmpty() || totalGoats == 0) {
        return
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(Color.White)
            .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(16.dp))
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .background(Color(0xFF7C3AED), CircleShape)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Population by Status",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF0F172A)
                    )
                }
                Text(
                    text = "Reproductive & physiological herd composition",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color(0xFF64748B)
                )
            }

            if (selectedStatus != null) {
                TextButton(
                    onClick = { onSelectStatus(null) },
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                ) {
                    Text("Clear Filter", fontSize = 11.sp, color = FarmGreenPrimary)
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Donut Chart Canvas and Legend in Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Left Donut Canvas
            Box(
                modifier = Modifier
                    .size(170.dp)
                    .padding(8.dp),
                contentAlignment = Alignment.Center
            ) {
                Canvas(
                    modifier = Modifier
                        .fillMaxSize()
                        .pointerInput(statusStats) {
                            detectTapGestures { offset ->
                                val center = Offset(size.width / 2f, size.height / 2f)
                                val dx = offset.x - center.x
                                val dy = offset.y - center.y
                                var angle = Math.toDegrees(kotlin.math.atan2(dy.toDouble(), dx.toDouble())).toFloat()
                                if (angle < 0) angle += 360f

                                // Check which segment was clicked
                                var currentAngle = -90f
                                for (stat in statusStats) {
                                    val sweep = (stat.count.toFloat() / totalGoats) * 360f
                                    val start = if (currentAngle < 0) currentAngle + 360f else currentAngle
                                    // Normalize check
                                    val inSegment = if (start + sweep <= 360f) {
                                        angle >= start && angle <= start + sweep
                                    } else {
                                        (angle >= start && angle <= 360f) || (angle >= 0f && angle <= (start + sweep - 360f))
                                    }
                                    if (inSegment) {
                                        if (stat.status.equals(selectedStatus, true)) {
                                            onSelectStatus(null)
                                        } else {
                                            onSelectStatus(stat.status)
                                        }
                                        break
                                    }
                                    currentAngle += sweep
                                }
                            }
                        }
                ) {
                    val strokeW = 28.dp.toPx()
                    val diameter = size.minDimension - strokeW
                    val arcTopLeft = Offset((size.width - diameter) / 2f, (size.height - diameter) / 2f)
                    val arcSize = Size(diameter, diameter)

                    var startAngle = -90f
                    statusStats.forEach { stat ->
                        val sweep = (stat.count.toFloat() / totalGoats) * 360f
                        val isSelected = selectedStatus?.equals(stat.status, ignoreCase = true) == true
                        val color = if (selectedStatus == null || isSelected) stat.color else stat.color.copy(alpha = 0.3f)
                        val actualStroke = if (isSelected) strokeW + 6.dp.toPx() else strokeW

                        drawArc(
                            color = color,
                            startAngle = startAngle,
                            sweepAngle = (sweep - 2f).coerceAtLeast(1f),
                            useCenter = false,
                            topLeft = arcTopLeft,
                            size = arcSize,
                            style = Stroke(width = actualStroke)
                        )
                        startAngle += sweep
                    }
                }

                // Center Text Display
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "$totalGoats",
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 22.sp,
                        color = Color(0xFF0F172A)
                    )
                    Text(
                        text = "Total Herd",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Medium,
                        color = Color(0xFF64748B)
                    )
                }
            }

            Spacer(modifier = Modifier.width(12.dp))

            // Right Legend Items
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                statusStats.forEach { stat ->
                    val isSelected = selectedStatus?.equals(stat.status, ignoreCase = true) == true
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(6.dp))
                            .background(if (isSelected) stat.color.copy(alpha = 0.12f) else Color.Transparent)
                            .clickable {
                                if (isSelected) onSelectStatus(null) else onSelectStatus(stat.status)
                            }
                            .padding(horizontal = 6.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(10.dp)
                                    .background(stat.color, RoundedCornerShape(2.dp))
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = stat.status,
                                fontSize = 12.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                color = if (isSelected) stat.color else Color(0xFF1E293B)
                            )
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "${stat.count}",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF0F172A)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "(${String.format(Locale.US, "%.0f", stat.percentage)}%)",
                                fontSize = 10.sp,
                                color = Color(0xFF64748B)
                            )
                        }
                    }
                }
            }
        }
    }
}

// ==============================================================================
// 4. BREED × STATUS STACKED COMPOSITION CHART
// ==============================================================================

@Composable
fun RechartsBreedStatusStackedChart(
    breedStats: List<BreedPopulationStat>,
    modifier: Modifier = Modifier
) {
    if (breedStats.isEmpty()) return

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(Color.White)
            .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(16.dp))
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(modifier = Modifier.size(10.dp).background(Color(0xFF0284C7), CircleShape))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Status Composition by Breed",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF0F172A)
                    )
                }
                Text(
                    text = "Stacked view of pregnant, lactating, and growing animals per breed",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color(0xFF64748B)
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Stacked Horizontal Bars per Breed
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            breedStats.forEach { stat ->
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = stat.breed,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            color = Color(0xFF1E293B)
                        )
                        Text(
                            text = "${stat.totalCount} goats",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color(0xFF64748B)
                        )
                    }

                    // Stacked Bar Container
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(18.dp)
                            .clip(RoundedCornerShape(6.dp))
                            .background(Color(0xFFF1F5F9))
                    ) {
                        if (stat.activeCount > 0) {
                            Box(
                                modifier = Modifier
                                    .weight(stat.activeCount.toFloat())
                                    .fillMaxHeight()
                                    .background(StatusColorActive)
                            )
                        }
                        if (stat.pregnantCount > 0) {
                            Box(
                                modifier = Modifier
                                    .weight(stat.pregnantCount.toFloat())
                                    .fillMaxHeight()
                                    .background(StatusColorPregnant)
                            )
                        }
                        if (stat.lactatingCount > 0) {
                            Box(
                                modifier = Modifier
                                    .weight(stat.lactatingCount.toFloat())
                                    .fillMaxHeight()
                                    .background(StatusColorLactating)
                            )
                        }
                        if (stat.kidCount > 0) {
                            Box(
                                modifier = Modifier
                                    .weight(stat.kidCount.toFloat())
                                    .fillMaxHeight()
                                    .background(StatusColorKid)
                            )
                        }
                        if (stat.quarantinedCount > 0) {
                            Box(
                                modifier = Modifier
                                    .weight(stat.quarantinedCount.toFloat())
                                    .fillMaxHeight()
                                    .background(StatusColorQuarantine)
                            )
                        }
                    }
                }
            }
        }

        // Mini Status Legend
        Spacer(modifier = Modifier.height(14.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            StackedLegendDot(color = StatusColorActive, label = "Active")
            StackedLegendDot(color = StatusColorPregnant, label = "Pregnant")
            StackedLegendDot(color = StatusColorLactating, label = "Lactating")
            StackedLegendDot(color = StatusColorKid, label = "Kids")
            StackedLegendDot(color = StatusColorQuarantine, label = "Quarantine")
        }
    }
}

@Composable
private fun StackedLegendDot(color: Color, label: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(modifier = Modifier.size(8.dp).background(color, CircleShape))
        Spacer(modifier = Modifier.width(4.dp))
        Text(text = label, fontSize = 10.sp, color = Color(0xFF64748B), fontWeight = FontWeight.Medium)
    }
}

// ==============================================================================
// 5. CROSS-TABULATION MATRIX TABLE (BREED × STATUS)
// ==============================================================================

@Composable
fun CrossTabulationPopulationMatrix(
    summary: HerdPopulationSummary,
    selectedBreed: String?,
    selectedStatus: String?,
    onSelectBreed: (String?) -> Unit,
    onSelectStatus: (String?) -> Unit,
    modifier: Modifier = Modifier
) {
    if (summary.totalGoats == 0) return

    val statuses = remember(summary.statusStats) { summary.statusStats.map { it.status } }

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Breed × Status Cross Matrix",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = FarmGreenDark
                    )
                    Text(
                        text = "Full demographic distribution across all categories",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.Gray
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Horizontally Scrollable Matrix
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
            ) {
                Column {
                    // Header Row
                    Row(
                        modifier = Modifier
                            .background(Color(0xFFF1F5F9), RoundedCornerShape(8.dp))
                            .padding(vertical = 8.dp, horizontal = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Breed Name",
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            color = Color(0xFF334155),
                            modifier = Modifier.width(110.dp).padding(start = 8.dp)
                        )
                        statuses.forEach { statusName ->
                            Text(
                                text = statusName,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp,
                                textAlign = TextAlign.Center,
                                color = getStatusColor(statusName),
                                modifier = Modifier.width(68.dp)
                            )
                        }
                        Text(
                            text = "Total",
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            textAlign = TextAlign.Center,
                            color = Color(0xFF0F172A),
                            modifier = Modifier.width(64.dp)
                        )
                    }

                    HorizontalDivider(color = Color(0xFFE2E8F0), thickness = 1.dp)

                    // Data Rows
                    summary.breedStats.forEach { stat ->
                        val isBreedSelected = stat.breed.equals(selectedBreed, true)
                        Row(
                            modifier = Modifier
                                .clickable {
                                    if (isBreedSelected) onSelectBreed(null) else onSelectBreed(stat.breed)
                                }
                                .background(if (isBreedSelected) FarmGreenContainer.copy(alpha = 0.5f) else Color.Transparent)
                                .padding(vertical = 8.dp, horizontal = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                modifier = Modifier.width(110.dp).padding(start = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(modifier = Modifier.size(6.dp).background(stat.color, CircleShape))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = stat.breed,
                                    fontSize = 12.sp,
                                    fontWeight = if (isBreedSelected) FontWeight.Bold else FontWeight.Medium,
                                    color = Color(0xFF1E293B),
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }

                            statuses.forEach { st ->
                                val count = when (st.lowercase(Locale.ROOT)) {
                                    "active" -> stat.activeCount
                                    "pregnant" -> stat.pregnantCount
                                    "lactating", "in milk" -> stat.lactatingCount
                                    "dry" -> stat.dryCount
                                    "kid" -> stat.kidCount
                                    "quarantine" -> stat.quarantinedCount
                                    else -> 0
                                }
                                Box(
                                    modifier = Modifier.width(68.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    if (count > 0) {
                                        Surface(
                                            shape = RoundedCornerShape(4.dp),
                                            color = if (count >= 5) getStatusColor(st).copy(alpha = 0.2f) else Color(0xFFF1F5F9),
                                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                        ) {
                                            Text(
                                                text = "$count",
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = if (count >= 5) getStatusColor(st) else Color(0xFF334155),
                                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                            )
                                        }
                                    } else {
                                        Text(text = "–", fontSize = 11.sp, color = Color.LightGray)
                                    }
                                }
                            }

                            Text(
                                text = "${stat.totalCount}",
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                textAlign = TextAlign.Center,
                                color = Color(0xFF0F172A),
                                modifier = Modifier.width(64.dp)
                            )
                        }
                        HorizontalDivider(color = Color(0xFFF8FAFC))
                    }

                    // Total Bottom Row
                    Row(
                        modifier = Modifier
                            .background(Color(0xFFF8FAFC), RoundedCornerShape(8.dp))
                            .padding(vertical = 8.dp, horizontal = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "TOTALS",
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            color = Color(0xFF0F172A),
                            modifier = Modifier.width(110.dp).padding(start = 8.dp)
                        )
                        statuses.forEach { st ->
                            val statusTotal = summary.statusStats.firstOrNull { it.status.equals(st, true) }?.count ?: 0
                            Text(
                                text = "$statusTotal",
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp,
                                textAlign = TextAlign.Center,
                                color = getStatusColor(st),
                                modifier = Modifier.width(68.dp)
                            )
                        }
                        Text(
                            text = "${summary.totalGoats}",
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 12.sp,
                            textAlign = TextAlign.Center,
                            color = FarmGreenDark,
                            modifier = Modifier.width(64.dp)
                        )
                    }
                }
            }
        }
    }
}

// ==============================================================================
// 6. POPULATION KPI STAT CARDS
// ==============================================================================

@Composable
fun PopulationKpiCardsRow(
    summary: HerdPopulationSummary,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        KpiCard(
            title = "Total Herd",
            value = "${summary.totalGoats}",
            sub = "${summary.totalBreeds} Breeds",
            color = FarmGreenPrimary,
            icon = Icons.Default.Pets,
            modifier = Modifier.weight(1f)
        )
        KpiCard(
            title = "Breeding Does",
            value = "${summary.doesCount}",
            sub = "${summary.pregnantCount} Pregnant",
            color = Color(0xFF7C3AED),
            icon = Icons.Default.Favorite,
            modifier = Modifier.weight(1f)
        )
        KpiCard(
            title = "Sires (Bucks)",
            value = "${summary.bucksCount}",
            sub = "Active Sires",
            color = Color(0xFF0284C7),
            icon = Icons.Default.Shield,
            modifier = Modifier.weight(1f)
        )
        KpiCard(
            title = "Growing Kids",
            value = "${summary.kidCount}",
            sub = "Offspring",
            color = Color(0xFFF97316),
            icon = Icons.Default.ChildCare,
            modifier = Modifier.weight(1f)
        )
    }
}

@Composable
private fun KpiCard(
    title: String,
    value: String,
    sub: String,
    color: Color,
    icon: ImageVector,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = Color.White,
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
        modifier = modifier
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(24.dp)
                        .background(color.copy(alpha = 0.12f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(14.dp))
                }
                Text(
                    text = sub,
                    fontSize = 10.sp,
                    color = Color(0xFF64748B),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = value,
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp,
                color = Color(0xFF0F172A)
            )
            Text(
                text = title,
                fontSize = 10.sp,
                color = Color(0xFF64748B),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}
