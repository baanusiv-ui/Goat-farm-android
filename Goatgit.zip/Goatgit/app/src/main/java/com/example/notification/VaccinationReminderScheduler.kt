package com.example.notification

import android.content.Context
import android.util.Log
import androidx.work.*
import java.util.concurrent.TimeUnit

object VaccinationReminderScheduler {
    private const val TAG = "VaccinationScheduler"
    private const val UNIQUE_WORK_NAME = "recurring_goat_vaccination_reminders"

    /**
     * Schedules periodic 24-hour background checking for upcoming goat vaccinations.
     */
    fun scheduleDaily(context: Context) {
        val constraints = Constraints.Builder()
            .setRequiresBatteryNotLow(false)
            .build()

        val periodicWork = PeriodicWorkRequestBuilder<VaccinationNotificationWorker>(
            24, TimeUnit.HOURS,
            4, TimeUnit.HOURS // flex interval
        )
            .setConstraints(constraints)
            .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 15, TimeUnit.MINUTES)
            .build()

        WorkManager.getInstance(context).enqueueUniquePeriodicWork(
            UNIQUE_WORK_NAME,
            ExistingPeriodicWorkPolicy.KEEP,
            periodicWork
        )
        Log.d(TAG, "Recurring vaccination notification system scheduled (every 24 hours).")
    }

    /**
     * Triggers an immediate one-time check for upcoming vaccinations.
     * Useful for on-demand testing or immediate scan upon recording new health events.
     */
    fun triggerImmediateCheck(context: Context) {
        val oneTimeWork = OneTimeWorkRequestBuilder<VaccinationNotificationWorker>()
            .setExpedited(OutOfQuotaPolicy.RUN_AS_NON_EXPEDITED_WORK_REQUEST)
            .build()

        WorkManager.getInstance(context).enqueue(oneTimeWork)
        Log.d(TAG, "Immediate vaccination reminder check triggered.")
    }

    /**
     * Cancels the recurring notification worker.
     */
    fun cancel(context: Context) {
        WorkManager.getInstance(context).cancelUniqueWork(UNIQUE_WORK_NAME)
        Log.d(TAG, "Recurring vaccination notification system cancelled.")
    }
}
