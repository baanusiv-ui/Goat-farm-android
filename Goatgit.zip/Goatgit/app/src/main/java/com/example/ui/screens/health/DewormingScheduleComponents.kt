package com.example.ui.screens.health

import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.supabase.DewormingRecord
import com.example.data.supabase.Goat
import com.example.data.supabase.PregnancyRecord
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun DewormingProtocolsListView(
    onSelectProtocolForRecord: (DewormingProtocolStage) -> Unit
) {
    var selectedCategory by remember { mutableStateOf(DewormingCategory.ALL) }

    val filteredProtocols = remember(selectedCategory) {
        if (selectedCategory == DewormingCategory.ALL) {
            DewormingScheduleCatalog.protocols
        } else {
            DewormingScheduleCatalog.protocols.filter { it.category == selectedCategory }
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Category Filter Chips
        item {
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                item {
                    FilterChip(
                        selected = selectedCategory == DewormingCategory.ALL,
                        onClick = { selectedCategory = DewormingCategory.ALL },
                        label = { Text("All Protocols", fontSize = 11.sp, fontWeight = FontWeight.SemiBold) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = FarmGreenDark,
                            selectedLabelColor = Color.White
                        ),
                        modifier = Modifier.testTag("chip_deworm_all")
                    )
                }
                item {
                    FilterChip(
                        selected = selectedCategory == DewormingCategory.KIDS,
                        onClick = { selectedCategory = DewormingCategory.KIDS },
                        label = { Text("Kids (குட்டிகள் 0-3m)", fontSize = 11.sp, fontWeight = FontWeight.SemiBold) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = Color(0xFF0284C7),
                            selectedLabelColor = Color.White
                        ),
                        modifier = Modifier.testTag("chip_deworm_kids")
                    )
                }
                item {
                    FilterChip(
                        selected = selectedCategory == DewormingCategory.GROWING,
                        onClick = { selectedCategory = DewormingCategory.GROWING },
                        label = { Text("Growing (வளரும் 3-6m)", fontSize = 11.sp, fontWeight = FontWeight.SemiBold) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = Color(0xFFD97706),
                            selectedLabelColor = Color.White
                        )
                    )
                }
                item {
                    FilterChip(
                        selected = selectedCategory == DewormingCategory.ADULTS,
                        onClick = { selectedCategory = DewormingCategory.ADULTS },
                        label = { Text("Adults (பெரிய ஆடுகள்)", fontSize = 11.sp, fontWeight = FontWeight.SemiBold) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = Color(0xFF059669),
                            selectedLabelColor = Color.White
                        )
                    )
                }
                item {
                    FilterChip(
                        selected = selectedCategory == DewormingCategory.PREGNANT_DOES,
                        onClick = { selectedCategory = DewormingCategory.PREGNANT_DOES },
                        label = { Text("Pregnant Does (சினை ஆடுகள்)", fontSize = 11.sp, fontWeight = FontWeight.SemiBold) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = Color(0xFFDC2626),
                            selectedLabelColor = Color.White
                        )
                    )
                }
                item {
                    FilterChip(
                        selected = selectedCategory == DewormingCategory.ROTATION_GUIDE,
                        onClick = { selectedCategory = DewormingCategory.ROTATION_GUIDE },
                        label = { Text("Drug Rotation (மருந்து சுழற்சி)", fontSize = 11.sp, fontWeight = FontWeight.SemiBold) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = Color(0xFF7C3AED),
                            selectedLabelColor = Color.White
                        )
                    )
                }
            }
        }

        // Critical Pregnancy Safety Banner
        item {
            Surface(
                color = Color(0xFFFEF2F2),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.5.dp, Color(0xFFFCA5A5)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.WarningAmber,
                            contentDescription = null,
                            tint = Color(0xFFDC2626),
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "CRITICAL PREGNANCY WARNING (சினை ஆடுகள் எச்சரிக்கை)",
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            color = Color(0xFF991B1B)
                        )
                    }
                    Text(
                        text = "• DO NOT DEWORM during the first 45-60 days of pregnancy! High risk of embryonic resorption and birth defects (especially with Albendazole).\n• Late gestation (90+ days): Use pregnancy-safe Fenbendazole ONLY if essential.\n• Deworm doe 2-3 weeks post-kidding to arrest lactational egg shedding.",
                        fontSize = 11.sp,
                        color = Color(0xFF7F1D1D),
                        lineHeight = 15.sp
                    )
                }
            }
        }

        // Show Drug Rotation Chart if selected
        if (selectedCategory == DewormingCategory.ROTATION_GUIDE || selectedCategory == DewormingCategory.ALL) {
            item {
                AnthelminticRotationGuideCard()
            }
        }

        // Protocols list
        if (selectedCategory != DewormingCategory.ROTATION_GUIDE) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "AGE & STAGE PROTOCOLS (${filteredProtocols.size})",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.Gray,
                        letterSpacing = 0.5.sp
                    )
                    Text(
                        text = "Based on Caprine Veterinary Guidelines",
                        fontSize = 10.sp,
                        color = Color(0xFF059669)
                    )
                }
            }

            items(filteredProtocols, key = { it.id }) { protocol ->
                DewormingProtocolCard(
                    protocol = protocol,
                    onApply = { onSelectProtocolForRecord(protocol) }
                )
            }
        }

        item {
            Spacer(modifier = Modifier.height(72.dp))
        }
    }
}

@Composable
fun DewormingProtocolCard(
    protocol: DewormingProtocolStage,
    onApply: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(12.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        border = if (protocol.isContraindicated) BorderStroke(1.dp, Color(0xFFFCA5A5)) else BorderStroke(1.dp, Color(0xFFF1F5F9)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            // Header Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = protocol.title,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = Color(0xFF1E293B)
                    )
                    Text(
                        text = protocol.tamilTitle,
                        fontSize = 11.sp,
                        color = Color.Gray
                    )
                }

                Surface(
                    color = if (protocol.isContraindicated) Color(0xFFFEE2E2) else protocol.accentColor.copy(alpha = 0.12f),
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text(
                        text = protocol.stageBadge,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (protocol.isContraindicated) Color(0xFFDC2626) else protocol.accentColor,
                        modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp)
                    )
                }
            }

            HorizontalDivider(color = Color(0xFFF1F5F9))

            // Medicine & Drug Class
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(30.dp)
                        .clip(CircleShape)
                        .background(protocol.accentColor.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Medication,
                        contentDescription = null,
                        tint = protocol.accentColor,
                        modifier = Modifier.size(16.dp)
                    )
                }
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text(
                        text = protocol.recommendedMedicine,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = Color(0xFF0F172A)
                    )
                    Text(
                        text = "Class: ${protocol.drugClass} • Route: ${protocol.route}",
                        fontSize = 10.sp,
                        color = Color.Gray
                    )
                }
            }

            // Dosage & Parasites
            Surface(
                color = Color(0xFFF8FAFC),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row {
                        Text("Dosage: ", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = Color(0xFF334155))
                        Text(protocol.dosageGuide, fontSize = 11.sp, color = Color(0xFF0F172A))
                    }
                    Row {
                        Text("Targets: ", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = Color(0xFF334155))
                        Text(protocol.targetParasites, fontSize = 11.sp, color = Color(0xFF64748B))
                    }
                }
            }

            // Instructions
            Text(
                text = protocol.clinicalInstructions,
                fontSize = 11.sp,
                color = Color(0xFF475569),
                lineHeight = 15.sp
            )

            // Warning if present
            if (!protocol.vitalWarning.isNullOrBlank()) {
                Surface(
                    color = if (protocol.isContraindicated) Color(0xFFFEF2F2) else Color(0xFFFFFBEB),
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = null,
                            tint = if (protocol.isContraindicated) Color(0xFFDC2626) else Color(0xFFD97706),
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = protocol.vitalWarning,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = if (protocol.isContraindicated) Color(0xFF991B1B) else Color(0xFF92400E)
                        )
                    }
                }
            }

            // Action button
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                OutlinedButton(
                    onClick = onApply,
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = protocol.accentColor),
                    border = BorderStroke(1.dp, protocol.accentColor),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Icon(Icons.Default.AddCircleOutline, contentDescription = null, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (protocol.isContraindicated) "Review Doe Safety" else "Use Protocol to Record",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
fun AnthelminticRotationGuideCard() {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .clip(CircleShape)
                        .background(Color(0xFFEDE9FE)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Autorenew,
                        contentDescription = null,
                        tint = Color(0xFF7C3AED),
                        modifier = Modifier.size(18.dp)
                    )
                }
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text(
                        text = "Anthelmintic Class Rotation Guide",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = Color(0xFF1E293B)
                    )
                    Text(
                        text = "மருந்து சுழற்சி முறை - புழுக்களின் மருந்து எதிர்ப்பைத் தடுத்தல்",
                        fontSize = 11.sp,
                        color = Color.Gray
                    )
                }
            }

            Text(
                text = "Continuous use of the same anthelmintic chemical causes super-parasites that survive all treatment. Always rotate across these 4 distinct drug classes:",
                fontSize = 11.sp,
                color = Color(0xFF475569)
            )

            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                DewormingScheduleCatalog.anthelminticClasses.forEach { cls ->
                    Surface(
                        color = Color(0xFFF8FAFC),
                        shape = RoundedCornerShape(8.dp),
                        border = BorderStroke(1.dp, Color(0xFFF1F5F9)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(cls.className, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color(0xFF0F172A))
                                Surface(color = Color(0xFFE2E8F0), shape = RoundedCornerShape(4.dp)) {
                                    Text(cls.colorTag, fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color(0xFF475569), modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp))
                                }
                            }
                            Text(cls.tamilName, fontSize = 10.sp, color = Color(0xFF7C3AED), fontWeight = FontWeight.SemiBold)
                            Text("Drugs: ${cls.commonDrugs}", fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFF059669))
                            Text(cls.primaryMode, fontSize = 10.sp, color = Color(0xFF475569))
                            Text(cls.safetyNotes, fontSize = 10.sp, color = Color(0xFF94A3B8), fontWeight = FontWeight.Medium)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun HerdDewormingDueView(
    goats: List<Goat>,
    dewormings: List<DewormingRecord>,
    pregnancies: List<PregnancyRecord>,
    onDewormGoat: (Goat, String, String) -> Unit
) {
    val dateFormat = remember { SimpleDateFormat("yyyy-MM-dd", Locale.US) }
    val today = remember { Date() }

    val latestDewormingMap = remember(dewormings) {
        dewormings.groupBy { it.goat_id_c }.mapValues { (_, list) ->
            list.maxByOrNull { it.treatment_date_c }
        }
    }

    val activePregnancyMap = remember(pregnancies) {
        pregnancies.filter { it.status_c.equals("Confirmed", ignoreCase = true) }
            .associateBy { it.doe_id_c }
    }

    val evaluations = remember(goats, latestDewormingMap, activePregnancyMap) {
        goats.filter { !it.status_c.equals("Deceased", ignoreCase = true) && !it.status_c.equals("Sold", ignoreCase = true) }
            .map { g ->
                val lastDew = latestDewormingMap[g.id]
                val preg = activePregnancyMap[g.id]
                val isPregnant = preg != null || g.status_c.equals("Pregnant", ignoreCase = true)

                var gestationDays: Int? = null
                if (preg != null) {
                    try {
                        val expKidding = dateFormat.parse(preg.expected_kidding_date_c)
                        if (expKidding != null) {
                            val daysUntilKidding = ((expKidding.time - today.time) / (1000 * 60 * 60 * 24)).toInt()
                            gestationDays = (150 - daysUntilKidding).coerceIn(1, 155)
                        }
                    } catch (_: Exception) {}
                }

                DewormingScheduleCatalog.evaluateGoatDeworming(
                    goat = g,
                    lastDewormingDate = lastDew?.treatment_date_c,
                    lastMedicine = lastDew?.medicine_c,
                    isPregnant = isPregnant,
                    gestationDays = gestationDays
                )
            }
    }

    val dueGoats = remember(evaluations) { evaluations.filter { it.isDueNow } }
    val pregnantGoats = remember(evaluations) { evaluations.filter { it.pregnancyRisk.isPregnant } }
    val okGoats = remember(evaluations) { evaluations.filter { !it.isDueNow && !it.pregnancyRisk.isPregnant } }

    var filterMode by remember { mutableStateOf("ALL_DUE") } // ALL_DUE, PREGNANT_CAUTION, KIDS_MILESTONE, ALL_HERD

    val displayList = remember(evaluations, filterMode, dueGoats, pregnantGoats) {
        when (filterMode) {
            "ALL_DUE" -> dueGoats
            "PREGNANT_CAUTION" -> pregnantGoats
            "KIDS_MILESTONE" -> evaluations.filter { (it.ageDays ?: 999) <= 95 }
            else -> evaluations
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                FilterChip(
                    selected = filterMode == "ALL_DUE",
                    onClick = { filterMode = "ALL_DUE" },
                    label = { Text("Due Now (${dueGoats.size})", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = if (dueGoats.isNotEmpty()) Color(0xFFD97706) else FarmGreenDark,
                        selectedLabelColor = Color.White
                    )
                )
                FilterChip(
                    selected = filterMode == "PREGNANT_CAUTION",
                    onClick = { filterMode = "PREGNANT_CAUTION" },
                    label = { Text("Pregnant Does (${pregnantGoats.size})", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = Color(0xFFDC2626),
                        selectedLabelColor = Color.White
                    )
                )
                FilterChip(
                    selected = filterMode == "KIDS_MILESTONE",
                    onClick = { filterMode = "KIDS_MILESTONE" },
                    label = { Text("Kids (0-3m)", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = Color(0xFF0284C7),
                        selectedLabelColor = Color.White
                    )
                )
                FilterChip(
                    selected = filterMode == "ALL_HERD",
                    onClick = { filterMode = "ALL_HERD" },
                    label = { Text("All (${evaluations.size})", fontSize = 11.sp) }
                )
            }
        }

        if (displayList.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = FarmGreenDark, modifier = Modifier.size(44.dp))
                        Text("No animals matching this filter", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text("Herd deworming schedule is currently up to date.", fontSize = 11.sp, color = Color.Gray)
                    }
                }
            }
        } else {
            items(displayList, key = { it.goat.id }) { eval ->
                HerdDewormingItemCard(
                    evaluation = eval,
                    onDeworm = { onDewormGoat(eval.goat, eval.recommendedMedicine, eval.recommendedDose) }
                )
            }
        }

        item {
            Spacer(modifier = Modifier.height(72.dp))
        }
    }
}

@Composable
fun HerdDewormingItemCard(
    evaluation: GoatDewormingEvaluation,
    onDeworm: () -> Unit
) {
    val g = evaluation.goat
    val preg = evaluation.pregnancyRisk

    Card(
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(
            1.dp,
            if (preg.isPregnant && preg.isContraindicated) Color(0xFFFCA5A5)
            else if (evaluation.isDueNow) Color(0xFFFDE68A)
            else Color(0xFFF1F5F9)
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(34.dp)
                            .clip(CircleShape)
                            .background(
                                if (preg.isPregnant && preg.isContraindicated) Color(0xFFFEE2E2)
                                else if (evaluation.isDueNow) Color(0xFFFEF3C7)
                                else Color(0xFFD1FAE5)
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (preg.isPregnant && preg.isContraindicated) Icons.Default.Warning
                            else if (evaluation.isDueNow) Icons.Default.PriorityHigh
                            else Icons.Default.Check,
                            contentDescription = null,
                            tint = if (preg.isPregnant && preg.isContraindicated) Color(0xFFDC2626)
                            else if (evaluation.isDueNow) Color(0xFFD97706)
                            else Color(0xFF059669),
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text("${g.tag_c} - ${g.name}", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text(
                            text = "${g.breed_c} • ${g.sex_c} • ${g.weight_kg_c ?: "--"} kg • ${evaluation.lifeStageLabel}",
                            fontSize = 11.sp,
                            color = Color.Gray
                        )
                    }
                }

                Surface(
                    color = if (preg.isPregnant && preg.isContraindicated) Color(0xFFFEE2E2)
                    else if (evaluation.isDueNow) Color(0xFFFEF3C7)
                    else Color(0xFFF0FDF4),
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text(
                        text = if (preg.isPregnant && preg.isContraindicated) "CONTRAINDICATED"
                        else if (evaluation.isDueNow) "DUE NOW"
                        else "PROTECTED",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (preg.isPregnant && preg.isContraindicated) Color(0xFFDC2626)
                        else if (evaluation.isDueNow) Color(0xFFB45309)
                        else FarmGreenDark,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                    )
                }
            }

            HorizontalDivider(color = Color(0xFFF8FAFC))

            // Reason & Advice
            Text(
                text = evaluation.dueReason,
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold,
                color = if (preg.isPregnant && preg.isContraindicated) Color(0xFFDC2626)
                else if (evaluation.isDueNow) Color(0xFFB45309)
                else Color(0xFF475569)
            )

            // Recommended protocol
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("Rec. Drug: ${evaluation.recommendedMedicine}", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF0F172A))
                    Text("Calculated Dose: ${evaluation.recommendedDose}", fontSize = 10.sp, color = Color.Gray)
                    if (!evaluation.lastTreatmentDate.isNullOrBlank()) {
                        Text("Last Treatment: ${evaluation.lastTreatmentDate} (${evaluation.lastMedicineUsed ?: ""})", fontSize = 10.sp, color = Color.Gray)
                    }
                }

                if (!preg.isPregnant || !preg.isContraindicated) {
                    Button(
                        onClick = onDeworm,
                        colors = ButtonDefaults.buttonColors(containerColor = FarmGreenDark),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                        modifier = Modifier.testTag("btn_deworm_item_${g.tag_c}")
                    ) {
                        Icon(Icons.Default.Medication, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Deworm", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DewormingCalculatorView(
    goats: List<Goat>,
    dewormings: List<DewormingRecord>,
    pregnancies: List<PregnancyRecord>,
    onRecordWithCalculatedData: (goatId: String, medicine: String, dose: String, nextDue: String) -> Unit
) {
    val activeGoats = remember(goats) { goats.filter { !it.status_c.equals("Deceased", ignoreCase = true) } }
    var selectedGoatId by remember { mutableStateOf(activeGoats.firstOrNull()?.id ?: "") }
    var goatDropdownExpanded by remember { mutableStateOf(false) }

    val selectedGoat = remember(selectedGoatId, activeGoats) { activeGoats.find { it.id == selectedGoatId } }

    var customWeightStr by remember(selectedGoat) { mutableStateOf((selectedGoat?.weight_kg_c ?: 25.0).toString()) }
    var isPregnantOverride by remember(selectedGoat) { mutableStateOf(selectedGoat?.status_c.equals("Pregnant", ignoreCase = true)) }
    var gestationDaysStr by remember(selectedGoat) { mutableStateOf("30") }

    val dateFormat = remember { SimpleDateFormat("yyyy-MM-dd", Locale.US) }
    val today = remember { Date() }

    val latestDeworming = remember(selectedGoatId, dewormings) {
        dewormings.filter { it.goat_id_c == selectedGoatId }.maxByOrNull { it.treatment_date_c }
    }

    val activePregnancy = remember(selectedGoatId, pregnancies) {
        pregnancies.find { it.doe_id_c == selectedGoatId && it.status_c.equals("Confirmed", ignoreCase = true) }
    }

    val evaluatedGestationDays = remember(isPregnantOverride, gestationDaysStr, activePregnancy) {
        if (!isPregnantOverride) null
        else {
            if (activePregnancy != null) {
                try {
                    val exp = dateFormat.parse(activePregnancy.expected_kidding_date_c)
                    if (exp != null) {
                        (150 - ((exp.time - today.time) / (1000 * 60 * 60 * 24)).toInt()).coerceIn(1, 155)
                    } else gestationDaysStr.toIntOrNull() ?: 30
                } catch (_: Exception) { gestationDaysStr.toIntOrNull() ?: 30 }
            } else gestationDaysStr.toIntOrNull() ?: 30
        }
    }

    val eval = remember(selectedGoat, customWeightStr, isPregnantOverride, evaluatedGestationDays, latestDeworming) {
        val g = selectedGoat ?: Goat(name = "Sample", tag_c = "G01", weight_kg_c = customWeightStr.toDoubleOrNull() ?: 25.0)
        val goatWithWeight = g.copy(weight_kg_c = customWeightStr.toDoubleOrNull() ?: g.weight_kg_c ?: 25.0)
        DewormingScheduleCatalog.evaluateGoatDeworming(
            goat = goatWithWeight,
            lastDewormingDate = latestDeworming?.treatment_date_c,
            lastMedicine = latestDeworming?.medicine_c,
            isPregnant = isPregnantOverride,
            gestationDays = evaluatedGestationDays
        )
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(12.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "Deworming Schedule & Dose Calculator",
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        color = FarmGreenDark
                    )
                    Text(
                        text = "Calculates exact lifecycle stage, anthelmintic rotation, pregnancy contraindications, and weight-based dose.",
                        fontSize = 11.sp,
                        color = Color.Gray
                    )

                    // Goat selector
                    ExposedDropdownMenuBox(
                        expanded = goatDropdownExpanded,
                        onExpandedChange = { goatDropdownExpanded = !goatDropdownExpanded }
                    ) {
                        OutlinedTextField(
                            value = "${selectedGoat?.tag_c ?: "Select Goat"} - ${selectedGoat?.name ?: ""}",
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Select Goat from Herd") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = goatDropdownExpanded) },
                            modifier = Modifier.fillMaxWidth().menuAnchor()
                        )
                        ExposedDropdownMenu(
                            expanded = goatDropdownExpanded,
                            onDismissRequest = { goatDropdownExpanded = false }
                        ) {
                            activeGoats.forEach { g ->
                                DropdownMenuItem(
                                    text = { Text("${g.tag_c} - ${g.name} (${g.sex_c}, ${g.weight_kg_c ?: "--"} kg)") },
                                    onClick = {
                                        selectedGoatId = g.id
                                        goatDropdownExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    // Weight and Pregnancy Overrides
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = customWeightStr,
                            onValueChange = { customWeightStr = it },
                            label = { Text("Weight (kg)") },
                            modifier = Modifier.weight(1f)
                        )

                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Checkbox(
                                    checked = isPregnantOverride,
                                    onCheckedChange = { isPregnantOverride = it }
                                )
                                Text("Is Pregnant Doe", fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                            }
                            if (isPregnantOverride) {
                                OutlinedTextField(
                                    value = gestationDaysStr,
                                    onValueChange = { gestationDaysStr = it },
                                    label = { Text("Gestation Days") },
                                    placeholder = { Text("e.g. 40") },
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                        }
                    }
                }
            }
        }

        // Live Result Card
        item {
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = if (eval.pregnancyRisk.isPregnant && eval.pregnancyRisk.isContraindicated) Color(0xFFFEF2F2) else Color(0xFFF0FDF4)
                ),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(
                    1.dp,
                    if (eval.pregnancyRisk.isPregnant && eval.pregnancyRisk.isContraindicated) Color(0xFFFCA5A5) else Color(0xFFA7F3D0)
                ),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "ASSESSMENT RESULT",
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            color = if (eval.pregnancyRisk.isPregnant && eval.pregnancyRisk.isContraindicated) Color(0xFF991B1B) else Color(0xFF065F46)
                        )
                        Surface(
                            color = if (eval.pregnancyRisk.isPregnant && eval.pregnancyRisk.isContraindicated) Color(0xFFDC2626) else FarmGreenDark,
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Text(
                                text = eval.lifeStageLabel,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }

                    // Warning if pregnant
                    if (eval.pregnancyRisk.isPregnant) {
                        Text(
                            text = eval.pregnancyRisk.warningMessage,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (eval.pregnancyRisk.isContraindicated) Color(0xFFDC2626) else Color(0xFFB45309),
                            lineHeight = 15.sp
                        )
                    }

                    HorizontalDivider(color = Color.White.copy(alpha = 0.5f))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Animal Age:", fontSize = 11.sp, color = Color.DarkGray)
                        Text(
                            text = if (eval.ageDays != null) "${eval.ageDays} days (~${String.format(Locale.US, "%.1f", eval.ageMonths)} months)" else "Age unknown",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Recommended Drug:", fontSize = 11.sp, color = Color.DarkGray)
                        Text(eval.recommendedMedicine, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF0F172A))
                    }

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Calculated Dosage:", fontSize = 11.sp, color = Color.DarkGray)
                        Text(eval.recommendedDose, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFF059669))
                    }

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Next Booster Interval:", fontSize = 11.sp, color = Color.DarkGray)
                        Text("Every ${eval.recommendedIntervalDays} days", fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                    }

                    if (eval.lastTreatmentDate != null) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Last Treatment:", fontSize = 11.sp, color = Color.DarkGray)
                            Text("${eval.lastTreatmentDate} (${eval.lastMedicineUsed ?: ""})", fontSize = 11.sp, color = Color.Gray)
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    if (!eval.pregnancyRisk.isPregnant || !eval.pregnancyRisk.isContraindicated) {
                        Button(
                            onClick = {
                                val cal = Calendar.getInstance()
                                cal.add(Calendar.DAY_OF_YEAR, eval.recommendedIntervalDays)
                                val nextDue = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(cal.time)
                                onRecordWithCalculatedData(
                                    selectedGoat?.id ?: "",
                                    eval.recommendedMedicine,
                                    eval.recommendedDose,
                                    nextDue
                                )
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = FarmGreenDark),
                            modifier = Modifier.fillMaxWidth().testTag("btn_record_calculated_deworming")
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Record Deworming with this Schedule", fontWeight = FontWeight.Bold)
                        }
                    } else {
                        Button(
                            onClick = {},
                            enabled = false,
                            colors = ButtonDefaults.buttonColors(disabledContainerColor = Color(0xFFFCA5A5), disabledContentColor = Color.White),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Default.Block, contentDescription = null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Deworming Restricted (First 45-60 Days)", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(72.dp))
        }
    }
}
