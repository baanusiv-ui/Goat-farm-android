package com.example.ui.screens.fodder

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.fodder.FodderCultivationTechnique
import com.example.data.fodder.FodderRepository
import com.example.ui.theme.*

@Composable
fun FodderCultivationTechniquesView(
    repository: FodderRepository,
    modifier: Modifier = Modifier
) {
    val techniques = remember { repository.getCultivationTechniques() }
    var searchQuery by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("All") }

    val categories = listOf("All", "Perennial Grass", "Legume Fodder", "Cereal Fodder", "Tree Fodder / Browse")

    val filtered = remember(searchQuery, selectedCategory, techniques) {
        techniques.filter { tech ->
            val matchesCategory = selectedCategory == "All" || tech.category == selectedCategory
            val matchesSearch = tech.cropName.contains(searchQuery, ignoreCase = true) ||
                    tech.scientificName.contains(searchQuery, ignoreCase = true) ||
                    tech.feedingGuidelinesForGoats.contains(searchQuery, ignoreCase = true)
            matchesCategory && matchesSearch
        }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(
                    text = "Fodder Cultivation Technique Database",
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.titleLarge,
                    color = FarmGreenDark
                )
                Text(
                    text = "Agronomic protocols, propagation methods, fertilizer schedules, harvesting stubble heights, and goat nutrition profiles for recommended fodder crops.",
                    fontSize = 12.sp,
                    color = Color.Gray
                )
            }
        }

        // Search Bar
        item {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                label = { Text("Search crop by name, nutrition, or management...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = FarmGreenDark) },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { searchQuery = "" }) {
                            Icon(Icons.Default.Clear, contentDescription = "Clear")
                        }
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("technique_search_input"),
                singleLine = true,
                shape = RoundedCornerShape(12.dp)
            )
        }

        // Category Filter Chips
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                categories.take(3).forEach { cat ->
                    FilterChip(
                        selected = selectedCategory == cat,
                        onClick = { selectedCategory = cat },
                        label = { Text(cat, fontSize = 11.sp) },
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                categories.drop(3).forEach { cat ->
                    FilterChip(
                        selected = selectedCategory == cat,
                        onClick = { selectedCategory = cat },
                        label = { Text(cat, fontSize = 11.sp) },
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        // Techniques List
        items(filtered, key = { it.id }) { tech ->
            TechniqueCard(tech)
        }

        item {
            Spacer(modifier = Modifier.height(48.dp))
        }
    }
}

@Composable
private fun TechniqueCard(tech: FodderCultivationTechnique) {
    var expanded by remember { mutableStateOf(false) }

    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { expanded = !expanded }
            .testTag("technique_card_${tech.id}")
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Header Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = tech.cropName,
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleMedium,
                        color = FarmGreenDark
                    )
                    Text(
                        text = tech.scientificName,
                        style = MaterialTheme.typography.labelSmall,
                        fontStyle = androidx.compose.ui.text.font.FontStyle.Italic,
                        color = Color.Gray
                    )
                }

                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = when (tech.category) {
                        "Legume Fodder" -> Color(0xFFF3E5F5)
                        "Cereal Fodder" -> FarmAmberContainer
                        "Tree Fodder / Browse" -> Color(0xFFE8EAF6)
                        else -> FarmGreenContainer
                    }
                ) {
                    Text(
                        text = tech.category,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = when (tech.category) {
                            "Legume Fodder" -> Color(0xFF7B1FA2)
                            "Cereal Fodder" -> FarmBrown
                            "Tree Fodder / Browse" -> Color(0xFF303F9F)
                            else -> FarmGreenDark
                        },
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Nutritive Badges Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Color(0xFFF1F8E9),
                    modifier = Modifier.weight(1f)
                ) {
                    Column(modifier = Modifier.padding(8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Crude Protein", fontSize = 10.sp, color = Color.Gray)
                        Text("${tech.crudeProteinPct}%", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = FarmGreenDark)
                    }
                }
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Color(0xFFFFF8E1),
                    modifier = Modifier.weight(1f)
                ) {
                    Column(modifier = Modifier.padding(8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Dry Matter", fontSize = 10.sp, color = Color.Gray)
                        Text("${tech.dryMatterPct}%", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = FarmBrown)
                    }
                }
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Color(0xFFE1F5FE),
                    modifier = Modifier.weight(1.2f)
                ) {
                    Column(modifier = Modifier.padding(8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Regrowth Interval", fontSize = 10.sp, color = Color.Gray)
                        Text(tech.regrowthInterval.take(12), fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color(0xFF0277BD))
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Quick Yield & First Cut summary
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("• 1st Cut: ${tech.firstCutDays}", fontSize = 11.sp, color = Color.DarkGray)
                Text("• Yield: ${tech.expectedAnnualYield.take(20)}...", fontSize = 11.sp, color = Color.DarkGray)
            }

            // Expandable Detailed Agronomy Protocol
            AnimatedVisibility(visible = expanded) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    HorizontalDivider(color = Color(0xFFE0E0E0))

                    TechniqueDetailSection(title = "🌱 Land Preparation & Soil", detail = tech.landPreparation + "\n" + tech.soilAndClimate)
                    TechniqueDetailSection(title = "📏 Propagation & Spacing", detail = tech.propagationAndSpacing + "\nSeed/Slip Rate: " + tech.seedOrSlipRate)
                    TechniqueDetailSection(title = "🧪 Fertilizer & Manure Dosage", detail = tech.fertilizerDosage)
                    TechniqueDetailSection(title = "💧 Irrigation Schedule", detail = tech.irrigationSchedule)
                    TechniqueDetailSection(title = "✂️ Harvesting Protocol & Stubble Height", detail = tech.harvestingProtocol)
                    TechniqueDetailSection(title = "🐐 Goat Feeding Guidelines", detail = tech.feedingGuidelinesForGoats)
                    TechniqueDetailSection(title = "🌾 Silage / Preservation Suitability", detail = tech.silageSuitability)
                    TechniqueDetailSection(title = "⚠️ Precautions & Anti-Nutritional Factors", detail = tech.precautionsAndAntiNutritional, isWarning = true)
                }
            }

            // Toggle Expand Button
            Row(
                modifier = Modifier.fillMaxWidth().padding(top = 6.dp),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (expanded) "Show Less" else "Tap for Full Cultivation Protocol",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = FarmGreenDark
                )
                Icon(
                    imageVector = if (expanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                    contentDescription = null,
                    tint = FarmGreenDark,
                    modifier = Modifier.size(16.dp)
                )
            }
        }
    }
}

@Composable
private fun TechniqueDetailSection(title: String, detail: String, isWarning: Boolean = false) {
    Surface(
        shape = RoundedCornerShape(8.dp),
        color = if (isWarning) Color(0xFFFFF3E0) else Color(0xFFF9FBF9),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Text(
                text = title,
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp,
                color = if (isWarning) Color(0xFFE65100) else FarmGreenDark
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = detail,
                fontSize = 11.sp,
                color = Color.DarkGray,
                lineHeight = 15.sp
            )
        }
    }
}
