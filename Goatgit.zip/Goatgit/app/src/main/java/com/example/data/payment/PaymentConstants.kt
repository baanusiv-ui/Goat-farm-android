package com.example.data.payment

object PaymentMethod {
    const val CASH = "CASH"
    const val UPI_QR = "UPI_QR"
    const val PAYTM_GATEWAY = "PAYTM_GATEWAY"
    const val CREDIT = "CREDIT"

    fun normalize(method: String?): String {
        return when (method?.uppercase()?.trim()) {
            "CASH" -> CASH
            "UPI", "UPI_QR", "UPI / QR", "QR" -> UPI_QR
            "PAYTM", "PAYTM_GATEWAY", "GATEWAY" -> PAYTM_GATEWAY
            "CREDIT", "UDHAAR" -> CREDIT
            else -> CASH
        }
    }

    fun displayName(method: String): String {
        return when (normalize(method)) {
            CASH -> "Cash"
            UPI_QR -> "UPI / QR"
            PAYTM_GATEWAY -> "Paytm Gateway"
            CREDIT -> "Credit"
            else -> method
        }
    }
}

object PaymentStatus {
    const val UNPAID = "UNPAID"
    const val PARTIALLY_PAID = "PARTIALLY_PAID"
    const val PAID = "PAID"
    const val PENDING = "PENDING"
    const val FAILED = "FAILED"
    const val CANCELLED = "CANCELLED"
    const val REFUNDED = "REFUNDED"

    fun normalize(status: String?): String {
        return when (status?.uppercase()?.trim()) {
            "PAID", "RECEIVED", "SUCCESS", "TXN_SUCCESS" -> PAID
            "PARTIALLY_PAID", "PARTIALLY PAID", "PARTIAL" -> PARTIALLY_PAID
            "UNPAID", "CREDIT" -> UNPAID
            "PENDING" -> PENDING
            "FAILED", "TXN_FAILURE", "ERROR" -> FAILED
            "CANCELLED", "CANCELED" -> CANCELLED
            "REFUNDED" -> REFUNDED
            else -> PENDING
        }
    }

    fun isPaid(status: String?): Boolean {
        return normalize(status) == PAID
    }
}

object SaleType {
    const val PIECE = "PIECE"
    const val WEIGHT = "WEIGHT"

    fun normalize(type: String?): String {
        return if (type?.uppercase()?.trim() == "WEIGHT") WEIGHT else PIECE
    }
}

object DeliveryStatus {
    const val EXPECTED = "EXPECTED"
    const val READY = "READY"
    const val DISPATCHED = "DISPATCHED"
    const val DELIVERED = "DELIVERED"

    fun normalize(status: String?): String {
        return when (status?.uppercase()?.trim()) {
            "READY" -> READY
            "DISPATCHED" -> DISPATCHED
            "DELIVERED" -> DELIVERED
            else -> EXPECTED
        }
    }

    fun isDelivered(status: String?): Boolean {
        return normalize(status) == DELIVERED
    }
}

object PaymentSource {
    const val MANUAL = "MANUAL"
    const val SMS = "SMS"
    const val PAYTM_GATEWAY = "PAYTM_GATEWAY"
}
