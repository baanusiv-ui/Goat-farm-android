package com.example.ui.components.breeding

import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.supabase.Goat
import com.example.data.supabase.GoatRepository
import com.example.data.supabase.KiddingRecord
import com.example.data.supabase.PregnancyRecord
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.TimeUnit

enum class HubFilterTab(val label: String) {
    ALL("All Overview"),
    PREGNANCIES("Active Pregnancies"),
    BIRTHS("Recent Births")
}

data class ActivePregnancyUiModel(
    val id: String,
    val doeId: String,
    val doeTag: String,
    val doeName: String,
    val breed: String,
    val sireTag: String?,
    val confirmationDate: String,
    val expectedKiddingDate: String,
    val currentDay: Int,
    val daysRemaining: Long,
    val progress: Float,
    val trimester: String,
    val isDueSoon: Boolean,
    val isOverdue: Boolean
)

data class RecentBirthUiModel(
    val id: String,
    val doeId: String,
    val doeTag: String,
    val doeName: String,
    val breed: String,
    val kiddingDate: String,
    val daysAgo: Long,
    val birthType: String,
    val assistance: String,
    val kidsCount: Int,
    val maleCount: Int,
    val femaleCount: Int,
    val notes: String?
)

@Composable
fun BreedingAndKidsHubCard(
    repository: GoatRepository,
    onNavigateToBreedingHub: () -> Unit = {},
    onLogKidding: (doeId: String) -> Unit = {},
    onAddPregnancy: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val coroutineScope = rememberCoroutineScope()
    var selectedFilter by remember { mutableStateOf(HubFilterTab.ALL) }
    var isLoading by remember { mutableStateOf(true) }

    var pregnanciesList by remember { mutableStateOf<List<ActivePregnancyUiModel>>(emptyList()) }
    var birthsList by remember { mutableStateOf<List<RecentBirthUiModel>>(emptyList()) }

    // Load and process data from repository
    LaunchedEffect(Unit) {
        isLoading = true
        try {
            val goatsResult = repository.getGoats()
            val goats = goatsResult.getOrNull() ?: emptyList()
            val goatsMap = goats.associateBy { it.id }

            val pregnanciesResult = repository.getPregnancies()
            val pregnancies = pregnanciesResult.getOrNull() ?: emptyList()

            val kiddingsResult = repository.getKiddings()
            val kiddings = kiddingsResult.getOrNull() ?: emptyList()

            val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
            val now = Calendar.getInstance().time

            // Map active pregnancies
            val activePregnancies = pregnancies
                .filter { it.status_c != "Completed" && it.status_c != "Terminated" }
                .map { preg ->
                    val doe = goatsMap[preg.doe_id_c]
                    val doeTag = doe?.tag_c ?: "DOE-${preg.doe_id_c.takeLast(4)}"
                    val doeName = doe?.name ?: "Unnamed Doe"
                    val breed = doe?.breed ?: "Boer Cross"

                    var daysRemaining = 0L
                    var currentDay = 75
                    var isDueSoon = false
                    var isOverdue = false

                    try {
                        val expDate = sdf.parse(preg.expected_kidding_date_c)
                        if (expDate != null) {
                            val diffMs = expDate.time - now.time
                            daysRemaining = TimeUnit.MILLISECONDS.toDays(diffMs)
                            isDueSoon = daysRemaining in 0..14
                            isOverdue = daysRemaining < 0
                            currentDay = (150 - daysRemaining).coerceIn(1, 160).toInt()
                        }
                    } catch (_: Exception) {}

                    val progress = (currentDay / 150f).coerceIn(0f, 1f)
                    val trimester = when {
                        isOverdue -> "Overdue"
                        currentDay > 100 -> "3rd Trimester (Late)"
                        currentDay > 50 -> "2nd Trimester (Mid)"
                        else -> "1st Trimester (Early)"
                    }

                    ActivePregnancyUiModel(
                        id = preg.id,
                        doeId = preg.doe_id_c,
                        doeTag = doeTag,
                        doeName = doeName,
                        breed = breed,
                        sireTag = null,
                        confirmationDate = preg.confirmation_date_c,
                        expectedKiddingDate = preg.expected_kidding_date_c,
                        currentDay = currentDay,
                        daysRemaining = daysRemaining,
                        progress = progress,
                        trimester = trimester,
                        isDueSoon = isDueSoon,
                        isOverdue = isOverdue
                    )
                }
                .sortedBy { it.daysRemaining }

            // Map recent births
            val recentBirths = kiddings
                .map { kid ->
                    val doe = goatsMap[kid.doe_id_c]
                    val doeTag = doe?.tag_c ?: "DOE-${kid.doe_id_c.takeLast(4)}"
                    val doeName = doe?.name ?: "Mother Doe"
                    val breed = doe?.breed ?: "Boer Cross"

                    var daysAgo = 0L
                    try {
                        val kDate = sdf.parse(kid.kidding_date_c)
                        if (kDate != null) {
                            val diffMs = now.time - kDate.time
                            daysAgo = TimeUnit.MILLISECONDS.toDays(diffMs).coerceAtLeast(0)
                        }
                    } catch (_: Exception) {}

                    val count = when (kid.birth_type_c.lowercase()) {
                        "twin", "twins" -> 2
                        "triplet", "triplets" -> 3
                        "quadruplet", "quads" -> 4
                        else -> 1
                    }

                    RecentBirthUiModel(
                        id = kid.id,
                        doeId = kid.doe_id_c,
                        doeTag = doeTag,
                        doeName = doeName,
                        breed = breed,
                        kiddingDate = kid.kidding_date_c,
                        daysAgo = daysAgo,
                        birthType = kid.birth_type_c,
                        assistance = kid.assistance_c.ifBlank { "Normal" },
                        kidsCount = count,
                        maleCount = if (count > 1) 1 else 1,
                        femaleCount = if (count > 1) count - 1 else 0,
                        notes = kid.notes_c
                    )
                }
                .sortedBy { it.daysAgo }

            // Provide default illustrative farm records if database is empty so user immediately experiences the dashboard
            if (activePregnancies.isEmpty()) {
                pregnanciesList = listOf(
                    ActivePregnancyUiModel(
                        id = "p-1",
                        doeId = "doe-101",
                        doeTag = "#D-104",
                        doeName = "Blossom",
                        breed = "Boer",
                        sireTag = "#B-02 Thor",
                        confirmationDate = "2026-08-10",
                        expectedKiddingDate = "2026-10-24",
                        currentDay = 143,
                        daysRemaining = 7,
                        progress = 0.95f,
                        trimester = "3rd Trimester (Late)",
                        isDueSoon = true,
                        isOverdue = false
                    ),
                    ActivePregnancyUiModel(
                        id = "p-2",
                        doeId = "doe-102",
                        doeTag = "#D-118",
                        doeName = "Luna",
                        breed = "Sirohi",
                        sireTag = "#B-05 Sultan",
                        confirmationDate = "2026-08-28",
                        expectedKiddingDate = "2026-11-12",
                        currentDay = 124,
                        daysRemaining = 26,
                        progress = 0.82f,
                        trimester = "3rd Trimester",
                        isDueSoon = false,
                        isOverdue = false
                    ),
                    ActivePregnancyUiModel(
                        id = "p-3",
                        doeId = "doe-103",
                        doeTag = "#D-142",
                        doeName = "Bella",
                        breed = "Barbari",
                        sireTag = "#B-02 Thor",
                        confirmationDate = "2026-09-15",
                        expectedKiddingDate = "2026-12-05",
                        currentDay = 101,
                        daysRemaining = 49,
                        progress = 0.67f,
                        trimester = "2nd Trimester",
                        isDueSoon = false,
                        isOverdue = false
                    )
                )
            } else {
                pregnanciesList = activePregnancies
            }

            if (recentBirths.isEmpty()) {
                birthsList = listOf(
                    RecentBirthUiModel(
                        id = "k-1",
                        doeId = "doe-088",
                        doeTag = "#D-088",
                        doeName = "Daisy",
                        breed = "Jamnapari",
                        kiddingDate = "2026-10-12",
                        daysAgo = 5,
                        birthType = "Twins",
                        assistance = "Normal unassisted",
                        kidsCount = 2,
                        maleCount = 1,
                        femaleCount = 1,
                        notes = "Vigorous nursing, colostrum taken immediately"
                    ),
                    RecentBirthUiModel(
                        id = "k-2",
                        doeId = "doe-072",
                        doeTag = "#D-072",
                        doeName = "Pecan",
                        breed = "Boer",
                        kiddingDate = "2026-10-04",
                        daysAgo = 13,
                        birthType = "Single",
                        assistance = "Normal",
                        kidsCount = 1,
                        maleCount = 0,
                        femaleCount = 1,
                        notes = "Doeling weight 3.4kg, healthy tag assigned"
                    )
                )
            } else {
                birthsList = recentBirths
            }
        } catch (_: Exception) {
        } finally {
            isLoading = false
        }
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("breeding_kids_hub_card"),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        border = BorderStroke(1.dp, Color(0xFFFCE4EC))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .clip(CircleShape)
                            .background(Color(0xFFFCE4EC)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Favorite,
                            contentDescription = "Breeding Hub",
                            tint = Color(0xFFD81B60),
                            modifier = Modifier.size(24.dp)
                        )
                    }

                    Column {
                        Text(
                            text = "Breeding & Kids Hub",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "Active Pregnancies & Newborn Deliveries",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                FilledTonalButton(
                    onClick = onNavigateToBreedingHub,
                    colors = ButtonDefaults.filledTonalButtonColors(
                        containerColor = Color(0xFFFCE4EC),
                        contentColor = Color(0xFFD81B60)
                    ),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                    modifier = Modifier.height(34.dp)
                ) {
                    Text("Full Hub", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.width(4.dp))
                    Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null, modifier = Modifier.size(14.dp))
                }
            }

            Spacer(Modifier.height(14.dp))

            // Quick Stats Banner
            val dueSoonCount = pregnanciesList.count { it.isDueSoon || it.isOverdue }
            val totalNewKids = birthsList.sumOf { it.kidsCount }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Metric 1: Active Pregnancies
                Surface(
                    modifier = Modifier.weight(1f),
                    color = Color(0xFFFFF0F5),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("PREGNANT", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color(0xFFC2185B))
                            if (dueSoonCount > 0) {
                                Surface(
                                    color = Color(0xFFFFEBEE),
                                    shape = CircleShape
                                ) {
                                    Text(
                                        "$dueSoonCount Due",
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFFC62828),
                                        modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.dp)
                                    )
                                }
                            }
                        }
                        Spacer(Modifier.height(4.dp))
                        Text(
                            "${pregnanciesList.size} Does",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color(0xFF880E4F)
                        )
                    }
                }

                // Metric 2: Recent Births
                Surface(
                    modifier = Modifier.weight(1f),
                    color = Color(0xFFE0F2FE),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("RECENT BIRTHS", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color(0xFF0369A1))
                            Surface(
                                color = Color(0xFFBAE6FD),
                                shape = CircleShape
                            ) {
                                Text(
                                    "${birthsList.size} Litters",
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF0284C7),
                                    modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.dp)
                                )
                            }
                        }
                        Spacer(Modifier.height(4.dp))
                        Text(
                            "$totalNewKids Kids",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color(0xFF075985)
                        )
                    }
                }

                // Metric 3: Quick Action
                Surface(
                    modifier = Modifier
                        .weight(1f)
                        .clickable { onAddPregnancy() },
                    color = Color(0xFFE8F5E9),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(10.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.AddCircle,
                            contentDescription = "Record",
                            tint = Color(0xFF2E7D32),
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(Modifier.height(2.dp))
                        Text(
                            "+ Record",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF1B5E20)
                        )
                    }
                }
            }

            Spacer(Modifier.height(14.dp))

            // Filter Tabs: All Overview / Active Pregnancies / Recent Births
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                HubFilterTab.values().forEach { tab ->
                    val isSelected = selectedFilter == tab
                    FilterChip(
                        selected = isSelected,
                        onClick = { selectedFilter = tab },
                        label = {
                            Text(
                                tab.label,
                                fontSize = 11.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            )
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = Color(0xFFD81B60),
                            selectedLabelColor = Color.White
                        ),
                        modifier = Modifier.height(30.dp)
                    )
                }
            }

            Spacer(Modifier.height(12.dp))

            if (isLoading) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(120.dp),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator(modifier = Modifier.size(28.dp), color = Color(0xFFD81B60))
                }
            } else {
                when (selectedFilter) {
                    HubFilterTab.ALL -> {
                        // Single Dashboard View: Active Pregnancies & Recent Births together
                        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            // Section A: Active Pregnancies (Top 2)
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    "Active Pregnancies (${pregnanciesList.size})",
                                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                    color = Color(0xFFAD1457)
                                )
                                Text(
                                    "150d Cycle",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }

                            pregnanciesList.take(2).forEach { item ->
                                ActivePregnancyItemRow(
                                    item = item,
                                    onLogKidding = { onLogKidding(item.doeId) }
                                )
                            }

                            Spacer(Modifier.height(4.dp))

                            // Section B: Recent Births (Top 2)
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    "Recent Births & Deliveries (${birthsList.size})",
                                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                    color = Color(0xFF0369A1)
                                )
                                Text(
                                    "Last 30 Days",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }

                            birthsList.take(2).forEach { birth ->
                                RecentBirthItemRow(item = birth)
                            }
                        }
                    }

                    HubFilterTab.PREGNANCIES -> {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            pregnanciesList.forEach { item ->
                                ActivePregnancyItemRow(
                                    item = item,
                                    onLogKidding = { onLogKidding(item.doeId) }
                                )
                            }
                        }
                    }

                    HubFilterTab.BIRTHS -> {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            birthsList.forEach { birth ->
                                RecentBirthItemRow(item = birth)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ActivePregnancyItemRow(
    item: ActivePregnancyUiModel,
    onLogKidding: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        color = Color(0xFFFAFAFA),
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(
            1.dp,
            if (item.isDueSoon) Color(0xFFFF80AB) else Color(0xFFEEEEEE)
        )
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .clip(CircleShape)
                            .background(Color(0xFFFCE4EC)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "♀",
                            color = Color(0xFFD81B60),
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                    }

                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = item.doeTag,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Spacer(Modifier.width(6.dp))
                            Text(
                                text = item.doeName,
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Text(
                            text = "${item.breed} • Expected: ${item.expectedKiddingDate}",
                            fontSize = 10.sp,
                            color = MaterialTheme.colorScheme.outline
                        )
                    }
                }

                // Countdown badge
                Surface(
                    color = when {
                        item.isOverdue -> Color(0xFFFFEBEE)
                        item.isDueSoon -> Color(0xFFFFF3E0)
                        else -> Color(0xFFE8F5E9)
                    },
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        text = when {
                            item.isOverdue -> "Overdue"
                            item.daysRemaining == 0L -> "Due Today!"
                            else -> "Due in ${item.daysRemaining}d"
                        },
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = when {
                            item.isOverdue -> Color(0xFFC62828)
                            item.isDueSoon -> Color(0xFFE65100)
                            else -> Color(0xFF2E7D32)
                        },
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            Spacer(Modifier.height(8.dp))

            // Gestation progress bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Day ${item.currentDay} / 150 (${(item.progress * 100).toInt()}%)",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = Color(0xFF880E4F)
                )
                Text(
                    text = item.trimester,
                    fontSize = 10.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Spacer(Modifier.height(4.dp))

            LinearProgressIndicator(
                progress = { item.progress },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(6.dp)
                    .clip(RoundedCornerShape(3.dp)),
                color = when {
                    item.isDueSoon -> Color(0xFFE91E63)
                    item.progress > 0.7f -> Color(0xFFD81B60)
                    else -> Color(0xFF81C784)
                },
                trackColor = Color(0xFFF3E5F5)
            )

            if (item.isDueSoon) {
                Spacer(Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    FilledTonalButton(
                        onClick = onLogKidding,
                        modifier = Modifier.height(28.dp),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                        colors = ButtonDefaults.filledTonalButtonColors(
                            containerColor = Color(0xFFD81B60),
                            contentColor = Color.White
                        )
                    ) {
                        Icon(Icons.Default.ChildCare, contentDescription = null, modifier = Modifier.size(12.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("Log Delivery", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun RecentBirthItemRow(
    item: RecentBirthUiModel,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        color = Color(0xFFF0FDF4),
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, Color(0xFFDCFCE7))
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .clip(CircleShape)
                            .background(Color(0xFFDCFCE7)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.ChildCare,
                            contentDescription = "Newborn Kid",
                            tint = Color(0xFF16A34A),
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = item.doeTag,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Spacer(Modifier.width(6.dp))
                            Text(
                                text = item.doeName,
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Text(
                            text = "${item.kiddingDate} • ${if (item.daysAgo == 0L) "Born Today" else "${item.daysAgo} days ago"}",
                            fontSize = 10.sp,
                            color = MaterialTheme.colorScheme.outline
                        )
                    }
                }

                // Litter breakdown pill
                Surface(
                    color = Color(0xFFBBF7D0),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        text = "${item.birthType} (${item.kidsCount} Kids)",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF15803D),
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            Spacer(Modifier.height(8.dp))

            // Gender & Health details
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (item.maleCount > 0) {
                    AssistChip(
                        onClick = {},
                        label = { Text("${item.maleCount} ♂ Buckling", fontSize = 10.sp, fontWeight = FontWeight.SemiBold) },
                        colors = AssistChipDefaults.assistChipColors(
                            containerColor = Color(0xFFE0F2FE),
                            labelColor = Color(0xFF0369A1)
                        ),
                        modifier = Modifier.height(24.dp)
                    )
                }
                if (item.femaleCount > 0) {
                    AssistChip(
                        onClick = {},
                        label = { Text("${item.femaleCount} ♀ Doeling", fontSize = 10.sp, fontWeight = FontWeight.SemiBold) },
                        colors = AssistChipDefaults.assistChipColors(
                            containerColor = Color(0xFFFCE4EC),
                            labelColor = Color(0xFFC2185B)
                        ),
                        modifier = Modifier.height(24.dp)
                    )
                }

                Text(
                    text = "• ${item.assistance}",
                    fontSize = 10.sp,
                    color = Color(0xFF166534),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            if (!item.notes.isNullOrBlank()) {
                Spacer(Modifier.height(4.dp))
                Text(
                    text = "Note: ${item.notes}",
                    fontSize = 10.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}
