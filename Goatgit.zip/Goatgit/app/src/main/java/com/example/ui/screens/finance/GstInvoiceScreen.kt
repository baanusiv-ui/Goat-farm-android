package com.example.ui.screens.finance

import android.content.Intent
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.supabase.*
import com.example.ui.components.DatePickerField
import com.example.ui.theme.*
import com.example.util.CurrencyUtils
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GstInvoiceScreen(
    repository: GoatRepository,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler { onNavigateBack() }

    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val dateFormat = remember { SimpleDateFormat("yyyy-MM-dd", Locale.US) }
    val today = remember { dateFormat.format(Date()) }

    var gstSettings by remember { mutableStateOf(GstSettings()) }
    var sales by remember { mutableStateOf<List<SaleRecord>>(emptyList()) }
    var customers by remember { mutableStateOf<List<CustomerRecord>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }

    var showConfigDialog by remember { mutableStateOf(false) }
    var showNewInvoiceDialog by remember { mutableStateOf(false) }
    var previewInvoiceData by remember { mutableStateOf<GstInvoicePreviewData?>(null) }

    fun loadData() {
        isLoading = true
        coroutineScope.launch {
            val setRes = repository.finance.getGstSettings()
            if (setRes.isSuccess) gstSettings = setRes.getOrThrow()

            val salesRes = repository.getSales()
            if (salesRes.isSuccess) sales = salesRes.getOrThrow()

            val custRes = repository.getCustomers()
            if (custRes.isSuccess) customers = custRes.getOrThrow()

            isLoading = false
        }
    }

    LaunchedEffect(Unit) {
        loadData()
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "GST Invoicing",
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp
                        )
                        Text(
                            text = "Tax Invoices, CGST / SGST & IGST Compliant",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack, modifier = Modifier.testTag("gst_btn_back")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(onClick = { showConfigDialog = true }, modifier = Modifier.testTag("gst_btn_config")) {
                        Icon(Icons.Default.Settings, contentDescription = "GST Settings")
                    }
                    IconButton(onClick = { loadData() }, modifier = Modifier.testTag("gst_btn_refresh")) {
                        Icon(Icons.Default.Refresh, contentDescription = "Refresh")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.White)
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { showNewInvoiceDialog = true },
                containerColor = FarmGreenDark,
                contentColor = Color.White,
                icon = { Icon(Icons.Default.ReceiptLong, contentDescription = null) },
                text = { Text("Generate GST Invoice", fontWeight = FontWeight.Bold) },
                modifier = Modifier.testTag("btn_generate_gst_invoice")
            )
        },
        containerColor = Color(0xFFF8F9FA),
        modifier = modifier
    ) { innerPadding ->
        if (isLoading) {
            Box(modifier = Modifier.fillMaxSize().padding(innerPadding), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = FarmGreenDark)
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                item { Spacer(modifier = Modifier.height(4.dp)) }

                // GST Configuration Status Banner
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = if (gstSettings.gst_enabled) Color(0xFFE8F5E9) else Color(0xFFFFF3E0)),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth().testTag("gst_status_card")
                    ) {
                        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = if (gstSettings.gst_enabled) Icons.Default.CheckCircle else Icons.Default.Warning,
                                        contentDescription = null,
                                        tint = if (gstSettings.gst_enabled) FarmGreenDark else Color(0xFFE65100),
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = if (gstSettings.gst_enabled) "GST Enabled (Tax Invoices Active)" else "GST Disabled (Exempt Farm Sales)",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp,
                                        color = if (gstSettings.gst_enabled) FarmGreenDark else Color(0xFFE65100)
                                    )
                                }
                                TextButton(onClick = { showConfigDialog = true }) {
                                    Text("Configure", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                            if (gstSettings.gst_enabled) {
                                Text("Business: ${gstSettings.business_name} • GSTIN: ${gstSettings.gstin.ifBlank { "Unset" }}", fontSize = 12.sp, color = Color.DarkGray)
                                Text("State: ${gstSettings.state_name} (Code: ${gstSettings.state_code}) • Default HSN: ${gstSettings.default_hsn} (${gstSettings.default_tax_rate}%)", fontSize = 11.sp, color = Color.Gray)
                            }
                        }
                    }
                }

                item {
                    Text("Farm Sales Invoices", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = FarmGreenDark)
                }

                if (sales.isEmpty()) {
                    item {
                        Card(colors = CardDefaults.cardColors(containerColor = Color.White), modifier = Modifier.fillMaxWidth().padding(vertical = 16.dp)) {
                            Box(modifier = Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                                Text("No sales recorded yet. Tap 'Generate GST Invoice' to create an official tax invoice.", color = Color.Gray, fontSize = 13.sp)
                            }
                        }
                    }
                } else {
                    items(sales) { sale ->
                        GstSaleItemCard(
                            sale = sale,
                            gstSettings = gstSettings,
                            onPreview = {
                                val isInterState = !sale.buyer_address_c.contains(gstSettings.state_name, ignoreCase = true) && sale.buyer_address_c.isNotBlank()
                                val breakdown = repository.finance.calculateGstBreakdown(
                                    taxableValue = sale.amount_c,
                                    gstRate = gstSettings.default_tax_rate,
                                    isInterState = isInterState
                                )
                                previewInvoiceData = GstInvoicePreviewData(
                                    invoiceNumber = "${gstSettings.invoice_prefix}-${sale.id.takeLast(6).uppercase()}",
                                    invoiceDate = sale.sale_date_c,
                                    buyerName = sale.buyer_name_c.ifBlank { "Walk-in Buyer" },
                                    buyerAddress = sale.buyer_address_c.ifBlank { "Local Farm Gate" },
                                    buyerGstin = "",
                                    itemDescription = "Live Goat Sale (${if (sale.sale_type_c == "WEIGHT") "${sale.total_weight_kg_c} kg" else "${sale.quantity_c} pcs"})",
                                    hsn = gstSettings.default_hsn,
                                    breakdown = breakdown,
                                    gstSettings = gstSettings
                                )
                            }
                        )
                    }
                }

                item { Spacer(modifier = Modifier.height(72.dp)) }
            }
        }
    }

    // Config GST Dialog
    if (showConfigDialog) {
        GstSettingsDialog(
            currentSettings = gstSettings,
            onDismiss = { showConfigDialog = false },
            onSave = { updated ->
                showConfigDialog = false
                coroutineScope.launch {
                    val res = repository.finance.saveGstSettings(updated)
                    if (res.isSuccess) {
                        Toast.makeText(context, "GST settings saved", Toast.LENGTH_SHORT).show()
                        loadData()
                    }
                }
            }
        )
    }

    // New GST Invoice Dialog
    if (showNewInvoiceDialog) {
        CreateGstInvoiceDialog(
            gstSettings = gstSettings,
            customers = customers,
            onDismiss = { showNewInvoiceDialog = false },
            onGenerate = { previewData ->
                showNewInvoiceDialog = false
                previewInvoiceData = previewData
            }
        )
    }

    // Invoice Preview & Print Dialog
    if (previewInvoiceData != null) {
        GstInvoicePreviewDialog(
            data = previewInvoiceData!!,
            onDismiss = { previewInvoiceData = null },
            onShare = {
                val shareText = buildString {
                    appendLine("TAX INVOICE - ${previewInvoiceData!!.gstSettings.business_name}")
                    appendLine("GSTIN: ${previewInvoiceData!!.gstSettings.gstin}")
                    appendLine("Invoice No: ${previewInvoiceData!!.invoiceNumber} | Date: ${previewInvoiceData!!.invoiceDate}")
                    appendLine("Customer: ${previewInvoiceData!!.buyerName}")
                    appendLine("Item: ${previewInvoiceData!!.itemDescription} | HSN: ${previewInvoiceData!!.hsn}")
                    appendLine("Taxable Value: ₹${previewInvoiceData!!.breakdown.taxableValue}")
                    if (previewInvoiceData!!.breakdown.isInterState) {
                        appendLine("IGST (${previewInvoiceData!!.breakdown.igstRate}%): ₹${previewInvoiceData!!.breakdown.igstAmount}")
                    } else {
                        appendLine("CGST (${previewInvoiceData!!.breakdown.cgstRate}%): ₹${previewInvoiceData!!.breakdown.cgstAmount}")
                        appendLine("SGST (${previewInvoiceData!!.breakdown.sgstRate}%): ₹${previewInvoiceData!!.breakdown.sgstAmount}")
                    }
                    appendLine("Grand Total: ₹${previewInvoiceData!!.breakdown.grandTotal}")
                }
                val intent = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_SUBJECT, "Tax Invoice ${previewInvoiceData!!.invoiceNumber}")
                    putExtra(Intent.EXTRA_TEXT, shareText)
                }
                context.startActivity(Intent.createChooser(intent, "Share Tax Invoice"))
            }
        )
    }
}

data class GstInvoicePreviewData(
    val invoiceNumber: String,
    val invoiceDate: String,
    val buyerName: String,
    val buyerAddress: String,
    val buyerGstin: String,
    val itemDescription: String,
    val hsn: String,
    val breakdown: GstTaxBreakdown,
    val gstSettings: GstSettings
)

@Composable
private fun GstSaleItemCard(
    sale: SaleRecord,
    gstSettings: GstSettings,
    onPreview: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier.fillMaxWidth().testTag("gst_sale_card_${sale.id}")
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(sale.buyer_name_c.ifBlank { "Buyer" }, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Text("${sale.sale_date_c} • ${sale.sale_type_c}", fontSize = 11.sp, color = Color.Gray)
                Text("Amount: ${CurrencyUtils.formatInr(sale.amount_c)}", fontSize = 12.sp, color = FarmGreenDark, fontWeight = FontWeight.SemiBold)
            }

            Button(
                onClick = onPreview,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E3A8A)),
                shape = RoundedCornerShape(8.dp),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                modifier = Modifier.height(32.dp).testTag("btn_view_gst_invoice_${sale.id}")
            ) {
                Text("GST Invoice", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun GstSettingsDialog(
    currentSettings: GstSettings,
    onDismiss: () -> Unit,
    onSave: (GstSettings) -> Unit
) {
    var enabled by remember { mutableStateOf(currentSettings.gst_enabled) }
    var busName by remember { mutableStateOf(currentSettings.business_name) }
    var busAddr by remember { mutableStateOf(currentSettings.business_address) }
    var gstin by remember { mutableStateOf(currentSettings.gstin) }
    var state by remember { mutableStateOf(currentSettings.state_name) }
    var stateCode by remember { mutableStateOf(currentSettings.state_code) }
    var prefix by remember { mutableStateOf(currentSettings.invoice_prefix) }
    var hsn by remember { mutableStateOf(currentSettings.default_hsn) }
    var taxRateStr by remember { mutableStateOf(currentSettings.default_tax_rate.toString()) }

    Dialog(onDismissRequest = onDismiss) {
        Surface(shape = RoundedCornerShape(16.dp), color = Color.White, modifier = Modifier.fillMaxWidth().fillMaxHeight(0.9f)) {
            Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("GST Invoicing Configuration", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = FarmGreenDark)

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("Enable GST Invoicing", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                    Switch(checked = enabled, onCheckedChange = { enabled = it }, modifier = Modifier.testTag("switch_gst_enable"))
                }

                LazyColumn(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    item {
                        OutlinedTextField(value = busName, onValueChange = { busName = it }, label = { Text("Business / Farm Name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    }
                    item {
                        OutlinedTextField(value = busAddr, onValueChange = { busAddr = it }, label = { Text("Business Address") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    }
                    item {
                        OutlinedTextField(value = gstin, onValueChange = { gstin = it }, label = { Text("Farm GSTIN (15 Digits)") }, singleLine = true, modifier = Modifier.fillMaxWidth().testTag("input_farm_gstin"))
                    }
                    item {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(value = state, onValueChange = { state = it }, label = { Text("Home State") }, modifier = Modifier.weight(1.3f))
                            OutlinedTextField(value = stateCode, onValueChange = { stateCode = it }, label = { Text("Code") }, modifier = Modifier.weight(0.7f))
                        }
                    }
                    item {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(value = prefix, onValueChange = { prefix = it }, label = { Text("Prefix") }, modifier = Modifier.weight(1f))
                            OutlinedTextField(value = hsn, onValueChange = { hsn = it }, label = { Text("HSN Code") }, modifier = Modifier.weight(1f))
                            OutlinedTextField(value = taxRateStr, onValueChange = { taxRateStr = it }, label = { Text("Tax %") }, modifier = Modifier.weight(1f))
                        }
                    }
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    TextButton(onClick = onDismiss) { Text("Cancel") }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            val updated = currentSettings.copy(
                                gst_enabled = enabled,
                                business_name = busName.trim(),
                                business_address = busAddr.trim(),
                                gstin = gstin.trim(),
                                state_name = state.trim(),
                                state_code = stateCode.trim(),
                                invoice_prefix = prefix.trim(),
                                default_hsn = hsn.trim(),
                                default_tax_rate = taxRateStr.toDoubleOrNull() ?: 5.0,
                                updated_at = System.currentTimeMillis()
                            )
                            onSave(updated)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = FarmGreenDark),
                        modifier = Modifier.testTag("btn_save_gst_config")
                    ) {
                        Text("Save Settings")
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun CreateGstInvoiceDialog(
    gstSettings: GstSettings,
    customers: List<CustomerRecord>,
    onDismiss: () -> Unit,
    onGenerate: (GstInvoicePreviewData) -> Unit
) {
    var buyerName by remember { mutableStateOf("") }
    var buyerAddress by remember { mutableStateOf("") }
    var buyerGstin by remember { mutableStateOf("") }
    var isInterState by remember { mutableStateOf(false) }
    var itemDesc by remember { mutableStateOf("Live Goat / Breeding Stock") }
    var hsn by remember { mutableStateOf(gstSettings.default_hsn) }
    var taxableStr by remember { mutableStateOf("15000") }
    var gstRateStr by remember { mutableStateOf(gstSettings.default_tax_rate.toString()) }

    val taxable = taxableStr.toDoubleOrNull() ?: 0.0
    val gstRate = gstRateStr.toDoubleOrNull() ?: 5.0
    val breakdown = remember(taxable, gstRate, isInterState) {
        GstTaxBreakdown(taxableValue = taxable, gstRate = gstRate, isInterState = isInterState)
    }

    Dialog(onDismissRequest = onDismiss) {
        Surface(shape = RoundedCornerShape(16.dp), color = Color.White, modifier = Modifier.fillMaxWidth().fillMaxHeight(0.9f)) {
            Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Generate GST Tax Invoice", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = FarmGreenDark)

                LazyColumn(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    item {
                        OutlinedTextField(value = buyerName, onValueChange = { buyerName = it }, label = { Text("Buyer Name *") }, singleLine = true, modifier = Modifier.fillMaxWidth().testTag("input_gst_buyer_name"))
                    }
                    item {
                        OutlinedTextField(value = buyerAddress, onValueChange = { buyerAddress = it }, label = { Text("Buyer Address") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    }
                    item {
                        OutlinedTextField(value = buyerGstin, onValueChange = { buyerGstin = it }, label = { Text("Buyer GSTIN (if registered B2B)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    }
                    item {
                        // Intra-state vs Inter-state selector
                        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFF1F8E9)), modifier = Modifier.fillMaxWidth()) {
                            Row(modifier = Modifier.padding(10.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                Text(if (isInterState) "Supply: Inter-State (IGST)" else "Supply: Intra-State (CGST + SGST)", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                Switch(checked = isInterState, onCheckedChange = { isInterState = it }, modifier = Modifier.testTag("switch_inter_state"))
                            }
                        }
                    }
                    item {
                        OutlinedTextField(value = itemDesc, onValueChange = { itemDesc = it }, label = { Text("Item Description") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    }
                    item {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(value = taxableStr, onValueChange = { taxableStr = it }, label = { Text("Taxable Value (₹) *") }, modifier = Modifier.weight(1.3f).testTag("input_taxable"))
                            OutlinedTextField(value = gstRateStr, onValueChange = { gstRateStr = it }, label = { Text("GST Rate (%)") }, modifier = Modifier.weight(0.9f))
                        }
                    }

                    // Transparent Tax Breakdown Card
                    item {
                        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFEFF6FF)), shape = RoundedCornerShape(10.dp), modifier = Modifier.fillMaxWidth()) {
                            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text("Tax Computation Breakdown:", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color(0xFF1E3A8A))
                                Text("• Taxable Base: ₹${breakdown.taxableValue}", fontSize = 11.sp)
                                if (isInterState) {
                                    Text("• IGST (${breakdown.igstRate}%): ₹${breakdown.igstAmount}", fontSize = 11.sp, color = FarmGreenDark, fontWeight = FontWeight.Bold)
                                } else {
                                    Text("• CGST (${breakdown.cgstRate}%): ₹${breakdown.cgstAmount}", fontSize = 11.sp, color = FarmGreenDark)
                                    Text("• SGST (${breakdown.sgstRate}%): ₹${breakdown.sgstAmount}", fontSize = 11.sp, color = FarmGreenDark)
                                }
                                Text("• Total Tax: ₹${breakdown.totalTax}", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                HorizontalDivider(color = Color(0xFFBFDBFE))
                                Text("Grand Invoice Total: ₹${breakdown.grandTotal}", fontWeight = FontWeight.ExtraBold, fontSize = 14.sp, color = Color(0xFF1E3A8A))
                            }
                        }
                    }
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    TextButton(onClick = onDismiss) { Text("Cancel") }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            if (buyerName.isBlank() || taxable <= 0) return@Button
                            val invNumber = "${gstSettings.invoice_prefix}-${System.currentTimeMillis().toString().takeLast(6)}"
                            val data = GstInvoicePreviewData(
                                invoiceNumber = invNumber,
                                invoiceDate = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date()),
                                buyerName = buyerName.trim(),
                                buyerAddress = buyerAddress.trim(),
                                buyerGstin = buyerGstin.trim(),
                                itemDescription = itemDesc.trim(),
                                hsn = hsn.trim(),
                                breakdown = breakdown,
                                gstSettings = gstSettings
                            )
                            onGenerate(data)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = FarmGreenDark),
                        enabled = buyerName.isNotBlank() && taxable > 0,
                        modifier = Modifier.testTag("btn_confirm_generate_invoice")
                    ) {
                        Text("Preview & Print Invoice")
                    }
                }
            }
        }
    }
}

@Composable
private fun GstInvoicePreviewDialog(
    data: GstInvoicePreviewData,
    onDismiss: () -> Unit,
    onShare: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Surface(shape = RoundedCornerShape(16.dp), color = Color.White, modifier = Modifier.fillMaxWidth().fillMaxHeight(0.9f)) {
            Column(modifier = Modifier.padding(18.dp)) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("TAX INVOICE PREVIEW", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = FarmGreenDark)
                    IconButton(onClick = onDismiss) { Icon(Icons.Default.Close, contentDescription = "Close") }
                }

                HorizontalDivider(modifier = Modifier.padding(vertical = 6.dp))

                // Printable Invoice Layout
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFFCFDFD)),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.weight(1f).border(1.dp, Color(0xFFDDDDDD), RoundedCornerShape(8.dp))
                ) {
                    LazyColumn(modifier = Modifier.fillMaxSize().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        item {
                            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                                Text(data.gstSettings.business_name, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
                                Text(data.gstSettings.business_address, fontSize = 11.sp, color = Color.Gray)
                                Text("GSTIN: ${data.gstSettings.gstin} • State: ${data.gstSettings.state_name} (${data.gstSettings.state_code})", fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                            }
                            HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))
                        }

                        item {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Column {
                                    Text("Billed To:", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                    Text(data.buyerName, fontSize = 12.sp)
                                    if (data.buyerAddress.isNotBlank()) Text(data.buyerAddress, fontSize = 11.sp, color = Color.DarkGray)
                                    if (data.buyerGstin.isNotBlank()) Text("Buyer GSTIN: ${data.buyerGstin}", fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                                }
                                Column(horizontalAlignment = Alignment.End) {
                                    Text("Invoice No: ${data.invoiceNumber}", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                    Text("Date: ${data.invoiceDate}", fontSize = 11.sp, color = Color.Gray)
                                    Text("Place: ${data.gstSettings.state_name}", fontSize = 11.sp, color = Color.Gray)
                                }
                            }
                            HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))
                        }

                        item {
                            Text("Description: ${data.itemDescription}", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            Text("HSN Code: ${data.hsn} • Taxable: ₹${data.breakdown.taxableValue}", fontSize = 11.sp, color = Color.DarkGray)

                            Spacer(modifier = Modifier.height(4.dp))
                            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFF9FAFB)), modifier = Modifier.fillMaxWidth()) {
                                Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                    if (data.breakdown.isInterState) {
                                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                            Text("Integrated Tax (IGST ${data.breakdown.igstRate}%):", fontSize = 11.sp)
                                            Text("₹${data.breakdown.igstAmount}", fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                        }
                                    } else {
                                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                            Text("Central Tax (CGST ${data.breakdown.cgstRate}%):", fontSize = 11.sp)
                                            Text("₹${data.breakdown.cgstAmount}", fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                        }
                                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                            Text("State Tax (SGST ${data.breakdown.sgstRate}%):", fontSize = 11.sp)
                                            Text("₹${data.breakdown.sgstAmount}", fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                        }
                                    }
                                    HorizontalDivider(color = Color(0xFFE5E7EB))
                                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                        Text("Invoice Total:", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                        Text("₹${data.breakdown.grandTotal}", fontWeight = FontWeight.ExtraBold, fontSize = 14.sp, color = FarmGreenDark)
                                    }
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    TextButton(onClick = onDismiss) { Text("Close") }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = onShare,
                        colors = ButtonDefaults.buttonColors(containerColor = FarmGreenDark),
                        modifier = Modifier.testTag("btn_share_gst_invoice")
                    ) {
                        Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Share / Print PDF")
                    }
                }
            }
        }
    }
}
