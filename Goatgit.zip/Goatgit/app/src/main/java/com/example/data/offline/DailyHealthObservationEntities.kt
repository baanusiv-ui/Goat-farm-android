package com.example.data.offline

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.UUID

@Entity(tableName = "local_daily_health_observations")
data class DailyHealthObservationEntity(
    @PrimaryKey
    val id: String = UUID.randomUUID().toString(),
    val goat_id: String,
    val goat_tag: String,
    val goat_name: String = "",
    val observation_date: String, // yyyy-MM-dd
    val temperature_celsius: Double? = null,
    val pulse_bpm: Int? = null,
    val respiration_rate: Int? = null,
    val appetite_status: String = "Normal", // Normal, Reduced, Anorexic, Voracious
    val activity_level: String = "Active & Alert", // Active & Alert, Lethargic, Depressed, Isolated
    val body_condition_score: Double? = null, // 1.0 to 5.0
    val feces_consistency: String = "Normal Pellets", // Normal Pellets, Soft Pellets, Diarrhea/Scours, Constipated
    val urination_status: String = "Normal", // Normal, Straining, Discolored
    val rumen_motility: String = "Normal", // Normal (1-2/min), Hypomotile/Weak, Bloated/Tympanic
    val mucous_membrane_famacha: String = "Score 1 - Optimal Pink", // FAMACHA 1 to 5
    val abnormal_symptoms: String = "None", // Comma-separated list of active symptoms
    val overall_health_rating: String = "Healthy", // Healthy, Mild Concern, Needs Vet Attention, Critical
    val observer_name: String = "Farm Staff",
    val notes: String? = null,
    val follow_up_required: Boolean = false,
    val created_at: Long = System.currentTimeMillis(),
    val updated_at: Long = System.currentTimeMillis(),
    val is_synced: Boolean = false
) {
    val isFever: Boolean
        get() = temperature_celsius != null && temperature_celsius > 39.7

    val isHypothermia: Boolean
        get() = temperature_celsius != null && temperature_celsius < 38.5

    val hasClinicalSigns: Boolean
        get() = overall_health_rating != "Healthy" || isFever || isHypothermia ||
                abnormal_symptoms != "None" || appetite_status != "Normal" || activity_level != "Active & Alert"
}
