package com.example.ui.screens.weaning

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.weaning.KidWeaningItem
import com.example.data.weaning.WeaningRepository
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RecordWeaningDialog(
    item: KidWeaningItem,
    weaningRepository: WeaningRepository,
    onDismiss: () -> Unit,
    onSuccess: (String) -> Unit
) {
    val coroutineScope = rememberCoroutineScope()
    val dateFormat = remember { SimpleDateFormat("yyyy-MM-dd", Locale.US) }
    val todayStr = remember { dateFormat.format(Date()) }

    var weaningDate by remember { mutableStateOf(todayStr) }
    var weaningWeightInput by remember {
        mutableStateOf(item.latestWeightKg?.toString() ?: "")
    }
    var weaningMethod by remember { mutableStateOf("GRADUAL") }
    var methodExpanded by remember { mutableStateOf(false) }
    val methods = listOf("GRADUAL", "NATURAL", "SEPARATION", "OTHER")

    var postFeedGroup by remember { mutableStateOf(item.record.post_weaning_feed_group) }
    var feedGroupExpanded by remember { mutableStateOf(false) }
    val feedGroups = listOf(
        "WEANED KID / GROWING KID",
        "HIGH-PROTEIN GROWER CONCENTRATE",
        "GREEN FODDER & DRY HAY",
        "STARTER MASH & LEGUMES",
        "WHOLE HERD PASTURE"
    )

    var delayReason by remember { mutableStateOf(item.record.reason_if_delayed ?: "") }
    var notes by remember { mutableStateOf(item.record.notes ?: "") }
    var isSaving by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    val weaningWeight = weaningWeightInput.toDoubleOrNull()
    val ageAtWeaningDays = remember(weaningDate) {
        weaningRepository.calculateAgeInDays(item.record.birth_date, weaningDate)
    }

    val birthWeight = item.birthWeightKg ?: item.kidGoat?.weight_kg_c
    val prevWeight = item.latestWeightKg ?: birthWeight

    val liveAdgFromBirth = remember(weaningWeight, ageAtWeaningDays, birthWeight) {
        if (weaningWeight != null && birthWeight != null && ageAtWeaningDays > 0) {
            weaningRepository.calculateAdg(weaningWeight, birthWeight, ageAtWeaningDays)
        } else null
    }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.92f)
                .testTag("record_weaning_dialog")
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(20.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Record Weaning",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF1B5E20)
                        )
                        val kidTag = item.kidGoat?.tag_c ?: "Tag-${item.record.goat_id.take(4)}"
                        Text(
                            text = "Kid #$kidTag • ${item.kidGoat?.breed_c ?: "Boer"}",
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close")
                    }
                }

                HorizontalDivider(modifier = Modifier.padding(vertical = 10.dp))

                Column(
                    modifier = Modifier
                        .weight(1f)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Kid & Lineage Info Card
                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFF1F8E9))
                    ) {
                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Mother (Dam):", fontSize = 12.sp, color = Color.Gray)
                                val damTag = item.motherGoat?.tag_c ?: item.kidGoat?.dam_c ?: "Unknown"
                                Text(damTag, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFF2E7D32))
                            }
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Father (Sire):", fontSize = 12.sp, color = Color.Gray)
                                val sireTag = item.fatherGoat?.tag_c ?: item.kidGoat?.sire_c ?: "Unknown"
                                Text(sireTag, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                            }
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Birth Date & Weight:", fontSize = 12.sp, color = Color.Gray)
                                Text("${item.record.birth_date} (${birthWeight?.let { "$it kg" } ?: "Not recorded"})", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                            }
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Expected Due Date:", fontSize = 12.sp, color = Color.Gray)
                                Text("${item.record.weaning_due_date} (${item.record.setting_source})", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFFE65100))
                            }
                        }
                    }

                    // Health Overview (Requirement 9)
                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFE3F2FD))
                    ) {
                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.MedicalServices, contentDescription = null, tint = Color(0xFF1565C0), modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Health & Clinical Status", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color(0xFF1565C0))
                            }
                            Text("• Vaccination: ${item.vaccinationStatus}", fontSize = 11.sp, color = Color(0xFF0D47A1))
                            Text("• Deworming: ${item.dewormingStatus}", fontSize = 11.sp, color = Color(0xFF0D47A1))
                            Text("• Treatment: ${item.treatmentStatus}", fontSize = 11.sp, color = Color(0xFF0D47A1))
                            if (item.isQuarantined) {
                                Text("⚠️ Currently in Quarantine / Biosecurity Isolation", fontSize = 11.sp, color = Color.Red, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    // Actual Weaning Date
                    OutlinedTextField(
                        value = weaningDate,
                        onValueChange = { weaningDate = it },
                        label = { Text("Actual Weaning Date (YYYY-MM-DD) *") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("weaning_date_input"),
                        leadingIcon = { Icon(Icons.Default.CalendarToday, contentDescription = null) }
                    )

                    Text(
                        text = "Calculated Age at Weaning: $ageAtWeaningDays days",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF2E7D32)
                    )

                    // Weaning Weight Input (Requirement 5)
                    OutlinedTextField(
                        value = weaningWeightInput,
                        onValueChange = { weaningWeightInput = it },
                        label = { Text("Weaning Weight (kg) *") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("weaning_weight_input"),
                        leadingIcon = { Icon(Icons.Default.Scale, contentDescription = null) }
                    )

                    // ADG Growth Card
                    if (liveAdgFromBirth != null && liveAdgFromBirth > 0) {
                        Card(
                            shape = RoundedCornerShape(10.dp),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF8E1))
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Text("Live Growth & Daily Gain (ADG)", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFFF57F17))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text("Growth:", fontSize = 11.sp)
                                    Text("${birthWeight ?: 0.0} kg ➔ ${weaningWeight ?: 0.0} kg (+${String.format(Locale.US, "%.2f", (weaningWeight ?: 0.0) - (birthWeight ?: 0.0))} kg)", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text("Average Daily Gain (ADG):", fontSize = 11.sp)
                                    Text("${liveAdgFromBirth.toInt()} g/day (${String.format(Locale.US, "%.3f", liveAdgFromBirth / 1000.0)} kg/d)", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFFE65100))
                                }
                            }
                        }
                    }

                    // Weaning Method Dropdown (Requirement 6)
                    ExposedDropdownMenuBox(
                        expanded = methodExpanded,
                        onExpandedChange = { methodExpanded = it }
                    ) {
                        OutlinedTextField(
                            value = weaningMethod,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Weaning Method *") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = methodExpanded) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .menuAnchor()
                        )
                        ExposedDropdownMenu(
                            expanded = methodExpanded,
                            onDismissRequest = { methodExpanded = false }
                        ) {
                            methods.forEach { m ->
                                DropdownMenuItem(
                                    text = { Text(m) },
                                    onClick = {
                                        weaningMethod = m
                                        methodExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    // Post-Weaning Feed Group (Requirement 8)
                    ExposedDropdownMenuBox(
                        expanded = feedGroupExpanded,
                        onExpandedChange = { feedGroupExpanded = it }
                    ) {
                        OutlinedTextField(
                            value = postFeedGroup,
                            onValueChange = { postFeedGroup = it },
                            label = { Text("Post-Weaning Feed Group *") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = feedGroupExpanded) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .menuAnchor()
                        )
                        ExposedDropdownMenu(
                            expanded = feedGroupExpanded,
                            onDismissRequest = { feedGroupExpanded = false }
                        ) {
                            feedGroups.forEach { g ->
                                DropdownMenuItem(
                                    text = { Text(g) },
                                    onClick = {
                                        postFeedGroup = g
                                        feedGroupExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    // If delayed, allow reason
                    if (item.dynamicStatus == "DELAYED") {
                        OutlinedTextField(
                            value = delayReason,
                            onValueChange = { delayReason = it },
                            label = { Text("Reason If Delayed") },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }

                    // Notes
                    OutlinedTextField(
                        value = notes,
                        onValueChange = { notes = it },
                        label = { Text("Observations & Notes") },
                        modifier = Modifier.fillMaxWidth(),
                        maxLines = 2
                    )

                    if (errorMessage != null) {
                        Text(
                            text = errorMessage!!,
                            color = MaterialTheme.colorScheme.error,
                            fontSize = 12.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Action buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(onClick = onDismiss) {
                        Text("Cancel")
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            val w = weaningWeightInput.toDoubleOrNull()
                            if (w == null || w <= 0.0) {
                                errorMessage = "Please enter a valid weaning weight in kg."
                                return@Button
                            }
                            isSaving = true
                            errorMessage = null
                            coroutineScope.launch {
                                val res = weaningRepository.recordWeaning(
                                    recordId = item.record.id,
                                    actualWeaningDate = weaningDate,
                                    weightAtWeaning = w,
                                    weaningMethod = weaningMethod,
                                    postFeedGroup = postFeedGroup,
                                    notes = notes,
                                    isDelayed = item.dynamicStatus == "DELAYED",
                                    delayReason = delayReason
                                )
                                isSaving = false
                                if (res.isSuccess) {
                                    val tag = item.kidGoat?.tag_c ?: "Kid"
                                    onSuccess("Weaning recorded successfully for #$tag! Status updated to WEANED.")
                                } else {
                                    errorMessage = res.exceptionOrNull()?.message ?: "Failed to save record"
                                }
                            }
                        },
                        enabled = !isSaving,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32)),
                        modifier = Modifier.testTag("confirm_wean_button")
                    ) {
                        if (isSaving) {
                            CircularProgressIndicator(color = Color.White, modifier = Modifier.size(18.dp))
                        } else {
                            Text("Complete Weaning", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CreateWeaningBatchDialog(
    candidates: List<KidWeaningItem>,
    weaningRepository: WeaningRepository,
    onDismiss: () -> Unit,
    onSuccess: (String) -> Unit
) {
    val coroutineScope = rememberCoroutineScope()
    val dateFormat = remember { SimpleDateFormat("yyyy-MM-dd", Locale.US) }
    val todayStr = remember { dateFormat.format(Date()) }

    var batchDate by remember { mutableStateOf(todayStr) }
    var batchMethod by remember { mutableStateOf("GRADUAL") }
    var methodExpanded by remember { mutableStateOf(false) }
    val methods = listOf("GRADUAL", "NATURAL", "SEPARATION", "OTHER")

    var postFeedGroup by remember { mutableStateOf("WEANED KID / GROWING KID") }

    // Selected kid record IDs and their individual weights
    val selectedRecordIds = remember { mutableStateMapOf<String, Boolean>() }
    val kidWeights = remember { mutableStateMapOf<String, String>() }

    // Default: select all candidates
    LaunchedEffect(candidates) {
        candidates.forEach { c ->
            selectedRecordIds[c.record.id] = true
            kidWeights[c.record.id] = c.latestWeightKg?.toString() ?: "12.5"
        }
    }

    var notes by remember { mutableStateOf("") }
    var isSaving by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.92f)
                .testTag("batch_weaning_dialog")
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(20.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("Create Weaning Batch", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1B5E20))
                        val count = selectedRecordIds.values.count { it }
                        Text("$count kids selected for batch weaning", fontSize = 12.sp, color = Color.Gray)
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close")
                    }
                }

                HorizontalDivider(modifier = Modifier.padding(vertical = 10.dp))

                Column(
                    modifier = Modifier
                        .weight(1f)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OutlinedTextField(
                        value = batchDate,
                        onValueChange = { batchDate = it },
                        label = { Text("Batch Weaning Date *") },
                        modifier = Modifier.fillMaxWidth(),
                        leadingIcon = { Icon(Icons.Default.CalendarToday, contentDescription = null) }
                    )

                    // Method
                    ExposedDropdownMenuBox(
                        expanded = methodExpanded,
                        onExpandedChange = { methodExpanded = it }
                    ) {
                        OutlinedTextField(
                            value = batchMethod,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Batch Weaning Method *") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = methodExpanded) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .menuAnchor()
                        )
                        ExposedDropdownMenu(
                            expanded = methodExpanded,
                            onDismissRequest = { methodExpanded = false }
                        ) {
                            methods.forEach { m ->
                                DropdownMenuItem(
                                    text = { Text(m) },
                                    onClick = {
                                        batchMethod = m
                                        methodExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    OutlinedTextField(
                        value = postFeedGroup,
                        onValueChange = { postFeedGroup = it },
                        label = { Text("Assigned Feed Group After Weaning *") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    Text("Select Kids & Enter Individual Weaning Weight (kg):", fontWeight = FontWeight.Bold, fontSize = 13.sp)

                    candidates.forEach { c ->
                        val isChecked = selectedRecordIds[c.record.id] ?: false
                        Card(
                            shape = RoundedCornerShape(10.dp),
                            colors = CardDefaults.cardColors(containerColor = if (isChecked) Color(0xFFF1F8E9) else Color(0xFFF5F5F5)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Checkbox(
                                    checked = isChecked,
                                    onCheckedChange = { selectedRecordIds[c.record.id] = it }
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    val tag = c.kidGoat?.tag_c ?: "Tag-${c.record.goat_id.take(4)}"
                                    Text("#$tag (${c.kidGoat?.breed_c ?: "Boer"})", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                    Text("Dam: ${c.motherGoat?.tag_c ?: c.kidGoat?.dam_c ?: "—"} • Age: ${c.currentAgeDays}d", fontSize = 11.sp, color = Color.Gray)
                                }
                                if (isChecked) {
                                    OutlinedTextField(
                                        value = kidWeights[c.record.id] ?: "",
                                        onValueChange = { kidWeights[c.record.id] = it },
                                        label = { Text("Weight") },
                                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                                        modifier = Modifier.width(90.dp),
                                        singleLine = true
                                    )
                                }
                            }
                        }
                    }

                    OutlinedTextField(
                        value = notes,
                        onValueChange = { notes = it },
                        label = { Text("Batch Notes") },
                        modifier = Modifier.fillMaxWidth(),
                        maxLines = 2
                    )

                    if (errorMessage != null) {
                        Text(text = errorMessage!!, color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(onClick = onDismiss) { Text("Cancel") }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            val selected = candidates.filter { selectedRecordIds[it.record.id] == true }
                            if (selected.isEmpty()) {
                                errorMessage = "Select at least 1 kid to wean."
                                return@Button
                            }
                            val pairs = mutableListOf<Pair<String, Double>>()
                            for (kid in selected) {
                                val wStr = kidWeights[kid.record.id]
                                val w = wStr?.toDoubleOrNull()
                                if (w == null || w <= 0.0) {
                                    errorMessage = "Please enter a valid weight for kid #${kid.kidGoat?.tag_c ?: ""}"
                                    return@Button
                                }
                                pairs.add(Pair(kid.record.id, w))
                            }

                            isSaving = true
                            errorMessage = null
                            coroutineScope.launch {
                                val res = weaningRepository.createWeaningBatch(
                                    kidsWithWeights = pairs,
                                    weaningDate = batchDate,
                                    method = batchMethod,
                                    postFeedGroup = postFeedGroup,
                                    notes = notes
                                )
                                isSaving = false
                                if (res.isSuccess) {
                                    onSuccess("Weaning batch created with ${pairs.size} kids successfully!")
                                } else {
                                    errorMessage = res.exceptionOrNull()?.message ?: "Failed to create batch"
                                }
                            }
                        },
                        enabled = !isSaving,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32)),
                        modifier = Modifier.testTag("submit_weaning_batch_btn")
                    ) {
                        if (isSaving) {
                            CircularProgressIndicator(color = Color.White, modifier = Modifier.size(18.dp))
                        } else {
                            Text("Create Weaning Batch", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WeaningSettingsDialog(
    weaningRepository: WeaningRepository,
    onDismiss: () -> Unit,
    onSuccess: (String) -> Unit
) {
    val coroutineScope = rememberCoroutineScope()
    var defaultDaysInput by remember { mutableStateOf("90") }
    var boerDaysInput by remember { mutableStateOf("90") }
    var sirohiDaysInput by remember { mutableStateOf("90") }
    var bengalDaysInput by remember { mutableStateOf("75") }
    var barbariDaysInput by remember { mutableStateOf("75") }
    var jamnapariDaysInput by remember { mutableStateOf("100") }
    var feedGroupInput by remember { mutableStateOf("WEANED KID / GROWING KID") }
    var isSaving by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        defaultDaysInput = weaningRepository.getDefaultWeaningDays().toString()
        boerDaysInput = weaningRepository.getBreedWeaningDays("Boer").toString()
        sirohiDaysInput = weaningRepository.getBreedWeaningDays("Sirohi").toString()
        bengalDaysInput = weaningRepository.getBreedWeaningDays("Black Bengal").toString()
        barbariDaysInput = weaningRepository.getBreedWeaningDays("Barbari").toString()
        jamnapariDaysInput = weaningRepository.getBreedWeaningDays("Jamnapari").toString()
        feedGroupInput = weaningRepository.getPostWeaningFeedGroupSetting()
    }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.85f)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(20.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Weaning Configuration", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1B5E20))
                    IconButton(onClick = onDismiss) { Icon(Icons.Default.Close, contentDescription = "Close") }
                }

                HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

                Column(
                    modifier = Modifier
                        .weight(1f)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        "Configure the farm default and breed-specific weaning ages. These are applied automatically upon kid registration.",
                        fontSize = 12.sp,
                        color = Color.Gray
                    )

                    OutlinedTextField(
                        value = defaultDaysInput,
                        onValueChange = { defaultDaysInput = it },
                        label = { Text("Farm Default Weaning Age (Days) *") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Text("Breed-Specific Weaning Targets (Days):", fontWeight = FontWeight.Bold, fontSize = 13.sp)

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = boerDaysInput,
                            onValueChange = { boerDaysInput = it },
                            label = { Text("Boer") },
                            modifier = Modifier.weight(1f),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                        )
                        OutlinedTextField(
                            value = sirohiDaysInput,
                            onValueChange = { sirohiDaysInput = it },
                            label = { Text("Sirohi") },
                            modifier = Modifier.weight(1f),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                        )
                    }

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = bengalDaysInput,
                            onValueChange = { bengalDaysInput = it },
                            label = { Text("Black Bengal") },
                            modifier = Modifier.weight(1f),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                        )
                        OutlinedTextField(
                            value = barbariDaysInput,
                            onValueChange = { barbariDaysInput = it },
                            label = { Text("Barbari") },
                            modifier = Modifier.weight(1f),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                        )
                    }

                    OutlinedTextField(
                        value = jamnapariDaysInput,
                        onValueChange = { jamnapariDaysInput = it },
                        label = { Text("Jamnapari (Days)") },
                        modifier = Modifier.fillMaxWidth(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                    )

                    OutlinedTextField(
                        value = feedGroupInput,
                        onValueChange = { feedGroupInput = it },
                        label = { Text("Default Post-Weaning Feed Group") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(onClick = onDismiss) { Text("Cancel") }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            val defDays = defaultDaysInput.toIntOrNull() ?: 90
                            isSaving = true
                            coroutineScope.launch {
                                weaningRepository.setDefaultWeaningDays(defDays)
                                boerDaysInput.toIntOrNull()?.let { weaningRepository.setBreedWeaningDays("Boer", it) }
                                sirohiDaysInput.toIntOrNull()?.let { weaningRepository.setBreedWeaningDays("Sirohi", it) }
                                bengalDaysInput.toIntOrNull()?.let { weaningRepository.setBreedWeaningDays("Black Bengal", it) }
                                barbariDaysInput.toIntOrNull()?.let { weaningRepository.setBreedWeaningDays("Barbari", it) }
                                jamnapariDaysInput.toIntOrNull()?.let { weaningRepository.setBreedWeaningDays("Jamnapari", it) }
                                weaningRepository.setPostWeaningFeedGroupSetting(feedGroupInput)
                                isSaving = false
                                onSuccess("Weaning settings updated successfully!")
                            }
                        },
                        enabled = !isSaving,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32))
                    ) {
                        Text("Save Settings", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
