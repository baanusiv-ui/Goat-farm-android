package com.example.ui.screens.breeding

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.pedigree.*
import com.example.data.supabase.Goat
import com.example.data.supabase.GoatRepository
import com.example.data.supabase.MatingRecord
import com.example.i18n.t
import com.example.ui.components.OriginBadge
import com.example.ui.theme.*
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LineageAuditView(
    repository: GoatRepository,
    goats: List<Goat>,
    matings: List<MatingRecord>,
    onGoatsUpdated: () -> Unit
) {
    val coroutineScope = rememberCoroutineScope()
    val auditReport = remember(goats, matings) {
        PedigreeManager.generateAuditReport(goats, matings)
    }

    var goatToEditBreed by remember { mutableStateOf<Goat?>(null) }
    var newBreedSelection by remember { mutableStateOf("Boer") }
    var isUpdatingBreed by remember { mutableStateOf(false) }

    val commonBreeds = listOf("Salem Karupu", "Kodi Adu", "Boer", "Jamnapari", "Barbari", "Sirohi", "Saanen", "Nubian", "Alpine", "Beetal", "Kalahari Red")

    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Report Header Banner
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = FarmGreenDark),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Verified, contentDescription = null, tint = Color.White)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = t("pedigree.audit_report"),
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleMedium,
                        color = Color.White
                    )
                }
                Text(
                    text = "Automated breeding and lineage integrity check across herd and mating history. Identifies cross-breeding, inbreeding, and missing records.",
                    fontSize = 12.sp,
                    color = Color.White.copy(alpha = 0.85f)
                )
            }
        }

        // Summary Metric Badges
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            AuditMetricCard(
                title = "Missing Breed",
                count = auditReport.goatsWithMissingBreed.size,
                isWarning = auditReport.goatsWithMissingBreed.isNotEmpty(),
                modifier = Modifier.weight(1f)
            )
            AuditMetricCard(
                title = "Missing Parents",
                count = auditReport.farmBornMissingParents.size,
                isWarning = auditReport.farmBornMissingParents.isNotEmpty(),
                modifier = Modifier.weight(1f)
            )
            AuditMetricCard(
                title = "Market Goats",
                count = auditReport.marketBoughtUnknownPedigree.size,
                isWarning = false,
                modifier = Modifier.weight(1f)
            )
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            AuditMetricCard(
                title = "Cross-Breed Mating",
                count = auditReport.historicalCrossBreedMatings.size,
                isWarning = auditReport.historicalCrossBreedMatings.isNotEmpty(),
                modifier = Modifier.weight(1f)
            )
            AuditMetricCard(
                title = "Close-Relative Mating",
                count = auditReport.historicalCloseRelativeMatings.size,
                isWarning = auditReport.historicalCloseRelativeMatings.isNotEmpty(),
                modifier = Modifier.weight(1f)
            )
        }

        // Section 1: Goats with Missing Breed
        if (auditReport.goatsWithMissingBreed.isNotEmpty()) {
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = FarmErrorContainer.copy(alpha = 0.6f))
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Warning, contentDescription = null, tint = FarmError)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Goats with Missing Breed (${auditReport.goatsWithMissingBreed.size})",
                            fontWeight = FontWeight.Bold,
                            color = FarmError
                        )
                    }
                    Text(
                        text = t("pedigree.breed_info_required"),
                        fontSize = 12.sp,
                        color = Color.DarkGray
                    )

                    auditReport.goatsWithMissingBreed.forEach { g ->
                        Card(
                            shape = RoundedCornerShape(8.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.White)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text("${g.name} (${g.tag_c})", fontWeight = FontWeight.Bold)
                                    Text("Origin: ${g.effectiveOrigin} • Sex: ${g.sex_c}", fontSize = 11.sp, color = Color.Gray)
                                }
                                Button(
                                    onClick = {
                                        goatToEditBreed = g
                                        newBreedSelection = "Boer"
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = FarmGreenPrimary),
                                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                                    modifier = Modifier.height(34.dp)
                                ) {
                                    Text("Set Breed", fontSize = 12.sp)
                                }
                            }
                        }
                    }
                }
            }
        }

        // Section 2: Farm-Born Missing Sire/Dam
        if (auditReport.farmBornMissingParents.isNotEmpty()) {
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Farm-Born Goats Missing Pedigree (${auditReport.farmBornMissingParents.size})",
                        fontWeight = FontWeight.Bold,
                        color = FarmGreenDark
                    )
                    Text(
                        text = "Farm-born animals should record Sire and Dam for lineage tracking.",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    auditReport.farmBornMissingParents.take(6).forEach { g ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("${g.name} (${g.tag_c}) - ${g.breed_c}", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                            Text("Missing: ${if (g.sire_c.isNullOrBlank()) "Sire " else ""}${if (g.dam_c.isNullOrBlank()) "Dam" else ""}", fontSize = 11.sp, color = Color.Gray)
                        }
                        HorizontalDivider(color = Color(0xFFF0F0F0))
                    }
                }
            }
        }

        // Section 3: Market-bought goats notice
        Card(
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFFE3F2FD))
        ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Info, contentDescription = null, tint = Color(0xFF0D47A1))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Market-Bought Goats Inventory (${auditReport.marketBoughtUnknownPedigree.size})",
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF0D47A1)
                    )
                }
                Text(
                    text = "Market-bought goats are safely maintained in the herd. Farm pedigree is not required or invented for them.",
                    fontSize = 12.sp,
                    color = Color(0xFF1565C0)
                )
            }
        }

        // Section 4: Historical Mating Records Analysis
        if (auditReport.historicalCrossBreedMatings.isNotEmpty() || auditReport.historicalCloseRelativeMatings.isNotEmpty()) {
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Historical Mating Records Analysis",
                        fontWeight = FontWeight.Bold,
                        color = FarmGreenDark
                    )
                    Text(
                        text = "Historical records are preserved for farm auditing without automatic modification.",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    auditReport.historicalCrossBreedMatings.forEach { cbm ->
                        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF3E0))) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Text("Cross-Breeding Record (${cbm.mating.mating_date_c})", fontWeight = FontWeight.Bold, color = Color(0xFFE65100), fontSize = 12.sp)
                                Text(cbm.descriptionEn, fontSize = 12.sp)
                                Text(cbm.descriptionTa, fontSize = 11.sp, color = Color.Gray)
                            }
                        }
                    }

                    auditReport.historicalCloseRelativeMatings.forEach { crm ->
                        Card(colors = CardDefaults.cardColors(containerColor = FarmErrorContainer.copy(alpha = 0.5f))) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Text("Close-Relative Record (${crm.mating.mating_date_c})", fontWeight = FontWeight.Bold, color = FarmError, fontSize = 12.sp)
                                Text(crm.descriptionEn, fontSize = 12.sp)
                                Text(crm.descriptionTa, fontSize = 11.sp, color = Color.Gray)
                            }
                        }
                    }
                }
            }
        } else {
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = FarmGreenContainer.copy(alpha = 0.4f))
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = FarmSuccess)
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "All historical mating records pass purebred and kinship standards.",
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 12.sp,
                        color = FarmGreenDark
                    )
                }
            }
        }
    }

    // Breed Update Dialog
    goatToEditBreed?.let { targetGoat ->
        var expanded by remember { mutableStateOf(false) }
        AlertDialog(
            onDismissRequest = { if (!isUpdatingBreed) goatToEditBreed = null },
            title = { Text("Update Breed for ${targetGoat.tag_c}") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Select a verified breed for this animal before proceeding with farm mating:")
                    ExposedDropdownMenuBox(
                        expanded = expanded,
                        onExpandedChange = { expanded = !expanded }
                    ) {
                        OutlinedTextField(
                            value = newBreedSelection,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text(t("pedigree.breed")) },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
                            modifier = Modifier.fillMaxWidth().menuAnchor()
                        )
                        ExposedDropdownMenu(
                            expanded = expanded,
                            onDismissRequest = { expanded = false }
                        ) {
                            commonBreeds.forEach { b ->
                                DropdownMenuItem(
                                    text = { Text(b) },
                                    onClick = {
                                        newBreedSelection = b
                                        expanded = false
                                    }
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        isUpdatingBreed = true
                        coroutineScope.launch {
                            val updated = targetGoat.copy(breed_c = newBreedSelection)
                            repository.updateGoat(updated)
                            isUpdatingBreed = false
                            goatToEditBreed = null
                            onGoatsUpdated()
                        }
                    },
                    enabled = !isUpdatingBreed,
                    colors = ButtonDefaults.buttonColors(containerColor = FarmGreenPrimary)
                ) {
                    if (isUpdatingBreed) CircularProgressIndicator(color = Color.White, modifier = Modifier.size(20.dp))
                    else Text("Save Breed")
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { goatToEditBreed = null },
                    enabled = !isUpdatingBreed
                ) {
                    Text(t("btn.cancel"))
                }
            }
        )
    }
}

@Composable
fun AuditMetricCard(
    title: String,
    count: Int,
    isWarning: Boolean,
    modifier: Modifier = Modifier
) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isWarning) FarmErrorContainer else Color.White
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = count.toString(),
                fontWeight = FontWeight.Bold,
                fontSize = 20.sp,
                color = if (isWarning) FarmError else FarmGreenDark
            )
            Text(
                text = title,
                fontSize = 10.sp,
                fontWeight = FontWeight.SemiBold,
                color = if (isWarning) FarmError else MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
