package com.example.data.offline

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.UUID

@Entity(tableName = "local_vaccination_schedules")
data class VaccinationScheduleEntity(
    @PrimaryKey
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val disease: String,
    val vaccine_name: String,
    val species: String = "Goat",
    val recommended_age: String,
    val recommended_interval: String,
    val dose_reference: String,
    val notes: String? = null,
    val source: String = "TANUVAS Reference Schedule",
    val active: Boolean = true,
    val created_at: String? = null,
    val updated_at: Long = System.currentTimeMillis()
)

@Entity(tableName = "local_deworming_schedules")
data class DewormingScheduleEntity(
    @PrimaryKey
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val species: String = "Goat",
    val trigger_type: String, // PERIODIC, FEC-BASED, VETERINARIAN ADVISED, CUSTOM
    val interval_days: Int = 90,
    val fec_reference: String? = null,
    val notes: String? = null,
    val source: String = "TANUVAS Reference",
    val active: Boolean = true,
    val created_at: String? = null,
    val updated_at: Long = System.currentTimeMillis()
)

@Entity(tableName = "local_quarantine_records")
data class QuarantineRecordEntity(
    @PrimaryKey
    val id: String = UUID.randomUUID().toString(),
    val farm_id: String = "default_farm",
    val goat_id: String,
    val purchase_id: String? = null,
    val start_date: String,
    val planned_end_date: String,
    val actual_release_date: String? = null,
    val source_location: String? = null,
    val seller_name: String? = null,
    val seller_contact: String? = null,
    val reason: String = "Market Purchase Quarantine Protocol",
    val initial_health_status: String = "Under Observation",
    val temperature: Double? = null,
    val weight: Double? = null,
    val vaccination_status: String = "Pending Review",
    val deworming_status: String = "Pending Review",
    val fecal_test: String? = null,
    val clinical_exam: String? = null,
    val veterinarian: String? = null,
    val isolation_location: String = "Isolation Barn / Quarantine Pen",
    val status: String = "QUARANTINE", // QUARANTINE, CLEARED, EXTENDED, REJECTED, TRANSFERRED, DECEASED
    val release_reason: String? = null,
    val notes: String? = null,
    val checklist_json: String? = null,
    val extensions_json: String? = null,
    val created_at: String? = null,
    val updated_at: Long = System.currentTimeMillis(),
    val is_synced: Boolean = false
)
