package com.example.ui.screens.weight

import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.TrendingUp
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.data.offline.GoatWeightEntity
import com.example.data.supabase.Goat
import com.example.data.supabase.GoatRepository
import com.example.ui.components.DatePickerField
import com.example.ui.theme.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.TimeUnit
import kotlin.math.roundToInt

/**
 * Breed growth benchmark standards used to compute expected averages.
 */
data class BreedGrowthBenchmark(
    val breedName: String,
    val birthWeightKg: Double,
    val weaningWeightKg: Double, // ~90 days
    val sixMonthWeightKg: Double, // ~180 days
    val adultWeightKg: Double, // ~365 days
    val targetAdgGramsPerDay: Int,
    val marketTargetWeightKg: Double
) {
    fun calculateExpectedWeight(ageDays: Int): Double {
        return when {
            ageDays <= 0 -> birthWeightKg
            ageDays <= 90 -> birthWeightKg + ((weaningWeightKg - birthWeightKg) / 90.0) * ageDays
            ageDays <= 180 -> weaningWeightKg + ((sixMonthWeightKg - weaningWeightKg) / 90.0) * (ageDays - 90)
            ageDays <= 365 -> sixMonthWeightKg + ((adultWeightKg - sixMonthWeightKg) / 185.0) * (ageDays - 180)
            else -> adultWeightKg + (ageDays - 365) * 0.015
        }.coerceAtLeast(birthWeightKg)
    }

    fun calculateExpectedWeightFromStart(initialKg: Double, elapsedDays: Int): Double {
        val dailyGainKg = targetAdgGramsPerDay / 1000.0
        return (initialKg + dailyGainKg * elapsedDays).coerceAtLeast(initialKg)
    }
}

val DefaultBreedBenchmarks = listOf(
    BreedGrowthBenchmark("Boer", 3.5, 22.0, 38.0, 65.0, 190, 38.0),
    BreedGrowthBenchmark("Jamunapari", 3.2, 16.0, 26.0, 45.0, 140, 32.0),
    BreedGrowthBenchmark("Sirohi", 2.8, 14.0, 23.0, 38.0, 120, 30.0),
    BreedGrowthBenchmark("Barbari", 1.9, 9.0, 15.0, 25.0, 80, 22.0),
    BreedGrowthBenchmark("Black Bengal", 1.3, 6.5, 12.0, 19.0, 65, 16.0),
    BreedGrowthBenchmark("Saanen", 3.4, 18.0, 30.0, 52.0, 150, 35.0),
    BreedGrowthBenchmark("Beetal", 3.2, 17.0, 28.0, 48.0, 145, 34.0),
    BreedGrowthBenchmark("General Meat", 2.8, 15.0, 24.0, 38.0, 115, 30.0)
)

data class RechartsChartPoint(
    val id: String,
    val dateStr: String,
    val timestamp: Long,
    val actualWeightKg: Double,
    val expectedWeightKg: Double,
    val varianceKg: Double, // actual - expected
    val variancePct: Double,
    val gainSinceLastKg: Double?,
    val intervalDays: Long?,
    val intervalAdgGrams: Int?,
    val method: String,
    val notes: String?
)

/**
 * High-performance Recharts data visualization screen for tracking goat growth curves,
 * weight progression, and Average Daily Gain (ADG) against expected breed averages.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GoatWeightTrendsVisualizationScreen(
    repository: GoatRepository,
    initialGoatId: String? = null,
    onNavigateBack: () -> Unit,
    onNavigateToRecordWeight: ((String?) -> Unit)? = null
) {
    BackHandler { onNavigateBack() }

    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val dateFormat = remember { SimpleDateFormat("yyyy-MM-dd", Locale.US) }
    val displayFormat = remember { SimpleDateFormat("dd MMM yyyy", Locale.US) }

    // Reactive streams from local Room DB
    val allGoats by repository.getLocalGoatsFlow().collectAsState(initial = emptyList())
    val allWeightsFlow by repository.database.healthDao().getAllWeightsFlow().collectAsState(initial = emptyList())

    // Selected Goat & Filters
    var selectedGoatId by remember { mutableStateOf(initialGoatId ?: "") }
    var selectedTimeframe by remember { mutableStateOf("6M") } // 1M, 3M, 6M, 1Y, ALL
    var chartEngineMode by remember { mutableStateOf("CANVAS") } // CANVAS or RECHARTS_WEB
    var showRecordWeightDialog by remember { mutableStateOf(false) }
    var selectedBenchmarkOverride by remember { mutableStateOf<String?>(null) }
    var showSimulationConfirmDialog by remember { mutableStateOf(false) }

    // Ensure selected goat is valid once goats load
    LaunchedEffect(allGoats) {
        if (selectedGoatId.isBlank() && allGoats.isNotEmpty()) {
            selectedGoatId = allGoats.first().id
        }
    }

    val currentGoat = remember(allGoats, selectedGoatId) {
        allGoats.find { it.id == selectedGoatId } ?: allGoats.firstOrNull()
    }

    // Determine Breed Benchmark
    val activeBenchmark = remember(currentGoat, selectedBenchmarkOverride) {
        val overrideName = selectedBenchmarkOverride
        if (overrideName != null) {
            DefaultBreedBenchmarks.find { it.breedName.equals(overrideName, ignoreCase = true) }
                ?: DefaultBreedBenchmarks.last()
        } else {
            val goatBreed = currentGoat?.breed_c.orEmpty()
            DefaultBreedBenchmarks.find { it.breedName.equals(goatBreed, ignoreCase = true) }
                ?: DefaultBreedBenchmarks.firstOrNull { goatBreed.contains(it.breedName, ignoreCase = true) }
                ?: DefaultBreedBenchmarks.last() // General Meat
        }
    }

    // Filter weights for current goat
    val rawGoatWeights = remember(allWeightsFlow, currentGoat) {
        if (currentGoat == null) emptyList()
        else allWeightsFlow.filter { it.goat_id_c == currentGoat.id }.sortedBy { it.date_c }
    }

    // Timeframe cutoff
    val cutoffMillis = remember(selectedTimeframe) {
        val now = System.currentTimeMillis()
        when (selectedTimeframe) {
            "1M" -> now - 30L * 86400000L
            "3M" -> now - 90L * 86400000L
            "6M" -> now - 180L * 86400000L
            "1Y" -> now - 365L * 86400000L
            else -> 0L
        }
    }

    val filteredWeights = remember(rawGoatWeights, cutoffMillis) {
        rawGoatWeights.filter {
            val t = try { dateFormat.parse(it.date_c)?.time ?: 0L } catch (_: Exception) { 0L }
            t >= cutoffMillis
        }
    }

    // Compute Recharts Points with Expected Averages
    val chartPoints = remember(filteredWeights, activeBenchmark, currentGoat) {
        if (filteredWeights.isEmpty()) emptyList()
        else {
            val points = mutableListOf<RechartsChartPoint>()
            val firstWeight = filteredWeights.first()
            val firstDate = try { dateFormat.parse(firstWeight.date_c) ?: Date() } catch (_: Exception) { Date() }

            // Birth date parse if available
            val birthDate = currentGoat?.birth_date_c?.let {
                try { dateFormat.parse(it) } catch (_: Exception) { null }
            }

            for (i in filteredWeights.indices) {
                val item = filteredWeights[i]
                val itemDate = try { dateFormat.parse(item.date_c) ?: Date() } catch (_: Exception) { Date() }
                val time = itemDate.time

                // Expected Weight Calculation:
                val expected = if (birthDate != null) {
                    val ageDays = TimeUnit.MILLISECONDS.toDays(itemDate.time - birthDate.time).toInt()
                    activeBenchmark.calculateExpectedWeight(ageDays)
                } else {
                    val elapsedDays = TimeUnit.MILLISECONDS.toDays(itemDate.time - firstDate.time).toInt()
                    activeBenchmark.calculateExpectedWeightFromStart(firstWeight.weight_kg_c, elapsedDays)
                }

                val varianceKg = item.weight_kg_c - expected
                val variancePct = if (expected > 0) (varianceKg / expected) * 100.0 else 0.0

                val prevItem = if (i > 0) filteredWeights[i - 1] else null
                val gainSinceLast = prevItem?.let { item.weight_kg_c - it.weight_kg_c }
                val daysSinceLast = prevItem?.let {
                    val prevDate = try { dateFormat.parse(it.date_c) ?: Date() } catch (_: Exception) { Date() }
                    TimeUnit.MILLISECONDS.toDays(itemDate.time - prevDate.time).coerceAtLeast(1L)
                }
                val intervalAdg = if (gainSinceLast != null && daysSinceLast != null && daysSinceLast > 0) {
                    ((gainSinceLast * 1000.0) / daysSinceLast).toInt()
                } else null

                points.add(
                    RechartsChartPoint(
                        id = item.id,
                        dateStr = item.date_c,
                        timestamp = time,
                        actualWeightKg = item.weight_kg_c,
                        expectedWeightKg = ((expected * 10.0).roundToInt()) / 10.0,
                        varianceKg = ((varianceKg * 10.0).roundToInt()) / 10.0,
                        variancePct = ((variancePct * 10.0).roundToInt()) / 10.0,
                        gainSinceLastKg = gainSinceLast?.let { ((it * 10.0).roundToInt()) / 10.0 },
                        intervalDays = daysSinceLast,
                        intervalAdgGrams = intervalAdg,
                        method = item.method_c,
                        notes = item.notes_c
                    )
                )
            }
            points
        }
    }

    // High level KPIs
    val latestPoint = chartPoints.lastOrNull()
    val earliestPoint = chartPoints.firstOrNull()
    val currentWeightKg = latestPoint?.actualWeightKg ?: currentGoat?.weight_kg_c ?: 0.0
    val totalGainKg = if (chartPoints.size >= 2) {
        latestPoint!!.actualWeightKg - earliestPoint!!.actualWeightKg
    } else 0.0

    val overallAdgGrams = remember(chartPoints) {
        if (chartPoints.size >= 2) {
            val first = chartPoints.first()
            val last = chartPoints.last()
            val days = TimeUnit.MILLISECONDS.toDays(last.timestamp - first.timestamp).coerceAtLeast(1L)
            val gainKg = last.actualWeightKg - first.actualWeightKg
            ((gainKg * 1000.0) / days).toInt()
        } else null
    }

    val marketTargetKg = activeBenchmark.marketTargetWeightKg
    val targetProgressPct = if (marketTargetKg > 0) {
        ((currentWeightKg / marketTargetKg) * 100f).coerceIn(0.0, 100.0).toFloat()
    } else 0f

    val projectedDaysToTarget = if (overallAdgGrams != null && overallAdgGrams > 10 && currentWeightKg < marketTargetKg) {
        val neededGainKg = marketTargetKg - currentWeightKg
        val dailyGainKg = overallAdgGrams / 1000.0
        (neededGainKg / dailyGainKg).toInt()
    } else null

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "Weight Trends & Growth",
                            fontWeight = FontWeight.Bold,
                            fontSize = 17.sp,
                            color = Color.White
                        )
                        Text(
                            text = "Recharts Data Visualizer • Breed Benchmarks",
                            fontSize = 11.sp,
                            color = Color(0xFFA7F3D0)
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }
                },
                actions = {
                    IconButton(
                        onClick = { showRecordWeightDialog = true },
                        modifier = Modifier.testTag("btn_top_add_weight")
                    ) {
                        Icon(Icons.Default.Add, contentDescription = "Log Weight", tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = FarmGreenDark
                )
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { showRecordWeightDialog = true },
                containerColor = FarmGreenPrimary,
                contentColor = Color.White,
                icon = { Icon(Icons.Default.Scale, contentDescription = null) },
                text = { Text("Log Weigh-in", fontWeight = FontWeight.Bold) },
                modifier = Modifier.testTag("fab_record_weigh_in")
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFFF8FAFC))
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Goat Selection & Header Card
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "Select Animal to Inspect",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Color(0xFF64748B)
                    )

                    // Horizontally scrollable goat selector chips
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        allGoats.forEach { g ->
                            val isSelected = g.id == currentGoat?.id
                            FilterChip(
                                selected = isSelected,
                                onClick = { selectedGoatId = g.id },
                                label = {
                                    Column(modifier = Modifier.padding(vertical = 2.dp)) {
                                        Text(
                                            text = "${g.tag_c} - ${g.name}",
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                            fontSize = 12.sp
                                        )
                                        Text(
                                            text = "${g.breed_c ?: "Mixed"} • ${g.weight_kg_c?.let { "${it}kg" } ?: "--"}",
                                            fontSize = 10.sp
                                        )
                                    }
                                },
                                leadingIcon = {
                                    Surface(
                                        shape = CircleShape,
                                        color = if (isSelected) FarmGreenDark else Color(0xFFE2E8F0),
                                        modifier = Modifier.size(24.dp)
                                    ) {
                                        Box(contentAlignment = Alignment.Center) {
                                            Text(
                                                text = (g.tag_c.takeLast(2)),
                                                fontSize = 9.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = if (isSelected) Color.White else Color.DarkGray
                                            )
                                        }
                                    }
                                },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = Color(0xFFDCFCE7),
                                    selectedLabelColor = FarmGreenDark
                                ),
                                border = FilterChipDefaults.filterChipBorder(
                                    enabled = true,
                                    selected = isSelected,
                                    borderColor = if (isSelected) FarmGreenDark else Color(0xFFE2E8F0)
                                ),
                                modifier = Modifier.testTag("goat_chip_${g.tag_c}")
                            )
                        }
                    }

                    // Active Goat Summary Card
                    currentGoat?.let { goat ->
                        HorizontalDivider(color = Color(0xFFF1F5F9))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Text(
                                        text = "${goat.tag_c} • ${goat.name}",
                                        fontWeight = FontWeight.ExtraBold,
                                        fontSize = 16.sp,
                                        color = Color(0xFF0F172A)
                                    )
                                    Surface(
                                        shape = RoundedCornerShape(4.dp),
                                        color = if (goat.sex_c.contains("Doe", ignoreCase = true)) Color(0xFFFCE7F3) else Color(0xFFE0F2FE)
                                    ) {
                                        Text(
                                            text = goat.sex_c,
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = if (goat.sex_c.contains("Doe", ignoreCase = true)) Color(0xFFBE185D) else Color(0xFF0369A1),
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                }

                                Text(
                                    text = "Breed: ${goat.breed_c ?: "Mixed"} | Benchmark: ${activeBenchmark.breedName} Standard",
                                    fontSize = 11.sp,
                                    color = Color(0xFF64748B)
                                )
                            }

                            // Benchmark Override Dropdown Chip
                            AssistChip(
                                onClick = {
                                    // Cycle through breed benchmarks
                                    val currentIdx = DefaultBreedBenchmarks.indexOfFirst { it.breedName == activeBenchmark.breedName }
                                    val nextIdx = (currentIdx + 1) % DefaultBreedBenchmarks.size
                                    selectedBenchmarkOverride = DefaultBreedBenchmarks[nextIdx].breedName
                                },
                                label = { Text("Standard: ${activeBenchmark.breedName}", fontSize = 10.sp, fontWeight = FontWeight.SemiBold) },
                                leadingIcon = {
                                    Icon(Icons.Default.Tune, contentDescription = null, modifier = Modifier.size(12.dp))
                                }
                            )
                        }
                    }
                }
            }

            // Quick Simulation Generator Banner (if zero or only 1 weight recorded)
            if (chartPoints.size < 2) {
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFFEF3C7)),
                    border = BorderStroke(1.dp, Color(0xFFFDE68A)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(Icons.Default.AutoGraph, contentDescription = null, tint = Color(0xFFD97706), modifier = Modifier.size(20.dp))
                            Text(
                                text = "Limited Weigh-in History (${chartPoints.size} logged)",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = Color(0xFF92400E)
                            )
                        }
                        Text(
                            text = "To test Recharts spline curves, interactive tooltips, and ADG trajectories against breed benchmarks, generate realistic historical weights or record new ones.",
                            fontSize = 11.sp,
                            color = Color(0xFF78350F)
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(
                                onClick = {
                                    currentGoat?.let { g ->
                                        seedSampleGrowthTrajectoryForGoat(
                                            repository = repository,
                                            goat = g,
                                            benchmark = activeBenchmark,
                                            onDone = {
                                                Toast.makeText(context, "Generated 6-month weight history!", Toast.LENGTH_SHORT).show()
                                            }
                                        )
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD97706)),
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                                modifier = Modifier.testTag("btn_seed_growth_trajectory")
                            ) {
                                Icon(Icons.Default.Insights, contentDescription = null, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Generate 6M Benchmark Trajectory", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                            OutlinedButton(
                                onClick = { showRecordWeightDialog = true },
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                            ) {
                                Text("Log First Weight", fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                            }
                        }
                    }
                }
            }

            // Timeframe & Chart Engine Mode Bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Timeframe Pills
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    listOf("1M", "3M", "6M", "1Y", "ALL").forEach { tf ->
                        val isSel = selectedTimeframe == tf
                        Surface(
                            shape = RoundedCornerShape(20.dp),
                            color = if (isSel) FarmGreenDark else Color(0xFFE2E8F0),
                            modifier = Modifier
                                .clickable { selectedTimeframe = tf }
                                .testTag("timeframe_$tf")
                        ) {
                            Text(
                                text = tf,
                                fontSize = 11.sp,
                                fontWeight = if (isSel) FontWeight.Bold else FontWeight.Medium,
                                color = if (isSel) Color.White else Color(0xFF475569),
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                            )
                        }
                    }
                }

                // Chart Engine Toggle: Canvas (Smooth Compose) vs Web Recharts
                Row(
                    modifier = Modifier
                        .background(Color(0xFFE2E8F0), RoundedCornerShape(20.dp))
                        .padding(2.dp),
                    horizontalArrangement = Arrangement.spacedBy(2.dp)
                ) {
                    val isCanvas = chartEngineMode == "CANVAS"
                    Surface(
                        shape = RoundedCornerShape(18.dp),
                        color = if (isCanvas) Color.White else Color.Transparent,
                        modifier = Modifier.clickable { chartEngineMode = "CANVAS" }
                    ) {
                        Text(
                            text = "Native Canvas",
                            fontSize = 10.sp,
                            fontWeight = if (isCanvas) FontWeight.Bold else FontWeight.Normal,
                            color = if (isCanvas) FarmGreenDark else Color(0xFF64748B),
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                    Surface(
                        shape = RoundedCornerShape(18.dp),
                        color = if (!isCanvas) Color.White else Color.Transparent,
                        modifier = Modifier.clickable { chartEngineMode = "RECHARTS_WEB" }
                    ) {
                        Text(
                            text = "Recharts SVG",
                            fontSize = 10.sp,
                            fontWeight = if (!isCanvas) FontWeight.Bold else FontWeight.Normal,
                            color = if (!isCanvas) FarmGreenDark else Color(0xFF64748B),
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }
            }

            // PRIMARY RECHARTS DATA VISUALIZATION CARD
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("recharts_weight_visualization_card")
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Header with Recharts badge
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Surface(
                                shape = CircleShape,
                                color = Color(0xFF10B981).copy(alpha = 0.15f),
                                modifier = Modifier.size(32.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(Icons.AutoMirrored.Filled.TrendingUp, contentDescription = null, tint = Color(0xFF10B981), modifier = Modifier.size(18.dp))
                                }
                            }
                            Column {
                                Text(
                                    text = "Weight Progression vs Breed Average",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    color = Color(0xFF0F172A)
                                )
                                Text(
                                    text = "Recharts Monotone Spline with Expected Trajectory",
                                    fontSize = 10.sp,
                                    color = Color(0xFF64748B)
                                )
                            }
                        }

                        // Recharts Style Legend Badge
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = Color(0xFFF1F5F9),
                            modifier = Modifier.padding(start = 4.dp)
                        ) {
                            Text(
                                text = "Recharts v2.x",
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF0284C7),
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }

                    // Recharts Legend Bar
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Actual Weight Legend
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            Box(
                                modifier = Modifier
                                    .size(10.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFF10B981))
                            )
                            Text("Actual Weight (kg)", fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFF0F172A))
                        }

                        Spacer(modifier = Modifier.width(16.dp))

                        // Expected Average Legend
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            Box(
                                modifier = Modifier
                                    .width(14.dp)
                                    .height(3.dp)
                                    .background(Color(0xFFF59E0B))
                            )
                            Text("Expected ${activeBenchmark.breedName} Avg", fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFFD97706))
                        }
                    }

                    // Chart Rendering Container
                    if (chartPoints.isEmpty()) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(220.dp)
                                .background(Color(0xFFF8FAFC), RoundedCornerShape(12.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Icon(Icons.Default.Scale, contentDescription = null, tint = Color.LightGray, modifier = Modifier.size(36.dp))
                                Text("No weigh-ins found in the selected timeframe.", fontSize = 12.sp, color = Color.Gray)
                                Text("Tap '+ Weigh-in' to add measurements", fontSize = 11.sp, color = Color.Gray)
                            }
                        }
                    } else {
                        if (chartEngineMode == "CANVAS") {
                            RechartsComposeCanvasChart(
                                points = chartPoints,
                                marketTargetKg = marketTargetKg,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(260.dp)
                            )
                        } else {
                            RechartsWebInteractiveChart(
                                points = chartPoints,
                                breedName = activeBenchmark.breedName,
                                marketTargetKg = marketTargetKg,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(260.dp)
                            )
                        }
                    }

                    // Touch guide footer
                    Text(
                        text = "💡 Scrub across the chart to inspect date-by-date weights, variance, and ADG intervals.",
                        fontSize = 10.sp,
                        color = Color(0xFF94A3B8),
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }

            // GROWTH METRICS & ADG SUMMARY CARDS
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Current Weight
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = Color.White,
                    border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
                    modifier = Modifier.weight(1f)
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("Current Weight", fontSize = 10.sp, color = Color.Gray, fontWeight = FontWeight.SemiBold)
                        Text(
                            text = if (latestPoint != null) "${String.format(Locale.US, "%.1f", latestPoint.actualWeightKg)} kg" else "--",
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 16.sp,
                            color = Color(0xFF0F172A)
                        )
                        latestPoint?.let { lp ->
                            val isAbove = lp.varianceKg >= 0
                            Text(
                                text = "${if (isAbove) "+" else ""}${lp.varianceKg} kg vs avg",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isAbove) Color(0xFF15803D) else Color(0xFFDC2626)
                            )
                        }
                    }
                }

                // Average Daily Gain (ADG)
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = Color.White,
                    border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
                    modifier = Modifier.weight(1f)
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("Actual ADG", fontSize = 10.sp, color = Color.Gray, fontWeight = FontWeight.SemiBold)
                        Text(
                            text = if (overallAdgGrams != null) "$overallAdgGrams g/d" else "--",
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 16.sp,
                            color = Color(0xFF0284C7)
                        )
                        Text(
                            text = "Target: ${activeBenchmark.targetAdgGramsPerDay} g/d",
                            fontSize = 10.sp,
                            color = Color(0xFF64748B)
                        )
                    }
                }

                // Net Total Gain
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = Color.White,
                    border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
                    modifier = Modifier.weight(1f)
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("Net Gain", fontSize = 10.sp, color = Color.Gray, fontWeight = FontWeight.SemiBold)
                        val sign = if (totalGainKg >= 0) "+" else ""
                        Text(
                            text = if (chartPoints.size >= 2) "$sign${String.format(Locale.US, "%.1f", totalGainKg)} kg" else "--",
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 16.sp,
                            color = if (totalGainKg >= 0) Color(0xFF16A34A) else Color(0xFFDC2626)
                        )
                        Text(
                            text = "${chartPoints.size} weigh-ins",
                            fontSize = 10.sp,
                            color = Color(0xFF64748B)
                        )
                    }
                }
            }

            // TARGET WEIGHT PROGRESS & PROJECTIONS CARD
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Icon(Icons.Default.Flag, contentDescription = null, tint = Color(0xFF7C3AED), modifier = Modifier.size(18.dp))
                            Text(
                                text = "Market Weight Target Progress (${marketTargetKg} kg)",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = Color(0xFF1E293B)
                            )
                        }
                        Text(
                            text = "${targetProgressPct.roundToInt()}%",
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 14.sp,
                            color = Color(0xFF7C3AED)
                        )
                    }

                    LinearProgressIndicator(
                        progress = { (targetProgressPct / 100f).coerceIn(0f, 1f) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .clip(RoundedCornerShape(4.dp)),
                        color = Color(0xFF7C3AED),
                        trackColor = Color(0xFFEDE9FE)
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Current: ${String.format(Locale.US, "%.1f", currentWeightKg)} kg",
                            fontSize = 11.sp,
                            color = Color(0xFF64748B)
                        )
                        if (projectedDaysToTarget != null) {
                            Text(
                                text = "Est. $projectedDaysToTarget days to target weight",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = Color(0xFF059669)
                            )
                        } else if (currentWeightKg >= marketTargetKg) {
                            Text(
                                text = "🎯 Target market weight achieved!",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF059669)
                            )
                        } else {
                            Text(
                                text = "Keep logging to calculate target projection",
                                fontSize = 11.sp,
                                color = Color(0xFF94A3B8)
                            )
                        }
                    }
                }
            }

            // CHRONOLOGICAL WEIGH-IN LOG TABLE
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Historical Weigh-in Log (${chartPoints.size})",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = Color(0xFF0F172A)
                        )
                        TextButton(
                            onClick = { showRecordWeightDialog = true }
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Add Entry", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    HorizontalDivider(color = Color(0xFFF1F5F9))

                    if (chartPoints.isEmpty()) {
                        Text(
                            text = "No weights recorded yet.",
                            fontSize = 12.sp,
                            color = Color.Gray,
                            modifier = Modifier.padding(vertical = 8.dp)
                        )
                    } else {
                        // Show most recent first in table
                        chartPoints.reversed().take(10).forEach { pt ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 6.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Surface(
                                        shape = CircleShape,
                                        color = Color(0xFF10B981).copy(alpha = 0.15f),
                                        modifier = Modifier.size(32.dp)
                                    ) {
                                        Box(contentAlignment = Alignment.Center) {
                                            Text(
                                                text = "${pt.actualWeightKg.roundToInt()}",
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = FarmGreenDark
                                            )
                                        }
                                    }
                                    Column {
                                        Text(
                                            text = "${String.format(Locale.US, "%.1f", pt.actualWeightKg)} kg",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 13.sp,
                                            color = Color(0xFF0F172A)
                                        )
                                        Text(
                                            text = "${pt.dateStr} • ${pt.method}",
                                            fontSize = 10.sp,
                                            color = Color(0xFF64748B)
                                        )
                                    }
                                }

                                Column(horizontalAlignment = Alignment.End) {
                                    pt.gainSinceLastKg?.let { gain ->
                                        val isPlus = gain >= 0
                                        Surface(
                                            shape = RoundedCornerShape(4.dp),
                                            color = if (isPlus) Color(0xFFDCFCE7) else Color(0xFFFEE2E2)
                                        ) {
                                            Text(
                                                text = "${if (isPlus) "+" else ""}${String.format(Locale.US, "%.1f", gain)} kg",
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = if (isPlus) Color(0xFF15803D) else Color(0xFFB91C1C),
                                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                            )
                                        }
                                    }
                                    pt.intervalAdgGrams?.let { adg ->
                                        Text(
                                            text = "$adg g/d",
                                            fontSize = 10.sp,
                                            color = Color(0xFF0284C7),
                                            fontWeight = FontWeight.SemiBold
                                        )
                                    }
                                }
                            }
                            HorizontalDivider(color = Color(0xFFF8FAFC))
                        }
                    }
                }
            }
        }
    }

    // Modal Dialog to Record New Weight
    if (showRecordWeightDialog && currentGoat != null) {
        RecordWeightModalSheet(
            goat = currentGoat,
            onDismiss = { showRecordWeightDialog = false },
            onSaveWeight = { kg, dateStr, method, notes ->
                coroutineScope.launch {
                    val result = repository.recordWeight(
                        com.example.data.supabase.GoatWeight(
                            id = UUID.randomUUID().toString(),
                            goat_id_c = currentGoat.id,
                            weight_kg_c = kg,
                            date_c = dateStr,
                            method_c = method,
                            notes_c = notes
                        )
                    )
                    if (result.isSuccess) {
                        Toast.makeText(context, "Recorded $kg kg for ${currentGoat.tag_c}", Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(context, "Saved weight locally to database", Toast.LENGTH_SHORT).show()
                    }
                    showRecordWeightDialog = false
                }
            }
        )
    }
}

/**
 * 60 FPS Jetpack Compose Canvas implementation of the Recharts AreaChart & LineChart.
 * Renders monotone cubic spline, Cartesian grid lines, expected average dashed line,
 * target benchmark reference line, and interactive touch scrubbing with tooltips.
 */
@Composable
fun RechartsComposeCanvasChart(
    points: List<RechartsChartPoint>,
    marketTargetKg: Double,
    modifier: Modifier = Modifier
) {
    var selectedIndex by remember { mutableStateOf<Int?>(null) }

    val sorted = remember(points) { points.sortedBy { it.timestamp } }
    val minWeight = remember(sorted) {
        val minActual = sorted.minOfOrNull { it.actualWeightKg } ?: 0.0
        val minExpected = sorted.minOfOrNull { it.expectedWeightKg } ?: 0.0
        (minOf(minActual, minExpected) - 2.0).coerceAtLeast(0.0)
    }
    val maxWeight = remember(sorted, marketTargetKg) {
        val maxActual = sorted.maxOfOrNull { it.actualWeightKg } ?: 30.0
        val maxExpected = sorted.maxOfOrNull { it.expectedWeightKg } ?: 30.0
        maxOf(maxActual, maxExpected, marketTargetKg * 0.9) + 4.0
    }

    val selectedPoint = selectedIndex?.let { sorted.getOrNull(it) }

    Column(modifier = modifier) {
        // Floating Recharts Tooltip Overlay
        AnimatedVisibility(
            visible = selectedPoint != null,
            enter = fadeIn(),
            exit = fadeOut()
        ) {
            selectedPoint?.let { pt ->
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Color(0xFF1E293B),
                    shadowElevation = 4.dp,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 6.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(text = pt.dateStr, fontSize = 11.sp, color = Color(0xFF94A3B8))
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text(
                                    text = "Actual: ${String.format(Locale.US, "%.1f", pt.actualWeightKg)} kg",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF34D399)
                                )
                                Text(
                                    text = "| Expected: ${String.format(Locale.US, "%.1f", pt.expectedWeightKg)} kg",
                                    fontSize = 11.sp,
                                    color = Color(0xFFFBBF24)
                                )
                            }
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            val isGain = pt.varianceKg >= 0
                            Text(
                                text = "${if (isGain) "+" else ""}${pt.varianceKg} kg (${if (isGain) "+" else ""}${pt.variancePct}%)",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isGain) Color(0xFF4ADE80) else Color(0xFFF87171)
                            )
                            pt.intervalAdgGrams?.let { adg ->
                                Text(text = "$adg g/day", fontSize = 10.sp, color = Color(0xFF38BDF8))
                            }
                        }
                    }
                }
            }
        }

        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .pointerInput(sorted) {
                    detectTapGestures(
                        onPress = { offset ->
                            val leftPad = 40.dp.toPx()
                            val rightPad = 16.dp.toPx()
                            val usableWidth = size.width - leftPad - rightPad
                            if (usableWidth > 0 && sorted.isNotEmpty()) {
                                val relX = (offset.x - leftPad).coerceIn(0f, usableWidth)
                                val idx = if (sorted.size == 1) 0 else ((relX / usableWidth) * (sorted.size - 1)).roundToInt()
                                selectedIndex = idx.coerceIn(0, sorted.size - 1)
                            }
                        }
                    )
                }
        ) {
            val leftPad = 40.dp.toPx()
            val rightPad = 16.dp.toPx()
            val topPad = 12.dp.toPx()
            val bottomPad = 26.dp.toPx()

            val chartWidth = size.width - leftPad - rightPad
            val chartHeight = size.height - topPad - bottomPad

            if (chartWidth <= 0 || chartHeight <= 0) return@Canvas

            // 1. Cartesian Grid Horizontal Dotted Lines (Recharts signature)
            val gridSteps = 4
            val dashEffect = PathEffect.dashPathEffect(floatArrayOf(6f, 6f), 0f)
            val range = (maxWeight - minWeight).coerceAtLeast(1.0)

            for (step in 0..gridSteps) {
                val ratio = step.toFloat() / gridSteps
                val y = topPad + chartHeight * (1f - ratio)
                val weightVal = minWeight + range * ratio

                // Dotted horizontal grid
                drawLine(
                    color = Color(0xFFE2E8F0),
                    start = Offset(leftPad, y),
                    end = Offset(size.width - rightPad, y),
                    strokeWidth = 1.dp.toPx(),
                    pathEffect = dashEffect
                )
            }

            // 2. Reference Line: Market Target Weight (if within view range)
            if (marketTargetKg in minWeight..maxWeight) {
                val targetRatio = ((marketTargetKg - minWeight) / range).toFloat()
                val targetY = topPad + chartHeight * (1f - targetRatio)

                drawLine(
                    color = Color(0xFF8B5CF6),
                    start = Offset(leftPad, targetY),
                    end = Offset(size.width - rightPad, targetY),
                    strokeWidth = 1.5.dp.toPx(),
                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 6f), 0f)
                )
            }

            if (sorted.isEmpty()) return@Canvas

            // Compute Coordinates
            fun xForIndex(i: Int): Float {
                return if (sorted.size == 1) leftPad + chartWidth / 2f
                else leftPad + (i.toFloat() / (sorted.size - 1)) * chartWidth
            }

            fun yForWeight(kg: Double): Float {
                val ratio = ((kg - minWeight) / range).toFloat().coerceIn(0f, 1f)
                return topPad + chartHeight * (1f - ratio)
            }

            // 3. Expected Average Line (Dashed Amber)
            if (sorted.size >= 2) {
                val expectedPath = Path().apply {
                    moveTo(xForIndex(0), yForWeight(sorted[0].expectedWeightKg))
                    for (i in 1 until sorted.size) {
                        val prevX = xForIndex(i - 1)
                        val prevY = yForWeight(sorted[i - 1].expectedWeightKg)
                        val curX = xForIndex(i)
                        val curY = yForWeight(sorted[i].expectedWeightKg)

                        // Smooth spline control points
                        val midX = (prevX + curX) / 2f
                        cubicTo(midX, prevY, midX, curY, curX, curY)
                    }
                }

                drawPath(
                    path = expectedPath,
                    color = Color(0xFFF59E0B),
                    style = Stroke(
                        width = 2.dp.toPx(),
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 8f), 0f),
                        cap = StrokeCap.Round
                    )
                )
            }

            // 4. Actual Weight Area & Spline Line (Emerald Green)
            val actualPath = Path().apply {
                moveTo(xForIndex(0), yForWeight(sorted[0].actualWeightKg))
                for (i in 1 until sorted.size) {
                    val prevX = xForIndex(i - 1)
                    val prevY = yForWeight(sorted[i - 1].actualWeightKg)
                    val curX = xForIndex(i)
                    val curY = yForWeight(sorted[i].actualWeightKg)

                    val midX = (prevX + curX) / 2f
                    cubicTo(midX, prevY, midX, curY, curX, curY)
                }
            }

            // Area Gradient Fill under Actual Line
            val areaPath = Path().apply {
                addPath(actualPath)
                lineTo(xForIndex(sorted.size - 1), topPad + chartHeight)
                lineTo(xForIndex(0), topPad + chartHeight)
                close()
            }

            drawPath(
                path = areaPath,
                brush = Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFF10B981).copy(alpha = 0.35f),
                        Color(0xFF10B981).copy(alpha = 0.02f)
                    ),
                    startY = topPad,
                    endY = topPad + chartHeight
                )
            )

            // Draw Actual Weight Line
            drawPath(
                path = actualPath,
                color = Color(0xFF10B981),
                style = Stroke(
                    width = 3.dp.toPx(),
                    cap = StrokeCap.Round,
                    join = StrokeJoin.Round
                )
            )

            // 5. Data Dots (Active and Static)
            for (i in sorted.indices) {
                val cx = xForIndex(i)
                val cy = yForWeight(sorted[i].actualWeightKg)
                val isSelected = selectedIndex == i

                if (isSelected) {
                    // Outer halo
                    drawCircle(
                        color = Color(0xFF10B981).copy(alpha = 0.25f),
                        radius = 12.dp.toPx(),
                        center = Offset(cx, cy)
                    )
                    // Inner dot
                    drawCircle(
                        color = Color(0xFF10B981),
                        radius = 5.dp.toPx(),
                        center = Offset(cx, cy)
                    )
                    drawCircle(
                        color = Color.White,
                        radius = 2.5.dp.toPx(),
                        center = Offset(cx, cy)
                    )

                    // Vertical scrubber guideline
                    drawLine(
                        color = Color(0xFF94A3B8),
                        start = Offset(cx, topPad),
                        end = Offset(cx, topPad + chartHeight),
                        strokeWidth = 1.dp.toPx(),
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(4f, 4f), 0f)
                    )
                } else {
                    drawCircle(
                        color = Color.White,
                        radius = 4.dp.toPx(),
                        center = Offset(cx, cy)
                    )
                    drawCircle(
                        color = Color(0xFF10B981),
                        radius = 4.dp.toPx(),
                        style = Stroke(width = 2.dp.toPx()),
                        center = Offset(cx, cy)
                    )
                }
            }
        }
    }
}

/**
 * Embedded Recharts Web View rendering responsive HTML5 SVG chart.
 * Perfect for full Recharts ecosystem styling, interactive hovering, and brush control.
 */
@Composable
fun RechartsWebInteractiveChart(
    points: List<RechartsChartPoint>,
    breedName: String,
    marketTargetKg: Double,
    modifier: Modifier = Modifier
) {
    val htmlContent = remember(points, breedName, marketTargetKg) {
        generateRechartsHtml(points, breedName, marketTargetKg)
    }

    AndroidView(
        factory = { ctx ->
            WebView(ctx).apply {
                settings.javaScriptEnabled = true
                settings.domStorageEnabled = true
                settings.loadWithOverviewMode = true
                settings.useWideViewPort = true
                webViewClient = WebViewClient()
                setBackgroundColor(android.graphics.Color.TRANSPARENT)
            }
        },
        update = { webView ->
            webView.loadDataWithBaseURL(null, htmlContent, "text/html", "UTF-8", null)
        },
        modifier = modifier
    )
}

/**
 * Builds a clean, responsive HTML document incorporating Recharts SVG aesthetics,
 * interactive touch tooltips, and dynamic curve interpolation.
 */
private fun generateRechartsHtml(
    points: List<RechartsChartPoint>,
    breedName: String,
    marketTargetKg: Double
): String {
    val dataJson = buildString {
        append("[")
        points.forEachIndexed { i, p ->
            if (i > 0) append(",")
            append("""{"date":"${p.dateStr}","weight":${p.actualWeightKg},"expected":${p.expectedWeightKg},"gain":${p.varianceKg}}""")
        }
        append("]")
    }

    return """
        <!DOCTYPE html>
        <html>
        <head>
          <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
          <style>
            * { box-sizing: border-box; margin: 0; padding: 0; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; }
            body { background: #ffffff; padding: 10px; overflow: hidden; }
            .chart-title { font-size: 11px; color: #64748b; margin-bottom: 6px; text-align: right; }
            svg { width: 100%; height: 210px; display: block; }
            .grid-line { stroke: #e2e8f0; stroke-dasharray: 4,4; stroke-width: 1; }
            .line-actual { fill: none; stroke: #10b981; stroke-width: 3; stroke-linecap: round; }
            .line-expected { fill: none; stroke: #f59e0b; stroke-width: 2; stroke-dasharray: 6,4; }
            .line-target { fill: none; stroke: #8b5cf6; stroke-width: 1.5; stroke-dasharray: 8,4; }
            .dot { fill: #ffffff; stroke: #10b981; stroke-width: 2; r: 4; }
            .dot:hover { r: 7; fill: #10b981; stroke: #ffffff; }
            .label { font-size: 9px; fill: #94a3b8; }
            .tooltip {
              position: absolute; display: none; background: #1e293b; color: #fff;
              padding: 6px 10px; border-radius: 6px; font-size: 11px; pointer-events: none;
              box-shadow: 0 4px 6px -1px rgba(0,0,0,0.1);
            }
          </style>
        </head>
        <body>
          <div class="chart-title">Recharts Interactive View</div>
          <div id="chart-container" style="position:relative;">
            <svg id="chart" viewBox="0 0 500 210">
              <defs>
                <linearGradient id="areaGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stop-color="#10b981" stop-opacity="0.35" />
                  <stop offset="100%" stop-color="#10b981" stop-opacity="0.02" />
                </linearGradient>
              </defs>
              <!-- Grid -->
              <line x1="40" y1="30" x2="480" y2="30" class="grid-line" />
              <line x1="40" y1="80" x2="480" y2="80" class="grid-line" />
              <line x1="40" y1="130" x2="480" y2="130" class="grid-line" />
              <line x1="40" y1="180" x2="480" y2="180" class="grid-line" />

              <path id="area" fill="url(#areaGrad)" />
              <path id="expected-path" class="line-expected" />
              <path id="actual-path" class="line-actual" />
              <g id="dots"></g>
              <g id="x-labels"></g>
            </svg>
            <div id="tooltip" class="tooltip"></div>
          </div>

          <script>
            const data = $dataJson;
            if (data.length > 0) {
              const minW = Math.min(...data.map(d => Math.min(d.weight, d.expected))) - 2;
              const maxW = Math.max(...data.map(d => Math.max(d.weight, d.expected)), $marketTargetKg) + 3;
              const range = Math.max(1, maxW - minW);

              const left = 40, right = 480, top = 20, bottom = 180;
              const w = right - left, h = bottom - top;

              const getX = (i) => data.length === 1 ? left + w/2 : left + (i / (data.length - 1)) * w;
              const getY = (val) => bottom - ((val - minW) / range) * h;

              // Actual path
              let actD = "M " + getX(0) + " " + getY(data[0].weight);
              let expD = "M " + getX(0) + " " + getY(data[0].expected);

              for (let i = 1; i < data.length; i++) {
                const x0 = getX(i-1), y0 = getY(data[i-1].weight);
                const x1 = getX(i), y1 = getY(data[i].weight);
                const mx = (x0 + x1) / 2;
                actD += " C " + mx + " " + y0 + ", " + mx + " " + y1 + ", " + x1 + " " + y1;

                const ex0 = getY(data[i-1].expected);
                const ex1 = getY(data[i].expected);
                expD += " C " + mx + " " + ex0 + ", " + mx + " " + ex1 + ", " + x1 + " " + ex1;
              }

              document.getElementById("actual-path").setAttribute("d", actD);
              document.getElementById("expected-path").setAttribute("d", expD);

              // Area
              const areaD = actD + " L " + getX(data.length-1) + " " + bottom + " L " + getX(0) + " " + bottom + " Z";
              document.getElementById("area").setAttribute("d", areaD);

              // Dots
              const dotsG = document.getElementById("dots");
              const xLabelsG = document.getElementById("x-labels");
              const tip = document.getElementById("tooltip");

              data.forEach((d, idx) => {
                const cx = getX(idx);
                const cy = getY(d.weight);

                const circle = document.createElementNS("http://www.w3.org/2000/svg", "circle");
                circle.setAttribute("cx", cx);
                circle.setAttribute("cy", cy);
                circle.setAttribute("class", "dot");

                circle.addEventListener("click", (e) => {
                  tip.style.display = "block";
                  tip.style.left = (cx * 0.7) + "px";
                  tip.style.top = (cy * 0.7 - 25) + "px";
                  tip.innerHTML = "<b>" + d.date + "</b><br/>Actual: " + d.weight + " kg<br/>Expected: " + d.expected + " kg";
                });

                dotsG.appendChild(circle);

                // Date label
                if (data.length <= 6 || idx % 2 === 0) {
                  const text = document.createElementNS("http://www.w3.org/2000/svg", "text");
                  text.setAttribute("x", cx);
                  text.setAttribute("y", bottom + 16);
                  text.setAttribute("text-anchor", "middle");
                  text.setAttribute("class", "label");
                  text.textContent = d.date.substring(5);
                  xLabelsG.appendChild(text);
                }
              });
            }
          </script>
        </body>
        </html>
    """.trimIndent()
}

/**
 * Modal Bottom Sheet for quickly recording a weigh-in.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RecordWeightModalSheet(
    goat: Goat,
    onDismiss: () -> Unit,
    onSaveWeight: (Double, String, String, String?) -> Unit
) {
    val dateFormat = remember { SimpleDateFormat("yyyy-MM-dd", Locale.US) }
    var weightInput by remember { mutableStateOf(goat.weight_kg_c?.let { String.format(Locale.US, "%.1f", it) } ?: "25.0") }
    var dateInput by remember { mutableStateOf(dateFormat.format(Date())) }
    var methodInput by remember { mutableStateOf("Scale") }
    var notesInput by remember { mutableStateOf("") }
    val methods = listOf("Scale", "Weight Tape", "Visual Estimate")

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp),
        containerColor = Color.White
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .padding(bottom = 36.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Record Weigh-in",
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,
                        color = Color(0xFF0F172A)
                    )
                    Text(
                        text = "${goat.tag_c} • ${goat.name}",
                        fontSize = 12.sp,
                        color = Color(0xFF64748B)
                    )
                }
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Default.Close, contentDescription = "Close")
                }
            }

            HorizontalDivider(color = Color(0xFFF1F5F9))

            // Weight Field with +/- quick stepper
            Text("Weight in Kilograms (kg) *", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = Color.DarkGray)
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                IconButton(
                    onClick = {
                        val curr = weightInput.toDoubleOrNull() ?: 25.0
                        weightInput = String.format(Locale.US, "%.1f", (curr - 0.5).coerceAtLeast(1.0))
                    },
                    modifier = Modifier
                        .background(Color(0xFFF1F5F9), CircleShape)
                        .size(40.dp)
                ) {
                    Icon(Icons.Default.Remove, contentDescription = "Minus 0.5kg")
                }

                OutlinedTextField(
                    value = weightInput,
                    onValueChange = { weightInput = it },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    modifier = Modifier.weight(1f).testTag("input_modal_weight"),
                    singleLine = true,
                    textStyle = LocalTextStyle.current.copy(textAlign = TextAlign.Center, fontWeight = FontWeight.Bold, fontSize = 18.sp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = FarmGreenDark,
                        unfocusedBorderColor = Color(0xFFCBD5E1)
                    )
                )

                IconButton(
                    onClick = {
                        val curr = weightInput.toDoubleOrNull() ?: 25.0
                        weightInput = String.format(Locale.US, "%.1f", (curr + 0.5))
                    },
                    modifier = Modifier
                        .background(Color(0xFFF1F5F9), CircleShape)
                        .size(40.dp)
                ) {
                    Icon(Icons.Default.Add, contentDescription = "Plus 0.5kg")
                }
            }

            // Date Field
            DatePickerField(
                dateValue = dateInput,
                onDateSelected = { dateInput = it },
                label = "Date Measured *"
            )

            // Method Selector
            Text("Measurement Method", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = Color.DarkGray)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                methods.forEach { m ->
                    FilterChip(
                        selected = methodInput == m,
                        onClick = { methodInput = m },
                        label = { Text(m, fontSize = 11.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = FarmGreenDark,
                            selectedLabelColor = Color.White
                        )
                    )
                }
            }

            // Notes
            OutlinedTextField(
                value = notesInput,
                onValueChange = { notesInput = it },
                label = { Text("Notes (optional)", fontSize = 12.sp) },
                modifier = Modifier.fillMaxWidth(),
                maxLines = 2
            )

            // Save Button
            Button(
                onClick = {
                    val kg = weightInput.toDoubleOrNull()
                    if (kg != null && kg > 0) {
                        onSaveWeight(kg, dateInput, methodInput, notesInput.ifBlank { null })
                    }
                },
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(containerColor = FarmGreenPrimary),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("btn_save_modal_weight")
            ) {
                Icon(Icons.Default.Check, contentDescription = null)
                Spacer(modifier = Modifier.width(6.dp))
                Text("Save Weigh-in Record", fontWeight = FontWeight.Bold, fontSize = 14.sp)
            }
        }
    }
}

/**
 * Seeds a realistic 6-month growth curve with realistic monthly weight gain so that
 * the user can immediately experience the Recharts visualization.
 */
fun seedSampleGrowthTrajectoryForGoat(
    repository: GoatRepository,
    goat: Goat,
    benchmark: BreedGrowthBenchmark,
    onDone: () -> Unit
) {
    kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.IO).launch {
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        val now = System.currentTimeMillis()

        // Base start weight 180 days ago
        val startKg = (goat.weight_kg_c?.minus(12.0) ?: 16.0).coerceAtLeast(benchmark.birthWeightKg)
        val dailyGain = (benchmark.targetAdgGramsPerDay / 1000.0) * (0.95 + (goat.id.hashCode() % 10) * 0.015)

        // Generate 6 data points over 180 days
        val checkpoints = listOf(180L, 145L, 110L, 75L, 40L, 5L)
        checkpoints.forEachIndexed { idx, daysAgo ->
            val pointTime = now - daysAgo * 86400000L
            val dateStr = sdf.format(Date(pointTime))
            val daysFromStart = 180 - daysAgo
            val calculatedWeight = startKg + (dailyGain * daysFromStart) + (if (idx % 2 == 0) 0.3 else -0.2)
            val roundedKg = ((calculatedWeight * 10.0).roundToInt()) / 10.0

            repository.recordWeight(
                com.example.data.supabase.GoatWeight(
                    id = UUID.randomUUID().toString(),
                    goat_id_c = goat.id,
                    weight_kg_c = roundedKg,
                    date_c = dateStr,
                    method_c = if (idx % 2 == 0) "Scale" else "Weight Tape",
                    notes_c = "Growth benchmark check: day $daysFromStart"
                )
            )
        }
        kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) {
            onDone()
        }
    }
}
