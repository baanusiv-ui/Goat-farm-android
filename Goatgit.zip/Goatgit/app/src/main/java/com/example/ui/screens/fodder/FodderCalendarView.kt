package com.example.ui.screens.fodder

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.fodder.CultivationCalendarEvent
import com.example.data.fodder.FodderRepository
import com.example.ui.theme.*
import kotlinx.coroutines.launch

@Composable
fun FodderCalendarView(
    repository: FodderRepository,
    onNavigateToCut: (plotId: String) -> Unit,
    modifier: Modifier = Modifier
) {
    var events by remember { mutableStateOf<List<CultivationCalendarEvent>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }
    var filterType by remember { mutableStateOf("All") }

    val coroutineScope = rememberCoroutineScope()

    LaunchedEffect(Unit) {
        isLoading = true
        events = repository.getCultivationCalendarEvents()
        isLoading = false
    }

    val filteredEvents = remember(events, filterType) {
        if (filterType == "All") events
        else if (filterType == "Due / Overdue") events.filter { !it.isCompleted }
        else events.filter { it.isCompleted }
    }

    val overdueCount = remember(events) { events.count { it.isOverdue } }
    val dueCount = remember(events) { events.count { !it.isCompleted && !it.isOverdue } }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    text = "Cultivation & Cutting Calendar",
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.titleLarge,
                    color = FarmGreenDark
                )
                Text(
                    text = "Track crop cycles, scheduled cuts, regrowth milestones, and field operations across all fodder plots.",
                    fontSize = 12.sp,
                    color = Color.Gray
                )
            }
        }

        // Status Banners: Overdue and Upcoming Cuts
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = if (overdueCount > 0) Color(0xFFFFEBEE) else Color(0xFFF1F8E9),
                    modifier = Modifier.weight(1f)
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = if (overdueCount > 0) Icons.Default.Warning else Icons.Default.CheckCircle,
                            contentDescription = null,
                            tint = if (overdueCount > 0) FarmError else FarmGreenDark,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = if (overdueCount > 0) "$overdueCount Overdue Cuts" else "No Overdue Cuts",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = if (overdueCount > 0) FarmError else FarmGreenDark
                            )
                            Text(
                                text = if (overdueCount > 0) "Immediate harvest needed" else "Harvests up to date",
                                fontSize = 10.sp,
                                color = Color.Gray
                            )
                        }
                    }
                }

                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = Color(0xFFE1F5FE),
                    modifier = Modifier.weight(1f)
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.CalendarToday,
                            contentDescription = null,
                            tint = Color(0xFF0277BD),
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = "$dueCount Scheduled Cuts",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = Color(0xFF0277BD)
                            )
                            Text(
                                text = "Next 45 days forecast",
                                fontSize = 10.sp,
                                color = Color.Gray
                            )
                        }
                    }
                }
            }
        }

        // Filter chips
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf("All", "Due / Overdue", "Completed History").forEach { filter ->
                    FilterChip(
                        selected = filterType == filter,
                        onClick = { filterType = filter },
                        label = { Text(filter, fontSize = 11.sp) },
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        if (isLoading) {
            item {
                Box(modifier = Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = FarmGreenDark)
                }
            }
        } else if (filteredEvents.isEmpty()) {
            item {
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.fillMaxWidth().padding(32.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(Icons.Default.EventAvailable, contentDescription = null, tint = Color.LightGray, modifier = Modifier.size(48.dp))
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("No calendar events found for this filter.", color = Color.Gray, fontSize = 13.sp)
                    }
                }
            }
        } else {
            items(filteredEvents, key = { it.id }) { ev ->
                CalendarEventRow(event = ev, onRecordCut = { onNavigateToCut(ev.plotId) })
            }
        }

        item { Spacer(modifier = Modifier.height(48.dp)) }
    }
}

@Composable
private fun CalendarEventRow(
    event: CultivationCalendarEvent,
    onRecordCut: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (event.isOverdue) Color(0xFFFFF8F8) else Color.White
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("calendar_event_${event.id}")
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Date Badge
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = when {
                    event.isOverdue -> Color(0xFFFFCDD2)
                    !event.isCompleted -> Color(0xFFBBDEFB)
                    else -> Color(0xFFE8F5E9)
                },
                modifier = Modifier.size(54.dp)
            ) {
                Column(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    val parts = event.eventDate.split("-")
                    val month = if (parts.size > 1) {
                        when (parts[1]) {
                            "01" -> "JAN"; "02" -> "FEB"; "03" -> "MAR"; "04" -> "APR"
                            "05" -> "MAY"; "06" -> "JUN"; "07" -> "JUL"; "08" -> "AUG"
                            "09" -> "SEP"; "10" -> "OCT"; "11" -> "NOV"; else -> "DEC"
                        }
                    } else "DATE"
                    val day = parts.lastOrNull() ?: "01"
                    Text(text = month, fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color.DarkGray)
                    Text(
                        text = day,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (event.isOverdue) FarmError else FarmGreenDark
                    )
                }
            }

            Spacer(modifier = Modifier.width(12.dp))

            // Details
            Column(modifier = Modifier.weight(1f)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = event.eventType,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = if (event.isOverdue) FarmError else if (!event.isCompleted) Color(0xFF0277BD) else FarmGreenDark
                    )
                    if (event.isOverdue) {
                        Surface(
                            shape = RoundedCornerShape(4.dp),
                            color = FarmError
                        ) {
                            Text("OVERDUE", color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp))
                        }
                    }
                }
                Text(
                    text = "${event.plotName} • ${event.speciesName}",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = Color.DarkGray
                )
                Text(
                    text = event.description,
                    fontSize = 10.sp,
                    color = Color.Gray,
                    maxLines = 2
                )
            }

            // Action Button for Due / Overdue cuts
            if (!event.isCompleted) {
                Spacer(modifier = Modifier.width(6.dp))
                Button(
                    onClick = onRecordCut,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (event.isOverdue) FarmError else FarmGreenDark
                    ),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(Icons.Default.ContentCut, contentDescription = null, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Cut", fontSize = 11.sp)
                }
            }
        }
    }
}
