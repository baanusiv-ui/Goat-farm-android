package com.example.ui.screens.health

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.TrendingUp
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.supabase.*
import com.example.ui.theme.*
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HealthDashboardScreen(
    repository: GoatRepository,
    onNavigateBack: () -> Unit,
    onNavigateToVaccination: () -> Unit,
    onNavigateToDeworming: () -> Unit,
    onNavigateToTreatment: () -> Unit,
    onNavigateToHealthHistory: () -> Unit,
    onNavigateToAlerts: () -> Unit,
    onNavigateToQuarantine: () -> Unit,
    onNavigateToReports: () -> Unit,
    onNavigateToCamera: () -> Unit = {},
    onNavigateToDailyObservation: () -> Unit = {},
    onNavigateToTrends: () -> Unit = {},
    onNavigateToRecurringHealthTracking: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    BackHandler { onNavigateBack() }

    val coroutineScope = rememberCoroutineScope()
    var summary by remember { mutableStateOf<HealthDashboardSummary?>(null) }
    var alerts by remember { mutableStateOf<List<HealthAlert>>(emptyList()) }
    var goatsList by remember { mutableStateOf<List<Goat>>(emptyList()) }
    var showVaccinationRecordDialog by remember { mutableStateOf(false) }
    var isLoading by remember { mutableStateOf(true) }

    fun loadData() {
        isLoading = true
        coroutineScope.launch {
            repository.seedTanuvasSchedulesIfEmpty()
            val sumRes = repository.getHealthDashboardSummary()
            if (sumRes.isSuccess) summary = sumRes.getOrThrow()

            val altRes = repository.getHealthAlerts()
            if (altRes.isSuccess) alerts = altRes.getOrThrow()

            val gRes = repository.getGoats()
            if (gRes.isSuccess) goatsList = gRes.getOrThrow()

            isLoading = false
        }
    }

    LaunchedEffect(Unit) {
        loadData()
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "Health & Clinical Care",
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp
                        )
                        Text(
                            text = "Vaccination, Deworming, Treatment & Quarantine",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                navigationIcon = {
                    IconButton(
                        onClick = onNavigateBack,
                        modifier = Modifier.testTag("health_btn_back")
                    ) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(
                        onClick = { showVaccinationRecordDialog = true },
                        modifier = Modifier.testTag("health_btn_add_vaccination")
                    ) {
                        Icon(Icons.Default.AddCircle, contentDescription = "Log Vaccination Record", tint = Color(0xFF0284C7))
                    }
                    IconButton(
                        onClick = onNavigateToTrends,
                        modifier = Modifier.testTag("health_btn_trends")
                    ) {
                        Icon(Icons.AutoMirrored.Filled.TrendingUp, contentDescription = "Trends & Analytics")
                    }
                    IconButton(
                        onClick = onNavigateToCamera,
                        modifier = Modifier.testTag("health_btn_camera")
                    ) {
                        Icon(Icons.Default.PhotoCamera, contentDescription = "Camera Documentation")
                    }
                    IconButton(onClick = onNavigateToReports) {
                        Icon(Icons.Default.Assessment, contentDescription = "Reports")
                    }
                }
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { showVaccinationRecordDialog = true },
                containerColor = Color(0xFF0284C7),
                contentColor = Color.White,
                icon = { Icon(Icons.Default.Add, contentDescription = null) },
                text = { Text("Log Vaccination", fontWeight = FontWeight.Bold) },
                modifier = Modifier.testTag("fab_log_vaccination")
            )
        }
    ) { padding ->
        if (isLoading) {
            Box(modifier = Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = FarmGreenPrimary)
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xFFF8FAFC))
                    .padding(padding)
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // 1. TANUVAS Reference Banner with Medical Safety Disclaimer (Requirement 2 & 23)
                item {
                    Surface(
                        color = Color(0xFFEFF6FF),
                        shape = RoundedCornerShape(12.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFBFDBFE)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFFDBEAFE)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.Verified, contentDescription = null, tint = Color(0xFF1D4ED8))
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "TANUVAS Reference Schedule Active",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    color = Color(0xFF1E40AF)
                                )
                                Text(
                                    text = "Reference guidance only. Confirm timing, doses, and disease risks with your local veterinarian/animal-health authority.",
                                    fontSize = 10.sp,
                                    color = Color(0xFF334155),
                                    lineHeight = 14.sp
                                )
                            }
                        }
                    }
                }

                // 2. Health KPI Quick Status Bar
                item {
                    val s = summary ?: HealthDashboardSummary()
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        HealthKpiTile(
                            title = "Herd Size",
                            value = "${s.totalGoats}",
                            icon = Icons.Default.Pets,
                            color = FarmGreenDark,
                            bgColor = Color(0xFFE8F5E9),
                            modifier = Modifier.weight(1f)
                        )
                        HealthKpiTile(
                            title = "Quarantined",
                            value = "${s.activeQuarantineCount}",
                            icon = Icons.Default.Shield,
                            color = if (s.activeQuarantineCount > 0) Color(0xFFD97706) else Color.Gray,
                            bgColor = if (s.activeQuarantineCount > 0) Color(0xFFFEF3C7) else Color(0xFFF1F5F9),
                            modifier = Modifier.weight(1f),
                            onClick = onNavigateToQuarantine
                        )
                        HealthKpiTile(
                            title = "Treatment",
                            value = "${s.activeTreatmentsCount}",
                            icon = Icons.Default.MedicalServices,
                            color = if (s.activeTreatmentsCount > 0) Color(0xFF0284C7) else Color.Gray,
                            bgColor = if (s.activeTreatmentsCount > 0) Color(0xFFE0F2FE) else Color(0xFFF1F5F9),
                            modifier = Modifier.weight(1f),
                            onClick = onNavigateToTreatment
                        )
                        HealthKpiTile(
                            title = "Alerts",
                            value = "${s.totalHealthAlertsCount}",
                            icon = Icons.Default.WarningAmber,
                            color = if (s.totalHealthAlertsCount > 0) Color(0xFFDC2626) else FarmGreenDark,
                            bgColor = if (s.totalHealthAlertsCount > 0) Color(0xFFFEE2E2) else Color(0xFFDCFCE7),
                            modifier = Modifier.weight(1f),
                            onClick = onNavigateToAlerts
                        )
                    }
                }

                // Dedicated Vaccination Record & Booster Shot Reminders Feature Card
                item {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("card_vaccination_record_feature"),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        shape = RoundedCornerShape(16.dp),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFBAE6FD))
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(40.dp)
                                            .clip(CircleShape)
                                            .background(Color(0xFFE0F2FE)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Vaccines,
                                            contentDescription = null,
                                            tint = Color(0xFF0284C7),
                                            modifier = Modifier.size(22.dp)
                                        )
                                    }
                                    Column {
                                        Text(
                                            text = "Vaccination Records & Booster Hub",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 15.sp,
                                            color = Color(0xFF0F172A)
                                        )
                                        Text(
                                            text = "Log dates, drug types & set automated booster shot alerts",
                                            fontSize = 11.sp,
                                            color = Color(0xFF64748B)
                                        )
                                    }
                                }
                            }

                            // Quick Drug Types Classification Pills
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Surface(
                                    color = Color(0xFFF1F5F9),
                                    shape = RoundedCornerShape(6.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Column(
                                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 6.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally
                                    ) {
                                        Text("INACTIVATED", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color(0xFF334155))
                                        Text("CCPP, FMD, HS", fontSize = 8.sp, color = Color.Gray)
                                    }
                                }
                                Surface(
                                    color = Color(0xFFF0FDF4),
                                    shape = RoundedCornerShape(6.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Column(
                                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 6.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally
                                    ) {
                                        Text("LIVE ATTENUATED", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color(0xFF15803D))
                                        Text("PPR, Goat Pox", fontSize = 8.sp, color = Color.Gray)
                                    }
                                }
                                Surface(
                                    color = Color(0xFFFEF3C7),
                                    shape = RoundedCornerShape(6.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Column(
                                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 6.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally
                                    ) {
                                        Text("TOXOIDS", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color(0xFFB45309))
                                        Text("ET, Tetanus", fontSize = 8.sp, color = Color.Gray)
                                    }
                                }
                            }

                            // Action Buttons
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Button(
                                    onClick = { showVaccinationRecordDialog = true },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7)),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("btn_log_vaccination_record")
                                ) {
                                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(Modifier.width(6.dp))
                                    Text("Log Record", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                }

                                OutlinedButton(
                                    onClick = onNavigateToVaccination,
                                    shape = RoundedCornerShape(10.dp),
                                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF0284C7)),
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("btn_view_vaccination_schedule")
                                ) {
                                    Icon(Icons.Default.Event, contentDescription = null, tint = Color(0xFF0284C7), modifier = Modifier.size(16.dp))
                                    Spacer(Modifier.width(6.dp))
                                    Text("Full Protocol", color = Color(0xFF0284C7), fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                                }
                            }
                        }
                    }
                }

                // 3. Main Functional Modules Navigation (Requirement 1)
                item {
                    Text(
                        text = "CLINICAL & PREVENTIVE MODULES",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.Gray,
                        letterSpacing = 0.5.sp
                    )
                }

                item {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            HealthModuleCard(
                                title = "Vaccination",
                                subtitle = "Upcoming, overdue, multi-goat & TANUVAS",
                                icon = Icons.Default.Vaccines,
                                color = Color(0xFF0284C7),
                                bgColor = Color(0xFFE0F2FE),
                                badge = (summary?.vaccinationDueCount ?: 0) + (summary?.vaccinationOverdueCount ?: 0),
                                modifier = Modifier.weight(1f).testTag("btn_health_vaccination"),
                                onClick = onNavigateToVaccination
                            )
                            HealthModuleCard(
                                title = "Deworming",
                                subtitle = "Age schedule, dose calculator & rotation protocol",
                                icon = Icons.Default.Medication,
                                color = Color(0xFF059669),
                                bgColor = Color(0xFFD1FAE5),
                                badge = (summary?.dewormingDueCount ?: 0) + (summary?.dewormingOverdueCount ?: 0),
                                modifier = Modifier.weight(1f).testTag("btn_health_deworming"),
                                onClick = onNavigateToDeworming
                            )
                        }

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            HealthModuleCard(
                                title = "Treatment",
                                subtitle = "Clinical complaints, diagnoses & outcomes",
                                icon = Icons.Default.Healing,
                                color = Color(0xFF9333EA),
                                bgColor = Color(0xFFF3E8FF),
                                badge = summary?.activeTreatmentsCount ?: 0,
                                modifier = Modifier.weight(1f).testTag("btn_health_treatment"),
                                onClick = onNavigateToTreatment
                            )
                            HealthModuleCard(
                                title = "Quarantine Station",
                                subtitle = "Market purchase isolation & 11-pt checklist",
                                icon = Icons.Default.Security,
                                color = Color(0xFFD97706),
                                bgColor = Color(0xFFFEF3C7),
                                badge = summary?.activeQuarantineCount ?: 0,
                                modifier = Modifier.weight(1f).testTag("btn_health_quarantine"),
                                onClick = onNavigateToQuarantine
                            )
                        }

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            HealthModuleCard(
                                title = "Health History",
                                subtitle = "Unified timeline of vaccinations & care",
                                icon = Icons.Default.History,
                                color = Color(0xFF475569),
                                bgColor = Color(0xFFF1F5F9),
                                modifier = Modifier.weight(1f).testTag("btn_health_history"),
                                onClick = onNavigateToHealthHistory
                            )
                            HealthModuleCard(
                                title = "Due / Overdue Alerts",
                                subtitle = "Actionable health & veterinary reminders",
                                icon = Icons.Default.NotificationsActive,
                                color = Color(0xFFDC2626),
                                bgColor = Color(0xFFFEE2E2),
                                badge = summary?.totalHealthAlertsCount ?: 0,
                                modifier = Modifier.weight(1f).testTag("btn_health_alerts"),
                                onClick = onNavigateToAlerts
                            )
                        }

                        HealthModuleCard(
                            title = "Recurring Health & Weight Tracking",
                            subtitle = "Scheduled weigh-in intervals, ADG growth tracking & timestamped weight logs in Room DB",
                            icon = Icons.Default.Scale,
                            color = Color(0xFF0D9488),
                            bgColor = Color(0xFFCCFBF1),
                            modifier = Modifier.fillMaxWidth().testTag("btn_recurring_health_tracking"),
                            onClick = onNavigateToRecurringHealthTracking
                        )

                        HealthModuleCard(
                            title = "Health Trends & Data Visualization",
                            subtitle = "Interactive Recharts/D3 spline curves, Average Daily Gain (ADG) & intervention frequency from Room DB",
                            icon = Icons.AutoMirrored.Filled.TrendingUp,
                            color = Color(0xFF059669),
                            bgColor = Color(0xFFD1FAE5),
                            modifier = Modifier.fillMaxWidth().testTag("btn_health_trends_analytics"),
                            onClick = onNavigateToTrends
                        )

                        HealthModuleCard(
                            title = "Daily Health Observations",
                            subtitle = "Input daily vitals, temperature, FAMACHA score, rumen motility, stool & appetite with Room local persistence",
                            icon = Icons.Default.EditNote,
                            color = Color(0xFF16A34A),
                            bgColor = Color(0xFFDCFCE7),
                            modifier = Modifier.fillMaxWidth().testTag("btn_daily_health_observation"),
                            onClick = onNavigateToDailyObservation
                        )

                        HealthModuleCard(
                            title = "Clinical Photo Documentation",
                            subtitle = "Capture & log lesions, eye mucosa (FAMACHA), hoof & udder condition with CameraX",
                            icon = Icons.Default.PhotoCamera,
                            color = Color(0xFF0D9488),
                            bgColor = Color(0xFFCCFBF1),
                            modifier = Modifier.fillMaxWidth().testTag("btn_health_camera"),
                            onClick = onNavigateToCamera
                        )
                    }
                }

                // 4. Actionable Health Alerts Preview (Requirement 9)
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "ACTIONABLE HEALTH ALERTS (${alerts.size})",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.Gray,
                            letterSpacing = 0.5.sp
                        )
                        if (alerts.isNotEmpty()) {
                            TextButton(onClick = onNavigateToAlerts) {
                                Text("View All", fontSize = 11.sp, color = FarmGreenDark)
                            }
                        }
                    }
                }

                if (alerts.isEmpty()) {
                    item {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.CheckCircle, contentDescription = null, tint = FarmGreenDark)
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text("All Health Protocols Up-to-date", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                    Text("No overdue vaccinations, dewormings, or pending quarantine clearances.", fontSize = 11.sp, color = Color.Gray)
                                }
                            }
                        }
                    }
                } else {
                    items(alerts.take(4)) { alert ->
                        HealthAlertPreviewCard(alert = alert, onClick = onNavigateToAlerts)
                    }
                }

                item {
                    Spacer(modifier = Modifier.height(24.dp))
                }
            }
        }
    }

    if (showVaccinationRecordDialog) {
        VaccinationRecordDialog(
            goats = goatsList,
            onDismiss = { showVaccinationRecordDialog = false },
            onSaveSuccess = {
                showVaccinationRecordDialog = false
                loadData()
            },
            repository = repository
        )
    }
}

@Composable
private fun HealthKpiTile(
    title: String,
    value: String,
    icon: ImageVector,
    color: Color,
    bgColor: Color,
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null
) {
    Surface(
        color = bgColor,
        shape = RoundedCornerShape(10.dp),
        modifier = modifier.clickable(enabled = onClick != null) { onClick?.invoke() }
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.height(4.dp))
            Text(text = value, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = color)
            Text(text = title, fontSize = 10.sp, color = Color.DarkGray, maxLines = 1)
        }
    }
}

@Composable
private fun HealthModuleCard(
    title: String,
    subtitle: String,
    icon: ImageVector,
    color: Color,
    bgColor: Color,
    badge: Int = 0,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Card(
        onClick = onClick,
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(12.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = modifier
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(bgColor),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(20.dp))
                }

                if (badge > 0) {
                    Surface(
                        color = Color(0xFFDC2626),
                        shape = CircleShape,
                        modifier = Modifier.size(22.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Text(
                                text = if (badge > 99) "99+" else "$badge",
                                color = Color.White,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            Text(text = title, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color(0xFF1E293B))
            Text(text = subtitle, fontSize = 10.sp, color = Color.Gray, lineHeight = 13.sp, maxLines = 2)
        }
    }
}

@Composable
private fun HealthAlertPreviewCard(
    alert: HealthAlert,
    onClick: () -> Unit
) {
    val borderColor = when (alert.severity) {
        "URGENT" -> Color(0xFFFCA5A5)
        "WARNING" -> Color(0xFFFDE68A)
        else -> Color(0xFFBFDBFE)
    }
    val iconColor = when (alert.severity) {
        "URGENT" -> Color(0xFFDC2626)
        "WARNING" -> Color(0xFFD97706)
        else -> Color(0xFF2563EB)
    }

    Card(
        onClick = onClick,
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(10.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, borderColor),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                if (alert.severity == "URGENT") Icons.Default.Error else Icons.Default.Warning,
                contentDescription = null,
                tint = iconColor,
                modifier = Modifier.size(24.dp)
            )
            Spacer(modifier = Modifier.width(10.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(text = alert.title, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                Text(text = alert.message, fontSize = 11.sp, color = Color.DarkGray)
            }
            Icon(Icons.Default.ChevronRight, contentDescription = null, tint = Color.LightGray)
        }
    }
}
