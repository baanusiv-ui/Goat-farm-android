package com.example.data.offline

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.UUID

@Entity(tableName = "local_fodder_species")
data class FodderSpeciesEntity(
    @PrimaryKey
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val scientific_name: String? = null,
    val category: String = "Perennial Grass", // Perennial Grass, Legume Fodder, Cereal Fodder, Tree Fodder
    val crude_protein_pct: Double = 15.0,
    val dry_matter_pct: Double = 22.0,
    val days_to_first_cut: Int = 60,
    val regrowth_interval_days: Int = 40,
    val cutting_height_cm: Double = 15.0,
    val expected_yield_per_acre_cut_kg: Double = 15000.0,
    val water_requirement: String = "Medium", // Low, Medium, High
    val notes: String? = null,
    val updated_at: Long = System.currentTimeMillis(),
    val is_synced: Boolean = true
)

@Entity(tableName = "local_fodder_plots")
data class FodderPlotEntity(
    @PrimaryKey
    val id: String = UUID.randomUUID().toString(),
    val plot_name: String,
    val area_value: Double,
    val area_unit: String = "Acres", // Acres, Hectares, Guntas, Cents, sq.m
    val variety: String? = null,
    val row_count: Int = 40,
    val row_length: Double = 25.0,
    val row_length_unit: String = "metre", // "metre", "feet"
    val row_spacing: Double = 1.0,
    val row_spacing_unit: String = "metre", // "metre", "feet"
    val calculated_cultivated_area: Double = 1000.0,
    val calculated_area_unit: String = "sq.m",
    val latitude: Double? = null,
    val longitude: Double? = null,
    val gps_accuracy: Float? = null,
    val location_tag: String? = null,
    val species_id: String,
    val species_name: String,
    val sowing_date: String,
    val crop_cycle_status: String = "Sown / Growing", // Sown / Growing, Ready for Cut, Regrowth Stage, Harvest Completed, Fallow
    val current_cut_count: Int = 0,
    val last_cut_date: String? = null,
    val next_expected_cut_date: String? = null,
    val irrigation_type: String = "Drip", // Drip, Sprinkler, Flood, Rainfed
    val soil_type: String = "Red Loam",
    val notes: String? = null,
    val updated_at: Long = System.currentTimeMillis(),
    val is_synced: Boolean = true
)

@Entity(tableName = "local_fodder_rows")
data class FodderRowEntity(
    @PrimaryKey
    val id: String = UUID.randomUUID().toString(),
    val plot_id: String,
    val row_index: Int, // 1 to N
    val row_code: String, // e.g. "R01", "R02", "R40"
    val crop_cycle_id: String? = null,
    val species_name: String,
    val variety: String? = null,
    val status: String = "Growing", // Planted, Growing, Due for cutting, Harvested, Regrowth, Damaged, Replanted, Abandoned
    val length_m: Double = 25.0,
    val spacing_m: Double = 1.0,
    val planting_date: String? = null,
    val planting_method: String? = "Slips",
    val last_cut_date: String? = null,
    val next_expected_cut_date: String? = null,
    val total_cuts: Int = 0,
    val total_yield_kg: Double = 0.0,
    val notes: String? = null,
    val updated_at: Long = System.currentTimeMillis(),
    val is_synced: Boolean = true
)

@Entity(tableName = "local_fodder_crop_cycles")
data class FodderCropCycleEntity(
    @PrimaryKey
    val id: String = UUID.randomUUID().toString(),
    val plot_id: String,
    val cycle_number: Int = 1,
    val cycle_name: String = "Crop Cycle 1",
    val species_name: String,
    val variety: String? = null,
    val planting_date: String,
    val planting_method: String = "Slips",
    val row_codes: String = "All Rows",
    val rows_count: Int = 40,
    val status: String = "Active", // Active, Completed, Replaced, Abandoned
    val start_date: String,
    val end_date: String? = null,
    val total_production_kg: Double = 0.0,
    val total_cuts_count: Int = 0,
    val notes: String? = null,
    val updated_at: Long = System.currentTimeMillis(),
    val is_synced: Boolean = true
)

@Entity(tableName = "local_fodder_materials")
data class FodderPlantingMaterialEntity(
    @PrimaryKey
    val id: String = UUID.randomUUID().toString(),
    val material_type: String = "Slips", // Seed, Direct sowing, Transplanting, Cuttings, Slips, Rooted slips, Vegetative propagation, Other
    val species_name: String,
    val variety: String? = null,
    val quantity_purchased: Double = 0.0,
    val quantity_used: Double = 0.0,
    val quantity_remaining: Double = 0.0,
    val unit: String = "slips", // kg, slips, cuttings, bags, bundles
    val unit_cost: Double = 0.0,
    val total_cost: Double = 0.0,
    val supplier: String? = null,
    val purchase_date: String,
    val batch_lot_number: String? = null,
    val notes: String? = null,
    val updated_at: Long = System.currentTimeMillis(),
    val is_synced: Boolean = true
)

@Entity(tableName = "local_fodder_activities")
data class FodderActivityEntity(
    @PrimaryKey
    val id: String = UUID.randomUUID().toString(),
    val plot_id: String,
    val plot_name: String,
    val crop_cycle_id: String? = null,
    val row_codes: String = "All Rows", // "R01–R05", "R01, R02", "All Rows"
    val species_name: String,
    val variety: String? = null,
    val activity_type: String, // Land preparation, Bed preparation, Seed purchase, Seed treatment, Sowing, Transplanting, Planting slips, Planting cuttings, Fertilization, Irrigation, Weeding, Pest control, Disease treatment, First cutting, Regrowth, Subsequent cutting, Wastage, Other
    val activity_date: String,
    val quantity: Double? = null,
    val unit: String? = null,
    val labour_hours: Double? = null,
    val labour_cost: Double? = null,
    val material_cost: Double? = null,
    val total_cost: Double = 0.0,
    val weather_temp_c: Double? = null,
    val weather_condition: String? = null,
    val weather_rainfall_mm: Double? = null,
    val weather_humidity_pct: Int? = null,
    val weather_wind_kmh: Double? = null,
    val operator_user: String? = null,
    val notes: String? = null,
    val updated_at: Long = System.currentTimeMillis(),
    val is_synced: Boolean = true
)

@Entity(tableName = "local_fodder_cuttings")
data class FodderCuttingEntity(
    @PrimaryKey
    val id: String = UUID.randomUUID().toString(),
    val plot_id: String,
    val plot_name: String,
    val species_id: String,
    val species_name: String,
    val cutting_date: String,
    val cut_number: Int,
    val harvested_weight_kg: Double,
    val area_harvested_pct: Double = 100.0,
    val labor_cost: Double? = null,
    val harvester_name: String? = null,
    val quality_rating: String = "Tender & Leafy", // Tender & Leafy, Good Standard, Fibrous / Overmature
    val crop_cycle_id: String? = null,
    val row_codes: String = "All Rows", // e.g. "R01–R05", "R01", "All Rows"
    val rows_harvested_count: Int = 1,
    val row_length_m: Double = 25.0,
    val total_harvested_row_length_m: Double = 25.0,
    val yield_per_metre: Double = 0.0,
    val yield_per_row: Double = 0.0,
    val yield_per_acre: Double = 0.0,
    val weather_summary: String? = null,
    val weather_temp_c: Double? = null,
    val weather_rainfall_mm: Double? = null,
    val notes: String? = null,
    val updated_at: Long = System.currentTimeMillis(),
    val is_synced: Boolean = true
)

@Entity(tableName = "local_fodder_feedings")
data class FodderFeedingEntity(
    @PrimaryKey
    val id: String = UUID.randomUUID().toString(),
    val feeding_date: String,
    val species_id: String? = null,
    val species_name: String,
    val target_group: String = "All Does", // All Does, Bucks Shed, Weaners & Kids, Lactating, Whole Herd
    val goats_count: Int = 1,
    val quantity_fed_kg: Double,
    val feeding_time: String = "Morning", // Morning, Afternoon, Evening
    val chaffed_method: String = "Chaff Cut Machine", // Chaff Cut Machine, Hand Chopped, Uncut Stalk
    val wastage_kg: Double = 0.0,
    val notes: String? = null,
    val updated_at: Long = System.currentTimeMillis(),
    val is_synced: Boolean = true
)

@Entity(tableName = "local_fodder_stock_adjustments")
data class FodderStockAdjustmentEntity(
    @PrimaryKey
    val id: String = UUID.randomUUID().toString(),
    val date_c: String,
    val species_name: String? = null,
    val adjustment_type: String = "WASTAGE", // SPOILED, DRIED_OUT, AUDIT_CORRECTION, INITIAL_STOCK
    val quantity_kg: Double,
    val notes: String? = null,
    val updated_at: Long = System.currentTimeMillis(),
    val is_synced: Boolean = true
)

@Entity(tableName = "local_fodder_master_settings")
data class FodderMasterSettingEntity(
    @PrimaryKey
    val setting_key: String, // e.g. "planting_methods", "activity_types", "crop_statuses", "row_units", "spacing_units"
    val setting_values_csv: String,
    val updated_at: Long = System.currentTimeMillis()
)
