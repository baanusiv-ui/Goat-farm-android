package com.example.ui.screens.fodder

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.fodder.FodderPlannerData
import com.example.data.fodder.FodderRepository
import com.example.ui.theme.*
import java.util.Locale
import kotlin.math.abs

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FodderRequirementPlannerView(
    repository: FodderRepository,
    modifier: Modifier = Modifier
) {
    var plannerData by remember { mutableStateOf(FodderPlannerData()) }
    var isLoading by remember { mutableStateOf(true) }

    // Interactive acreage calculator sliders
    var targetHerdSize by remember { mutableStateOf(50f) }
    var selectedFodderType by remember { mutableStateOf("Super Napier") }

    val cropYieldsPerAcreKg = mapOf(
        "Super Napier" to 180000.0,
        "CO-5 Napier" to 150000.0,
        "Lucerne" to 40000.0,
        "Hedge Lucerne" to 45000.0,
        "Multicut Sorghum" to 85000.0,
        "Guinea Grass" to 80000.0
    )

    LaunchedEffect(Unit) {
        isLoading = true
        plannerData = repository.getFodderPlannerData()
        targetHerdSize = plannerData.totalGoats.toFloat().coerceAtLeast(10f)
        isLoading = false
    }

    val calculatedTargetDailyReq = remember(targetHerdSize) {
        // Average 5 kg/goat/day across mixed herd
        targetHerdSize * 5.0
    }
    val calculatedAnnualRequirement = remember(calculatedTargetDailyReq) {
        calculatedTargetDailyReq * 365.0
    }
    val annualYieldPerAcre = cropYieldsPerAcreKg[selectedFodderType] ?: 150000.0
    val calculatedRequiredAcreage = remember(calculatedAnnualRequirement, annualYieldPerAcre) {
        calculatedAnnualRequirement / annualYieldPerAcre
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    text = "Fodder Requirement & Acreage Planner",
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.titleLarge,
                    color = FarmGreenDark
                )
                Text(
                    text = "Balance your goat herd's nutritional dry/green matter requirements against farm pasture production capacity to achieve 100% feed self-sufficiency.",
                    fontSize = 12.sp,
                    color = Color.Gray
                )
            }
        }

        if (isLoading) {
            item {
                Box(modifier = Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = FarmGreenDark)
                }
            }
        } else {
            // 1. Current Status Card: Surplus vs Deficit
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (plannerData.isSelfSufficient) Color(0xFFF1F8E9) else Color(0xFFFFF3E0)
                    ),
                    modifier = Modifier.fillMaxWidth().testTag("planner_status_card")
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = if (plannerData.isSelfSufficient) Icons.Default.CheckCircle else Icons.Default.Warning,
                                    contentDescription = null,
                                    tint = if (plannerData.isSelfSufficient) FarmGreenDark else FarmWarning,
                                    modifier = Modifier.size(24.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = if (plannerData.isSelfSufficient) "FODDER SELF-SUFFICIENT" else "FODDER DEFICIT ALERT",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    color = if (plannerData.isSelfSufficient) FarmGreenDark else Color(0xFFE65100)
                                )
                            }

                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = if (plannerData.isSelfSufficient) FarmGreenContainer else Color(0xFFFFE0B2)
                            ) {
                                Text(
                                    text = if (plannerData.isSelfSufficient) "+${plannerData.dailySurplusDeficitKg.toInt()} kg/day Surplus"
                                    else "-${abs(plannerData.dailySurplusDeficitKg).toInt()} kg/day Deficit",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp,
                                    color = if (plannerData.isSelfSufficient) FarmGreenDark else Color(0xFFE65100),
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }

                        // Progress Indicator
                        val ratio = if (plannerData.dailyRequirementKg > 0)
                            (plannerData.dailyProductionYieldKg / plannerData.dailyRequirementKg).toFloat().coerceIn(0f, 1f)
                        else 1f

                        LinearProgressIndicator(
                            progress = { ratio },
                            modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)),
                            color = if (plannerData.isSelfSufficient) FarmGreenDark else FarmWarning,
                            trackColor = Color.White.copy(alpha = 0.6f)
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Current Daily Production: ${plannerData.dailyProductionYieldKg.toInt()} kg/d", fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = Color.DarkGray)
                            Text("Herd Requirement: ${plannerData.dailyRequirementKg.toInt()} kg/d", fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = Color.DarkGray)
                        }
                    }
                }
            }

            // 2. Herd Demographics & Requirement Breakdown
            item {
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(
                            text = "Herd Breakdown (${plannerData.totalGoats} Animals Total)",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = FarmGreenDark
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            DemographicPill(label = "Adult Does", count = plannerData.adultDoes, dailyPerHead = "5 kg/d", modifier = Modifier.weight(1f))
                            DemographicPill(label = "Lactating", count = plannerData.lactatingDoes, dailyPerHead = "7 kg/d", modifier = Modifier.weight(1f))
                            DemographicPill(label = "Bucks", count = plannerData.adultBucks, dailyPerHead = "6 kg/d", modifier = Modifier.weight(1f))
                            DemographicPill(label = "Kids/Weaners", count = plannerData.kidsWeaners, dailyPerHead = "2 kg/d", modifier = Modifier.weight(1f))
                        }

                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = Color(0xFFF9FBF9),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text("Monthly Herd Fodder Requirement", fontSize = 11.sp, color = Color.Gray)
                                    Text("${plannerData.monthlyRequirementKg.toInt()} kg / month", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = FarmGreenDark)
                                }
                                Column(horizontalAlignment = Alignment.End) {
                                    Text("Est. Monthly Pasture Yield", fontSize = 11.sp, color = Color.Gray)
                                    Text("${plannerData.monthlyProductionYieldKg.toInt()} kg / month", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = Color(0xFF0277BD))
                                }
                            }
                        }
                    }
                }
            }

            // 3. Interactive Acreage & Self-Sufficiency Calculator
            item {
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier.fillMaxWidth().testTag("interactive_acreage_calculator")
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Calculate, contentDescription = null, tint = FarmGreenDark)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Acreage Sizing Calculator",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = FarmGreenDark
                            )
                        }

                        // Target Herd Size Slider
                        Column {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Simulate Herd Size:", fontSize = 12.sp, color = Color.DarkGray)
                                Text("${targetHerdSize.toInt()} Goats", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = FarmGreenDark)
                            }
                            Slider(
                                value = targetHerdSize,
                                onValueChange = { targetHerdSize = it },
                                valueRange = 10f..500f,
                                steps = 48,
                                colors = SliderDefaults.colors(
                                    thumbColor = FarmGreenDark,
                                    activeTrackColor = FarmGreenDark
                                )
                            )
                        }

                        // Choose Crop Type
                        Text("Select Primary Fodder Crop:", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = Color.DarkGray)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            listOf("Super Napier", "CO-5 Napier", "Lucerne").forEach { crop ->
                                FilterChip(
                                    selected = selectedFodderType == crop,
                                    onClick = { selectedFodderType = crop },
                                    label = { Text(crop, fontSize = 11.sp) },
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            listOf("Hedge Lucerne", "Multicut Sorghum", "Guinea Grass").forEach { crop ->
                                FilterChip(
                                    selected = selectedFodderType == crop,
                                    onClick = { selectedFodderType = crop },
                                    label = { Text(crop, fontSize = 11.sp) },
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }

                        // Calculation Result Hero
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = Color(0xFFE8F5E9),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text("Acreage Needed for 100% Self-Sufficiency:", fontSize = 11.sp, color = Color.Gray)
                                Text(
                                    text = "${String.format(Locale.US, "%.2f", calculatedRequiredAcreage)} Acres",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 22.sp,
                                    color = FarmGreenDark
                                )
                                Text(
                                    text = "To feed ${targetHerdSize.toInt()} goats (${calculatedTargetDailyReq.toInt()} kg/day), you need ${String.format(Locale.US, "%.2f", calculatedRequiredAcreage)} acres of $selectedFodderType yielding ${(annualYieldPerAcre / 1000).toInt()} Tonnes/acre/year.",
                                    fontSize = 11.sp,
                                    color = Color.DarkGray,
                                    lineHeight = 15.sp
                                )
                            }
                        }
                    }
                }
            }
        }

        item { Spacer(modifier = Modifier.height(48.dp)) }
    }
}

@Composable
private fun DemographicPill(
    label: String,
    count: Int,
    dailyPerHead: String,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(8.dp),
        color = Color(0xFFF1F8E9),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(label, fontSize = 9.sp, color = Color.Gray, maxLines = 1)
            Text("$count", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = FarmGreenDark)
            Text(dailyPerHead, fontSize = 8.sp, color = Color.DarkGray)
        }
    }
}
