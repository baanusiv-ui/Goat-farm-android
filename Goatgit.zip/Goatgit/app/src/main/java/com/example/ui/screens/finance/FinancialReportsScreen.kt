package com.example.ui.screens.finance

import android.content.Intent
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.supabase.*
import com.example.ui.theme.*
import com.example.util.CurrencyUtils
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FinancialReportsScreen(
    repository: GoatRepository,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler { onNavigateBack() }

    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val dateFormat = remember { SimpleDateFormat("yyyy-MM-dd", Locale.US) }
    val today = remember { dateFormat.format(Date()) }

    var cashFlowSummary by remember { mutableStateOf(ThreePillarCashFlowSummary()) }
    var financeSummary by remember { mutableStateOf(FarmFinanceSummary()) }
    var accounts by remember { mutableStateOf<List<FinancialAccount>>(emptyList()) }
    var transactions by remember { mutableStateOf<List<AccountTransaction>>(emptyList()) }
    var invoices by remember { mutableStateOf<List<SupplierInvoice>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }

    var selectedReport by remember { mutableStateOf("CASH_FLOW") } // CASH_FLOW, PNL, CASH_BOOK, SUPPLIER_AGING, GST_SUMMARY

    fun loadData() {
        isLoading = true
        coroutineScope.launch {
            val cfRes = repository.finance.getThreePillarCashFlow()
            if (cfRes.isSuccess) cashFlowSummary = cfRes.getOrThrow()

            val pnlRes = repository.getFarmFinanceSummary()
            if (pnlRes.isSuccess) financeSummary = pnlRes.getOrThrow()

            val accRes = repository.finance.getAccounts()
            if (accRes.isSuccess) accounts = accRes.getOrThrow()

            val txRes = repository.finance.getTransactions()
            if (txRes.isSuccess) transactions = txRes.getOrThrow()

            val invRes = repository.finance.getSupplierInvoices()
            if (invRes.isSuccess) invoices = invRes.getOrThrow()

            isLoading = false
        }
    }

    LaunchedEffect(Unit) {
        loadData()
    }

    val reportTypes = listOf(
        "CASH_FLOW" to "3-Pillar Cash Flow",
        "PNL" to "Profit & Loss (P&L)",
        "CASH_BOOK" to "Cash & Bank Book",
        "SUPPLIER_AGING" to "Creditor Ageing",
        "GST_SUMMARY" to "GST Tax Summary"
    )

    fun exportReportCsv() {
        val csv = buildString {
            when (selectedReport) {
                "CASH_FLOW" -> {
                    appendLine("THREE-PILLAR CASH FLOW STATEMENT")
                    appendLine("Generated on: $today")
                    appendLine("Category,Inflow,Outflow,Net")
                    appendLine("Opening Cash & Bank,,,${cashFlowSummary.openingCashAndBank}")
                    appendLine("Operating Cash Flow,${cashFlowSummary.operatingInflow},${cashFlowSummary.operatingOutflow},${cashFlowSummary.netOperatingCashFlow}")
                    appendLine("Investing Cash Flow (CAPEX),${cashFlowSummary.investingInflow},${cashFlowSummary.investingOutflow},${cashFlowSummary.netInvestingCashFlow}")
                    appendLine("Financing Cash Flow (Loans/Capital),${cashFlowSummary.financingInflow},${cashFlowSummary.financingOutflow},${cashFlowSummary.netFinancingCashFlow}")
                    appendLine("Closing Cash & Bank,,,${cashFlowSummary.closingCashAndBank}")
                    appendLine("Reconciled Account Balance,,,${cashFlowSummary.totalLiquidFundsInAccounts}")
                }
                "PNL" -> {
                    appendLine("FARM PROFIT & LOSS STATEMENT")
                    appendLine("Generated on: $today")
                    appendLine("Particulars,Amount (INR)")
                    appendLine("Goat Sales Income,${financeSummary.goatSalesIncome}")
                    appendLine("Manure Sales Income,${financeSummary.manureSalesIncome}")
                    appendLine("Other Revenue,${financeSummary.otherIncome}")
                    appendLine("Total Revenue,${financeSummary.totalIncome}")
                    appendLine("Feed & Fodder Expenses,${financeSummary.feedExpenses}")
                    appendLine("Medicine Expenses,${financeSummary.medicineExpenses}")
                    appendLine("Veterinary Expenses,${financeSummary.veterinaryExpenses}")
                    appendLine("Labour Expenses,${financeSummary.labourExpenses}")
                    appendLine("Other Operating Expenses,${financeSummary.otherExpenses}")
                    appendLine("Total Operating Expenses,${financeSummary.totalExpenses}")
                    appendLine("Net Farm Profit / (Loss),${financeSummary.netProfit}")
                }
                else -> {
                    appendLine("ACCOUNT TRANSACTIONS REPORT")
                    appendLine("Date,Account,Type,Category,Pillar,Amount")
                    transactions.forEach {
                        appendLine("${it.date},${it.account_id},${it.transaction_type},${it.category},${it.pillar},${it.amount}")
                    }
                }
            }
        }

        val sendIntent = Intent(Intent.ACTION_SEND).apply {
            type = "text/csv"
            putExtra(Intent.EXTRA_SUBJECT, "Financial_Report_$selectedReport.csv")
            putExtra(Intent.EXTRA_TEXT, csv)
        }
        context.startActivity(Intent.createChooser(sendIntent, "Export Report CSV"))
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "Financial Statements & Reports",
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp
                        )
                        Text(
                            text = "Audited Cash Flow, P&L, Ledgers & CSV Export",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack, modifier = Modifier.testTag("reports_btn_back")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(onClick = { exportReportCsv() }, modifier = Modifier.testTag("reports_btn_export_csv")) {
                        Icon(Icons.Default.Download, contentDescription = "Export CSV", tint = FarmGreenDark)
                    }
                    IconButton(onClick = { loadData() }, modifier = Modifier.testTag("reports_btn_refresh")) {
                        Icon(Icons.Default.Refresh, contentDescription = "Refresh")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.White)
            )
        },
        containerColor = Color(0xFFF8F9FA),
        modifier = modifier
    ) { innerPadding ->
        if (isLoading) {
            Box(modifier = Modifier.fillMaxSize().padding(innerPadding), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = FarmGreenDark)
            }
        } else {
            Column(modifier = Modifier.fillMaxSize().padding(innerPadding)) {
                // Report Selector Chips
                LazyRow(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color.White)
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(reportTypes) { (key, title) ->
                        val isSelected = selectedReport == key
                        FilterChip(
                            selected = isSelected,
                            onClick = { selectedReport = key },
                            label = { Text(title, fontSize = 12.sp, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = FarmGreenDark,
                                selectedLabelColor = Color.White
                            )
                        )
                    }
                }

                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    item { Spacer(modifier = Modifier.height(4.dp)) }

                    when (selectedReport) {
                        "CASH_FLOW" -> {
                            item {
                                ThreePillarCashFlowReportCard(summary = cashFlowSummary)
                            }
                        }
                        "PNL" -> {
                            item {
                                ProfitAndLossReportCard(summary = financeSummary)
                            }
                        }
                        "CASH_BOOK" -> {
                            item {
                                CashBookReportCard(accounts = accounts, transactions = transactions)
                            }
                        }
                        "SUPPLIER_AGING" -> {
                            item {
                                CreditorAgeingReportCard(invoices = invoices, today = today)
                            }
                        }
                        "GST_SUMMARY" -> {
                            item {
                                GstSummaryReportCard(transactions = transactions)
                            }
                        }
                    }

                    item { Spacer(modifier = Modifier.height(32.dp)) }
                }
            }
        }
    }
}

@Composable
private fun ThreePillarCashFlowReportCard(summary: ThreePillarCashFlowSummary) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier.fillMaxWidth().testTag("three_pillar_cash_flow_card")
    ) {
        Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Three-Pillar Cash Flow Statement", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = FarmGreenDark)
            Text("Reconciles Opening Cash & Bank with Operating, Investing, and Financing cash movements.", fontSize = 11.sp, color = Color.Gray)

            HorizontalDivider(color = Color(0xFFEEEEEE))

            // Opening Balance
            ReportLine(label = "Opening Cash & Bank Balance", amount = summary.openingCashAndBank, isBold = true)

            // 1. Operating Activities
            Spacer(modifier = Modifier.height(4.dp))
            Text("1. Cash Flow from Operating Activities", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color(0xFF1E3A8A))
            ReportLine(label = "  • Operating Inflows (Sales & Receipts)", amount = summary.operatingInflow, color = FarmGreenDark)
            ReportLine(label = "  • Operating Outflows (Feed, Meds, Labour, EB)", amount = -summary.operatingOutflow, color = FarmError)
            ReportLine(label = "  = Net Operating Cash Flow", amount = summary.netOperatingCashFlow, isBold = true)

            // 2. Investing Activities
            Spacer(modifier = Modifier.height(4.dp))
            Text("2. Cash Flow from Investing Activities (CAPEX)", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color(0xFF6B21A8))
            ReportLine(label = "  • Investing Inflows (Asset Sales)", amount = summary.investingInflow, color = FarmGreenDark)
            ReportLine(label = "  • Investing Outflows (Sheds, Borewell, Equipment)", amount = -summary.investingOutflow, color = FarmError)
            ReportLine(label = "  = Net Investing Cash Flow", amount = summary.netInvestingCashFlow, isBold = true)

            // 3. Financing Activities
            Spacer(modifier = Modifier.height(4.dp))
            Text("3. Cash Flow from Financing Activities", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color(0xFFB45309))
            ReportLine(label = "  • Financing Inflows (Loans Received, Owner Capital)", amount = summary.financingInflow, color = FarmGreenDark)
            ReportLine(label = "  • Financing Outflows (Loan Principal Repayments)", amount = -summary.financingOutflow, color = FarmError)
            ReportLine(label = "  = Net Financing Cash Flow", amount = summary.netFinancingCashFlow, isBold = true)

            HorizontalDivider(color = Color(0xFFDDDDDD))

            // Reconciled Closing Balance
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Column {
                    Text("Calculated Closing Cash & Bank:", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Text("Reconciled Liquid Funds: ${CurrencyUtils.formatInr(summary.totalLiquidFundsInAccounts)}", fontSize = 11.sp, color = FarmGreenDark)
                }
                Text(
                    text = CurrencyUtils.formatInr(summary.closingCashAndBank),
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 18.sp,
                    color = FarmGreenDark
                )
            }
        }
    }
}

@Composable
private fun ProfitAndLossReportCard(summary: FarmFinanceSummary) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier.fillMaxWidth().testTag("pnl_report_card")
    ) {
        Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Farm Profit & Loss Statement (Operating)", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = FarmGreenDark)
            Text("Operating revenues minus operating expenses. Excludes CAPEX and financing loans.", fontSize = 11.sp, color = Color.Gray)

            HorizontalDivider(color = Color(0xFFEEEEEE))

            Text("Operating Revenues", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = FarmGreenDark)
            ReportLine(label = "  • Goat Sales Revenue", amount = summary.goatSalesIncome)
            ReportLine(label = "  • Manure & Compost Revenue", amount = summary.manureSalesIncome)
            ReportLine(label = "  • Other Operating Income", amount = summary.otherIncome)
            ReportLine(label = "Total Operating Revenue", amount = summary.totalIncome, isBold = true, color = FarmGreenDark)

            Spacer(modifier = Modifier.height(4.dp))
            Text("Operating Expenses (OPEX)", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = FarmError)
            ReportLine(label = "  • Feed & Fodder Purchases", amount = summary.feedExpenses)
            ReportLine(label = "  • Medicines & Health", amount = summary.medicineExpenses)
            ReportLine(label = "  • Veterinary Doctor Fees", amount = summary.veterinaryExpenses)
            ReportLine(label = "  • Farm Labour & Wages", amount = summary.labourExpenses)
            ReportLine(label = "  • Electricity, Maintenance & General", amount = summary.otherExpenses)
            ReportLine(label = "Total Operating Expenses", amount = summary.totalExpenses, isBold = true, color = FarmError)

            HorizontalDivider(color = Color(0xFFDDDDDD))

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text("Net Operating Farm Profit:", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Text(
                    text = CurrencyUtils.formatInr(summary.netProfit),
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 18.sp,
                    color = if (summary.netProfit >= 0) FarmGreenDark else FarmError
                )
            }
        }
    }
}

@Composable
private fun CashBookReportCard(accounts: List<FinancialAccount>, transactions: List<AccountTransaction>) {
    Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Cash & Bank Ledger Book", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = Color(0xFF1E3A8A))
            Text("${accounts.size} Active Accounts • ${transactions.size} Total Audited Entries", fontSize = 11.sp, color = Color.Gray)

            HorizontalDivider(color = Color(0xFFEEEEEE))

            accounts.forEach { acc ->
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(acc.account_name, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    Text(CurrencyUtils.formatInr(acc.current_balance), fontWeight = FontWeight.Bold, fontSize = 13.sp, color = FarmGreenDark)
                }
            }
        }
    }
}

@Composable
private fun CreditorAgeingReportCard(invoices: List<SupplierInvoice>, today: String) {
    Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Supplier Ageing & Accounts Payable Report", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = Color(0xFF991B1B))
            Text("Outstanding invoices grouped by credit payment status.", fontSize = 11.sp, color = Color.Gray)

            HorizontalDivider(color = Color(0xFFEEEEEE))

            invoices.filter { it.status != "PAID" }.forEach { inv ->
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column {
                        Text("Inv #${inv.invoice_number} • ${inv.items_description}", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        Text("Due: ${inv.due_date}", fontSize = 11.sp, color = Color.Gray)
                    }
                    Text(CurrencyUtils.formatInr(inv.balance_due), fontWeight = FontWeight.Bold, fontSize = 13.sp, color = FarmError)
                }
                HorizontalDivider(color = Color(0xFFF9FAFB))
            }
        }
    }
}

@Composable
private fun GstSummaryReportCard(transactions: List<AccountTransaction>) {
    Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("GST Sales Tax Summary", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = FarmGreenDark)
            Text("Summary of outward taxable supplies for GST return filing.", fontSize = 11.sp, color = Color.Gray)

            HorizontalDivider(color = Color(0xFFEEEEEE))

            val salesTx = transactions.filter { it.transaction_type == "CUSTOMER_RECEIPT" || it.category.contains("Sale", ignoreCase = true) }
            val totalTaxable = salesTx.sumOf { it.amount }
            val estGst = totalTaxable * 0.05 // default 5% rate for live animals

            ReportLine(label = "Total Taxable Farm Sales", amount = totalTaxable)
            ReportLine(label = "Output Tax (Estimated 5% GST)", amount = estGst, color = FarmGreenDark)
        }
    }
}

@Composable
private fun ReportLine(
    label: String,
    amount: Double,
    isBold: Boolean = false,
    color: Color = Color.DarkGray
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            fontSize = if (isBold) 13.sp else 12.sp,
            fontWeight = if (isBold) FontWeight.Bold else FontWeight.Normal,
            color = if (isBold) Color.Black else Color.DarkGray
        )
        Text(
            text = CurrencyUtils.formatInr(amount),
            fontSize = if (isBold) 14.sp else 12.sp,
            fontWeight = if (isBold) FontWeight.ExtraBold else FontWeight.SemiBold,
            color = color
        )
    }
}
