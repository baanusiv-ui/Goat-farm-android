package com.example.ui.screens

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.supabase.*
import com.example.ui.components.DatePickerField
import com.example.ui.screens.health.*
import com.example.ui.theme.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DewormingScreen(
    repository: GoatRepository,
    initialGoatId: String? = null,
    initialTab: Int = 0,
    onNavigateBack: () -> Unit,
    onDewormingSaved: () -> Unit = {}
) {
    BackHandler { onNavigateBack() }

    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val dateFormat = remember { SimpleDateFormat("yyyy-MM-dd", Locale.US) }
    val today = remember { dateFormat.format(Date()) }

    var selectedTab by remember { mutableIntStateOf(initialTab) }
    var dewormings by remember { mutableStateOf<List<DewormingRecord>>(emptyList()) }
    var schedules by remember { mutableStateOf<List<DewormingSchedule>>(emptyList()) }
    var goats by remember { mutableStateOf<List<Goat>>(emptyList()) }
    var pregnancies by remember { mutableStateOf<List<PregnancyRecord>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }

    var showRecordDialog by remember { mutableStateOf(false) }

    // Dialog prefill states
    var dialogPrefillGoatId by remember { mutableStateOf<String?>(initialGoatId) }
    var dialogPrefillMedicine by remember { mutableStateOf<String?>(null) }
    var dialogPrefillDose by remember { mutableStateOf<String?>(null) }
    var dialogPrefillDueDate by remember { mutableStateOf<String?>(null) }
    var dialogPrefillProtocolType by remember { mutableStateOf<String?>(null) }

    fun loadData() {
        isLoading = true
        coroutineScope.launch {
            repository.seedTanuvasSchedulesIfEmpty()
            val dewRes = repository.getDewormings()
            if (dewRes.isSuccess) dewormings = dewRes.getOrThrow()

            val schRes = repository.getDewormingSchedules()
            if (schRes.isSuccess) schedules = schRes.getOrThrow()

            val gRes = repository.getGoats()
            if (gRes.isSuccess) goats = gRes.getOrThrow()

            val pRes = repository.getPregnancies()
            if (pRes.isSuccess) pregnancies = pRes.getOrThrow()

            isLoading = false
        }
    }

    LaunchedEffect(Unit) {
        loadData()
        if (initialGoatId != null) {
            dialogPrefillGoatId = initialGoatId
            showRecordDialog = true
        }
    }

    val goatsMap = remember(goats) { goats.associateBy { it.id } }
    val todayDate = remember(today) { dateFormat.parse(today) ?: Date() }

    val dueOrOverdue = remember(dewormings, todayDate) {
        dewormings.filter { rec ->
            if (rec.next_due_date_c.isNullOrBlank()) false
            else {
                try {
                    val d = dateFormat.parse(rec.next_due_date_c)
                    d != null && (d.before(todayDate) || rec.next_due_date_c == today || ((d.time - todayDate.time) / (1000 * 60 * 60 * 24)) <= 14)
                } catch (_: Exception) { false }
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "Deworming Schedule & Protocol",
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp
                        )
                        Text(
                            text = "Age-Based Timeline, Anthelmintic Rotation & Safety",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack, modifier = Modifier.testTag("deworming_btn_back")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(
                        onClick = {
                            dialogPrefillGoatId = null
                            dialogPrefillMedicine = null
                            dialogPrefillDose = null
                            dialogPrefillDueDate = null
                            dialogPrefillProtocolType = null
                            showRecordDialog = true
                        }
                    ) {
                        Icon(Icons.Default.AddCircle, contentDescription = "Record Deworming")
                    }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = {
                    dialogPrefillGoatId = null
                    dialogPrefillMedicine = null
                    dialogPrefillDose = null
                    dialogPrefillDueDate = null
                    dialogPrefillProtocolType = null
                    showRecordDialog = true
                },
                containerColor = FarmGreenDark,
                contentColor = Color.White,
                modifier = Modifier.testTag("btn_add_deworming")
            ) {
                Row(modifier = Modifier.padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Add, contentDescription = null)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Record Deworming", fontWeight = FontWeight.Bold)
                }
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(Color(0xFFF8FAFC))
        ) {
            ScrollableTabRow(
                selectedTabIndex = selectedTab,
                containerColor = Color.White,
                edgePadding = 12.dp
            ) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = {
                        Text("Schedule & Protocols (அட்டவணை)", fontWeight = FontWeight.Bold)
                    }
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = {
                        Text(
                            "Due & Herd Alerts",
                            fontWeight = FontWeight.Bold,
                            color = if (dueOrOverdue.isNotEmpty()) Color(0xFFD97706) else Color.Unspecified
                        )
                    }
                )
                Tab(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    text = {
                        Text("Dose Calculator", fontWeight = FontWeight.Bold, color = Color(0xFF0284C7))
                    }
                )
                Tab(
                    selected = selectedTab == 3,
                    onClick = { selectedTab = 3 },
                    text = {
                        Text("History (${dewormings.size})", fontWeight = FontWeight.Bold)
                    }
                )
                Tab(
                    selected = selectedTab == 4,
                    onClick = { selectedTab = 4 },
                    text = {
                        Text("TANUVAS Guidance", fontWeight = FontWeight.Bold, color = Color(0xFF059669))
                    }
                )
            }

            if (isLoading) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = FarmGreenPrimary)
                }
            } else {
                when (selectedTab) {
                    0 -> DewormingProtocolsListView(
                        onSelectProtocolForRecord = { proto ->
                            dialogPrefillGoatId = null
                            dialogPrefillMedicine = proto.recommendedMedicine
                            dialogPrefillDose = proto.dosageGuide.substringBefore("(")
                            val cal = Calendar.getInstance()
                            cal.add(Calendar.DAY_OF_YEAR, if (proto.id.contains("kid")) 30 else 90)
                            dialogPrefillDueDate = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(cal.time)
                            dialogPrefillProtocolType = if (proto.id.contains("kid")) "AGE-BASED / KID" else "PERIODIC"
                            showRecordDialog = true
                        }
                    )
                    1 -> HerdDewormingDueView(
                        goats = goats,
                        dewormings = dewormings,
                        pregnancies = pregnancies,
                        onDewormGoat = { g, recMed, recDose ->
                            dialogPrefillGoatId = g.id
                            dialogPrefillMedicine = recMed
                            dialogPrefillDose = recDose
                            val cal = Calendar.getInstance()
                            cal.add(Calendar.DAY_OF_YEAR, 90)
                            dialogPrefillDueDate = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(cal.time)
                            dialogPrefillProtocolType = "AGE-BASED / SCHEDULE"
                            showRecordDialog = true
                        }
                    )
                    2 -> DewormingCalculatorView(
                        goats = goats,
                        dewormings = dewormings,
                        pregnancies = pregnancies,
                        onRecordWithCalculatedData = { goatId, medicine, dose, nextDue ->
                            dialogPrefillGoatId = goatId
                            dialogPrefillMedicine = medicine
                            dialogPrefillDose = dose
                            dialogPrefillDueDate = nextDue
                            dialogPrefillProtocolType = "CALCULATOR PRESET"
                            showRecordDialog = true
                        }
                    )
                    3 -> DewormingRecordsList(records = dewormings, goatsMap = goatsMap, label = "All Completed Dewormings")
                    4 -> TanuvasDewormingGuidanceView(schedules = schedules)
                }
            }
        }
    }

    if (showRecordDialog) {
        RecordDewormingDialog(
            goats = goats,
            pregnancies = pregnancies,
            initialGoatId = dialogPrefillGoatId,
            initialMedicine = dialogPrefillMedicine,
            initialDose = dialogPrefillDose,
            initialNextDue = dialogPrefillDueDate,
            initialProtocolType = dialogPrefillProtocolType,
            today = today,
            onDismiss = { showRecordDialog = false },
            onSave = { records, cost, prodName ->
                coroutineScope.launch {
                    val res = repository.recordDewormingsForGoats(records, totalCost = cost, productName = prodName)
                    showRecordDialog = false
                    if (res.isSuccess) {
                        Toast.makeText(context, "${records.size} deworming(s) recorded successfully!", Toast.LENGTH_SHORT).show()
                        loadData()
                        onDewormingSaved()
                    } else {
                        Toast.makeText(context, "Failed: ${res.exceptionOrNull()?.message}", Toast.LENGTH_LONG).show()
                    }
                }
            }
        )
    }
}

@Composable
private fun DewormingRecordsList(
    records: List<DewormingRecord>,
    goatsMap: Map<String, Goat>,
    label: String
) {
    if (records.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(Icons.Default.CheckCircle, contentDescription = null, tint = FarmGreenDark, modifier = Modifier.size(48.dp))
                Text("No records found", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Text("Tap + to record routine, age-based or FEC-based deworming treatments.", fontSize = 12.sp, color = Color.Gray)
            }
        }
    } else {
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(horizontal = 14.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                Text(label, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.Gray, modifier = Modifier.padding(vertical = 4.dp))
            }
            items(records) { rec ->
                DewormingCardItem(record = rec, goat = goatsMap[rec.goat_id_c])
            }
            item {
                Spacer(modifier = Modifier.height(72.dp))
            }
        }
    }
}

@Composable
private fun DewormingCardItem(record: DewormingRecord, goat: Goat?) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(12.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(34.dp)
                            .clip(CircleShape)
                            .background(Color(0xFFD1FAE5)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.Medication, contentDescription = null, tint = Color(0xFF059669), modifier = Modifier.size(18.dp))
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(record.medicine_c, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text("Goat: ${goat?.tag_c ?: "Goat"} (${goat?.name ?: ""})", fontSize = 11.sp, color = Color.Gray)
                    }
                }

                if (!record.next_due_date_c.isNullOrBlank()) {
                    Surface(color = Color(0xFFF0FDF4), shape = RoundedCornerShape(6.dp)) {
                        Text(
                            text = "Due: ${record.next_due_date_c}",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = FarmGreenDark,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                        )
                    }
                }
            }

            HorizontalDivider(color = Color(0xFFF1F5F9))

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Date: ${record.treatment_date_c}", fontSize = 11.sp, color = Color.DarkGray)
                Text("Dose: ${record.dose_c}", fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
            }

            if (record.weight_at_treatment_c != null) {
                Text("Animal Weight: ${record.weight_at_treatment_c} kg", fontSize = 10.sp, color = Color.Gray)
            }

            if (!record.notes_c.isNullOrBlank()) {
                Text(record.notes_c, fontSize = 11.sp, color = Color.DarkGray)
            }
        }
    }
}

@Composable
private fun TanuvasDewormingGuidanceView(schedules: List<DewormingSchedule>) {
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Surface(
                color = Color(0xFFECFDF5),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, Color(0xFFA7F3D0)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Verified, contentDescription = null, tint = Color(0xFF059669), modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Caprine Deworming Guidelines", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color(0xFF065F46))
                    }
                    Text(
                        text = "Follow systematic anthelmintic rotation across chemical groups (Benzimidazoles, Macrocyclic Lactones, Levamisole, Flukicides). Check kids at 30, 60, and 90 days. Avoid administering dewormers in the first 45-60 days of doe gestation.",
                        fontSize = 11.sp,
                        color = Color(0xFF047857),
                        lineHeight = 15.sp
                    )
                }
            }
        }

        items(schedules) { sch ->
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(12.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(sch.name, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color(0xFF1E293B), modifier = Modifier.weight(1f))
                        Surface(color = Color(0xFFE0E7FF), shape = RoundedCornerShape(4.dp)) {
                            Text(sch.trigger_type, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color(0xFF3730A3), modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                        }
                    }

                    if (!sch.fec_reference.isNullOrBlank()) {
                        Text("FEC / Indication: ${sch.fec_reference}", fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFF059669))
                    }
                    Text("Trigger Interval: Every ${sch.interval_days} days", fontSize = 11.sp, color = Color.Gray)

                    if (!sch.notes.isNullOrBlank()) {
                        Text(sch.notes, fontSize = 11.sp, color = Color.DarkGray)
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(72.dp))
        }
    }
}

// Dialog for recording deworming (Requirement 5)
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun RecordDewormingDialog(
    goats: List<Goat>,
    pregnancies: List<PregnancyRecord> = emptyList(),
    initialGoatId: String?,
    initialMedicine: String? = null,
    initialDose: String? = null,
    initialNextDue: String? = null,
    initialProtocolType: String? = null,
    today: String,
    onDismiss: () -> Unit,
    onSave: (List<DewormingRecord>, cost: Double?, productName: String) -> Unit
) {
    val activeGoats = remember(goats) { goats.filter { !it.status_c.equals("Deceased", ignoreCase = true) } }

    var selectionMode by remember { mutableStateOf(if (initialGoatId != null) "INDIVIDUAL" else "INDIVIDUAL") }
    var singleGoatId by remember { mutableStateOf(initialGoatId ?: activeGoats.firstOrNull()?.id ?: "") }
    var singleGoatExpanded by remember { mutableStateOf(false) }
    val multipleSelectedIds = remember { mutableStateListOf<String>().apply { if (initialGoatId != null) add(initialGoatId) } }

    // Schedule Type presets
    val scheduleTypes = listOf("AGE-BASED / KID", "PERIODIC", "FEC-BASED", "VETERINARIAN ADVISED", "CUSTOM")
    var selectedScheduleType by remember { mutableStateOf(initialProtocolType ?: "AGE-BASED / KID") }

    var product by remember { mutableStateOf(initialMedicine ?: "Albendazole Suspension") }
    var activeIngredient by remember { mutableStateOf(if (product.contains("Albendazole", ignoreCase = true)) "Albendazole (Micronized)" else "") }
    var dose by remember { mutableStateOf(initialDose ?: "5 ml (7.5 mg/kg)") }
    var route by remember { mutableStateOf("Oral Drench") }
    var animalWeightStr by remember { mutableStateOf("25") }
    var reason by remember { mutableStateOf("Age-based routine deworming") }
    var fecCount by remember { mutableStateOf("") }
    var treatmentDate by remember { mutableStateOf(today) }

    var nextDueDate by remember {
        if (!initialNextDue.isNullOrBlank()) {
            mutableStateOf(initialNextDue)
        } else {
            val cal = Calendar.getInstance()
            cal.add(Calendar.DAY_OF_YEAR, 90)
            mutableStateOf(SimpleDateFormat("yyyy-MM-dd", Locale.US).format(cal.time))
        }
    }

    var veterinarian by remember { mutableStateOf("") }
    var batchNumber by remember { mutableStateOf("") }
    var expiryDate by remember { mutableStateOf("") }
    var totalCostStr by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }
    var attachmentNote by remember { mutableStateOf("") }

    val coveredGoats = remember(selectionMode, singleGoatId, multipleSelectedIds.toList(), activeGoats) {
        when (selectionMode) {
            "INDIVIDUAL" -> activeGoats.filter { it.id == singleGoatId }
            "MULTIPLE" -> activeGoats.filter { multipleSelectedIds.contains(it.id) }
            "ALL_HERD" -> activeGoats
            "DOES" -> activeGoats.filter { it.sex_c.equals("Doe", ignoreCase = true) }
            "BUCKS" -> activeGoats.filter { it.sex_c.equals("Buck", ignoreCase = true) }
            "KIDS" -> activeGoats.filter { it.sex_c.equals("Kid", ignoreCase = true) || it.tag_c.contains("K", ignoreCase = true) }
            else -> activeGoats.filter { it.id == singleGoatId }
        }
    }

    // Pregnancy check for selected animals
    val activePregnancyDoeIds = remember(pregnancies, goats) {
        val fromPreg = pregnancies.filter { it.status_c.equals("Confirmed", ignoreCase = true) }.map { it.doe_id_c }.toSet()
        val fromStatus = goats.filter { it.status_c.equals("Pregnant", ignoreCase = true) }.map { it.id }.toSet()
        fromPreg + fromStatus
    }

    val containsPregnantDoe = remember(coveredGoats, activePregnancyDoeIds) {
        coveredGoats.any { activePregnancyDoeIds.contains(it.id) }
    }

    Dialog(onDismissRequest = onDismiss) {
        Surface(shape = RoundedCornerShape(16.dp), color = Color.White, modifier = Modifier.fillMaxWidth().fillMaxHeight(0.92f)) {
            LazyColumn(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                item {
                    Text("Record Anthelmintic Treatment", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = FarmGreenDark)
                    Text("Apply age-based schedule or periodic rotation without hardcoded fixed prescriptions.", fontSize = 11.sp, color = Color.Gray)
                }

                // Pregnancy alert if applicable
                if (containsPregnantDoe) {
                    item {
                        Surface(
                            color = Color(0xFFFEF2F2),
                            shape = RoundedCornerShape(8.dp),
                            border = BorderStroke(1.dp, Color(0xFFFCA5A5)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(modifier = Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Warning, contentDescription = null, tint = Color(0xFFDC2626), modifier = Modifier.size(20.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Column {
                                    Text(
                                        text = "⚠️ PREGNANCY CAUTION FOR SELECTED DOES",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 11.sp,
                                        color = Color(0xFF991B1B)
                                    )
                                    Text(
                                        text = "Selected animal includes pregnant doe(s). Avoid Albendazole in early pregnancy (Days 1-60). Use Fenbendazole only if clinically essential.",
                                        fontSize = 10.sp,
                                        color = Color(0xFF7F1D1D)
                                    )
                                }
                            }
                        }
                    }
                }

                // Quick Schedule Presets
                item {
                    Text("Quick Presets from Schedule", fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = Color.Gray)
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(4.dp), modifier = Modifier.fillMaxWidth()) {
                        item {
                            SuggestionChip(
                                onClick = {
                                    product = "Albendazole Suspension 2.5%"
                                    activeIngredient = "Albendazole"
                                    dose = "1 ml / 3-5 kg (7.5 mg/kg)"
                                    route = "Oral Drench"
                                    selectedScheduleType = "AGE-BASED / KID"
                                    reason = "Kid 1st Deworming (30 Days)"
                                    val cal = Calendar.getInstance()
                                    cal.add(Calendar.DAY_OF_YEAR, 30)
                                    nextDueDate = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(cal.time)
                                },
                                label = { Text("Kid 1st (30d)", fontSize = 10.sp) }
                            )
                        }
                        item {
                            SuggestionChip(
                                onClick = {
                                    product = "Levamisole Hydrochloride"
                                    activeIngredient = "Levamisole (Rotated)"
                                    dose = "1 ml / 5 kg (7.5 mg/kg)"
                                    route = "Oral Drench"
                                    selectedScheduleType = "AGE-BASED / KID"
                                    reason = "Kid 2nd Deworming (60 Days - Rotated)"
                                    val cal = Calendar.getInstance()
                                    cal.add(Calendar.DAY_OF_YEAR, 30)
                                    nextDueDate = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(cal.time)
                                },
                                label = { Text("Kid 2nd (60d)", fontSize = 10.sp) }
                            )
                        }
                        item {
                            SuggestionChip(
                                onClick = {
                                    product = "Oxyclozanide + Levamisole"
                                    activeIngredient = "Oxyclozanide + Levamisole"
                                    dose = "1 ml / 4 kg"
                                    route = "Oral Drench"
                                    selectedScheduleType = "AGE-BASED / WEANING"
                                    reason = "Kid 3rd Deworming - Weaning (90 Days)"
                                    val cal = Calendar.getInstance()
                                    cal.add(Calendar.DAY_OF_YEAR, 60)
                                    nextDueDate = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(cal.time)
                                },
                                label = { Text("Weaning (90d)", fontSize = 10.sp) }
                            )
                        }
                        item {
                            SuggestionChip(
                                onClick = {
                                    product = "Closantel Oral Suspension 5%"
                                    activeIngredient = "Closantel"
                                    dose = "1 ml / 5 kg (10 mg/kg)"
                                    route = "Oral Drench"
                                    selectedScheduleType = "GROWING (3-6m)"
                                    reason = "Growing Weaner Deworming"
                                    val cal = Calendar.getInstance()
                                    cal.add(Calendar.DAY_OF_YEAR, 60)
                                    nextDueDate = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(cal.time)
                                },
                                label = { Text("Growing (3-6m)", fontSize = 10.sp) }
                            )
                        }
                        item {
                            SuggestionChip(
                                onClick = {
                                    product = "Ivermectin 1% Injection"
                                    activeIngredient = "Ivermectin"
                                    dose = "1 ml / 50 kg (0.2 mg/kg)"
                                    route = "Subcutaneous (S/C)"
                                    selectedScheduleType = "PRE-MONSOON"
                                    reason = "Pre-Monsoon Strategic Deworming"
                                    val cal = Calendar.getInstance()
                                    cal.add(Calendar.DAY_OF_YEAR, 90)
                                    nextDueDate = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(cal.time)
                                },
                                label = { Text("Pre-Monsoon", fontSize = 10.sp) }
                            )
                        }
                        item {
                            SuggestionChip(
                                onClick = {
                                    product = "Fenbendazole Suspension (Pregnancy Safe)"
                                    activeIngredient = "Fenbendazole"
                                    dose = "1 ml / 4 kg (5 mg/kg)"
                                    route = "Oral Drench"
                                    selectedScheduleType = "GESTATION SAFE"
                                    reason = "Late Gestation Safe Protocol"
                                    val cal = Calendar.getInstance()
                                    cal.add(Calendar.DAY_OF_YEAR, 120)
                                    nextDueDate = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(cal.time)
                                },
                                label = { Text("Late Gestation Safe", fontSize = 10.sp) }
                            )
                        }
                    }
                }

                // Deworming Schedule Type Selection
                item {
                    Text("Protocol Category *", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        scheduleTypes.forEach { st ->
                            FilterChip(
                                selected = selectedScheduleType == st,
                                onClick = { selectedScheduleType = st },
                                label = { Text(st, fontSize = 9.sp) },
                                colors = FilterChipDefaults.filterChipColors(selectedContainerColor = Color(0xFF059669), selectedLabelColor = Color.White)
                            )
                        }
                    }
                }

                // Animal Selection Mode
                item {
                    Text("Target Animals *", fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        listOf("INDIVIDUAL", "MULTIPLE", "ALL_HERD", "DOES", "KIDS").forEach { m ->
                            FilterChip(
                                selected = selectionMode == m,
                                onClick = { selectionMode = m },
                                label = { Text(m.replace("_", " "), fontSize = 10.sp) },
                                colors = FilterChipDefaults.filterChipColors(selectedContainerColor = FarmGreenDark, selectedLabelColor = Color.White)
                            )
                        }
                    }
                }

                if (selectionMode == "INDIVIDUAL") {
                    item {
                        ExposedDropdownMenuBox(expanded = singleGoatExpanded, onExpandedChange = { singleGoatExpanded = !singleGoatExpanded }) {
                            val cur = activeGoats.find { it.id == singleGoatId }
                            OutlinedTextField(
                                value = "${cur?.tag_c ?: "Select"} - ${cur?.name ?: ""}",
                                onValueChange = {},
                                readOnly = true,
                                label = { Text("Select Goat *") },
                                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = singleGoatExpanded) },
                                modifier = Modifier.fillMaxWidth().menuAnchor()
                            )
                            ExposedDropdownMenu(expanded = singleGoatExpanded, onDismissRequest = { singleGoatExpanded = false }) {
                                activeGoats.forEach { g ->
                                    DropdownMenuItem(
                                        text = { Text("${g.tag_c} - ${g.name} (${g.sex_c}, ${g.weight_kg_c ?: "--"} kg)") },
                                        onClick = {
                                            singleGoatId = g.id
                                            singleGoatExpanded = false
                                            if (g.weight_kg_c != null) {
                                                animalWeightStr = g.weight_kg_c.toString()
                                            }
                                        }
                                    )
                                }
                            }
                        }
                    }
                }

                item {
                    Text("Covered: ${coveredGoats.size} animal(s)", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = FarmGreenDark)
                }

                item {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = product,
                            onValueChange = { product = it },
                            label = { Text("Product / Brand *") },
                            modifier = Modifier.weight(1f).testTag("input_deworm_product")
                        )
                        OutlinedTextField(
                            value = activeIngredient,
                            onValueChange = { activeIngredient = it },
                            label = { Text("Active Ingredient") },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                item {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = dose,
                            onValueChange = { dose = it },
                            label = { Text("Dose *") },
                            placeholder = { Text("e.g. 5 ml") },
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = route,
                            onValueChange = { route = it },
                            label = { Text("Route") },
                            placeholder = { Text("Oral / S/C") },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                item {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = animalWeightStr,
                            onValueChange = { animalWeightStr = it },
                            label = { Text("Goat Weight (kg)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = fecCount,
                            onValueChange = { fecCount = it },
                            label = { Text("Faecal Egg Count (EPG)") },
                            placeholder = { Text("e.g. 650") },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                item {
                    DatePickerField(dateValue = treatmentDate, onDateSelected = { treatmentDate = it }, label = "Treatment Date *")
                }

                item {
                    DatePickerField(dateValue = nextDueDate, onDateSelected = { nextDueDate = it }, label = "Next Due Date (Target Booster) *")
                }

                item {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = batchNumber,
                            onValueChange = { batchNumber = it },
                            label = { Text("Batch Number") },
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = expiryDate,
                            onValueChange = { expiryDate = it },
                            label = { Text("Batch Expiry") },
                            placeholder = { Text("YYYY-MM") },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                item {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = veterinarian,
                            onValueChange = { veterinarian = it },
                            label = { Text("Veterinarian / Administered By") },
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = totalCostStr,
                            onValueChange = { totalCostStr = it },
                            label = { Text("Total Cost (₹)") },
                            placeholder = { Text("Creates Expense") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                item {
                    OutlinedTextField(
                        value = notes,
                        onValueChange = { notes = it },
                        label = { Text("Parasite Observation & Notes") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                item {
                    OutlinedTextField(
                        value = attachmentNote,
                        onValueChange = { attachmentNote = it },
                        label = { Text("Lab Report / Invoice Note") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                item {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                        TextButton(onClick = onDismiss) { Text("Cancel") }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = {
                                if (coveredGoats.isEmpty()) return@Button
                                val records = coveredGoats.map { g ->
                                    DewormingRecord(
                                        goat_id_c = g.id,
                                        medicine_c = product.ifBlank { "Deworming" },
                                        dose_c = dose.ifBlank { "5 ml" },
                                        treatment_date_c = treatmentDate,
                                        next_due_date_c = nextDueDate.ifBlank { null },
                                        weight_at_treatment_c = animalWeightStr.toDoubleOrNull() ?: g.weight_kg_c,
                                        administered_by_c = veterinarian.ifBlank { null },
                                        notes_c = buildString {
                                            append("Protocol: $selectedScheduleType. ")
                                            if (activeIngredient.isNotBlank()) append("AI: $activeIngredient. ")
                                            if (fecCount.isNotBlank()) append("FEC: $fecCount EPG. ")
                                            if (batchNumber.isNotBlank()) append("Batch: $batchNumber. ")
                                            if (notes.isNotBlank()) append(notes)
                                            if (attachmentNote.isNotBlank()) append(" [Doc: $attachmentNote]")
                                        }.ifBlank { null }
                                    )
                                }
                                val cost = totalCostStr.toDoubleOrNull()
                                onSave(records, cost, product)
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = FarmGreenDark),
                            modifier = Modifier.testTag("btn_save_deworming")
                        ) {
                            Text("Save for ${coveredGoats.size} Goat(s)")
                        }
                    }
                }
            }
        }
    }
}
