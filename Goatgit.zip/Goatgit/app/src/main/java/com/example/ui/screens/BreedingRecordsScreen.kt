package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Notes
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.offline.BreedingRecordEntity
import com.example.data.supabase.Goat
import com.example.data.supabase.GoatRepository
import com.example.ui.components.DatePickerField
import com.example.ui.components.FarmTopBar
import com.example.ui.theme.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.TimeUnit

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BreedingRecordsScreen(
    repository: GoatRepository,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    var breedingRecords by remember { mutableStateOf<List<BreedingRecordEntity>>(emptyList()) }
    var goats by remember { mutableStateOf<List<Goat>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }
    var showRecordDialog by remember { mutableStateOf(false) }
    var searchQuery by remember { mutableStateOf("") }
    var selectedFilter by remember { mutableStateOf("All") } // All, Active, Kidded

    fun loadData() {
        isLoading = true
        coroutineScope.launch {
            val recordsRes = repository.getBreedingRecords()
            val goatsRes = repository.getGoats()
            isLoading = false
            if (recordsRes.isSuccess) breedingRecords = recordsRes.getOrThrow()
            if (goatsRes.isSuccess) goats = goatsRes.getOrThrow()
        }
    }

    LaunchedEffect(Unit) {
        loadData()
    }

    val goatsMap = remember(goats) { goats.associateBy { it.id } }

    val filteredRecords = remember(breedingRecords, searchQuery, selectedFilter, goatsMap) {
        breedingRecords.filter { record ->
            val doe = goatsMap[record.doe_id]
            val buck = goatsMap[record.buck_id]
            val matchesQuery = searchQuery.isBlank() ||
                    (doe?.tag_c?.contains(searchQuery, ignoreCase = true) == true) ||
                    (doe?.name?.contains(searchQuery, ignoreCase = true) == true) ||
                    (buck?.tag_c?.contains(searchQuery, ignoreCase = true) == true) ||
                    (buck?.name?.contains(searchQuery, ignoreCase = true) == true) ||
                    (record.mating_date.contains(searchQuery)) ||
                    (record.expected_kidding_date.contains(searchQuery))

            val matchesFilter = when (selectedFilter) {
                "Active" -> record.status.equals("Active", ignoreCase = true)
                "Kidded" -> record.status.equals("Kidded", ignoreCase = true)
                else -> true
            }

            matchesQuery && matchesFilter
        }
    }

    Scaffold(
        topBar = {
            FarmTopBar(
                title = "Breeding Records",
                canNavigateBack = true,
                onNavigateBack = onNavigateBack,
                actions = {
                    IconButton(
                        onClick = {
                            com.example.notification.KiddingReminderScheduler.sendTestNotification(context)
                            Toast.makeText(context, "Test kidding alert sent to device notifications!", Toast.LENGTH_SHORT).show()
                        }
                    ) {
                        Icon(
                            Icons.Default.NotificationsActive,
                            contentDescription = "Test Kidding Alert",
                            tint = FarmGreenDark
                        )
                    }
                }
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { showRecordDialog = true },
                containerColor = FarmGreenDark,
                contentColor = Color.White,
                icon = { Icon(Icons.Default.Add, contentDescription = null) },
                text = { Text("Record Breeding", fontWeight = FontWeight.Bold) },
                modifier = Modifier.testTag("btn_add_breeding_record")
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(FarmBackgroundLight)
                .padding(padding)
        ) {
            // KPI Summary Header
            Surface(
                color = Color.White,
                shadowElevation = 1.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val activeCount = breedingRecords.count { it.status.equals("Active", ignoreCase = true) }
                    val kiddedCount = breedingRecords.count { it.status.equals("Kidded", ignoreCase = true) }

                    // Card 1: Total
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = Color(0xFFF1F5F9),
                        modifier = Modifier.weight(1f)
                    ) {
                        Column(
                            modifier = Modifier.padding(10.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text("Total Mated", fontSize = 11.sp, color = Color.Gray, fontWeight = FontWeight.SemiBold)
                            Text("${breedingRecords.size}", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = FarmGreenDark)
                        }
                    }

                    // Card 2: Active / Gestating
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = Color(0xFFE8F5E9),
                        modifier = Modifier.weight(1f)
                    ) {
                        Column(
                            modifier = Modifier.padding(10.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text("Gestating", fontSize = 11.sp, color = Color(0xFF2E7D32), fontWeight = FontWeight.SemiBold)
                            Text("$activeCount", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1B5E20))
                        }
                    }

                    // Card 3: Kidded
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = Color(0xFFFFF3E0),
                        modifier = Modifier.weight(1f)
                    ) {
                        Column(
                            modifier = Modifier.padding(10.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text("Kidded", fontSize = 11.sp, color = Color(0xFFE65100), fontWeight = FontWeight.SemiBold)
                            Text("$kiddedCount", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color(0xFFBF360C))
                        }
                    }
                }
            }

            // Search & Filter Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("Search by Tag, Name, Date...", fontSize = 12.sp) },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, modifier = Modifier.size(18.dp)) },
                    singleLine = true,
                    shape = RoundedCornerShape(10.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = Color.White,
                        unfocusedContainerColor = Color.White
                    ),
                    modifier = Modifier.weight(1f)
                )

                listOf("All", "Active", "Kidded").forEach { filter ->
                    FilterChip(
                        selected = selectedFilter == filter,
                        onClick = { selectedFilter = filter },
                        label = { Text(filter, fontSize = 11.sp) }
                    )
                }
            }

            if (isLoading) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = FarmGreenDark)
                }
            } else if (filteredRecords.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(Icons.Default.Favorite, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(48.dp))
                        Text("No breeding records found", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = Color.DarkGray)
                        Text("Tap '+ Record Breeding' below to log a mating date, buck/doe IDs, and expected kidding date.", fontSize = 12.sp, color = Color.Gray, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(start = 14.dp, end = 14.dp, bottom = 80.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(filteredRecords, key = { it.id }) { record ->
                        val doe = goatsMap[record.doe_id]
                        val buck = goatsMap[record.buck_id]

                        BreedingRecordCard(
                            record = record,
                            doe = doe,
                            buck = buck,
                            onDelete = {
                                coroutineScope.launch {
                                    repository.deleteBreedingRecord(record.id)
                                    loadData()
                                    Toast.makeText(context, "Record removed", Toast.LENGTH_SHORT).show()
                                }
                            }
                        )
                    }
                }
            }
        }
    }

    if (showRecordDialog) {
        AddBreedingRecordDialog(
            goats = goats,
            onDismiss = { showRecordDialog = false },
            onSave = { buckId, doeId, matingDate, expectedDate, method, notes, enablePush ->
                coroutineScope.launch {
                    val fullNotes = buildString {
                        append("Method: $method")
                        if (notes.isNotBlank()) append(" | $notes")
                    }
                    val newRecord = BreedingRecordEntity(
                        id = UUID.randomUUID().toString(),
                        buck_id = buckId,
                        doe_id = doeId,
                        mating_date = matingDate,
                        expected_kidding_date = expectedDate,
                        outcome_notes = fullNotes,
                        status = "Active"
                    )
                    val res = repository.saveBreedingRecord(newRecord)
                    if (res.isSuccess) {
                        loadData()
                        showRecordDialog = false
                        val doe = goatsMap[doeId]
                        val buck = goatsMap[buckId]
                        if (enablePush) {
                            com.example.notification.KiddingReminderScheduler.scheduleBreedingReminderNotification(
                                context = context,
                                doeTag = doe?.tag_c ?: "Doe",
                                buckTag = buck?.tag_c ?: "Buck",
                                serviceDate = matingDate,
                                expectedKiddingDate = expectedDate,
                                method = method
                            )
                            Toast.makeText(context, "Breeding service captured! Push notification reminders scheduled for $expectedDate.", Toast.LENGTH_LONG).show()
                        } else {
                            com.example.notification.KiddingReminderScheduler.triggerImmediateCheck(context)
                            Toast.makeText(context, "Breeding service saved successfully!", Toast.LENGTH_SHORT).show()
                        }
                    } else {
                        Toast.makeText(context, "Error saving breeding record", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        )
    }
}

@Composable
private fun BreedingRecordCard(
    record: BreedingRecordEntity,
    doe: Goat?,
    buck: Goat?,
    onDelete: () -> Unit
) {
    val dateFormat = remember { SimpleDateFormat("yyyy-MM-dd", Locale.US) }
    val today = remember { Date() }

    val daysLeft = remember(record.expected_kidding_date) {
        try {
            val due = dateFormat.parse(record.expected_kidding_date) ?: today
            TimeUnit.MILLISECONDS.toDays(due.time - today.time)
        } catch (_: Exception) { 0L }
    }

    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier.fillMaxWidth().testTag("breeding_record_item")
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Surface(
                        shape = CircleShape,
                        color = Color(0xFFFCE4EC),
                        modifier = Modifier.size(28.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(Icons.Default.Favorite, contentDescription = null, tint = Color(0xFFD81B60), modifier = Modifier.size(16.dp))
                        }
                    }
                    Text(
                        text = "Mating: ${record.mating_date}",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = FarmGreenDark
                    )
                }

                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = when {
                        record.status.equals("Kidded", ignoreCase = true) -> Color(0xFFE8F5E9)
                        daysLeft < 0 -> Color(0xFFFFEBEE)
                        daysLeft <= 14 -> Color(0xFFFFF3E0)
                        else -> Color(0xFFE3F2FD)
                    }
                ) {
                    Text(
                        text = when {
                            record.status.equals("Kidded", ignoreCase = true) -> "Kidded"
                            daysLeft < 0 -> "Overdue (${-daysLeft}d)"
                            daysLeft == 0L -> "Due Today!"
                            else -> "Due in ${daysLeft}d"
                        },
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = when {
                            record.status.equals("Kidded", ignoreCase = true) -> Color(0xFF2E7D32)
                            daysLeft < 0 -> Color(0xFFC62828)
                            daysLeft <= 14 -> Color(0xFFE65100)
                            else -> Color(0xFF1565C0)
                        },
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                    )
                }
            }

            HorizontalDivider(color = Color(0xFFF1F5F9))

            // Doe & Buck Info
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Doe
                Column(modifier = Modifier.weight(1f)) {
                    Text("Doe (Mother)", fontSize = 10.sp, color = Color.Gray, fontWeight = FontWeight.SemiBold)
                    Text(
                        text = doe?.let { "${it.tag_c} - ${it.name}" } ?: "ID: ${record.doe_id}",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF0F172A),
                        maxLines = 1
                    )
                }

                // Buck
                Column(modifier = Modifier.weight(1f)) {
                    Text("Buck (Sire)", fontSize = 10.sp, color = Color.Gray, fontWeight = FontWeight.SemiBold)
                    Text(
                        text = buck?.let { "${it.tag_c} - ${it.name}" } ?: "ID: ${record.buck_id}",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF0F172A),
                        maxLines = 1
                    )
                }
            }

            // Expected Kidding Date
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    Icon(Icons.Default.Event, contentDescription = null, tint = FarmAmber, modifier = Modifier.size(14.dp))
                    Text(
                        text = "Expected Kidding: ${record.expected_kidding_date}",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Color(0xFF334155)
                    )
                }

                IconButton(
                    onClick = onDelete,
                    modifier = Modifier.size(24.dp)
                ) {
                    Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color.LightGray, modifier = Modifier.size(16.dp))
                }
            }

            // Notes if available
            if (!record.outcome_notes.isNullOrBlank()) {
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = Color(0xFFF8FAFC),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(Icons.AutoMirrored.Filled.Notes, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(12.dp))
                        Text(
                            text = record.outcome_notes,
                            fontSize = 11.sp,
                            color = Color(0xFF64748B),
                            maxLines = 2
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AddBreedingRecordDialog(
    goats: List<Goat>,
    onDismiss: () -> Unit,
    onSave: (buckId: String, doeId: String, matingDate: String, expectedDate: String, method: String, notes: String, enablePush: Boolean) -> Unit
) {
    val context = LocalContext.current
    val dateFormat = remember { SimpleDateFormat("yyyy-MM-dd", Locale.US) }
    val today = remember { dateFormat.format(Date()) }

    var selectedDoeId by remember { mutableStateOf("") }
    var selectedBuckId by remember { mutableStateOf("") }
    var matingDate by remember { mutableStateOf(today) }
    var expectedKiddingDate by remember { mutableStateOf(calculateExpectedKidding(today)) }
    var matingMethod by remember { mutableStateOf("Natural Service") }
    var enablePushReminders by remember { mutableStateOf(true) }
    var notes by remember { mutableStateOf("") }
    var doeExpanded by remember { mutableStateOf(false) }
    var buckExpanded by remember { mutableStateOf(false) }

    val repeatHeatDate = remember(matingDate) { calculateReturnToHeat(matingDate) }

    val femaleGoats = remember(goats) {
        goats.filter { it.sex_c.equals("Doe", ignoreCase = true) || it.sex_c.equals("Female", ignoreCase = true) }
    }
    val maleGoats = remember(goats) {
        goats.filter { it.sex_c.equals("Buck", ignoreCase = true) || it.sex_c.equals("Male", ignoreCase = true) }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(Icons.Default.Favorite, contentDescription = null, tint = FarmGreenDark)
                Text("Capture Breeding Service", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "Log service details. Expected kidding date is automatically computed with 150-day gestation and automated push notification reminders.",
                    fontSize = 11.sp,
                    color = Color.Gray
                )

                // Select Dam (Doe)
                ExposedDropdownMenuBox(
                    expanded = doeExpanded,
                    onExpandedChange = { doeExpanded = it },
                    modifier = Modifier.fillMaxWidth().testTag("dropdown_doe")
                ) {
                    val doe = femaleGoats.firstOrNull { it.id == selectedDoeId }
                    OutlinedTextField(
                        value = doe?.let { "${it.tag_c} - ${it.name} (${it.breed_c.ifBlank { "Dam" }})" } ?: "",
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Dam / Doe ID *") },
                        placeholder = { Text("Select Dam (Doe)") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = doeExpanded) },
                        modifier = Modifier.menuAnchor().fillMaxWidth()
                    )
                    ExposedDropdownMenu(
                        expanded = doeExpanded,
                        onDismissRequest = { doeExpanded = false }
                    ) {
                        femaleGoats.forEach { d ->
                            DropdownMenuItem(
                                text = { Text("${d.tag_c} - ${d.name} (${d.breed_c.ifBlank { "Dam" }})") },
                                onClick = {
                                    selectedDoeId = d.id
                                    doeExpanded = false
                                }
                            )
                        }
                    }
                }

                // Select Sire (Buck)
                ExposedDropdownMenuBox(
                    expanded = buckExpanded,
                    onExpandedChange = { buckExpanded = it },
                    modifier = Modifier.fillMaxWidth().testTag("dropdown_buck")
                ) {
                    val buck = maleGoats.firstOrNull { it.id == selectedBuckId }
                    OutlinedTextField(
                        value = buck?.let { "${it.tag_c} - ${it.name} (${it.breed_c.ifBlank { "Sire" }})" } ?: "",
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Sire / Buck ID *") },
                        placeholder = { Text("Select Sire (Buck)") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = buckExpanded) },
                        modifier = Modifier.menuAnchor().fillMaxWidth()
                    )
                    ExposedDropdownMenu(
                        expanded = buckExpanded,
                        onDismissRequest = { buckExpanded = false }
                    ) {
                        maleGoats.forEach { b ->
                            DropdownMenuItem(
                                text = { Text("${b.tag_c} - ${b.name} (${b.breed_c.ifBlank { "Sire" }})") },
                                onClick = {
                                    selectedBuckId = b.id
                                    buckExpanded = false
                                }
                            )
                        }
                    }
                }

                // Service / Mating Method
                Text("Service Method", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = Color.DarkGray)
                Row(
                    modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    listOf("Natural Service", "Artificial Insemination (AI)", "Hand Mating", "Pen Mating").forEach { m ->
                        FilterChip(
                            selected = matingMethod == m,
                            onClick = { matingMethod = m },
                            label = { Text(m, fontSize = 11.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = FarmGreenDark,
                                selectedLabelColor = Color.White
                            )
                        )
                    }
                }

                // Service Date (Mating Date)
                DatePickerField(
                    dateValue = matingDate,
                    onDateSelected = { newDate ->
                        matingDate = newDate
                        expectedKiddingDate = calculateExpectedKidding(newDate)
                    },
                    label = "Service Date (Mating) *"
                )

                // Predicted Kidding Date & Gestation Intel Card
                Card(
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFF0FDF4)),
                    border = BorderStroke(1.dp, Color(0xFFBBF7D0)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(10.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Icon(Icons.Default.DateRange, contentDescription = null, tint = FarmGreenDark, modifier = Modifier.size(16.dp))
                                Text("Predicted Kidding Date", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = FarmGreenDark)
                            }
                            Surface(color = FarmGreenDark, shape = RoundedCornerShape(4.dp)) {
                                Text("150-Day Gestation", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color.White, modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp))
                            }
                        }

                        Text(
                            text = expectedKiddingDate,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 15.sp,
                            color = FarmGreenDark
                        )

                        HorizontalDivider(color = Color(0xFFDCFCE7))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Repeat Heat Check (18-21d):", fontSize = 10.sp, color = Color.DarkGray)
                            Text(repeatHeatDate, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color(0xFFD97706))
                        }
                    }
                }

                // Push Notification Reminders Settings
                Card(
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = if (enablePushReminders) Color(0xFFFAF5FF) else Color(0xFFF8FAFC)),
                    border = BorderStroke(1.dp, if (enablePushReminders) Color(0xFFE9D5FF) else Color(0xFFE2E8F0)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(10.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Icon(
                                    if (enablePushReminders) Icons.Default.NotificationsActive else Icons.Default.NotificationsOff,
                                    contentDescription = null,
                                    tint = if (enablePushReminders) Color(0xFF7B1FA2) else Color.Gray,
                                    modifier = Modifier.size(16.dp)
                                )
                                Text("Push Notification Reminders", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color(0xFF1E293B))
                            }
                            Switch(
                                checked = enablePushReminders,
                                onCheckedChange = { enablePushReminders = it },
                                modifier = Modifier.testTag("switch_breeding_push_reminders")
                            )
                        }

                        if (enablePushReminders) {
                            Text(
                                text = "Scheduled Push Reminders for this Breeding:\n" +
                                        "• Day +21: Repeat Heat Check\n" +
                                        "• Day +120: CD&T Pre-Kidding Booster\n" +
                                        "• Day +143: 7-Day Maternity Pen Prep\n" +
                                        "• Day +149: 24h Labor Watch\n" +
                                        "• Day +150: Expected Kidding Delivery Alert",
                                fontSize = 10.sp,
                                color = Color(0xFF6B21A8)
                            )
                        }
                    }
                }

                // Notes
                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Breeding Notes / Observations") },
                    placeholder = { Text("e.g. Active standing heat, confirmed visual mounting") },
                    modifier = Modifier.fillMaxWidth(),
                    maxLines = 3
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (selectedDoeId.isNotBlank() && selectedBuckId.isNotBlank() && matingDate.isNotBlank()) {
                        onSave(selectedBuckId, selectedDoeId, matingDate, expectedKiddingDate, matingMethod, notes, enablePushReminders)
                    }
                },
                enabled = selectedDoeId.isNotBlank() && selectedBuckId.isNotBlank() && matingDate.isNotBlank(),
                colors = ButtonDefaults.buttonColors(containerColor = FarmGreenDark),
                modifier = Modifier.testTag("btn_save_breeding_record")
            ) {
                Text("Save Breeding Service")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

private fun calculateExpectedKidding(matingDateStr: String): String {
    val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
    return try {
        val date = sdf.parse(matingDateStr) ?: Date()
        val cal = Calendar.getInstance()
        cal.time = date
        cal.add(Calendar.DAY_OF_YEAR, 150) // 150 days average goat gestation
        sdf.format(cal.time)
    } catch (_: Exception) {
        matingDateStr
    }
}

private fun calculateReturnToHeat(matingDateStr: String): String {
    val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
    return try {
        val date = sdf.parse(matingDateStr) ?: Date()
        val cal = Calendar.getInstance()
        cal.time = date
        cal.add(Calendar.DAY_OF_YEAR, 21) // 21 days caprine estrous cycle
        sdf.format(cal.time)
    } catch (_: Exception) {
        matingDateStr
    }
}
