package com.example.i18n

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.ripple.rememberRipple
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.FarmGreenDark
import com.example.ui.theme.FarmGreenContainer
import com.example.ui.theme.FarmOnGreenContainer

@Composable
fun LanguageToggle(
    currentLanguage: AppLanguage,
    onLanguageChange: (AppLanguage) -> Unit,
    modifier: Modifier = Modifier,
    isDarkHeader: Boolean = true
) {
    // Elegant pill toggle: English | தமிழ் with minimum 48dp touch target
    val backgroundColor = if (isDarkHeader) Color.White.copy(alpha = 0.18f) else MaterialTheme.colorScheme.surfaceVariant
    val borderColor = if (isDarkHeader) Color.White.copy(alpha = 0.35f) else MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)

    Surface(
        modifier = modifier
            .clip(RoundedCornerShape(24.dp))
            .border(1.dp, borderColor, RoundedCornerShape(24.dp))
            .testTag("language_toggle_container"),
        shape = RoundedCornerShape(24.dp),
        color = backgroundColor
    ) {
        Row(
            modifier = Modifier.padding(2.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // English item
            val isEnSelected = currentLanguage == AppLanguage.ENGLISH
            val enBg = if (isEnSelected) {
                if (isDarkHeader) Color.White else FarmGreenDark
            } else Color.Transparent
            val enText = if (isEnSelected) {
                if (isDarkHeader) FarmGreenDark else Color.White
            } else {
                if (isDarkHeader) Color.White.copy(alpha = 0.9f) else MaterialTheme.colorScheme.onSurfaceVariant
            }

            Box(
                modifier = Modifier
                    .defaultMinSize(minWidth = 52.dp, minHeight = 48.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .background(enBg)
                    .clickable(
                        role = Role.RadioButton,
                        onClick = { onLanguageChange(AppLanguage.ENGLISH) }
                    )
                    .padding(horizontal = 10.dp, vertical = 6.dp)
                    .testTag("lang_toggle_en"),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "English",
                    fontSize = 12.sp,
                    fontWeight = if (isEnSelected) FontWeight.Bold else FontWeight.Medium,
                    color = enText
                )
            }

            // Divider line
            Box(
                modifier = Modifier
                    .width(1.dp)
                    .height(20.dp)
                    .background(if (isDarkHeader) Color.White.copy(alpha = 0.3f) else MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))
            )

            // Tamil item
            val isTaSelected = currentLanguage == AppLanguage.TAMIL
            val taBg = if (isTaSelected) {
                if (isDarkHeader) Color.White else FarmGreenDark
            } else Color.Transparent
            val taText = if (isTaSelected) {
                if (isDarkHeader) FarmGreenDark else Color.White
            } else {
                if (isDarkHeader) Color.White.copy(alpha = 0.9f) else MaterialTheme.colorScheme.onSurfaceVariant
            }

            Box(
                modifier = Modifier
                    .defaultMinSize(minWidth = 52.dp, minHeight = 48.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .background(taBg)
                    .clickable(
                        role = Role.RadioButton,
                        onClick = { onLanguageChange(AppLanguage.TAMIL) }
                    )
                    .padding(horizontal = 10.dp, vertical = 6.dp)
                    .testTag("lang_toggle_ta"),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "தமிழ்",
                    fontSize = 12.sp,
                    fontWeight = if (isTaSelected) FontWeight.Bold else FontWeight.Medium,
                    color = taText
                )
            }
        }
    }
}
