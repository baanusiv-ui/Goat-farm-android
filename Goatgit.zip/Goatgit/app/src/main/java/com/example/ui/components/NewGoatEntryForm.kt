package com.example.ui.components

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.supabase.Goat
import com.example.data.supabase.GoatRepository
import com.example.data.supabase.GoatWeight
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

/**
 * 'New Goat Entry' form component that allows users to input:
 * - Breed
 * - Birth Date
 * - Weight (kg)
 * - Tag ID & Name
 * - Gender & Status
 *
 * Saves directly to the local Room database (local_goats & local_goat_weights).
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NewGoatEntryForm(
    repository: GoatRepository,
    onGoatSaved: (Goat) -> Unit,
    onCancel: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val dateFormat = remember { SimpleDateFormat("yyyy-MM-dd", Locale.US) }
    val today = remember { dateFormat.format(Date()) }

    // Form state
    var tagId by remember { mutableStateOf("") }
    var goatName by remember { mutableStateOf("") }
    var selectedBreed by remember { mutableStateOf("Boer") }
    var birthDate by remember { mutableStateOf(today) }
    var weightStr by remember { mutableStateOf("") }
    var selectedSex by remember { mutableStateOf("Doe") }
    var selectedStatus by remember { mutableStateOf("Active") }
    var barnLocation by remember { mutableStateOf("Main Shed") }
    var notes by remember { mutableStateOf("") }

    var isSaving by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var breedExpanded by remember { mutableStateOf(false) }
    var statusExpanded by remember { mutableStateOf(false) }

    val commonBreeds = listOf(
        "Salem Karupu",
        "Kodi Adu",
        "Boer",
        "Sirohi",
        "Jamnapari",
        "Beetal",
        "Barbari",
        "Osmanabadi",
        "Black Bengal",
        "Saanen",
        "Alpine",
        "Nubian",
        "Kalahari Red",
        "Commercial Cross"
    )

    val sexes = listOf("Doe", "Buck", "Kid", "Wether")
    val statuses = listOf("Active", "Pregnant", "Lactating", "Quarantine")

    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(Color.White, RoundedCornerShape(16.dp))
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Form Title
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "New Goat Entry",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF003893)
                )
                Text(
                    text = "Saves immediately to local Room database",
                    style = MaterialTheme.typography.labelSmall,
                    color = Color.Gray
                )
            }
            IconButton(onClick = onCancel) {
                Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.Gray)
            }
        }

        HorizontalDivider(color = Color(0xFFEEEEEE), thickness = 1.dp)

        // 1. Tag ID & Goat Name
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            OutlinedTextField(
                value = tagId,
                onValueChange = { tagId = it.uppercase(); errorMessage = null },
                label = { Text("Ear Tag / UID *") },
                placeholder = { Text("e.g. GT-101") },
                singleLine = true,
                modifier = Modifier
                    .weight(1f)
                    .testTag("new_goat_tag_input")
            )
            OutlinedTextField(
                value = goatName,
                onValueChange = { goatName = it },
                label = { Text("Goat Name") },
                placeholder = { Text("Optional") },
                singleLine = true,
                modifier = Modifier
                    .weight(1.2f)
                    .testTag("new_goat_name_input")
            )
        }

        // 2. Breed Selection Dropdown
        ExposedDropdownMenuBox(
            expanded = breedExpanded,
            onExpandedChange = { breedExpanded = !breedExpanded }
        ) {
            OutlinedTextField(
                value = selectedBreed,
                onValueChange = {},
                readOnly = true,
                label = { Text("Breed *") },
                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = breedExpanded) },
                modifier = Modifier
                    .fillMaxWidth()
                    .menuAnchor()
                    .testTag("new_goat_breed_select")
            )
            ExposedDropdownMenu(
                expanded = breedExpanded,
                onDismissRequest = { breedExpanded = false }
            ) {
                commonBreeds.forEach { breed ->
                    DropdownMenuItem(
                        text = { Text(breed) },
                        onClick = {
                            selectedBreed = breed
                            breedExpanded = false
                        }
                    )
                }
            }
        }

        // 3. Gender / Sex Selection Chips
        Column {
            Text(
                text = "Gender / Sex",
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.SemiBold,
                color = Color(0xFF37474F)
            )
            Spacer(modifier = Modifier.height(6.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                sexes.forEach { sex ->
                    FilterChip(
                        selected = selectedSex == sex,
                        onClick = { selectedSex = sex },
                        label = { Text(sex, fontSize = 12.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = Color(0xFF003893),
                            selectedLabelColor = Color.White
                        ),
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        // 4. Birth Date & Initial Weight (kg)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            DatePickerField(
                dateValue = birthDate,
                onDateSelected = { birthDate = it },
                label = "Birth Date",
                modifier = Modifier
                    .weight(1.2f)
                    .testTag("new_goat_dob_input")
            )

            OutlinedTextField(
                value = weightStr,
                onValueChange = { weightStr = it; errorMessage = null },
                label = { Text("Weight (kg)") },
                placeholder = { Text("e.g. 15.5") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                singleLine = true,
                modifier = Modifier
                    .weight(1f)
                    .testTag("new_goat_weight_input")
            )
        }

        // 5. Status & Barn Location
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            ExposedDropdownMenuBox(
                expanded = statusExpanded,
                onExpandedChange = { statusExpanded = !statusExpanded },
                modifier = Modifier.weight(1f)
            ) {
                OutlinedTextField(
                    value = selectedStatus,
                    onValueChange = {},
                    readOnly = true,
                    label = { Text("Status") },
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = statusExpanded) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .menuAnchor()
                )
                ExposedDropdownMenu(
                    expanded = statusExpanded,
                    onDismissRequest = { statusExpanded = false }
                ) {
                    statuses.forEach { st ->
                        DropdownMenuItem(
                            text = { Text(st) },
                            onClick = {
                                selectedStatus = st
                                statusExpanded = false
                            }
                        )
                    }
                }
            }

            OutlinedTextField(
                value = barnLocation,
                onValueChange = { barnLocation = it },
                label = { Text("Barn / Pen") },
                placeholder = { Text("e.g. Barn A") },
                singleLine = true,
                modifier = Modifier.weight(1f)
            )
        }

        // 6. Notes
        OutlinedTextField(
            value = notes,
            onValueChange = { notes = it },
            label = { Text("Notes (Optional)") },
            placeholder = { Text("Color, markings, health remarks...") },
            modifier = Modifier.fillMaxWidth(),
            minLines = 2,
            maxLines = 3
        )

        // Error Feedback
        if (!errorMessage.isNullOrBlank()) {
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = Color(0xFFFFEBEE),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = errorMessage ?: "",
                    color = Color(0xFFC62828),
                    fontSize = 12.sp,
                    modifier = Modifier.padding(10.dp)
                )
            }
        }

        // Action Buttons: Cancel and Save to Local Room DB
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            OutlinedButton(
                onClick = onCancel,
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(10.dp)
            ) {
                Text("Cancel")
            }

            Button(
                onClick = {
                    if (tagId.isBlank()) {
                        errorMessage = "Please enter an Ear Tag ID"
                        return@Button
                    }
                    val effectiveName = if (goatName.isBlank()) "Goat $tagId" else goatName.trim()
                    val parsedWeight = weightStr.toDoubleOrNull()

                    val newGoat = Goat(
                        id = UUID.randomUUID().toString(),
                        name = effectiveName,
                        tag_c = tagId.trim(),
                        breed_c = selectedBreed,
                        sex_c = selectedSex,
                        status_c = selectedStatus,
                        birth_date_c = birthDate.ifBlank { null },
                        weight_kg_c = parsedWeight,
                        farm_location_c = barnLocation.ifBlank { null },
                        notes_c = notes.ifBlank { null }
                    )

                    isSaving = true
                    errorMessage = null
                    coroutineScope.launch {
                        // 1. Save goat to local Room database
                        val res = repository.addGoat(newGoat)
                        if (res.isSuccess) {
                            // 2. If weight is provided, record baseline weight in local_goat_weights
                            if (parsedWeight != null && parsedWeight > 0.0) {
                                val weightRecord = GoatWeight(
                                    goat_id_c = newGoat.id,
                                    weight_kg_c = parsedWeight,
                                    date_c = birthDate.ifBlank { today },
                                    notes_c = "Initial birth/entry weight"
                                )
                                repository.recordWeight(weightRecord)
                            }
                            Toast.makeText(context, "Goat ${newGoat.tag_c} saved to local database!", Toast.LENGTH_SHORT).show()
                            onGoatSaved(newGoat)
                        } else {
                            errorMessage = res.exceptionOrNull()?.message ?: "Failed to save goat"
                        }
                        isSaving = false
                    }
                },
                enabled = !isSaving,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF003893)),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .weight(1.5f)
                    .testTag("save_new_goat_button")
            ) {
                if (isSaving) {
                    CircularProgressIndicator(color = Color.White, modifier = Modifier.size(20.dp))
                } else {
                    Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Save to Local DB", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

/**
 * Dialog wrapper for the NewGoatEntryForm component.
 */
@Composable
fun NewGoatEntryDialog(
    repository: GoatRepository,
    onGoatSaved: (Goat) -> Unit,
    onDismiss: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        NewGoatEntryForm(
            repository = repository,
            onGoatSaved = onGoatSaved,
            onCancel = onDismiss,
            modifier = Modifier.fillMaxWidth()
        )
    }
}
