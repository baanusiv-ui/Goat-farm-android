package com.example.data.backup

import android.content.Context
import android.content.Intent
import android.util.Log
import com.google.android.gms.auth.GoogleAuthUtil
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.Scope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext

class GoogleAuthManager(private val context: Context) {
    companion object {
        const val DRIVE_FILE_SCOPE = "https://www.googleapis.com/auth/drive.file"
        private const val PREFS_NAME = "google_drive_backup_prefs"
        private const val KEY_CONNECTED_EMAIL = "connected_google_account_email"
        private const val TAG = "GoogleAuthManager"
    }

    private val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    private val _connectedAccountEmail = MutableStateFlow<String?>(prefs.getString(KEY_CONNECTED_EMAIL, null))
    val connectedAccountEmail: StateFlow<String?> = _connectedAccountEmail.asStateFlow()

    private val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
        .requestEmail()
        .requestScopes(Scope(DRIVE_FILE_SCOPE))
        .build()

    val signInClient: GoogleSignInClient = GoogleSignIn.getClient(context, gso)

    init {
        // Sync with Google Play Services current signed-in account if present
        val currentAccount = GoogleSignIn.getLastSignedInAccount(context)
        if (currentAccount != null && GoogleSignIn.hasPermissions(currentAccount, Scope(DRIVE_FILE_SCOPE))) {
            val email = currentAccount.email ?: "Connected"
            _connectedAccountEmail.value = email
            prefs.edit().putString(KEY_CONNECTED_EMAIL, email).apply()
        }
    }

    fun isConnected(): Boolean {
        val currentAccount = GoogleSignIn.getLastSignedInAccount(context)
        val hasScope = currentAccount != null && GoogleSignIn.hasPermissions(currentAccount, Scope(DRIVE_FILE_SCOPE))
        return hasScope && !_connectedAccountEmail.value.isNullOrBlank()
    }

    fun getSignInIntent(): Intent {
        return signInClient.signInIntent
    }

    fun handleSignInResult(account: GoogleSignInAccount?): Boolean {
        if (account != null && GoogleSignIn.hasPermissions(account, Scope(DRIVE_FILE_SCOPE))) {
            val email = account.email ?: "Google Account"
            _connectedAccountEmail.value = email
            prefs.edit().putString(KEY_CONNECTED_EMAIL, email).apply()
            Log.d(TAG, "Successfully connected Google account: $email")
            return true
        }
        return false
    }

    suspend fun getAccessToken(): Result<String> = withContext(Dispatchers.IO) {
        try {
            val account = GoogleSignIn.getLastSignedInAccount(context)
                ?: return@withContext Result.failure(Exception("No Google account signed in. Please connect Google Drive first."))

            val androidAccount = account.account
                ?: return@withContext Result.failure(Exception("Google account details not found"))

            val oauthScope = "oauth2:$DRIVE_FILE_SCOPE"
            val token = GoogleAuthUtil.getToken(context, androidAccount, oauthScope)
            Result.success(token)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to retrieve Google OAuth access token: ${e.message}", e)
            Result.failure(e)
        }
    }

    suspend fun clearCurrentToken(token: String) = withContext(Dispatchers.IO) {
        try {
            GoogleAuthUtil.clearToken(context, token)
        } catch (e: Exception) {
            Log.w(TAG, "Failed to clear expired token: ${e.message}")
        }
    }

    suspend fun disconnect() = withContext(Dispatchers.IO) {
        try {
            signInClient.signOut()
            signInClient.revokeAccess()
        } catch (e: Exception) {
            Log.w(TAG, "Sign out error: ${e.message}")
        } finally {
            _connectedAccountEmail.value = null
            prefs.edit().remove(KEY_CONNECTED_EMAIL).apply()
        }
    }
}
