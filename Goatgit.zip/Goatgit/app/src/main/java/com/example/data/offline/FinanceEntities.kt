package com.example.data.offline

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.UUID

@Entity(tableName = "local_financial_accounts")
data class FinancialAccountEntity(
    @PrimaryKey
    val id: String = UUID.randomUUID().toString(),
    val account_name: String,
    val account_type: String = "CASH", // CASH, BANK, UPI, OTHER
    val account_number: String? = null,
    val upi_id: String? = null,
    val bank_name: String? = null,
    val ifsc_code: String? = null,
    val branch: String? = null,
    val opening_balance: Double = 0.0,
    val current_balance: Double = opening_balance,
    val opening_date: String? = null,
    val is_active: Boolean = true,
    val created_at: String? = null,
    val updated_at: Long = System.currentTimeMillis(),
    val is_synced: Boolean = false
)

@Entity(tableName = "local_account_transactions")
data class AccountTransactionEntity(
    @PrimaryKey
    val id: String = UUID.randomUUID().toString(),
    val date: String,
    val account_id: String,
    val transaction_type: String, // INCOME, EXPENSE, TRANSFER, DEPOSIT, WITHDRAWAL...
    val amount: Double,
    val category: String,
    val payment_mode: String = "Cash", // Cash, Bank Transfer, UPI, Cheque, Card
    val reference_id: String? = null,
    val to_account_id: String? = null,
    val affects_pnl: Boolean = true, // False for TRANSFER, LOAN_RECEIPT, OWNER_INVESTMENT...
    val pillar: String = "OPERATING", // OPERATING, INVESTING, FINANCING, NON_CASH
    val description: String? = null,
    val related_entity_type: String? = null,
    val related_entity_id: String? = null,
    val created_by: String = "user",
    val created_at: String? = null,
    val updated_at: Long = System.currentTimeMillis(),
    val is_synced: Boolean = false
)

@Entity(tableName = "local_recurring_expenses")
data class RecurringExpenseEntity(
    @PrimaryKey
    val id: String = UUID.randomUUID().toString(),
    val expense_name: String,
    val category: String,
    val vendor: String? = null,
    val amount: Double,
    val frequency: String = "MONTHLY",
    val start_date: String,
    val end_date: String? = null,
    val next_due_date: String,
    val payment_account_id: String? = null,
    val payment_method: String = "BANK",
    val gst_applicable: Boolean = false,
    val gst_rate: Double = 0.0,
    val notes: String? = null,
    val is_active: Boolean = true,
    val created_at: String? = null,
    val updated_at: Long = System.currentTimeMillis(),
    val is_synced: Boolean = false
)

@Entity(tableName = "local_electricity_connections")
data class ElectricityConnectionEntity(
    @PrimaryKey
    val id: String = UUID.randomUUID().toString(),
    val connection_name: String,
    val consumer_number: String,
    val meter_number: String,
    val service_provider: String,
    val tariff_category: String = "Agricultural",
    val location: String = "Main Shed",
    val billing_cycle: String = "Monthly",
    val is_active: Boolean = true,
    val created_at: String? = null,
    val updated_at: Long = System.currentTimeMillis(),
    val is_synced: Boolean = false
)

@Entity(tableName = "local_electricity_bills")
data class ElectricityBillEntity(
    @PrimaryKey
    val id: String = UUID.randomUUID().toString(),
    val connection_id: String,
    val billing_period: String,
    val bill_date: String,
    val due_date: String,
    val previous_reading: Double,
    val current_reading: Double,
    val units_consumed: Double,
    val base_amount: Double,
    val other_charges: Double = 0.0,
    val tax_amount: Double = 0.0,
    val total_bill: Double,
    val paid_amount: Double = 0.0,
    val balance_amount: Double,
    val payment_date: String? = null,
    val payment_account_id: String? = null,
    val payment_status: String = "UNPAID",
    val notes: String? = null,
    val created_at: String? = null,
    val updated_at: Long = System.currentTimeMillis(),
    val is_synced: Boolean = false
)

@Entity(tableName = "local_loans")
data class LoanEntity(
    @PrimaryKey
    val id: String = UUID.randomUUID().toString(),
    val lender: String,
    val loan_name: String,
    val loan_account_number: String,
    val loan_type: String = "BANK_LOAN",
    val sanctioned_amount: Double,
    val disbursed_amount: Double,
    val interest_rate: Double,
    val interest_type: String = "Diminishing",
    val tenure_months: Int,
    val emi_amount: Double,
    val start_date: String,
    val first_emi_date: String,
    val maturity_date: String,
    val processing_fee: Double = 0.0,
    val outstanding_principal: Double,
    val total_interest_paid: Double = 0.0,
    val total_principal_paid: Double = 0.0,
    val disbursement_account_id: String? = null,
    val status: String = "ACTIVE",
    val notes: String? = null,
    val created_at: String? = null,
    val updated_at: Long = System.currentTimeMillis(),
    val is_synced: Boolean = false
)

@Entity(tableName = "local_loan_schedules")
data class LoanScheduleEntity(
    @PrimaryKey
    val id: String = UUID.randomUUID().toString(),
    val loan_id: String,
    val emi_number: Int,
    val due_date: String,
    val opening_principal: Double,
    val principal_component: Double,
    val interest_component: Double,
    val emi_amount: Double,
    val closing_principal: Double,
    val paid_date: String? = null,
    val paid_amount: Double = 0.0,
    val payment_account_id: String? = null,
    val status: String = "PENDING",
    val created_at: String? = null,
    val updated_at: Long = System.currentTimeMillis(),
    val is_synced: Boolean = false
)

@Entity(tableName = "local_suppliers")
data class SupplierEntity(
    @PrimaryKey
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val phone: String? = null,
    val address: String? = null,
    val gstin: String? = null,
    val credit_limit: Double = 0.0,
    val credit_period_days: Int = 30,
    val opening_balance: Double = 0.0,
    val current_outstanding: Double = 0.0,
    val is_active: Boolean = true,
    val created_at: String? = null,
    val updated_at: Long = System.currentTimeMillis(),
    val is_synced: Boolean = false
)

@Entity(tableName = "local_supplier_invoices")
data class SupplierInvoiceEntity(
    @PrimaryKey
    val id: String = UUID.randomUUID().toString(),
    val supplier_id: String,
    val invoice_number: String,
    val invoice_date: String,
    val due_date: String,
    val items_description: String,
    val quantity: Double = 1.0,
    val rate: Double = 0.0,
    val taxable_value: Double,
    val gst_rate: Double = 0.0,
    val gst_amount: Double = 0.0,
    val total_amount: Double,
    val paid_amount: Double = 0.0,
    val balance_due: Double,
    val status: String = "UNPAID",
    val notes: String? = null,
    val created_at: String? = null,
    val updated_at: Long = System.currentTimeMillis(),
    val is_synced: Boolean = false
)

@Entity(tableName = "local_supplier_payments")
data class SupplierPaymentEntity(
    @PrimaryKey
    val id: String = UUID.randomUUID().toString(),
    val invoice_id: String,
    val supplier_id: String,
    val payment_date: String,
    val amount: Double,
    val payment_account_id: String,
    val payment_mode: String = "BANK",
    val reference_number: String? = null,
    val notes: String? = null,
    val created_at: String? = null,
    val updated_at: Long = System.currentTimeMillis(),
    val is_synced: Boolean = false
)

@Entity(tableName = "local_gst_settings")
data class GstSettingsEntity(
    @PrimaryKey
    val id: String = "default_gst_settings",
    val gst_enabled: Boolean = false,
    val business_name: String = "Green Pastures Goat Farm",
    val business_address: String = "Farm Road, Rural District",
    val gstin: String = "",
    val state_name: String = "Tamil Nadu",
    val state_code: String = "33",
    val invoice_prefix: String = "INV",
    val next_invoice_number: Int = 1001,
    val default_hsn: String = "0104",
    val default_tax_rate: Double = 5.0,
    val updated_at: Long = System.currentTimeMillis()
)

@Entity(tableName = "local_eway_bills")
data class EWayBillEntity(
    @PrimaryKey
    val id: String = UUID.randomUUID().toString(),
    val invoice_id: String,
    val invoice_number: String,
    val supplier_gstin: String,
    val recipient_gstin: String? = null,
    val place_of_supply: String,
    val delivery_address: String,
    val hsn_code: String = "0104",
    val quantity: Double,
    val taxable_value: Double,
    val gst_amount: Double,
    val total_value: Double,
    val transporter_id: String? = null,
    val transporter_name: String? = null,
    val vehicle_number: String,
    val transport_mode: String = "Road",
    val transport_doc_number: String? = null,
    val document_date: String,
    val eway_bill_number: String? = null,
    val status: String = "Draft",
    val error_message: String? = null,
    val created_at: String? = null,
    val updated_at: Long = System.currentTimeMillis(),
    val is_synced: Boolean = false
)
