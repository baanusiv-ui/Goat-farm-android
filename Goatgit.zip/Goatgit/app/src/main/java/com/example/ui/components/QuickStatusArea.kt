package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.supabase.LiveDashboardMetrics

/**
 * Quick Status Area component displaying aggregate counts for:
 * 1. Total Goats
 * 2. Pregnant Goats
 * 3. Health Alerts (Vaccinations, Deworming, Treatments, Critical Reminders)
 * 4. Due for Delivery
 * 5. Kids & Offspring
 *
 * Sourced directly from the local Room database (AppDatabase).
 */
@Composable
fun QuickStatusArea(
    metrics: LiveDashboardMetrics,
    onTotalGoatsClick: () -> Unit = {},
    onPregnantGoatsClick: () -> Unit = {},
    onHealthAlertsClick: () -> Unit = {},
    onDueDeliveryClick: () -> Unit = {},
    onKidsClick: () -> Unit = {},
    onMortalityClick: () -> Unit = {},
    onWeaningClick: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(14.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = modifier
            .fillMaxWidth()
            .testTag("quick_status_area")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 10.dp, horizontal = 10.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 4.dp, vertical = 2.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "FARM LIVE STATUS",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    fontSize = 10.sp,
                    color = Color(0xFF003893),
                    letterSpacing = 0.8.sp
                )
                Text(
                    text = "Local Database • Offline-Ready",
                    style = MaterialTheme.typography.labelSmall,
                    fontSize = 9.sp,
                    color = Color.Gray
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            LazyRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // 1. TOTAL GOATS
                item {
                    QuickStatusCard(
                        title = "TOTAL GOATS",
                        count = "${metrics.totalGoats}",
                        subtitle = "Active Herd",
                        icon = Icons.Default.Pets,
                        color = Color(0xFF003893),
                        containerColor = Color(0xFFE8F0FE),
                        testTag = "status_total_goats",
                        onClick = onTotalGoatsClick
                    )
                }

                // 2. PREGNANT GOATS
                item {
                    QuickStatusCard(
                        title = "PREGNANT",
                        count = "${metrics.pregnantCount}",
                        subtitle = "Confirmed Does",
                        icon = Icons.Default.Favorite,
                        color = Color(0xFF8E24AA),
                        containerColor = Color(0xFFF3E5F5),
                        testTag = "status_pregnant_goats",
                        onClick = onPregnantGoatsClick
                    )
                }

                // 3. HEALTH ALERTS
                item {
                    val alertCount = metrics.vaccinationBadge + metrics.alertsBadge
                    QuickStatusCard(
                        title = "HEALTH ALERTS",
                        count = "$alertCount",
                        subtitle = if (alertCount > 0) "Requires Attention" else "All Healthy",
                        icon = Icons.Default.MedicalServices,
                        color = if (alertCount > 0) Color(0xFFD32F2F) else Color(0xFF2E7D32),
                        containerColor = if (alertCount > 0) Color(0xFFFFEBEE) else Color(0xFFE8F5E9),
                        testTag = "status_health_alerts",
                        onClick = onHealthAlertsClick
                    )
                }

                // 4. DUE FOR DELIVERY
                item {
                    QuickStatusCard(
                        title = "DUE DELIVERY",
                        count = "${metrics.dueForDeliveryCount}",
                        subtitle = "Expected Soon",
                        icon = Icons.Default.ChildCare,
                        color = Color(0xFFE65100),
                        containerColor = Color(0xFFFFF3E0),
                        testTag = "status_due_delivery",
                        onClick = onDueDeliveryClick
                    )
                }

                // 5. KIDS
                item {
                    QuickStatusCard(
                        title = "KIDS",
                        count = "${metrics.kidsCount}",
                        subtitle = "Young Stock",
                        icon = Icons.Default.ChildCare,
                        color = Color(0xFF00796B),
                        containerColor = Color(0xFFE0F2F1),
                        testTag = "status_kids",
                        onClick = onKidsClick
                    )
                }

                // 6. MORTALITY
                item {
                    QuickStatusCard(
                        title = "MORTALITY",
                        count = "${metrics.mortalityCount}",
                        subtitle = "Deceased",
                        icon = Icons.Default.WarningAmber,
                        color = Color(0xFFC62828),
                        containerColor = Color(0xFFFFEBEE),
                        testTag = "status_mortality",
                        onClick = onMortalityClick
                    )
                }

                // 7. WEANING DUE (Requirement 14)
                item {
                    QuickStatusCard(
                        title = "WEANING DUE",
                        count = "${metrics.weaningDueCount}",
                        subtitle = if (metrics.weaningDueCount > 0) "Action Required" else "On Track",
                        icon = Icons.Default.ChildCare,
                        color = Color(0xFFE65100),
                        containerColor = Color(0xFFFFF3E0),
                        testTag = "status_weaning_due",
                        onClick = onWeaningClick
                    )
                }
            }
        }
    }
}

@Composable
private fun QuickStatusCard(
    title: String,
    count: String,
    subtitle: String,
    icon: ImageVector,
    color: Color,
    containerColor: Color,
    testTag: String,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(12.dp),
        color = containerColor,
        modifier = Modifier
            .height(68.dp)
            .testTag(testTag)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(color.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = color,
                    modifier = Modifier.size(20.dp)
                )
            }

            Spacer(modifier = Modifier.width(10.dp))

            Column(verticalArrangement = Arrangement.Center) {
                Row(verticalAlignment = Alignment.Bottom) {
                    Text(
                        text = count,
                        fontWeight = FontWeight.Bold,
                        fontSize = 17.sp,
                        color = color
                    )
                }
                Text(
                    text = title,
                    style = MaterialTheme.typography.labelSmall,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    color = color.copy(alpha = 0.9f)
                )
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.labelSmall,
                    fontSize = 8.sp,
                    color = color.copy(alpha = 0.7f)
                )
            }
        }
    }
}
