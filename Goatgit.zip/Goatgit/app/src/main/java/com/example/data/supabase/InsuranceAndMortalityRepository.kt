package com.example.data.supabase

import com.example.data.offline.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.TimeUnit

class InsuranceAndMortalityRepository(
    private val client: SupabaseClient,
    private val database: AppDatabase,
    private val syncManager: OfflineSyncManager,
    private val financeRepository: FinanceRepository
) {
    private val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.US)

    // ==============================================================================
    // 1. INSURANCE PROVIDERS & ADAPTERS
    // ==============================================================================
    suspend fun getProviders(includeInactive: Boolean = false): Result<List<InsuranceProvider>> = withContext(Dispatchers.IO) {
        try {
            var providers = if (includeInactive) {
                database.insuranceDao().getAllProvidersAdmin().map { it.toDomain() }
            } else {
                database.insuranceDao().getAllProviders().map { it.toDomain() }
            }

            val requiredInsurers = listOf(
                InsuranceProvider(id = "prov-01", name = "The New India Assurance Company Limited", company_name = "The New India Assurance Company Limited", code = "NIA", type = "GENERAL", is_active = true, notes = "Public sector general insurer; offers livestock policies"),
                InsuranceProvider(id = "prov-02", name = "United India Insurance Company Limited", company_name = "United India Insurance Company Limited", code = "UIIC", type = "GENERAL", is_active = true, notes = "Public sector general insurer; rural cattle and sheep/goat coverage"),
                InsuranceProvider(id = "prov-03", name = "The Oriental Insurance Company Limited", company_name = "The Oriental Insurance Company Limited", code = "OICL", type = "GENERAL", is_active = true, notes = "Public sector general insurer; livestock and rural insurance schemes"),
                InsuranceProvider(id = "prov-04", name = "National Insurance Company Limited", company_name = "National Insurance Company Limited", code = "NICL", type = "GENERAL", is_active = true, notes = "Public sector general insurer; subsidized small ruminant policies"),
                InsuranceProvider(id = "prov-05", name = "SBI General Insurance Company Limited", company_name = "SBI General Insurance Company Limited", code = "SBIG", type = "GENERAL", is_active = true, notes = "General insurance; cattle and rural micro-insurance products"),
                InsuranceProvider(id = "prov-06", name = "HDFC ERGO General Insurance Company Limited", company_name = "HDFC ERGO General Insurance Company Limited", code = "HDFC", type = "GENERAL", is_active = true, notes = "Private general insurer; rural and weather/livestock micro-insurance"),
                InsuranceProvider(id = "prov-07", name = "ICICI Lombard General Insurance Company Limited", company_name = "ICICI Lombard General Insurance Company Limited", code = "ICICI", type = "GENERAL", is_active = true, notes = "Private general insurer with rural and weather indexed insurance"),
                InsuranceProvider(id = "prov-08", name = "Bajaj General Insurance Limited", company_name = "Bajaj General Insurance Limited", code = "BAJAJ", type = "GENERAL", is_active = true, notes = "General insurer; rural animal insurance programs"),
                InsuranceProvider(id = "prov-09", name = "Tata AIG General Insurance Company Limited", company_name = "Tata AIG General Insurance Company Limited", code = "TATAAIG", type = "GENERAL", is_active = true, notes = "General insurer; rural livestock & property coverage"),
                InsuranceProvider(id = "prov-10", name = "IFFCO Tokio General Insurance Company Limited", company_name = "IFFCO Tokio General Insurance Company Limited", code = "IFFCO", type = "GENERAL", is_active = true, notes = "Rural-focused insurer with extensive farmer and livestock reach"),
                InsuranceProvider(id = "prov-11", name = "Cholamandalam MS General Insurance Company Limited", company_name = "Cholamandalam MS General Insurance Company Limited", code = "CHOLA", type = "GENERAL", is_active = true, notes = "General insurer; rural micro-insurance options"),
                InsuranceProvider(id = "prov-12", name = "Royal Sundaram General Insurance Company Limited", company_name = "Royal Sundaram General Insurance Company Limited", code = "ROYAL", type = "GENERAL", is_active = true, notes = "General insurance company"),
                InsuranceProvider(id = "prov-13", name = "Reliance General Insurance Company Limited", company_name = "Reliance General Insurance Company Limited", code = "RELIANCE", type = "GENERAL", is_active = true, notes = "General insurer with rural offerings"),
                InsuranceProvider(id = "prov-14", name = "Go Digit General Insurance Limited", company_name = "Go Digit General Insurance Limited", code = "DIGIT", type = "GENERAL", is_active = true, notes = "Digital-first general insurance provider"),
                InsuranceProvider(id = "prov-15", name = "Magma General Insurance Limited", company_name = "Magma General Insurance Limited", code = "MAGMA", type = "GENERAL", is_active = true, notes = "General insurance provider"),
                InsuranceProvider(id = "prov-16", name = "Liberty General Insurance Limited", company_name = "Liberty General Insurance Limited", code = "LIBERTY", type = "GENERAL", is_active = true, notes = "General insurer operating in India"),
                InsuranceProvider(id = "prov-17", name = "Shriram General Insurance Company Limited", company_name = "Shriram General Insurance Company Limited", code = "SHRIRAM", type = "GENERAL", is_active = true, notes = "Semi-urban & rural vehicle and general insurance"),
                InsuranceProvider(id = "prov-18", name = "Universal Sompo General Insurance Company Limited", company_name = "Universal Sompo General Insurance Company Limited", code = "SOMPO", type = "GENERAL", is_active = true, notes = "General insurer; cattle and livestock schemes"),
                InsuranceProvider(id = "prov-19", name = "Zuno General Insurance Limited", company_name = "Zuno General Insurance Limited", code = "ZUNO", type = "GENERAL", is_active = true, notes = "General insurance provider"),
                InsuranceProvider(id = "prov-20", name = "Navi General Insurance Limited", company_name = "Navi General Insurance Limited", code = "NAVI", type = "GENERAL", is_active = true, notes = "Digital general insurer"),
                InsuranceProvider(id = "prov-21", name = "Generali Central Insurance Company Limited", company_name = "Generali Central Insurance Company Limited", code = "GENERALI", type = "GENERAL", is_active = true, notes = "General insurance provider"),
                InsuranceProvider(id = "prov-22", name = "Zurich Kotak General Insurance Company Limited", company_name = "Zurich Kotak General Insurance Company Limited", code = "KOTAK", type = "GENERAL", is_active = true, notes = "General insurance provider"),
                InsuranceProvider(id = "prov-23", name = "Raheja QBE General Insurance Company Limited", company_name = "Raheja QBE General Insurance Company Limited", code = "RAHEJA", type = "GENERAL", is_active = true, notes = "General insurance provider"),
                InsuranceProvider(id = "prov-24", name = "Acko General Insurance Limited", company_name = "Acko General Insurance Limited", code = "ACKO", type = "GENERAL", is_active = true, notes = "Direct-to-consumer digital insurer")
            )

            // Ensure all 24 are present in the database without deleting historical custom entries
            val existingAdminList = database.insuranceDao().getAllProvidersAdmin()
            val existingNames = existingAdminList.map { it.company_name.lowercase().trim() }.toSet()
            for (req in requiredInsurers) {
                if (!existingNames.contains(req.company_name.lowercase().trim())) {
                    database.insuranceDao().insertProvider(req.toEntity(isSynced = true))
                }
            }

            providers = if (includeInactive) {
                database.insuranceDao().getAllProvidersAdmin().map { it.toDomain() }
            } else {
                database.insuranceDao().getAllProviders().map { it.toDomain() }
            }

            Result.success(providers)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun setProviderActive(providerId: String, isActive: Boolean): Result<Boolean> = withContext(Dispatchers.IO) {
        try {
            database.insuranceDao().setProviderActive(providerId, isActive)
            Result.success(true)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun saveProvider(provider: InsuranceProvider): Result<InsuranceProvider> = withContext(Dispatchers.IO) {
        try {
            val entity = provider.toEntity(isSynced = false)
            database.insuranceDao().insertProvider(entity)

            val json = JSONObject().apply {
                put("id", entity.id)
                put("name", entity.name)
                put("company_name", entity.company_name)
                if (!entity.api_base_url.isNullOrBlank()) put("api_base_url", entity.api_base_url)
                if (!entity.sandbox_url.isNullOrBlank()) put("sandbox_url", entity.sandbox_url)
                if (!entity.production_url.isNullOrBlank()) put("production_url", entity.production_url)
                put("api_version", entity.api_version)
                put("auth_type", entity.auth_type)
                put("is_active", entity.is_active)
                put("is_sandbox", entity.is_sandbox)
            }
            syncManager.enqueueOperation("insurance_providers", entity.id, "CREATE", json)
            Result.success(provider)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun getAdapterForProvider(provider: InsuranceProvider): InsuranceProviderAdapter {
        return ConfigurableInsuranceAdapter(provider)
    }

    // ==============================================================================
    // 2. POLICIES & QUOTES
    // ==============================================================================
    suspend fun getPolicies(): Result<List<InsurancePolicy>> = withContext(Dispatchers.IO) {
        try {
            val today = dateFormat.format(Date())
            val entities = database.insuranceDao().getAllPolicies()
            val list = entities.map { entity ->
                var domain = entity.toDomain()
                // Auto compute Expiring Soon status if within 30 days
                if (domain.status.equals("Active", ignoreCase = true)) {
                    val daysDiff = calculateDaysDiff(today, domain.expiry_date)
                    if (daysDiff <= 0) {
                        domain = domain.copy(status = "Expired")
                        database.insuranceDao().updatePolicyStatus(domain.id, "Expired")
                    } else if (daysDiff <= 30) {
                        domain = domain.copy(status = "Expiring Soon")
                        database.insuranceDao().updatePolicyStatus(domain.id, "Expiring Soon")
                    }
                }
                domain
            }
            Result.success(list)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getPoliciesForGoat(goatId: String): Result<List<InsurancePolicy>> = withContext(Dispatchers.IO) {
        try {
            val list = database.insuranceDao().getPoliciesForGoat(goatId).map { it.toDomain() }
            Result.success(list)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getActivePolicyForGoat(goatId: String): Result<InsurancePolicy?> = withContext(Dispatchers.IO) {
        try {
            val entity = database.insuranceDao().getActivePolicyForGoat(goatId)
            Result.success(entity?.toDomain())
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun savePolicy(policy: InsurancePolicy, paymentAccountId: String? = null): Result<InsurancePolicy> = withContext(Dispatchers.IO) {
        try {
            val entity = policy.toEntity(isSynced = false)
            database.insuranceDao().insertPolicy(entity)

            // Enqueue to Supabase
            val json = JSONObject().apply {
                put("id", entity.id)
                put("goat_id", entity.goat_id)
                put("goat_tag", entity.goat_tag)
                if (!entity.rfid.isNullOrBlank()) put("rfid", entity.rfid)
                if (!entity.goat_name.isNullOrBlank()) put("goat_name", entity.goat_name)
                if (!entity.provider_id.isNullOrBlank()) put("provider_id", entity.provider_id)
                put("insurance_company", entity.insurance_company)
                put("policy_name", entity.policy_name)
                if (!entity.policy_number.isNullOrBlank()) put("policy_number", entity.policy_number)
                if (!entity.proposal_number.isNullOrBlank()) put("proposal_number", entity.proposal_number)
                put("sum_insured", entity.sum_insured)
                put("market_value", entity.market_value)
                put("premium", entity.premium)
                put("tax_amount", entity.tax_amount)
                put("total_premium", entity.total_premium)
                put("start_date", entity.start_date)
                put("expiry_date", entity.expiry_date)
                if (!entity.renewal_date.isNullOrBlank()) put("renewal_date", entity.renewal_date)
                put("status", entity.status)
                put("coverage_type", entity.coverage_type)
                put("deductible", entity.deductible)
                if (!entity.agent_name.isNullOrBlank()) put("agent_name", entity.agent_name)
                if (!entity.agent_contact.isNullOrBlank()) put("agent_contact", entity.agent_contact)
                if (!entity.policy_document_url.isNullOrBlank()) put("policy_document_url", entity.policy_document_url)
                if (!entity.vet_certificate_url.isNullOrBlank()) put("vet_certificate_url", entity.vet_certificate_url)
                if (!entity.animal_photo_url.isNullOrBlank()) put("animal_photo_url", entity.animal_photo_url)
                if (!entity.eartag_photo_url.isNullOrBlank()) put("eartag_photo_url", entity.eartag_photo_url)
            }
            syncManager.enqueueOperation("insurance_policies", entity.id, "CREATE", json)

            // Generate De-duplicated Expiry Alerts (30, 15, 7, 3, 1, 0 days)
            generatePolicyAlerts(policy)

            // FINANCE INTEGRATION: If payment account is provided and premium > 0, record Operating Expense
            if (!paymentAccountId.isNullOrBlank() && policy.total_premium > 0) {
                financeRepository.recordExpense(
                    accountId = paymentAccountId,
                    amount = policy.total_premium,
                    category = "Insurance Premium",
                    date = policy.start_date,
                    paymentMode = "Bank Transfer",
                    description = "Livestock insurance premium for goat ${policy.goat_tag} (${policy.insurance_company} #${policy.policy_number ?: "New"})",
                    referenceId = policy.policy_number ?: policy.id,
                    isCapex = false
                )
            }

            Result.success(policy)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun savePoliciesForMultipleGoats(policies: List<InsurancePolicy>, paymentAccountId: String? = null): Result<List<InsurancePolicy>> = withContext(Dispatchers.IO) {
        try {
            var totalPaidPremium = 0.0
            for (p in policies) {
                val entity = p.toEntity(isSynced = false)
                database.insuranceDao().insertPolicy(entity)
                generatePolicyAlerts(p)
                totalPaidPremium += p.total_premium

                val json = JSONObject().apply {
                    put("id", entity.id)
                    put("goat_id", entity.goat_id)
                    put("goat_tag", entity.goat_tag)
                    put("insurance_company", entity.insurance_company)
                    put("policy_name", entity.policy_name)
                    if (!entity.policy_number.isNullOrBlank()) put("policy_number", entity.policy_number)
                    put("sum_insured", entity.sum_insured)
                    put("premium", entity.premium)
                    put("total_premium", entity.total_premium)
                    put("start_date", entity.start_date)
                    put("expiry_date", entity.expiry_date)
                    put("status", entity.status)
                    put("coverage_type", entity.coverage_type)
                }
                syncManager.enqueueOperation("insurance_policies", entity.id, "CREATE", json)
            }

            if (!paymentAccountId.isNullOrBlank() && totalPaidPremium > 0) {
                val firstPolicy = policies.firstOrNull()
                financeRepository.recordExpense(
                    accountId = paymentAccountId,
                    amount = totalPaidPremium,
                    category = "Insurance Premium",
                    date = firstPolicy?.start_date ?: dateFormat.format(Date()),
                    paymentMode = "Bank Transfer",
                    description = "Livestock insurance premium for ${policies.size} goats (${firstPolicy?.insurance_company} Policy #${firstPolicy?.policy_number ?: "Bulk"})",
                    referenceId = firstPolicy?.policy_number ?: UUID.randomUUID().toString(),
                    isCapex = false
                )
            }
            Result.success(policies)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private suspend fun generatePolicyAlerts(policy: InsurancePolicy) {
        val schedule = listOf(30, 15, 7, 3, 1, 0)
        for (days in schedule) {
            val existing = database.insuranceDao().findExistingAlert(policy.id, "EXPIRY", days)
            if (existing == null) {
                val alert = InsuranceAlertEntity(
                    id = UUID.randomUUID().toString(),
                    policy_id = policy.id,
                    goat_id = policy.goat_id,
                    alert_type = "EXPIRY",
                    title = if (days == 0) "Insurance Policy Expired!" else "Insurance Policy Expiring in $days Days",
                    message = "Policy #${policy.policy_number ?: "Pending"} for Goat ${policy.goat_tag} expires on ${policy.expiry_date}. Company: ${policy.insurance_company}.",
                    due_date = policy.expiry_date,
                    days_before_expiry = days,
                    is_dismissed = false,
                    created_at = dateFormat.format(Date())
                )
                database.insuranceDao().insertAlert(alert)
            }
        }
    }

    // ==============================================================================
    // 3. CLAIMS & SETTLEMENTS
    // ==============================================================================
    suspend fun getClaims(): Result<List<InsuranceClaim>> = withContext(Dispatchers.IO) {
        try {
            val list = database.insuranceDao().getAllClaims().map { it.toDomain() }
            Result.success(list)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun submitClaim(claim: InsuranceClaim): Result<InsuranceClaim> = withContext(Dispatchers.IO) {
        try {
            val entity = claim.toEntity(isSynced = false)
            database.insuranceDao().insertClaim(entity)

            // Update policy status to 'Claim Submitted'
            database.insuranceDao().updatePolicyStatus(claim.policy_id, "Claim Submitted")

            val json = JSONObject().apply {
                put("id", entity.id)
                put("policy_id", entity.policy_id)
                put("goat_id", entity.goat_id)
                put("goat_tag", entity.goat_tag)
                if (!entity.mortality_event_id.isNullOrBlank()) put("mortality_event_id", entity.mortality_event_id)
                put("incident_date", entity.incident_date)
                put("incident_type", entity.incident_type)
                put("cause", entity.cause)
                if (!entity.description.isNullOrBlank()) put("description", entity.description)
                if (!entity.location.isNullOrBlank()) put("location", entity.location)
                if (!entity.vet_doctor.isNullOrBlank()) put("vet_doctor", entity.vet_doctor)
                put("claim_amount", entity.claim_amount)
                if (!entity.claim_number.isNullOrBlank()) put("claim_number", entity.claim_number)
                put("status", entity.status)
            }
            syncManager.enqueueOperation("insurance_claims", entity.id, "CREATE", json)

            Result.success(claim)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun settleClaim(
        claimId: String,
        settlementAmount: Double,
        settlementDate: String,
        settlementAccountId: String? = null,
        approvedAmount: Double = settlementAmount,
        remarks: String? = null
    ): Result<Boolean> = withContext(Dispatchers.IO) {
        try {
            val claim = database.insuranceDao().getClaimById(claimId)
                ?: return@withContext Result.failure(IllegalArgumentException("Claim not found"))

            database.insuranceDao().updateClaimStatus(
                id = claimId,
                status = "Settled",
                approvedAmount = approvedAmount,
                settlementAmount = settlementAmount,
                settlementDate = settlementDate
            )

            database.insuranceDao().updatePolicyStatus(claim.policy_id, "Claim Settled")

            // FINANCE INTEGRATION: Record settlement as Income (Insurance Recovery - NOT goat sale income!)
            if (!settlementAccountId.isNullOrBlank() && settlementAmount > 0) {
                financeRepository.recordIncome(
                    accountId = settlementAccountId,
                    amount = settlementAmount,
                    category = "Insurance Claim Settlement",
                    date = settlementDate,
                    paymentMode = "Bank Transfer",
                    description = "Insurance claim settlement payout for goat ${claim.goat_tag} (Claim #${claim.claim_number ?: claim.id.take(8)})",
                    referenceId = claim.claim_number ?: claim.id
                )
            }

            Result.success(true)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun updateClaimStatusOnly(claimId: String, status: String): Result<Boolean> = withContext(Dispatchers.IO) {
        try {
            database.insuranceDao().updateClaimStatusOnly(claimId, status)
            val json = JSONObject().apply {
                put("id", claimId)
                put("status", status)
            }
            syncManager.enqueueOperation("insurance_claims", claimId, "UPDATE", json)
            Result.success(true)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // ==============================================================================
    // 4. ALERTS & DUE DATES
    // ==============================================================================
    suspend fun getActiveAlerts(): Result<List<InsuranceAlert>> = withContext(Dispatchers.IO) {
        try {
            val list = database.insuranceDao().getActiveAlerts().map { it.toDomain() }
            Result.success(list)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun dismissAlert(alertId: String): Result<Boolean> = withContext(Dispatchers.IO) {
        try {
            database.insuranceDao().dismissAlert(alertId)
            Result.success(true)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getInsuranceDueItems(): Result<List<InsuranceDueItem>> = withContext(Dispatchers.IO) {
        try {
            val today = dateFormat.format(Date())
            val policies = database.insuranceDao().getAllPolicies()
            val due = policies.filter {
                it.status.equals("Active", ignoreCase = true) ||
                it.status.equals("Expiring Soon", ignoreCase = true)
            }.map { p ->
                val days = calculateDaysDiff(today, p.expiry_date)
                InsuranceDueItem(
                    policyId = p.id,
                    goatId = p.goat_id,
                    goatTag = p.goat_tag,
                    goatName = p.goat_name,
                    policyNumber = p.policy_number,
                    company = p.insurance_company,
                    expiryDate = p.expiry_date,
                    daysRemaining = days,
                    premium = p.total_premium,
                    sumInsured = p.sum_insured,
                    status = if (days <= 0) "Expired" else if (days <= 30) "Expiring Soon" else "Active"
                )
            }.sortedBy { it.daysRemaining }

            Result.success(due)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // ==============================================================================
    // 5. REPRODUCTIVE EVENTS & ABORTIONS
    // ==============================================================================
    suspend fun recordAbortion(
        doeId: String,
        pregnancyId: String?,
        abortionDate: String,
        pregnancyAgeDays: Int?,
        numberOfFetuses: Int?,
        suspectedCause: String?,
        confirmedCause: String?,
        causeCategory: String,
        vetDiagnosis: String?,
        symptoms: String?,
        treatment: String?,
        vetDoctor: String?,
        notes: String?
    ): Result<ReproductiveEvent> = withContext(Dispatchers.IO) {
        try {
            val event = ReproductiveEvent(
                doe_id = doeId,
                pregnancy_id = pregnancyId,
                event_type = "ABORTION",
                event_date = abortionDate,
                pregnancy_age_days = pregnancyAgeDays,
                number_of_fetuses = numberOfFetuses,
                suspected_cause = suspectedCause,
                confirmed_cause = confirmedCause,
                cause_category = causeCategory,
                vet_diagnosis = vetDiagnosis,
                symptoms = symptoms,
                treatment = treatment,
                vet_doctor = vetDoctor,
                notes = notes,
                created_at = abortionDate
            )
            val entity = event.toEntity(isSynced = false)
            database.mortalityAndReproductionDao().insertReproductiveEvent(entity)

            // Update pregnancy status if linked
            if (!pregnancyId.isNullOrBlank()) {
                database.breedingDao().updatePregnancyStatus(pregnancyId, "Aborted")
                syncManager.enqueueOperation("pregnancies_c", pregnancyId, "UPDATE", JSONObject().put("status_c", "Aborted"))
            }

            // Update doe status to Active
            database.goatDao().updateStatus(doeId, "Active")
            syncManager.enqueueOperation("goats_c", doeId, "UPDATE", JSONObject().put("status_c", "Active"))

            // Sync reproductive event
            val json = JSONObject().apply {
                put("id", entity.id)
                put("doe_id", entity.doe_id)
                if (!entity.pregnancy_id.isNullOrBlank()) put("pregnancy_id", entity.pregnancy_id)
                put("event_type", entity.event_type)
                put("event_date", entity.event_date)
                if (entity.pregnancy_age_days != null) put("pregnancy_age_days", entity.pregnancy_age_days)
                if (entity.number_of_fetuses != null) put("number_of_fetuses", entity.number_of_fetuses)
                if (!entity.suspected_cause.isNullOrBlank()) put("suspected_cause", entity.suspected_cause)
                if (!entity.confirmed_cause.isNullOrBlank()) put("confirmed_cause", entity.confirmed_cause)
                if (!entity.cause_category.isNullOrBlank()) put("cause_category", entity.cause_category)
                if (!entity.vet_diagnosis.isNullOrBlank()) put("vet_diagnosis", entity.vet_diagnosis)
                if (!entity.treatment.isNullOrBlank()) put("treatment", entity.treatment)
                if (!entity.vet_doctor.isNullOrBlank()) put("vet_doctor", entity.vet_doctor)
            }
            syncManager.enqueueOperation("reproductive_events", entity.id, "CREATE", json)

            Result.success(event)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getAbortions(): Result<List<ReproductiveEvent>> = withContext(Dispatchers.IO) {
        try {
            val list = database.mortalityAndReproductionDao().getAbortions().map { it.toDomain() }
            Result.success(list)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // ==============================================================================
    // 6. DELIVERY / KIDDING ENTRY (With Auto Kid Creation & Stillborn tracking)
    // ==============================================================================
    suspend fun recordDeliveryOutcome(
        doeId: String,
        pregnancyId: String?,
        deliveryDate: String,
        deliveryType: String, // Normal, Assisted, Difficult
        numLiveKids: Int,
        numStillborn: Int,
        maleKids: Int,
        femaleKids: Int,
        birthWeight: Double?,
        complications: String?,
        vetDoctor: String?,
        notes: String?
    ): Result<ReproductiveEvent> = withContext(Dispatchers.IO) {
        try {
            val doe = database.goatDao().getGoatById(doeId)
            val event = ReproductiveEvent(
                doe_id = doeId,
                pregnancy_id = pregnancyId,
                event_type = "NORMAL_DELIVERY",
                event_date = deliveryDate,
                number_of_fetuses = numLiveKids + numStillborn,
                vet_doctor = vetDoctor,
                notes = buildString {
                    append("Delivery Type: $deliveryType. Live: $numLiveKids (M: $maleKids, F: $femaleKids), Stillborn: $numStillborn.")
                    if (!complications.isNullOrBlank()) append(" Complications: $complications.")
                    if (!notes.isNullOrBlank()) append(" $notes")
                },
                created_at = deliveryDate
            )
            database.mortalityAndReproductionDao().insertReproductiveEvent(event.toEntity(isSynced = false))

            // Update pregnancy
            if (!pregnancyId.isNullOrBlank()) {
                database.breedingDao().updatePregnancyStatus(pregnancyId, "Delivered")
                syncManager.enqueueOperation("pregnancies_c", pregnancyId, "UPDATE", JSONObject().put("status_c", "Delivered"))
            }

            // Update Doe status to Lactating
            database.goatDao().updateStatus(doeId, "Lactating")
            syncManager.enqueueOperation("goats_c", doeId, "UPDATE", JSONObject().put("status_c", "Lactating"))

            // Automatically create kid records for live births without duplicate
            val existingGoats = database.goatDao().getAllGoats()
            val damTag = doe?.tag_c ?: "DOE"

            var createdKidsCount = 0
            for (i in 1..numLiveKids) {
                val sex = if (i <= maleKids) "Male" else "Female"
                val proposedTag = "$damTag-K$i"
                val exists = existingGoats.any { it.tag_c.equals(proposedTag, ignoreCase = true) }
                if (!exists) {
                    val kidGoat = GoatEntity(
                        id = UUID.randomUUID().toString(),
                        name = "Kid $i of $damTag",
                        tag_c = proposedTag,
                        breed_c = doe?.breed_c ?: "Commercial",
                        sex_c = sex,
                        birth_date_c = deliveryDate,
                        status_c = "Active",
                        dam_c = damTag,
                        weight_kg_c = birthWeight ?: 2.5,
                        notes_c = "Born on $deliveryDate via $deliveryType delivery"
                    )
                    database.goatDao().insertOrUpdate(kidGoat)
                    createdKidsCount++
                }
            }

            // If stillborn, also log reproductive stillbirth event
            if (numStillborn > 0) {
                val stillbirthEvent = ReproductiveEvent(
                    doe_id = doeId,
                    pregnancy_id = pregnancyId,
                    event_type = "STILLBIRTH",
                    event_date = deliveryDate,
                    number_of_fetuses = numStillborn,
                    notes = "Stillborn kids during delivery on $deliveryDate"
                )
                database.mortalityAndReproductionDao().insertReproductiveEvent(stillbirthEvent.toEntity(isSynced = false))
            }

            Result.success(event)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // ==============================================================================
    // 7. POST-DELIVERY MONITORING
    // ==============================================================================
    suspend fun recordPostDeliveryCheck(check: PostDeliveryCheck): Result<PostDeliveryCheck> = withContext(Dispatchers.IO) {
        try {
            val entity = check.toEntity(isSynced = false)
            database.mortalityAndReproductionDao().insertPostDeliveryCheck(entity)

            val json = JSONObject().apply {
                put("id", entity.id)
                put("doe_id", entity.doe_id)
                put("delivery_date", entity.delivery_date)
                put("check_date", entity.check_date)
                put("days_post_delivery", entity.days_post_delivery)
                put("appetite", entity.appetite)
                if (entity.temperature != null) put("temperature", entity.temperature)
                if (entity.milk_production_ltr != null) put("milk_production_ltr", entity.milk_production_ltr)
                if (!entity.complications.isNullOrBlank()) put("complications", entity.complications)
                if (!entity.treatment.isNullOrBlank()) put("treatment", entity.treatment)
                put("recovery_status", entity.recovery_status)
            }
            syncManager.enqueueOperation("post_delivery_checks", entity.id, "CREATE", json)

            Result.success(check)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getPostDeliveryChecks(doeId: String): Result<List<PostDeliveryCheck>> = withContext(Dispatchers.IO) {
        try {
            val list = database.mortalityAndReproductionDao().getChecksForDoe(doeId).map { it.toDomain() }
            Result.success(list)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // ==============================================================================
    // 8. MORTALITY & DEATH ENTRY (General, Post-Delivery, Kid)
    // ==============================================================================
    suspend fun recordMortality(event: MortalityEvent): Result<MortalityEvent> = withContext(Dispatchers.IO) {
        try {
            // Automatically calculate days_post_delivery if delivery_date is present
            val daysPostDel = if (!event.delivery_date.isNullOrBlank()) {
                calculateDaysDiff(event.delivery_date, event.death_date)
            } else event.days_post_delivery

            val processedEvent = event.copy(days_post_delivery = daysPostDel)
            val entity = processedEvent.toEntity(isSynced = false)
            database.mortalityAndReproductionDao().insertMortalityEvent(entity)

            // CRITICAL GOAT STATUS AUTOMATION:
            // Goat status becomes DECEASED. Does NOT delete goat; keeps history intact!
            database.goatDao().updateStatus(event.goat_id, "Deceased")
            syncManager.enqueueOperation("goats_c", event.goat_id, "UPDATE", JSONObject().put("status_c", "Deceased"))

            // Check if goat is insured
            val activePolicy = database.insuranceDao().getActivePolicyForGoat(event.goat_id)
            val policyId = activePolicy?.id

            // Sync mortality event
            val json = JSONObject().apply {
                put("id", entity.id)
                put("goat_id", entity.goat_id)
                put("goat_tag", entity.goat_tag)
                put("event_type", entity.event_type)
                put("death_date", entity.death_date)
                if (entity.age_at_death_days != null) put("age_at_death_days", entity.age_at_death_days)
                if (!entity.delivery_date.isNullOrBlank()) put("delivery_date", entity.delivery_date)
                if (entity.days_post_delivery != null) put("days_post_delivery", entity.days_post_delivery)
                put("immediate_cause", entity.immediate_cause)
                if (!entity.underlying_cause.isNullOrBlank()) put("underlying_cause", entity.underlying_cause)
                put("cause_certainty", entity.cause_certainty)
                put("cause_category", entity.cause_category)
                if (!entity.vet_doctor.isNullOrBlank()) put("vet_doctor", entity.vet_doctor)
                put("post_mortem_performed", entity.post_mortem_performed)
                if (!policyId.isNullOrBlank()) put("insurance_policy_id", policyId)
            }
            syncManager.enqueueOperation("mortality_events", entity.id, "CREATE", json)

            Result.success(processedEvent.copy(insurance_policy_id = policyId))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun recordKidMortality(
        kidId: String,
        deathDate: String,
        birthDate: String?,
        cause: String,
        causeCategory: String,
        isConfirmed: Boolean,
        weightAtDeath: Double?,
        vetDoctor: String?,
        notes: String?
    ): Result<MortalityEvent> = withContext(Dispatchers.IO) {
        try {
            val kid = database.goatDao().getGoatById(kidId)
            val dob = birthDate ?: kid?.birth_date_c
            val ageAtDeath = if (!dob.isNullOrBlank()) calculateDaysDiff(dob, deathDate) else null

            val event = MortalityEvent(
                goat_id = kidId,
                goat_tag = kid?.tag_c ?: "KID",
                event_type = "KID_DEATH",
                death_date = deathDate,
                age_at_death_days = ageAtDeath,
                weight_at_death = weightAtDeath,
                immediate_cause = cause,
                cause_certainty = if (isConfirmed) "Confirmed" else "Suspected",
                cause_category = causeCategory,
                vet_doctor = vetDoctor,
                notes = notes
            )
            recordMortality(event)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getMortalityEvents(): Result<List<MortalityEvent>> = withContext(Dispatchers.IO) {
        try {
            val list = database.mortalityAndReproductionDao().getAllMortalityEvents().map { it.toDomain() }
            Result.success(list)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // ==============================================================================
    // 9. MORTALITY & BREEDING DASHBOARD SUMMARIES
    // ==============================================================================
    suspend fun getFarmMortalitySummary(): Result<FarmMortalitySummary> = withContext(Dispatchers.IO) {
        try {
            val mortalities = database.mortalityAndReproductionDao().getAllMortalityEvents().map { it.toDomain() }
            val reproductiveEvents = database.mortalityAndReproductionDao().getAllReproductiveEvents().map { it.toDomain() }
            val goats = database.goatDao().getAllGoats()
            val claims = database.insuranceDao().getAllClaims().map { it.toDomain() }

            val totalDeaths = mortalities.size
            val adultDeaths = mortalities.count { it.event_type.equals("ADULT_DEATH", ignoreCase = true) || it.event_type.equals("DOE_POST_DELIVERY_DEATH", ignoreCase = true) }
            val kidDeaths = mortalities.count { it.event_type.equals("KID_DEATH", ignoreCase = true) }
            val postDeliveryDeaths = mortalities.count { it.event_type.equals("DOE_POST_DELIVERY_DEATH", ignoreCase = true) }

            val doeDeaths = mortalities.count { m ->
                val g = goats.find { it.id == m.goat_id }
                g?.sex_c.equals("Female", ignoreCase = true) || m.event_type.contains("DOE", ignoreCase = true)
            }
            val buckDeaths = mortalities.count { m ->
                val g = goats.find { it.id == m.goat_id }
                g?.sex_c.equals("Male", ignoreCase = true)
            }

            val abortions = reproductiveEvents.count { it.event_type.equals("ABORTION", ignoreCase = true) }
            val stillbirths = reproductiveEvents.count { it.event_type.equals("STILLBIRTH", ignoreCase = true) }

            val insuredDeaths = mortalities.count { !it.insurance_policy_id.isNullOrBlank() }
            val pendingClaims = claims.count { !it.status.equals("Settled", ignoreCase = true) && !it.status.equals("Rejected", ignoreCase = true) }
            val settledClaims = claims.count { it.status.equals("Settled", ignoreCase = true) }

            val totalHerd = goats.size.coerceAtLeast(1)
            val overallMortalityRate = (totalDeaths.toDouble() / totalHerd.toDouble()) * 100.0

            val totalKids = goats.count { (it.sex_c.isNullOrBlank() || it.tag_c.contains("K", ignoreCase = true)) || (it.birth_date_c?.let { d -> calculateDaysDiff(d, dateFormat.format(Date())) < 180 } == true) }.coerceAtLeast(1)
            val kidMortalityRate = (kidDeaths.toDouble() / totalKids.toDouble()) * 100.0

            val totalPregnanciesCount = (abortions + stillbirths + reproductiveEvents.count { it.event_type.equals("NORMAL_DELIVERY", ignoreCase = true) }).coerceAtLeast(1)
            val reproductiveLossRate = ((abortions + stillbirths).toDouble() / totalPregnanciesCount.toDouble()) * 100.0

            // Breakdowns
            val byMonth = mortalities.groupBy { it.death_date.take(7) }.mapValues { it.value.size }
            val byCause = mortalities.groupBy { it.cause_category }.mapValues { it.value.size }
            val byAge = mortalities.groupBy {
                val days = it.age_at_death_days ?: 0
                when {
                    days <= 30 -> "0-1 Month (Neonatal)"
                    days <= 90 -> "1-3 Months (Weaning)"
                    days <= 365 -> "3-12 Months (Grower)"
                    else -> "Adult (> 1 Year)"
                }
            }.mapValues { it.value.size }

            val summary = FarmMortalitySummary(
                totalDeaths = totalDeaths,
                adultDeaths = adultDeaths,
                kidDeaths = kidDeaths,
                doeDeaths = doeDeaths,
                buckDeaths = buckDeaths,
                abortionCount = abortions,
                stillbirthCount = stillbirths,
                postDeliveryDeaths = postDeliveryDeaths,
                insuredDeaths = insuredDeaths,
                claimsPending = pendingClaims,
                claimsSettled = settledClaims,
                totalHerdCount = goats.size,
                overallMortalityRate = overallMortalityRate,
                kidMortalityRate = kidMortalityRate,
                reproductiveLossRate = reproductiveLossRate,
                deathsByMonth = byMonth,
                deathsByCause = byCause,
                deathsByAgeGroup = byAge
            )
            Result.success(summary)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getBreedingPerformanceSummary(): Result<BreedingPerformanceSummary> = withContext(Dispatchers.IO) {
        try {
            val events = database.mortalityAndReproductionDao().getAllReproductiveEvents().map { it.toDomain() }
            val checks = database.mortalityAndReproductionDao().getAllPostDeliveryChecks()
            val mortalities = database.mortalityAndReproductionDao().getAllMortalityEvents()
            val pregnancies = database.breedingDao().getAllPregnancies()
            val breedings = database.breedingDao().getAllMatings()

            val doesBred = breedings.map { it.doe_id_c }.distinct().size
            val totalPreggo = pregnancies.size
            val confirmedPreggo = pregnancies.count { it.status_c.equals("Confirmed", ignoreCase = true) || it.status_c.equals("Delivered", ignoreCase = true) }
            val abortions = events.count { it.event_type.equals("ABORTION", ignoreCase = true) }
            val stillbirths = events.count { it.event_type.equals("STILLBIRTH", ignoreCase = true) }
            val deliveries = events.count { it.event_type.equals("NORMAL_DELIVERY", ignoreCase = true) }

            val liveKidsBorn = events.filter { it.event_type.equals("NORMAL_DELIVERY", ignoreCase = true) }
                .sumOf { it.number_of_fetuses ?: 1 }
            val kidDeaths = mortalities.count { it.event_type.equals("KID_DEATH", ignoreCase = true) }
            val kidSurvival = (liveKidsBorn - kidDeaths).coerceAtLeast(0)

            val complications = checks.count { !it.complications.isNullOrBlank() && !it.complications.equals("None", ignoreCase = true) }
            val doePostDeliveryDeath = mortalities.count { it.event_type.equals("DOE_POST_DELIVERY_DEATH", ignoreCase = true) }

            val summary = BreedingPerformanceSummary(
                totalDoesBred = doesBred,
                totalPregnancies = totalPreggo,
                confirmedPregnancies = confirmedPreggo,
                normalDeliveries = deliveries,
                abortions = abortions,
                stillbirths = stillbirths,
                totalLiveKidsBorn = liveKidsBorn,
                kidSurvivalCount = kidSurvival,
                postDeliveryComplicationsCount = complications,
                doeMortalityAfterDeliveryCount = doePostDeliveryDeath,
                conceptionRate = if (doesBred > 0) (confirmedPreggo.toDouble() / doesBred.toDouble()) * 100.0 else 0.0,
                kiddingRate = if (confirmedPreggo > 0) (deliveries.toDouble() / confirmedPreggo.toDouble()) * 100.0 else 0.0,
                kidSurvivalRate = if (liveKidsBorn > 0) (kidSurvival.toDouble() / liveKidsBorn.toDouble()) * 100.0 else 0.0
            )
            Result.success(summary)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun calculateDaysDiff(fromDate: String, toDate: String): Int {
        return try {
            val d1 = dateFormat.parse(fromDate) ?: Date()
            val d2 = dateFormat.parse(toDate) ?: Date()
            val diffMs = d2.time - d1.time
            TimeUnit.MILLISECONDS.toDays(diffMs).toInt()
        } catch (_: Exception) {
            0
        }
    }
}

// ==============================================================================
// MAPPERS: Domain <-> Entity
// ==============================================================================
fun InsuranceProvider.toEntity(isSynced: Boolean = false) = InsuranceProviderEntity(
    id = id,
    name = name,
    company_name = company_name,
    code = code,
    type = type,
    website = website,
    phone = phone,
    email = email,
    api_base_url = api_base_url,
    sandbox_url = sandbox_url,
    production_url = production_url,
    api_version = api_version,
    auth_type = auth_type,
    webhook_url = webhook_url,
    is_active = is_active,
    is_sandbox = is_sandbox,
    notes = notes,
    created_at = created_at,
    updated_at = updated_at,
    is_synced = isSynced
)

fun InsuranceProviderEntity.toDomain() = InsuranceProvider(
    id = id,
    name = name,
    company_name = company_name,
    code = code,
    type = type,
    website = website,
    phone = phone,
    email = email,
    api_base_url = api_base_url,
    sandbox_url = sandbox_url,
    production_url = production_url,
    api_version = api_version,
    auth_type = auth_type,
    webhook_url = webhook_url,
    is_active = is_active,
    is_sandbox = is_sandbox,
    notes = notes,
    created_at = created_at,
    updated_at = updated_at
)

fun InsurancePolicy.toEntity(isSynced: Boolean = false) = InsurancePolicyEntity(
    id = id,
    goat_id = goat_id,
    goat_tag = goat_tag,
    rfid = rfid,
    goat_name = goat_name,
    provider_id = provider_id,
    insurance_company = insurance_company,
    policy_name = policy_name,
    policy_number = policy_number,
    proposal_number = proposal_number,
    sum_insured = sum_insured,
    market_value = market_value,
    premium = premium,
    tax_amount = tax_amount,
    total_premium = total_premium,
    start_date = start_date,
    expiry_date = expiry_date,
    renewal_date = renewal_date,
    status = status,
    coverage_type = coverage_type,
    deductible = deductible,
    claim_eligibility = claim_eligibility,
    agent_name = agent_name,
    agent_contact = agent_contact,
    policy_document_url = policy_document_url,
    vet_certificate_url = vet_certificate_url,
    animal_photo_url = animal_photo_url,
    eartag_photo_url = eartag_photo_url,
    payment_account_id = payment_account_id,
    created_at = created_at,
    is_synced = isSynced
)

fun InsurancePolicyEntity.toDomain() = InsurancePolicy(
    id = id,
    goat_id = goat_id,
    goat_tag = goat_tag,
    rfid = rfid,
    goat_name = goat_name,
    provider_id = provider_id,
    insurance_company = insurance_company,
    policy_name = policy_name,
    policy_number = policy_number,
    proposal_number = proposal_number,
    sum_insured = sum_insured,
    market_value = market_value,
    premium = premium,
    tax_amount = tax_amount,
    total_premium = total_premium,
    start_date = start_date,
    expiry_date = expiry_date,
    renewal_date = renewal_date,
    status = status,
    coverage_type = coverage_type,
    deductible = deductible,
    claim_eligibility = claim_eligibility,
    agent_name = agent_name,
    agent_contact = agent_contact,
    policy_document_url = policy_document_url,
    vet_certificate_url = vet_certificate_url,
    animal_photo_url = animal_photo_url,
    eartag_photo_url = eartag_photo_url,
    payment_account_id = payment_account_id,
    created_at = created_at,
    updated_at = null
)

fun InsuranceQuote.toEntity(isSynced: Boolean = false) = InsuranceQuoteEntity(
    id = id,
    goat_id = goat_id,
    goat_tag = goat_tag,
    provider_id = provider_id,
    provider_name = provider_name,
    product_name = product_name,
    sum_insured = sum_insured,
    premium = premium,
    tax_amount = tax_amount,
    total_premium = total_premium,
    validity_date = validity_date,
    coverage_details = coverage_details,
    terms_and_conditions = terms_and_conditions,
    exclusions = exclusions,
    status = status,
    created_at = created_at,
    is_synced = isSynced
)

fun InsuranceQuoteEntity.toDomain() = InsuranceQuote(
    id = id,
    goat_id = goat_id,
    goat_tag = goat_tag,
    provider_id = provider_id,
    provider_name = provider_name,
    product_name = product_name,
    sum_insured = sum_insured,
    premium = premium,
    tax_amount = tax_amount,
    total_premium = total_premium,
    validity_date = validity_date,
    coverage_details = coverage_details,
    terms_and_conditions = terms_and_conditions,
    exclusions = exclusions,
    status = status,
    created_at = created_at
)

fun InsuranceClaim.toEntity(isSynced: Boolean = false) = InsuranceClaimEntity(
    id = id,
    policy_id = policy_id,
    goat_id = goat_id,
    goat_tag = goat_tag,
    mortality_event_id = mortality_event_id,
    incident_date = incident_date,
    incident_type = incident_type,
    cause = cause,
    description = description,
    location = location,
    vet_doctor = vet_doctor,
    vet_certificate_url = vet_certificate_url,
    photos_urls = photos_urls,
    eartag_photo_url = eartag_photo_url,
    post_mortem_report_url = post_mortem_report_url,
    police_report_url = police_report_url,
    claim_amount = claim_amount,
    claim_number = claim_number,
    submitted_date = submitted_date,
    insurer_response = insurer_response,
    approved_amount = approved_amount,
    settlement_date = settlement_date,
    settlement_amount = settlement_amount,
    settlement_account_id = settlement_account_id,
    rejection_reason = rejection_reason,
    status = status,
    notes = notes,
    created_at = created_at,
    is_synced = isSynced
)

fun InsuranceClaimEntity.toDomain() = InsuranceClaim(
    id = id,
    policy_id = policy_id,
    goat_id = goat_id,
    goat_tag = goat_tag,
    mortality_event_id = mortality_event_id,
    incident_date = incident_date,
    incident_type = incident_type,
    cause = cause,
    description = description,
    location = location,
    vet_doctor = vet_doctor,
    vet_certificate_url = vet_certificate_url,
    photos_urls = photos_urls,
    eartag_photo_url = eartag_photo_url,
    post_mortem_report_url = post_mortem_report_url,
    police_report_url = police_report_url,
    claim_amount = claim_amount,
    claim_number = claim_number,
    submitted_date = submitted_date,
    insurer_response = insurer_response,
    approved_amount = approved_amount,
    settlement_date = settlement_date,
    settlement_amount = settlement_amount,
    settlement_account_id = settlement_account_id,
    rejection_reason = rejection_reason,
    status = status,
    notes = notes,
    created_at = created_at,
    updated_at = null
)

fun InsuranceAlertEntity.toDomain() = InsuranceAlert(
    id = id,
    policy_id = policy_id,
    claim_id = claim_id,
    goat_id = goat_id,
    alert_type = alert_type,
    title = title,
    message = message,
    due_date = due_date,
    days_before_expiry = days_before_expiry,
    is_dismissed = is_dismissed,
    created_at = created_at
)

fun ReproductiveEvent.toEntity(isSynced: Boolean = false) = ReproductiveEventEntity(
    id = id,
    doe_id = doe_id,
    pregnancy_id = pregnancy_id,
    sire_id = sire_id,
    event_type = event_type,
    event_date = event_date,
    mating_date = mating_date,
    expected_delivery_date = expected_delivery_date,
    pregnancy_age_days = pregnancy_age_days,
    number_of_fetuses = number_of_fetuses,
    suspected_cause = suspected_cause,
    confirmed_cause = confirmed_cause,
    cause_category = cause_category,
    vet_diagnosis = vet_diagnosis,
    symptoms = symptoms,
    treatment = treatment,
    vet_doctor = vet_doctor,
    certificate_url = certificate_url,
    photo_url = photo_url,
    notes = notes,
    created_at = created_at,
    is_synced = isSynced
)

fun ReproductiveEventEntity.toDomain() = ReproductiveEvent(
    id = id,
    doe_id = doe_id,
    pregnancy_id = pregnancy_id,
    sire_id = sire_id,
    event_type = event_type,
    event_date = event_date,
    mating_date = mating_date,
    expected_delivery_date = expected_delivery_date,
    pregnancy_age_days = pregnancy_age_days,
    number_of_fetuses = number_of_fetuses,
    suspected_cause = suspected_cause,
    confirmed_cause = confirmed_cause,
    cause_category = cause_category,
    vet_diagnosis = vet_diagnosis,
    symptoms = symptoms,
    treatment = treatment,
    vet_doctor = vet_doctor,
    certificate_url = certificate_url,
    photo_url = photo_url,
    notes = notes,
    created_at = created_at
)

fun PostDeliveryCheck.toEntity(isSynced: Boolean = false) = PostDeliveryCheckEntity(
    id = id,
    doe_id = doe_id,
    delivery_date = delivery_date,
    check_date = check_date,
    days_post_delivery = days_post_delivery,
    appetite = appetite,
    temperature = temperature,
    milk_production_ltr = milk_production_ltr,
    complications = complications,
    treatment = treatment,
    medication = medication,
    vet_visit = vet_visit,
    vet_doctor = vet_doctor,
    recovery_status = recovery_status,
    notes = notes,
    created_at = created_at,
    is_synced = isSynced
)

fun PostDeliveryCheckEntity.toDomain() = PostDeliveryCheck(
    id = id,
    doe_id = doe_id,
    delivery_date = delivery_date,
    check_date = check_date,
    days_post_delivery = days_post_delivery,
    appetite = appetite,
    temperature = temperature,
    milk_production_ltr = milk_production_ltr,
    complications = complications,
    treatment = treatment,
    medication = medication,
    vet_visit = vet_visit,
    vet_doctor = vet_doctor,
    recovery_status = recovery_status,
    notes = notes,
    created_at = created_at
)

fun MortalityEvent.toEntity(isSynced: Boolean = false) = MortalityEventEntity(
    id = id,
    goat_id = goat_id,
    goat_tag = goat_tag,
    event_type = event_type,
    death_date = death_date,
    death_time = death_time,
    age_at_death_days = age_at_death_days,
    weight_at_death = weight_at_death,
    delivery_date = delivery_date,
    days_post_delivery = days_post_delivery,
    immediate_cause = immediate_cause,
    underlying_cause = underlying_cause,
    cause_certainty = cause_certainty,
    cause_category = cause_category,
    disease_name = disease_name,
    injury_details = injury_details,
    treatment_history = treatment_history,
    vet_doctor = vet_doctor,
    post_mortem_performed = post_mortem_performed,
    post_mortem_report_url = post_mortem_report_url,
    photos_urls = photos_urls,
    insurance_policy_id = insurance_policy_id,
    insurance_claim_id = insurance_claim_id,
    notes = notes,
    created_at = created_at,
    is_synced = isSynced
)

fun MortalityEventEntity.toDomain() = MortalityEvent(
    id = id,
    goat_id = goat_id,
    goat_tag = goat_tag,
    event_type = event_type,
    death_date = death_date,
    death_time = death_time,
    age_at_death_days = age_at_death_days,
    weight_at_death = weight_at_death,
    delivery_date = delivery_date,
    days_post_delivery = days_post_delivery,
    immediate_cause = immediate_cause,
    underlying_cause = underlying_cause,
    cause_certainty = cause_certainty,
    cause_category = cause_category,
    disease_name = disease_name,
    injury_details = injury_details,
    treatment_history = treatment_history,
    vet_doctor = vet_doctor,
    post_mortem_performed = post_mortem_performed,
    post_mortem_report_url = post_mortem_report_url,
    photos_urls = photos_urls,
    insurance_policy_id = insurance_policy_id,
    insurance_claim_id = insurance_claim_id,
    notes = notes,
    created_at = created_at
)
