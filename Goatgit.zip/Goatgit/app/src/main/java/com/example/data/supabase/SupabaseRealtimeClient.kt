package com.example.data.supabase

import android.util.Log
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import okhttp3.*
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger

enum class RealtimeStatus {
    DISCONNECTED,
    CONNECTING,
    CONNECTED,
    SUBSCRIBED,
    ERROR
}

data class SupabaseRealtimeEvent(
    val table: String,
    val eventType: EventType,
    val record: JSONObject?,
    val oldRecord: JSONObject?,
    val commitTimestamp: String? = null
) {
    enum class EventType {
        INSERT,
        UPDATE,
        DELETE,
        UNKNOWN
    }
}

/**
 * Robust Supabase Realtime Client managing WebSocket connections,
 * Phoenix Channels protocol joins, periodic heartbeats, and real-time
 * PostgreSQL change subscriptions for live farm data sync.
 */
class SupabaseRealtimeClient(
    private val config: SupabaseConfig,
    private val httpClient: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(0, TimeUnit.MILLISECONDS) // Keep alive indefinitely for websockets
        .writeTimeout(15, TimeUnit.SECONDS)
        .pingInterval(20, TimeUnit.SECONDS)
        .build()
) {
    private val tag = "SupabaseRealtime"
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private val _status = MutableStateFlow(RealtimeStatus.DISCONNECTED)
    val status: StateFlow<RealtimeStatus> = _status.asStateFlow()

    private val _events = MutableSharedFlow<SupabaseRealtimeEvent>(extraBufferCapacity = 64)
    val realtimeEvents: SharedFlow<SupabaseRealtimeEvent> = _events.asSharedFlow()

    private val _lastEventTime = MutableStateFlow(0L)
    val lastEventTime: StateFlow<Long> = _lastEventTime.asStateFlow()

    private val _eventCount = MutableStateFlow(0)
    val eventCount: StateFlow<Int> = _eventCount.asStateFlow()

    private val _lastError = MutableStateFlow<String?>(null)
    val lastError: StateFlow<String?> = _lastError.asStateFlow()

    private var webSocket: WebSocket? = null
    private var heartbeatJob: Job? = null
    private var reconnectJob: Job? = null
    private var shouldBeConnected = false
    private var reconnectAttempts = 0
    private val refCounter = AtomicInteger(1)

    private val monitoredTables = setOf(
        "goats_c",
        "goat_weights_c",
        "vaccinations_c",
        "deworming_records_c",
        "treatments_c",
        "tasks_c",
        "sales_c",
        "feed_inventory_c",
        "medicine_inventory_c",
        "farm_assets",
        "breeding_records",
        "breeding_records_c",
        "weaning_records"
    )

    fun getMonitoredTables(): Set<String> = monitoredTables

    fun getWebSocketUrl(): String {
        val baseUrl = config.url
        val wsScheme = if (baseUrl.startsWith("https://")) "wss://" else "ws://"
        val hostAndPath = baseUrl.removePrefix("https://").removePrefix("http://").trimEnd('/')
        val key = config.publishableKey
        return "$wsScheme$hostAndPath/realtime/v1/websocket?apikey=$key&vsn=1.0.0"
    }

    /**
     * Connect to Supabase Realtime WebSocket and subscribe to public PostgreSQL changes.
     */
    fun connect() {
        if (!config.hasValidKey()) {
            Log.w(tag, "Cannot connect to Supabase Realtime: publishable key not configured")
            _status.value = RealtimeStatus.DISCONNECTED
            return
        }

        // Supabase Realtime WebSocket endpoint requires a valid JWT (with 2 dots: header.payload.signature).
        // Non-JWT tokens (like 'sb_publishable_...') without an authenticated user JWT will be rejected
        // by the Supabase Realtime server with HTTP 401 Unauthorized.
        // In that case, we skip the WebSocket handshake and seamlessly rely on REST sync.
        val token = config.accessToken
        val hasJwtToken = !token.isNullOrBlank() && token.count { it == '.' } == 2 && !token.startsWith("sb_publishable_")
        val hasJwtApiKey = config.publishableKey.count { it == '.' } == 2 && !config.publishableKey.startsWith("sb_publishable_")

        if (!hasJwtToken && !hasJwtApiKey) {
            Log.d(tag, "Supabase Realtime WebSocket requires a JWT key/session. Using periodic REST sync.")
            _status.value = RealtimeStatus.DISCONNECTED
            _lastError.value = null
            shouldBeConnected = false
            return
        }

        shouldBeConnected = true
        if (_status.value == RealtimeStatus.CONNECTED || _status.value == RealtimeStatus.SUBSCRIBED || _status.value == RealtimeStatus.CONNECTING) {
            return
        }

        reconnectJob?.cancel()
        _status.value = RealtimeStatus.CONNECTING
        _lastError.value = null

        val url = getWebSocketUrl()
        Log.i(tag, "Initiating Supabase Realtime connection to $url")

        val requestBuilder = Request.Builder()
            .url(url)
            .header("apikey", config.publishableKey)

        if (hasJwtToken) {
            requestBuilder.header("Authorization", "Bearer $token")
        }
        val request = requestBuilder.build()

        webSocket = httpClient.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(ws: WebSocket, response: Response) {
                Log.i(tag, "WebSocket connection established!")
                _status.value = RealtimeStatus.CONNECTED
                reconnectAttempts = 0
                _lastError.value = null

                // Start Phoenix Channel join and heartbeats
                scope.launch {
                    joinChannel(ws)
                    startHeartbeat(ws)
                }
            }

            override fun onMessage(ws: WebSocket, text: String) {
                handleIncomingMessage(text)
            }

            override fun onClosing(ws: WebSocket, code: Int, reason: String) {
                Log.i(tag, "WebSocket closing (code $code): $reason")
                _status.value = RealtimeStatus.DISCONNECTED
            }

            override fun onClosed(ws: WebSocket, code: Int, reason: String) {
                Log.i(tag, "WebSocket closed (code $code): $reason")
                _status.value = RealtimeStatus.DISCONNECTED
                heartbeatJob?.cancel()
                if (shouldBeConnected) {
                    scheduleReconnect(false)
                }
            }

            override fun onFailure(ws: WebSocket, t: Throwable, response: Response?) {
                val is401 = response?.code == 401 || (t.message?.contains("401") == true)
                val isAuthError = is401 || response?.code == 403

                if (isAuthError) {
                    // Graceful fallback to REST sync without printing error stack traces to logcat
                    Log.w(tag, "Supabase Realtime connection declined (${response?.code ?: 401}). Disabling WebSocket; offline and REST sync remain active.")
                    _lastError.value = "Realtime unavailable (${response?.code ?: 401}); REST sync active"
                    _status.value = RealtimeStatus.DISCONNECTED
                    heartbeatJob?.cancel()
                    reconnectJob?.cancel()
                    shouldBeConnected = false
                    config.clearSession()
                    return
                }

                val errorMsg = t.message ?: "Unknown WebSocket error"
                Log.w(tag, "WebSocket warning: $errorMsg")
                _lastError.value = errorMsg
                _status.value = RealtimeStatus.ERROR
                heartbeatJob?.cancel()

                if (shouldBeConnected) {
                    scheduleReconnect(false)
                }
            }
        })
    }

    /**
     * Send Phoenix Channel join message to subscribe to PostgreSQL changes for public tables.
     */
    private fun joinChannel(ws: WebSocket) {
        try {
            val joinRef = "join_${refCounter.incrementAndGet()}"
            val payload = JSONObject().apply {
                val configObj = JSONObject().apply {
                    put("broadcast", JSONObject().apply { put("self", false) })
                    put("presence", JSONObject().apply { put("key", "") })

                    // Listen to all public schema table changes
                    val postgresChanges = JSONArray().apply {
                        put(JSONObject().apply {
                            put("event", "*")
                            put("schema", "public")
                        })
                    }
                    put("postgres_changes", postgresChanges)
                }
                put("config", configObj)

                // Optional valid JWT token for channel authorization
                val token = config.accessToken
                if (!token.isNullOrBlank() && token.count { it == '.' } == 2 && !token.startsWith("sb_publishable_")) {
                    put("access_token", token)
                }
            }

            val joinMessage = JSONObject().apply {
                put("topic", "realtime:public")
                put("event", "phx_join")
                put("payload", payload)
                put("ref", joinRef)
            }

            ws.send(joinMessage.toString())
            Log.d(tag, "Sent phx_join for topic 'realtime:public' with postgres_changes")
        } catch (e: Exception) {
            Log.e(tag, "Failed to send phx_join: ${e.message}", e)
        }
    }

    /**
     * Periodic Phoenix heartbeat to keep connection alive.
     */
    private fun startHeartbeat(ws: WebSocket) {
        heartbeatJob?.cancel()
        heartbeatJob = scope.launch {
            while (isActive && shouldBeConnected) {
                delay(25000L) // Phoenix protocol recommended 25s
                try {
                    val hbRef = "hb_${refCounter.incrementAndGet()}"
                    val hb = JSONObject().apply {
                        put("topic", "phoenix")
                        put("event", "heartbeat")
                        put("payload", JSONObject())
                        put("ref", hbRef)
                    }
                    ws.send(hb.toString())
                } catch (e: Exception) {
                    Log.w(tag, "Heartbeat send error: ${e.message}")
                    break
                }
            }
        }
    }

    /**
     * Process incoming WebSocket message frames.
     */
    private fun handleIncomingMessage(text: String) {
        try {
            val json = JSONObject(text)
            val event = json.optString("event")
            val topic = json.optString("topic")

            when (event) {
                "phx_reply" -> {
                    val payload = json.optJSONObject("payload")
                    val statusStr = payload?.optString("status")
                    if (statusStr == "ok" && topic.startsWith("realtime:")) {
                        _status.value = RealtimeStatus.SUBSCRIBED
                        Log.i(tag, "Subscribed successfully to $topic!")
                    }
                }
                "postgres_changes" -> {
                    val payload = json.optJSONObject("payload")
                    val data = payload?.optJSONObject("data") ?: payload
                    if (data != null) {
                        val table = data.optString("table")
                        val typeStr = data.optString("type")
                        val eventType = when (typeStr.uppercase()) {
                            "INSERT" -> SupabaseRealtimeEvent.EventType.INSERT
                            "UPDATE" -> SupabaseRealtimeEvent.EventType.UPDATE
                            "DELETE" -> SupabaseRealtimeEvent.EventType.DELETE
                            else -> SupabaseRealtimeEvent.EventType.UNKNOWN
                        }
                        val record = data.optJSONObject("record")
                        val oldRecord = data.optJSONObject("old_record")
                        val commitTimestamp = data.optString("commit_timestamp")

                        val realtimeEvent = SupabaseRealtimeEvent(
                            table = table,
                            eventType = eventType,
                            record = record,
                            oldRecord = oldRecord,
                            commitTimestamp = commitTimestamp
                        )

                        Log.d(tag, "Real-time event: $eventType on table '$table'")
                        _events.tryEmit(realtimeEvent)
                        _lastEventTime.value = System.currentTimeMillis()
                        _eventCount.value += 1
                    }
                }
                "system" -> {
                    val payload = json.optJSONObject("payload")
                    val status = payload?.optString("status")
                    if (status == "ok") {
                        Log.d(tag, "System message OK")
                    }
                }
                else -> {
                    // Other Phoenix protocol events or broadcasts
                    if (json.has("payload") && json.optJSONObject("payload")?.has("data") == true) {
                        val data = json.optJSONObject("payload")?.optJSONObject("data")
                        val table = data?.optString("table")
                        if (!table.isNullOrBlank()) {
                            val typeStr = data.optString("type")
                            val eventType = when (typeStr.uppercase()) {
                                "INSERT" -> SupabaseRealtimeEvent.EventType.INSERT
                                "UPDATE" -> SupabaseRealtimeEvent.EventType.UPDATE
                                "DELETE" -> SupabaseRealtimeEvent.EventType.DELETE
                                else -> SupabaseRealtimeEvent.EventType.UNKNOWN
                            }
                            val realtimeEvent = SupabaseRealtimeEvent(
                                table = table,
                                eventType = eventType,
                                record = data.optJSONObject("record"),
                                oldRecord = data.optJSONObject("old_record"),
                                commitTimestamp = data.optString("commit_timestamp")
                            )
                            _events.tryEmit(realtimeEvent)
                            _lastEventTime.value = System.currentTimeMillis()
                            _eventCount.value += 1
                        }
                    }
                }
            }
        } catch (e: Exception) {
            Log.w(tag, "Error parsing incoming realtime message: ${e.message}")
        }
    }

    /**
     * Automatic exponential backoff reconnection.
     */
    private fun scheduleReconnect(isAuthError: Boolean = false) {
        if (!shouldBeConnected || isAuthError) return
        reconnectJob?.cancel()
        reconnectJob = scope.launch {
            val backoffSec = if (isAuthError) {
                // If auth failed, back off longer (10s to 30s) to avoid repeated rejected handshakes
                (10L * (reconnectAttempts + 1)).coerceAtMost(30L)
            } else {
                (1L shl reconnectAttempts.coerceAtMost(4)).coerceAtMost(16L)
            }
            reconnectAttempts++
            Log.i(tag, "Scheduling Realtime reconnection in ${backoffSec}s (attempt $reconnectAttempts, authError=$isAuthError)...")
            delay(backoffSec * 1000L)
            if (shouldBeConnected) {
                connect()
            }
        }
    }

    /**
     * Force immediate reconnection.
     */
    fun reconnect() {
        disconnect()
        reconnectAttempts = 0
        connect()
    }

    /**
     * Disconnect WebSocket and cancel background tasks.
     */
    fun disconnect() {
        shouldBeConnected = false
        heartbeatJob?.cancel()
        reconnectJob?.cancel()
        try {
            webSocket?.close(1000, "Normal closure")
        } catch (_: Exception) {}
        webSocket = null
        _status.value = RealtimeStatus.DISCONNECTED
        Log.i(tag, "Disconnected Supabase Realtime client")
    }

    /**
     * Convenience flow filtering for a specific table.
     */
    fun observeTable(table: String): Flow<SupabaseRealtimeEvent> =
        realtimeEvents.filter { it.table.equals(table, ignoreCase = true) }
}
