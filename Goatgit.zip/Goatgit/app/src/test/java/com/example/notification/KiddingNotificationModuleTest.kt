package com.example.notification

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.text.SimpleDateFormat
import java.util.*

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class KiddingNotificationModuleTest {

    private val context: Context get() = ApplicationProvider.getApplicationContext()

    @Test
    fun testExpectedKiddingDateCalculation150Days() {
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        val matingDateStr = "2026-01-01"
        val matingDate = sdf.parse(matingDateStr)!!

        val cal = Calendar.getInstance().apply {
            time = matingDate
            add(Calendar.DAY_OF_YEAR, 150)
        }
        val expectedKiddingDate = sdf.format(cal.time)

        // 150 days from Jan 1 in non-leap year (2026):
        // Jan: 30 days remaining, Feb: 28, Mar: 31, Apr: 30, May: 31 = 150 days -> May 31, 2026
        assertEquals("2026-05-31", expectedKiddingDate)
    }

    @Test
    fun testKiddingAlertStagesEnum() {
        val stages = KiddingAlertStage.values()
        assertTrue(stages.contains(KiddingAlertStage.OVERDUE))
        assertTrue(stages.contains(KiddingAlertStage.DUE_TODAY))
        assertTrue(stages.contains(KiddingAlertStage.DUE_TOMORROW))
        assertTrue(stages.contains(KiddingAlertStage.DUE_IN_3_DAYS))
        assertTrue(stages.contains(KiddingAlertStage.DUE_IN_7_DAYS))
        assertTrue(stages.contains(KiddingAlertStage.CDT_BOOSTER))
    }

    @Test
    fun testKiddingReminderSchedulerEnableDisableToggle() {
        KiddingReminderScheduler.setAlertsEnabled(context, true)
        assertTrue(KiddingReminderScheduler.areAlertsEnabled(context))

        KiddingReminderScheduler.setAlertsEnabled(context, false)
        assertFalse(KiddingReminderScheduler.areAlertsEnabled(context))

        // Re-enable
        KiddingReminderScheduler.setAlertsEnabled(context, true)
        assertTrue(KiddingReminderScheduler.areAlertsEnabled(context))
    }

    @Test
    fun testSendTestNotificationDoesNotCrash() {
        // Dispatches sample test notification through NotificationManagerCompat
        KiddingReminderScheduler.sendTestNotification(
            context = context,
            doeTag = "DOE-999",
            doeName = "Ginger",
            expectedKiddingDate = "2026-11-20"
        )
        // Verify channel and notification setup executes without unhandled exceptions
        assertTrue(true)
    }

    @Test
    fun testKiddingAlertItemDataModel() {
        val alert = KiddingAlertItem(
            id = "test_alert_1",
            recordId = "rec_123",
            recordType = "BreedingRecord",
            doeId = "doe_456",
            doeTag = "DOE-202",
            doeName = "Luna",
            sireTag = "BUCK-101",
            expectedKiddingDate = "2026-10-15",
            diffDays = 0L,
            gestationDay = 150,
            stage = KiddingAlertStage.DUE_TODAY,
            title = "KIDDING DUE TODAY: Doe #DOE-202",
            message = "Expected delivery is today.",
            actionRecommendation = "Prepare kidding stall & iodine dip"
        )

        assertEquals("DOE-202", alert.doeTag)
        assertEquals(0L, alert.diffDays)
        assertEquals(KiddingAlertStage.DUE_TODAY, alert.stage)
        assertEquals("BUCK-101", alert.sireTag)
    }
}
