package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.offline.AppDatabase
import com.example.data.offline.GoatEntity
import com.example.data.offline.NetworkMonitor
import com.example.data.offline.OfflineSyncManager
import com.example.data.payment.*
import com.example.data.supabase.GoatRepository
import com.example.data.supabase.SaleRecord
import com.example.data.supabase.SupabaseClient
import com.example.data.supabase.SupabaseConfig
import com.example.util.CurrencyUtils
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.util.UUID

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class PaymentAndCurrencyTest {

    private lateinit var context: Context
    private lateinit var database: AppDatabase
    private lateinit var repository: GoatRepository
    private lateinit var paymentSettings: PaymentSettingsManager
    private lateinit var paytmService: PaytmService

    @Before
    fun setup() {
        context = ApplicationProvider.getApplicationContext()
        database = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
            .allowMainThreadQueries()
            .build()

        val config = SupabaseConfig(context)
        val client = SupabaseClient(config)
        val networkMonitor = NetworkMonitor(context)
        val syncManager = OfflineSyncManager(context, database, client, networkMonitor)
        val authManager = com.example.data.backup.GoogleAuthManager(context)
        val backupManager = com.example.data.backup.BackupManager(context, database, syncManager, authManager)
        repository = GoatRepository(client, database, syncManager, backupManager)
        paymentSettings = PaymentSettingsManager(context)
        paytmService = PaytmService(config, paymentSettings)
    }

    @After
    fun tearDown() {
        database.close()
    }

    @Test
    fun testCurrencyFormattingINR() {
        assertEquals("₹1,250.00", CurrencyUtils.formatInr(1250.0))
        assertEquals("₹8,500.00", CurrencyUtils.formatInr(8500.0))
        assertEquals("₹0.00", CurrencyUtils.formatInr(0.0))
        assertEquals("₹5,000", CurrencyUtils.formatInr(5000.0, includeDecimals = false))
        assertFalse(CurrencyUtils.formatInr(1250.0).contains("$"))
        assertFalse(CurrencyUtils.formatInr(1250.0).contains("USD"))
    }

    @Test
    fun testPaytmOrderIdFormat() {
        val orderId = PaytmService.generateOrderId()
        assertTrue(orderId.startsWith("GF-"))
        assertEquals(18, orderId.length) // GF-YYYYMMDD-XXXXXX (3 + 8 + 1 + 6 = 18)
    }

    @Test
    fun testCashPaymentMarksGoatSoldAndPaidOffline() = runBlocking {
        // Insert active test goat
        val goatId = UUID.randomUUID().toString()
        database.goatDao().insertOrUpdate(
            GoatEntity(
                id = goatId,
                name = "Test Boer 1",
                tag_c = "GT-001",
                status_c = "Active"
            )
        )

        val sale = SaleRecord(
            goat_id_c = goatId,
            amount_c = 8500.0,
            sale_date_c = "2026-09-29",
            buyer_name_c = "Ramesh Kumar",
            payment_mode_c = PaymentMethod.CASH
        )

        val result = repository.recordSale(sale)
        assertTrue(result.isSuccess)

        val recorded = result.getOrThrow()
        assertEquals(PaymentStatus.PAID, recorded.payment_status_c)
        assertEquals(PaymentMethod.CASH, recorded.payment_mode_c)
        assertNotNull(recorded.payment_timestamp_c)

        // Verify goat is marked as Sold locally
        val updatedGoat = database.goatDao().getGoatById(goatId)
        assertNotNull(updatedGoat)
        assertEquals("Sold", updatedGoat?.status_c)

        // Verify transaction is recorded in local_transactions
        val txs = database.transactionDao().getAllTransactions()
        assertTrue(txs.any { it.related_id_c == recorded.id && it.payment_status_c == "PAID" && it.amount_c == 8500.0 })
    }

    @Test
    fun testUpiPaymentPendingUntilConfirmedOffline() = runBlocking {
        // Insert active test goat
        val goatId = UUID.randomUUID().toString()
        database.goatDao().insertOrUpdate(
            GoatEntity(
                id = goatId,
                name = "Test Sirohi",
                tag_c = "GT-002",
                status_c = "Active"
            )
        )

        val sale = SaleRecord(
            goat_id_c = goatId,
            amount_c = 12000.0,
            sale_date_c = "2026-09-29",
            buyer_name_c = "Suresh Patel",
            payment_mode_c = PaymentMethod.UPI_QR
        )

        // Step 1: Create sale with UPI_QR -> Must be PENDING, goat MUST NOT be sold
        val recordResult = repository.recordSale(sale)
        assertTrue(recordResult.isSuccess)
        val pendingSale = recordResult.getOrThrow()
        assertEquals(PaymentStatus.PENDING, pendingSale.payment_status_c)

        val goatBeforeConfirm = database.goatDao().getGoatById(goatId)
        assertEquals("Active", goatBeforeConfirm?.status_c) // Goat is still unsold!

        // Step 2: Confirm UPI payment received
        val confirmResult = repository.confirmUpiPayment(pendingSale, referenceNumber = "UPI987654321")
        assertTrue(confirmResult.isSuccess)
        val confirmedSale = confirmResult.getOrThrow()

        assertEquals(PaymentStatus.PAID, confirmedSale.payment_status_c)
        assertEquals(PaymentMethod.UPI_QR, confirmedSale.payment_mode_c)
        assertEquals("UPI987654321", confirmedSale.reference_c)

        // Now goat must be marked Sold
        val goatAfterConfirm = database.goatDao().getGoatById(goatId)
        assertEquals("Sold", goatAfterConfirm?.status_c)
    }

    @Test
    fun testPaytmGatewaySuccessMarksGoatSold() = runBlocking {
        val goatId = UUID.randomUUID().toString()
        database.goatDao().insertOrUpdate(
            GoatEntity(
                id = goatId,
                name = "Test Beetal",
                tag_c = "GT-003",
                status_c = "Active"
            )
        )

        val orderId = PaytmService.generateOrderId()
        val sale = SaleRecord(
            goat_id_c = goatId,
            amount_c = 15000.0,
            sale_date_c = "2026-09-29",
            buyer_name_c = "Anand Sharma",
            payment_mode_c = PaymentMethod.PAYTM_GATEWAY,
            order_id_c = orderId
        )

        // Initial creation is PENDING
        val recordResult = repository.recordSale(sale)
        val initialSale = recordResult.getOrThrow()
        assertEquals(PaymentStatus.PENDING, initialSale.payment_status_c)

        val goatBefore = database.goatDao().getGoatById(goatId)
        assertEquals("Active", goatBefore?.status_c)

        // Simulate server-side verified TXN_SUCCESS
        val verifySuccess = PaytmVerifyResult(
            isSuccess = true,
            orderId = orderId,
            paymentStatus = PaymentStatus.PAID,
            txnId = "PTM_TEST_TXN_001",
            bankTxnId = "BANK_TEST_001"
        )

        val confirmResult = repository.confirmPaytmPayment(initialSale, verifySuccess)
        assertTrue(confirmResult.isSuccess)
        val paidSale = confirmResult.getOrThrow()

        assertEquals(PaymentStatus.PAID, paidSale.payment_status_c)
        assertEquals(PaymentMethod.PAYTM_GATEWAY, paidSale.payment_mode_c)
        assertEquals("PTM_TEST_TXN_001", paidSale.transaction_id_c)
        assertEquals("BANK_TEST_001", paidSale.bank_transaction_id_c)

        val goatAfter = database.goatDao().getGoatById(goatId)
        assertEquals("Sold", goatAfter?.status_c)
    }

    @Test
    fun testPaytmGatewayFailureDoesNotMarkGoatSold() = runBlocking {
        val goatId = UUID.randomUUID().toString()
        database.goatDao().insertOrUpdate(
            GoatEntity(
                id = goatId,
                name = "Test Jamnapari",
                tag_c = "GT-004",
                status_c = "Active"
            )
        )

        val orderId = PaytmService.generateOrderId()
        val sale = SaleRecord(
            goat_id_c = goatId,
            amount_c = 9000.0,
            sale_date_c = "2026-09-29",
            buyer_name_c = "Vijay",
            payment_mode_c = PaymentMethod.PAYTM_GATEWAY,
            order_id_c = orderId
        )

        val recordResult = repository.recordSale(sale)
        val initialSale = recordResult.getOrThrow()

        // Payment failed
        val failResult = repository.markPaymentFailed(
            initialSale,
            PaymentStatus.FAILED,
            failureReason = "Bank declined"
        )
        assertTrue(failResult.isSuccess)
        val failedSale = failResult.getOrThrow()

        assertEquals(PaymentStatus.FAILED, failedSale.payment_status_c)
        assertEquals("Bank declined", failedSale.failure_reason_c)

        // Goat MUST REMAIN Active (not sold)
        val goat = database.goatDao().getGoatById(goatId)
        assertEquals("Active", goat?.status_c)

        // Unsold goats list must still include this goat
        val unsoldGoats = repository.getUnsoldGoats().getOrThrow()
        assertTrue(unsoldGoats.any { it.id == goatId })
    }
}
