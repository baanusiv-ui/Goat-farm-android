package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.fodder.FodderRepository
import com.example.data.offline.AppDatabase
import com.example.data.offline.FodderPlotEntity
import com.example.data.offline.NetworkMonitor
import com.example.data.offline.OfflineSyncManager
import com.example.data.supabase.SupabaseClient
import com.example.data.supabase.SupabaseConfig
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.util.UUID

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class FodderRowManagementTest {

    private lateinit var context: Context
    private lateinit var database: AppDatabase
    private lateinit var syncManager: OfflineSyncManager
    private lateinit var repository: FodderRepository

    @Before
    fun setUp() {
        context = ApplicationProvider.getApplicationContext()
        database = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        val config = SupabaseConfig(context)
        val client = SupabaseClient(config)
        val networkMonitor = NetworkMonitor(context)
        syncManager = OfflineSyncManager(context, database, client, networkMonitor)
        repository = FodderRepository(database, syncManager)
    }

    @After
    fun tearDown() {
        database.close()
    }

    @Test
    fun testFieldRowManagementAndSequentialHarvest() = runBlocking {
        // 1. Create Field A: 40 rows, 25 m each, 1 m row spacing
        val fieldA = FodderPlotEntity(
            id = "field-a-${UUID.randomUUID()}",
            plot_name = "Field A",
            area_value = 1.0,
            area_unit = "Acres",
            variety = "CO-4 Napier",
            row_count = 40,
            row_length = 25.0,
            row_length_unit = "metre",
            row_spacing = 1.0,
            row_spacing_unit = "metre",
            calculated_cultivated_area = 40.0 * 25.0 * 1.0, // 1000 sq.m
            species_id = "sp-co4",
            species_name = "CO-4 Hybrid Napier",
            sowing_date = "2026-06-01",
            crop_cycle_status = "Due for cutting"
        )

        // Save plot and plant all 40 rows
        val savedResult = repository.savePlot(fieldA, autoGenerateRows = true)
        assertTrue(savedResult.isSuccess)

        val initialRows = database.fodderDao().getRowsByPlot(fieldA.id)
        assertEquals(40, initialRows.size)
        assertEquals("R01", initialRows.first().row_code)
        assertEquals("R40", initialRows.last().row_code)

        // 2. Harvest rows 1–5 (R01 to R05)
        val rows1To5 = (1..5).map { "R%02d".format(it) }
        val harvest1Result = repository.recordRowHarvest(
            plotId = fieldA.id,
            selectedRowCodes = rows1To5,
            harvestedWeightKg = 150.0,
            cuttingDate = "2026-08-20",
            laborCost = 20.0,
            harvesterName = "Farmer John",
            qualityRating = "Tender & Leafy",
            notes = "First batch cutting R01-R05"
        )
        assertTrue(harvest1Result.isSuccess)
        val cut1 = harvest1Result.getOrThrow()
        assertEquals(125.0, cut1.total_harvested_row_length_m, 0.01) // 5 rows × 25 m = 125 m

        // Verify state after first harvest:
        // Total rows = 40, Harvested rows = 5, Remaining rows = 35, Harvested row length = 125 m
        val rowsAfterCut1 = database.fodderDao().getRowsByPlot(fieldA.id)
        val harvestedRowsAfterCut1 = rowsAfterCut1.filter { it.status == "Harvested" }
        val remainingRowsAfterCut1 = rowsAfterCut1.filter { it.status != "Harvested" }

        assertEquals(40, rowsAfterCut1.size)
        assertEquals(5, harvestedRowsAfterCut1.size)
        assertEquals(35, remainingRowsAfterCut1.size)
        assertEquals(125.0, harvestedRowsAfterCut1.sumOf { it.length_m }, 0.01)

        // 3. Harvest rows 6–10 (R06 to R10)
        val rows6To10 = (6..10).map { "R%02d".format(it) }
        val harvest2Result = repository.recordRowHarvest(
            plotId = fieldA.id,
            selectedRowCodes = rows6To10,
            harvestedWeightKg = 160.0,
            cuttingDate = "2026-08-21",
            laborCost = 20.0,
            harvesterName = "Farmer John",
            qualityRating = "Tender & Leafy",
            notes = "Second batch cutting R06-R10"
        )
        assertTrue(harvest2Result.isSuccess)
        val cut2 = harvest2Result.getOrThrow()
        assertEquals(125.0, cut2.total_harvested_row_length_m, 0.01)

        // Verify state after second harvest:
        // Harvested rows = 10, Remaining rows = 30, Total harvested row length = 250 m
        val rowsAfterCut2 = database.fodderDao().getRowsByPlot(fieldA.id)
        val harvestedRowsAfterCut2 = rowsAfterCut2.filter { it.status == "Harvested" }
        val remainingRowsAfterCut2 = rowsAfterCut2.filter { it.status != "Harvested" }
        val totalHarvestedLength = harvestedRowsAfterCut2.sumOf { it.length_m }

        assertEquals(10, harvestedRowsAfterCut2.size)
        assertEquals(30, remainingRowsAfterCut2.size)
        assertEquals(250.0, totalHarvestedLength, 0.01) // 10 rows × 25 m = 250 m

        // Verify Row History preservation
        val row1History = repository.getRowHarvestHistory(fieldA.id, "R01")
        assertEquals("R01", row1History.rowCode)
        assertTrue(row1History.cuttings.isNotEmpty())

        val row8History = repository.getRowHarvestHistory(fieldA.id, "R08")
        assertEquals("R08", row8History.rowCode)
        assertTrue(row8History.cuttings.isNotEmpty())

        // Verify Partial field harvest: Plot remains active
        val plotAfter = database.fodderDao().getPlotById(fieldA.id)
        assertTrue(plotAfter != null)
        assertTrue(plotAfter!!.crop_cycle_status.contains("Partial", ignoreCase = true))

        // Verify Replanting on a row without losing history
        val replantResult = repository.replantRow(
            plotId = fieldA.id,
            rowCode = "R05",
            speciesName = "CO-4 Hybrid Napier",
            variety = "CO-4",
            plantingDate = "2026-08-25",
            plantingMethod = "Rooted slips",
            materialQuantity = 50.0,
            materialUnit = "slips",
            source = "Nursery",
            cost = 25.0,
            notes = "Replanted damaged end"
        )
        assertTrue(replantResult.isSuccess)

        val row5After = database.fodderDao().getRowByCode(fieldA.id, "R05")
        assertEquals("Replanted", row5After?.status)

        // Historical cuttings still preserved!
        val row5History = repository.getRowHarvestHistory(fieldA.id, "R05")
        assertTrue(row5History.cuttings.isNotEmpty())
    }
}
