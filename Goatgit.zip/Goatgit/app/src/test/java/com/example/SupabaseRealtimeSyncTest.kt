package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.offline.AppDatabase
import com.example.data.offline.GoatEntity
import com.example.data.offline.NetworkMonitor
import com.example.data.offline.OfflineSyncManager
import com.example.data.supabase.*
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.json.JSONObject
import org.junit.After
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.util.UUID

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class SupabaseRealtimeSyncTest {

    private lateinit var context: Context
    private lateinit var database: AppDatabase
    private lateinit var client: SupabaseClient
    private lateinit var goatSyncRepository: SupabaseGoatRepository

    @Before
    fun setup() {
        context = ApplicationProvider.getApplicationContext()
        database = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
            .allowMainThreadQueries()
            .build()

        val config = SupabaseClientConfig(
            url = "https://test-project.supabase.co",
            apiKey = "test-anon-key-12345"
        )
        client = SupabaseClient(config)
        goatSyncRepository = SupabaseGoatRepository(client, database)
    }

    @After
    fun tearDown() {
        goatSyncRepository.stopRealtimeSync()
        database.close()
    }

    @Test
    fun testSupabaseClientConfigInitialization() {
        val config = SupabaseClientConfig(
            url = "https://custom-domain.supabase.co",
            apiKey = "secret-anon-key"
        )

        assertEquals("https://custom-domain.supabase.co", config.url)
        assertEquals("secret-anon-key", config.apiKey)
        assertTrue(config.hasValidKey)
        assertTrue(config.websocketUrl.startsWith("wss://custom-domain.supabase.co/realtime/v1/websocket"))
        assertTrue(config.websocketUrl.contains("apikey=secret-anon-key"))
        assertEquals("https://custom-domain.supabase.co/rest/v1", config.restUrl)
        assertEquals("https://custom-domain.supabase.co/auth/v1", config.authUrl)
    }

    @Test
    fun testSupabaseConfigStandaloneWithoutContext() {
        val config = SupabaseConfig("https://example.supabase.co", "sample-key")
        assertEquals("https://example.supabase.co", config.url)
        assertEquals("sample-key", config.publishableKey)
        assertEquals("sample-key", config.apiKey)
        assertTrue(config.hasValidKey())
        assertFalse(config.isAuthenticated())

        config.saveSession("access-token-abc", "refresh-token-xyz", "test@farm.org", "user-uuid-1")
        assertTrue(config.isAuthenticated())
        assertEquals("access-token-abc", config.accessToken)
        assertEquals("test@farm.org", config.userEmail)

        config.clearSession()
        assertFalse(config.isAuthenticated())
        assertNull(config.accessToken)
    }

    @Test
    fun testGoatDataModelCoreFields() {
        val goat = Goat(
            name = "Bella",
            tagId = "TAG-001",
            breed = "Boer",
            gender = "Doe",
            dateOfBirth = "2024-01-15",
            status = "Active",
            weightKg = 42.5
        )

        assertEquals("Bella", goat.name)
        assertEquals("TAG-001", goat.tagId)
        assertEquals("TAG-001", goat.earTagId)
        assertEquals("TAG-001", goat.tag_c)
        assertEquals("Boer", goat.breed)
        assertEquals("Boer", goat.breed_c)
        assertEquals("Doe", goat.gender)
        assertEquals("Doe", goat.sex_c)
        assertEquals("2024-01-15", goat.dateOfBirth)
        assertEquals("2024-01-15", goat.birth_date_c)
        assertEquals(42.5, goat.weight_kg_c)
    }

    @Test
    fun testRealtimeEventInsertGoat() = runBlocking {
        val goatId = UUID.randomUUID().toString()
        val insertRecord = JSONObject().apply {
            put("id", goatId)
            put("name", "Luna")
            put("tag_c", "LUNA-777")
            put("breed_c", "Jamnapari")
            put("sex_c", "Doe")
            put("status_c", "Active")
            put("birth_date_c", "2023-05-10")
            put("weight_kg_c", 38.0)
        }

        val event = SupabaseRealtimeEvent(
            table = "goats_c",
            eventType = SupabaseRealtimeEvent.EventType.INSERT,
            record = insertRecord,
            oldRecord = null
        )

        // Process real-time event
        goatSyncRepository.handleRealtimeEvent(event)

        // Verify locally persisted
        val saved = goatSyncRepository.getGoatById(goatId)
        assertNotNull(saved)
        assertEquals("Luna", saved?.name)
        assertEquals("LUNA-777", saved?.tagId)
        assertEquals("Jamnapari", saved?.breed)
        assertEquals("Doe", saved?.gender)
        assertEquals(38.0, saved?.weight_kg_c)
    }

    @Test
    fun testRealtimeEventUpdateGoat() = runBlocking {
        val goatId = UUID.randomUUID().toString()
        val initialEntity = GoatEntity(
            id = goatId,
            name = "Max",
            tag_c = "MAX-101",
            breed_c = "Sirohi",
            sex_c = "Buck",
            status_c = "Active",
            weight_kg_c = 50.0
        )
        database.goatDao().insertOrUpdate(initialEntity)

        val updatedRecord = JSONObject().apply {
            put("id", goatId)
            put("name", "Maximus")
            put("tag_c", "MAX-101")
            put("breed_c", "Sirohi")
            put("sex_c", "Buck")
            put("status_c", "Active")
            put("weight_kg_c", 55.5)
        }

        val event = SupabaseRealtimeEvent(
            table = "goats_c",
            eventType = SupabaseRealtimeEvent.EventType.UPDATE,
            record = updatedRecord,
            oldRecord = null
        )

        goatSyncRepository.handleRealtimeEvent(event)

        val updated = goatSyncRepository.getGoatById(goatId)
        assertNotNull(updated)
        assertEquals("Maximus", updated?.name)
        assertEquals(55.5, updated?.weight_kg_c)
    }

    @Test
    fun testRealtimeEventDeleteGoat() = runBlocking {
        val goatId = UUID.randomUUID().toString()
        val entity = GoatEntity(
            id = goatId,
            name = "Daisy",
            tag_c = "DAISY-009",
            breed_c = "Barbari",
            sex_c = "Doe",
            status_c = "Active"
        )
        database.goatDao().insertOrUpdate(entity)
        assertNotNull(goatSyncRepository.getGoatById(goatId))

        val oldRecord = JSONObject().apply {
            put("id", goatId)
        }

        val event = SupabaseRealtimeEvent(
            table = "goats_c",
            eventType = SupabaseRealtimeEvent.EventType.DELETE,
            record = null,
            oldRecord = oldRecord
        )

        goatSyncRepository.handleRealtimeEvent(event)

        val deleted = goatSyncRepository.getGoatById(goatId)
        assertNull(deleted)
    }

    @Test
    fun testGoatSerializationRoundTrip() {
        val goat = Goat(
            name = "Hercules",
            tagId = "HERC-99",
            breed = "Beetal",
            gender = "Buck",
            dateOfBirth = "2022-11-20",
            status = "Active",
            weightKg = 72.0
        )

        val json = goatSyncRepository.goatToJson(goat)
        assertEquals(goat.id, json.getString("id"))
        assertEquals("Hercules", json.getString("name"))
        assertEquals("HERC-99", json.getString("tag_c"))
        assertEquals("Beetal", json.getString("breed_c"))
        assertEquals("Buck", json.getString("sex_c"))
        assertEquals(72.0, json.getDouble("weight_kg_c"), 0.001)

        val parsedEntity = goatSyncRepository.parseGoatEntityFromJson(json, goat.id)
        assertEquals(goat.id, parsedEntity.id)
        assertEquals("Hercules", parsedEntity.name)
        assertEquals("HERC-99", parsedEntity.tagId)
        assertEquals("Beetal", parsedEntity.breed)
        assertEquals("Buck", parsedEntity.gender)
    }

    @Test
    fun testGoatsFlowEmitsUpdates() = runBlocking {
        val initialList = goatSyncRepository.goatsFlow.first()
        val initialCount = initialList.size

        val newGoat = Goat(
            name = "Starlight",
            tagId = "STAR-42",
            breed = "Alpine",
            gender = "Doe"
        )
        goatSyncRepository.addGoat(newGoat)

        val updatedList = goatSyncRepository.goatsFlow.first()
        assertEquals(initialCount + 1, updatedList.size)
        assertTrue(updatedList.any { it.tagId == "STAR-42" })
    }
}
