package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.offline.AppDatabase
import com.example.data.offline.NetworkMonitor
import com.example.data.offline.OfflineSyncManager
import com.example.data.supabase.*
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.util.UUID

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class MultiAccountTransactionTest {

    private lateinit var context: Context
    private lateinit var database: AppDatabase
    private lateinit var repository: GoatRepository

    @Before
    fun setup() {
        context = ApplicationProvider.getApplicationContext()
        database = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
            .allowMainThreadQueries()
            .build()

        val config = SupabaseConfig(context)
        val client = SupabaseClient(config)
        val networkMonitor = NetworkMonitor(context)
        val syncManager = OfflineSyncManager(context, database, client, networkMonitor)
        val authManager = com.example.data.backup.GoogleAuthManager(context)
        val backupManager = com.example.data.backup.BackupManager(context, database, syncManager, authManager)
        repository = GoatRepository(client, database, syncManager, backupManager)
    }

    @After
    fun tearDown() {
        database.close()
    }

    @Test
    fun testMultiAccountCreation_CashBankUpi() = runBlocking {
        // 1. Cash Account
        val cashAcc = FinancialAccount(
            id = "cash-01",
            account_name = "Farm Cash in Hand",
            account_type = "CASH",
            opening_balance = 10000.0,
            current_balance = 10000.0
        )
        val resCash = repository.finance.addAccount(cashAcc)
        assertTrue(resCash.isSuccess)

        // 2. Bank Account
        val bankAcc = FinancialAccount(
            id = "bank-01",
            account_name = "State Bank Current",
            account_type = "BANK",
            account_number = "123456789012",
            bank_name = "State Bank of India",
            ifsc_code = "SBIN0001234",
            opening_balance = 50000.0,
            current_balance = 50000.0
        )
        val resBank = repository.finance.addAccount(bankAcc)
        assertTrue(resBank.isSuccess)

        // 3. UPI Account
        val upiAcc = FinancialAccount(
            id = "upi-01",
            account_name = "Google Pay Business",
            account_type = "UPI",
            upi_id = "goatfarm@okhdfcbank",
            bank_name = "Google Pay",
            opening_balance = 5000.0,
            current_balance = 5000.0
        )
        val resUpi = repository.finance.addAccount(upiAcc)
        assertTrue(resUpi.isSuccess)

        // Verify accounts in repository
        val accounts = repository.finance.getAccounts().getOrThrow()
        assertEquals(3, accounts.size)

        val retrievedUpi = accounts.first { it.id == "upi-01" }
        assertEquals("goatfarm@okhdfcbank", retrievedUpi.upi_id)
        assertEquals("UPI", retrievedUpi.account_type)
    }

    @Test
    fun testTransfersDoNotAffectProfitAndLoss() = runBlocking {
        // Setup initial accounts: Cash ₹20,000, Bank ₹50,000, UPI ₹10,000
        val cash = repository.finance.addAccount(
            FinancialAccount(id = "c-1", account_name = "Cash", account_type = "CASH", opening_balance = 20000.0, current_balance = 20000.0)
        ).getOrThrow()

        val bank = repository.finance.addAccount(
            FinancialAccount(id = "b-1", account_name = "Bank", account_type = "BANK", opening_balance = 50000.0, current_balance = 50000.0)
        ).getOrThrow()

        val upi = repository.finance.addAccount(
            FinancialAccount(id = "u-1", account_name = "UPI", account_type = "UPI", upi_id = "farm@upi", opening_balance = 10000.0, current_balance = 10000.0)
        ).getOrThrow()

        val initialLiquidFunds = 20000.0 + 50000.0 + 10000.0 // ₹80,000

        // Check baseline P&L
        val pnlBefore = repository.getFarmFinanceSummary().getOrThrow()
        assertEquals(0.0, pnlBefore.totalIncome, 0.001)
        assertEquals(0.0, pnlBefore.totalExpenses, 0.001)
        assertEquals(0.0, pnlBefore.netProfit, 0.001)

        // 1. Transfer ₹10,000 from Cash to Bank
        val transfer1 = repository.finance.recordTransfer(
            fromAccountId = cash.id,
            toAccountId = bank.id,
            amount = 10000.0,
            date = "2026-10-01",
            description = "Cash deposit to bank"
        )
        assertTrue(transfer1.isSuccess)

        // Verify balances after Transfer 1:
        // Cash: 20000 - 10000 = 10000
        // Bank: 50000 + 10000 = 60000
        val accountsAfter1 = repository.finance.getAccounts().getOrThrow().associateBy { it.id }
        assertEquals(10000.0, accountsAfter1["c-1"]!!.current_balance, 0.001)
        assertEquals(60000.0, accountsAfter1["b-1"]!!.current_balance, 0.001)
        assertEquals(10000.0, accountsAfter1["u-1"]!!.current_balance, 0.001)

        // Total liquid funds MUST be unchanged
        val totalAfter1 = accountsAfter1.values.sumOf { it.current_balance }
        assertEquals(initialLiquidFunds, totalAfter1, 0.001)

        // P&L MUST BE COMPLETELY UNAFFECTED (Net impact: 0.0)
        val pnlAfter1 = repository.getFarmFinanceSummary().getOrThrow()
        assertEquals(0.0, pnlAfter1.totalIncome, 0.001)
        assertEquals(0.0, pnlAfter1.totalExpenses, 0.001)
        assertEquals(0.0, pnlAfter1.netProfit, 0.001)

        // 2. Transfer ₹5,000 from Bank to UPI
        val transfer2 = repository.finance.recordTransfer(
            fromAccountId = bank.id,
            toAccountId = upi.id,
            amount = 5000.0,
            date = "2026-10-01",
            description = "Top up UPI wallet from Bank"
        )
        assertTrue(transfer2.isSuccess)

        // Verify balances after Transfer 2:
        // Bank: 60000 - 5000 = 55000
        // UPI: 10000 + 5000 = 15000
        val accountsAfter2 = repository.finance.getAccounts().getOrThrow().associateBy { it.id }
        assertEquals(10000.0, accountsAfter2["c-1"]!!.current_balance, 0.001)
        assertEquals(55000.0, accountsAfter2["b-1"]!!.current_balance, 0.001)
        assertEquals(15000.0, accountsAfter2["u-1"]!!.current_balance, 0.001)

        // Total liquid funds MUST be unchanged
        val totalAfter2 = accountsAfter2.values.sumOf { it.current_balance }
        assertEquals(initialLiquidFunds, totalAfter2, 0.001)

        // P&L MUST STILL BE 100% UNAFFECTED
        val pnlAfter2 = repository.getFarmFinanceSummary().getOrThrow()
        assertEquals(0.0, pnlAfter2.totalIncome, 0.001)
        assertEquals(0.0, pnlAfter2.totalExpenses, 0.001)
        assertEquals(0.0, pnlAfter2.netProfit, 0.001)

        // Verify transaction entities have affects_pnl == false
        val txns = repository.finance.getTransactions().getOrThrow()
        assertEquals(2, txns.size)
        assertTrue(txns.all { !it.affects_pnl })
        assertTrue(txns.all { it.pillar == "NON_CASH" })
    }

    @Test
    fun testIncomeAndExpenseAffectPnLCorrectly() = runBlocking {
        val bank = repository.finance.addAccount(
            FinancialAccount(id = "bank-main", account_name = "Main Bank", account_type = "BANK", opening_balance = 50000.0, current_balance = 50000.0)
        ).getOrThrow()

        // 1. Record Income (Goat sale received via UPI into Bank)
        val incRes = repository.finance.recordIncome(
            accountId = bank.id,
            amount = 15000.0,
            category = "Goat Sale",
            date = "2026-10-01",
            paymentMode = "UPI",
            description = "Sold 2 breeding bucks"
        )
        assertTrue(incRes.isSuccess)
        val incTx = incRes.getOrThrow()
        assertTrue(incTx.affects_pnl)
        assertEquals("OPERATING", incTx.pillar)

        // 2. Record Operating Expense (Feed purchase)
        val expRes = repository.finance.recordExpense(
            accountId = bank.id,
            amount = 4000.0,
            category = "Feed & Fodder",
            date = "2026-10-01",
            paymentMode = "Bank Transfer",
            description = "Concentrate feed 500kg"
        )
        assertTrue(expRes.isSuccess)
        val expTx = expRes.getOrThrow()
        assertTrue(expTx.affects_pnl)
        assertEquals("OPERATING", expTx.pillar)

        // Verify Bank balance: 50000 + 15000 - 4000 = 61000
        val updatedBank = repository.finance.getAccounts().getOrThrow().first { it.id == bank.id }
        assertEquals(61000.0, updatedBank.current_balance, 0.001)

        // Verify P&L:
        // Income = 15000
        // Expense = 4000
        // Net Profit = 11000
        val pnl = repository.getFarmFinanceSummary().getOrThrow()
        assertEquals(15000.0, pnl.totalIncome, 0.001)
        assertEquals(4000.0, pnl.totalExpenses, 0.001)
        assertEquals(11000.0, pnl.netProfit, 0.001)
    }

    @Test
    fun testTransferValidation_SameAccountRejected() = runBlocking {
        val cash = repository.finance.addAccount(
            FinancialAccount(id = "c-same", account_name = "Cash", account_type = "CASH", opening_balance = 5000.0, current_balance = 5000.0)
        ).getOrThrow()

        val transferSame = repository.finance.recordTransfer(
            fromAccountId = cash.id,
            toAccountId = cash.id,
            amount = 1000.0,
            date = "2026-10-01"
        )
        assertFalse(transferSame.isSuccess)
    }

    @Test
    fun testTransferValidation_NegativeAmountRejected() = runBlocking {
        val cash = repository.finance.addAccount(
            FinancialAccount(id = "c-neg1", account_name = "Cash", account_type = "CASH", opening_balance = 5000.0, current_balance = 5000.0)
        ).getOrThrow()
        val bank = repository.finance.addAccount(
            FinancialAccount(id = "b-neg2", account_name = "Bank", account_type = "BANK", opening_balance = 5000.0, current_balance = 5000.0)
        ).getOrThrow()

        val transferNeg = repository.finance.recordTransfer(
            fromAccountId = cash.id,
            toAccountId = bank.id,
            amount = -500.0,
            date = "2026-10-01"
        )
        assertFalse(transferNeg.isSuccess)
    }
}
