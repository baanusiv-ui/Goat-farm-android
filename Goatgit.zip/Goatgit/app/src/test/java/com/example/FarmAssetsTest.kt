package com.example

import com.example.data.offline.FarmAssetEntity
import com.example.data.supabase.FarmAsset
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test
import java.util.UUID

class FarmAssetsTest {

    @Test
    fun testFarmAssetRequiredColumnsInitialization() {
        val asset = FarmAsset(
            id = "asset-001",
            name = "Goat Shed Alpha",
            category = "Farm Buildings",
            purchase_date = "2026-01-15",
            cost = 250000.0,
            useful_life = 10,
            current_condition = "Good",
            location = "North Pasture",
            warranty_expiry = "2031-01-15",
            maintenance_schedule = "Monthly",
            asset_id = "SHED-01",
            supplier = "Apex Rural Builders",
            quantity = 1,
            status = "Active",
            residual_value = 25000.0,
            depreciation_method = "Straight-line",
            is_capex = true
        )

        assertEquals("Goat Shed Alpha", asset.name)
        assertEquals("Farm Buildings", asset.category)
        assertEquals("2026-01-15", asset.purchase_date)
        assertEquals(250000.0, asset.cost, 0.001)
        assertEquals(10, asset.useful_life)
        assertEquals("Good", asset.current_condition)
        assertEquals("North Pasture", asset.location)
        assertEquals("2031-01-15", asset.warranty_expiry)
        assertEquals("Monthly", asset.maintenance_schedule)
        assertTrue(asset.is_capex)
    }

    @Test
    fun testStraightLineDepreciationCalculation() {
        val asset = FarmAsset(
            name = "Heavy Duty Chaff Cutter",
            category = "Equipment",
            cost = 60000.0,
            useful_life = 5,
            residual_value = 10000.0
        )

        // Depreciable amount = 60000 - 10000 = 50000
        // Annual depreciation = 50000 / 5 = 10000 / year
        // Monthly depreciation = 10000 / 12 = 833.333
        assertEquals(10000.0, asset.annualDepreciation, 0.01)
        assertEquals(833.33, asset.monthlyDepreciation, 0.01)

        // Book value after 2 years
        val bookValueYear2 = asset.calculateBookValue(yearsElapsed = 2.0)
        assertEquals(40000.0, bookValueYear2, 0.01)

        // Book value after 5 years (reaches residual value)
        val bookValueYear5 = asset.calculateBookValue(yearsElapsed = 5.0)
        assertEquals(10000.0, bookValueYear5, 0.01)

        // Book value cannot drop below residual value even after 10 years
        val bookValueYear10 = asset.calculateBookValue(yearsElapsed = 10.0)
        assertEquals(10000.0, bookValueYear10, 0.01)
    }

    @Test
    fun testSupabaseJsonPayloadSerialization() {
        val asset = FarmAsset(
            id = "test-uuid-123",
            name = "Submersible Borewell Pump",
            category = "Farm Infrastructure",
            purchase_date = "2026-03-01",
            cost = 45000.0,
            useful_life = 7,
            current_condition = "Excellent",
            location = "East Borewell",
            warranty_expiry = "2028-03-01",
            maintenance_schedule = "Quarterly"
        )

        val json = JSONObject().apply {
            put("id", asset.id)
            put("name", asset.name)
            put("category", asset.category)
            put("purchase_date", asset.purchase_date)
            put("cost", asset.cost)
            put("useful_life", asset.useful_life)
            put("current_condition", asset.current_condition)
            put("location", asset.location)
            put("warranty_expiry", asset.warranty_expiry)
            put("maintenance_schedule", asset.maintenance_schedule)
        }

        assertEquals("Submersible Borewell Pump", json.getString("name"))
        assertEquals("Farm Infrastructure", json.getString("category"))
        assertEquals("2026-03-01", json.getString("purchase_date"))
        assertEquals(45000.0, json.getDouble("cost"), 0.001)
        assertEquals(7, json.getInt("useful_life"))
        assertEquals("Excellent", json.getString("current_condition"))
        assertEquals("East Borewell", json.getString("location"))
        assertEquals("2028-03-01", json.getString("warranty_expiry"))
        assertEquals("Quarterly", json.getString("maintenance_schedule"))
    }

    @Test
    fun testRoomEntityMapping() {
        val entity = FarmAssetEntity(
            id = "entity-01",
            name = "Farm Tractor 4WD",
            category = "Vehicles",
            purchase_date = "2025-06-10",
            cost = 650000.0,
            useful_life = 12,
            current_condition = "Good",
            location = "Vehicle Garage",
            warranty_expiry = "2027-06-10",
            maintenance_schedule = "Monthly",
            asset_id = "VEH-01",
            supplier = "Mahindra Tractors",
            quantity = 1,
            status = "Active",
            residual_value = 100000.0,
            depreciation_method = "Straight-line",
            accumulated_depreciation = 45000.0,
            current_book_value = 605000.0,
            is_capex = true,
            is_synced = true
        )

        assertEquals("Farm Tractor 4WD", entity.name)
        assertEquals("Vehicles", entity.category)
        assertEquals(650000.0, entity.cost, 0.001)
        assertEquals(12, entity.useful_life)
        assertEquals("Good", entity.current_condition)
        assertEquals("Vehicle Garage", entity.location)
        assertEquals("2027-06-10", entity.warranty_expiry)
        assertEquals("Monthly", entity.maintenance_schedule)
        assertTrue(entity.is_synced)
    }
}
