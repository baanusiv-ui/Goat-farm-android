package com.example

import com.example.data.ai.AiEntryParser
import com.example.data.ai.ParsedFarmEntry
import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Test

class ExampleUnitTest {
    @Test
    fun addition_isCorrect() {
        assertEquals(4, 2 + 2)
    }

    @Test
    fun testAiEntryWeightParsing() = runBlocking {
        val parser = AiEntryParser()
        val result = parser.parseFarmerInput("Tag G102 weighed 32 kilos today")
        assertTrue(result.isSuccess)
        val entry = result.getOrNull()
        assertTrue(entry is ParsedFarmEntry.Weight)
        val weightEntry = entry as ParsedFarmEntry.Weight
        assertEquals("G102", weightEntry.tag)
        assertEquals(32.0, weightEntry.weightKg, 0.01)
    }

    @Test
    fun testAiEntryVaccinationParsing() = runBlocking {
        val parser = AiEntryParser()
        val result = parser.parseFarmerInput("Goat G102 vaccinated for PPR, next due in 6 months")
        assertTrue(result.isSuccess)
        val entry = result.getOrNull()
        assertTrue(entry is ParsedFarmEntry.Vaccination)
        val vacEntry = entry as ParsedFarmEntry.Vaccination
        assertEquals("G102", vacEntry.tag)
        assertEquals("PPR", vacEntry.vaccine)
        assertNotNull(vacEntry.nextDueDate)
    }

    @Test
    fun testAiEntryDewormingParsing() = runBlocking {
        val parser = AiEntryParser()
        val result = parser.parseFarmerInput("Goat G105 was dewormed today")
        assertTrue(result.isSuccess)
        val entry = result.getOrNull()
        assertTrue(entry is ParsedFarmEntry.Deworming)
        val dewormEntry = entry as ParsedFarmEntry.Deworming
        assertEquals("G105", dewormEntry.tag)
        assertEquals("Albendazole", dewormEntry.medicine)
    }

    @Test
    fun testBatchHealthObservationModel() {
        val goatIds = listOf("goat-1", "goat-2", "goat-3")
        val observations = goatIds.map { id ->
            com.example.data.offline.DailyHealthObservationEntity(
                goat_id = id,
                goat_tag = "TAG-$id",
                goat_name = "Goat $id",
                observation_date = "2026-10-13",
                overall_health_rating = "Healthy",
                abnormal_symptoms = "None",
                observer_name = "Farm Staff"
            )
        }
        assertEquals(3, observations.size)
        assertTrue(observations.all { it.overall_health_rating == "Healthy" })
        assertFalse(observations.any { it.hasClinicalSigns })
    }

    @Test
    fun testBatchTreatmentRecordModel() {
        val goatIds = listOf("goat-1", "goat-2")
        val treatments = goatIds.map { id ->
            com.example.data.supabase.TreatmentRecord(
                goat_id_c = id,
                symptoms_c = "External Parasites",
                diagnosis_c = "Parasite Infestation",
                medicine_c = "Ivermectin 1%",
                dose_c = "1 ml / 10 kg SC",
                start_date_c = "2026-10-13",
                outcome_c = "Under Treatment"
            )
        }
        assertEquals(2, treatments.size)
        assertEquals("Ivermectin 1%", treatments[0].medicine_c)
        assertEquals("Under Treatment", treatments[1].outcome_c)
    }
}
