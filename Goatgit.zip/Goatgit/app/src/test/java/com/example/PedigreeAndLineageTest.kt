package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.backup.BackupManager
import com.example.data.backup.GoogleAuthManager
import com.example.data.offline.AppDatabase
import com.example.data.offline.NetworkMonitor
import com.example.data.offline.OfflineSyncManager
import com.example.data.pedigree.AnimalOrigin
import com.example.data.pedigree.BreedCheckResult
import com.example.data.pedigree.PedigreeCheckResult
import com.example.data.pedigree.PedigreeManager
import com.example.data.supabase.Goat
import com.example.data.supabase.GoatRepository
import com.example.data.supabase.MatingRecord
import com.example.data.supabase.SupabaseClient
import com.example.data.supabase.SupabaseConfig
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.util.UUID

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class PedigreeAndLineageTest {

    private lateinit var context: Context
    private lateinit var database: AppDatabase
    private lateinit var repository: GoatRepository

    @Before
    fun setup() {
        context = ApplicationProvider.getApplicationContext()
        database = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
            .allowMainThreadQueries()
            .build()

        val config = SupabaseConfig(context)
        val client = SupabaseClient(config)
        val networkMonitor = NetworkMonitor(context)
        val syncManager = OfflineSyncManager(context, database, client, networkMonitor)
        val authManager = GoogleAuthManager(context)
        val backupManager = BackupManager(context, database, syncManager, authManager)
        repository = GoatRepository(client, database, syncManager, backupManager)
    }

    @After
    fun tearDown() {
        database.close()
    }

    @Test
    fun testOriginClassification() {
        val farmBorn = Goat(name = "Maya", tag_c = "F01", origin_c = "FARM_BORN")
        assertEquals(AnimalOrigin.FARM_BORN, farmBorn.effectiveOrigin)

        val marketBought = Goat(name = "Raja", tag_c = "M01", origin_c = "MARKET_BOUGHT")
        assertEquals(AnimalOrigin.MARKET_BOUGHT, marketBought.effectiveOrigin)

        val legacyPurchased = Goat(name = "Gita", tag_c = "P01", source_c = "Purchased")
        assertEquals(AnimalOrigin.MARKET_BOUGHT, legacyPurchased.effectiveOrigin)

        val legacyFarmBorn = Goat(name = "Kannan", tag_c = "B01", source_c = "Born on farm")
        assertEquals(AnimalOrigin.FARM_BORN, legacyFarmBorn.effectiveOrigin)

        val unknownOrigin = Goat(name = "UnknownGoat", tag_c = "U01", source_c = "Unknown", origin_c = null)
        assertEquals(AnimalOrigin.UNKNOWN, unknownOrigin.effectiveOrigin)
    }

    @Test
    fun testFarmBornSameBreedUnrelatedBuckAndDoeAllowed() {
        val doe = Goat(id = "doe1", name = "Daisy", tag_c = "D01", breed_c = "Boer", sex_c = "Doe", origin_c = AnimalOrigin.FARM_BORN)
        val buck = Goat(id = "buck1", name = "Billy", tag_c = "B01", breed_c = "Boer", sex_c = "Buck", origin_c = AnimalOrigin.FARM_BORN)
        val herd = listOf(doe, buck)

        val breedCheck = PedigreeManager.checkBreedCompatibility(doe, buck)
        assertTrue(breedCheck is BreedCheckResult.AllowedSameBreed)
        assertTrue(breedCheck.isAllowed)

        val pedigreeCheck = PedigreeManager.checkPedigreeCompatibility(doe, buck, herd)
        assertTrue(pedigreeCheck is PedigreeCheckResult.AllowedNoRelationship)
        assertTrue(pedigreeCheck.isAllowed)

        val eligibility = PedigreeManager.evaluateMating(doe, buck, herd)
        assertTrue(eligibility.canRecordMating)
    }

    @Test
    fun testFarmBornDifferentBreedBlockedCrossBreeding() {
        val doe = Goat(id = "doe2", name = "Bella", tag_c = "D02", breed_c = "Boer", sex_c = "Doe", origin_c = AnimalOrigin.FARM_BORN)
        val buck = Goat(id = "buck2", name = "Thor", tag_c = "B02", breed_c = "Saanen", sex_c = "Buck", origin_c = AnimalOrigin.FARM_BORN)
        val herd = listOf(doe, buck)

        val breedCheck = PedigreeManager.checkBreedCompatibility(doe, buck)
        assertTrue(breedCheck is BreedCheckResult.BlockedCrossBreeding)
        assertFalse(breedCheck.isAllowed)

        val eligibility = PedigreeManager.evaluateMating(doe, buck, herd)
        assertFalse(eligibility.canRecordMating)
        val reasonEn = eligibility.rejectionReasonEn ?: ""
        val reasonTa = eligibility.rejectionReasonTa ?: ""
        assertTrue(reasonEn.contains("CROSS-BREEDING NOT ALLOWED", ignoreCase = true))
        assertTrue(reasonTa.contains("கலப்பின", ignoreCase = true))
    }

    @Test
    fun testFarmBornParentOffspringBlocked() {
        val sire = Goat(id = "sire1", name = "Sultan", tag_c = "S01", breed_c = "Boer", sex_c = "Buck", origin_c = AnimalOrigin.FARM_BORN)
        val daughter = Goat(id = "daughter1", name = "Tara", tag_c = "D03", breed_c = "Boer", sex_c = "Doe", sire_c = "S01", origin_c = AnimalOrigin.FARM_BORN)
        val herd = listOf(sire, daughter)

        val pedigreeCheck = PedigreeManager.checkPedigreeCompatibility(daughter, sire, herd)
        assertTrue(pedigreeCheck is PedigreeCheckResult.BlockedCloseRelative)
        val blocked = pedigreeCheck as PedigreeCheckResult.BlockedCloseRelative
        assertTrue(blocked.relationshipType.contains("Offspring", ignoreCase = true) || blocked.relationshipType.contains("Parent", ignoreCase = true))

        val eligibility = PedigreeManager.evaluateMating(daughter, sire, herd)
        assertFalse(eligibility.canRecordMating)
        val reasonEn = eligibility.rejectionReasonEn ?: ""
        val reasonTa = eligibility.rejectionReasonTa ?: ""
        assertTrue(reasonEn.contains("Close-relative mating is not allowed", ignoreCase = true))
        assertTrue(reasonTa.contains("நெருங்கிய உறவினர்", ignoreCase = true))
    }

    @Test
    fun testFarmBornSiblingsBlocked() {
        val sire = Goat(id = "sireA", name = "Champion", tag_c = "SIRE_A", breed_c = "Boer", sex_c = "Buck")
        val sister = Goat(id = "doeSib", name = "Ruby", tag_c = "D_SIB", breed_c = "Boer", sex_c = "Doe", sire_c = "SIRE_A", origin_c = AnimalOrigin.FARM_BORN)
        val brother = Goat(id = "buckSib", name = "Rex", tag_c = "B_SIB", breed_c = "Boer", sex_c = "Buck", sire_c = "SIRE_A", origin_c = AnimalOrigin.FARM_BORN)
        val herd = listOf(sire, sister, brother)

        val pedigreeCheck = PedigreeManager.checkPedigreeCompatibility(sister, brother, herd)
        assertTrue(pedigreeCheck is PedigreeCheckResult.BlockedCloseRelative)

        val eligibility = PedigreeManager.evaluateMating(sister, brother, herd)
        assertFalse(eligibility.canRecordMating)
        val reasonEn = eligibility.rejectionReasonEn ?: ""
        assertTrue(reasonEn.contains("Close-relative mating is not allowed", ignoreCase = true))
    }

    @Test
    fun testUnknownBreedBlocked() {
        val doe = Goat(id = "doeU", name = "NoBreedDoe", tag_c = "D_NO_BREED", breed_c = "", sex_c = "Doe")
        val buck = Goat(id = "buckBoer", name = "BoerBuck", tag_c = "B_BOER", breed_c = "Boer", sex_c = "Buck")
        val herd = listOf(doe, buck)

        val breedCheck = PedigreeManager.checkBreedCompatibility(doe, buck)
        assertTrue(breedCheck is BreedCheckResult.BreedMissing)
        assertFalse(breedCheck.isAllowed)

        val eligibility = PedigreeManager.evaluateMating(doe, buck, herd)
        assertFalse(eligibility.canRecordMating)
        val reasonEn = eligibility.rejectionReasonEn ?: ""
        assertTrue(reasonEn.contains("Breed information required", ignoreCase = true))
    }

    @Test
    fun testMarketBoughtGoatParentsUnknownNotInvented() {
        val marketGoat = Goat(
            id = "mkt1",
            name = "MarketQueen",
            tag_c = "MQ01",
            breed_c = "Boer",
            sex_c = "Doe",
            origin_c = AnimalOrigin.MARKET_BOUGHT,
            sire_c = null,
            dam_c = null,
            purchase_date_c = "2026-01-10",
            purchase_cost_c = 15000.0
        )
        val herd = listOf(marketGoat)

        val pedigree = PedigreeManager.buildPedigree(marketGoat, herd)
        assertTrue(pedigree.isMarketBought)
        assertFalse(pedigree.hasPedigreeData)
        assertNull(pedigree.sireNode)
        assertNull(pedigree.damNode)
        assertTrue(pedigree.generation2Grandparents.isEmpty())
        assertTrue(pedigree.generation3GreatGrandparents.isEmpty())
    }

    @Test
    fun testFarmBornGoatLineageUsesSireIdAndDamId() {
        val grandSire = Goat(id = "gs1", name = "Titan", tag_c = "T01", breed_c = "Boer", sex_c = "Buck", origin_c = AnimalOrigin.FARM_BORN)
        val grandDam = Goat(id = "gd1", name = "Luna", tag_c = "L01", breed_c = "Boer", sex_c = "Doe", origin_c = AnimalOrigin.FARM_BORN)
        val sire = Goat(id = "sire10", name = "Apollo", tag_c = "A10", breed_c = "Boer", sex_c = "Buck", sire_id = "gs1", dam_id = "gd1", origin_c = AnimalOrigin.FARM_BORN)
        val dam = Goat(id = "dam10", name = "Athena", tag_c = "A20", breed_c = "Boer", sex_c = "Doe", origin_c = AnimalOrigin.FARM_BORN)
        val kid = Goat(
            id = "kid10",
            name = "Hercules",
            tag_c = "H10",
            breed_c = "Boer",
            sex_c = "Buck",
            sire_id = "sire10",
            dam_id = "dam10",
            origin_c = AnimalOrigin.FARM_BORN
        )

        assertEquals("sire10", kid.effectiveSireId)
        assertEquals("dam10", kid.effectiveDamId)
        assertTrue(kid.effectiveOrigin == AnimalOrigin.FARM_BORN)

        val herd = listOf(grandSire, grandDam, sire, dam, kid)
        val pedigree = PedigreeManager.buildPedigree(kid, herd)

        assertTrue(pedigree.isFarmBorn)
        assertFalse(pedigree.isMarketBought)
        assertTrue(pedigree.hasPedigreeData)

        // Sire & Dam Nodes (Gen 1)
        assertNotNull(pedigree.sireNode)
        assertEquals("A10", pedigree.sireNode?.tag)
        assertEquals("Apollo", pedigree.sireNode?.name)
        assertNotNull(pedigree.damNode)
        assertEquals("A20", pedigree.damNode?.tag)
        assertEquals("Athena", pedigree.damNode?.name)

        // Grandparents Nodes (Gen 2 via sire_id)
        assertEquals(2, pedigree.generation2Grandparents.size)
        val gpTags = pedigree.generation2Grandparents.map { it.tag }
        assertTrue(gpTags.contains("T01"))
        assertTrue(gpTags.contains("L01"))
    }

    @Test
    fun testMarketBoughtUnknownStatusPolicy() {
        val marketDoe = Goat(
            id = "mktDoe",
            name = "MarketDaisy",
            tag_c = "MD01",
            breed_c = "Boer",
            sex_c = "Doe",
            origin_c = AnimalOrigin.MARKET_BOUGHT,
            source_c = "Purchased from Market",
            purchase_date_c = "2026-02-15",
            purchase_cost_c = 18000.0
        )
        val herd = listOf(marketDoe)
        val pedigree = PedigreeManager.buildPedigree(marketDoe, herd)

        assertTrue(pedigree.isMarketBought)
        assertFalse(pedigree.isFarmBorn)
        assertFalse(pedigree.hasPedigreeData)
        assertNull(pedigree.sireNode)
        assertNull(pedigree.damNode)
        assertTrue(pedigree.generation1Parents.isEmpty())
        assertTrue(pedigree.generation2Grandparents.isEmpty())
        assertTrue(pedigree.generation3GreatGrandparents.isEmpty())
    }

    @Test
    fun testRecordMatingRepoValidationBlocksCrossBreedBeforeInsertion() = runBlocking {
        val doe = Goat(id = "dCross", name = "BoerDoe", tag_c = "BC01", breed_c = "Boer", sex_c = "Doe")
        val buck = Goat(id = "bCross", name = "SaanenBuck", tag_c = "SC01", breed_c = "Saanen", sex_c = "Buck")
        repository.addGoat(doe)
        repository.addGoat(buck)

        val mating = MatingRecord(
            doe_id_c = doe.id,
            buck_id_c = buck.id,
            mating_date_c = "2026-09-30",
            notes_c = "Test cross mating"
        )

        val result = repository.recordMating(mating)
        assertTrue(result.isFailure)
        val msg = result.exceptionOrNull()?.message ?: ""
        assertTrue(msg.contains("CROSS-BREEDING", ignoreCase = true))

        val matingsInDb = repository.getMatingRecords().getOrThrow()
        assertTrue(matingsInDb.none { it.doe_id_c == doe.id && it.buck_id_c == buck.id })
    }
}
