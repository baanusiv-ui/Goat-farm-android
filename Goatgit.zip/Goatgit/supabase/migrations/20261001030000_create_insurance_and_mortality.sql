-- ==============================================================================
-- Supabase Migration: create_insurance_and_mortality
-- Modules:
--   1. Livestock Insurance Management (policies, providers, quotes, claims, alerts)
--   2. Mortality & Reproductive Outcomes (abortions, deliveries, post-delivery, general/kid deaths)
-- ==============================================================================

-- 1. Insurance Providers
CREATE TABLE IF NOT EXISTS public.insurance_providers (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name TEXT NOT NULL,
    company_name TEXT NOT NULL,
    api_base_url TEXT,
    sandbox_url TEXT,
    production_url TEXT,
    api_version TEXT DEFAULT 'v1',
    auth_type TEXT DEFAULT 'API_KEY', -- API_KEY, OAUTH2, BASIC, NONE
    webhook_url TEXT,
    is_active BOOLEAN NOT NULL DEFAULT true,
    is_sandbox BOOLEAN NOT NULL DEFAULT true,
    notes TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 2. Insurance Policies (Linked to individual goat)
CREATE TABLE IF NOT EXISTS public.insurance_policies (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    goat_id UUID NOT NULL,
    goat_tag TEXT NOT NULL,
    rfid TEXT,
    goat_name TEXT,
    provider_id UUID REFERENCES public.insurance_providers(id) ON DELETE SET NULL,
    insurance_company TEXT NOT NULL,
    policy_name TEXT NOT NULL,
    policy_number TEXT,
    proposal_number TEXT,
    sum_insured NUMERIC(14, 2) NOT NULL DEFAULT 0.00,
    market_value NUMERIC(14, 2) NOT NULL DEFAULT 0.00,
    premium NUMERIC(14, 2) NOT NULL DEFAULT 0.00,
    tax_amount NUMERIC(14, 2) NOT NULL DEFAULT 0.00,
    total_premium NUMERIC(14, 2) NOT NULL DEFAULT 0.00,
    start_date DATE NOT NULL,
    expiry_date DATE NOT NULL,
    renewal_date DATE,
    status TEXT NOT NULL DEFAULT 'Draft', -- Draft, Proposal, Active, Expiring Soon, Expired, Cancelled, Claim Submitted, Claim Under Review, Claim Approved, Claim Rejected, Claim Settled
    coverage_type TEXT NOT NULL DEFAULT 'Comprehensive (Death & PTD)',
    deductible NUMERIC(14, 2) NOT NULL DEFAULT 0.00,
    claim_eligibility TEXT,
    agent_name TEXT,
    agent_contact TEXT,
    policy_document_url TEXT,
    vet_certificate_url TEXT,
    animal_photo_url TEXT,
    eartag_photo_url TEXT,
    payment_account_id TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 3. Insurance Quotes
CREATE TABLE IF NOT EXISTS public.insurance_quotes (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    goat_id UUID NOT NULL,
    goat_tag TEXT NOT NULL,
    provider_id UUID REFERENCES public.insurance_providers(id) ON DELETE SET NULL,
    provider_name TEXT NOT NULL,
    product_name TEXT NOT NULL,
    sum_insured NUMERIC(14, 2) NOT NULL,
    premium NUMERIC(14, 2) NOT NULL,
    tax_amount NUMERIC(14, 2) NOT NULL,
    total_premium NUMERIC(14, 2) NOT NULL,
    validity_date DATE NOT NULL,
    coverage_details TEXT,
    terms_and_conditions TEXT,
    exclusions TEXT,
    status TEXT NOT NULL DEFAULT 'AVAILABLE', -- AVAILABLE, ACCEPTED, REJECTED, EXPIRED
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 4. Insurance Claims
CREATE TABLE IF NOT EXISTS public.insurance_claims (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    policy_id UUID NOT NULL REFERENCES public.insurance_policies(id) ON DELETE CASCADE,
    goat_id UUID NOT NULL,
    goat_tag TEXT NOT NULL,
    mortality_event_id UUID,
    incident_date DATE NOT NULL,
    incident_type TEXT NOT NULL DEFAULT 'Death', -- Death, Accident, PTD, Theft, Sickness
    cause TEXT NOT NULL,
    description TEXT,
    location TEXT,
    vet_doctor TEXT,
    vet_certificate_url TEXT,
    photos_urls TEXT,
    eartag_photo_url TEXT,
    post_mortem_report_url TEXT,
    police_report_url TEXT,
    claim_amount NUMERIC(14, 2) NOT NULL,
    claim_number TEXT,
    submitted_date DATE,
    insurer_response TEXT,
    approved_amount NUMERIC(14, 2),
    settlement_date DATE,
    settlement_amount NUMERIC(14, 2),
    settlement_account_id TEXT,
    rejection_reason TEXT,
    status TEXT NOT NULL DEFAULT 'Draft', -- Draft, Submitted, Documents Pending, Under Review, Approved, Rejected, Partially Settled, Settled
    notes TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 5. Insurance Alerts (De-duplicated reminders)
CREATE TABLE IF NOT EXISTS public.insurance_alerts (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    policy_id UUID REFERENCES public.insurance_policies(id) ON DELETE CASCADE,
    claim_id UUID REFERENCES public.insurance_claims(id) ON DELETE CASCADE,
    goat_id UUID,
    alert_type TEXT NOT NULL, -- EXPIRY, RENEWAL_DUE, PREMIUM_DUE, PROPOSAL_PENDING, MISSING_DOCUMENTS, CLAIM_STATUS
    title TEXT NOT NULL,
    message TEXT NOT NULL,
    due_date DATE NOT NULL,
    days_before_expiry INT DEFAULT 0,
    is_dismissed BOOLEAN NOT NULL DEFAULT false,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT uq_policy_alert_schedule UNIQUE(policy_id, alert_type, days_before_expiry)
);

-- 6. Reproductive Events (Abortion, Delivery, Stillbirth, etc.)
CREATE TABLE IF NOT EXISTS public.reproductive_events (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    doe_id UUID NOT NULL,
    pregnancy_id UUID,
    sire_id UUID,
    event_type TEXT NOT NULL, -- NORMAL_DELIVERY, ABORTION, STILLBIRTH, KID_DEATH, DOE_DEATH, POST_DELIVERY_DEATH, OTHER_MORTALITY
    event_date DATE NOT NULL,
    mating_date DATE,
    expected_delivery_date DATE,
    pregnancy_age_days INT,
    number_of_fetuses INT,
    suspected_cause TEXT,
    confirmed_cause TEXT,
    cause_category TEXT, -- Disease/infection, Nutritional deficiency, Trauma/injury, Fever, Toxicity, Parasites, Medication-related, Stress, Poor body condition, Multiple pregnancy complication, Unknown, Other
    vet_diagnosis TEXT,
    symptoms TEXT,
    treatment TEXT,
    vet_doctor TEXT,
    certificate_url TEXT,
    photo_url TEXT,
    notes TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 7. Post-Delivery Monitoring Checks
CREATE TABLE IF NOT EXISTS public.post_delivery_checks (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    doe_id UUID NOT NULL,
    delivery_date DATE NOT NULL,
    check_date DATE NOT NULL,
    days_post_delivery INT NOT NULL,
    appetite TEXT DEFAULT 'Normal', -- Normal, Poor, Anorexic
    temperature NUMERIC(5, 2),
    milk_production_ltr NUMERIC(6, 2),
    complications TEXT, -- Retained placenta, Metritis, Mastitis, Milk fever, Hypocalcemia, Ketosis, Prolapse, Excessive bleeding, Fever, Infection, Weakness, Poor appetite, Milk production problem, Injury, Difficult recovery, Sudden death, None, Other
    treatment TEXT,
    medication TEXT,
    vet_visit BOOLEAN NOT NULL DEFAULT false,
    vet_doctor TEXT,
    recovery_status TEXT NOT NULL DEFAULT 'Recovering', -- Recovered, Recovering, Critical, Deceased
    notes TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 8. Mortality Events (General Goat Death, Kid Mortality, Post-Delivery Doe Death)
CREATE TABLE IF NOT EXISTS public.mortality_events (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    goat_id UUID NOT NULL,
    goat_tag TEXT NOT NULL,
    event_type TEXT NOT NULL, -- ADULT_DEATH, KID_DEATH, DOE_POST_DELIVERY_DEATH, STILLBIRTH, OTHER
    death_date DATE NOT NULL,
    death_time TEXT,
    age_at_death_days INT,
    weight_at_death NUMERIC(6, 2),
    delivery_date DATE,
    days_post_delivery INT,
    immediate_cause TEXT NOT NULL,
    underlying_cause TEXT,
    cause_certainty TEXT NOT NULL DEFAULT 'Suspected', -- Confirmed, Suspected, Unknown
    cause_category TEXT NOT NULL, -- Disease, Accident, Injury, Predator attack, Poisoning/toxicity, Parasites, Digestive problem, Respiratory problem, Reproductive complication, Post-delivery complication, Starvation/malnutrition, Heat stress, Cold stress, Unknown, Other
    disease_name TEXT,
    injury_details TEXT,
    treatment_history TEXT,
    vet_doctor TEXT,
    post_mortem_performed BOOLEAN NOT NULL DEFAULT false,
    post_mortem_report_url TEXT,
    photos_urls TEXT,
    insurance_policy_id UUID REFERENCES public.insurance_policies(id) ON DELETE SET NULL,
    insurance_claim_id UUID REFERENCES public.insurance_claims(id) ON DELETE SET NULL,
    notes TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Indexes for performance
CREATE INDEX IF NOT EXISTS idx_insurance_policies_goat ON public.insurance_policies(goat_id);
CREATE INDEX IF NOT EXISTS idx_insurance_policies_status ON public.insurance_policies(status);
CREATE INDEX IF NOT EXISTS idx_insurance_policies_expiry ON public.insurance_policies(expiry_date);
CREATE INDEX IF NOT EXISTS idx_insurance_claims_policy ON public.insurance_claims(policy_id);
CREATE INDEX IF NOT EXISTS idx_insurance_claims_goat ON public.insurance_claims(goat_id);
CREATE INDEX IF NOT EXISTS idx_reproductive_events_doe ON public.reproductive_events(doe_id);
CREATE INDEX IF NOT EXISTS idx_reproductive_events_type ON public.reproductive_events(event_type);
CREATE INDEX IF NOT EXISTS idx_post_delivery_doe ON public.post_delivery_checks(doe_id);
CREATE INDEX IF NOT EXISTS idx_mortality_events_goat ON public.mortality_events(goat_id);
CREATE INDEX IF NOT EXISTS idx_mortality_events_date ON public.mortality_events(death_date);

-- RLS
ALTER TABLE public.insurance_providers ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.insurance_policies ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.insurance_quotes ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.insurance_claims ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.insurance_alerts ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.reproductive_events ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.post_delivery_checks ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.mortality_events ENABLE ROW LEVEL SECURITY;

DO $$
BEGIN
    CREATE POLICY "Allow auth all insurance_providers" ON public.insurance_providers FOR ALL TO authenticated USING (true) WITH CHECK (true);
    CREATE POLICY "Allow anon all insurance_providers" ON public.insurance_providers FOR ALL TO anon USING (true) WITH CHECK (true);

    CREATE POLICY "Allow auth all insurance_policies" ON public.insurance_policies FOR ALL TO authenticated USING (true) WITH CHECK (true);
    CREATE POLICY "Allow anon all insurance_policies" ON public.insurance_policies FOR ALL TO anon USING (true) WITH CHECK (true);

    CREATE POLICY "Allow auth all insurance_quotes" ON public.insurance_quotes FOR ALL TO authenticated USING (true) WITH CHECK (true);
    CREATE POLICY "Allow anon all insurance_quotes" ON public.insurance_quotes FOR ALL TO anon USING (true) WITH CHECK (true);

    CREATE POLICY "Allow auth all insurance_claims" ON public.insurance_claims FOR ALL TO authenticated USING (true) WITH CHECK (true);
    CREATE POLICY "Allow anon all insurance_claims" ON public.insurance_claims FOR ALL TO anon USING (true) WITH CHECK (true);

    CREATE POLICY "Allow auth all insurance_alerts" ON public.insurance_alerts FOR ALL TO authenticated USING (true) WITH CHECK (true);
    CREATE POLICY "Allow anon all insurance_alerts" ON public.insurance_alerts FOR ALL TO anon USING (true) WITH CHECK (true);

    CREATE POLICY "Allow auth all reproductive_events" ON public.reproductive_events FOR ALL TO authenticated USING (true) WITH CHECK (true);
    CREATE POLICY "Allow anon all reproductive_events" ON public.reproductive_events FOR ALL TO anon USING (true) WITH CHECK (true);

    CREATE POLICY "Allow auth all post_delivery_checks" ON public.post_delivery_checks FOR ALL TO authenticated USING (true) WITH CHECK (true);
    CREATE POLICY "Allow anon all post_delivery_checks" ON public.post_delivery_checks FOR ALL TO anon USING (true) WITH CHECK (true);

    CREATE POLICY "Allow auth all mortality_events" ON public.mortality_events FOR ALL TO authenticated USING (true) WITH CHECK (true);
    CREATE POLICY "Allow anon all mortality_events" ON public.mortality_events FOR ALL TO anon USING (true) WITH CHECK (true);
EXCEPTION WHEN duplicate_object THEN
    NULL;
END $$;
