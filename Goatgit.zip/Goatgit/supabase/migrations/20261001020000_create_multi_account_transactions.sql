-- ==============================================================================
-- Supabase Migration: create_multi_account_transactions
-- Purpose:
--   1. Support multi-account system for Cash, Bank, and UPI accounts
--   2. Define shared 'transactions' table for Income, Expense, and Account-to-Account Transfers
--   3. Guarantee that internal Transfers do NOT affect Profit & Loss (P&L)
-- ==============================================================================

-- 1. Ensure financial_accounts has UPI support
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns 
        WHERE table_name = 'financial_accounts' AND column_name = 'upi_id'
    ) THEN
        ALTER TABLE public.financial_accounts ADD COLUMN upi_id TEXT;
    END IF;
END $$;

-- 2. Shared 'transactions' table
CREATE TABLE IF NOT EXISTS public.transactions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    date DATE NOT NULL,
    account_id UUID REFERENCES public.financial_accounts(id) ON DELETE SET NULL,
    to_account_id UUID REFERENCES public.financial_accounts(id) ON DELETE SET NULL,
    transaction_type TEXT NOT NULL, -- 'INCOME', 'EXPENSE', 'TRANSFER'
    amount NUMERIC(14, 2) NOT NULL CHECK (amount >= 0),
    category TEXT NOT NULL,
    payment_mode TEXT NOT NULL DEFAULT 'Cash', -- 'Cash', 'Bank Transfer', 'UPI', 'Cheque', 'Card'
    reference_id TEXT,
    description TEXT,
    affects_pnl BOOLEAN NOT NULL DEFAULT true,
    pillar TEXT NOT NULL DEFAULT 'OPERATING', -- 'OPERATING', 'INVESTING', 'FINANCING', 'NON_CASH'
    related_entity_type TEXT,
    related_entity_id TEXT,
    created_by TEXT DEFAULT 'user',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Ensure default rule: Transfers NEVER affect P&L
CREATE OR REPLACE FUNCTION public.trg_enforce_transfer_pnl_rule()
RETURNS TRIGGER AS $$
BEGIN
    IF UPPER(NEW.transaction_type) = 'TRANSFER' THEN
        NEW.affects_pnl := false;
        NEW.pillar := 'NON_CASH';
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_check_transfer_pnl ON public.transactions;
CREATE TRIGGER trg_check_transfer_pnl
BEFORE INSERT OR UPDATE ON public.transactions
FOR EACH ROW
EXECUTE FUNCTION public.trg_enforce_transfer_pnl_rule();

-- 3. Indexes for fast retrieval and reporting
CREATE INDEX IF NOT EXISTS idx_transactions_date ON public.transactions(date DESC);
CREATE INDEX IF NOT EXISTS idx_transactions_type ON public.transactions(transaction_type);
CREATE INDEX IF NOT EXISTS idx_transactions_account ON public.transactions(account_id);
CREATE INDEX IF NOT EXISTS idx_transactions_to_account ON public.transactions(to_account_id);
CREATE INDEX IF NOT EXISTS idx_transactions_affects_pnl ON public.transactions(affects_pnl);
CREATE INDEX IF NOT EXISTS idx_financial_accounts_type ON public.financial_accounts(account_type);

-- 4. Row Level Security
ALTER TABLE public.transactions ENABLE ROW LEVEL SECURITY;

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_policies WHERE tablename = 'transactions' AND policyname = 'Allow authenticated read/write transactions'
    ) THEN
        CREATE POLICY "Allow authenticated read/write transactions" ON public.transactions
            FOR ALL TO authenticated USING (true) WITH CHECK (true);
    END IF;

    IF NOT EXISTS (
        SELECT 1 FROM pg_policies WHERE tablename = 'transactions' AND policyname = 'Allow anon read/write transactions'
    ) THEN
        CREATE POLICY "Allow anon read/write transactions" ON public.transactions
            FOR ALL TO anon USING (true) WITH CHECK (true);
    END IF;
END $$;

-- 5. Accounting View: P&L Transactions (Guarantees transfers are excluded)
CREATE OR REPLACE VIEW public.pnl_transactions AS
SELECT * FROM public.transactions
WHERE affects_pnl = true AND UPPER(transaction_type) != 'TRANSFER';
