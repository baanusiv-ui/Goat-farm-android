# Streamlined Dashboard Layout & Unified Operational Hubs

Streamlines the main dashboard by removing individual Breeding, Delivery, Deworming, and Weaning tiles, consolidating all reproduction and kidding cycles into the unified **Breeding & Kids Hub**, integrating deworming into **Health Records** and the **Quick Add** action menu, and arranging the remaining operational modules in a clean 3-column grid.

---

### User Review & Critical Decisions

> [!IMPORTANT]
> The following architectural decisions were confirmed directly through your answers:
> - **Breeding, Delivery & Weaning Consolidation**: Individual tiles for Breeding, Delivery, and Weaning are completely removed from the dashboard grid. All mating logs, pregnancy monitoring, delivery/kidding records, and kid weaning schedules are accessed via the unified **Breeding & Kids Hub** module (`breeding_hub`).
> - **Deworming Integration**: The standalone Deworming tile is removed from the dashboard grid. Deworming scheduling and logs are managed inside **Health Records** (`health`), while one-tap recording remains accessible via the floating **Quick Add (+)** menu.
> - **Layout Structure**: Retains a high-density, clean **3-column operational icon grid** with distinct category-colored icon cards, accessible 48dp touch targets, and streamlined visual hierarchy.
> - **Customization & State Sanitization**: Filters and purges legacy tile IDs from both `getDefaultDashboardModules()` and any locally persisted `dashboard_customization` JSON in the database so removed tiles do not reappear.

---

### 1. Overview & Core Concept

As a farm grows, presenting every sub-task as an independent tile on the dashboard creates visual noise and fragmentation. This update shifts the dashboard paradigm from fragmented task buttons to comprehensive command hubs:

```
┌────────────────────────────────────────────────────────────────────────┐
│                      Streamlined Farm Dashboard                        │
│                                                                        │
│   [ ☰ Menu ]  [ 🐐 Sunrise Goat Farm ]             [ 🔍 ] [ 🔔 ] [ ⚙️ ] │
│                                                                        │
│   ┌────────────────────────────────────────────────────────────────┐   │
│   │ FARM LIVE STATUS:  Total Goats • Pregnant • Health • Offspring │   │
│   └────────────────────────────────────────────────────────────────┘   │
│                                                                        │
│   ┌──────────────────┐  ┌──────────────────┐  ┌──────────────────┐     │
│   │      GOATS       │  │      BREEDS      │  │     WEIGHTS      │     │
│   │   Herd Roster    │  │  Classification  │  │   Growth Logs    │     │
│   └──────────────────┘  └──────────────────┘  └──────────────────┘     │
│   ┌──────────────────┐  ┌──────────────────┐  ┌──────────────────┐     │
│   │ BREEDING & KIDS  │  │      HEALTH      │  │BIOSECURITY & RISK│     │
│   │ Mating/Kids/Wean │  │ Vaccines/Deworm  │  │ Quarantine/Insur │     │
│   └──────────────────┘  └──────────────────┘  └──────────────────┘     │
│   ┌──────────────────┐  ┌──────────────────┐  ┌──────────────────┐     │
│   │   FEED & STOCK   │  │   GREEN FODDER   │  │      SALES       │     │
│   │ Feed Inventory   │  │ Silage & Pasture │  │ Goats & Manure   │     │
│   └──────────────────┘  └──────────────────┘  └──────────────────┘     │
│   ┌──────────────────┐  ┌──────────────────┐  ┌──────────────────┐     │
│   │     EXPENSES     │  │     FINANCE      │  │     REPORTS      │     │
│   │ Operating Costs  │  │  P&L / Cashflow  │  │   PDF & Audits   │     │
│   └──────────────────┘  └──────────────────┘  └──────────────────┘     │
│                                                                        │
│                                                     ┌───────────┐      │
│                                                     │  [ + ]    │      │
│                                                     │ Quick Add │      │
│                                                     └───────────┘      │
└────────────────────────────────────────────────────────────────────────┘
```

1. **Reproduction & Life-Cycle Hub**:
   Instead of scattering Breeding, Delivery, and Weaning across separate cards, farmers tap **Breeding & Kids Hub** to access tabbed workflows:
   - *Tab 0*: Active Mating & Breeding Pairings
   - *Tab 1*: Confirmed Pregnancy Monitoring & Gestation Tracking
   - *Tab 2*: Delivery, Kidding Logs & Birth Weight Registration
   - *Tab 3*: Weaning Stage Schedules & Post-weaning Transition

2. **Preventative Health Command**:
   Instead of a standalone Deworming card competing with Health, farmers access Deworming directly inside **Health Records** (under preventative deworming protocols) and can instantly log doses via the **Quick Add (+)** floating button.

3. **Streamlined Live Status Strip**:
   Keeps the top status metrics clean, focusing on herd numbers, pregnant does, health alert count, and off-spring.

---

### 2. User Experience & Visual Design

#### A. Clean 3-Column Module Grid (`DashboardScreen.kt`)
- **Grid Layout**: Responsive 3-column layout on standard mobile screens (4 columns on tablets).
- **Tile Appearance**:
  - Soft tonal container shapes (16.dp rounded corners) with 48dp circular icon badges.
  - Distinct pastel container colors with bold glyph tints (Emerald for Livestock, Pink for Breeding & Kids, Teal for Health, Blue for Biosecurity, Green for Fodder, Gold/Amber for Finance).
  - Clear, crisp 2-line label typography (`labelMedium`, 11.sp, `FontWeight.SemiBold`).
  - Active badge counters where appropriate (e.g., pending health alerts, expiring insurance, due payments).
- **Explicit Omission of Redundant Tiles**:
  - `breeding` ➔ Removed (merged into `breeding_hub`)
  - `delivery` ➔ Removed (merged into `breeding_hub`)
  - `deworming` ➔ Removed (merged into `health` & Quick Add)
  - `weaning` ➔ Removed (merged into `breeding_hub`)

#### B. Quick Add Bottom Sheet
- The floating action button `[+]` remains the fastest way to log single events in the field without navigating deep into menus:
  - Add New Goat
  - Record Weight
  - Log Vaccination
  - Log Deworming (Instant direct dialog)
  - Record Delivery / Kidding
  - Record Treatment
  - Feed Purchase & Stock

#### C. Navigation Drawer & Customize Center
- In the "Customize Dashboard" dialog, module lists are updated to only offer primary operational hubs, preventing users from seeing disconnected obsolete entries.
- In the Navigation Drawer, options are neatly categorized under Livestock, Breeding & Offspring, Health & Biosecurity, and Finance.

---

### 3. Key Product Decisions & Trade-Offs

- **Decision 1: Unified Hub vs. Micro-tiles**:
  - *Chosen Approach*: Group lifecycle stages (breeding, delivery, weaning) under a single multi-tab hub rather than occupying 3-4 separate dashboard tiles.
  - *Why*: Reduces cognitive clutter, maintains a clean above-the-fold view of the farm, and provides a cohesive chronological timeline of an animal's reproductive cycle.
- **Decision 2: Retention of Direct Quick Actions**:
  - *Chosen Approach*: Keep direct shortcuts in the Quick Add menu and navigation drawer while clearing the main grid.
  - *Why*: Daily field operations (like deworming a batch or recording sudden kidding) can still be done with 1 tap without sacrificing the clean dashboard layout.
- **Decision 3: Backward Compatibility for Saved Customizations**:
  - *Chosen Approach*: Filter out removed module IDs (`breeding`, `delivery`, `deworming`, `weaning`) when loading `dashboard_customization` from local storage.
  - *Why*: Prevents previously saved layouts on user devices from reviving deleted tiles.

---

### 4. Technical Architecture & Navigation Flow

```
┌────────────────────────────────────────────────────────────────────────┐
│                           Dashboard Screen                             │
│                                                                        │
│   ┌────────────────────────────────────────────────────────────────┐   │
│   │                      QuickStatusArea                           │   │
│   │      Total Goats  │  Pregnant Does  │  Health  │  Offspring    │   │
│   └────────────────────────────────────────────────────────────────┘   │
│                                                                        │
│   ┌────────────────────────────────────────────────────────────────┐   │
│   │                  3-Column ModuleGrid                           │   │
│   │                                                                │   │
│   │  [ Goats ]        [ Breeds ]        [ Weights ]                │   │
│   │  [ Breeding Hub ] [ Health ]        [ Biosecurity Hub ]        │   │
│   │  [ Feed Stock ]   [ Green Fodder ]  [ Sales ]                  │   │
│   │  [ Expenses ]     [ Finance ]       [ Reports ]                │   │
│   │  [ Assets ]       [ Insurance Due ] [ Settings ]               │   │
│   └────────────────────────────────────────────────────────────────┘   │
│             │                  │                                       │
│             ▼                  ▼                                       │
│   ┌──────────────────┐  ┌──────────────────┐                           │
│   │  Breeding Hub    │  │  Health Screen   │                           │
│   │  - Breeding (0)  │  │  - Vaccines      │                           │
│   │  - Pregnancy (1) │  │  - Deworming     │                           │
│   │  - Delivery (2)  │  │  - Treatments    │                           │
│   │  - Weaning (3)   │  │  - Disease Logs  │                           │
│   └──────────────────┘  └──────────────────┘                           │
└────────────────────────────────────────────────────────────────────────┘
```

- **Files Targeted for Implementation**:
  1. `app/src/main/java/com/example/ui/screens/DashboardScreen.kt`:
     - Update `getDefaultDashboardModules()` to remove any individual tile items for `breeding`, `delivery`, `deworming`, and `weaning`.
     - In `loadDashboardData()`, explicitly filter out legacy tile IDs (`breeding`, `delivery`, `deworming`, `weaning`) when parsing saved `dashboard_customization` JSON.
     - Update `onModuleClicked()` routing and badge helper functions to keep navigation clean and consolidated.
  2. `app/src/main/java/com/example/ui/components/QuickStatusArea.kt`:
     - Ensure the horizontal status strip maintains a clean, balanced layout focused on core livestock aggregates.
